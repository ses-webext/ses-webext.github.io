//Ensure browser variable from web-ext polyfills is available if ran on Service Worker
self.browser = browser; 

// support both browserAction from manifest v2 and action from manifest v3
if(!browser.action) {
    browser.action = browser.browserAction;
}