window.browser = window.browser || chrome;

browser.runtime.onMessage.addListener(handleMessage);

function handleMessage({ data, layout }) {
    document.head.innerHTML += `
    <style>
        table {
            border-collapse: collapse;
        }
        tr, td, th {
            border: 1px solid black;
            padding: 0.25em 0.5em;
        }
    </style>
    `;

    const table = create(data, layout);

    document.body.appendChild(table);
}

function sendReadyMessage() {
    browser.tabs.getCurrent(info => {
        browser.runtime.sendMessage({ tabId: info.id });
    });
}

sendReadyMessage();


function create(data, layout) {
    const table = document.createElement('table');
    const thead = document.createElement('thead');
    let tbody = document.createElement('tbody');
    table.appendChild(thead);
    table.appendChild(tbody);

    const headers = layout.map(c => th(c.name, e => filter(c.propName, e.target.value)));
    const row = tr(headers);
    thead.appendChild(row);

    // Compose index
    const entries = [];
    for (let row of data) {
        entries.push({
            entry: row,
            element: tr(layout.map(c => td(row[c.propName])))
        });
    }
    entries.map(e => tbody.appendChild(e.element));

    return table;

    function filter(propName, value) {
        console.log(propName, value);
        const newBody = document.createElement('tbody');
        for (let entry of entries) {
            if (entry.entry[propName].toString().toLowerCase().includes(value.toLowerCase())) {
                newBody.appendChild(entry.element);
            }
        }
        table.replaceChild(newBody, tbody);
        tbody = newBody;
    }
}

function tr(cols) {
    const element = document.createElement('tr');
    cols.map(col => element.appendChild(col));
    return element;
}

function th(contents, onInput) {
    const element = document.createElement('th');
    element.appendChild(document.createTextNode(contents));
    const input = document.createElement('input');
    element.appendChild(input);
    input.addEventListener('input', onInput);

    return element;
}

function td(contents) {
    const element = document.createElement('td');
    element.appendChild(document.createTextNode(contents));
    return element;
}