window.browser = window.browser || chrome;

browser.runtime.onMessage.addListener(handleMessage);

function handleMessage(m) {
    document.body.innerHTML = m;
}

function sendReadyMessage() {
    browser.tabs.getCurrent(info => {
        browser.runtime.sendMessage({ tabId: info.id });
    });
}

sendReadyMessage();