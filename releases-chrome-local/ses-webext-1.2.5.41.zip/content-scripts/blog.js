/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/awesome-notifications/src/constants.js":
/*!*************************************************************!*\
  !*** ./node_modules/awesome-notifications/src/constants.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "eConsts": () => (/* binding */ eConsts),
/* harmony export */   "mConsts": () => (/* binding */ mConsts),
/* harmony export */   "tConsts": () => (/* binding */ tConsts)
/* harmony export */ });
const libName = "awn"
const prefix = {
  popup: `${libName}-popup`,
  toast: `${libName}-toast`,
  btn: `${libName}-btn`,
  confirm: `${libName}-confirm`
}

// Constants for toasts
const tConsts = {
  prefix: prefix.toast,
  klass: {
    label: `${prefix.toast}-label`,
    content: `${prefix.toast}-content`,
    icon: `${prefix.toast}-icon`,
    progressBar: `${prefix.toast}-progress-bar`,
    progressBarPause: `${prefix.toast}-progress-bar-paused`
  },
  ids: {
    container: `${prefix.toast}-container`
  }
}

// Constants for popups
const mConsts = {
  prefix: prefix.popup,
  klass: {
    buttons: `${libName}-buttons`,
    button: prefix.btn,
    successBtn: `${prefix.btn}-success`,
    cancelBtn: `${prefix.btn}-cancel`,
    title: `${prefix.popup}-title`,
    body: `${prefix.popup}-body`,
    content: `${prefix.popup}-content`,
    dotAnimation: `${prefix.popup}-loading-dots`
  },
  ids: {
    wrapper: `${prefix.popup}-wrapper`,
    confirmOk: `${prefix.confirm}-ok`,
    confirmCancel: `${prefix.confirm}-cancel`
  }
}

const eConsts = {
  klass: {
    hiding: `${libName}-hiding`
  },
  lib: libName
}


/***/ }),

/***/ "./node_modules/awesome-notifications/src/elem.js":
/*!********************************************************!*\
  !*** ./node_modules/awesome-notifications/src/elem.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./constants */ "./node_modules/awesome-notifications/src/constants.js");


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (class {
    constructor(parent, id, klass, style, options) {
        this.newNode = document.createElement('div')
        if (id) this.newNode.id = id
        if (klass) this.newNode.className = klass
        if (style) this.newNode.style.cssText = style
        this.parent = parent
        this.options = options
    }
    beforeInsert() {}
    afterInsert() {}
    insert() {
        this.beforeInsert()
        this.el = this.parent.appendChild(this.newNode)
        this.afterInsert()
        return this
    }

    replace(el) {
        if (!this.getElement()) return
        return this.beforeDelete().then(() => {
            this.updateType(el.type)
            this.parent.replaceChild(el.newNode, this.el)
            this.el = this.getElement(el.newNode)
            this.afterInsert()
            return this
        })
    }

    beforeDelete(el = this.el) {
        let timeLeft = 0
        if (this.start) {
            timeLeft = this.options.minDurations[this.type] + this.start - Date.now()
            if (timeLeft < 0) timeLeft = 0
        }

        return new Promise(resolve => {
            setTimeout(() => {
                el.classList.add(_constants__WEBPACK_IMPORTED_MODULE_0__.eConsts.klass.hiding)
                setTimeout(resolve, this.options.animationDuration)
            }, timeLeft)
        })
    }

    delete(el = this.el) {
        if (!this.getElement(el)) return null
        return this.beforeDelete(el).then(() => {
            el.remove()
            this.afterDelete()
        })
    }
    afterDelete() {}

    getElement(el = this.el) {
        if (!el) return null
        return document.getElementById(el.id)
    }

    addEvent(name, func) {
        this.el.addEventListener(name, func)
    }

    toggleClass(klass) {
        this.el.classList.toggle(klass)
    }
    updateType(type) {
        this.type = type
        this.duration = this.options.duration(this.type)
    }
});

/***/ }),

/***/ "./node_modules/awesome-notifications/src/index.js":
/*!*********************************************************!*\
  !*** ./node_modules/awesome-notifications/src/index.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Notifier)
/* harmony export */ });
/* harmony import */ var _options__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./options */ "./node_modules/awesome-notifications/src/options.js");
/* harmony import */ var _toast__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./toast */ "./node_modules/awesome-notifications/src/toast.js");
/* harmony import */ var _popup__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./popup */ "./node_modules/awesome-notifications/src/popup.js");
/* harmony import */ var _elem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./elem */ "./node_modules/awesome-notifications/src/elem.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./constants */ "./node_modules/awesome-notifications/src/constants.js");







class Notifier {
  constructor(options = {}) {
    this.options = new _options__WEBPACK_IMPORTED_MODULE_0__["default"](options)
  }

  tip(msg, options) {
    return this._addToast(msg, "tip", options).el
  }

  info(msg, options) {
    return this._addToast(msg, "info", options).el
  }

  success(msg, options) {
    return this._addToast(msg, "success", options).el
  }

  warning(msg, options) {
    return this._addToast(msg, "warning", options).el
  }

  alert(msg, options) {
    return this._addToast(msg, "alert", options).el
  }

  async (promise, onResolve, onReject, msg, options) {
    let asyncToast = this._addToast(msg, "async", options)
    return this._afterAsync(promise, onResolve, onReject, options, asyncToast)
  }

  confirm(msg, onOk, onCancel, options) {
    return this._addPopup(msg, "confirm", options, onOk, onCancel)
  }

  asyncBlock(promise, onResolve, onReject, msg, options) {
    let asyncBlock = this._addPopup(msg, "async-block", options)
    return this._afterAsync(promise, onResolve, onReject, options, asyncBlock)
  }

  modal(msg, className, options) {
    return this._addPopup(msg, className, options)
  }

  closeToasts() {
    let c = this.container
    while (c.firstChild) {
      c.removeChild(c.firstChild)
    }
  }

  // Tools
  _addPopup(msg, className, options, onOk, onCancel) {
    return new _popup__WEBPACK_IMPORTED_MODULE_2__["default"](msg, className, this.options.override(options), onOk, onCancel)
  }

  _addToast(msg, type, options, old) {
    options = this.options.override(options)
    let newToast = new _toast__WEBPACK_IMPORTED_MODULE_1__["default"](msg, type, options, this.container)
    if (old) {
      if (old instanceof _popup__WEBPACK_IMPORTED_MODULE_2__["default"]) return old.delete().then(() => newToast.insert())
      let i = old.replace(newToast)
      return i
    }
    return newToast.insert()
  }

  _afterAsync(promise, onResolve, onReject, options, oldElement) {
    return promise.then(
      this._responseHandler(onResolve, "success", options, oldElement),
      this._responseHandler(onReject, "alert", options, oldElement)
    )
  }

  _responseHandler(payload, toastName, options, oldElement) {
    return result => {
      switch (typeof payload) {
        case 'undefined':
        case 'string':
          let msg = toastName === 'alert' ? payload || result : payload
          this._addToast(msg, toastName, options, oldElement)
          break
        default:
          oldElement.delete().then(() => {
            if (payload) payload(result)
          })
      }
    }
  }

  _createContainer() {
    return new _elem__WEBPACK_IMPORTED_MODULE_3__["default"](document.body, _constants__WEBPACK_IMPORTED_MODULE_4__.tConsts.ids.container, `awn-${this.options.position}`).insert().el
  }

  get container() {
    return document.getElementById(_constants__WEBPACK_IMPORTED_MODULE_4__.tConsts.ids.container) || this._createContainer()
  }
}


/***/ }),

/***/ "./node_modules/awesome-notifications/src/options.js":
/*!***********************************************************!*\
  !*** ./node_modules/awesome-notifications/src/options.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Options)
/* harmony export */ });
const defaults = {
  maxNotifications: 10,
  animationDuration: 300,
  position: "bottom-right",
  labels: {
    tip: "Tip",
    info: "Info",
    success: "Success",
    warning: "Attention",
    alert: "Error",
    async: "Loading",
    confirm: "Confirmation required",
    confirmOk: "OK",
    confirmCancel: "Cancel"
  },
  icons: {
    tip: "question-circle",
    info: "info-circle",
    success: "check-circle",
    warning: "exclamation-circle",
    alert: "exclamation-triangle",
    async: "cog fa-spin",
    confirm: "exclamation-triangle",
    prefix: "<i class='fa fas fa-fw fa-",
    suffix: "'></i>",
    enabled: true
  },
  replacements: {
    tip: null,
    info: null,
    success: null,
    warning: null,
    alert: null,
    async: null,
    "async-block": null,
    modal: null,
    confirm: null,
    general: {
      "<script>": "",
      "</script>": ""
    }
  },
  messages: {
    tip: "",
    info: "",
    success: "Action has been succeeded",
    warning: "",
    alert: "Action has been failed",
    confirm: "This action can't be undone. Continue?",
    async: "Please, wait...",
    "async-block": "Loading"
  },
  formatError(err) {
    if (err.response) {
      if (!err.response.data) return '500 API Server Error'
      if (err.response.data.errors) {
        return err.response.data.errors.map(o => o.detail).join('<br>')
      }
      if (err.response.statusText) {
        return `${err.response.status} ${err.response.statusText}: ${err.response.data}`
      }
    }
    if (err.message) return err.message
    return err
  },
  durations: {
    global: 5000,
    success: null,
    info: null,
    tip: null,
    warning: null,
    alert: null
  },
  minDurations: {
    async: 1000,
    "async-block": 1000
  },
}
class Options {
  constructor(options = {}, global = defaults) {
    Object.assign(this, this.defaultsDeep(global, options))
  }

  icon(type) {
    if (this.icons.enabled) return `${this.icons.prefix}${this.icons[type]}${this.icons.suffix}`
    return ''
  }

  label(type) {
    return this.labels[type]
  }

  duration(type) {
    let duration = this.durations[type]
    return duration === null ? this.durations.global : duration
  }

  toSecs(value) {
    return `${value / 1000}s`
  }

  applyReplacements(str, type) {
    if (!str) return this.messages[type] || ""
    for (const n of ['general', type]) {
      if (!this.replacements[n]) continue
      for (const k in this.replacements[n]) {
        str = str.replace(k, this.replacements[n][k])
      }
    }
    return str
  }

  override(options) {
    if (options) return new Options(options, this)
    return this
  }

  defaultsDeep(defaults, overrides) {
    let result = {}
    for (const k in defaults) {
      if (overrides.hasOwnProperty(k)) {
        result[k] = typeof defaults[k] === "object" && defaults[k] !== null ? this.defaultsDeep(defaults[k], overrides[k]) : overrides[k]
      } else {
        result[k] = defaults[k]
      }
    }
    return result
  }
}


/***/ }),

/***/ "./node_modules/awesome-notifications/src/popup.js":
/*!*********************************************************!*\
  !*** ./node_modules/awesome-notifications/src/popup.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _elem__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./elem */ "./node_modules/awesome-notifications/src/elem.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./constants */ "./node_modules/awesome-notifications/src/constants.js");



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (class extends _elem__WEBPACK_IMPORTED_MODULE_0__["default"] {
  constructor(msg, type = 'modal', options, onOk, onCancel) {
    let animationDuration = `animation-duration: ${options.toSecs(options.animationDuration)};`
    super(document.body, _constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.wrapper, null, animationDuration, options)
    this[_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmOk] = onOk
    this[_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmCancel] = onCancel
    this.className = `${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.prefix}-${type}`
    if (!['confirm', 'async-block', 'modal'].includes(type)) type = 'modal'
    this.updateType(type)
    this.setInnerHtml(msg)
    this.insert()
  }

  setInnerHtml(html) {
    let innerHTML = this.options.applyReplacements(html, this.type)
    switch (this.type) {
      case "confirm":
        let buttons = [`<button class='${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.button} ${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.successBtn}'id='${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmOk}'>${this.options.labels.confirmOk}</button>`]
        if (this[_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmCancel] !== false) {
          buttons.push(`<button class='${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.button} ${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.cancelBtn}'id='${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmCancel}'>${this.options.labels.confirmCancel}</button>`)
        }
        innerHTML = `${this.options.icon(this.type)}<div class='${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.title}'>${this.options.label(this.type)}</div><div class="${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.content}">${innerHTML}</div><div class='${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.buttons} ${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.buttons}-${buttons.length}'>${buttons.join('')}</div>`
        break
      case "async-block":
        innerHTML = `${innerHTML}<div class="${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.dotAnimation}"></div>`
    }
    this.newNode.innerHTML = `<div class="${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.body} ${this.className}">${innerHTML}</div>`
  }

  keyupListener(e) {
    if (this.type === 'async-block') return e.preventDefault()
    switch (e.code) {
      case 'Escape':
        e.preventDefault()
        this.delete()
      case 'Tab':
        e.preventDefault()
        if (this.type !== 'confirm' || this[_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmCancel] === false) return true
        let next = this.okBtn
        if (e.shiftKey) {
          if (document.activeElement.id == _constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmOk) next = this.cancelBtn
        } else if (document.activeElement.id !== _constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmCancel) next = this.cancelBtn
        next.focus()
    }
  }
  afterInsert() {
    this.listener = e => this.keyupListener(e)
    window.addEventListener("keydown", this.listener)
    switch (this.type) {
      case 'async-block':
        this.start = Date.now()
        break
      case 'confirm':
        this.okBtn.focus()
        this.addEvent("click", e => {
          if (e.target.nodeName !== "BUTTON") return false
          this.delete()
          if (this[e.target.id]) this[e.target.id]()
        })
        break
      default:
        document.activeElement.blur()
        this.addEvent("click", e => {
          if (e.target.id === this.newNode.id) this.delete()
        })
    }
  }

  afterDelete() {
    window.removeEventListener("keydown", this.listener)
  }

  get okBtn() {
    return document.getElementById(_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmOk)
  }

  get cancelBtn() {
    return document.getElementById(_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmCancel)
  }
});


/***/ }),

/***/ "./node_modules/awesome-notifications/src/timer.js":
/*!*********************************************************!*\
  !*** ./node_modules/awesome-notifications/src/timer.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (class {
  constructor(callback, delay) {
    this.callback = callback
    this.remaining = delay
    this.resume()
  }
  pause() {
    this.paused = true
    window.clearTimeout(this.timerId)
    this.remaining -= new Date() - this.start
  }
  resume() {
    this.paused = false
    this.start = new Date()
    window.clearTimeout(this.timerId)
    this.timerId = window.setTimeout(() => {
      window.clearTimeout(this.timerId)
      this.callback()
    }, this.remaining)
  }
  toggle() {
    if (this.paused) this.resume()
    else this.pause()
  }
});


/***/ }),

/***/ "./node_modules/awesome-notifications/src/toast.js":
/*!*********************************************************!*\
  !*** ./node_modules/awesome-notifications/src/toast.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _elem__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./elem */ "./node_modules/awesome-notifications/src/elem.js");
/* harmony import */ var _timer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./timer */ "./node_modules/awesome-notifications/src/timer.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./constants */ "./node_modules/awesome-notifications/src/constants.js");





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (class extends _elem__WEBPACK_IMPORTED_MODULE_0__["default"] {
  constructor(msg, type, options, parent) {
    super(
      parent,
      `${_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.prefix}-${Math.floor(Date.now() - Math.random() * 100)}`,
      `${_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.prefix} ${_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.prefix}-${type}`,
      `animation-duration: ${options.toSecs(options.animationDuration)};`,
      options
    )
    this.updateType(type)
    this.setInnerHtml(msg)
  }

  setInnerHtml(html) {
    if (this.type === 'alert' && html) html = this.options.formatError(html)
    html = this.options.applyReplacements(html, this.type)
    this.newNode.innerHTML = `<div class="awn-toast-wrapper">${this.progressBar}${this.label}<div class="${_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.klass.content}">${html}</div><span class="${_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.klass.icon}">${this.options.icon(this.type)}</span></div>`
  }

  beforeInsert() {
    if (this.parent.childElementCount >= this.options.maxNotifications) {
      let elements = Array.from(this.parent.getElementsByClassName(_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.prefix))
      this.delete(elements.find(e => !this.isDeleted(e)))
    }
  }
  afterInsert() {
    if (this.type == "async") return this.start = Date.now()

    this.addEvent("click", () => this.delete())

    if (this.duration <= 0) return
    this.timer = new _timer__WEBPACK_IMPORTED_MODULE_1__["default"](() => this.delete(), this.duration)
    for (const e of ["mouseenter", "mouseleave"]) {
      this.addEvent(e, () => {
        if (this.isDeleted()) return
        this.toggleClass(_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.klass.progressBarPause)
        this.timer.toggle()
      })
    }
  }

  isDeleted(el = this.el) {
    return el.classList.contains(_constants__WEBPACK_IMPORTED_MODULE_2__.eConsts.klass.hiding)
  }
  get progressBar() {
    if (this.duration <= 0 || this.type === 'async') return ""
    return `<div class='${_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.klass.progressBar}' style="animation-duration:${this.options.toSecs(this.duration)};"></div>`
  }
  get label() {
    return `<b class="${_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.klass.label}">${this.options.label(this.type)}</b>`
  }

});


/***/ }),

/***/ "./src/api/api-index.js":
/*!******************************!*\
  !*** ./src/api/api-index.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ bindSiteApi)
/* harmony export */ });
/* harmony import */ var _trainings_trainings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./trainings/trainings */ "./src/api/trainings/trainings.js");
/* harmony import */ var _module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./module */ "./src/api/module.js");
/* harmony import */ var _payments__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./payments */ "./src/api/payments.js");
/* harmony import */ var _survey__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./survey */ "./src/api/survey.js");
/* harmony import */ var _common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./common */ "./src/api/common.js");
/* harmony import */ var _quiz__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./quiz */ "./src/api/quiz.js");
/* harmony import */ var _users__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./users */ "./src/api/users.js");
/* harmony import */ var _stream_stream__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./stream/stream */ "./src/api/stream/stream.js");
/* harmony import */ var _cpe_cpe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./cpe/cpe */ "./src/api/cpe/cpe.js");
/* harmony import */ var _storage_generic__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./storage/generic */ "./src/api/storage/generic.js");
/* harmony import */ var _storage_templates__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./storage/templates */ "./src/api/storage/templates.js");
/* harmony import */ var _storage_assessmentConfig__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./storage/assessmentConfig */ "./src/api/storage/assessmentConfig.js");
/* harmony import */ var _storage_paymentStats__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./storage/paymentStats */ "./src/api/storage/paymentStats.js");
/* harmony import */ var _storage_modulesData_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./storage/modulesData.js */ "./src/api/storage/modulesData.js");
/* harmony import */ var _judge_alphaJudge_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./judge/alphaJudge.js */ "./src/api/judge/alphaJudge.js");
/* harmony import */ var _util_contentTypes_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../util/contentTypes.js */ "./src/util/contentTypes.js");
















function bindSiteApi(appName) {
  const env = {
    interopHost,
    interopAppId,
    params,
    post,
    get,
    interopPlatformHost,
    interopAdminAlphaJudgeHost
  };
  const actions = { ...(0,_trainings_trainings__WEBPACK_IMPORTED_MODULE_0__["default"])(env),
    ...(0,_module__WEBPACK_IMPORTED_MODULE_1__["default"])(env),
    ...(0,_payments__WEBPACK_IMPORTED_MODULE_2__["default"])(env),
    ...(0,_survey__WEBPACK_IMPORTED_MODULE_3__["default"])(env),
    ...(0,_common__WEBPACK_IMPORTED_MODULE_4__["default"])(env),
    ...(0,_quiz__WEBPACK_IMPORTED_MODULE_5__["default"])(env),
    ...(0,_users__WEBPACK_IMPORTED_MODULE_6__["default"])(env),
    ...(0,_stream_stream__WEBPACK_IMPORTED_MODULE_7__["default"])(env),
    ...(0,_cpe_cpe__WEBPACK_IMPORTED_MODULE_8__["default"])(env),
    ...(0,_storage_generic__WEBPACK_IMPORTED_MODULE_9__["default"])(env),
    ...(0,_storage_templates__WEBPACK_IMPORTED_MODULE_10__["default"])(env),
    ...(0,_storage_assessmentConfig__WEBPACK_IMPORTED_MODULE_11__["default"])(env),
    ...(0,_storage_paymentStats__WEBPACK_IMPORTED_MODULE_12__["default"])(env),
    ...(0,_storage_modulesData_js__WEBPACK_IMPORTED_MODULE_13__["default"])(env),
    ...(0,_judge_alphaJudge_js__WEBPACK_IMPORTED_MODULE_14__["default"])(env)
  };

  if (appName === null) {
    return Object.keys(actions);
  } else {
    return actions;
  }

  function interopHost(endpoint) {
    switch (appName) {
      case 'digital':
        return 'https://digital.softuni.bg/' + endpoint;

      case 'creative':
        return 'https://creative.softuni.bg/' + endpoint;

      case 'ai':
        return 'https://ai.softuni.bg/' + endpoint;

      case 'financeacademy':
        return 'https://financeacademy.bg/' + endpoint;

      case 'devdigital':
        return 'https://dev.digital.softuni.bg/' + endpoint;

      case 'devsoftuni':
        return 'https://dev.softuni.bg/' + endpoint;

      default:
        return 'https://softuni.bg/' + endpoint;
    }
  }

  function interopAppId() {
    switch (appName) {
      case 'digital':
        return 'digital.softuni.bg';

      case 'creative':
        return 'creative.softuni.bg';

      case 'ai':
        return 'ai.softuni.bg';

      case 'financeacademy':
        return 'financeacademy.bg';

      case 'devdigital':
        return 'digital.softuni.bg';

      case 'devsoftuni':
        return 'softuni.bg';

      default:
        return 'softuni.bg';
    }
  }

  function interopPlatformHost() {
    switch (appName) {
      case 'digital':
        return 'https://platform.softuni.bg';

      case 'creative':
        return 'https://platform.softuni.bg';

      case 'ai':
        return 'https://platform.softuni.bg';

      case 'financeacademy':
        return 'https://platform.financeacademy.bg';

      case 'devdigital':
        return 'https://dev.platform.softuni.bg';

      case 'devsoftuni':
        return 'https://dev.platform.softuni.bg';

      default:
        return 'https://platform.softuni.bg';
    }
  }

  function interopAdminAlphaJudgeHost() {
    switch (appName) {
      case 'devsoftuni':
        return "https://admin.dev.alpha.judge.softuni.org";

      default:
        return "https://admin.alpha.judge.softuni.org";
    }
  }
}
let hosts = ['https://digital.softuni.bg/', 'https://creative.softuni.bg/', 'https://ai.softuni.bg/', 'https://financeacademy.bg/', 'https://dev.digital.softuni.bg/', 'https://dev.softuni.bg/', 'https://softuni.bg/'];
let platformHosts = ['https://platform.financeacademy.bg', 'https://dev.platform.softuni.bg', 'https://platform.softuni.bg'];
let judgeHosts = ["https://admin.alpha.judge.softuni.org", "https://dev.admin.alpha.judge.softuni.org", "https://alpha.judge.softuni.org", "https://dev.alpha.judge.softuni.org"];

function params(params = {}) {
  return Object.assign({
    sort: '',
    page: 1,
    pageSize: 10,
    group: '',
    filter: ''
  }, params);
}

async function post(url, params, contentType = _util_contentTypes_js__WEBPACK_IMPORTED_MODULE_15__.ContentType.UrlFormEncoded, asBlob = false) {
  let body = new URLSearchParams();

  if (contentType === _util_contentTypes_js__WEBPACK_IMPORTED_MODULE_15__.ContentType.ApplicationJson) {
    body = JSON.stringify(params);
  } else {
    for (let key of Object.keys(params)) {
      body.append(key, params[key]);
    }
  }

  const req = {
    method: 'POST',
    headers: {
      'Content-Type': contentType
    },
    body
  };

  try {
    const response = await fetch(url, req);

    if (response.status !== 200) {
      console.warn('Unsuccessful request');
      console.warn(params);
      console.warn(response);
      let error = new Error(`${response.status}: ${response.statusText} at ${response.url}`);
      error._status = response.status;
      throw error;
    }

    if (response.redirected || response.status == 302) {
      let urlDomain = hosts.find(x => url.startsWith(x));
      let platformDomain = platformHosts.find(x => url.startsWith(x));
      let judgeDomain = judgeHosts.find(x => url.startsWith(x));

      if (!urlDomain) {
        urlDomain = platformDomain;
      }

      if (!urlDomain) {
        urlDomain = judgeDomain;
      }

      console.error(`Request error fetching from ${url}, you're probably not logged in '${urlDomain}'.`);
      const error = new Error(`Request error, you're probably not logged in <a href="${urlDomain}" target="_blank">${urlDomain}</a>. Please login to <a href="${urlDomain}" target="_blank">${urlDomain}</a> and try again.`);
      error._url = url;
      throw error;
    }

    if (asBlob) {
      let filename = response.headers.get('Content-Disposition').split('filename=')[1].split(';')[0].replaceAll('\"', '');
      let blob = await response.blob();
      blob.filename = filename;
      return blob;
    }

    try {
      let result = await response.json();

      if (result.Errors) {
        let errorsParsed = JSON.stringify(result.Errors, undefined, 2);
        throw new Error(errorsParsed);
      }

      return result;
    } catch (e) {
      if (e instanceof SyntaxError) {
        return response;
      } else {
        throw e;
      }
    }
  } catch (e) {
    console.error(e);
    throw e;
  }
}

async function get(url, asBlob) {
  const req = {
    method: 'GET'
  };

  try {
    let response = await fetch(url, req);

    if (response.status !== 200) {
      console.warn('Unsuccessful request');
      console.warn(params);
      console.warn(response);
      throw new Error(`${response.statusText} at ${response.url}`);
    }

    if (response.redirected) {
      if (url.includes('platform')) {
        let platformDomain = platformHosts.find(x => url.startsWith(x));
        console.error(`Request error fetching from ${url}, you're probably not logged in to the platform.`);
        const error = new Error(`Request error, you're probably not logged in <a href="${platformDomain}" target="_blank">${platformDomain}</a>. Please login to <a href="${platformDomain}" target="_blank">${platformDomain}</a> and try again.`);
        error._url = url;
        throw error;
      } else {
        response = await fetch(response.url, req);
      }
    }

    if (asBlob) {
      return response.blob();
    }

    const reader = response.body.getReader();
    const utf8Decoder = new TextDecoder('utf-8');
    let result = '';

    while (true) {
      const {
        done,
        value
      } = await reader.read();

      if (done) {
        break;
      }

      result += utf8Decoder.decode(value);
    }

    try {
      return JSON.parse(result);
    } catch (e) {
      return result;
    }
  } catch (e) {
    console.error(e);
    throw e;
  }
}

/***/ }),

/***/ "./src/api/common.js":
/*!***************************!*\
  !*** ./src/api/common.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getBlogByUrl(blogUrl) {
    const uri = interopHost('administration_cms/news/read');
    const body = params({
      filter: `Url~eq~'${blogUrl}'`
    });
    return (await post(uri, body)).Data[0];
  }

  async function getHalls() {
    const dir = interopAppId() == 'softuni.bg' ? 'administration_university' : 'Administration';
    const uri = interopHost(dir + '/traininglabs/read');
    const body = params({
      pageSize: 1000
    });
    return post(uri, body);
  }

  async function getSoftwareUniversityHalls() {
    const uri = 'https://softuni.bg/administration_university/traininglabs/read';
    const body = params({
      pageSize: 1000
    });
    return post(uri, body);
  }

  function getHallBody(hall) {
    let currentDate = new Date(); // simplest way to convert date to ISO format in local Timezone as SULS requires

    currentDate.setMinutes(currentDate.getMinutes() - currentDate.getTimezoneOffset());
    let modifiedOnDate = currentDate.toISOString().slice(0, -1);
    const body = {
      sort: '',
      group: '',
      filter: '',
      Id: hall.Id,
      NameBg: hall.NameBg,
      NameEn: hall.NameEn,
      Address: hall.Address,
      Capacity: hall.Capacity,
      Description: hall.Description,
      DisableSecureLink: hall.DisableSecureLink,
      Floor: hall.Floor,
      GoogleCalendarId: hall.GoogleCalendarId,
      IsActive: hall.IsActive,
      IsFeatured: hall.IsFeatured,
      IsPhysical: hall.IsPhysical,
      ShowOnSchedule: hall.ShowOnSchedule,
      BranchId: hall.BranchId,
      SeatsConfiguration: hall.SeatsConfiguration,
      StreamingType: hall.StreamingType,
      YouTubeCode: hall.YouTubeCode,
      SoftUniStreamCode: hall.SoftUniStreamCode,
      StreamingServerBaseId: hall.StreamingServerBaseId,
      UcdnStreamingCode: hall.UcdnStreamingCode,
      CreatedOn: hall.CreatedOn,
      ModifiedOn: hall.ModifiedOn || modifiedOnDate
    };
    return body;
  }

  async function updateHall(hall) {
    let uri;

    if (interopAppId() === 'softuni.bg') {
      uri = interopHost('administration_university/traininglabs/update');
    } else {
      uri = interopHost('Administration/TrainingLabs/Update');
    }

    const body = getHallBody(hall);

    if (interopAppId() !== 'softuni.bg') {
      delete body.BranchId;
      delete body.SeatsConfiguration;
    }

    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function updateSoftwareUniversityHall(hall) {
    let uri = 'https://softuni.bg/administration_university/traininglabs/update';
    const body = getHallBody(hall);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  return {
    getBlogByUrl,
    getHalls,
    updateHall,
    getSoftwareUniversityHalls,
    updateSoftwareUniversityHall
  };
}

/***/ }),

/***/ "./src/api/cpe/cpe.js":
/*!****************************!*\
  !*** ./src/api/cpe/cpe.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _navet__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./navet */ "./src/api/cpe/navet.js");

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get,
  interopPlatformHost
}) {
  const navetApi = (0,_navet__WEBPACK_IMPORTED_MODULE_0__["default"])();

  async function getApplicationsByInstanceId(instanceId) {
    const uri = `${interopPlatformHost()}/administration/cpecertificateapplications/read?appId=${interopAppId()}`;
    const body = params({
      sort: 'CreatedOn-desc-asc',
      pageSize: 1000,
      filter: `TrainingId~eq~${instanceId}`
    });
    return (await post(uri, body)).Data;
  }

  async function getApplications(query, page) {
    const uri = `${interopPlatformHost()}/administration/cpecertificateapplications/read?appId=${interopAppId()}`;
    const filterTokens = [];

    if (query.instanceId) {
      filterTokens.push(`(TrainingId~eq~${query.instanceId})`);
    }

    if (query.instanceName) {
      filterTokens.push(`(TrainingName~contains~'${tokenize(query.instanceName).join('\'~and~TrainingName~contains~\'')}')`);
    }

    if (query.names) {
      const nameTokens = tokenize(query.names);
      let nameFilter = '';

      if (nameTokens.length == 1) {
        nameFilter = `(FirstName~contains~'${nameTokens[0]}'~or~MiddleName~contains~'${nameTokens[0]}'~or~LastName~contains~'${nameTokens[0]}')`;
      } else if (nameTokens.length == 2) {
        nameFilter = `(FirstName~contains~'${nameTokens[0]}'~and~(MiddleName~contains~'${nameTokens[1]}'~or~LastName~contains~'${nameTokens[1]}'))`;
      } else if (nameTokens.length == 3) {
        nameFilter = `(FirstName~contains~'${nameTokens[0]}'~and~MiddleName~contains~'${nameTokens[1]}'~and~LastName~contains~'${nameTokens[2]}')`;
      }

      filterTokens.push(nameFilter);
    }

    if (query.SSN) {
      filterTokens.push(`SSN~contains~'${query.SSN}'`);
    }

    const body = params({
      sort: 'CreatedOn-desc',
      pageSize: page ? 25 : 2000,
      page: page ? page : 1,
      filter: filterTokens.join('~and~')
    });
    return post(uri, body);
  }

  async function getAppZip(id) {
    const res = await fetch(`${interopPlatformHost()}/administration/cpecertificateapplications/getfileszip?id=${id}`);
    const blob = await res.blob();
    const serializedBlob = new Uint8Array(await blob.arrayBuffer());
    const blobData = {
      type: blob.type,
      buffer: Array.from(serializedBlob)
    };
    return blobData;
  } // ### External storage of application data (uses lectures inside a fixed course instance)


  const storeId = {
    'softuni.bg': 3124,
    'digital.softuni.bg': 2336,
    'creative.softuni.bg': 1193,
    'ai.softuni.bg': 8,
    'financeacademy.bg': 228
  };
  const statusModel = {
    sort: '',
    group: '',
    filter: '',
    Id: '',
    TrainingId: '',
    NameBg: '',
    NameEn: '',
    HasManualNumberOfStudyHours: '',
    NumberOfStudyHours: '',
    IsExcludedFromCertificate: '',
    HasHomework: '',
    ResourceMailsState: '',
    HomeworkMailsState: '',
    JudgeContestId: '',
    OrderBy: '',
    DescriptionBg: '',
    DescriptionEn: '',
    ExcludeFromCalendar: '',
    HasLiveStream: '',
    CreatedOn: '',
    ModifiedOn: ''
  };

  async function getAppStatus(id) {
    const uri = interopHost(`administration_trainings/lectures/read?foreignKeyId=${storeId[interopAppId()]}`);
    let filter = '';

    if (Array.isArray(id)) {
      filter = `NameEn~eq~'${id.join('\'~or~NameEn~eq~\'')}'`;
    } else {
      filter = `NameEn~eq~'${id}'`;
    }

    const body = params({
      pageSize: 1000,
      filter
    });
    return (await post(uri, body)).Data;
  }

  async function getAppStatusByInstanceId(id) {
    const uri = interopHost(`administration_trainings/lectures/read?foreignKeyId=${storeId[interopAppId()]}`);
    const body = params({
      pageSize: 1000,
      filter: `NameBg~eq~'${id}'`
    });
    return (await post(uri, body)).Data;
  }

  async function createStatus(status) {
    const uri = interopHost(`administration_trainings/lectures/create?foreignKeyId=${storeId[interopAppId()]}`);
    const body = Object.assign(params({}), statusModel);

    for (let field in body) {
      body[field] = status[field] === undefined ? body[field] : status[field];
    }

    body.TrainingId = storeId[interopAppId()];
    let startDate = new Date();
    let endDate = new Date(startDate);
    endDate.setUTCDate(endDate.getUTCDate() + 1);
    body[`DatesInfo[0].Start`] = startDate.toISOString();
    body[`DatesInfo[0].End`] = endDate.toISOString();
    body[`DatesInfo[0].ExtraInformation`] = '';
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return (await post(uri, body)).Data;
  }

  async function updateStatus(status) {
    const uri = interopHost(`administration_trainings/lectures/update?foreignKeyId=${storeId[interopAppId()]}`);
    const body = Object.assign(params({}), statusModel);

    for (let field in body) {
      body[field] = status[field] === undefined ? body[field] : status[field];
    }

    body.TrainingId = storeId[interopAppId()];
    let startDate = new Date();
    let endDate = new Date(startDate);
    endDate.setUTCDate(endDate.getUTCDate() + 1);
    body[`DatesInfo[0].Start`] = startDate.toISOString();
    body[`DatesInfo[0].End`] = endDate.toISOString();
    body[`DatesInfo[0].ExtraInformation`] = '';
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return (await post(uri, body)).Data;
  }

  async function destroyStatus(status) {
    const uri = interopHost(`administration_trainings/lectures/destroy?foreignKeyId=${storeId[interopAppId()]}`);
    const body = params({
      sort: '',
      group: '',
      filter: ''
    });
    Object.assign(body, status);
    body.TrainingId = storeId[interopAppId()];
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  return { ...navetApi,
    getApplicationsByInstanceId,
    getApplications,
    getAppZip,
    getAppStatus,
    getAppStatusByInstanceId,
    createStatus,
    updateStatus,
    destroyStatus
  };
}

function tokenize(asString) {
  return asString.split(' ').map(t => t.trim()).filter(t => t.length > 0);
}

/***/ }),

/***/ "./src/api/cpe/navet.js":
/*!******************************!*\
  !*** ./src/api/cpe/navet.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_json5_dist_index_min__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/json5/dist/index.min */ "./node_modules/json5/dist/index.min.js");
/* harmony import */ var _node_modules_json5_dist_index_min__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_json5_dist_index_min__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__() {
  const host = 'https://is.navet.government.bg/furia/Projects/napoo/index.new.php';

  async function get(url) {
    const res = await fetch(url);
    const text = await res.text();
    return text;
  }

  async function postForm(url, body) {
    Object.assign(body, {
      application: 'AJAXDataProvider',
      noCache: Date.now()
    });
    const query = [];

    for (let param in body) {
      query.push(`${param}=${encodeURIComponent(body[param])}`);
    }

    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-type': 'application/x-www-form-urlencoded; charset=utf-8'
      },
      body: query.join('&')
    });
    return res.text();
  }

  function parseResponse(data) {
    let json;
    json = _node_modules_json5_dist_index_min__WEBPACK_IMPORTED_MODULE_0___default().parse(data);

    if (json.hasOwnProperty('obj')) {
      return parseObject(json.obj);
    } else if (json.hasOwnProperty('objs')) {
      return json.objs.map(parseObject);
    } else if (json.hasOwnProperty('data') || json.status != 0) {
      return json;
    } else {
      console.error(json);

      if (json.status == 0) {
        console.error('Your session has expired. Please enter your credentials again.');
        throw new Error('Your session has expired. Please enter your credentials again.');
      } else {
        throw new TypeError('Unable to parse data: no keys [obj] or [objs] found. See console for details.');
      }
    }

    function parseObject(obj) {
      const parsed = {};

      for (let prop in obj) {
        parsed[prop] = obj[prop].value;
      }

      return parsed;
    }
  }

  async function getExtraCourseInfo(id) {
    const body = {
      invoke: `TbCourseGroupsManager.getByCourseGroupId(${id})`
    };
    return parseResponse(await postForm(host, body));
  }

  async function getNavetCurrentCourses() {
    const body = {
      invoke: 'ViewCourseGroupListManager.customGetByProviderIdAndCourseStatusId(2929,2)'
    };
    return parseResponse(await postForm(host, body));
  }

  async function getNavetClosedCourses() {
    const body = {
      invoke: 'ViewFinishedCourseGroupListManager.customGetByProviderIdAndCourseStatusIdNotArchived(2929)'
    };
    return parseResponse(await postForm(host, body));
  }

  async function getNavetArchivedCourses() {
    const body = {
      invoke: 'ViewFinishedCourseGroupListManager.customGetByProviderIdAndCourseStatusIdArchived(2929)'
    };
    return parseResponse(await postForm(host, body));
  }

  async function getNavetCourseInfo(id, type = 'current') {
    let extraInfo = getExtraCourseInfo(id);
    let courseList = [];

    switch (type) {
      case 'current':
        courseList = getNavetCurrentCourses();
        break;

      case 'concluded':
        courseList = getNavetClosedCourses();
        break;

      case 'archive':
        courseList = getNavetArchivedCourses();
        break;
    }

    [extraInfo, courseList] = await Promise.all([extraInfo, courseList]);
    const selected = courseList.find(c => c.id == id);
    selected._extra = extraInfo[0];
    return selected;
  }
  /* Replaced, because it doesn't provide the necessary information */

  /*
  async function getNavetCourseInfo(id) {
      const body = {
          invoke: `ViewCourseInfoManager.getById(${id})`
      };
      return parseResponse(await postForm(host, body));
  }
  */


  async function getNavetStudents(id) {
    const body = {
      invoke: `ViewClientCoursesManager.getByCourseGroupId(${id})`
    };
    return parseResponse(await postForm(host, body));
  }

  async function getNavetStudentInfo(clientId) {
    const body = {
      invoke: `TbClientsManager.getById(${clientId})`,
      id: clientId
    };
    return parseResponse(await postForm(host, body));
  }

  async function getNavetExistingFiles(courseId, id) {
    const body = {
      invoke: `TbClientsRequiredDocumentsManager.customGetValidByCourseGroupAndClient(${courseId},${id})`
    };
    return parseResponse(await postForm(host, body));
  }

  async function uploadFile(formData) {
    const result = await fetch(host, {
      method: 'POST',
      body: formData
    });
    const output = await result.text();

    if (output.search(/status:\s0/) != -1) {
      throw new Error('Your session has expired. Please enter your credentials again.');
    } else {
      return output;
    }
  }

  async function uploadMedical(courseId, id, fileDescriptor) {
    let blob;
    let filename;

    if (fileDescriptor.fileUrl !== undefined) {
      blob = await (await fetch(fileDescriptor.fileUrl)).blob();
      filename = fileDescriptor.name;
    } else {
      blob = fileDescriptor.file;
      filename = fileDescriptor.file.name;
    }

    const formData = new FormData();
    formData.append('id', null);
    formData.append('int_course_group_id', courseId);
    formData.append('is_valid', true);
    formData.append('oid_file_action', 'upload');
    formData.append('oid_file', blob, filename);
    formData.append('invoke', 'TbClientsRequiredDocumentsManager.createObject()');
    formData.append('application', 'AJAXDataProvider');
    formData.append('protocol', 'dataIFrame');
    formData.append('null', '');
    formData.append('int_code_course_group_required_documents_type_id', 1);
    formData.append('int_client_id', id);
    formData.append('vc_desciption', 'медицинско (auto)');
    formData.append('dt_document_date', '');
    formData.append('vc_document_reg_no', '');
    formData.append('vc_document_prn_no', '');
    formData.append('dt_document_official_date', '');
    formData.append('bool_before_date', false);
    formData.append('int_code_ext_register_id', null);
    formData.append('title', '<div class=\'napoo-title-dark\'>Медицинско свидетелство:</div>');
    formData.append('async_iframe_id', 'async_iframe_3152');
    return uploadFile(formData);
  }

  async function uploadDiploma(courseId, id, fileDescriptor, reg_no, prn_no, doc_date) {
    let blob;
    let filename;

    if (fileDescriptor.fileUrl !== undefined) {
      blob = await (await fetch(fileDescriptor.fileUrl)).blob();
      filename = fileDescriptor.name;
    } else {
      blob = fileDescriptor.file;
      filename = fileDescriptor.file.name;
    }

    const formData = new FormData();
    formData.append('id', null);
    formData.append('int_course_group_id', courseId);
    formData.append('is_valid', true);
    formData.append('int_code_education_id', 31);
    formData.append('341-text', 'завършено средно образование (или по-високо)');
    formData.append('vc_document_reg_no', reg_no);
    formData.append('vc_document_prn_no', prn_no);
    formData.append('oid_file_action', 'upload');
    formData.append('oid_file', blob, filename);
    formData.append('invoke', 'TbClientsRequiredDocumentsManager.createObject()');
    formData.append('application', 'AJAXDataProvider');
    formData.append('protocol', 'dataIFrame');
    formData.append('null', '');
    formData.append('int_client_id', id);
    formData.append('vc_desciption', 'диплома (auto)');
    formData.append('dt_document_date', '');
    formData.append('dt_document_official_date', doc_date);
    formData.append('bool_before_date', false);
    formData.append('int_code_ext_register_id', null);
    formData.append('title', '<div class=\'napoo-title-dark\'>Входящо минимално образователно равнище:</div>');
    formData.append('respInfo', '');
    formData.append('extraInfo', '');
    formData.append('check-in-edu-button', 'Провери в регистрите');
    formData.append('async_iframe_id', 'async_iframe_374');
    return uploadFile(formData);
  }

  async function openNavetFile(id) {
    const url = `${host}?application=AJAXDataProvider&invoke=TbClientsRequiredDocumentsManager.customDownloadFile(${id},"oid_file")`;
    const res = await fetch(url);
    const blob = await res.blob();
    const serializedBlob = new Uint8Array(await blob.arrayBuffer());
    let blobData = {
      type: blob.type,
      buffer: Array.from(serializedBlob)
    };
    return blobData;
  }

  async function deleteNavetFile(id) {
    const body = {
      invoke: `TbClientsRequiredDocumentsManager.customSetToFalse(${id})`
    };
    return parseResponse(await postForm(host, body));
  }
  /* Experimental */


  async function navetLogin(username, password) {
    const body = {
      response: 'client',
      request: 'login',
      username,
      password
    };
    const header = encodeURIComponent(JSON.stringify(body));
    const url = '/response';
    let request = new XMLHttpRequest();

    request.onreadystatechange = () => {
      if (request.readyState == 4 && (request.status == 200 || window.location.href.indexOf('http') == -1)) {
        let udat = JSON.parse(request.responseText);

        if (udat.status == 1) {
          window.location.href = '/';
        } else {
          throw new Error('Error: ' + udat.error_code);
        }

        request = null;
      }
    };

    const cache = '?' + new Date().getTime();
    request.open('GET', url + cache, true);
    request.setRequestHeader('ACCSSCTRL', header);
    request.send(null);
  }

  async function getGraduateInfo(id) {
    const body = {
      invoke: `RefClientsCoursesManager.getById(${id})`
    };
    return parseResponse(await postForm(host, body));
  }

  async function getNavetCertificate(id) {
    const body = {
      invoke: `ViewClientsCoursesDocumentsManager.getByClientCoursesId(${id})`
    };
    return parseResponse(await postForm(host, body));
  }

  async function openNavetCertificate(id, page) {
    const url = `${host}?application=AJAXDataProvider&invoke=TbClientsCoursesDocumentsManager.customDownloadFile(${id}, "document_${page}_file")`;
    const res = await fetch(url);
    const blob = await res.blob();

    if (blob.type == 'text/javascript') {
      console.error('Your session has expired. Please enter your credentials again.');
      throw new Error('Your session has expired. Please enter your credentials again.');
    }

    const serializedBlob = new Uint8Array(await blob.arrayBuffer());
    let blobData = {
      type: blob.type,
      buffer: Array.from(serializedBlob)
    };
    return blobData;
  }

  async function uploadNavetCertificate(meta, fileDescriptors) {
    const files = await Promise.all(fileDescriptors.map(async descriptor => {
      if (descriptor === null) {
        return null;
      } else if (descriptor.fileUrl !== undefined) {
        return {
          blob: await (await fetch(descriptor.fileUrl)).blob(),
          filename: descriptor.name
        };
      } else {
        return {
          blob: descriptor.file,
          filename: descriptor.file.name
        };
      }
    }));
    const formData = new FormData();
    formData.append('id', meta.id);
    formData.append('int_clients_courses_id', meta.int_clients_courses_id);
    formData.append('int_document_type_id', meta.int_document_type_id);
    formData.append('608-text', 'Удостоверение за професионално обучение');
    formData.append('int_course_finished_year', meta.int_course_finished_year); // need this added

    formData.append('vc_document_prn_no', '');
    formData.append('612-text', '');
    formData.append('vc_original_prn_no', meta.vc_document_prn_no);
    formData.append('vc_document_reg_no', meta.vc_document_reg_no); // need this added

    formData.append('vc_document_prot', meta.vc_document_prot);
    formData.append('num_theory_result', meta.num_theory_result);
    formData.append('num_practice_result', meta.num_practice_result);
    formData.append('vc_qualification_name', meta.vc_qualification_name);
    formData.append('vc_qualificatioj_level', meta.vc_qualificatioj_level);

    if (files[0] !== null) {
      formData.append('document_1_file_action', 'upload');
      formData.append('document_1_file', files[0].blob, files[0].filename);
    } else {
      formData.append('document_1_file_action', '');
      formData.append('document_1_file', new Blob(['']), '');
    }

    if (files[1] !== null) {
      formData.append('document_2_file_action', 'upload');
      formData.append('document_2_file', files[1].blob, files[1].filename);
    } else {
      formData.append('document_2_file_action', '');
      formData.append('document_2_file', new Blob(['']), '');
    }

    formData.append('invoke', `TbClientsCoursesDocumentsManager.updateObject(${meta.id})`);
    formData.append('application', 'AJAXDataProvider');
    formData.append('protocol', 'dataIFrame');
    formData.append('dt_document_date', meta.dt_document_date);
    formData.append('vc_document_type_name', meta.vc_document_type_name);
    formData.append('int_document_status', meta.int_document_status);
    formData.append('bool_with_note', meta.bool_with_note);
    formData.append('async_iframe_id', 'async_iframe_639');
    return uploadFile(formData);
  }

  async function updateNavetStudent(id, student) {
    const body = Object.assign({}, student, {
      invoke: `RefClientsCoursesManager.updateObject(${id})`
    });
    return parseResponse(await postForm(host, body));
  }

  async function createDocument(studentId, clientId, data) {
    const formData = new FormData();
    formData.append('id', null);
    formData.append('int_clients_courses_id', null);
    formData.append('int_document_type_id', '');
    formData.append('304-text', 'Удостоверение за професионално обучение');
    formData.append('int_course_finished_year', data.int_course_finished_year); // need this added

    formData.append('vc_document_prn_no', '');
    formData.append('308-text', '');
    formData.append('vc_document_reg_no', data.vc_document_reg_no); // need this added

    formData.append('vc_document_prot', '');
    formData.append('num_theory_result', 0);
    formData.append('num_practice_result', 0);
    formData.append('vc_qualification_name', '');
    formData.append('vc_qualificatioj_level', '');
    formData.append('document_1_file_action', '');
    formData.append('document_1_file', new Blob(['']), '');
    formData.append('document_2_file_action', '');
    formData.append('document_2_file', new Blob(['']), '');
    formData.append('invoke', 'CustomEventsManager.customTbClientsCoursesDocuments(1)');
    formData.append('application', 'AJAXDataProvider');
    formData.append('protocol', 'dataIFrame');
    formData.append('int_provider_id', 2929);
    formData.append('ref_clients_courses_id_t', studentId); //data.id

    formData.append('tb_clients_id_t', clientId); //data.int_client_id

    formData.append('dt_document_date_t', '');
    formData.append('int_client_course_id_t', studentId); //data.id

    formData.append('int_document_type_id_t', 2);
    formData.append('vc_document_prn_no_t', '');
    formData.append('vc_document_reg_no_t', data.vc_document_reg_no); // need this added, same as above

    formData.append('int_document_status', 0);
    formData.append('async_iframe_id', 'async_iframe_329');
    return uploadFile(formData);
  }

  return {
    getNavetCurrentCourses,
    getNavetClosedCourses,
    getNavetArchivedCourses,
    getNavetCourseInfo,
    getNavetStudents,
    getNavetStudentInfo,
    getNavetExistingFiles,
    uploadMedical,
    uploadDiploma,
    openNavetFile,
    deleteNavetFile,
    getGraduateInfo,
    getNavetCertificate,
    openNavetCertificate,
    uploadNavetCertificate,
    updateNavetStudent,
    createDocument,
    getExtraCourseInfo
  };
}

/***/ }),

/***/ "./src/api/judge/alphaJudge.js":
/*!*************************************!*\
  !*** ./src/api/judge/alphaJudge.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _util_contentTypes_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../util/contentTypes.js */ "./src/util/contentTypes.js");

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get,
  interopPlatformHost,
  interopAdminAlphaJudgeHost
}) {
  async function getContestCompeteResults(contestId) {
    const uri = `${interopAdminAlphaJudgeHost()}/api/contests/ExportResults`;
    const body = {
      id: contestId,
      type: 0
    };
    let blob = await post(uri, body, _util_contentTypes_js__WEBPACK_IMPORTED_MODULE_0__.ContentType.ApplicationJson, true);
    const serializedBlob = new Uint8Array(await blob.arrayBuffer());
    const blobData = {
      type: blob.type,
      filename: blob.filename,
      buffer: Array.from(serializedBlob)
    };
    return blobData;
  }

  async function getContestPracticeResults(contestId) {
    const uri = `${interopAdminAlphaJudgeHost()}/api/contests/ExportResults`;
    const body = {
      id: contestId,
      type: 1
    };
    let blob = await post(uri, body, _util_contentTypes_js__WEBPACK_IMPORTED_MODULE_0__.ContentType.ApplicationJson, true);
    const serializedBlob = new Uint8Array(await blob.arrayBuffer());
    const blobData = {
      type: blob.type,
      filename: blob.filename,
      buffer: Array.from(serializedBlob)
    };
    return blobData;
  }

  return {
    getContestCompeteResults,
    getContestPracticeResults
  };
}

/***/ }),

/***/ "./src/api/module.js":
/*!***************************!*\
  !*** ./src/api/module.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post
}) {
  async function getModulesInProfession(professionId) {
    const url = (() => {
      if (interopAppId() === 'softuni.bg') {
        return interopHost(`administration_professions/levelgroupsinprofessioninstances/read?foreignKeyId=${professionId}`);
      } else {
        return interopHost(`Administration_Professions/CourseGroupsInProfessionInstances/Read?foreignKeyId=${professionId}`);
      }
    })();

    const body = params({
      pageSize: 100
    });
    return post(url, body);
  }

  async function getModules() {
    const url = interopHost('administration_Levels/levels/read');
    const body = params({
      pageSize: 1000
    });
    return (await post(url, body)).Data;
  }

  async function getInstancesInModule(moduleId) {
    const url = (() => {
      if (interopAppId() === 'softuni.bg') {
        return interopHost(`administration_levels/levelinstances/read?importLevelId=${moduleId}&levelId=${moduleId}`);
      } else {
        return interopHost(`Administration_Levels/LevelInstances/Read?importLevelId=${moduleId}&levelId=${moduleId}&foreignKeyId=${moduleId}`);
      }
    })();

    const body = params({
      pageSize: 1000
    });
    return post(url, body);
  }

  async function getInstanceInModule(moduleId, moduleInstanceId) {
    const url = (() => {
      if (interopAppId() === 'softuni.bg') {
        return interopHost(`administration_levels/levelinstances/read?importLevelId=${moduleId}&levelId=${moduleId}`);
      } else {
        return interopHost(`Administration_Levels/LevelInstances/Read?importLevelId=${moduleId}&levelId=${moduleId}&foreignKeyId=${moduleId}`);
      }
    })();

    let filter = `Id~eq~${moduleInstanceId}`;

    if (Array.isArray(moduleInstanceId)) {
      filter = `Id~eq~${moduleInstanceId.join('~or~Id~eq~')}`;
    }

    const body = params({
      pageSize: 100,
      filter: filter
    });
    return post(url, body);
  }

  async function searchModules(query) {
    const url = interopHost('administration_levels/levels/read');
    const filter = `NameBg~contains~'${query.split(' ').filter(s => s.length > 0).join('\'~and~NameBg~contains~\'')}'`;
    const body = params({
      pageSize: 100,
      filter,
      sort: 'CreatedOn-desc'
    });
    return (await post(url, body)).Data;
  }

  return {
    getModulesInProfession,
    getModules,
    getInstancesInModule,
    searchModules,
    getInstanceInModule
  };
}

/***/ }),

/***/ "./src/api/payments.js":
/*!*****************************!*\
  !*** ./src/api/payments.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get,
  interopPlatformHost
}) {
  async function getPaymentsForPackage(packageName) {
    // This field does not work with multiple values

    /*
    const filter = (() => {
        if (Array.isArray(packageId)) {
            return `PaymentPackagesAsString~eq~'${packageId.join('\'~or~PaymentPackagesAsString~eq~\'')}'`;
            //return `PaymentStatus~eq~4~and~(PaymentPackagesAsString~eq~'${packageId.join('\'~or~PaymentPackagesAsString~eq~\'')}')`;
        } else {
            return `PaymentPackagesAsString~eq~'${packageId}'`;
            //return `PaymentStatus~eq~4~and~PaymentPackagesAsString~eq~${packageId}`;
        }
    })();
    */
    const url = `${interopPlatformHost()}/administration/payments/read?appId=${interopAppId()}`;
    const body = params({
      pageSize: 10000,
      filter: `PaymentStatus~eq~4~and~PaymentPackagesAsString~eq~'${packageName}'`
    });
    return post(url, body);
  }

  async function getPackagesForProduct(productId) {
    if (Array.isArray(productId) && productId.length === 0) {
      return {
        Data: []
      };
    }

    const filter = (() => {
      if (Array.isArray(productId)) {
        return `Name~doesnotcontain~'II'~and~(Product.Id~eq~${productId.join('~or~Product.Id~eq~')})`;
      } else {
        return `Name~doesnotcontain~'II'~and~Product.Id~eq~${productId}`;
      }
    })();

    const url = `${interopPlatformHost()}/administration/paymentpackages/read?appId=${interopAppId()}`;
    const body = params({
      pageSize: 1000,
      filter
    });
    return post(url, body);
  }

  async function getProductsForModule(moduleId) {
    const filter = (() => {
      if (Array.isArray(moduleId)) {
        return `Name~doesnotcontain~'II'~and~(LevelInstanceId~eq~${moduleId.join('~or~LevelInstanceId~eq~')})`;
      } else {
        return `Name~doesnotcontain~'II'~and~LevelInstanceId~eq~${moduleId}`;
      }
    })();

    const url = `${interopPlatformHost()}/administration/levelinstanceproducts/read?appId=${interopAppId()}`;
    const body = params({
      pageSize: 1000,
      filter
    });
    return post(url, body);
  }

  async function getProductsForCourse(instanceId, type = 'open') {
    const epStrings = (() => {
      switch (type) {
        case 'open':
          return {
            path: 'fasttrackinstanceproducts',
            param: 'FastTrackInstanceId'
          };
      }
    })();

    const filter = (() => {
      if (Array.isArray(instanceId)) {
        return `(${epStrings.param}~eq~${instanceId.join(`~or~${epStrings.param}~eq~`)})`;
      } else {
        return `${epStrings.param}~eq~${instanceId}`;
      }
    })();

    const url = `${interopPlatformHost()}/administration/${epStrings.path}/read?appId=${interopAppId()}`;
    const body = params({
      pageSize: 1000,
      filter
    });
    return post(url, body);
  }

  return {
    getPaymentsForPackage,
    getPackagesForProduct,
    getProductsForModule,
    getProductsForCourse
  };
}

/***/ }),

/***/ "./src/api/quiz.js":
/*!*************************!*\
  !*** ./src/api/quiz.js ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function createQuizInstance(payload) {
    const uri = interopHost('administration_testsystem/tests/create');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: 0,
      Name: payload.name,
      Description: payload.description,
      QuestionsCount: 0
    });
    return await post(uri, body);
  }

  async function addQuestion(quizId, question) {
    const uri = interopHost(`administration_testsystem/testquestions/create?foreignKeyId=${quizId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: 0,
      Type: 1,
      Content: question,
      CorrectAnswerPoints: 1,
      WrongAnswerPoints: 0,
      KeepAnswersOrder: false,
      ShowCorrectAnswersCount: false,
      CorrectCount: 0,
      WrongCount: 0,
      AllCount: 0,
      PercentCorrect: 0
    });
    return await post(uri, body);
  }

  async function addAnswer(questionId, answer, isCorrect) {
    const uri = interopHost(`administration_testsystem/testquestionanswers/create?foreignKeyId=${questionId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: 0,
      QuestionId: 0,
      Content: answer,
      IsCorrect: isCorrect,
      SelectedCount: 0
    });
    return await post(uri, body);
  }

  async function getAllQuizesByName(containingName, pageSize, page) {
    const uri = interopHost(`administration_testsystem/tests/read`);
    const body = params({
      sort: '',
      group: '',
      filter: `Name~contains~'${containingName}'`,
      pageSize,
      page
    });
    return await post(uri, body);
  }

  async function getQuestionsById(quizId, pageSize, page) {
    const uri = interopHost(`administration_testsystem/testquestions/read?foreignKeyId=${quizId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      pageSize,
      page
    });
    return await post(uri, body);
  }

  async function getAnswersByQuestionId(questionId, pageSize, page) {
    const uri = interopHost(`administration_testsystem/testquestionanswers/read?foreignKeyId=${questionId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      pageSize,
      page
    });
    return await post(uri, body);
  }

  return {
    createQuizInstance,
    addQuestion,
    addAnswer,
    getAllQuizesByName,
    getQuestionsById,
    getAnswersByQuestionId
  };
}

/***/ }),

/***/ "./src/api/storage/assessmentConfig.js":
/*!*********************************************!*\
  !*** ./src/api/storage/assessmentConfig.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _generic__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./generic */ "./src/api/storage/generic.js");

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  const genericApi = (0,_generic__WEBPACK_IMPORTED_MODULE_0__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const storeId = {
    'softuni.bg': 3797,
    'digital.softuni.bg': 3556,
    'creative.softuni.bg': 1411,
    'ai.softuni.bg': 6,
    'financeacademy.bg': 73
  };

  function serialize(data) {
    return {
      sort: '',
      group: '',
      filter: '',
      Id: data.Id || 0,
      TrainingId: storeId[interopAppId()],
      NameBg: '0000000000' + data.ExamId,
      NameEn: '0000000000',
      HasManualNumberOfStudyHours: true,
      NumberOfStudyHours: 0,
      IsExcludedFromCertificate: false,
      HasHomework: false,
      ResourceMailsState: 0,
      HomeworkMailsState: 0,
      JudgeContestId: '',
      OrderBy: 0,
      DescriptionBg: '0000000000' + JSON.stringify(data.Config),
      DescriptionEn: '0000000000',
      ExcludeFromCalendar: false,
      HasLiveStream: false,
      CreatedOn: '',
      ModifiedOn: ''
    };
  }

  function parse(entry) {
    if (entry) {
      return {
        Id: entry.Id,
        ExamId: Number((entry.NameBg || '').slice(10)),
        Config: JSON.parse((entry.DescriptionBg || '').slice(10))
      };
    } else {
      return undefined;
    }
  }

  async function getConfigs(examIds) {
    const data = await genericApi.getEntries(storeId[interopAppId()], `NameBg~eq~'${examIds.map(id => '0000000000' + id).join('\'~or~NameBg~eq~\'')}'`);
    return data.map(parse);
    ;
  }

  async function getConfigByExamId(examId) {
    const config = await genericApi.getEntries(storeId[interopAppId()], `NameBg~eq~'0000000000${examId}'`);
    return parse(config.Data[0]);
  }

  async function saveConfig(config) {
    const operation = config.Id ? genericApi.updateEntry : genericApi.createEntry;
    const result = await operation(serialize(config));
    return parse(result.Data[0]);
  }

  async function deleteConfig(config) {
    return genericApi.destroyEntry(serialize(config));
  }

  return {
    getConfigs,
    getConfigByExamId,
    saveConfig,
    deleteConfig
  };
}

/***/ }),

/***/ "./src/api/storage/generic.js":
/*!************************************!*\
  !*** ./src/api/storage/generic.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  /* Entry model:
        {
          sort: '',
          group: '',
          filter: '',
          Id: data.Id,
          TrainingId: storeId[interopAppId()],
          NameBg: '',                             String (3-200)
          NameEn: '',                             String (3-200)
          NumberOfStudyHours: 0,                  Integer
          IsExcludedFromCertificate: false,       Boolean
          HasHomework: false,                     Boolean
          ResourceMailsState: 0,
          HomeworkMailsState: 0,
          JudgeContestId: '',                     Integer (cannot be empty)
          OrderBy: 0,                             Integer
          DescriptionBg: '',                      String (10-6000)
          DescriptionEn: '',                      String (10-6000)
          ExcludeFromCalendar: false,             Boolean
          HasLiveStream: false,                   Boolean
          CreatedOn: '',
          ModifiedOn: ''
      };
  */
  const settingsStoreId = {
    'softuni.bg': 529,
    'digital.softuni.bg': 1064,
    'creative.softuni.bg': 101,
    'ai.softuni.bg': 5,
    'financeacademy.bg': 24
  };

  async function getStoreSettings(storeId) {
    const uri = interopHost(`administration_trainings/fasttrackinstances/read?foreignKeyId=${settingsStoreId[interopAppId()]}`);
    const body = params({
      filter: `Id~eq~${storeId}`
    });
    const store = (await post(uri, body)).Data[0];
    const asJson = (store.DescriptionBg || '').slice(10) + (store.DescriptionEn || '').slice(10);

    try {
      return {
        settings: JSON.parse(asJson),
        _ModifiedOn: store.ModifiedOn || store.CreatedOn
      };
    } catch (err) {
      console.error(err);
      return undefined;
    }
  }

  async function saveStoreSettings(storeId, settings) {
    const currentUri = interopHost(`administration_trainings/fasttrackinstances/read?foreignKeyId=${settingsStoreId[interopAppId()]}`);
    const currentBody = params({
      filter: `Id~eq~${storeId}`
    });
    const current = (await post(currentUri, currentBody)).Data[0];
    delete current.SharesLiveStreamWithTrainings;

    if (settings.hasOwnProperty('_ModifiedOn') && settings.hasOwnProperty('settings')) {
      settings = settings.settings;
    }

    const asJson = JSON.stringify(settings);
    current.DescriptionBg = '0000000000' + asJson.slice(0, 10000);
    current.DescriptionEn = '0000000000' + asJson.slice(10000); //Certificate type is now required (8 = None)

    current.CertificateType = 8;
    const uri = interopHost(`administration_trainings/fasttrackinstances/update?foreignKeyId=${settingsStoreId[interopAppId()]}`);
    const body = {
      'sort': '',
      'group': '',
      'filter': '',
      ...current,
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:01.317'
    };
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });

    try {
      const result = (await post(uri, body)).Data[0];
      return JSON.parse((result.DescriptionBg || '').slice(10));
    } catch (err) {
      console.error(err);
      return undefined;
    }
  }

  async function getEntries(storeId, filter) {
    const uri = interopHost(`administration_trainings/lectures/read?foreignKeyId=${storeId}`);
    const body = params({
      pageSize: 1000
    });

    if (filter) {
      body.filter = filter;
    }

    return (await post(uri, body)).Data;
  }

  async function updateEntry(entry) {
    let startDate = new Date();
    let endDate = new Date(startDate);
    endDate.setUTCDate(endDate.getUTCDate() + 1);
    const uri = interopHost(`administration_trainings/lectures/update?foreignKeyId=${entry.TrainingId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: entry.Id,
      TrainingId: entry.TrainingId,
      NameBg: entry.NameBg,
      NameEn: entry.NameEn,
      HasManualNumberOfStudyHours: true,
      NumberOfStudyHours: entry.NumberOfStudyHours,
      IsExcludedFromCertificate: entry.IsExcludedFromCertificate,
      HasHomework: entry.HasHomework,
      ResourceMailsState: entry.ResourceMailsState,
      HomeworkMailsState: entry.HomeworkMailsState,
      JudgeContestId: entry.JudgeContestId,
      OrderBy: entry.OrderBy,
      DescriptionBg: entry.DescriptionBg,
      DescriptionEn: entry.DescriptionEn,
      ExcludeFromCalendar: entry.ExcludeFromCalendar,
      HasLiveStream: entry.HasLiveStream,
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:02.317',
      DatesInfo: [{
        Start: startDate.toISOString(),
        End: endDate.toISOString(),
        ExtraInformation: ''
      }]
    });
    serializeDatesInfo(body);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function createEntry(entry) {
    let startDate = new Date();
    let endDate = new Date(startDate);
    endDate.setUTCDate(endDate.getUTCDate() + 1);
    const uri = interopHost(`administration_trainings/lectures/create?foreignKeyId=${entry.TrainingId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: entry.Id,
      TrainingId: entry.TrainingId,
      NameBg: entry.NameBg,
      NameEn: entry.NameEn,
      HasManualNumberOfStudyHours: true,
      NumberOfStudyHours: entry.NumberOfStudyHours,
      IsExcludedFromCertificate: entry.IsExcludedFromCertificate,
      HasHomework: entry.HasHomework,
      ResourceMailsState: entry.ResourceMailsState,
      HomeworkMailsState: entry.HomeworkMailsState,
      JudgeContestId: entry.JudgeContestId,
      OrderBy: entry.OrderBy,
      DescriptionBg: entry.DescriptionBg,
      DescriptionEn: entry.DescriptionEn,
      ExcludeFromCalendar: entry.ExcludeFromCalendar,
      HasLiveStream: entry.HasLiveStream,
      CreatedOn: '',
      ModifiedOn: '',
      DatesInfo: [{
        Start: startDate.toISOString(),
        End: endDate.toISOString(),
        ExtraInformation: ''
      }]
    });
    serializeDatesInfo(body);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function destroyEntry(entry) {
    const uri = interopHost(`administration_trainings/lectures/destroy?foreignKeyId=${entry.TrainingId}`);
    const body = params({
      sort: '',
      group: '',
      filter: ''
    });
    Object.assign(body, entry);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    return post(uri, body);
  }

  function serializeDatesInfo(body) {
    const datesInfo = body.DatesInfo;
    delete body.DatesInfo;

    for (let i = 0; i < datesInfo.length; i++) {
      const date = datesInfo[i];
      body[`DatesInfo[${i}].Start`] = date.Start;
      body[`DatesInfo[${i}].End`] = date.End;
      body[`DatesInfo[${i}].ExtraInformation`] = date.ExtraInformation;
    }
  }

  return {
    getStoreSettings,
    saveStoreSettings,
    getEntries,
    updateEntry,
    createEntry,
    destroyEntry
  };
}

/***/ }),

/***/ "./src/api/storage/modulesData.js":
/*!****************************************!*\
  !*** ./src/api/storage/modulesData.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _generic__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./generic */ "./src/api/storage/generic.js");

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  const genericApi = (0,_generic__WEBPACK_IMPORTED_MODULE_0__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const storeId = {
    'softuni.bg': 4492,
    'digital.softuni.bg': 3815,
    'creative.softuni.bg': 1612,
    'ai.softuni.bg': 9
  };
  return {
    getModuleDataSettings: () => genericApi.getStoreSettings(storeId[interopAppId()]),
    saveModuleDataSettings: settings => genericApi.saveStoreSettings(storeId[interopAppId()], settings)
  };
}

/***/ }),

/***/ "./src/api/storage/paymentStats.js":
/*!*****************************************!*\
  !*** ./src/api/storage/paymentStats.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _generic__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./generic */ "./src/api/storage/generic.js");

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  const genericApi = (0,_generic__WEBPACK_IMPORTED_MODULE_0__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const storeId = {
    'softuni.bg': 3833,
    'digital.softuni.bg': 3582,
    'creative.softuni.bg': 1428,
    'ai.softuni.bg': 10
  };

  function serialize(data) {
    const payload = {
      PaymentsByDate: data.PaymentsByDate,
      RetentionByDate: data.RetentionByDate,
      OnlinePayments: data.OnlinePayments || 0,
      OnlineRetention: data.OnlineRetention || 0,
      SitePayments: data.SitePayments || 0,
      SiteRetention: data.SiteRetention || 0
    };
    const asJson = JSON.stringify(payload);
    return {
      sort: '',
      group: '',
      filter: '',
      Id: data.Id || 0,
      TrainingId: storeId[interopAppId()],
      NameBg: '0000000000' + (data.NameBg + '::' + data.NameEn + '::' + data.LevelId),
      NameEn: '0000000000' + JSON.stringify(data.DateConfig),
      HasManualNumberOfStudyHours: true,
      NumberOfStudyHours: data.StartIndex || 0,
      IsExcludedFromCertificate: false,
      JudgeContestId: data.LevelId,
      HasHomework: false,
      ResourceMailsState: 0,
      HomeworkMailsState: 0,
      OrderBy: data.InstanceId,
      DescriptionBg: '0000000000' + asJson.slice(0, 5980),
      DescriptionEn: '0000000000' + asJson.slice(5980),
      ExcludeFromCalendar: !data.IsMainProgram,
      HasLiveStream: false,
      CreatedOn: '',
      ModifiedOn: ''
    };
  }

  function parse(entry) {
    if (entry) {
      try {
        const payloadJson = (entry.DescriptionBg || '').slice(10) + (entry.DescriptionEn || '').slice(10);
        const payload = JSON.parse(payloadJson);
        const namesAndLevel = entry.NameBg.slice(10).split('::');
        return {
          Id: entry.Id,
          InstanceId: Number(entry.OrderBy) || null,
          LevelId: Number(namesAndLevel[2]) || entry.JudgeContestId,
          NameBg: namesAndLevel[0],
          NameEn: namesAndLevel[1],
          DateConfig: JSON.parse((entry.NameEn || '').slice(10)),
          StartIndex: entry.NumberOfStudyHours,
          PaymentsByDate: payload.PaymentsByDate,
          RetentionByDate: payload.RetentionByDate,
          OnlinePayments: payload.OnlinePayments || 0,
          OnlineRetention: payload.OnlineRetention || 0,
          SitePayments: payload.SitePayments || 0,
          SiteRetention: payload.SiteRetention || 0,
          IsMainProgram: !entry.ExcludeFromCalendar,
          ModifiedOn: entry.ModifiedOn || entry.CreatedOn
        };
      } catch (err) {
        console.error('Destroying incompatible entry');
        console.log(entry);
        console.error(err);
        genericApi.destroyEntry(entry);
        return undefined;
      }
    } else {
      return undefined;
    }
  }

  async function getStats(instanceIds) {
    const data = await genericApi.getEntries(storeId[interopAppId()], `OrderBy~eq~${instanceIds.join('~or~OrderBy~eq~')}`);
    return data.map(parse);
  }

  async function getStatsByInstanceId(instanceId) {
    const config = await genericApi.getEntries(storeId[interopAppId()], `OrderBy~eq~${instanceId}`);
    return parse(config[0]);
  }

  async function getStatsByStartIndex(start, end) {
    const data = await genericApi.getEntries(storeId[interopAppId()], `NumberOfStudyHours~gte~${start}~and~NumberOfStudyHours~lte~${end}`);
    return data.map(parse);
  }

  async function saveStats(stats) {
    const operation = stats.Id ? genericApi.updateEntry : genericApi.createEntry;
    const result = await operation(serialize(stats));

    if (result.Errors) {
      const error = new Error('Request returned Errors');
      error._errorObject = result.Errors;
      throw error;
    } // console.log(JSON.stringify(result));


    return parse(result.Data[0]);
  }

  async function deleteStats(stats) {
    return genericApi.destroyEntry(serialize(stats));
  }

  return {
    getStatsSettings: () => genericApi.getStoreSettings(storeId[interopAppId()]),
    saveStatsSettings: settings => genericApi.saveStoreSettings(storeId[interopAppId()], settings),
    getStats,
    getStatsByInstanceId,
    getStatsByStartIndex,
    saveStats,
    deleteStats
  };
}

/***/ }),

/***/ "./src/api/storage/templates.js":
/*!**************************************!*\
  !*** ./src/api/storage/templates.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _generic__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./generic */ "./src/api/storage/generic.js");

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  const genericApi = (0,_generic__WEBPACK_IMPORTED_MODULE_0__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const templateStoreId = {
    'softuni.bg': 3519,
    'digital.softuni.bg': 3440,
    'creative.softuni.bg': 1300,
    'ai.softuni.bg': 7,
    'financeacademy.bg': 74
  };

  async function getTemplateStoreSettings() {
    return genericApi.getStoreSettings(templateStoreId[interopAppId()]);
  }

  function templateToEntry(data) {
    return {
      sort: '',
      group: '',
      filter: '',
      Id: data.Id || 0,
      TrainingId: templateStoreId[interopAppId()],
      NameBg: '0000000000' + data.Name,
      NameEn: '0000000000' + JSON.stringify(data.Category),
      HasManualNumberOfStudyHours: true,
      NumberOfStudyHours: 0,
      IsExcludedFromCertificate: data.Active,
      HasHomework: false,
      ResourceMailsState: 0,
      HomeworkMailsState: 0,
      JudgeContestId: '',
      OrderBy: 0,
      DescriptionBg: '0000000000' + data.Content,
      DescriptionEn: ('0000000000' + (data.InstanceId || '')).slice(-10),
      ExcludeFromCalendar: data.Compound,
      HasLiveStream: false,
      CreatedOn: '',
      ModifiedOn: ''
    };
  }

  function entryToTemplate(entry) {
    if (entry) {
      return {
        Id: entry.Id,
        Name: entry.NameBg.slice(10),
        Category: JSON.parse(entry.NameEn.slice(10)) || [],
        Active: entry.IsExcludedFromCertificate,
        Compound: entry.ExcludeFromCalendar,
        Content: (entry.DescriptionBg || '').slice(10),
        InstanceId: Number(entry.DescriptionEn) || null
      };
    } else {
      return undefined;
    }
  }

  async function getTemplates() {
    const data = await genericApi.getEntries(templateStoreId[interopAppId()]);
    return data.map(entryToTemplate).sort((a, b) => {
      return (b.Active ? 1 : 0) - (a.Active ? 1 : 0) || (b.Compound ? 1 : 0) - (a.Compound ? 1 : 0) || a.Name.localeCompare(b.Name);
    });
  }

  async function getTemplateByName(name) {
    const template = await genericApi.getEntries(templateStoreId[interopAppId()], `NameBg~eq~'${name}'`);
    return entryToTemplate(template[0]);
  }

  async function getTemplateByInstanceId(instanceId) {
    const template = await genericApi.getEntries(templateStoreId[interopAppId()], `DescriptionEn~eq~'${instanceId}'`);
    return entryToTemplate(template[0]);
  }

  async function saveTemplate(template) {
    const operation = template.Id ? genericApi.updateEntry : genericApi.createEntry;
    const result = await operation(templateToEntry(template));
    return entryToTemplate(result.Data[0]);
  }

  async function deleteTemplate(template) {
    return genericApi.destroyEntry(templateToEntry(template));
  }

  return {
    getTemplateStoreSettings,
    getTemplates,
    getTemplateByName,
    getTemplateByInstanceId,
    saveTemplate,
    deleteTemplate
  };
}

/***/ }),

/***/ "./src/api/stream/stream.js":
/*!**********************************!*\
  !*** ./src/api/stream/stream.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getInstanceConfig(instanceId) {
    const uri = `https://ses-webext.github.io/stream/${instanceId}.json`;

    try {
      const result = await get(uri);
      return result;
    } catch (err) {
      console.log(err);
      return null;
    }
  }

  return {
    getInstanceConfig
  };
}

/***/ }),

/***/ "./src/api/survey.js":
/*!***************************!*\
  !*** ./src/api/survey.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post
}) {
  async function getSurveys(page, query, filter, pageSize = 30) {
    if (pageSize == undefined) {
      pageSize = 30;
    }

    const url = interopHost('administration_surveys/surveys/read');
    const body = params({
      sort: 'ActiveTo-desc',
      pageSize: pageSize,
      page
    });

    if (query) {
      body.filter = `Name~contains~'${query}'`;
    }

    if (filter) {
      body.filter += `~and~(${filter})`;
    }

    return post(url, body);
  }

  async function getSurveysByNameAndStartAndEndDate(page, name, startDate, endDate, pageSize = 30) {
    if (pageSize == undefined) {
      pageSize = 30;
    }

    const url = interopHost('administration_surveys/surveys/read');
    const body = params({
      sort: 'ActiveTo-desc',
      pageSize: pageSize,
      page
    });
    body.filter = `Name~contains~'${name}'~and~ActiveFrom~gte~datetime'${startDate}'~and~ActiveFrom~lt~datetime'${endDate}'`;
    return post(url, body);
  }

  async function getSurveyById(surveyId) {
    const url = interopHost('administration_surveys/surveys/read');
    const body = params({
      filter: 'Id~eq~' + surveyId
    });
    return (await post(url, body)).Data[0];
  }

  async function getSurveyAnswers(surveyId) {
    const url = interopHost('administration_surveys/userpollanswers/read');
    const body = params({
      pageSize: 10000,
      filter: 'SurveyId~eq~' + surveyId
    });
    return post(url, body);
  }

  async function getSurveyTemplates() {
    const url = interopHost('administration_surveys/surveysectiontemplates/read');
    const body = params({
      pageSize: 10000
    });
    return post(url, body);
  }

  async function getSurveyQuestionsByTemplateId(templateId) {
    const url = interopHost(`administration_surveys/pollquestions/readpollquestions?surveySectionTemplateId=${templateId}`);
    const body = params({
      pageSize: 10000
    });
    return post(url, body);
  }

  async function getSurveySectionsByTemplateId(templateId) {
    const url = interopHost('administration_surveys/surveysections/read');
    const body = params({
      pageSize: 10000,
      filter: `SurveySectionTemplateId~eq~${templateId}`
    });
    return post(url, body);
  }

  async function getSurveySectionsById(sectionId) {
    const url = interopHost('administration_surveys/surveysections/read');
    const body = params({
      pageSize: 10000,
      filter: `Id~eq~${Array.isArray(sectionId) ? sectionId.join('~or~Id~eq~') : sectionId}`
    });
    return post(url, body);
  }

  async function findSectionsByTraining(nameBg) {
    const url = interopHost('administration_surveys/surveysections/read');
    const body = params({
      pageSize: 100,
      filter: `Training~eq~'${nameBg}'~and~Name~doesnotcontain~'обслужване'~and~Name~doesnotcontain~'информация'~and~Name~doesnotcontain~'свързани с курса'`
    });
    return (await post(url, body)).Data.map(s => s.Name);
  }

  async function findAnswersBySection(sectionNames) {
    const url = interopHost('administration_surveys/userpollanswers/read');
    const body = params({
      pageSize: 10000,
      filter: 'Section~eq~\'' + sectionNames.join('\'~or~Section~eq~\'') + '\''
    });
    return (await post(url, body)).Data;
  }

  async function findSurveyByTraining(nameBg) {
    const sections = await findSectionsByTraining(nameBg);
    console.log(sections);
    const answers = await findAnswersBySection(sections);
    const surveys = [...answers.reduce((p, c) => {
      p.add(c.SurveyId);
      return p;
    }, new Set())];
    return Promise.all(surveys.map(getSurveyById));
  }

  return {
    getSurveys,
    getSurveysByNameAndStartAndEndDate,
    getSurveyById,
    getSurveyAnswers,
    getSurveyTemplates,
    getSurveyQuestionsByTemplateId,
    getSurveySectionsByTemplateId,
    getSurveySectionsById,
    findSurveyByTraining
  };
}

/***/ }),

/***/ "./src/api/trainings/assessment.js":
/*!*****************************************!*\
  !*** ./src/api/trainings/assessment.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util */ "./src/api/util.js");

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getHomeworkResults(instanceId) {
    const uri = interopHost(`administration_crm/internalcoursecrmprofiles/readinternalcoursecrmprofiles/${instanceId}`);
    return await fetchNext();

    async function fetchNext(page = 1) {
      const body = params({
        sort: 'CreatedOn-desc',
        pageSize: 1000,
        page
      });
      const response = await post(uri, body);
      let result = response.Data;

      if (response.Total > page * 1000) {
        result = result.concat(await fetchNext(page + 1));
      }

      return result;
    }
  }

  async function getProtocol(instanceId) {
    const response = await fetch(interopHost(`administration_trainings/usersincourses/exporttrainingprotocol/${instanceId}`), {
      'credentials': 'include',
      'headers': {
        'Host': 'softuni.bg',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:97.0) Gecko/20100101 Firefox/97.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br',
        'Connection': 'keep-alive',
        'Referer': interopHost('administration_trainings/usersintrainingsmanagement'),
        'Upgrade-Insecure-Requests': 1,
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache'
      },
      'method': 'GET',
      'mode': 'cors'
    });
    const blob = await response.blob();
    const serializedBlob = new Uint8Array(await blob.arrayBuffer());
    const blobData = {
      type: blob.type,
      buffer: Array.from(serializedBlob)
    };
    return blobData;
  }

  async function uploadFile(url, formData) {
    const result = await fetch(url, {
      credentials: 'include',
      method: 'POST',
      body: formData
    });
    return result;
  }

  async function uploadExamResults(examName, examId, combo, fileDescriptor) {
    const url = interopHost('administration_trainings/exams/importexamresults');
    const {
      blob,
      filename
    } = await (0,_util__WEBPACK_IMPORTED_MODULE_0__.parseCrossBrowserFile)(fileDescriptor);
    const formData = new FormData();
    const rvt = await obtainRVT();
    formData.append('__RequestVerificationToken', rvt);
    formData.append('ExamId_input', examName);
    formData.append('ExamId', examId);
    formData.append('ResultsFile', blob, filename);

    if (combo.importPractice) {
      formData.append('ImportPreferences', 1); // Practice
    }

    if (combo.importQuiz) {
      formData.append('ImportPreferences', 2); // Quiz
    }

    formData.append('UsernameColumn', 1);
    formData.append('ResultColumn', 2);
    formData.append('CommentColumn', 3);
    formData.append('TheoryResultColumn', 4);
    formData.append('TheoryCommentColumn', 5);
    const result = await uploadFile(url, formData);
    return processExamResultOutcome(result);
  }

  async function processExamResultOutcome(result) {
    const page = await result.text();
    const successPattern = /<h3>Успешни записи:(.+?)<\/h3>/us;
    const failurePattern = /<h3>Неуспешни записи:(.+?)<\/h3>/us;
    const userlistPattern = /<p>.*?Успешно бяха вмъкнати резултатите на следните потребители:(.+?)<\/p>/us;

    try {
      const successful = Number(successPattern.exec(page)[1].trim());
      const failed = Number(failurePattern.exec(page)[1].trim());
      const list = userlistPattern.exec(page)[1].trim().split(',').map(u => u.trim());
      return {
        successful,
        failed,
        list
      };
    } catch (err) {
      console.error(err);
      throw new Error('Error processing file');
    }
  }

  async function obtainRVT() {
    const url = interopHost('administration_trainings/exams/importexamresults');
    const pageData = await get(url);
    const pattern = /<input.*?name="__RequestVerificationToken".*?value="(.+?)".*?>/i;
    const rvt = pattern.exec(pageData)[1];
    return rvt;
  }

  return {
    getHomeworkResults,
    getProtocol,
    uploadExamResults
  };
}

/***/ }),

/***/ "./src/api/trainings/events.js":
/*!*************************************!*\
  !*** ./src/api/trainings/events.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getEvents(instanceId) {
    const uri = interopHost('administration_trainings/traininggrouplectures/read');
    const body = params({
      sort: 'StartDateTime-asc',
      page: 1,
      pageSize: 100,
      group: '',
      filter: `TrainingId~eq~${instanceId}`
    });
    return (await post(uri, body)).Data;
  }

  async function updateEvent(event) {
    const uri = interopHost('administration_trainings/traininggrouplectures/update');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: event.Id,
      TrainingGroupId: event.TrainingGroupId,
      TrainingGroupName: event.TrainingGroupName,
      LectureId: event.LectureId,
      LectureName: event.LectureName,
      TrainingId: event.TrainingId,
      StartDateTime: event.StartDateTime,
      EndDateTime: event.EndDateTime,
      HasLiveStream: event.HasLiveStream,
      TrainingLabId: event.TrainingLabId,
      TrainingLabName: event.TrainingLabName,
      LastEditedUsername: '',
      CreatedOn: '',
      ModifiedOn: '',
      TrainingGroupId_input: ''
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function createEvent(event) {
    const uri = interopHost('administration_trainings/traininggrouplectures/create');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: event.Id,
      TrainingGroupId: event.TrainingGroupId,
      TrainingGroupName: event.TrainingGroupName,
      LectureId: event.LectureId,
      LectureName: event.LectureName,
      TrainingId: event.TrainingId,
      StartDateTime: event.StartDateTime,
      EndDateTime: event.EndDateTime,
      HasLiveStream: event.HasLiveStream,
      TrainingLabId: event.TrainingLabId,
      TrainingLabName: event.TrainingLabName,
      LastEditedUsername: '',
      CreatedOn: '',
      ModifiedOn: '',
      TrainingGroupId_input: ''
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function destroyEvent(event) {
    const uri = interopHost('administration_trainings/traininggrouplectures/destroy');
    const body = params({
      sort: '',
      group: '',
      filter: ''
    });
    Object.assign(body, event);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    return post(uri, body);
  }

  async function getEventsByDate(startDate, endDate) {
    // Date format yyyy-mm-dd example: 2020-03-25
    const uri = interopHost('administration_trainings/traininggrouplectures/read');
    const body = params({
      sort: 'StartDateTime-asc',
      page: 1,
      pageSize: 10000,
      group: '',
      filter: `StartDateTime~gte~datetime'${startDate}T00-00-00'~and~EndDateTime~lte~datetime'${endDate}T23-59-59'`
    });
    return (await post(uri, body)).Data;
  }

  async function getEventsById(eventId) {
    // Date format yyyy-mm-dd example: 2020-03-25
    const uri = interopHost('administration_trainings/traininggrouplectures/read');
    const body = params({
      sort: 'StartDateTime-asc',
      page: 1,
      pageSize: 1000,
      group: '',
      filter: `Id~eq~${eventId}`
    });
    return (await post(uri, body)).Data;
  }

  return {
    getEvents,
    updateEvent,
    createEvent,
    destroyEvent,
    getEventsByDate,
    getEventsById
  };
}

/***/ }),

/***/ "./src/api/trainings/exams.js":
/*!************************************!*\
  !*** ./src/api/trainings/exams.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getExamsById(ids) {
    if (Array.isArray(ids) == false) {
      ids = [ids];
    }

    if (ids.length == 0) {
      return [];
    }

    const uri = interopHost('administration_trainings/exams/read');
    const body = params({
      pageSize: 10000,
      filter: `Id~eq~${ids.join('~or~Id~eq~')}`
    });
    return (await post(uri, body)).Data;
  }

  async function getExamsByCourse(nameBg, instanceId) {
    const uri = interopHost('administration_trainings/exams/read');

    const filter = (() => {
      if (interopAppId() === 'softuni.bg') {
        return `TrainingNamesString~contains~'${nameBg}'`;
      } else {
        return '';
      }
    })();

    const body = params({
      pageSize: 10000,
      filter
    });
    const data = await post(uri, body);
    return data.Data.filter(e => e.PrimaryTrainings.filter(t => t.Id == instanceId).length > 0 || e.RetakenTrainings.filter(t => t.Id == instanceId).length > 0);
  }

  async function getExamsByName(query) {
    const uri = interopHost('administration_trainings/exams/read');

    const filter = (() => {
      if (Array.isArray(query)) {
        return `(NameBg~contains~'${query.join('\'~or~NameBg~contains~\'')}')~or~(NameEn~contains~'${query.join('\'~or~NameEn~contains~\'')}')`;
      } else {
        return `NameBg~contains~'${query}'~or~NameEn~contains~'${query}'`;
      }
    })();

    const body = params({
      sort: 'CreatedOn-desc',
      pageSize: 20,
      filter
    });
    const data = await post(uri, body);

    if (Array.isArray(query)) {
      const fullMatch = await getExamsByName(query.join(' '));
      const filtered = data.Data.filter(r => fullMatch.some(x => x.Id == r.Id) == false);
      return fullMatch.concat(filtered.slice(0, 20 - fullMatch.length));
    } else {
      return data.Data;
    }
  }

  async function getExamGroupsByExamId(examId) {
    if (Array.isArray(examId) == false) {
      examId = [examId];
    }

    if (examId.length == 0) {
      return [];
    }

    const uri = interopHost('administration_trainings/examgroups/read');
    const body = params({
      pageSize: 10000,
      filter: `ExamId~eq~${examId.join('~or~ExamId~eq~')}`
    });
    return (await post(uri, body)).Data;
  }

  async function getExamGroupsByDate(startDate, endDate) {
    // Date format yyyy-mm-dd example: 2020-03-25
    const uri = interopHost('administration_trainings/examgroups/read');
    const body = params({
      sort: 'StartTime-asc',
      page: 1,
      pageSize: 10000,
      group: '',
      filter: `StartTime~gte~datetime'${startDate}T00-00-00'~and~EndTime~lte~datetime'${endDate}T23-59-59'`
    });
    return (await post(uri, body)).Data;
  }

  async function getEnrolledByGroupId(examGroupId) {
    const uri = interopHost(`administration_trainings/examgroupparticipants/read?foreignKeyId=${examGroupId}`);
    const body = params({
      pageSize: 10000
    });
    return (await post(uri, body)).Data;
  }

  async function createExam(exam) {
    const uri = interopHost('administration_trainings/exams/create');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: exam.Id,
      NameBg: exam.NameBg,
      NameEn: exam.NameEn,
      Type: exam.Type,
      AllowChoosingSeatsWithComputer: exam.AllowChoosingSeatsWithComputer,
      AllowAllUsersInTrainingsToSitExam: exam.AllowAllUsersInTrainingsToSitExam,
      ExamGroupEnrollmentDeadline: exam.ExamGroupEnrollmentDeadline,
      TrainingNamesString: '',
      CreatedOn: '',
      ModifiedOn: ''
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    }); // Two-step process is necessary because of a server bug when the exam has associated training instances

    const result = await post(uri, body);

    if (result.Errors !== null) {
      return result;
    } else {
      const item = result.Data[0];
      item.PrimaryTrainings = exam.PrimaryTrainings;
      item.RetakenTrainings = exam.RetakenTrainings;
      const deadline = new Date(Number(item.ExamGroupEnrollmentDeadline.match(/\d+/)[0]));
      item.ExamGroupEnrollmentDeadline = Number.isNaN(deadline) ? '' : deadline.toISOString();
      return updateExam(item);
    }
  }

  async function updateExam(exam) {
    const uri = interopHost('administration_trainings/exams/update');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: exam.Id,
      NameBg: exam.NameBg,
      NameEn: exam.NameEn,
      Type: exam.Type,
      AllowChoosingSeatsWithComputer: exam.AllowChoosingSeatsWithComputer,
      AllowAllUsersInTrainingsToSitExam: exam.AllowAllUsersInTrainingsToSitExam,
      ExamGroupEnrollmentDeadline: exam.ExamGroupEnrollmentDeadline,
      TrainingNamesString: '',
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:01.317'
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    exam.PrimaryTrainings.forEach(trainingsToBody('PrimaryTrainings'));
    exam.RetakenTrainings.forEach(trainingsToBody('RetakenTrainings'));
    return post(uri, body);

    function trainingsToBody(propName) {
      return function (training, index) {
        body[`${propName}[${index}].Id`] = training.Id;
        body[`${propName}[${index}].Name`] = training.NameBg;
        body[`${propName}[${index}].NameBg`] = training.NameBg;
        body[`${propName}[${index}].NameEn`] = training.NameEn;
      };
    }
  }

  async function createExamGroup(group) {
    const uri = interopHost('administration_trainings/examgroups/create');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: '0',
      ExamId: group.ExamId,
      ExamName: '',
      StartTime: group.StartTime,
      EndTime: group.EndTime,
      TrainingLabId: group.TrainingLabId,
      JudgeSystemContestId: group.JudgeSystemContestId,
      TestSystemTestId: group.TestSystemTestId,
      ExamGroupParticipantsCount: group.ExamGroupParticipantsCount,
      Limit: group.Limit,
      IsAddedToGoogleCalendar: group.IsAddedToGoogleCalendar,
      CustomEnrollmentSuccessMessage: group.CustomEnrollmentSuccessMessage,
      CreatedOn: '',
      ModifiedOn: ''
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function updateExamGroup(group) {
    const uri = interopHost('administration_trainings/examgroups/update');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: group.Id,
      ExamId: group.ExamId,
      ExamName: group.ExamName,
      StartTime: group.StartTime,
      EndTime: group.EndTime,
      TrainingLabId: group.TrainingLabId,
      JudgeSystemContestId: group.JudgeSystemContestId,
      TestSystemTestId: group.TestSystemTestId,
      ExamGroupParticipantsCount: group.ExamGroupParticipantsCount,
      Limit: group.Limit,
      IsAddedToGoogleCalendar: group.IsAddedToGoogleCalendar,
      CustomEnrollmentSuccessMessage: group.CustomEnrollmentSuccessMessage,
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:01.317'
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function destroyExamGroup(group) {
    const uri = interopHost('administration_trainings/examgroups/destroy');
    const body = params({
      sort: '',
      group: '',
      filter: ''
    });
    Object.assign(body, group);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    return post(uri, body);
  }

  return {
    getExamsById,
    getExamsByCourse,
    getExamsByName,
    getExamGroupsByExamId,
    getEnrolledByGroupId,
    getExamGroupsByDate,
    createExam,
    updateExam,
    createExamGroup,
    updateExamGroup,
    destroyExamGroup
  };
}

/***/ }),

/***/ "./src/api/trainings/groups.js":
/*!*************************************!*\
  !*** ./src/api/trainings/groups.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getInsanceGroups(instanceId) {
    const uri = interopHost('administration_trainings/traininggroups/read');
    const body = params({
      pageSize: 100,
      filter: `TrainingId~eq~${instanceId}`
    });
    return (await post(uri, body)).Data;
  }

  async function getGroupById(groupId) {
    const uri = interopHost('administration_trainings/traininggroups/read');
    const body = params({
      pageSize: 100,
      filter: `Id~eq~${groupId}`
    });
    return (await post(uri, body)).Data[0];
  }

  async function createTrainingGroup(group) {
    const uri = interopHost('administration_trainings/traininggroups/create');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: group.Id,
      TrainingId: group.TrainingId,
      TrainingName: group.TrainingName,
      TrainingLabId: group.TrainingLabId,
      Name: group.Name,
      DayOfWeek: group.DayOfWeek,
      StartTime: group.StartTime,
      EndTime: group.EndTime,
      SkipWeeksCount: group.SkipWeeksCount,
      WeekLectureNumber: group.WeekLectureNumber,
      PeopleLimit: group.PeopleLimit,
      TakenPlaces: group.TakenPlaces,
      IsAddedToGoogleCalendar: group.IsAddedToGoogleCalendar,
      CreatedOn: '',
      ModifiedOn: ''
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function destroyGroup(group) {
    const uri = interopHost('administration_trainings/traininggroups/destroy');
    const body = params({
      sort: '',
      group: '',
      filter: ''
    });
    Object.assign(body, group);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    return post(uri, body);
  }

  return {
    getInsanceGroups,
    getGroupById,
    createTrainingGroup,
    destroyGroup
  };
}

/***/ }),

/***/ "./src/api/trainings/lectures.js":
/*!***************************************!*\
  !*** ./src/api/trainings/lectures.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getInstanceLectures(instanceId) {
    const uri = interopHost(`administration_trainings/lectures/read?foreignKeyId=${instanceId}`);
    const body = params({
      sort: 'OrderBy-asc',
      pageSize: 100
    });
    return (await post(uri, body)).Data;
  }

  async function getLecturesForExamsByTrainingId(trainingId) {
    const uri = interopHost(`administration_trainings/lectures/read?foreignKeyId=${trainingId}`);
    const examKeywords = ['exam', 'defence', 'defense', 'изпит', 'защита'];
    const examExcludeKeywords = ['preparation', 'подготовка'];
    const body = params({
      sort: 'OrderBy-asc',
      pageSize: 100,
      filter: `(NameBg~contains~'${examKeywords.join('\'~or~NameBg~contains~\'')}')~and~(NameBg~doesnotcontain~'${examExcludeKeywords.join('\'~and~NameBg~doesnotcontain~\'')}')`
    });
    return (await post(uri, body)).Data;
  }

  async function updateLecture(lecture) {
    console.log(lecture);
    const uri = interopHost(`administration_trainings/lectures/update?foreignKeyId=${lecture.TrainingId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: lecture.Id,
      TrainingId: lecture.TrainingId,
      NameBg: lecture.NameBg,
      NameEn: lecture.NameEn,
      HasManualNumberOfStudyHours: lecture.HasManualNumberOfStudyHours,
      NumberOfStudyHours: lecture.NumberOfStudyHours,
      IsExcludedFromCertificate: lecture.IsExcludedFromCertificate,
      HasHomework: lecture.HasHomework,
      ResourceMailsState: lecture.ResourceMailsState,
      HomeworkMailsState: lecture.HomeworkMailsState,
      JudgeContestId: lecture.JudgeContestId,
      AlphaJudgeContestId: lecture.AlphaJudgeContestId,
      OrderBy: lecture.OrderBy,
      DescriptionBg: lecture.DescriptionBg,
      DescriptionEn: lecture.DescriptionEn,
      DatesInfo: lecture.DatesInfo || [],
      Lecturer: lecture.Lecturer,
      LectureType: lecture.LectureType,
      ExcludeFromCalendar: lecture.ExcludeFromCalendar,
      HasLiveStream: lecture.HasLiveStream,
      ExamPassword: lecture.ExamPassword,
      DiscordChannel: lecture.DiscordChannel,
      SlidoCode: lecture.SlidoCode,
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:02.317'
    });
    serializeDatesInfo(body);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function createLecture(lecture) {
    const uri = interopHost(`administration_trainings/lectures/create?foreignKeyId=${lecture.TrainingId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: lecture.Id,
      TrainingId: lecture.TrainingId,
      NameBg: lecture.NameBg,
      NameEn: lecture.NameEn,
      HasManualNumberOfStudyHours: lecture.HasManualNumberOfStudyHours,
      NumberOfStudyHours: lecture.NumberOfStudyHours,
      IsExcludedFromCertificate: lecture.IsExcludedFromCertificate,
      HasHomework: lecture.HasHomework,
      ResourceMailsState: lecture.ResourceMailsState,
      HomeworkMailsState: lecture.HomeworkMailsState,
      JudgeContestId: lecture.JudgeContestId,
      AlphaJudgeContestId: lecture.AlphaJudgeContestId,
      OrderBy: lecture.OrderBy,
      DescriptionBg: lecture.DescriptionBg,
      DescriptionEn: lecture.DescriptionEn,
      DatesInfo: lecture.DatesInfo || [],
      Lecturer: lecture.Lecturer,
      LectureType: lecture.LectureType,
      ExcludeFromCalendar: lecture.ExcludeFromCalendar,
      HasLiveStream: lecture.HasLiveStream,
      ExamPassword: lecture.ExamPassword,
      DiscordChannel: lecture.DiscordChannel,
      SlidoCode: lecture.SlidoCode,
      CreatedOn: '',
      ModifiedOn: ''
    });
    serializeDatesInfo(body);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function destroyLecture(lecture) {
    const uri = interopHost(`administration_trainings/lectures/destroy?foreignKeyId=${lecture.TrainingId}`);
    const body = params({
      sort: '',
      group: '',
      filter: ''
    });
    Object.assign(body, lecture);
    serializeDatesInfo(body);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    return post(uri, body);
  }

  async function getLectureDetails(trainingId, lectureId) {
    const url = interopHost(`trainings/trainings/getlecturedetails?trainingId=${trainingId}&lectureId=${lectureId}`);
    return get(url);
  }

  function serializeDatesInfo(body) {
    const datesInfo = body.DatesInfo;
    delete body.DatesInfo;

    for (let i = 0; i < datesInfo.length; i++) {
      const date = datesInfo[i];
      body[`DatesInfo[${i}].Start`] = date.Start;
      body[`DatesInfo[${i}].End`] = date.End;
      body[`DatesInfo[${i}].ExtraInformation`] = date.ExtraInformation;
    }
  }

  return {
    getInstanceLectures,
    updateLecture,
    createLecture,
    destroyLecture,
    getLectureDetails,
    getLecturesForExamsByTrainingId
  };
}

/***/ }),

/***/ "./src/api/trainings/seminars.js":
/*!***************************************!*\
  !*** ./src/api/trainings/seminars.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getSeminarsByDate(startDate, endDate) {
    // Date format yyyy-mm-dd example: 2020-03-25
    const uri = interopHost('administration_trainings/seminars/read');
    const body = params({
      sort: 'StartDate-asc',
      page: 1,
      pageSize: 10000,
      group: '',
      filter: `StartDate~gte~datetime'${startDate}T00-00-00'~and~EndDate~lte~datetime'${endDate}T23-59-59'`
    });
    return (await post(uri, body)).Data;
  }

  return {
    getSeminarsByDate
  };
}

/***/ }),

/***/ "./src/api/trainings/skills.js":
/*!*************************************!*\
  !*** ./src/api/trainings/skills.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getSkillsByInstance(name, instanceId) {
    const body = params({
      pageSize: 10000,
      sort: 'OrderBy-asc'
    });
    body.filter = `MergedTrainings~contains~'${name}'`;
    const data = await Promise.all([post(interopHost('administration_trainings/fasttrackinstanceskills/read'), body), post(interopHost('administration_trainings/courseinstanceskills/read'), body)]);
    let response = [];
    response = response.concat(data[0].Data.filter(i => i.Trainings.filter(t => t.Id == instanceId).length > 0).map(s => {
      s.Type = 'open';
      return s;
    }));
    response = response.concat(data[1].Data.filter(i => i.Trainings.filter(t => t.Id == instanceId).length > 0).map(s => {
      s.Type = 'main';
      return s;
    }));
    return response;
  }

  async function updateSkill(skill) {
    const uri = interopHost(`administration_trainings/${skill.Type === 'main' ? 'courseinstanceskills' : 'fasttrackinstanceskills'}/update`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: skill.Id,
      TextBg: skill.TextBg,
      OrderBy: skill.OrderBy,
      MergedTrainings: skill.MergedTrainings,
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:01.317'
    });

    for (let i = 0; i < skill.Trainings.length; i++) {
      const training = skill.Trainings[i];
      body[`Trainings[${i}].Id`] = training.Id;
      body[`Trainings[${i}].Name`] = training.Name;
      body[`Trainings[${i}].NameBg`] = training.NameBg;
      body[`Trainings[${i}].NameEn`] = training.NameEn;
    }

    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    const result = await post(uri, body);
    result.Data[0].Type = skill.Type;
    return result;
  }

  async function createSkill(skill) {
    const uri = interopHost(`administration_trainings/${skill.Type === 'main' ? 'courseinstanceskills' : 'fasttrackinstanceskills'}/create`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: skill.Id,
      TextBg: skill.TextBg,
      OrderBy: skill.OrderBy,
      MergedTrainings: skill.MergedTrainings,
      CreatedOn: '',
      ModifiedOn: ''
    });

    for (let i = 0; i < skill.Trainings.length; i++) {
      const training = skill.Trainings[i];
      body[`Trainings[${i}].Id`] = training.Id;
      body[`Trainings[${i}].Name`] = training.Name;
      body[`Trainings[${i}].NameBg`] = training.NameBg;
      body[`Trainings[${i}].NameEn`] = training.NameEn;
    }

    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    const result = await post(uri, body);
    result.Data[0].Type = skill.Type;
    return result;
  }

  async function destroySkill(skill) {
    const uri = interopHost(`administration_trainings/${skill.Type === 'main' ? 'courseinstanceskills' : 'fasttrackinstanceskills'}/destroy`);
    const body = params({
      sort: '',
      group: '',
      filter: ''
    });
    Object.assign(body, skill);

    for (let i = 0; i < skill.Trainings.length; i++) {
      const training = skill.Trainings[i];
      body[`Trainings[${i}].Id`] = training.Id;
      body[`Trainings[${i}].Name`] = training.Name;
      body[`Trainings[${i}].NameBg`] = training.NameBg;
      body[`Trainings[${i}].NameEn`] = training.NameEn;
    }

    delete body.Trainings;
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    return post(uri, body);
  }

  async function searchSkills(query, type) {
    const uri = interopHost(`administration_trainings/${type === 'main' ? 'courseinstanceskills' : 'fasttrackinstanceskills'}/read`);
    const body = params({
      pageSize: 15,
      sort: 'OrderBy-asc',
      filter: `TextBg~contains~'${query}'`
    });
    const data = await post(uri, body);
    data.Data.forEach(s => s.Type = type);
    return data.Data;
  }

  return {
    getSkillsByInstance,
    updateSkill,
    createSkill,
    destroySkill,
    searchSkills
  };
}

/***/ }),

/***/ "./src/api/trainings/trainings.js":
/*!****************************************!*\
  !*** ./src/api/trainings/trainings.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _events__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./events */ "./src/api/trainings/events.js");
/* harmony import */ var _lectures__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./lectures */ "./src/api/trainings/lectures.js");
/* harmony import */ var _skills__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./skills */ "./src/api/trainings/skills.js");
/* harmony import */ var _groups__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./groups */ "./src/api/trainings/groups.js");
/* harmony import */ var _exams__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./exams */ "./src/api/trainings/exams.js");
/* harmony import */ var _assessment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./assessment */ "./src/api/trainings/assessment.js");
/* harmony import */ var _seminars__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./seminars */ "./src/api/trainings/seminars.js");







/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get,
  interopPlatformHost
}) {
  const eventsApi = (0,_events__WEBPACK_IMPORTED_MODULE_0__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const lecturesApi = (0,_lectures__WEBPACK_IMPORTED_MODULE_1__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const skillsApi = (0,_skills__WEBPACK_IMPORTED_MODULE_2__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const groupsApi = (0,_groups__WEBPACK_IMPORTED_MODULE_3__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const examsApi = (0,_exams__WEBPACK_IMPORTED_MODULE_4__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const assessmentApi = (0,_assessment__WEBPACK_IMPORTED_MODULE_5__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const seminarsApi = (0,_seminars__WEBPACK_IMPORTED_MODULE_6__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });

  async function searchByName(body) {
    const query = body.query.filter(f => f.length > 0);
    const courses = await Promise.all([body.main && getMainInstances(body.page, query), body.open && getOpenInstances(body.page, query), body.general && getGeneralInstances(body.page, query)]);
    const result = [];

    for (let course of courses[0] || []) {
      result.push({
        Id: course.Id,
        NameBg: course.NameBg,
        Type: 'main',
        CourseId: course.CourseId
      });
    }

    for (let course of courses[1] || []) {
      result.push({
        Id: course.Id,
        NameBg: course.NameBg,
        Type: 'open',
        CourseId: course.CourseId
      });
    }

    for (let course of courses[2] || []) {
      result.push({
        Id: course.Id,
        NameBg: course.NameBg,
        Type: 'general',
        CourseId: course.CourseId
      });
    }

    return result;
  }

  async function searchTrainingsByName(name, exact = false) {
    if (Array.isArray(name) == false) {
      name = [name];
    }

    const uri = interopHost('administration_trainings/trainings/read');
    const body = params({
      pageSize: 50,
      filter: exact ? `NameBg~eq~'${name.filter(s => s.length > 0).join('\'~or~NameBg~eq~\'')}'` : `NameBg~contains~'${name.filter(s => s.length > 0).join('\'~or~NameBg~contains~\'')}'`,
      sort: 'StartDate-desc',
      page: 1
    });
    return (await post(uri, body)).Data;
  }

  async function searchCourses(query) {
    const url = interopHost('administration_trainings/courses/read');
    const filter = `Name~contains~'${query.split(' ').filter(s => s.length > 0).join('\'~and~Name~contains~\'')}'`;
    const body = params({
      pageSize: 100,
      filter,
      sort: 'CreatedOn-desc'
    });
    const result = (await post(url, body)).Data;
    result.forEach(r => {
      r.NameBg = r.Name;
      r.NameEn = r.Name;
    });
    return result;
  }

  async function searchCourseInstancesByCourseNameAndInstanceId(courseNames, instanceIds, filter = undefined) {
    if (Array.isArray(courseNames) == false) {
      courseNames = [courseNames];
    }

    const url = interopHost('administration_trainings/courses/read');
    const coursesFilter = `Name~contains~'${courseNames.filter(s => s.length > 0).join('\'~and~Name~contains~\'')}'`;
    const body = params({
      pageSize: 100,
      filter: coursesFilter,
      sort: 'CreatedOn-desc'
    });
    const result = (await post(url, body)).Data;
    result.forEach(r => {
      r.NameBg = r.Name;
      r.NameEn = r.Name;
    });
    let courseInstancesPromises = [];
    result.forEach(c => {
      courseInstancesPromises.push(getCourseInstances(c.Id, filter));
    });

    if (Array.isArray(instanceIds) == false) {
      instanceIds = [instanceIds];
    }

    let allCourseInstances = (await Promise.all(courseInstancesPromises)).reduce((a, c) => a.concat(c), []);
    let filteredCourseInstances = instanceIds.length == 0 ? allCourseInstances : allCourseInstances.filter(ci => instanceIds.includes(ci.Id));
    return filteredCourseInstances;
  }

  async function getMainInstances(page, query) {
    const uri = interopHost('administration_trainings/usersincourses/readcourseinstances');
    const filter = query.map(e => `NameBg~contains~'${e}'`).join('~and~');
    const body = params({
      sort: 'IsActive-desc~CreatedOn-desc',
      page,
      pageSize: 25,
      filter
    });
    const data = await post(uri, body);
    return data.Data.map(e => ({
      Id: e.Id,
      NameBg: e.NameBg,
      CourseId: e.CourseId
    }));
  }

  async function getOpenInstances(page, query) {
    const uri = interopHost('/administration_trainings/usersinfasttracks/readfasttrackinstances');
    const filter = query.map(e => `NameBg~contains~'${e}'`).join('~and~');
    const body = params({
      sort: 'IsActive-desc~CreatedOn-desc',
      page,
      pageSize: 25,
      filter
    });
    const data = await post(uri, body);
    return data.Data.map(e => ({
      Id: e.Id,
      NameBg: e.NameBg,
      CourseId: e.CourseId
    }));
  }

  async function getGeneralInstances(page, query) {
    const uri = interopHost('administration_trainings/usersingeneralcourseinstances/readgeneralcourseinstances');
    const filter = query.map(e => `NameBg~contains~'${e}'`).join('~and~');
    const body = params({
      sort: 'IsActive-desc~CreatedOn-desc',
      page,
      pageSize: 25,
      filter
    });
    const data = await post(uri, body);
    return data.Data.map(e => ({
      Id: e.Id,
      NameBg: e.NameBg,
      CourseId: e.CourseId
    }));
  }

  async function getCourseData(courseId) {
    const uri = interopHost('administration_trainings/courses/read');
    const body = params({
      filter: `Id~eq~'${courseId}'`
    });
    return (await post(uri, body)).Data[0];
  }

  async function getCourseInstances(courseId, filter = undefined) {
    const body = params({
      sort: 'StartDate-desc',
      pageSize: 100
    });
    const data = await Promise.all([filter == undefined || filter.main === true ? post(interopHost(`administration_trainings/courseinstances/read?foreignKeyId=${courseId}`), body) : Promise.resolve(true), filter == undefined || filter.main === true ? post(interopHost(`administration_trainings/fasttrackinstances/read?foreignKeyId=${courseId}`), body) : Promise.resolve(true), filter == undefined || filter.general === true ? post(interopHost(`administration_trainings/generalcourseinstances/read?foreignKeyId=${courseId}`), body) : Promise.resolve(true)]);
    let response = [];
    response = response.concat(data[0].Data != undefined ? data[0].Data.map(c => {
      c.InstanceRefType = 'main';
      return c;
    }) : []);
    response = response.concat(data[1].Data != undefined ? data[1].Data.map(c => {
      c.InstanceRefType = 'open';
      return c;
    }) : []);
    response = response.concat(data[2].Data != undefined ? data[2].Data.map(c => {
      c.InstanceRefType = 'general';
      return c;
    }) : []);
    return response;
  }

  async function getInstanceData(instanceId, courseId, type) {
    try {
      if (type) {
        return getInstanceDataByType(instanceId, courseId, type);
      } else {
        const queryResults = await Promise.all([getInstanceDataByType(instanceId, courseId, 'main'), getInstanceDataByType(instanceId, courseId, 'open'), getInstanceDataByType(instanceId, courseId, 'general')]);
        return queryResults.filter(e => e !== undefined)[0];
      }
    } catch (e) {
      console.log(e);
    }
  }

  async function getInstanceDataByType(instanceId, courseId, type) {
    const uri = (() => {
      switch (type) {
        case 'main':
          return interopHost(`administration_trainings/courseinstances/read?foreignKeyId=${courseId}`);

        case 'open':
          return interopHost(`administration_trainings/fasttrackinstances/read?foreignKeyId=${courseId}`);

        case 'general':
          return interopHost(`administration_trainings/generalcourseinstances/read?foreignKeyId=${courseId}`);
      }
    })();

    const body = params({
      filter: `Id~eq~${instanceId}`
    });
    const instance = (await post(uri, body)).Data[0];

    if (instance !== undefined) {
      instance.InstanceRefType = type;
    }

    return instance;
  }

  async function getInstanceOverview(instanceIds) {
    if (Array.isArray(instanceIds) == false) {
      instanceIds = [instanceIds];
    }

    const uri = interopHost('administration_trainings/trainings/read');
    const body = params({
      pageSize: 1000,
      filter: `TrainingId~eq~${instanceIds.join('~or~TrainingId~eq~')}`
    });
    return (await post(uri, body)).Data;
  }

  function updateCourse(course) {
    const uri = interopHost('administration_trainings/courses/update');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: course.Id,
      Name: course.Name,
      DescriptionBg: course.DescriptionBg,
      DescriptionEn: course.DescriptionEn,
      UrlName: course.UrlName,
      IconUrl: course.IconUrl,
      Credits: course.Credits,
      IsActive: course.IsActive,
      IsHidden: course.IsHidden,
      OrderBy: course.OrderBy,
      MergedTags: course.MergedTags,
      CourseCategoryId: course.CourseCategoryId,
      CourseDifficultyLevel: course.CourseDifficultyLevel,
      CourseDifficultyLevelDescriptionBg: course.CourseDifficultyLevelDescriptionBg,
      CourseDifficultyLevelDescriptionEn: course.CourseDifficultyLevelDescriptionEn,
      CreatedOn: course.CreatedOn,
      ModifiedOn: course.ModifiedOn || course.CreatedOn
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function updateInstance(instance) {
    const uri = (() => {
      switch (instance.InstanceRefType) {
        case 'main':
          return interopHost(`administration_trainings/courseinstances/update?foreignKeyId=${instance.CourseId}`);

        case 'open':
          return interopHost(`administration_trainings/fasttrackinstances/update?foreignKeyId=${instance.CourseId}`);

        case 'general':
          return interopHost(`administration_trainings/generalcourseinstances/update?foreignKeyId=${instance.CourseId}`);

        default:
          return interopHost(`administration_trainings/fasttrackinstances/update?foreignKeyId=${instance.CourseId}`);
      }
    })();

    const body = Object.assign({}, instance, {
      sort: '',
      group: '',
      filter: '',
      ModifiedOn: instance.ModifiedOn || instance.CreatedOn
    });
    delete body.InstanceRefType;
    delete body.SharesLiveStreamWithTrainings;
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function getStudents(instanceId, type = 'main') {
    const uri = (() => {
      switch (type) {
        case 'main':
          return interopHost(`administration_trainings/usersincourses/read?foreignKeyId=${instanceId}`);

        case 'open':
          return interopHost(`administration_trainings/usersinfasttracks/read?foreignKeyId=${instanceId}`);

        case 'general':
          return interopHost(`administration_trainings/usersingeneralcourseinstances/read?foreignKeyId=${instanceId}`);
      }
    })();

    return await fetchNext();

    async function fetchNext(page = 1) {
      const body = params({
        sort: 'CreatedOn-desc',
        pageSize: 1000,
        page
      });
      const response = await post(uri, body);
      let result = response.Data;

      if (response.Total > page * 1000) {
        result = result.concat(await fetchNext(page + 1));
      }

      return result;
    }
  }

  async function getCourseEvents(instanceId) {
    const data = await Promise.all([getMainById(instanceId), getOpenById(instanceId), getGeneralById(instanceId), eventsApi.getEvents(instanceId)]);

    for (let i = 0; i < 3; i++) {
      if (data[i].Total > 0) {
        const response = {
          Id: data[i].Data[0].Id,
          CourseId: data[i].Data[0].CourseId,
          NameBg: data[i].Data[0].NameBg,
          Events: data[3],
          InstanceRefType: {
            0: 'main',
            1: 'open',
            2: 'general'
          }[i]
        };
        return response;
      }
    }

    throw new Error('Error fetching instance data: All searches returned 0 matches');
  }

  async function getAnyById(instanceId) {
    if (Array.isArray(instanceId) && instanceId.length === 0) {
      return [];
    }

    const result = await Promise.all([getMainById(instanceId), getOpenById(instanceId), getGeneralById(instanceId)]);

    for (let i = 0; i < result.length; i++) {
      const instance = result[i];

      if (instance.Total > 0) {
        const type = {
          0: 'main',
          1: 'open',
          2: 'general'
        }[i];
        instance.Data.forEach(i => i.InstanceRefType = type);
      }
    }

    return result.reduce((p, c) => p.concat(c.Data), []);
  }

  async function getMainById(instanceId) {
    const filter = (() => {
      if (Array.isArray(instanceId)) {
        return `Id~eq~${instanceId.join('~or~Id~eq~')}`;
      } else {
        return `Id~eq~${instanceId}`;
      }
    })();

    const uri = interopHost('administration_trainings/usersincourses/readcourseinstances');
    const body = params({
      pageSize: 10000,
      filter
    });
    return post(uri, body);
  }

  async function getOpenById(instanceId) {
    const filter = (() => {
      if (Array.isArray(instanceId)) {
        return `Id~eq~${instanceId.join('~or~Id~eq~')}`;
      } else {
        return `Id~eq~${instanceId}`;
      }
    })();

    const uri = interopHost('administration_trainings/usersinfasttracks/readfasttrackinstances');
    const body = params({
      pageSize: 10000,
      filter
    });
    return post(uri, body);
  }

  async function getGeneralById(instanceId) {
    const filter = (() => {
      if (Array.isArray(instanceId)) {
        return `Id~eq~${instanceId.join('~or~Id~eq~')}`;
      } else {
        return `Id~eq~${instanceId}`;
      }
    })();

    const uri = interopHost('administration_trainings/usersingeneralcourseinstances/readgeneralcourseinstances');
    const body = params({
      pageSize: 10000,
      filter
    });
    return post(uri, body);
  }

  async function getInstancePage(instanceId) {
    const uri = interopHost(`trainings/trainings/getcoursedetails?id=${instanceId}`);
    return get(uri);
  }

  async function getInstanceFullPage(url) {
    return get(url);
  }

  async function getTrainerNames(instanceId) {
    return (await fetch(interopHost(`kendoremotedata/gettrainersbytraining?trainingId=${instanceId}`), {
      'credentials': 'include',
      'headers': {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:96.0) Gecko/20100101 Firefox/96.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'X-Requested-With': 'XMLHttpRequest',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'no-cors',
        'Sec-Fetch-Site': 'same-origin'
      },
      'method': 'GET',
      'mode': 'cors'
    })).json();
  }

  return { ...eventsApi,
    ...lecturesApi,
    ...skillsApi,
    ...groupsApi,
    ...examsApi,
    ...assessmentApi,
    ...seminarsApi,
    searchByName,
    searchCourses,
    getCourseData,
    getCourseInstances,
    getInstanceData,
    getInstanceOverview,
    updateCourse,
    updateInstance,
    getStudents,
    getCourseEvents,
    getAnyById,
    getInstancePage,
    getInstanceFullPage,
    getTrainerNames,
    searchCourseInstancesByCourseNameAndInstanceId,
    searchTrainingsByName
  };
}

/***/ }),

/***/ "./src/api/users.js":
/*!**************************!*\
  !*** ./src/api/users.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getTrainingsByTrainer(userId) {
    const uri = (() => {
      if (interopAppId() === 'softuni.bg') {
        return interopHost(`administration_users/trainersintrainings/readtrainingsoftrainer?trainerId=${userId}`);
      } else {
        return interopHost(`Administration_Users/TrainersInTrainings/Read?foreignKey=${userId}&foreignKeyId=${userId}`);
      }
    })();

    const body = params({
      pageSize: 100,
      sort: 'ModifiedOn-desc'
    });
    const result = await post(uri, body);
    result.Data.forEach(t => {
      t.DescriptionBg = t.DescriptionBg || '';
      t.DescriptionEn = t.DescriptionEn || '';
    });
    return result;
  }

  async function getTrainerById(userId) {
    const uri = (() => {
      if (interopAppId() === 'softuni.bg') {
        return interopHost('administration_users/trainersintrainings/read');
      } else {
        return interopHost('Administration_Users/Trainers/Read');
      }
    })();

    const body = params({
      pageSize: 100,
      filter: `UserId~eq~'${userId}'`
    });
    return post(uri, body);
  }

  async function updateTrainingByTrainer(training) {
    const uri = (() => {
      if (interopAppId() === 'softuni.bg') {
        return interopHost('administration_users/trainersintrainings/UpdateTrainerInTraining');
      } else {
        return interopHost('Administration_Users/TrainersInTrainings/Update');
      }
    })();

    const body = params({
      TrainingId: training.TrainingId,
      TrainingName: training.TrainingName,
      TrainerFirstName: training.TrainerFirstName,
      TrainerLastName: training.TrainerLastName,
      TrainerId: training.TrainerId,
      TrainerOrderBy: training.TrainerOrderBy,
      IsPublicTrainer: training.IsPublicTrainer,
      DescriptionBg: training.DescriptionBg,
      DescriptionEn: training.DescriptionEn,
      TrainerPhotoPath: training.TrainerPhotoPath,
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:01.317'
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null || body[k] === undefined) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function createTrainingByTrainer(training) {
    const uri = interopAppId() === 'softuni.bg' ? interopHost(`administration_users/trainersintrainings/AddTrainerToTraining?userId=${training.TrainerId}`) : interopHost(`Administration_Users/TrainersInTrainings/Create?foreignKey=${training.TrainerId}`);
    const body = params({
      TrainingId: training.TrainingId,
      TrainingName: training.TrainingName,
      TrainerFirstName: training.TrainerFirstName,
      TrainerLastName: training.TrainerLastName,
      TrainerId: training.TrainerId,
      TrainerOrderBy: training.TrainerOrderBy,
      IsPublicTrainer: training.IsPublicTrainer,
      DescriptionBg: training.DescriptionBg,
      DescriptionEn: training.DescriptionEn,
      TrainerPhotoPath: training.TrainerPhotoPath,
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:01.317'
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null || body[k] === undefined) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function searchUsers(query, exclude) {
    const result = await Promise.all([searchUsersByName(query, exclude), searchUsersByUserName(query, exclude)]);
    return result[0].concat(result[1]);
  }

  async function destroyTrainingOfTrainer(training) {
    const uri = interopAppId() === 'softuni.bg' ? interopHost('administration_users/trainersintrainings/DeleteTrainerFromTraining') : interopHost('Administration_Users/TrainersInTrainings/Destroy');
    const body = Object.assign(params(), training);
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    Object.keys(body).forEach(k => {
      if (body[k] === null || body[k] === undefined) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function searchUsersByName(name, exclude) {
    const uri = interopHost('administration_users/users/read');
    let filter = name.includes(' ') ? `(FirstNameEn~eq~'${name.split(' ')[0]}'~and~LastNameEn~startswith~'${name.split(' ')[1]}')~or~(FirstNameBg~eq~'${name.split(' ')[0]}'~and~LastNameBg~startswith~'${name.split(' ')[1]}')` : `FirstNameEn~contains~'${name}'~or~LastNameEn~contains~'${name}'~or~FirstNameBg~contains~'${name}'~or~LastNameBg~contains~'${name}'`;

    if (Array.isArray(exclude)) {
      filter = `(${filter})~and~(Id~neq~'${exclude.join('\'~and~Id~neq~\'')}')`;
    }

    const body = params({
      sort: 'UserName-asc',
      pageSize: 5,
      filter
    });
    return (await post(uri, body)).Data;
  }

  async function searchUsersByUserName(name, exclude) {
    if (name.includes(' ')) {
      return [];
    }

    const uri = interopHost('administration_users/users/read');
    let filter = `UserName~contains~'${name}'`;

    if (Array.isArray(exclude)) {
      filter = `(${filter})~and~(Id~neq~'${exclude.join('\'~and~Id~neq~\'')}')`;
    }

    const body = params({
      sort: 'UserName-asc',
      pageSize: 5,
      filter
    });
    return (await post(uri, body)).Data;
  }

  async function getTrainersByTraining(trainingId) {
    const uri = interopHost(`Administration_Trainings/TrainingsWithTrainers/Read?foreignKey=${trainingId}&foreignKeyId=${trainingId}`);
    const body = params({
      pageSize: 10,
      sort: 'OrderBy-asc'
    });
    const result = await post(uri, body);
    result.Data.forEach(t => {
      t.DescriptionBg = t.DescriptionBg || '';
      t.DescriptionEn = t.DescriptionEn || '';
    });
    return result.Data;
  }

  return {
    getTrainingsByTrainer,
    getTrainerById,
    updateTrainingByTrainer,
    createTrainingByTrainer,
    destroyTrainingOfTrainer,
    searchUsers,
    getTrainersByTraining
  };
}

/***/ }),

/***/ "./src/api/util.js":
/*!*************************!*\
  !*** ./src/api/util.js ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "parseCrossBrowserFile": () => (/* binding */ parseCrossBrowserFile)
/* harmony export */ });
async function parseCrossBrowserFile(fileDescriptor) {
  let blob;
  let filename;

  if (fileDescriptor.fileUrl !== undefined) {
    blob = await (await fetch(fileDescriptor.fileUrl)).blob();
    filename = fileDescriptor.name;
  } else {
    blob = fileDescriptor.file;
    filename = fileDescriptor.file.name;
  }

  return {
    blob,
    filename
  };
}

/***/ }),

/***/ "./src/util/api-connect.js":
/*!*********************************!*\
  !*** ./src/util/api-connect.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _parse__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parse */ "./src/util/parse.js");
/* harmony import */ var _api_api_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../api/api-index */ "./src/api/api-index.js");
/* harmony import */ var _node_modules_awesome_notifications_src_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../node_modules/awesome-notifications/src/index.js */ "./node_modules/awesome-notifications/src/index.js");
/// <reference path="./api.d.ts" />



const dispatcher = {};
let bgPort;
startSesApiPort();

function startSesApiPort() {
  bgPort = browser.runtime.connect({
    name: 'ses-api-port'
  });
  bgPort.onMessage.addListener(onMessage);
  bgPort.onDisconnect.addListener(() => {
    startSesApiPort();
  });
}

function getData(type, params) {
  return new Promise((resolve, reject) => {
    const _uuid = (0,_parse__WEBPACK_IMPORTED_MODULE_0__.uuid)();

    bgPort.postMessage({
      _uuid,
      appName: interopAppName(),
      type,
      params
    });
    dispatcher[_uuid] = {
      resolve,
      reject,
      type
    };
  });
}

function onMessage(m) {
  const uuid = m._uuid;

  if (m._rejected) {
    console.info('Operation reject:', dispatcher[uuid].type);
    const error = new Error(m._error);
    let notifier = new _node_modules_awesome_notifications_src_index_js__WEBPACK_IMPORTED_MODULE_2__["default"]();
    notifier.alert(`${m._error}`, {
      durations: {
        alert: 10000
      }
    }); //maybe update to show only in debug mode, providing more detailed error information using the _meta property

    console.dir(error);
    error._meta = m._meta;
    dispatcher[uuid].reject(error);
  } else {
    dispatcher[uuid].resolve(m.data);
  }

  delete dispatcher[uuid];
}

function interopAppName() {
  switch (window.location.host.slice(0, 7)) {
    case 'digital':
      return 'digital';

    case 'creativ':
      return 'creative';

    case 'ai.soft':
      return 'ai';

    case 'finance':
      return 'financeacademy';

    case 'dev.dig':
      return 'devdigital';

    case 'dev.sof':
      return 'devsoftuni';

    default:
      return 'programming';
  }
}
/** @type {SUAPI} */


const actions = (0,_api_api_index__WEBPACK_IMPORTED_MODULE_1__["default"])(null).map(a => ({
  name: a,
  func: (...params) => getData(a, params)
})).reduce((p, c) => {
  p[c.name] = c.func;
  return p;
}, {});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (actions);

/***/ }),

/***/ "./src/util/api.js":
/*!*************************!*\
  !*** ./src/util/api.js ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "addQuizQuestion": () => (/* binding */ addQuizQuestion),
/* harmony export */   "addQuizQuestionAnswer": () => (/* binding */ addQuizQuestionAnswer),
/* harmony export */   "createDocument": () => (/* binding */ createDocument),
/* harmony export */   "createEvent": () => (/* binding */ createEvent),
/* harmony export */   "createExam": () => (/* binding */ createExam),
/* harmony export */   "createExamGroup": () => (/* binding */ createExamGroup),
/* harmony export */   "createLecture": () => (/* binding */ createLecture),
/* harmony export */   "createQuizInstance": () => (/* binding */ createQuizInstance),
/* harmony export */   "createSkill": () => (/* binding */ createSkill),
/* harmony export */   "createStatus": () => (/* binding */ createStatus),
/* harmony export */   "createTrainingByTrainer": () => (/* binding */ createTrainingByTrainer),
/* harmony export */   "createTrainingGroup": () => (/* binding */ createTrainingGroup),
/* harmony export */   "deleteConfig": () => (/* binding */ deleteConfig),
/* harmony export */   "deleteNavetFile": () => (/* binding */ deleteNavetFile),
/* harmony export */   "deleteTemplate": () => (/* binding */ deleteTemplate),
/* harmony export */   "destroyEvent": () => (/* binding */ destroyEvent),
/* harmony export */   "destroyExamGroup": () => (/* binding */ destroyExamGroup),
/* harmony export */   "destroyGroup": () => (/* binding */ destroyGroup),
/* harmony export */   "destroyLecture": () => (/* binding */ destroyLecture),
/* harmony export */   "destroySkill": () => (/* binding */ destroySkill),
/* harmony export */   "destroyStatus": () => (/* binding */ destroyStatus),
/* harmony export */   "destroyTrainingOfTrainer": () => (/* binding */ destroyTrainingOfTrainer),
/* harmony export */   "findSurveyByTraining": () => (/* binding */ findSurveyByTraining),
/* harmony export */   "getAllQuizesByName": () => (/* binding */ getAllQuizesByName),
/* harmony export */   "getAnswersByQuestionId": () => (/* binding */ getAnswersByQuestionId),
/* harmony export */   "getAnyById": () => (/* binding */ getAnyById),
/* harmony export */   "getAppStatus": () => (/* binding */ getAppStatus),
/* harmony export */   "getAppStatusByInstanceId": () => (/* binding */ getAppStatusByInstanceId),
/* harmony export */   "getAppZip": () => (/* binding */ getAppZip),
/* harmony export */   "getApplications": () => (/* binding */ getApplications),
/* harmony export */   "getApplicationsByInstanceId": () => (/* binding */ getApplicationsByInstanceId),
/* harmony export */   "getBlogByUrl": () => (/* binding */ getBlogByUrl),
/* harmony export */   "getConfigByExamId": () => (/* binding */ getConfigByExamId),
/* harmony export */   "getConfigs": () => (/* binding */ getConfigs),
/* harmony export */   "getContestCompeteResults": () => (/* binding */ getContestCompeteResults),
/* harmony export */   "getCourseData": () => (/* binding */ getCourseData),
/* harmony export */   "getCourseEvents": () => (/* binding */ getCourseEvents),
/* harmony export */   "getCourseInstances": () => (/* binding */ getCourseInstances),
/* harmony export */   "getEnrolledByGroupId": () => (/* binding */ getEnrolledByGroupId),
/* harmony export */   "getEvents": () => (/* binding */ getEvents),
/* harmony export */   "getEventsByDate": () => (/* binding */ getEventsByDate),
/* harmony export */   "getEventsById": () => (/* binding */ getEventsById),
/* harmony export */   "getExamGroupsByExamId": () => (/* binding */ getExamGroupsByExamId),
/* harmony export */   "getExamsByCourse": () => (/* binding */ getExamsByCourse),
/* harmony export */   "getExamsByName": () => (/* binding */ getExamsByName),
/* harmony export */   "getExtraCourseInfo": () => (/* binding */ getExtraCourseInfo),
/* harmony export */   "getGraduateInfo": () => (/* binding */ getGraduateInfo),
/* harmony export */   "getGroupById": () => (/* binding */ getGroupById),
/* harmony export */   "getHalls": () => (/* binding */ getHalls),
/* harmony export */   "getHomeworkResults": () => (/* binding */ getHomeworkResults),
/* harmony export */   "getInsanceGroups": () => (/* binding */ getInsanceGroups),
/* harmony export */   "getInstanceConfig": () => (/* binding */ getInstanceConfig),
/* harmony export */   "getInstanceData": () => (/* binding */ getInstanceData),
/* harmony export */   "getInstanceFullPage": () => (/* binding */ getInstanceFullPage),
/* harmony export */   "getInstanceInModule": () => (/* binding */ getInstanceInModule),
/* harmony export */   "getInstanceLectures": () => (/* binding */ getInstanceLectures),
/* harmony export */   "getInstancePage": () => (/* binding */ getInstancePage),
/* harmony export */   "getInstancesInModule": () => (/* binding */ getInstancesInModule),
/* harmony export */   "getLectureDetails": () => (/* binding */ getLectureDetails),
/* harmony export */   "getLecturesForExamsByTrainingId": () => (/* binding */ getLecturesForExamsByTrainingId),
/* harmony export */   "getModules": () => (/* binding */ getModules),
/* harmony export */   "getModulesInProfession": () => (/* binding */ getModulesInProfession),
/* harmony export */   "getNavetArchivedCourses": () => (/* binding */ getNavetArchivedCourses),
/* harmony export */   "getNavetCertificate": () => (/* binding */ getNavetCertificate),
/* harmony export */   "getNavetClosedCourses": () => (/* binding */ getNavetClosedCourses),
/* harmony export */   "getNavetCourseInfo": () => (/* binding */ getNavetCourseInfo),
/* harmony export */   "getNavetCurrentCourses": () => (/* binding */ getNavetCurrentCourses),
/* harmony export */   "getNavetExistingFiles": () => (/* binding */ getNavetExistingFiles),
/* harmony export */   "getNavetStudentInfo": () => (/* binding */ getNavetStudentInfo),
/* harmony export */   "getNavetStudents": () => (/* binding */ getNavetStudents),
/* harmony export */   "getPackagesForProduct": () => (/* binding */ getPackagesForProduct),
/* harmony export */   "getPaymentsForPackage": () => (/* binding */ getPaymentsForPackage),
/* harmony export */   "getProductsForCourse": () => (/* binding */ getProductsForCourse),
/* harmony export */   "getProductsForModule": () => (/* binding */ getProductsForModule),
/* harmony export */   "getProtocol": () => (/* binding */ getProtocol),
/* harmony export */   "getQuestionsById": () => (/* binding */ getQuestionsById),
/* harmony export */   "getSeminarsByDate": () => (/* binding */ getSeminarsByDate),
/* harmony export */   "getSkillsByInstance": () => (/* binding */ getSkillsByInstance),
/* harmony export */   "getStoreSettings": () => (/* binding */ getStoreSettings),
/* harmony export */   "getStudents": () => (/* binding */ getStudents),
/* harmony export */   "getSurveyAnswers": () => (/* binding */ getSurveyAnswers),
/* harmony export */   "getSurveyById": () => (/* binding */ getSurveyById),
/* harmony export */   "getSurveyQuestionsByTemplateId": () => (/* binding */ getSurveyQuestionsByTemplateId),
/* harmony export */   "getSurveySectionsById": () => (/* binding */ getSurveySectionsById),
/* harmony export */   "getSurveySectionsByTemplateId": () => (/* binding */ getSurveySectionsByTemplateId),
/* harmony export */   "getSurveyTemplates": () => (/* binding */ getSurveyTemplates),
/* harmony export */   "getSurveys": () => (/* binding */ getSurveys),
/* harmony export */   "getSurveysByNameAndStartAndEndDate": () => (/* binding */ getSurveysByNameAndStartAndEndDate),
/* harmony export */   "getTemplateByInstanceId": () => (/* binding */ getTemplateByInstanceId),
/* harmony export */   "getTemplateByName": () => (/* binding */ getTemplateByName),
/* harmony export */   "getTemplateStoreSettings": () => (/* binding */ getTemplateStoreSettings),
/* harmony export */   "getTemplates": () => (/* binding */ getTemplates),
/* harmony export */   "getTrainerById": () => (/* binding */ getTrainerById),
/* harmony export */   "getTrainerNames": () => (/* binding */ getTrainerNames),
/* harmony export */   "getTrainersByTraining": () => (/* binding */ getTrainersByTraining),
/* harmony export */   "getTrainingsByTrainer": () => (/* binding */ getTrainingsByTrainer),
/* harmony export */   "openNavetCertificate": () => (/* binding */ openNavetCertificate),
/* harmony export */   "openNavetFile": () => (/* binding */ openNavetFile),
/* harmony export */   "saveConfig": () => (/* binding */ saveConfig),
/* harmony export */   "saveTemplate": () => (/* binding */ saveTemplate),
/* harmony export */   "searchByName": () => (/* binding */ searchByName),
/* harmony export */   "searchCourseInstancesByCourseNameAndInstanceId": () => (/* binding */ searchCourseInstancesByCourseNameAndInstanceId),
/* harmony export */   "searchCourses": () => (/* binding */ searchCourses),
/* harmony export */   "searchModules": () => (/* binding */ searchModules),
/* harmony export */   "searchSkills": () => (/* binding */ searchSkills),
/* harmony export */   "searchTrainingsByName": () => (/* binding */ searchTrainingsByName),
/* harmony export */   "searchUsers": () => (/* binding */ searchUsers),
/* harmony export */   "updateCourse": () => (/* binding */ updateCourse),
/* harmony export */   "updateEvent": () => (/* binding */ updateEvent),
/* harmony export */   "updateExam": () => (/* binding */ updateExam),
/* harmony export */   "updateExamGroup": () => (/* binding */ updateExamGroup),
/* harmony export */   "updateHall": () => (/* binding */ updateHall),
/* harmony export */   "updateInstance": () => (/* binding */ updateInstance),
/* harmony export */   "updateLecture": () => (/* binding */ updateLecture),
/* harmony export */   "updateNavetStudent": () => (/* binding */ updateNavetStudent),
/* harmony export */   "updateSkill": () => (/* binding */ updateSkill),
/* harmony export */   "updateStatus": () => (/* binding */ updateStatus),
/* harmony export */   "updateTrainingByTrainer": () => (/* binding */ updateTrainingByTrainer),
/* harmony export */   "uploadDiploma": () => (/* binding */ uploadDiploma),
/* harmony export */   "uploadExamResults": () => (/* binding */ uploadExamResults),
/* harmony export */   "uploadMedical": () => (/* binding */ uploadMedical),
/* harmony export */   "uploadNavetCertificate": () => (/* binding */ uploadNavetCertificate)
/* harmony export */ });
/* harmony import */ var _api_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./api-connect */ "./src/util/api-connect.js");
 // ########################################################################################################################
// ### Common Data
// ########################################################################################################################

async function getBlogByUrl(blogUrl) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getBlogByUrl(blogUrl);
}
async function getHalls() {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getHalls();
}
async function updateHall(hall) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateHall(hall);
} // ########################################################################################################################
// ### Module Data
// ########################################################################################################################

async function getModulesInProfession(professionId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getModulesInProfession(professionId);
}
async function getModules() {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getModules();
}
async function getInstancesInModule(moduleId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInstancesInModule(moduleId);
}
async function searchModules(query) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].searchModules(query);
}
async function getInstanceInModule(moduleId, moduleInstanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInstanceInModule(moduleId, moduleInstanceId);
} // ########################################################################################################################
// ### Payments Data
// ########################################################################################################################

async function getPaymentsForPackage(packageName) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getPaymentsForPackage(packageName);
}
async function getPackagesForProduct(productId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getPackagesForProduct(productId);
}
async function getProductsForModule(moduleId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getProductsForModule(moduleId);
}
async function getProductsForCourse(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getProductsForCourse(instanceId);
} // ########################################################################################################################
// ### Payments Data
// ########################################################################################################################

async function getContestCompeteResults(contestId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getContestCompeteResults(contestId);
} // ########################################################################################################################
// ### Quiz Data
// ########################################################################################################################

async function createQuizInstance(payload) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createQuizInstance(payload);
}
async function addQuizQuestion(quizId, content) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].addQuestion(quizId, content);
}
async function addQuizQuestionAnswer(questionId, answer, isCorrect) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].addAnswer(questionId, answer, isCorrect);
}
async function getAllQuizesByName(containingName, pageSize, page) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getAllQuizesByName(containingName, pageSize, page);
}
async function getQuestionsById(quizId, pageSize, page) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getQuestionsById(quizId, pageSize, page);
}
async function getAnswersByQuestionId(questionId, pageSize, page) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getAnswersByQuestionId(questionId, pageSize, page);
} // ########################################################################################################################
// ### Survey Data
// ########################################################################################################################

async function getSurveys(page, query, pageSize) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveys(page, query, pageSize);
}
async function getSurveysByNameAndStartAndEndDate(page, name, startDate, endDate, pageSize) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveysByNameAndStartAndEndDate(page, name, startDate, endDate, pageSize);
}
async function getSurveyById(surveyId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveyById(surveyId);
}
async function getSurveyAnswers(surveyId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveyAnswers(surveyId);
}
async function getSurveyTemplates() {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveyTemplates();
}
async function getSurveyQuestionsByTemplateId(templateId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveyQuestionsByTemplateId(templateId);
}
async function getSurveySectionsByTemplateId(templateId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveySectionsByTemplateId(templateId);
}
async function getSurveySectionsById(sectionId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveySectionsById(sectionId);
}
async function findSurveyByTraining(nameBg) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].findSurveyByTraining(nameBg);
} // ########################################################################################################################
// ### User Data
// ########################################################################################################################

async function getTrainingsByTrainer(userId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTrainingsByTrainer(userId);
}
async function getTrainerById(userId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTrainerById(userId);
}
async function updateTrainingByTrainer(training) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateTrainingByTrainer(training);
}
async function createTrainingByTrainer(training) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createTrainingByTrainer(training);
}
async function destroyTrainingOfTrainer(training) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].destroyTrainingOfTrainer(training);
}
async function searchUsers(query, exclude) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].searchUsers(query, exclude);
}
async function getTrainersByTraining(trainingId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTrainersByTraining(trainingId);
} // ########################################################################################################################
// ### Course Data
// ########################################################################################################################

async function searchByName(body) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].searchByName(body);
}
async function searchCourses(query) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].searchCourses(query);
}
async function getCourseData(courseId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getCourseData(courseId);
}
async function getCourseInstances(courseId, filter = undefined) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getCourseInstances(courseId, filter = undefined);
}
async function getInstanceData(instanceId, courseId, type) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInstanceData(instanceId, courseId, type);
}
async function updateCourse(course) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateCourse(course);
}
async function updateInstance(instance) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateInstance(instance);
}
async function getStudents(instanceId, type = 'main') {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getStudents(instanceId, type);
}
async function getCourseEvents(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getCourseEvents(instanceId);
}
async function getAnyById(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getAnyById(instanceId);
}
async function getInstancePage(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInstancePage(instanceId);
}
async function getInstanceFullPage(url) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInstanceFullPage(url);
}
async function getTrainerNames(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTrainerNames(instanceId);
}
async function searchCourseInstancesByCourseNameAndInstanceId(courseName, instanceId, filter = undefined) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].searchCourseInstancesByCourseNameAndInstanceId(courseName, instanceId, filter = undefined);
}
async function searchTrainingsByName(name, exact = false) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].searchTrainingsByName(name, exact);
} // ########################################################################################################################
// ### Exam Data
// ########################################################################################################################

async function getExamsByCourse(nameBg, instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getExamsByCourse(nameBg, instanceId);
}
async function getExamsByName(query) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getExamsByName(query);
}
async function getExamGroupsByExamId(examId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getExamGroupsByExamId(examId);
}
async function getEnrolledByGroupId(examGroupId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getEnrolledByGroupId(examGroupId);
}
async function createExam(exam) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createExam(exam);
}
async function updateExam(exam) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateExam(exam);
}
async function createExamGroup(group) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createExamGroup(group);
}
async function updateExamGroup(group) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateExamGroup(group);
}
async function destroyExamGroup(group) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].destroyExamGroup(group);
} // ########################################################################################################################
// ### Event Data
// ########################################################################################################################

async function getEvents(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getEvents(instanceId);
}
async function updateEvent(event) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateEvent(event);
}
async function createEvent(event) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createEvent(event);
}
async function destroyEvent(event) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].destroyEvent(event);
}
async function getEventsByDate(startDate, endDate) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getEventsByDate(startDate, endDate);
}
async function getEventsById(eventId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getEventsById(eventId);
} // ########################################################################################################################
// ### Group Data
// ########################################################################################################################

async function getInsanceGroups(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInsanceGroups(instanceId);
}
async function getGroupById(groupId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getGroupById(groupId);
}
async function createTrainingGroup(group) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createTrainingGroup(group);
}
async function destroyGroup(group) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].destroyGroup(group);
} // ########################################################################################################################
// ### Lecture Data
// ########################################################################################################################

async function getInstanceLectures(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInstanceLectures(instanceId);
}
async function updateLecture(lecture) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateLecture(lecture);
}
async function createLecture(lecture) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createLecture(lecture);
}
async function destroyLecture(lecture) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].destroyLecture(lecture);
}
async function getLectureDetails(trainingId, lectureId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getLectureDetails(trainingId, lectureId);
}
async function getLecturesForExamsByTrainingId(trainingId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getLecturesForExamsByTrainingId(trainingId);
} // ########################################################################################################################
// ### Skill Data
// ########################################################################################################################

async function getSkillsByInstance(name, instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSkillsByInstance(name, instanceId);
}
async function updateSkill(skill) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateSkill(skill);
}
async function createSkill(skill) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createSkill(skill);
}
async function destroySkill(skill) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].destroySkill(skill);
}
async function searchSkills(query, type) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].searchSkills(query, type);
} // ########################################################################################################################
// ### Stream Data
// ########################################################################################################################

async function getInstanceConfig(instanceId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInstanceConfig(instanceId);
} // ########################################################################################################################
// ### CPE Data
// ########################################################################################################################

async function getApplicationsByInstanceId(instanceId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getApplicationsByInstanceId(instanceId);
}
async function getApplications(query, page) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getApplications(query, page);
}
async function getAppZip(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getAppZip(id);
}
async function getAppStatus(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getAppStatus(id);
}
async function getAppStatusByInstanceId(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getAppStatusByInstanceId(id);
}
async function createStatus(status) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createStatus(status);
}
async function updateStatus(status) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateStatus(status);
}
async function destroyStatus(status) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].destroyStatus(status);
} // ########################################################################################################################
// ### NAVET Data
// ########################################################################################################################

async function getNavetCurrentCourses() {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetCurrentCourses();
}
async function getNavetClosedCourses() {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetClosedCourses();
}
async function getNavetArchivedCourses() {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetArchivedCourses();
}
async function getNavetCourseInfo(id, type) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetCourseInfo(id, type);
}
async function getNavetStudents(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetStudents(id);
}
async function getNavetStudentInfo(clientId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetStudentInfo(clientId);
}
async function getNavetExistingFiles(courseId, id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetExistingFiles(courseId, id);
}
async function uploadMedical(courseId, id, fileDescriptor) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].uploadMedical(courseId, id, fileDescriptor);
}
async function uploadDiploma(courseId, id, fileDescriptor, reg_no, prn_no, doc_date) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].uploadDiploma(courseId, id, fileDescriptor, reg_no, prn_no, doc_date);
}
async function openNavetFile(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].openNavetFile(id);
}
async function deleteNavetFile(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].deleteNavetFile(id);
}
async function getGraduateInfo(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getGraduateInfo(id);
}
async function getNavetCertificate(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetCertificate(id);
}
async function openNavetCertificate(id, page) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].openNavetCertificate(id, page);
}
async function uploadNavetCertificate(meta, fileDescriptors) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].uploadNavetCertificate(meta, fileDescriptors);
}
async function updateNavetStudent(id, student) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateNavetStudent(id, student);
}
async function createDocument(studentId, clientId, data) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createDocument(studentId, clientId, data);
}
async function getExtraCourseInfo(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getExtraCourseInfo(id);
} // ########################################################################################################################
// ### Generic Data Store
// ########################################################################################################################

async function getStoreSettings(storeId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getStoreSettings(storeId);
} // ########################################################################################################################
// ### Templates Data
// ########################################################################################################################

async function getTemplateStoreSettings() {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTemplateStoreSettings();
}
async function getTemplates() {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTemplates();
}
async function getTemplateByName(name) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTemplateByName(name);
}
async function getTemplateByInstanceId(instanceId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTemplateByInstanceId(instanceId);
}
async function saveTemplate(template) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].saveTemplate(template);
}
async function deleteTemplate(template) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].deleteTemplate(template);
} // ########################################################################################################################
// ### Assessment Data
// ########################################################################################################################

async function getHomeworkResults(instanceId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getHomeworkResults(instanceId);
}
async function getProtocol(instanceId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getProtocol(instanceId);
}
async function uploadExamResults(examName, examId, combo, fileDescriptor) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].uploadExamResults(examName, examId, combo, fileDescriptor);
}
async function getConfigs(examIds) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getConfigs(examIds);
}
async function getConfigByExamId(examId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getConfigByExamId(examId);
}
async function saveConfig(config) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].saveConfig(config);
}
async function deleteConfig(config) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].deleteConfig(config);
} // ########################################################################################################################
// ### Seminar Data
// ########################################################################################################################

async function getSeminarsByDate(startDate, endDate) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSeminarsByDate(startDate, endDate);
}

/***/ }),

/***/ "./src/util/contentTypes.js":
/*!**********************************!*\
  !*** ./src/util/contentTypes.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ContentType": () => (/* binding */ ContentType)
/* harmony export */ });
class ContentType {
  // Private Fields
  static #_UrlFormEncoded = 'application/x-www-form-urlencoded; charset=UTF-8';
  static #_ApplictionJson = 'application/json'; // Accessors for "get" functions only (no "set" functions)

  static get UrlFormEncoded() {
    return this.#_UrlFormEncoded;
  }

  static get ApplicationJson() {
    return this.#_ApplictionJson;
  }

}

/***/ }),

/***/ "./src/util/jsx-render-mod/dom.js":
/*!****************************************!*\
  !*** ./src/util/jsx-render-mod/dom.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Fragment": () => (/* binding */ Fragment),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "portalCreator": () => (/* binding */ portalCreator)
/* harmony export */ });
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils */ "./src/util/jsx-render-mod/utils.js");

/**
 * The tag name and create an html together with the attributes
 *
 * @param  {String} tagName name as string, e.g. 'div', 'span', 'svg'
 * @param  {Object} attrs html attributes e.g. data-, width, src
 * @param  {Array} children html nodes from inside de elements
 * @return {HTMLElement|SVGElement} html node with attrs
 */

function createElements(tagName, attrs, children) {
  const element = (0,_utils__WEBPACK_IMPORTED_MODULE_0__.isSVG)(tagName) ? document.createElementNS('http://www.w3.org/2000/svg', tagName) : document.createElement(tagName); // one or multiple will be evaluated to append as string or HTMLElement

  const fragment = (0,_utils__WEBPACK_IMPORTED_MODULE_0__.createFragmentFrom)(children);
  element.appendChild(fragment);
  Object.keys(attrs || {}).forEach(prop => {
    if (prop === 'style') {
      // e.g. origin: <element style={{ prop: value }} />
      Object.assign(element.style, attrs[prop]);
    } else if (prop === 'ref' && typeof attrs.ref === 'function') {
      attrs.ref(element, attrs);
    } else if (prop === 'className') {
      element.setAttribute('class', attrs[prop]);
    } else if (prop === 'xlinkHref') {
      element.setAttributeNS('http://www.w3.org/1999/xlink', 'xlink:href', attrs[prop]);
    } else if (prop === 'dangerouslySetInnerHTML') {
      // eslint-disable-next-line no-underscore-dangle
      element.innerHTML = attrs[prop].__html;
    } else if (prop in _utils__WEBPACK_IMPORTED_MODULE_0__.EVENT_LISTENERS) {
      element.addEventListener(_utils__WEBPACK_IMPORTED_MODULE_0__.EVENT_LISTENERS[prop], attrs[prop]);
    } else {
      // any other prop will be set as attribute
      element.setAttribute(prop, attrs[prop]);
    }
  });
  return element;
}
/**
 * The JSXTag will be unwrapped returning the html
 *
 * @param  {Function} JSXTag name as string, e.g. 'div', 'span', 'svg'
 * @param  {Object} elementProps custom jsx attributes e.g. fn, strings
 * @param  {Array} children html nodes from inside de elements
 *
 * @return {Function} returns de 'dom' (fn) executed, leaving the HTMLElement
 *
 * JSXTag:  function Comp(props) {
 *   return dom("span", null, props.num);
 * }
 */


function composeToFunction(JSXTag, elementProps, children) {
  const props = Object.assign({}, JSXTag.defaultProps || {}, elementProps, {
    children
  });
  const bridge = JSXTag.prototype && JSXTag.prototype.render ? new JSXTag(props).render : JSXTag;
  const result = bridge(props);

  switch (result) {
    case 'FRAGMENT':
      return (0,_utils__WEBPACK_IMPORTED_MODULE_0__.createFragmentFrom)(children);
    // Portals are useful to render modals
    // allow render on a different element than the parent of the chain
    // and leave a comment instead

    case 'PORTAL':
      bridge.target.appendChild((0,_utils__WEBPACK_IMPORTED_MODULE_0__.createFragmentFrom)(children));
      return document.createComment('Portal Used');

    default:
      return result;
  }
}

function dom(element, attrs, ...children) {
  // Custom Components will be functions
  if (typeof element === 'function') {
    if (element.hasOwnProperty('propTypes')) {
      for (let prop of element.propTypes) {
        if (attrs.hasOwnProperty(prop) === false) {
          console.error(`JSX Error: Missing property '${prop}' from '${element.name}' invocation`);
        }
      }
    } // e.g. const CustomTag = ({ w }) => <span width={w} />
    // will be used
    // e.g. <CustomTag w={1} />
    // becomes: CustomTag({ w: 1})


    return composeToFunction(element, attrs, children);
  } // regular html components will be strings to create the elements
  // this is handled by the babel plugins


  if (typeof element === 'string') {
    return createElements(element, attrs, children);
  }

  return console.error(`jsx-render does not handle ${typeof tag}`);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (dom);
const Fragment = () => 'FRAGMENT';
const portalCreator = node => {
  function Portal() {
    return 'PORTAL';
  }

  Portal.target = document.body;

  if (node && node.nodeType === Node.ELEMENT_NODE) {
    Portal.target = node;
  }

  return Portal;
};

/***/ }),

/***/ "./src/util/jsx-render-mod/utils.js":
/*!******************************************!*\
  !*** ./src/util/jsx-render-mod/utils.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EVENT_LISTENERS": () => (/* binding */ EVENT_LISTENERS),
/* harmony export */   "createFragmentFrom": () => (/* binding */ createFragmentFrom),
/* harmony export */   "isSVG": () => (/* binding */ isSVG)
/* harmony export */ });
function isSVG(element) {
  const patt = new RegExp(`^${element}$`, 'i');
  const SVGTags = ['path', 'svg', 'use', 'g'];
  return SVGTags.some(tag => patt.test(tag));
}
function createFragmentFrom(children) {
  // fragments will help later to append multiple children to the initial node
  const fragment = document.createDocumentFragment();

  function processDOMNodes(child) {
    if (child instanceof HTMLElement || child instanceof SVGElement || child instanceof Comment || child instanceof DocumentFragment) {
      fragment.appendChild(child);
    } else if (typeof child === 'string' || typeof child === 'number') {
      const textnode = document.createTextNode(child);
      fragment.appendChild(textnode);
    } else if (child instanceof Array) {
      child.forEach(processDOMNodes);
    } else if (child === false || child === null) {// expression evaluated as false e.g. {false && <Elem />}
      // expression evaluated as false e.g. {null && <Elem />}
    } else if (typeof child === 'function') {} else if (true) {
      // later other things could not be HTMLElement nor strings
      console.log(child, 'is not appendable');
    }
  }

  children.forEach(processDOMNodes);
  return fragment;
} // Map from JSX property (e.g. onClick) to event name (e.g. 'click').

const EVENT_LISTENERS = {
  // Clipboard Events
  onCopy: 'copy',
  onCut: 'cut',
  onPaste: 'paste',
  // Composition Events
  onCompositionEnd: 'compositionend',
  onCompositionStart: 'compositionstart',
  onCompositionUpdate: 'compositionupdate',
  // Focus Events
  onFocus: 'focus',
  onBlur: 'blur',
  // Form Events
  onChange: 'change',
  onBeforeInput: 'beforeinput',
  onInput: 'input',
  onReset: 'reset',
  onSubmit: 'submit',
  onInvalid: 'invalid',
  // Image Events
  onLoad: 'load',
  onError: 'error',
  // Keyboard Events
  onKeyDown: 'keydown',
  onKeyPress: 'keypress',
  onKeyUp: 'keyup',
  // Media Events
  onAbort: 'abort',
  onCanPlay: 'canplay',
  onCanPlayThrough: 'canplaythrough',
  onDurationChange: 'durationchange',
  onEmptied: 'emptied',
  onEncrypted: 'encrypted',
  onEnded: 'ended',
  onLoadedData: 'loadeddata',
  onLoadedMetadata: 'loadedmetadata',
  onLoadStart: 'loadstart',
  onPause: 'pause',
  onPlay: 'play',
  onPlaying: 'playing',
  onProgress: 'progress',
  onRateChange: 'ratechange',
  onSeeked: 'seeked',
  onSeeking: 'seeking',
  onStalled: 'stalled',
  onSuspend: 'suspend',
  onTimeUpdate: 'timeupdate',
  onVolumeChange: 'volumechange',
  onWaiting: 'waiting',
  // MouseEvents
  onClick: 'click',
  onContextMenu: 'contextmenu',
  onDoubleClick: 'doubleclick',
  onDrag: 'drag',
  onDragEnd: 'dragend',
  onDragEnter: 'dragenter',
  onDragExit: 'dragexit',
  onDragLeave: 'dragleave',
  onDragOver: 'dragover',
  onDragStart: 'dragstart',
  onDrop: 'drop',
  onMouseDown: 'mousedown',
  onMouseEnter: 'mouseenter',
  onMouseLeave: 'mouseleave',
  onMouseMove: 'mousemove',
  onMouseOut: 'mouseout',
  onMouseOver: 'mouseover',
  onMouseUp: 'mouseup',
  // Selection Events
  onSelect: 'select',
  // Touch Events
  onTouchCancel: 'touchcancel',
  onTouchEnd: 'touchend',
  onTouchMove: 'touchmove',
  onTouchStart: 'touchstart',
  // Pointer Events
  onPointerDown: 'pointerdown',
  onPointerMove: 'pointermove',
  onPointerUp: 'pointerup',
  onPointerCancel: 'pointercancel',
  onPointerEnter: 'pointerenter',
  onPointerLeave: 'pointerleave',
  onPointerOver: 'pointerover',
  onPointerOut: 'pointerout',
  // UI Events
  onScroll: 'scroll',
  // Wheel Events
  onWheel: 'wheel',
  // Animation Events
  onAnimationStart: 'animationstart',
  onAnimationEnd: 'animationend',
  onAnimationIteration: 'animationiteration',
  // Transition Events
  onTransitionEnd: 'transitionend'
};

/***/ }),

/***/ "./src/util/parse.js":
/*!***************************!*\
  !*** ./src/util/parse.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dateDiff": () => (/* binding */ dateDiff),
/* harmony export */   "dateDiffToDays": () => (/* binding */ dateDiffToDays),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "formatDate": () => (/* binding */ formatDate),
/* harmony export */   "formatLocaleDate": () => (/* binding */ formatLocaleDate),
/* harmony export */   "formatLocaleWeekday": () => (/* binding */ formatLocaleWeekday),
/* harmony export */   "formatTime": () => (/* binding */ formatTime),
/* harmony export */   "getDateIndex": () => (/* binding */ getDateIndex),
/* harmony export */   "getMonday": () => (/* binding */ getMonday),
/* harmony export */   "getOffsetByDays": () => (/* binding */ getOffsetByDays),
/* harmony export */   "getSunday": () => (/* binding */ getSunday),
/* harmony export */   "hasValue": () => (/* binding */ hasValue),
/* harmony export */   "htmlToText": () => (/* binding */ htmlToText),
/* harmony export */   "instanceMetaFromHref": () => (/* binding */ instanceMetaFromHref),
/* harmony export */   "isLastDay": () => (/* binding */ isLastDay),
/* harmony export */   "isLastWeek": () => (/* binding */ isLastWeek),
/* harmony export */   "localeMonthName": () => (/* binding */ localeMonthName),
/* harmony export */   "monthName": () => (/* binding */ monthName),
/* harmony export */   "normalizeDateTime": () => (/* binding */ normalizeDateTime),
/* harmony export */   "offsetByDays": () => (/* binding */ offsetByDays),
/* harmony export */   "paymentsToMatrix": () => (/* binding */ paymentsToMatrix),
/* harmony export */   "prettyJSON": () => (/* binding */ prettyJSON),
/* harmony export */   "queryString": () => (/* binding */ queryString),
/* harmony export */   "sumArrayMax": () => (/* binding */ sumArrayMax),
/* harmony export */   "toAssocArray": () => (/* binding */ toAssocArray),
/* harmony export */   "toCustomAssocArray": () => (/* binding */ toCustomAssocArray),
/* harmony export */   "uuid": () => (/* binding */ uuid),
/* harmony export */   "valueOrEmpty": () => (/* binding */ valueOrEmpty)
/* harmony export */ });
function queryString(query) {
  if (!query) {
    return null;
  }

  return query.split('?')[1].split('&').map(a => a.split('=')).reduce((a, c) => {
    a[c[0]] = c[1];
    return a;
  }, {});
}
/**
 * Calculate number of days passing between two dates
 * @param {Date} a Starting date
 * @param {Date} b Ending date
 * @returns {number} Number of days
 */


function dateDiff(a, b) {
  if (a.getFullYear() == b.getFullYear() && a.getMonth() == b.getMonth() && a.getDate() == b.getDate()) {
    return 0;
  } else {
    return b - a > 0 ? Math.ceil((b - a) / 86400000) : Math.floor((b - a) / 86400000);
  }
}

function dateDiffToDays(days) {
  if (days == 0) {
    return 'Today';
  } else {
    if (days <= 0) {
      return `In ${-days} day${days == -1 ? '' : 's'}`;
    } else {
      return `${days} day${days == 1 ? '' : 's'} ago`;
    }
  }
}
/**
 * Is the date in the last day of a month
 * @param {Date} date
 * @returns {boolean}
 */


function isLastDay(date) {
  const nextDay = new Date(date);
  nextDay.setDate(nextDay.getDate() + 1);
  return date.getMonth() != nextDay.getMonth();
}
/**
 * Is the date in the last week of a month
 * @param {Date} date
 * @returns {boolean}
 */


function isLastWeek(date) {
  const nextWeek = new Date(date);
  nextWeek.setDate(nextWeek.getDate() + 7);
  return date.getMonth() != nextWeek.getMonth();
}

function formatDate(date) {
  const asString = date.toLocaleDateString('en-US', {
    month: 'short',
    year: 'numeric'
  });
  return `${date.getDate()} ${asString}`;
}

function formatTime(date) {
  return date.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: 'numeric',
    // hour12: false,
    hourCycle: 'h23'
  });
}

function formatLocaleDate(date) {
  const day = date.getDate();
  const month = ['януари', 'февруари', 'март', 'април', 'май', 'юни', 'юли', 'август', 'септември', 'октомври', 'ноември', 'декември'][date.getMonth()];
  return `${day} ${month}`;
}

function formatLocaleWeekday(day, getAdj) {
  const weekday = ['неделя', 'понеделник', 'вторник', 'сряда', 'четвъртък', 'петък', 'събота'][day];

  if (getAdj) {
    return [weekday, ['всяка', 'всеки', 'всеки', 'всяка', 'всеки', 'всеки', 'всяка'][day]];
  }

  return weekday;
}
/**
 * Get a new date offset by the specified number of days
 * @param {Date} date Base date
 * @param {number} days How many days to offset
 * @returns {Date}
 */


function getOffsetByDays(date, days) {
  const result = new Date(date);
  result.setUTCDate(result.getUTCDate() + days);
  return result;
}
/**
 * Offset the given date in place by the specified number of days
 * @param {Date} date Base date
 * @param {number} days How many days to offset
 */

function offsetByDays(date, days) {
  date.setUTCDate(date.getUTCDate() + days);
}
/**
 * Create date index as string
 * @param {Date|string} date Base date
 * @returns {string}
 */

function getDateIndex(date) {
  if (typeof date == 'string') {
    date = new Date(date);
  }

  return date.toISOString().slice(0, 10);
}

function prettyJSON(obj) {
  return JSON.stringify(obj, null, 2).replace(/ /gmi, '&nbsp;').replace(/\n/gmi, '<br>');
}

function getMonday(date) {
  const monday = new Date(`${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()} 12:00:00`);
  monday.setDate(monday.getDate() - (monday.getDay() + 6) % 7);
  return monday;
}

function getSunday(date) {
  const sunday = new Date(`${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()} 23:59:59`);
  sunday.setDate(sunday.getDate() + (7 - sunday.getDay()) % 7);
  return sunday;
}

const monthName = {
  1: 'January',
  2: 'February',
  3: 'March',
  4: 'April',
  5: 'May',
  6: 'June',
  7: 'July',
  8: 'August',
  9: 'September',
  10: 'October',
  11: 'November',
  12: 'December'
};
const localeMonthName = {
  1: 'януари',
  2: 'февруари',
  3: 'март',
  4: 'април',
  5: 'май',
  6: 'юни',
  7: 'юли',
  8: 'август',
  9: 'септември',
  10: 'октомври',
  11: 'ноември',
  12: 'декември'
};

function toAssocArray(p, c, i, a) {
  p[c.Id] = c;
  return p;
}

function toCustomAssocArray(indexName, overwrite = false) {
  return (p, c, i, a) => {
    if (p[c[indexName]] !== undefined && overwrite == false) {
      if (Array.isArray(p[c[indexName]])) {
        p[c[indexName]].push(c);
      } else {
        p[c[indexName]] = [p[c[indexName]], c];
      }
    } else {
      p[c[indexName]] = c;
    }

    return p;
  };
}
/**
 * @param {Array<SUPayment>} data 
 * @returns {Array<PaymentViewModel>}
 */

function paymentsToMatrix(data) {
  const template = ['Id', 'PaymentNumber', 'ModuleNameEn', 'PaymentPackagesAsString', 'PaidForUserName', 'Price', 'EducationalForm', 'PaymentDateTime'];
  const parsed = data.map(e => {
    e.EducationalForm = e.EducationalForm == 1 ? 'online' : 'onsite';
    const entry = [];

    for (let prop of template) {
      if (prop === 'PaymentDateTime') {
        entry.push(new Date(e[prop]));
      } else {
        entry.push(e[prop]);
      }
    }

    return entry;
  });
  return [template, ...parsed];
}

function uuid() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    let r = Math.random() * 16 | 0,
        v = c == 'x' ? r : r & 0x3 | 0x8;
    return v.toString(16);
  });
}
function normalizeDateTime(datetime) {
  if (!datetime) {
    return '';
  } else if (datetime.toString().includes('Date(')) {
    const match = /Date\((.+)\)/.exec(datetime);

    if (match !== null) {
      const d = new Date(Number(match[1]));
      return `${('0000' + d.getFullYear()).slice(-4)}-${pt(d.getMonth() + 1)}-${pt(d.getDate())}T${pt(d.getHours())}:${pt(d.getMinutes())}`;
    } else {
      return datetime;
    }
  } else {
    return datetime;
  }
}

function pt(s) {
  return `0${s}`.slice(-2);
}

function htmlToText(html) {
  const div = document.createElement('div');
  div.innerHTML = html;
  return div.textContent;
}

function instanceMetaFromHref(href) {
  const instanceMeta = queryString(href);

  instanceMeta.InstanceRefType = (() => {
    switch (instanceMeta.type) {
      case 'course':
        return 'main';

      case 'fast-track':
        return 'open';

      case 'general-course-instance':
        return 'general';
    }
  })();

  return instanceMeta;
}
function hasValue(value) {
  return value !== null && value !== undefined && value !== '';
}
function valueOrEmpty(value, alt = '') {
  if (value === null || value === undefined || value === '') {
    return alt;
  } else {
    return value;
  }
}
function sumArrayMax(arr) {
  if (arr[0].length == 0 && arr[1].length == 0) {
    return null;
  }

  let result = 0;

  if (arr[0].length > 0) {
    result += Math.max(...arr[0]);
  }

  if (arr[1].length > 0) {
    result += Math.max(...arr[1]);
  }

  return result;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  queryString,
  dateDiff,
  dateDiffToDays,
  isLastDay,
  isLastWeek,
  formatDate,
  formatTime,
  formatLocaleDate,
  formatLocaleWeekday,
  prettyJSON,
  getMonday,
  getSunday,
  monthName,
  localeMonthName,
  toAssocArray,
  paymentsToMatrix,
  htmlToText
});


/***/ }),

/***/ "./src/util/template.js":
/*!******************************!*\
  !*** ./src/util/template.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Alert": () => (/* binding */ Alert),
/* harmony export */   "Autocomplete": () => (/* binding */ Autocomplete),
/* harmony export */   "Container": () => (/* binding */ Container),
/* harmony export */   "DownloadProgressBar": () => (/* binding */ DownloadProgressBar),
/* harmony export */   "Loading": () => (/* binding */ Loading),
/* harmony export */   "No": () => (/* binding */ No),
/* harmony export */   "Question": () => (/* binding */ Question),
/* harmony export */   "Remote": () => (/* binding */ Remote),
/* harmony export */   "Spinner": () => (/* binding */ Spinner),
/* harmony export */   "Yes": () => (/* binding */ Yes),
/* harmony export */   "applyBeginRequest": () => (/* binding */ applyBeginRequest),
/* harmony export */   "applyRequestError": () => (/* binding */ applyRequestError),
/* harmony export */   "applyRequestSuccess": () => (/* binding */ applyRequestSuccess),
/* harmony export */   "createCheckbox": () => (/* binding */ createCheckbox),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "element": () => (/* binding */ element),
/* harmony export */   "getEditorDecoration": () => (/* binding */ getEditorDecoration),
/* harmony export */   "popupTable": () => (/* binding */ popupTable),
/* harmony export */   "replaceContents": () => (/* binding */ replaceContents),
/* harmony export */   "swap": () => (/* binding */ swap),
/* harmony export */   "table": () => (/* binding */ table)
/* harmony export */ });
/* harmony import */ var _parse__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parse */ "./src/util/parse.js");
/* harmony import */ var _util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/jsx-render-mod/dom */ "./src/util/jsx-render-mod/dom.js");


/**
 * 
 * @param {*} type 
 * @param {*} content 
 * @param {*} attributes 
 * @param {{forceType: 'Text' | 'HTML'}} options 
 * @returns 
 */

function element(type, content, attributes, options = undefined) {
  const result = document.createElement(type);

  if (attributes) {
    for (let attr of Object.keys(attributes)) {
      result[attr] = attributes[attr];
    }
  }

  result.append = append.bind(result);

  result.appendTo = parent => {
    parent.append(result);
    return result;
  };

  if (content !== undefined && content !== null) {
    result.append(content, options);
  }

  return result;
}

function append(child, options = undefined) {
  if (typeof child === 'string' || typeof child === 'number') {
    if (options?.forceType != 'Text' && (options?.forceType === 'HTML' || child.toString().trim()[0] === '<')) {
      this.innerHTML = child;
    } else {
      child = document.createTextNode(child);
      this.appendChild(child);
    }
  } else if (Array.isArray(child)) {
    for (let node of child) {
      append.call(this, node);
    }
  } else {
    this.appendChild(child);
  }

  return this;
}

function replaceContents(node, newContents) {
  const cNode = node.cloneNode(false);
  append.call(cNode, newContents);

  try {
    node.parentNode.replaceChild(cNode, node);
  } catch (err) {
    console.info('Node has no parent or another problem occured');
  }

  return cNode;
}
function swap(oldNode, newNode) {
  oldNode.parentNode.replaceChild(newNode, oldNode);
  return newNode;
}
function Spinner({
  id
}) {
  const node = element('div', [element('div', null, {
    classList: 'sk-cube sk-cube1'
  }), element('div', null, {
    classList: 'sk-cube sk-cube2'
  }), element('div', null, {
    classList: 'sk-cube sk-cube3'
  }), element('div', null, {
    classList: 'sk-cube sk-cube4'
  }), element('div', null, {
    classList: 'sk-cube sk-cube5'
  }), element('div', null, {
    classList: 'sk-cube sk-cube6'
  }), element('div', null, {
    classList: 'sk-cube sk-cube7'
  }), element('div', null, {
    classList: 'sk-cube sk-cube8'
  }), element('div', null, {
    classList: 'sk-cube sk-cube9'
  })], {
    classList: 'sk-cube-grid'
  });

  if (id) {
    node.setAttribute('id', id);
  }

  return node;
}
function Loading({
  id,
  color = 'white'
}) {
  const node = element('div', [element('div', null, {
    classList: 'rect1'
  }), element('div', null, {
    classList: 'rect2'
  }), element('div', null, {
    classList: 'rect3'
  }), element('div', null, {
    classList: 'rect4'
  }), element('div', null, {
    classList: 'rect5'
  })], {
    classList: getClass()
  });

  if (id) {
    node.setAttribute('id', id);
  }

  return node;

  function getClass() {
    return `spinner ${color}`;
  }
}
function Remote({
  src,
  parse,
  component,
  color = 'white',
  onReady,
  onError
}) {
  const id = (0,_parse__WEBPACK_IMPORTED_MODULE_0__.uuid)();
  resolve();
  const loader = Loading({
    id,
    color
  });
  return loader;

  async function resolve() {
    let data = await (async () => {
      try {
        return (await (src instanceof Promise)) ? src : src();
      } catch (e) {
        if (onError) {
          onError(e, loader);
          throw e;
        }

        const retryBtn = element('button', [element('i', null, {
          className: 'glyphicon glyphicon-repeat'
        }), 'Retry'], {
          style: 'background-color: green'
        });
        retryBtn.addEventListener('click', () => {
          replaceSelf(Remote({
            src,
            parse,
            component,
            color
          }));
        });
        return element('div', [element('i', null, {
          className: 'glyphicon glyphicon-remove',
          style: 'color: red'
        }), e.message, retryBtn], {
          id: id
        });
      }
    })();

    if (parse) {
      data = parse(data);
    }

    replaceSelf(data);

    function replaceSelf(data) {
      //const loader = document.getElementById(id);
      const parent = loader.parentNode;

      if (component) {
        parent.insertBefore(component(data), loader);
      } else {
        append(data);
      } //await new Promise(resolve => setTimeout(10, resolve));
      //console.log(document.getElementById(id));


      loader.remove();

      if (onReady) {
        onReady();
      }

      function append(child) {
        if (typeof child === 'string' || typeof child === 'number') {
          if (child.toString().trim()[0] === '<') {
            const fragment = element('div', child);
            fragment.childNodes.forEach(n => parent.insertBefore(n.cloneNode(true), loader));
          } else {
            parent.insertBefore(document.createTextNode(child), loader);
          }
        } else if (Array.isArray(child)) {
          for (let node of child) {
            append(node);
          }
        } else {
          parent.insertBefore(child, loader);
        }
      }
    }
  }
}
function Yes() {
  const el = document.createElement('i');
  el.className = 'glyphicon glyphicon-ok';
  el.style.color = 'green';
  return el;
}
function No() {
  const el = document.createElement('i');
  el.className = 'glyphicon glyphicon-remove';
  el.style.color = 'red';
  return el;
}
function Question([title, answers]) {
  return element('div', [element('h2', title), element('ul', Object.entries(answers).map(([a, isCorrect]) => element('li', a, {
    classList: isCorrect ? 'correct-answer' : 'none'
  }, true)))], {
    classList: 'question-container'
  });
}
;
function Alert() {
  const el = document.createElement('i');
  el.className = 'glyphicon glyphicon-warning-sign';
  el.style.color = 'orange';
  return el;
}
function Container({
  children,
  className
}) {
  const section = element('section', children, {
    className: className ? 'event-container' : 'container'
  });
  const el = element('div', section, {
    className: className ? className : 'container administration-container ses-container'
  });
  return el;
}
function popupTable(data) {
  let html = `
        <style>
            table {
                border-collapse: collapse;
            }
            tr, td, th {
                border: 1px solid black;
                padding: 0.25em 0.5em;
            }
        </style>
        `;
  html += '<table><thead><tr>';

  for (let col of data[0]) {
    html += `<th>${col}</th>`;
  }

  html += '</tr></thead><tbody>';

  for (let row = 1; row < data.length; row++) {
    html += '<tr>';

    for (let col of data[row]) {
      html += `<td>${col}</td>`;
    }

    html += '</tr>';
  }

  html += '</tbody></table>';
  return html;
}
function getEditorDecoration(element) {
  function enable() {
    element.classList.add('enabled');
  }

  function disable() {
    element.classList.remove('enabled');
  }

  function working() {
    element.classList.remove('enabled');
    element.classList.add('working');
  }

  function updated() {
    element.classList.remove('working');
    element.classList.add('updated');
    setTimeout(() => element.classList.remove('updated'), 3000);
  }

  function failure() {
    element.classList.remove('working');
    element.classList.add('failed');
  }

  function _clear() {
    element.classList.remove('enabled');
    element.classList.remove('working');
    element.classList.remove('updated');
    element.classList.remove('failed');
  }

  return {
    enable,
    disable,
    working,
    updated,
    failure,
    _clear
  };
}
function applyBeginRequest(element) {
  element.childNodes.forEach(c => c.childNodes.forEach(n => n.disabled = true));
  element.classList.remove('enabled');
  element.classList.remove('failed');
  element.classList.add('working');
}
function applyRequestSuccess(element) {
  element.classList.remove('working');
  element.classList.add('updated');
  setTimeout(() => element.classList.remove('updated'), 3000);
}
function applyRequestError(refElement, errorContainer, fields) {
  refElement.childNodes.forEach(c => c.childNodes.forEach(n => n.disabled = false));
  refElement.classList.remove('working');
  refElement.classList.add('failed');
  console.warn(errorContainer);

  if (errorContainer.message !== undefined) {
    alert(errorContainer.message);
  } else {
    for (let error of Object.keys(errorContainer)) {
      if (error.length == 0) {
        alert(errorContainer[error].errors.join('\n'));
      } else {
        const field = fields[error];

        for (let message of errorContainer[error].errors) {
          field.appendChild(element('p', message));
        }
      }
    }
  }
}
function createCheckbox(name, data, text, onChange, defaultValue = false) {
  const id = 'ses-' + name;
  let value = readPrevInput();
  data[name] = value;
  let element = document.createElement('input');
  element.type = 'checkbox';
  element.id = id;
  element.name = name;
  let label = document.createElement('label');
  label.htmlFor = id;
  label.textContent = text;
  /*
  let element = <input type="checkbox" className="ses-check" id={id} name={name} />;
  let label = <label for={id}>{text}</label>;
  */

  element.checked = value;
  element.addEventListener('change', toggle);

  function readPrevInput() {
    let prevInput = document.getElementById(id);

    if (prevInput) {
      return prevInput.checked;
    } else {
      return defaultValue;
    }
  }

  function toggle(e) {
    value = e.target.checked;
    data[name] = value;
    redraw();
  }

  function redraw() {
    try {
      onChange();
    } catch (err) {
      console.log(err.message);
    }
  }

  const checkbox = {
    element,
    label
  };
  Object.defineProperty(checkbox, 'value', {
    get: () => value,
    set: newValue => {
      value = newValue;
      element.checked = value;
      data[name] = value;
      redraw();
    }
  });
  return checkbox;
}
function table(data, layout) {
  const thead = element('thead', element('tr', layout.map(h => element('th', h.label))));
  const tbody = element('tbody', data.map(r => element('tr', layout.map(h => element('td', r[h.name])))));
  const table = element('table', [thead, tbody]);
  table.thead = thead;
  table.tbody = tbody;
  return table;
}
function Autocomplete({
  values,
  current
}) {
  let autocomplete = element('div', [element('input', undefined, {
    className: 'ses-search-autocomplete-input'
  }), element('div', element('ul'), {
    className: 'ses-search-autocomplete-suggestions'
  })], {
    className: 'ses-search-autocomplete-container'
  });
  const suggestionsContainer = autocomplete.querySelector('.ses-search-autocomplete-suggestions');
  const input = autocomplete.querySelector('.ses-search-autocomplete-input');
  let selectedIndex = undefined;

  if (current != undefined) {
    input.value = current;
  }

  autocomplete.getValue = function () {
    return input.value;
  };

  function searchHandler(e) {
    const inputVal = e.currentTarget.value;
    let results = values;

    if (inputVal.length > 0) {
      results = values.filter(x => x.toLowerCase().indexOf(inputVal.toLowerCase()) > -1);
    }

    showSuggestions(results, inputVal);

    if (e.keyCode === 38 || e.keyCode === 40 || e.keyCode === 13) {
      scrollResults(e);
    }
  }

  function showSuggestions(results, inputVal) {
    let suggestions = suggestionsContainer.querySelector('ul');
    replaceContents(suggestions, '');
    suggestions = suggestionsContainer.querySelector('ul');
    ;

    if (results.length > 0) {
      for (let i = 0; i < results.length; i++) {
        let item = results[i];
        const match = item.match(new RegExp(inputVal, 'i'));
        item = item.replace(match[0], `<strong>${match[0]}</strong>`);
        let newLi = element('li', item, undefined, {
          forceType: "HTML"
        });
        suggestions.appendChild(newLi);
      }

      suggestions.classList.add('has-suggestions');
    } else {
      suggestions.classList.remove('has-suggestions');
    }
  }

  function useSuggestion(e) {
    input.value = e.target.textContent;
    input.focus();
    let suggestions = suggestionsContainer.querySelector('ul');
    replaceContents(suggestions, '');
    suggestions = suggestionsContainer.querySelector('ul');
    suggestions.classList.remove('has-suggestions');
  }

  function scrollResults(e) {
    let allSuggestions = [...suggestionsContainer.querySelectorAll('ul li')];
    let oldIndex = undefined;
    let indexChange = 1; // enter

    if (e.keyCode === 13) {
      input.value = allSuggestions[selectedIndex].textContent;
      selectedIndex = undefined;
      let suggestions = suggestionsContainer.querySelector('ul');
      suggestions.classList.remove('has-suggestions');
      return;
    }

    if (e.keyCode === 40) {
      // down arrow
      indexChange = 1;
    } else if (e.keyCode === 38) {
      // up arrow
      indexChange = -1;
    }

    if (selectedIndex == undefined) {
      selectedIndex = indexChange === 1 ? 0 : allSuggestions.length - 1;
    } else {
      oldIndex = selectedIndex;
      selectedIndex = (selectedIndex + indexChange + allSuggestions.length) % allSuggestions.length;
    }

    if (oldIndex !== undefined && oldIndex < allSuggestions.length) {
      allSuggestions[oldIndex].classList.remove('selected');
    }

    allSuggestions[selectedIndex].classList.add('selected');
  }

  input.addEventListener('keyup', searchHandler);
  suggestionsContainer.addEventListener('click', useSuggestion);
  return autocomplete;
}
/**
 * Creates a span element that represents a download progress bar
 * @param { {downloadFunction: (onProgress: import('./util.js').OnProgressFunction), returnFunction: function} } settings Contains the function that will download the resources, which will be called with onProgress
 * and the returnFunction which will be called with the results after the download finishes
 */

function DownloadProgressBar({
  downloadFunction,
  returnFunction
}) {
  const percent = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_1__["default"])("span", null, "0%");
  const bar = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_1__["default"])("span", {
    style: {
      padding: '0 0.5em',
      display: 'inline-block',
      width: '25%',
      background: 'linear-gradient(to right, #ffa000 0%, #eee 0)'
    }
  }, percent, " \u0421\u0432\u0430\u043B\u044F\u043D\u0435");
  downloadFunction(onProgress).then(data => {
    if (returnFunction) {
      returnFunction(data);
    }
  });
  return bar;

  function onProgress(completed, total, response, index) {
    const progress = Math.floor(completed / total * 100);
    percent.textContent = progress + '%';
    bar.style.background = `linear-gradient(to right, #ffa000 ${progress}%, #eee 0)`;
  }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  element
});

/***/ }),

/***/ "./src/util/util.js":
/*!**************************!*\
  !*** ./src/util/util.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "assertTemplate": () => (/* binding */ assertTemplate),
/* harmony export */   "createThrottledExecutor": () => (/* binding */ createThrottledExecutor),
/* harmony export */   "crossBrowserFileUpload": () => (/* binding */ crossBrowserFileUpload),
/* harmony export */   "distribute": () => (/* binding */ distribute),
/* harmony export */   "download": () => (/* binding */ download),
/* harmony export */   "escapeHTML": () => (/* binding */ escapeHTML),
/* harmony export */   "exportPaymentsToXlsx": () => (/* binding */ exportPaymentsToXlsx),
/* harmony export */   "exportToJson": () => (/* binding */ exportToJson),
/* harmony export */   "exportToXlsx": () => (/* binding */ exportToXlsx),
/* harmony export */   "getExcludedModuleInstances": () => (/* binding */ getExcludedModuleInstances),
/* harmony export */   "getExcludedModules": () => (/* binding */ getExcludedModules),
/* harmony export */   "getFundamentalLevelIds": () => (/* binding */ getFundamentalLevelIds),
/* harmony export */   "getLocale": () => (/* binding */ getLocale),
/* harmony export */   "getMime": () => (/* binding */ getMime),
/* harmony export */   "getProfessionInstanceIds": () => (/* binding */ getProfessionInstanceIds),
/* harmony export */   "getSubsite": () => (/* binding */ getSubsite),
/* harmony export */   "hasCPOAccess": () => (/* binding */ hasCPOAccess),
/* harmony export */   "iconAsset": () => (/* binding */ iconAsset),
/* harmony export */   "importFromXlsx": () => (/* binding */ importFromXlsx),
/* harmony export */   "importQuizFromXlsx": () => (/* binding */ importQuizFromXlsx),
/* harmony export */   "isAdmin": () => (/* binding */ isAdmin),
/* harmony export */   "openFile": () => (/* binding */ openFile),
/* harmony export */   "roundUpWithPrecision": () => (/* binding */ roundUpWithPrecision),
/* harmony export */   "serializeCalls": () => (/* binding */ serializeCalls),
/* harmony export */   "toLegacyXlsFile": () => (/* binding */ toLegacyXlsFile),
/* harmony export */   "toXlsxFile": () => (/* binding */ toXlsxFile),
/* harmony export */   "withProgress": () => (/* binding */ withProgress),
/* harmony export */   "zipFiles": () => (/* binding */ zipFiles)
/* harmony export */ });
/* harmony import */ var _parse__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parse */ "./src/util/parse.js");
/* globals xlsx, JSZip */

function importQuizFromXlsx(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = function (e) {
      const fileData = e.target.result;
      const wb = xlsx.read(fileData, {
        type: 'binary'
      });
      const firstSheet = wb.Sheets[wb.SheetNames[0]];
      const apiData = xlsx.utils.sheet_to_json(firstSheet, {
        header: 1
      }).slice(1) // remove first row
      .reduce((data, currentRow) => {
        if (currentRow.length !== 0) {
          const correctAnswerIndex = currentRow.pop();
          const question = currentRow[0];
          const allAnswers = currentRow.slice(1);
          const correctAnswer = currentRow[correctAnswerIndex];
          data[question] = allAnswers.reduce((answers, a) => {
            if (a != undefined && a.toString().trim() !== '') {
              answers[a] = a === correctAnswer;
            }

            return answers;
          }, {});
        }

        return data;
      }, {});
      resolve(apiData);
    };

    reader.readAsBinaryString(blob);
  });
}
function importFromXlsx(blob, useCellDates = false) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = function (e) {
      const file = e.target.result;

      try {
        const wb = xlsx.read(file, {
          type: 'binary',
          cellDates: useCellDates
        });
        const firstSheet = wb.Sheets[wb.SheetNames[0]];
        const data = xlsx.utils.sheet_to_json(firstSheet, {
          header: 1
        });
        resolve(data);
      } catch (err) {
        console.log('Error parsing XLSX file, make sure the library is loaded');
        reject(err);
      }
    };

    reader.onerror = function (e) {
      console.log('Error reading file');
      reject(e);
    };

    reader.readAsBinaryString(blob);
  });
}
function toXlsxFile(table, name = 'Output', ws_name) {
  if (ws_name === undefined) {
    ws_name = name.slice(0, 31);
  }

  const wb = xlsx.utils.book_new(),
        ws = xlsx.utils.aoa_to_sheet(table); // wb.Workbook = { Views: ['Window2'] };

  xlsx.utils.book_append_sheet(wb, ws, ws_name);
  const data = xlsx.write(wb, {
    type: 'array',
    bookType: 'xlsx'
  });
  const file = new File([data], name + '.xlsx', {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  });
  return file;
}
function toLegacyXlsFile(table, name = 'Output', ws_name) {
  if (ws_name === undefined) {
    ws_name = name.slice(0, 31);
  }

  const wb = xlsx.utils.book_new(),
        ws = xlsx.utils.aoa_to_sheet(table);
  wb.Workbook = {
    Views: ['Window2']
  };
  xlsx.utils.book_append_sheet(wb, ws, ws_name);
  const data = xlsx.write(wb, {
    type: 'array',
    bookType: 'biff8'
  });
  const file = new File([data], name + '.xls', {
    type: 'application/vnd.ms-excel'
  });
  return file;
}
function exportToXlsx(table, name = 'Output', ws_name) {
  const filename = `${name}.xlsx`;

  if (ws_name === undefined) {
    ws_name = name.slice(0, 31);
  } // Sheet name cannot contain: \ / ? * [ ]


  const sheetRegex = /[\[\]\\\/\*]/gi;

  if (sheetRegex.test(ws_name)) {
    ws_name = ws_name.replace(sheetRegex, '-');
  }

  const wb = xlsx.utils.book_new(),
        ws = xlsx.utils.aoa_to_sheet(table);
  xlsx.utils.book_append_sheet(wb, ws, ws_name);
  xlsx.writeFile(wb, filename);
}
function exportPaymentsToXlsx(data, year, month) {
  const filename = `Payments-${_parse__WEBPACK_IMPORTED_MODULE_0__["default"].monthName[month]}-${year}.xlsx`;
  const ws_name = `Payments ${_parse__WEBPACK_IMPORTED_MODULE_0__["default"].monthName[month]} ${year}`;
  const wb = xlsx.utils.book_new(),
        ws = xlsx.utils.aoa_to_sheet(data);
  xlsx.utils.book_append_sheet(wb, ws, ws_name);
  xlsx.writeFile(wb, filename);
}
function exportToJson(data, name = 'Output') {
  const blob = new Blob([data], {
    type: 'application/json'
  });

  if (window.navigator.msSaveOrOpenBlob) {
    window.navigator.msSaveBlob(blob, name + '.json');
  } else {
    var elem = window.document.createElement('a');
    elem.href = window.URL.createObjectURL(blob);
    elem.download = name + '.json';
    document.body.appendChild(elem);
    elem.click();
    document.body.removeChild(elem);
  }
}
/**
 * @param {{folder: string, files: File[]}[]} files 
 */

async function zipFiles(files) {
  const zip = new JSZip();

  for (let entry of files) {
    const current = zip.folder(entry.folder);
    current.file(entry.files.photo.name, await blobToBase64(entry.files.photo.file), {
      base64: true
    });
    current.file(entry.files.medical.name, await blobToBase64(entry.files.medical.file), {
      base64: true
    });
    current.file(entry.files.diploma.name, await blobToBase64(entry.files.diploma.file), {
      base64: true
    });
  }

  return zip.generateAsync({
    type: 'blob'
  });

  function blobToBase64(blob) {
    return new Promise(resolve => {
      const reader = new FileReader();

      reader.onload = function () {
        const dataUrl = reader.result;
        const base64 = dataUrl.split(',')[1];
        resolve(base64);
      };

      reader.readAsDataURL(blob);
    });
  }

  ;
}
const mimes = {
  'bmp': 'image/bmp',
  'gif': 'image/gif',
  'jpeg': 'image/jpeg',
  'jpg': 'image/jpeg',
  'png': 'image/png',
  'pdf': 'application/pdf',
  'tif': 'image/tiff',
  'tiff': 'image/tiff',
  'webp': 'image/webp',
  'zip': 'application/zip',
  '7z': 'application/x-7z-compressed',
  'tar': 'application/x-tar',
  'rar': 'application/vnd.rar'
};
function getMime(extension) {
  extension = extension.toLocaleLowerCase();
  return mimes[extension] || 'application/octet-stream';
}
async function openFile(file, name = 'output.txt') {
  try {
    var elem = window.document.createElement('a');
    elem.target = '_blank';
    elem.download = name;
    const href = window.URL.createObjectURL(file);
    elem.href = href;
    elem.click();
    setTimeout(() => URL.revokeObjectURL(href), 60000);
  } catch (err) {
    console.error(err);
  }
}
function download(blob, name = 'output.txt') {
  if (window.navigator.msSaveOrOpenBlob) {
    window.navigator.msSaveBlob(blob, name);
  } else {
    var elem = window.document.createElement('a');
    elem.target = '_blank';
    const href = window.URL.createObjectURL(blob);
    elem.href = href;
    elem.download = name;
    elem.click();
    setTimeout(() => URL.revokeObjectURL(href), 60000);
  }
}
async function crossBrowserFileUpload(apiCall, file) {
  if (!!window.chrome) {
    const fileUrl = URL.createObjectURL(file);
    const result = await apiCall({
      fileUrl,
      name: file.name
    });
    URL.revokeObjectURL(fileUrl);
    return result;
  } else {
    return await apiCall({
      file
    });
  }
}
function getSubsite() {
  switch (window.location.host.substr(0, 7)) {
    case 'digital':
      return 'digital';

    case 'creativ':
      return 'creative';

    case 'platfor':
      return 'platform';

    case 'ai.soft':
      return 'ai';

    case 'finance':
      return 'financeacademy';

    case 'dev.dig':
      return 'devdigital';

    case 'dev.sof':
      return 'devsoftuni';

    default:
      return 'programming';
  }
}
function hasCPOAccess() {
  return ['digital', 'creative', 'programming', 'devdigital', 'devsoftuni'].includes(getSubsite());
}
function isAdmin() {
  const e = document.querySelectorAll('a[href="/administration/navigation" i]');

  if (e.length > 0) {
    return true;
  } else {
    return false;
  }
}
function serializeCalls(fnArray, delay) {
  const callArray = [];

  if (delay !== undefined) {
    for (let i = 0; i < fnArray.length; i++) {
      const handler = (res, rej) => {
        setTimeout(async () => {
          try {
            const result = await fnArray[i]();
            res(result);
          } catch (err) {
            rej(err);
          }
        }, i * delay);
      };

      const pr = new Promise(handler);
      callArray.push(pr);
    }
  } else {
    for (let i = 0; i < fnArray.length; i++) {
      const handler = (res, rej) => {
        if (i > 0) {
          callArray[i - 1].finally(async () => {
            try {
              const result = await fnArray[i]();
              res(result);
            } catch (err) {
              rej(err);
            }
          });
        } else {
          fnArray[i]().then(res).catch(rej);
        }
      };

      const pr = new Promise(handler);
      callArray.push(pr);
    }
  }

  return callArray;
}
async function withProgress(callArray, onChange, delay = 10) {
  return new Promise((resolve, reject) => {
    // Failsave for empty callArray
    if (callArray.length == 0) {
      onChange(undefined, 0, 1, 1);
      resolve([]);
    }

    let resolved = 0;
    const response = [];
    callNext(0);

    function callNext(i) {
      if (i >= callArray.length) {
        return;
      } else {
        callArray[i].then(res => onResolve(res, i)).catch(onError);
        setTimeout(() => callNext(i + 1), delay);
      }
    }

    function onResolve(res, index) {
      resolved++;

      if (onChange) {
        onChange(res, index, resolved, callArray.length);
      }

      response[index] = res;

      if (resolved === callArray.length) {
        resolve(response);
      }
    }

    function onError(e) {
      reject(e);
    }
  });
}
/**
 * @typedef {(completed: number, total: number, response, index: number) => void} OnProgressFunction
 */

/**
 * @typedef {() => Promise} AsyncFunction
 */

/**
 * Initiate remote calls at intervals
 * @param {Array<AsyncFunction>} fnArray 
 * @param {OnProgressFunction} onProgress 
 * @param {number} [delay=10]
 * @returns 
 */

async function distribute(fnArray, onProgress, delay = 10) {
  return new Promise((resolve, reject) => {
    const total = fnArray.length;
    let completed = 0;
    let resolved = 0; // Failsave for empty fnArray

    if (total == 0) {
      if (typeof onProgress == 'function') {
        onProgress(undefined, 0, 1, 1);
      }

      resolve([]);
    }

    const calls = fnArray.map((fn, i) => {
      const call = {
        fn,
        sent: false,
        cancelled: false,
        response: undefined,
        timer: null
      };
      call.onCall = onCall.bind(call, i);
      call.cancel = onCancel.bind(call);
      call.timer = setTimeout(call.onCall, i * delay);
      return call;
    });
    calls.forEach((c, i) => c.next = calls[i + 1]);

    async function onCall(i) {
      if (this.sent == false) {
        clearTimeout(this.timer);
      }

      if (this.cancelled == false) {
        this.sent = true;

        try {
          const promise = this.fn();
          this.response = await promise;

          if (promise._cacheHit && this.next) {
            this.next.onCall();
          }

          resolved++;

          if (this.cancelled == false && resolved === total) {
            resolve(calls.map(c => c.response));
          }
        } catch (err) {
          onError(err);
        }
      }

      completed++;

      if (typeof onProgress == 'function') {
        onProgress(completed, total, this.response, i);
      }
    }

    function onCancel() {
      if (this.cancelled == false) {
        this.cancelled = true;

        if (this.sent == false) {
          clearTimeout(this.timer);
          this.onCall();
        }
      }
    }

    function onError(e) {
      calls.forEach(c => c.cancel());

      if (e instanceof Error) {
        e._responses = calls.map(c => c.response);
      }

      reject(e);
    }
  });
}
function assertTemplate(template, target, bottom = false) {
  if (template.Data !== undefined && template.Total !== undefined) {
    template = template.Data;
    target = target.Data;
  }

  if (Array.isArray(template)) {
    if (Array.isArray(target)) {
      if (bottom) {
        return;
      } else {
        assertTemplate(template[0], target[0], true);
      }
    } else {
      throw new TypeError('Target type mismatch');
    }
  } else if (typeof template === 'object') {
    if (typeof target === 'object') {
      const model = Object.keys(template);

      for (let prop of model) {
        if (target.hasOwnProperty(prop) === false) {
          throw new TypeError('Missing property on target: ' + prop);
        }
      }
    } else {
      throw new TypeError('Target type mismatch');
    }
  } else if (typeof template !== typeof target) {
    throw new TypeError('Target type mismatch');
  } else {
    return true;
  }
}
function getLocale() {
  return 'bg';
}
function createThrottledExecutor(callback, delay) {
  let timer = null;
  return function (...params) {
    clear();
    timer = setTimeout(() => {
      clear();
      callback(...params);
    }, delay);
  };

  function clear() {
    if (timer !== null) {
      clearTimeout(timer);
    }
  }
}
function iconAsset(name) {
  return browser.runtime.getURL(`icons/${name}.png`);
}
function escapeHTML(str) {
  return str.replace(/[&<>]/g, tag => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;'
  })[tag]);
}
;
function getFundamentalLevelIds(appname) {
  return {
    'programming': [19, 44, 57, 70, 106],
    'digital': [6, 7, 8, 23, 24, 25, 27, 33, 35, 40],
    'creative': [23, 24, 42, 52]
  }[appname];
}
function getProfessionInstanceIds(appname) {
  return {
    // Commented are for QA
    'programming': [1007, 1009, 1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1020, 1022, 1023, 1024, 1025, 1026, // 1028,
    1029, 1030, 1031, 1032, 1033, 1034, 1035, 1036, 1037, 1038, 1039, 1040, 1041, 1042, 1043, 1044, 1045, 1046, 1047, 1048, 1049, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1062, 1063, 1064, 1065, 1066, // 1067,
    // 1068,
    // 1069,
    1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078],
    'digital': [1, 3, 4, 5, 6, 7, 8, 9],
    'creative': [1, 3, 4, 5],
    'devdigital': [1, 3, 4, 5, 6, 7, 8, 9],
    'ai': []
  }[appname];
}
function getExcludedModules(appname) {
  return {
    'programming': [2]
  }[appname];
}
function getExcludedModuleInstances(appname) {
  return {
    'digital': [5, 50],
    'creative': [1, 14, 28, 46],
    'devdigital': [5, 50]
  }[appname];
}
/**
 * @description Rounds up a number up to specified number of decimal places using a specified number of decimal places as precision.
 * This allows correct rounding of problematic floating point numbers like "55.00000000000001" or "0.460000000000001"
 * @param {Number} number The number to round up
 * @param {Number} decimalPlacesToRoundTo The number of decimal places to round to
 * @param {Number} decimalPlacesPrecision The number of decimal places that should be considered for the rounding. Should be larger than decimalPlacesToRoundTo
 * @returns The rounded number
 */

function roundUpWithPrecision(number, decimalPlacesToRoundTo, decimalPlacesPrecision) {
  if (decimalPlacesPrecision <= decimalPlacesToRoundTo) {
    throw new RangeError('decimalPlacesPrecision should be larger than decimalPlacesToRoundTo');
  }

  let precisionValue = 10 ** decimalPlacesPrecision;
  let roundingValue = 10 ** decimalPlacesToRoundTo;
  let roundingValueBigInt = BigInt(roundingValue);
  let precisionDifferenceValue = BigInt(precisionValue / roundingValue);
  let bigInt = BigInt(Math.trunc(number * precisionValue));
  let roundedPlacesNumberPart = bigInt / precisionDifferenceValue;
  let precisionDifferenceLeftover = bigInt % precisionDifferenceValue;
  roundedPlacesNumberPart += precisionDifferenceLeftover > 0 ? 1n : 0n;
  let numberPart = roundedPlacesNumberPart / roundingValueBigInt;
  let decimalPart = roundedPlacesNumberPart % roundingValueBigInt;
  let roundedNum = Number(`${numberPart}.${decimalPart.toString().padStart(decimalPlacesToRoundTo, '0')}`);
  return roundedNum;
}

/***/ }),

/***/ "./node_modules/json5/dist/index.min.js":
/*!**********************************************!*\
  !*** ./node_modules/json5/dist/index.min.js ***!
  \**********************************************/
/***/ (function(module) {

!function(u,D){ true?module.exports=D():0}(this,function(){"use strict";function u(u,D){return u(D={exports:{}},D.exports),D.exports}var D=u(function(u){var D=u.exports="undefined"!=typeof window&&window.Math==Math?window:"undefined"!=typeof self&&self.Math==Math?self:Function("return this")();"number"==typeof __g&&(__g=D)}),e=u(function(u){var D=u.exports={version:"2.6.5"};"number"==typeof __e&&(__e=D)}),t=(e.version,function(u){return"object"==typeof u?null!==u:"function"==typeof u}),r=function(u){if(!t(u))throw TypeError(u+" is not an object!");return u},F=function(u){try{return!!u()}catch(u){return!0}},n=!F(function(){return 7!=Object.defineProperty({},"a",{get:function(){return 7}}).a}),C=D.document,A=t(C)&&t(C.createElement),i=!n&&!F(function(){return 7!=Object.defineProperty((u="div",A?C.createElement(u):{}),"a",{get:function(){return 7}}).a;var u}),E=Object.defineProperty,o={f:n?Object.defineProperty:function(u,D,e){if(r(u),D=function(u,D){if(!t(u))return u;var e,r;if(D&&"function"==typeof(e=u.toString)&&!t(r=e.call(u)))return r;if("function"==typeof(e=u.valueOf)&&!t(r=e.call(u)))return r;if(!D&&"function"==typeof(e=u.toString)&&!t(r=e.call(u)))return r;throw TypeError("Can't convert object to primitive value")}(D,!0),r(e),i)try{return E(u,D,e)}catch(u){}if("get"in e||"set"in e)throw TypeError("Accessors not supported!");return"value"in e&&(u[D]=e.value),u}},a=n?function(u,D,e){return o.f(u,D,function(u,D){return{enumerable:!(1&u),configurable:!(2&u),writable:!(4&u),value:D}}(1,e))}:function(u,D,e){return u[D]=e,u},c={}.hasOwnProperty,B=function(u,D){return c.call(u,D)},s=0,f=Math.random(),l=u(function(u){var t=D["__core-js_shared__"]||(D["__core-js_shared__"]={});(u.exports=function(u,D){return t[u]||(t[u]=void 0!==D?D:{})})("versions",[]).push({version:e.version,mode:"global",copyright:"© 2019 Denis Pushkarev (zloirock.ru)"})})("native-function-to-string",Function.toString),d=u(function(u){var t,r="Symbol(".concat(void 0===(t="src")?"":t,")_",(++s+f).toString(36)),F=(""+l).split("toString");e.inspectSource=function(u){return l.call(u)},(u.exports=function(u,e,t,n){var C="function"==typeof t;C&&(B(t,"name")||a(t,"name",e)),u[e]!==t&&(C&&(B(t,r)||a(t,r,u[e]?""+u[e]:F.join(String(e)))),u===D?u[e]=t:n?u[e]?u[e]=t:a(u,e,t):(delete u[e],a(u,e,t)))})(Function.prototype,"toString",function(){return"function"==typeof this&&this[r]||l.call(this)})}),v=function(u,D,e){if(function(u){if("function"!=typeof u)throw TypeError(u+" is not a function!")}(u),void 0===D)return u;switch(e){case 1:return function(e){return u.call(D,e)};case 2:return function(e,t){return u.call(D,e,t)};case 3:return function(e,t,r){return u.call(D,e,t,r)}}return function(){return u.apply(D,arguments)}},p=function(u,t,r){var F,n,C,A,i=u&p.F,E=u&p.G,o=u&p.S,c=u&p.P,B=u&p.B,s=E?D:o?D[t]||(D[t]={}):(D[t]||{}).prototype,f=E?e:e[t]||(e[t]={}),l=f.prototype||(f.prototype={});for(F in E&&(r=t),r)C=((n=!i&&s&&void 0!==s[F])?s:r)[F],A=B&&n?v(C,D):c&&"function"==typeof C?v(Function.call,C):C,s&&d(s,F,C,u&p.U),f[F]!=C&&a(f,F,A),c&&l[F]!=C&&(l[F]=C)};D.core=e,p.F=1,p.G=2,p.S=4,p.P=8,p.B=16,p.W=32,p.U=64,p.R=128;var h,m=p,g=Math.ceil,y=Math.floor,w=function(u){return isNaN(u=+u)?0:(u>0?y:g)(u)},S=(h=!1,function(u,D){var e,t,r=String(function(u){if(null==u)throw TypeError("Can't call method on  "+u);return u}(u)),F=w(D),n=r.length;return F<0||F>=n?h?"":void 0:(e=r.charCodeAt(F))<55296||e>56319||F+1===n||(t=r.charCodeAt(F+1))<56320||t>57343?h?r.charAt(F):e:h?r.slice(F,F+2):t-56320+(e-55296<<10)+65536});m(m.P,"String",{codePointAt:function(u){return S(this,u)}});e.String.codePointAt;var b=Math.max,x=Math.min,N=String.fromCharCode,P=String.fromCodePoint;m(m.S+m.F*(!!P&&1!=P.length),"String",{fromCodePoint:function(u){for(var D,e,t,r=arguments,F=[],n=arguments.length,C=0;n>C;){if(D=+r[C++],t=1114111,((e=w(e=D))<0?b(e+t,0):x(e,t))!==D)throw RangeError(D+" is not a valid code point");F.push(D<65536?N(D):N(55296+((D-=65536)>>10),D%1024+56320))}return F.join("")}});e.String.fromCodePoint;var _,I,O,j,V,J,M,k,L,T,z,H,$,R,G={Space_Separator:/[\u1680\u2000-\u200A\u202F\u205F\u3000]/,ID_Start:/[\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0559\u0561-\u0587\u05D0-\u05EA\u05F0-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u0860-\u086A\u08A0-\u08B4\u08B6-\u08BD\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u09FC\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C60\u0C61\u0C80\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D05-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D54-\u0D56\u0D5F-\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E87\u0E88\u0E8A\u0E8D\u0E94-\u0E97\u0E99-\u0E9F\u0EA1-\u0EA3\u0EA5\u0EA7\u0EAA\u0EAB\u0EAD-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u170C\u170E-\u1711\u1720-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1877\u1880-\u1884\u1887-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4B\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1C80-\u1C88\u1CE9-\u1CEC\u1CEE-\u1CF1\u1CF5\u1CF6\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2160-\u2188\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312E\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FEA\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6EF\uA717-\uA71F\uA722-\uA788\uA78B-\uA7AE\uA7B0-\uA7B7\uA7F7-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA8FD\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uA9E0-\uA9E4\uA9E6-\uA9EF\uA9FA-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB65\uAB70-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDD40-\uDD74\uDE80-\uDE9C\uDEA0-\uDED0\uDF00-\uDF1F\uDF2D-\uDF4A\uDF50-\uDF75\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF\uDFD1-\uDFD5]|\uD801[\uDC00-\uDC9D\uDCB0-\uDCD3\uDCD8-\uDCFB\uDD00-\uDD27\uDD30-\uDD63\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC60-\uDC76\uDC80-\uDC9E\uDCE0-\uDCF2\uDCF4\uDCF5\uDD00-\uDD15\uDD20-\uDD39\uDD80-\uDDB7\uDDBE\uDDBF\uDE00\uDE10-\uDE13\uDE15-\uDE17\uDE19-\uDE33\uDE60-\uDE7C\uDE80-\uDE9C\uDEC0-\uDEC7\uDEC9-\uDEE4\uDF00-\uDF35\uDF40-\uDF55\uDF60-\uDF72\uDF80-\uDF91]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2]|\uD804[\uDC03-\uDC37\uDC83-\uDCAF\uDCD0-\uDCE8\uDD03-\uDD26\uDD50-\uDD72\uDD76\uDD83-\uDDB2\uDDC1-\uDDC4\uDDDA\uDDDC\uDE00-\uDE11\uDE13-\uDE2B\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEDE\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3D\uDF50\uDF5D-\uDF61]|\uD805[\uDC00-\uDC34\uDC47-\uDC4A\uDC80-\uDCAF\uDCC4\uDCC5\uDCC7\uDD80-\uDDAE\uDDD8-\uDDDB\uDE00-\uDE2F\uDE44\uDE80-\uDEAA\uDF00-\uDF19]|\uD806[\uDCA0-\uDCDF\uDCFF\uDE00\uDE0B-\uDE32\uDE3A\uDE50\uDE5C-\uDE83\uDE86-\uDE89\uDEC0-\uDEF8]|\uD807[\uDC00-\uDC08\uDC0A-\uDC2E\uDC40\uDC72-\uDC8F\uDD00-\uDD06\uDD08\uDD09\uDD0B-\uDD30\uDD46]|\uD808[\uDC00-\uDF99]|\uD809[\uDC00-\uDC6E\uDC80-\uDD43]|[\uD80C\uD81C-\uD820\uD840-\uD868\uD86A-\uD86C\uD86F-\uD872\uD874-\uD879][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2E]|\uD811[\uDC00-\uDE46]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDED0-\uDEED\uDF00-\uDF2F\uDF40-\uDF43\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDF00-\uDF44\uDF50\uDF93-\uDF9F\uDFE0\uDFE1]|\uD821[\uDC00-\uDFEC]|\uD822[\uDC00-\uDEF2]|\uD82C[\uDC00-\uDD1E\uDD70-\uDEFB]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB]|\uD83A[\uDC00-\uDCC4\uDD00-\uDD43]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD869[\uDC00-\uDED6\uDF00-\uDFFF]|\uD86D[\uDC00-\uDF34\uDF40-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEA1\uDEB0-\uDFFF]|\uD87A[\uDC00-\uDFE0]|\uD87E[\uDC00-\uDE1D]/,ID_Continue:/[\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0300-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u0483-\u0487\u048A-\u052F\u0531-\u0556\u0559\u0561-\u0587\u0591-\u05BD\u05BF\u05C1\u05C2\u05C4\u05C5\u05C7\u05D0-\u05EA\u05F0-\u05F2\u0610-\u061A\u0620-\u0669\u066E-\u06D3\u06D5-\u06DC\u06DF-\u06E8\u06EA-\u06FC\u06FF\u0710-\u074A\u074D-\u07B1\u07C0-\u07F5\u07FA\u0800-\u082D\u0840-\u085B\u0860-\u086A\u08A0-\u08B4\u08B6-\u08BD\u08D4-\u08E1\u08E3-\u0963\u0966-\u096F\u0971-\u0983\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BC-\u09C4\u09C7\u09C8\u09CB-\u09CE\u09D7\u09DC\u09DD\u09DF-\u09E3\u09E6-\u09F1\u09FC\u0A01-\u0A03\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A3C\u0A3E-\u0A42\u0A47\u0A48\u0A4B-\u0A4D\u0A51\u0A59-\u0A5C\u0A5E\u0A66-\u0A75\u0A81-\u0A83\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABC-\u0AC5\u0AC7-\u0AC9\u0ACB-\u0ACD\u0AD0\u0AE0-\u0AE3\u0AE6-\u0AEF\u0AF9-\u0AFF\u0B01-\u0B03\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3C-\u0B44\u0B47\u0B48\u0B4B-\u0B4D\u0B56\u0B57\u0B5C\u0B5D\u0B5F-\u0B63\u0B66-\u0B6F\u0B71\u0B82\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BBE-\u0BC2\u0BC6-\u0BC8\u0BCA-\u0BCD\u0BD0\u0BD7\u0BE6-\u0BEF\u0C00-\u0C03\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D-\u0C44\u0C46-\u0C48\u0C4A-\u0C4D\u0C55\u0C56\u0C58-\u0C5A\u0C60-\u0C63\u0C66-\u0C6F\u0C80-\u0C83\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBC-\u0CC4\u0CC6-\u0CC8\u0CCA-\u0CCD\u0CD5\u0CD6\u0CDE\u0CE0-\u0CE3\u0CE6-\u0CEF\u0CF1\u0CF2\u0D00-\u0D03\u0D05-\u0D0C\u0D0E-\u0D10\u0D12-\u0D44\u0D46-\u0D48\u0D4A-\u0D4E\u0D54-\u0D57\u0D5F-\u0D63\u0D66-\u0D6F\u0D7A-\u0D7F\u0D82\u0D83\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0DCA\u0DCF-\u0DD4\u0DD6\u0DD8-\u0DDF\u0DE6-\u0DEF\u0DF2\u0DF3\u0E01-\u0E3A\u0E40-\u0E4E\u0E50-\u0E59\u0E81\u0E82\u0E84\u0E87\u0E88\u0E8A\u0E8D\u0E94-\u0E97\u0E99-\u0E9F\u0EA1-\u0EA3\u0EA5\u0EA7\u0EAA\u0EAB\u0EAD-\u0EB9\u0EBB-\u0EBD\u0EC0-\u0EC4\u0EC6\u0EC8-\u0ECD\u0ED0-\u0ED9\u0EDC-\u0EDF\u0F00\u0F18\u0F19\u0F20-\u0F29\u0F35\u0F37\u0F39\u0F3E-\u0F47\u0F49-\u0F6C\u0F71-\u0F84\u0F86-\u0F97\u0F99-\u0FBC\u0FC6\u1000-\u1049\u1050-\u109D\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u135D-\u135F\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u170C\u170E-\u1714\u1720-\u1734\u1740-\u1753\u1760-\u176C\u176E-\u1770\u1772\u1773\u1780-\u17D3\u17D7\u17DC\u17DD\u17E0-\u17E9\u180B-\u180D\u1810-\u1819\u1820-\u1877\u1880-\u18AA\u18B0-\u18F5\u1900-\u191E\u1920-\u192B\u1930-\u193B\u1946-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u19D0-\u19D9\u1A00-\u1A1B\u1A20-\u1A5E\u1A60-\u1A7C\u1A7F-\u1A89\u1A90-\u1A99\u1AA7\u1AB0-\u1ABD\u1B00-\u1B4B\u1B50-\u1B59\u1B6B-\u1B73\u1B80-\u1BF3\u1C00-\u1C37\u1C40-\u1C49\u1C4D-\u1C7D\u1C80-\u1C88\u1CD0-\u1CD2\u1CD4-\u1CF9\u1D00-\u1DF9\u1DFB-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u203F\u2040\u2054\u2071\u207F\u2090-\u209C\u20D0-\u20DC\u20E1\u20E5-\u20F0\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2160-\u2188\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D7F-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2DE0-\u2DFF\u2E2F\u3005-\u3007\u3021-\u302F\u3031-\u3035\u3038-\u303C\u3041-\u3096\u3099\u309A\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312E\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FEA\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA62B\uA640-\uA66F\uA674-\uA67D\uA67F-\uA6F1\uA717-\uA71F\uA722-\uA788\uA78B-\uA7AE\uA7B0-\uA7B7\uA7F7-\uA827\uA840-\uA873\uA880-\uA8C5\uA8D0-\uA8D9\uA8E0-\uA8F7\uA8FB\uA8FD\uA900-\uA92D\uA930-\uA953\uA960-\uA97C\uA980-\uA9C0\uA9CF-\uA9D9\uA9E0-\uA9FE\uAA00-\uAA36\uAA40-\uAA4D\uAA50-\uAA59\uAA60-\uAA76\uAA7A-\uAAC2\uAADB-\uAADD\uAAE0-\uAAEF\uAAF2-\uAAF6\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB65\uAB70-\uABEA\uABEC\uABED\uABF0-\uABF9\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE00-\uFE0F\uFE20-\uFE2F\uFE33\uFE34\uFE4D-\uFE4F\uFE70-\uFE74\uFE76-\uFEFC\uFF10-\uFF19\uFF21-\uFF3A\uFF3F\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDD40-\uDD74\uDDFD\uDE80-\uDE9C\uDEA0-\uDED0\uDEE0\uDF00-\uDF1F\uDF2D-\uDF4A\uDF50-\uDF7A\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF\uDFD1-\uDFD5]|\uD801[\uDC00-\uDC9D\uDCA0-\uDCA9\uDCB0-\uDCD3\uDCD8-\uDCFB\uDD00-\uDD27\uDD30-\uDD63\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC60-\uDC76\uDC80-\uDC9E\uDCE0-\uDCF2\uDCF4\uDCF5\uDD00-\uDD15\uDD20-\uDD39\uDD80-\uDDB7\uDDBE\uDDBF\uDE00-\uDE03\uDE05\uDE06\uDE0C-\uDE13\uDE15-\uDE17\uDE19-\uDE33\uDE38-\uDE3A\uDE3F\uDE60-\uDE7C\uDE80-\uDE9C\uDEC0-\uDEC7\uDEC9-\uDEE6\uDF00-\uDF35\uDF40-\uDF55\uDF60-\uDF72\uDF80-\uDF91]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2]|\uD804[\uDC00-\uDC46\uDC66-\uDC6F\uDC7F-\uDCBA\uDCD0-\uDCE8\uDCF0-\uDCF9\uDD00-\uDD34\uDD36-\uDD3F\uDD50-\uDD73\uDD76\uDD80-\uDDC4\uDDCA-\uDDCC\uDDD0-\uDDDA\uDDDC\uDE00-\uDE11\uDE13-\uDE37\uDE3E\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEEA\uDEF0-\uDEF9\uDF00-\uDF03\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3C-\uDF44\uDF47\uDF48\uDF4B-\uDF4D\uDF50\uDF57\uDF5D-\uDF63\uDF66-\uDF6C\uDF70-\uDF74]|\uD805[\uDC00-\uDC4A\uDC50-\uDC59\uDC80-\uDCC5\uDCC7\uDCD0-\uDCD9\uDD80-\uDDB5\uDDB8-\uDDC0\uDDD8-\uDDDD\uDE00-\uDE40\uDE44\uDE50-\uDE59\uDE80-\uDEB7\uDEC0-\uDEC9\uDF00-\uDF19\uDF1D-\uDF2B\uDF30-\uDF39]|\uD806[\uDCA0-\uDCE9\uDCFF\uDE00-\uDE3E\uDE47\uDE50-\uDE83\uDE86-\uDE99\uDEC0-\uDEF8]|\uD807[\uDC00-\uDC08\uDC0A-\uDC36\uDC38-\uDC40\uDC50-\uDC59\uDC72-\uDC8F\uDC92-\uDCA7\uDCA9-\uDCB6\uDD00-\uDD06\uDD08\uDD09\uDD0B-\uDD36\uDD3A\uDD3C\uDD3D\uDD3F-\uDD47\uDD50-\uDD59]|\uD808[\uDC00-\uDF99]|\uD809[\uDC00-\uDC6E\uDC80-\uDD43]|[\uD80C\uD81C-\uD820\uD840-\uD868\uD86A-\uD86C\uD86F-\uD872\uD874-\uD879][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2E]|\uD811[\uDC00-\uDE46]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDE60-\uDE69\uDED0-\uDEED\uDEF0-\uDEF4\uDF00-\uDF36\uDF40-\uDF43\uDF50-\uDF59\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDF00-\uDF44\uDF50-\uDF7E\uDF8F-\uDF9F\uDFE0\uDFE1]|\uD821[\uDC00-\uDFEC]|\uD822[\uDC00-\uDEF2]|\uD82C[\uDC00-\uDD1E\uDD70-\uDEFB]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99\uDC9D\uDC9E]|\uD834[\uDD65-\uDD69\uDD6D-\uDD72\uDD7B-\uDD82\uDD85-\uDD8B\uDDAA-\uDDAD\uDE42-\uDE44]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB\uDFCE-\uDFFF]|\uD836[\uDE00-\uDE36\uDE3B-\uDE6C\uDE75\uDE84\uDE9B-\uDE9F\uDEA1-\uDEAF]|\uD838[\uDC00-\uDC06\uDC08-\uDC18\uDC1B-\uDC21\uDC23\uDC24\uDC26-\uDC2A]|\uD83A[\uDC00-\uDCC4\uDCD0-\uDCD6\uDD00-\uDD4A\uDD50-\uDD59]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD869[\uDC00-\uDED6\uDF00-\uDFFF]|\uD86D[\uDC00-\uDF34\uDF40-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEA1\uDEB0-\uDFFF]|\uD87A[\uDC00-\uDFE0]|\uD87E[\uDC00-\uDE1D]|\uDB40[\uDD00-\uDDEF]/},U={isSpaceSeparator:function(u){return"string"==typeof u&&G.Space_Separator.test(u)},isIdStartChar:function(u){return"string"==typeof u&&(u>="a"&&u<="z"||u>="A"&&u<="Z"||"$"===u||"_"===u||G.ID_Start.test(u))},isIdContinueChar:function(u){return"string"==typeof u&&(u>="a"&&u<="z"||u>="A"&&u<="Z"||u>="0"&&u<="9"||"$"===u||"_"===u||"‌"===u||"‍"===u||G.ID_Continue.test(u))},isDigit:function(u){return"string"==typeof u&&/[0-9]/.test(u)},isHexDigit:function(u){return"string"==typeof u&&/[0-9A-Fa-f]/.test(u)}};function Z(){for(T="default",z="",H=!1,$=1;;){R=q();var u=X[T]();if(u)return u}}function q(){if(_[j])return String.fromCodePoint(_.codePointAt(j))}function W(){var u=q();return"\n"===u?(V++,J=0):u?J+=u.length:J++,u&&(j+=u.length),u}var X={default:function(){switch(R){case"\t":case"\v":case"\f":case" ":case" ":case"\ufeff":case"\n":case"\r":case"\u2028":case"\u2029":return void W();case"/":return W(),void(T="comment");case void 0:return W(),K("eof")}if(!U.isSpaceSeparator(R))return X[I]();W()},comment:function(){switch(R){case"*":return W(),void(T="multiLineComment");case"/":return W(),void(T="singleLineComment")}throw tu(W())},multiLineComment:function(){switch(R){case"*":return W(),void(T="multiLineCommentAsterisk");case void 0:throw tu(W())}W()},multiLineCommentAsterisk:function(){switch(R){case"*":return void W();case"/":return W(),void(T="default");case void 0:throw tu(W())}W(),T="multiLineComment"},singleLineComment:function(){switch(R){case"\n":case"\r":case"\u2028":case"\u2029":return W(),void(T="default");case void 0:return W(),K("eof")}W()},value:function(){switch(R){case"{":case"[":return K("punctuator",W());case"n":return W(),Q("ull"),K("null",null);case"t":return W(),Q("rue"),K("boolean",!0);case"f":return W(),Q("alse"),K("boolean",!1);case"-":case"+":return"-"===W()&&($=-1),void(T="sign");case".":return z=W(),void(T="decimalPointLeading");case"0":return z=W(),void(T="zero");case"1":case"2":case"3":case"4":case"5":case"6":case"7":case"8":case"9":return z=W(),void(T="decimalInteger");case"I":return W(),Q("nfinity"),K("numeric",1/0);case"N":return W(),Q("aN"),K("numeric",NaN);case'"':case"'":return H='"'===W(),z="",void(T="string")}throw tu(W())},identifierNameStartEscape:function(){if("u"!==R)throw tu(W());W();var u=Y();switch(u){case"$":case"_":break;default:if(!U.isIdStartChar(u))throw Fu()}z+=u,T="identifierName"},identifierName:function(){switch(R){case"$":case"_":case"‌":case"‍":return void(z+=W());case"\\":return W(),void(T="identifierNameEscape")}if(!U.isIdContinueChar(R))return K("identifier",z);z+=W()},identifierNameEscape:function(){if("u"!==R)throw tu(W());W();var u=Y();switch(u){case"$":case"_":case"‌":case"‍":break;default:if(!U.isIdContinueChar(u))throw Fu()}z+=u,T="identifierName"},sign:function(){switch(R){case".":return z=W(),void(T="decimalPointLeading");case"0":return z=W(),void(T="zero");case"1":case"2":case"3":case"4":case"5":case"6":case"7":case"8":case"9":return z=W(),void(T="decimalInteger");case"I":return W(),Q("nfinity"),K("numeric",$*(1/0));case"N":return W(),Q("aN"),K("numeric",NaN)}throw tu(W())},zero:function(){switch(R){case".":return z+=W(),void(T="decimalPoint");case"e":case"E":return z+=W(),void(T="decimalExponent");case"x":case"X":return z+=W(),void(T="hexadecimal")}return K("numeric",0*$)},decimalInteger:function(){switch(R){case".":return z+=W(),void(T="decimalPoint");case"e":case"E":return z+=W(),void(T="decimalExponent")}if(!U.isDigit(R))return K("numeric",$*Number(z));z+=W()},decimalPointLeading:function(){if(U.isDigit(R))return z+=W(),void(T="decimalFraction");throw tu(W())},decimalPoint:function(){switch(R){case"e":case"E":return z+=W(),void(T="decimalExponent")}return U.isDigit(R)?(z+=W(),void(T="decimalFraction")):K("numeric",$*Number(z))},decimalFraction:function(){switch(R){case"e":case"E":return z+=W(),void(T="decimalExponent")}if(!U.isDigit(R))return K("numeric",$*Number(z));z+=W()},decimalExponent:function(){switch(R){case"+":case"-":return z+=W(),void(T="decimalExponentSign")}if(U.isDigit(R))return z+=W(),void(T="decimalExponentInteger");throw tu(W())},decimalExponentSign:function(){if(U.isDigit(R))return z+=W(),void(T="decimalExponentInteger");throw tu(W())},decimalExponentInteger:function(){if(!U.isDigit(R))return K("numeric",$*Number(z));z+=W()},hexadecimal:function(){if(U.isHexDigit(R))return z+=W(),void(T="hexadecimalInteger");throw tu(W())},hexadecimalInteger:function(){if(!U.isHexDigit(R))return K("numeric",$*Number(z));z+=W()},string:function(){switch(R){case"\\":return W(),void(z+=function(){switch(q()){case"b":return W(),"\b";case"f":return W(),"\f";case"n":return W(),"\n";case"r":return W(),"\r";case"t":return W(),"\t";case"v":return W(),"\v";case"0":if(W(),U.isDigit(q()))throw tu(W());return"\0";case"x":return W(),function(){var u="",D=q();if(!U.isHexDigit(D))throw tu(W());if(u+=W(),D=q(),!U.isHexDigit(D))throw tu(W());return u+=W(),String.fromCodePoint(parseInt(u,16))}();case"u":return W(),Y();case"\n":case"\u2028":case"\u2029":return W(),"";case"\r":return W(),"\n"===q()&&W(),"";case"1":case"2":case"3":case"4":case"5":case"6":case"7":case"8":case"9":case void 0:throw tu(W())}return W()}());case'"':return H?(W(),K("string",z)):void(z+=W());case"'":return H?void(z+=W()):(W(),K("string",z));case"\n":case"\r":throw tu(W());case"\u2028":case"\u2029":!function(u){console.warn("JSON5: '"+nu(u)+"' in strings is not valid ECMAScript; consider escaping")}(R);break;case void 0:throw tu(W())}z+=W()},start:function(){switch(R){case"{":case"[":return K("punctuator",W())}T="value"},beforePropertyName:function(){switch(R){case"$":case"_":return z=W(),void(T="identifierName");case"\\":return W(),void(T="identifierNameStartEscape");case"}":return K("punctuator",W());case'"':case"'":return H='"'===W(),void(T="string")}if(U.isIdStartChar(R))return z+=W(),void(T="identifierName");throw tu(W())},afterPropertyName:function(){if(":"===R)return K("punctuator",W());throw tu(W())},beforePropertyValue:function(){T="value"},afterPropertyValue:function(){switch(R){case",":case"}":return K("punctuator",W())}throw tu(W())},beforeArrayValue:function(){if("]"===R)return K("punctuator",W());T="value"},afterArrayValue:function(){switch(R){case",":case"]":return K("punctuator",W())}throw tu(W())},end:function(){throw tu(W())}};function K(u,D){return{type:u,value:D,line:V,column:J}}function Q(u){for(var D=0,e=u;D<e.length;D+=1){var t=e[D];if(q()!==t)throw tu(W());W()}}function Y(){for(var u="",D=4;D-- >0;){var e=q();if(!U.isHexDigit(e))throw tu(W());u+=W()}return String.fromCodePoint(parseInt(u,16))}var uu={start:function(){if("eof"===M.type)throw ru();Du()},beforePropertyName:function(){switch(M.type){case"identifier":case"string":return k=M.value,void(I="afterPropertyName");case"punctuator":return void eu();case"eof":throw ru()}},afterPropertyName:function(){if("eof"===M.type)throw ru();I="beforePropertyValue"},beforePropertyValue:function(){if("eof"===M.type)throw ru();Du()},beforeArrayValue:function(){if("eof"===M.type)throw ru();"punctuator"!==M.type||"]"!==M.value?Du():eu()},afterPropertyValue:function(){if("eof"===M.type)throw ru();switch(M.value){case",":return void(I="beforePropertyName");case"}":eu()}},afterArrayValue:function(){if("eof"===M.type)throw ru();switch(M.value){case",":return void(I="beforeArrayValue");case"]":eu()}},end:function(){}};function Du(){var u;switch(M.type){case"punctuator":switch(M.value){case"{":u={};break;case"[":u=[]}break;case"null":case"boolean":case"numeric":case"string":u=M.value}if(void 0===L)L=u;else{var D=O[O.length-1];Array.isArray(D)?D.push(u):D[k]=u}if(null!==u&&"object"==typeof u)O.push(u),I=Array.isArray(u)?"beforeArrayValue":"beforePropertyName";else{var e=O[O.length-1];I=null==e?"end":Array.isArray(e)?"afterArrayValue":"afterPropertyValue"}}function eu(){O.pop();var u=O[O.length-1];I=null==u?"end":Array.isArray(u)?"afterArrayValue":"afterPropertyValue"}function tu(u){return Cu(void 0===u?"JSON5: invalid end of input at "+V+":"+J:"JSON5: invalid character '"+nu(u)+"' at "+V+":"+J)}function ru(){return Cu("JSON5: invalid end of input at "+V+":"+J)}function Fu(){return Cu("JSON5: invalid identifier character at "+V+":"+(J-=5))}function nu(u){var D={"'":"\\'",'"':'\\"',"\\":"\\\\","\b":"\\b","\f":"\\f","\n":"\\n","\r":"\\r","\t":"\\t","\v":"\\v","\0":"\\0","\u2028":"\\u2028","\u2029":"\\u2029"};if(D[u])return D[u];if(u<" "){var e=u.charCodeAt(0).toString(16);return"\\x"+("00"+e).substring(e.length)}return u}function Cu(u){var D=new SyntaxError(u);return D.lineNumber=V,D.columnNumber=J,D}return{parse:function(u,D){_=String(u),I="start",O=[],j=0,V=1,J=0,M=void 0,k=void 0,L=void 0;do{M=Z(),uu[I]()}while("eof"!==M.type);return"function"==typeof D?function u(D,e,t){var r=D[e];if(null!=r&&"object"==typeof r)for(var F in r){var n=u(r,F,t);void 0===n?delete r[F]:r[F]=n}return t.call(D,e,r)}({"":L},"",D):L},stringify:function(u,D,e){var t,r,F,n=[],C="",A="";if(null==D||"object"!=typeof D||Array.isArray(D)||(e=D.space,F=D.quote,D=D.replacer),"function"==typeof D)r=D;else if(Array.isArray(D)){t=[];for(var i=0,E=D;i<E.length;i+=1){var o=E[i],a=void 0;"string"==typeof o?a=o:("number"==typeof o||o instanceof String||o instanceof Number)&&(a=String(o)),void 0!==a&&t.indexOf(a)<0&&t.push(a)}}return e instanceof Number?e=Number(e):e instanceof String&&(e=String(e)),"number"==typeof e?e>0&&(e=Math.min(10,Math.floor(e)),A="          ".substr(0,e)):"string"==typeof e&&(A=e.substr(0,10)),c("",{"":u});function c(u,D){var e=D[u];switch(null!=e&&("function"==typeof e.toJSON5?e=e.toJSON5(u):"function"==typeof e.toJSON&&(e=e.toJSON(u))),r&&(e=r.call(D,u,e)),e instanceof Number?e=Number(e):e instanceof String?e=String(e):e instanceof Boolean&&(e=e.valueOf()),e){case null:return"null";case!0:return"true";case!1:return"false"}return"string"==typeof e?B(e):"number"==typeof e?String(e):"object"==typeof e?Array.isArray(e)?function(u){if(n.indexOf(u)>=0)throw TypeError("Converting circular structure to JSON5");n.push(u);var D=C;C+=A;for(var e,t=[],r=0;r<u.length;r++){var F=c(String(r),u);t.push(void 0!==F?F:"null")}if(0===t.length)e="[]";else if(""===A){var i=t.join(",");e="["+i+"]"}else{var E=",\n"+C,o=t.join(E);e="[\n"+C+o+",\n"+D+"]"}return n.pop(),C=D,e}(e):function(u){if(n.indexOf(u)>=0)throw TypeError("Converting circular structure to JSON5");n.push(u);var D=C;C+=A;for(var e,r,F=t||Object.keys(u),i=[],E=0,o=F;E<o.length;E+=1){var a=o[E],B=c(a,u);if(void 0!==B){var f=s(a)+":";""!==A&&(f+=" "),f+=B,i.push(f)}}if(0===i.length)e="{}";else if(""===A)r=i.join(","),e="{"+r+"}";else{var l=",\n"+C;r=i.join(l),e="{\n"+C+r+",\n"+D+"}"}return n.pop(),C=D,e}(e):void 0}function B(u){for(var D={"'":.1,'"':.2},e={"'":"\\'",'"':'\\"',"\\":"\\\\","\b":"\\b","\f":"\\f","\n":"\\n","\r":"\\r","\t":"\\t","\v":"\\v","\0":"\\0","\u2028":"\\u2028","\u2029":"\\u2029"},t="",r=0;r<u.length;r++){var n=u[r];switch(n){case"'":case'"':D[n]++,t+=n;continue;case"\0":if(U.isDigit(u[r+1])){t+="\\x00";continue}}if(e[n])t+=e[n];else if(n<" "){var C=n.charCodeAt(0).toString(16);t+="\\x"+("00"+C).substring(C.length)}else t+=n}var A=F||Object.keys(D).reduce(function(u,e){return D[u]<D[e]?u:e});return A+(t=t.replace(new RegExp(A,"g"),e[A]))+A}function s(u){if(0===u.length)return B(u);var D=String.fromCodePoint(u.codePointAt(0));if(!U.isIdStartChar(D))return B(u);for(var e=D.length;e<u.length;e++)if(!U.isIdContinueChar(String.fromCodePoint(u.codePointAt(e))))return B(u);return u}}}});


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
/*!**************************!*\
  !*** ./src/blog/blog.js ***!
  \**************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/jsx-render-mod/dom */ "./src/util/jsx-render-mod/dom.js");
/* harmony import */ var _util_util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/util */ "./src/util/util.js");
/* harmony import */ var _util_template__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../util/template */ "./src/util/template.js");
/* harmony import */ var _util_api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../util/api */ "./src/util/api.js");




const appName = (0,_util_util__WEBPACK_IMPORTED_MODULE_1__.getSubsite)();

if (appName == 'digital' || appName == 'creative') {
  injectButton();
}

function injectButton() {
  if ((0,_util_util__WEBPACK_IMPORTED_MODULE_1__.isAdmin)()) {
    document.querySelectorAll('.ses-div').forEach(e => e.remove());
    const blogUrl = /\/blog\/(.+)/.exec(window.location.pathname)[1];

    if (blogUrl) {
      const content = document.querySelectorAll('article>div.row.no-margin-offset.bottom-buffer-lg')[0];
      const element = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
        class: "row no-margin-offset bottom-buffer-lg ses-div"
      }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_2__.Remote, {
        src: () => getBlogId(blogUrl),
        component: editBtn,
        color: "black"
      }));
      content.parentElement.insertBefore(element, content);
    }
  }
}

function editBtn(blogId) {
  if (blogId === null) {
    return null;
  } else {
    return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("a", {
      class: "btn-primary purple-btn ses-btn",
      href: `/administration_cms/news/edit/${blogId}`
    }, "Edit article");
  }
}

async function getBlogId(url) {
  const blog = await _util_api__WEBPACK_IMPORTED_MODULE_3__.getBlogByUrl(url);

  if (blog) {
    return blog.Id;
  } else {
    return null;
  }
}
})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9kZXYvL2NvbnRlbnQtc2NyaXB0cy9ibG9nLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM5Q0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDekdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaElBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwRkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN4QkE7QUFDQTtBQUNBO0FBSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNURBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBUEE7QUFVQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFmQTs7QUFrQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQWRBO0FBZ0JBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBZEE7QUFnQkE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFkQTtBQWlCQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBSkE7QUFNQTtBQUNBO0FBRUE7QUFVQTtBQU1BOztBQU9BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTEE7QUFPQTs7QUFFQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBREE7QUFHQTtBQUxBOztBQVFBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBREE7O0FBSUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7Ozs7Ozs7Ozs7Ozs7OztBQ3pSQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBREE7QUFJQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFEQTtBQUlBO0FBQ0E7O0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFEQTtBQUlBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXpCQTtBQTRCQTtBQUVBOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTs7QUFHQTtBQUNBO0FBRUE7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMQTtBQU9BOzs7Ozs7Ozs7Ozs7Ozs7O0FDM0dBO0FBR0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBTUE7QUFDQTs7QUFFQTtBQUNBO0FBRUE7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUpBO0FBT0E7QUFDQTs7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7O0FBS0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTEE7QUFRQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXJCQTs7QUF3QkE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUdBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVRBO0FBV0E7O0FBRUE7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7OztBQzNNQTtBQUVBO0FBQ0E7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBREE7QUFHQTtBQUxBO0FBT0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBREE7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQURBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBREE7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBVEE7O0FBV0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUVBO0FBQ0E7QUFDQTtBQURBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBREE7QUFHQTtBQUNBO0FBR0E7OztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUpBO0FBT0E7QUFFQTtBQUVBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQURBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFFQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBSUE7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUlBO0FBQ0E7QUFHQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFsQkE7QUFvQkE7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwY0E7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQU1BO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFNQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUZBO0FBSUE7Ozs7Ozs7Ozs7Ozs7OztBQzNDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFEQTtBQUlBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFEQTtBQUlBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBREE7QUFJQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBTUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMQTtBQU9BOzs7Ozs7Ozs7Ozs7Ozs7QUNsRkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFGQTtBQU9BOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKQTtBQU1BOzs7Ozs7Ozs7Ozs7Ozs7QUM3RkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVBBO0FBVUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBZEE7QUFpQkE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBUkE7QUFXQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMQTtBQVFBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBO0FBUUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTEE7QUFRQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTkE7QUFRQTs7Ozs7Ozs7Ozs7Ozs7OztBQ3RHQTtBQUdBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMQTs7QUFRQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBckJBO0FBdUJBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBS0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSkE7QUFNQTs7Ozs7Ozs7Ozs7Ozs7O0FDaEZBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTEE7O0FBUUE7QUFDQTtBQUNBO0FBQ0E7QUFEQTtBQUlBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUlBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFEQTtBQUlBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFOQTtBQVFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQURBOztBQUdBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBSEE7QUF2QkE7QUE4QkE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUhBO0FBdkJBO0FBK0JBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFLQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFOQTtBQVFBOzs7Ozs7Ozs7Ozs7Ozs7O0FDak9BO0FBR0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKQTtBQU9BO0FBQ0E7QUFDQTtBQUZBO0FBSUE7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsQkE7QUFHQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUpBOztBQU9BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFOQTtBQVFBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFyQkE7QUF1QkE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFmQTtBQWlCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBUEE7QUFTQTs7Ozs7Ozs7Ozs7Ozs7OztBQ2pJQTtBQUdBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMQTs7QUFRQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXJCQTtBQXVCQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVBBO0FBU0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBR0E7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTkE7QUFRQTs7Ozs7Ozs7Ozs7Ozs7O0FDckdBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFEQTtBQUdBOzs7Ozs7Ozs7Ozs7Ozs7QUNqQkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBOztBQUtBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFNQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQURBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQURBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBVEE7QUFXQTs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZJQTtBQUdBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTtBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQU1BO0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFkQTtBQWdCQTtBQUNBO0FBbkJBO0FBc0JBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBTUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUVBO0FBRUE7QUFFQTtBQUNBO0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBS0E7Ozs7Ozs7Ozs7Ozs7OztBQzFJQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMQTtBQVFBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBbEJBO0FBb0JBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWxCQTtBQW9CQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQUtBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBO0FBUUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMQTtBQVFBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFOQTtBQVFBOzs7Ozs7Ozs7Ozs7Ozs7QUN2SEE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFNQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMQTtBQVFBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFEQTtBQUlBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFiQTtBQWVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBR0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWJBO0FBZUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWpCQTtBQW1CQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBakJBO0FBbUJBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBS0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWEE7QUFhQTs7Ozs7Ozs7Ozs7Ozs7O0FDelBBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWxCQTtBQW9CQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQUtBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKQTtBQU1BOzs7Ozs7Ozs7Ozs7Ozs7QUN0RUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQU1BO0FBQ0E7O0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQTVCQTtBQThCQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBNUJBO0FBOEJBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFLQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU5BO0FBUUE7Ozs7Ozs7Ozs7Ozs7OztBQy9JQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBO0FBUUE7QUFDQTs7QUFFQTtBQUNBO0FBREE7QUFHQTs7Ozs7Ozs7Ozs7Ozs7O0FDbEJBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBRUE7QUFJQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVRBOztBQVdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFUQTs7QUFXQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFLQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQU1BO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBO0FBT0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6SEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBRUE7QUFDQTtBQUVBO0FBS0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSkE7QUFNQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKQTtBQU1BOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUpBO0FBTUE7O0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7QUFOQTtBQVNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQU1BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBTUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSkE7QUFPQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFLQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSkE7QUFPQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFLQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSkE7QUFPQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFLQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQURBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFZQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBS0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBTkE7QUFRQTs7QUFDQTtBQUNBO0FBREE7QUFHQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBcEJBO0FBc0JBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFSQTtBQVVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKQTtBQU9BO0FBQ0E7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQU5BO0FBUUE7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBTUE7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUdBO0FBQ0E7O0FBTUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBTEE7QUFXQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFNQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQUtBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVRBO0FBV0E7QUFDQTtBQWRBO0FBZ0JBOztBQUVBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUF2QkE7QUF5QkE7Ozs7Ozs7Ozs7Ozs7OztBQ2pnQkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVpBO0FBY0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUlBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWkE7QUFjQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBSUE7QUFDQTtBQUNBO0FBRUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUVBOztBQUdBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBTUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUVBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBTUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBUEE7QUFTQTs7Ozs7Ozs7Ozs7Ozs7O0FDaExBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNaQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKQTtBQU9BO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUVBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBZEE7QUFnQkE7QUFFQTs7O0FBQ0E7QUFFQTtBQUNBO0FBRkE7QUFLQTtBQUNBO0FBQ0E7QUFFQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqRkE7QUFJQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFJQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7QUMxakJBO0FBQ0E7QUFDQTtBQUNBOztBQUdBO0FBQUE7QUFBQTs7QUFDQTtBQUFBO0FBQUE7O0FBUEE7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUtBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBWEE7QUFhQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUdBOzs7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcEhBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQU1BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUdBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBRUE7QUFDQTs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQTNHQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDMUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBS0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKQTtBQU1BOztBQUVBO0FBQ0E7QUFDQTtBQWNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFTQTtBQUNBO0FBU0E7O0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFaQTtBQWdCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVpBOztBQWVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQVVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFHQTtBQUNBO0FBQ0E7QUFBQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFBQTs7QUFDQTtBQUFBOztBQUNBO0FBQUE7QUFIQTtBQUtBOztBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWpCQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM3VUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTs7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7O0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUVBOztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQUE7QUFFQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSkE7QUFNQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBR0E7QUFBQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7OztBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFOQTtBQVFBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBUEE7QUFVQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQURBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdGdCQTtBQUVBO0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBREE7QUFHQTtBQUNBO0FBQ0E7QUFBQTtBQURBO0FBSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBSUE7QUFDQTtBQUFBO0FBQUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFBQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFBQTtBQUFBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFBQTtBQUFBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTs7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQUE7QUFBQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUNBOztBQUNBO0FBQUE7QUFBQTs7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFiQTtBQWdCQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBaEJBO0FBa0JBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFDQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFHQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTEE7QUFPQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUhBO0FBS0E7QUFBQTtBQUdBO0FBQ0E7QUFDQTtBQU9BO0FBWUE7QUFwQkE7QUEyQkE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQW1CQTtBQXVDQTtBQUNBO0FBQ0E7QUFVQTtBQVVBO0FBTUE7QUFVQTtBQWxHQTtBQW9HQTtBQUVBO0FBQ0E7QUFDQTtBQURBO0FBS0E7QUFFQTtBQUNBO0FBQ0E7QUFJQTtBQU1BO0FBWEE7QUFnQkE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBOzs7Ozs7Ozs7O0FDdHJCQTs7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7OztBQ3ZCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7OztBQ1BBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7O0FDUEE7Ozs7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUNOQTtBQUNBO0FBQ0E7QUFDQTtBQUVBOztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9ub2RlX21vZHVsZXMvYXdlc29tZS1ub3RpZmljYXRpb25zL3NyYy9jb25zdGFudHMuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL25vZGVfbW9kdWxlcy9hd2Vzb21lLW5vdGlmaWNhdGlvbnMvc3JjL2VsZW0uanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL25vZGVfbW9kdWxlcy9hd2Vzb21lLW5vdGlmaWNhdGlvbnMvc3JjL2luZGV4LmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9ub2RlX21vZHVsZXMvYXdlc29tZS1ub3RpZmljYXRpb25zL3NyYy9vcHRpb25zLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9ub2RlX21vZHVsZXMvYXdlc29tZS1ub3RpZmljYXRpb25zL3NyYy9wb3B1cC5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vbm9kZV9tb2R1bGVzL2F3ZXNvbWUtbm90aWZpY2F0aW9ucy9zcmMvdGltZXIuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL25vZGVfbW9kdWxlcy9hd2Vzb21lLW5vdGlmaWNhdGlvbnMvc3JjL3RvYXN0LmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvYXBpL2FwaS1pbmRleC5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL2FwaS9jb21tb24uanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvY3BlL2NwZS5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL2FwaS9jcGUvbmF2ZXQuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvanVkZ2UvYWxwaGFKdWRnZS5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL2FwaS9tb2R1bGUuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvcGF5bWVudHMuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvcXVpei5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL2FwaS9zdG9yYWdlL2Fzc2Vzc21lbnRDb25maWcuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvc3RvcmFnZS9nZW5lcmljLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvYXBpL3N0b3JhZ2UvbW9kdWxlc0RhdGEuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvc3RvcmFnZS9wYXltZW50U3RhdHMuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvc3RvcmFnZS90ZW1wbGF0ZXMuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvc3RyZWFtL3N0cmVhbS5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL2FwaS9zdXJ2ZXkuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvdHJhaW5pbmdzL2Fzc2Vzc21lbnQuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvdHJhaW5pbmdzL2V2ZW50cy5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL2FwaS90cmFpbmluZ3MvZXhhbXMuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvdHJhaW5pbmdzL2dyb3Vwcy5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL2FwaS90cmFpbmluZ3MvbGVjdHVyZXMuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvdHJhaW5pbmdzL3NlbWluYXJzLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvYXBpL3RyYWluaW5ncy9za2lsbHMuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvdHJhaW5pbmdzL3RyYWluaW5ncy5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL2FwaS91c2Vycy5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL2FwaS91dGlsLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvdXRpbC9hcGktY29ubmVjdC5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL3V0aWwvYXBpLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvdXRpbC9jb250ZW50VHlwZXMuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy91dGlsL2pzeC1yZW5kZXItbW9kL2RvbS5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL3V0aWwvanN4LXJlbmRlci1tb2QvdXRpbHMuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy91dGlsL3BhcnNlLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvdXRpbC90ZW1wbGF0ZS5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL3V0aWwvdXRpbC5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vbm9kZV9tb2R1bGVzL2pzb241L2Rpc3QvaW5kZXgubWluLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS93ZWJwYWNrL3J1bnRpbWUvY29tcGF0IGdldCBkZWZhdWx0IGV4cG9ydCIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlL3dlYnBhY2svcnVudGltZS9kZWZpbmUgcHJvcGVydHkgZ2V0dGVycyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlL3dlYnBhY2svcnVudGltZS9oYXNPd25Qcm9wZXJ0eSBzaG9ydGhhbmQiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS93ZWJwYWNrL3J1bnRpbWUvbWFrZSBuYW1lc3BhY2Ugb2JqZWN0Iiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvYmxvZy9ibG9nLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IGxpYk5hbWUgPSBcImF3blwiXG5jb25zdCBwcmVmaXggPSB7XG4gIHBvcHVwOiBgJHtsaWJOYW1lfS1wb3B1cGAsXG4gIHRvYXN0OiBgJHtsaWJOYW1lfS10b2FzdGAsXG4gIGJ0bjogYCR7bGliTmFtZX0tYnRuYCxcbiAgY29uZmlybTogYCR7bGliTmFtZX0tY29uZmlybWBcbn1cblxuLy8gQ29uc3RhbnRzIGZvciB0b2FzdHNcbmV4cG9ydCBjb25zdCB0Q29uc3RzID0ge1xuICBwcmVmaXg6IHByZWZpeC50b2FzdCxcbiAga2xhc3M6IHtcbiAgICBsYWJlbDogYCR7cHJlZml4LnRvYXN0fS1sYWJlbGAsXG4gICAgY29udGVudDogYCR7cHJlZml4LnRvYXN0fS1jb250ZW50YCxcbiAgICBpY29uOiBgJHtwcmVmaXgudG9hc3R9LWljb25gLFxuICAgIHByb2dyZXNzQmFyOiBgJHtwcmVmaXgudG9hc3R9LXByb2dyZXNzLWJhcmAsXG4gICAgcHJvZ3Jlc3NCYXJQYXVzZTogYCR7cHJlZml4LnRvYXN0fS1wcm9ncmVzcy1iYXItcGF1c2VkYFxuICB9LFxuICBpZHM6IHtcbiAgICBjb250YWluZXI6IGAke3ByZWZpeC50b2FzdH0tY29udGFpbmVyYFxuICB9XG59XG5cbi8vIENvbnN0YW50cyBmb3IgcG9wdXBzXG5leHBvcnQgY29uc3QgbUNvbnN0cyA9IHtcbiAgcHJlZml4OiBwcmVmaXgucG9wdXAsXG4gIGtsYXNzOiB7XG4gICAgYnV0dG9uczogYCR7bGliTmFtZX0tYnV0dG9uc2AsXG4gICAgYnV0dG9uOiBwcmVmaXguYnRuLFxuICAgIHN1Y2Nlc3NCdG46IGAke3ByZWZpeC5idG59LXN1Y2Nlc3NgLFxuICAgIGNhbmNlbEJ0bjogYCR7cHJlZml4LmJ0bn0tY2FuY2VsYCxcbiAgICB0aXRsZTogYCR7cHJlZml4LnBvcHVwfS10aXRsZWAsXG4gICAgYm9keTogYCR7cHJlZml4LnBvcHVwfS1ib2R5YCxcbiAgICBjb250ZW50OiBgJHtwcmVmaXgucG9wdXB9LWNvbnRlbnRgLFxuICAgIGRvdEFuaW1hdGlvbjogYCR7cHJlZml4LnBvcHVwfS1sb2FkaW5nLWRvdHNgXG4gIH0sXG4gIGlkczoge1xuICAgIHdyYXBwZXI6IGAke3ByZWZpeC5wb3B1cH0td3JhcHBlcmAsXG4gICAgY29uZmlybU9rOiBgJHtwcmVmaXguY29uZmlybX0tb2tgLFxuICAgIGNvbmZpcm1DYW5jZWw6IGAke3ByZWZpeC5jb25maXJtfS1jYW5jZWxgXG4gIH1cbn1cblxuZXhwb3J0IGNvbnN0IGVDb25zdHMgPSB7XG4gIGtsYXNzOiB7XG4gICAgaGlkaW5nOiBgJHtsaWJOYW1lfS1oaWRpbmdgXG4gIH0sXG4gIGxpYjogbGliTmFtZVxufVxuIiwiaW1wb3J0IHtcbiAgICBlQ29uc3RzXG59IGZyb20gXCIuL2NvbnN0YW50c1wiXG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIHtcbiAgICBjb25zdHJ1Y3RvcihwYXJlbnQsIGlkLCBrbGFzcywgc3R5bGUsIG9wdGlvbnMpIHtcbiAgICAgICAgdGhpcy5uZXdOb2RlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JylcbiAgICAgICAgaWYgKGlkKSB0aGlzLm5ld05vZGUuaWQgPSBpZFxuICAgICAgICBpZiAoa2xhc3MpIHRoaXMubmV3Tm9kZS5jbGFzc05hbWUgPSBrbGFzc1xuICAgICAgICBpZiAoc3R5bGUpIHRoaXMubmV3Tm9kZS5zdHlsZS5jc3NUZXh0ID0gc3R5bGVcbiAgICAgICAgdGhpcy5wYXJlbnQgPSBwYXJlbnRcbiAgICAgICAgdGhpcy5vcHRpb25zID0gb3B0aW9uc1xuICAgIH1cbiAgICBiZWZvcmVJbnNlcnQoKSB7fVxuICAgIGFmdGVySW5zZXJ0KCkge31cbiAgICBpbnNlcnQoKSB7XG4gICAgICAgIHRoaXMuYmVmb3JlSW5zZXJ0KClcbiAgICAgICAgdGhpcy5lbCA9IHRoaXMucGFyZW50LmFwcGVuZENoaWxkKHRoaXMubmV3Tm9kZSlcbiAgICAgICAgdGhpcy5hZnRlckluc2VydCgpXG4gICAgICAgIHJldHVybiB0aGlzXG4gICAgfVxuXG4gICAgcmVwbGFjZShlbCkge1xuICAgICAgICBpZiAoIXRoaXMuZ2V0RWxlbWVudCgpKSByZXR1cm5cbiAgICAgICAgcmV0dXJuIHRoaXMuYmVmb3JlRGVsZXRlKCkudGhlbigoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnVwZGF0ZVR5cGUoZWwudHlwZSlcbiAgICAgICAgICAgIHRoaXMucGFyZW50LnJlcGxhY2VDaGlsZChlbC5uZXdOb2RlLCB0aGlzLmVsKVxuICAgICAgICAgICAgdGhpcy5lbCA9IHRoaXMuZ2V0RWxlbWVudChlbC5uZXdOb2RlKVxuICAgICAgICAgICAgdGhpcy5hZnRlckluc2VydCgpXG4gICAgICAgICAgICByZXR1cm4gdGhpc1xuICAgICAgICB9KVxuICAgIH1cblxuICAgIGJlZm9yZURlbGV0ZShlbCA9IHRoaXMuZWwpIHtcbiAgICAgICAgbGV0IHRpbWVMZWZ0ID0gMFxuICAgICAgICBpZiAodGhpcy5zdGFydCkge1xuICAgICAgICAgICAgdGltZUxlZnQgPSB0aGlzLm9wdGlvbnMubWluRHVyYXRpb25zW3RoaXMudHlwZV0gKyB0aGlzLnN0YXJ0IC0gRGF0ZS5ub3coKVxuICAgICAgICAgICAgaWYgKHRpbWVMZWZ0IDwgMCkgdGltZUxlZnQgPSAwXG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UocmVzb2x2ZSA9PiB7XG4gICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICBlbC5jbGFzc0xpc3QuYWRkKGVDb25zdHMua2xhc3MuaGlkaW5nKVxuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQocmVzb2x2ZSwgdGhpcy5vcHRpb25zLmFuaW1hdGlvbkR1cmF0aW9uKVxuICAgICAgICAgICAgfSwgdGltZUxlZnQpXG4gICAgICAgIH0pXG4gICAgfVxuXG4gICAgZGVsZXRlKGVsID0gdGhpcy5lbCkge1xuICAgICAgICBpZiAoIXRoaXMuZ2V0RWxlbWVudChlbCkpIHJldHVybiBudWxsXG4gICAgICAgIHJldHVybiB0aGlzLmJlZm9yZURlbGV0ZShlbCkudGhlbigoKSA9PiB7XG4gICAgICAgICAgICBlbC5yZW1vdmUoKVxuICAgICAgICAgICAgdGhpcy5hZnRlckRlbGV0ZSgpXG4gICAgICAgIH0pXG4gICAgfVxuICAgIGFmdGVyRGVsZXRlKCkge31cblxuICAgIGdldEVsZW1lbnQoZWwgPSB0aGlzLmVsKSB7XG4gICAgICAgIGlmICghZWwpIHJldHVybiBudWxsXG4gICAgICAgIHJldHVybiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChlbC5pZClcbiAgICB9XG5cbiAgICBhZGRFdmVudChuYW1lLCBmdW5jKSB7XG4gICAgICAgIHRoaXMuZWwuYWRkRXZlbnRMaXN0ZW5lcihuYW1lLCBmdW5jKVxuICAgIH1cblxuICAgIHRvZ2dsZUNsYXNzKGtsYXNzKSB7XG4gICAgICAgIHRoaXMuZWwuY2xhc3NMaXN0LnRvZ2dsZShrbGFzcylcbiAgICB9XG4gICAgdXBkYXRlVHlwZSh0eXBlKSB7XG4gICAgICAgIHRoaXMudHlwZSA9IHR5cGVcbiAgICAgICAgdGhpcy5kdXJhdGlvbiA9IHRoaXMub3B0aW9ucy5kdXJhdGlvbih0aGlzLnR5cGUpXG4gICAgfVxufSIsImltcG9ydCBPcHRpb25zIGZyb20gXCIuL29wdGlvbnNcIlxuaW1wb3J0IFRvYXN0IGZyb20gXCIuL3RvYXN0XCJcbmltcG9ydCBQb3B1cCBmcm9tIFwiLi9wb3B1cFwiXG5pbXBvcnQgRWxlbSBmcm9tIFwiLi9lbGVtXCJcblxuaW1wb3J0IHtcbiAgdENvbnN0c1xufSBmcm9tIFwiLi9jb25zdGFudHNcIlxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBOb3RpZmllciB7XG4gIGNvbnN0cnVjdG9yKG9wdGlvbnMgPSB7fSkge1xuICAgIHRoaXMub3B0aW9ucyA9IG5ldyBPcHRpb25zKG9wdGlvbnMpXG4gIH1cblxuICB0aXAobXNnLCBvcHRpb25zKSB7XG4gICAgcmV0dXJuIHRoaXMuX2FkZFRvYXN0KG1zZywgXCJ0aXBcIiwgb3B0aW9ucykuZWxcbiAgfVxuXG4gIGluZm8obXNnLCBvcHRpb25zKSB7XG4gICAgcmV0dXJuIHRoaXMuX2FkZFRvYXN0KG1zZywgXCJpbmZvXCIsIG9wdGlvbnMpLmVsXG4gIH1cblxuICBzdWNjZXNzKG1zZywgb3B0aW9ucykge1xuICAgIHJldHVybiB0aGlzLl9hZGRUb2FzdChtc2csIFwic3VjY2Vzc1wiLCBvcHRpb25zKS5lbFxuICB9XG5cbiAgd2FybmluZyhtc2csIG9wdGlvbnMpIHtcbiAgICByZXR1cm4gdGhpcy5fYWRkVG9hc3QobXNnLCBcIndhcm5pbmdcIiwgb3B0aW9ucykuZWxcbiAgfVxuXG4gIGFsZXJ0KG1zZywgb3B0aW9ucykge1xuICAgIHJldHVybiB0aGlzLl9hZGRUb2FzdChtc2csIFwiYWxlcnRcIiwgb3B0aW9ucykuZWxcbiAgfVxuXG4gIGFzeW5jIChwcm9taXNlLCBvblJlc29sdmUsIG9uUmVqZWN0LCBtc2csIG9wdGlvbnMpIHtcbiAgICBsZXQgYXN5bmNUb2FzdCA9IHRoaXMuX2FkZFRvYXN0KG1zZywgXCJhc3luY1wiLCBvcHRpb25zKVxuICAgIHJldHVybiB0aGlzLl9hZnRlckFzeW5jKHByb21pc2UsIG9uUmVzb2x2ZSwgb25SZWplY3QsIG9wdGlvbnMsIGFzeW5jVG9hc3QpXG4gIH1cblxuICBjb25maXJtKG1zZywgb25Paywgb25DYW5jZWwsIG9wdGlvbnMpIHtcbiAgICByZXR1cm4gdGhpcy5fYWRkUG9wdXAobXNnLCBcImNvbmZpcm1cIiwgb3B0aW9ucywgb25Paywgb25DYW5jZWwpXG4gIH1cblxuICBhc3luY0Jsb2NrKHByb21pc2UsIG9uUmVzb2x2ZSwgb25SZWplY3QsIG1zZywgb3B0aW9ucykge1xuICAgIGxldCBhc3luY0Jsb2NrID0gdGhpcy5fYWRkUG9wdXAobXNnLCBcImFzeW5jLWJsb2NrXCIsIG9wdGlvbnMpXG4gICAgcmV0dXJuIHRoaXMuX2FmdGVyQXN5bmMocHJvbWlzZSwgb25SZXNvbHZlLCBvblJlamVjdCwgb3B0aW9ucywgYXN5bmNCbG9jaylcbiAgfVxuXG4gIG1vZGFsKG1zZywgY2xhc3NOYW1lLCBvcHRpb25zKSB7XG4gICAgcmV0dXJuIHRoaXMuX2FkZFBvcHVwKG1zZywgY2xhc3NOYW1lLCBvcHRpb25zKVxuICB9XG5cbiAgY2xvc2VUb2FzdHMoKSB7XG4gICAgbGV0IGMgPSB0aGlzLmNvbnRhaW5lclxuICAgIHdoaWxlIChjLmZpcnN0Q2hpbGQpIHtcbiAgICAgIGMucmVtb3ZlQ2hpbGQoYy5maXJzdENoaWxkKVxuICAgIH1cbiAgfVxuXG4gIC8vIFRvb2xzXG4gIF9hZGRQb3B1cChtc2csIGNsYXNzTmFtZSwgb3B0aW9ucywgb25Paywgb25DYW5jZWwpIHtcbiAgICByZXR1cm4gbmV3IFBvcHVwKG1zZywgY2xhc3NOYW1lLCB0aGlzLm9wdGlvbnMub3ZlcnJpZGUob3B0aW9ucyksIG9uT2ssIG9uQ2FuY2VsKVxuICB9XG5cbiAgX2FkZFRvYXN0KG1zZywgdHlwZSwgb3B0aW9ucywgb2xkKSB7XG4gICAgb3B0aW9ucyA9IHRoaXMub3B0aW9ucy5vdmVycmlkZShvcHRpb25zKVxuICAgIGxldCBuZXdUb2FzdCA9IG5ldyBUb2FzdChtc2csIHR5cGUsIG9wdGlvbnMsIHRoaXMuY29udGFpbmVyKVxuICAgIGlmIChvbGQpIHtcbiAgICAgIGlmIChvbGQgaW5zdGFuY2VvZiBQb3B1cCkgcmV0dXJuIG9sZC5kZWxldGUoKS50aGVuKCgpID0+IG5ld1RvYXN0Lmluc2VydCgpKVxuICAgICAgbGV0IGkgPSBvbGQucmVwbGFjZShuZXdUb2FzdClcbiAgICAgIHJldHVybiBpXG4gICAgfVxuICAgIHJldHVybiBuZXdUb2FzdC5pbnNlcnQoKVxuICB9XG5cbiAgX2FmdGVyQXN5bmMocHJvbWlzZSwgb25SZXNvbHZlLCBvblJlamVjdCwgb3B0aW9ucywgb2xkRWxlbWVudCkge1xuICAgIHJldHVybiBwcm9taXNlLnRoZW4oXG4gICAgICB0aGlzLl9yZXNwb25zZUhhbmRsZXIob25SZXNvbHZlLCBcInN1Y2Nlc3NcIiwgb3B0aW9ucywgb2xkRWxlbWVudCksXG4gICAgICB0aGlzLl9yZXNwb25zZUhhbmRsZXIob25SZWplY3QsIFwiYWxlcnRcIiwgb3B0aW9ucywgb2xkRWxlbWVudClcbiAgICApXG4gIH1cblxuICBfcmVzcG9uc2VIYW5kbGVyKHBheWxvYWQsIHRvYXN0TmFtZSwgb3B0aW9ucywgb2xkRWxlbWVudCkge1xuICAgIHJldHVybiByZXN1bHQgPT4ge1xuICAgICAgc3dpdGNoICh0eXBlb2YgcGF5bG9hZCkge1xuICAgICAgICBjYXNlICd1bmRlZmluZWQnOlxuICAgICAgICBjYXNlICdzdHJpbmcnOlxuICAgICAgICAgIGxldCBtc2cgPSB0b2FzdE5hbWUgPT09ICdhbGVydCcgPyBwYXlsb2FkIHx8IHJlc3VsdCA6IHBheWxvYWRcbiAgICAgICAgICB0aGlzLl9hZGRUb2FzdChtc2csIHRvYXN0TmFtZSwgb3B0aW9ucywgb2xkRWxlbWVudClcbiAgICAgICAgICBicmVha1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgIG9sZEVsZW1lbnQuZGVsZXRlKCkudGhlbigoKSA9PiB7XG4gICAgICAgICAgICBpZiAocGF5bG9hZCkgcGF5bG9hZChyZXN1bHQpXG4gICAgICAgICAgfSlcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBfY3JlYXRlQ29udGFpbmVyKCkge1xuICAgIHJldHVybiBuZXcgRWxlbShkb2N1bWVudC5ib2R5LCB0Q29uc3RzLmlkcy5jb250YWluZXIsIGBhd24tJHt0aGlzLm9wdGlvbnMucG9zaXRpb259YCkuaW5zZXJ0KCkuZWxcbiAgfVxuXG4gIGdldCBjb250YWluZXIoKSB7XG4gICAgcmV0dXJuIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKHRDb25zdHMuaWRzLmNvbnRhaW5lcikgfHwgdGhpcy5fY3JlYXRlQ29udGFpbmVyKClcbiAgfVxufVxuIiwiY29uc3QgZGVmYXVsdHMgPSB7XG4gIG1heE5vdGlmaWNhdGlvbnM6IDEwLFxuICBhbmltYXRpb25EdXJhdGlvbjogMzAwLFxuICBwb3NpdGlvbjogXCJib3R0b20tcmlnaHRcIixcbiAgbGFiZWxzOiB7XG4gICAgdGlwOiBcIlRpcFwiLFxuICAgIGluZm86IFwiSW5mb1wiLFxuICAgIHN1Y2Nlc3M6IFwiU3VjY2Vzc1wiLFxuICAgIHdhcm5pbmc6IFwiQXR0ZW50aW9uXCIsXG4gICAgYWxlcnQ6IFwiRXJyb3JcIixcbiAgICBhc3luYzogXCJMb2FkaW5nXCIsXG4gICAgY29uZmlybTogXCJDb25maXJtYXRpb24gcmVxdWlyZWRcIixcbiAgICBjb25maXJtT2s6IFwiT0tcIixcbiAgICBjb25maXJtQ2FuY2VsOiBcIkNhbmNlbFwiXG4gIH0sXG4gIGljb25zOiB7XG4gICAgdGlwOiBcInF1ZXN0aW9uLWNpcmNsZVwiLFxuICAgIGluZm86IFwiaW5mby1jaXJjbGVcIixcbiAgICBzdWNjZXNzOiBcImNoZWNrLWNpcmNsZVwiLFxuICAgIHdhcm5pbmc6IFwiZXhjbGFtYXRpb24tY2lyY2xlXCIsXG4gICAgYWxlcnQ6IFwiZXhjbGFtYXRpb24tdHJpYW5nbGVcIixcbiAgICBhc3luYzogXCJjb2cgZmEtc3BpblwiLFxuICAgIGNvbmZpcm06IFwiZXhjbGFtYXRpb24tdHJpYW5nbGVcIixcbiAgICBwcmVmaXg6IFwiPGkgY2xhc3M9J2ZhIGZhcyBmYS1mdyBmYS1cIixcbiAgICBzdWZmaXg6IFwiJz48L2k+XCIsXG4gICAgZW5hYmxlZDogdHJ1ZVxuICB9LFxuICByZXBsYWNlbWVudHM6IHtcbiAgICB0aXA6IG51bGwsXG4gICAgaW5mbzogbnVsbCxcbiAgICBzdWNjZXNzOiBudWxsLFxuICAgIHdhcm5pbmc6IG51bGwsXG4gICAgYWxlcnQ6IG51bGwsXG4gICAgYXN5bmM6IG51bGwsXG4gICAgXCJhc3luYy1ibG9ja1wiOiBudWxsLFxuICAgIG1vZGFsOiBudWxsLFxuICAgIGNvbmZpcm06IG51bGwsXG4gICAgZ2VuZXJhbDoge1xuICAgICAgXCI8c2NyaXB0PlwiOiBcIlwiLFxuICAgICAgXCI8L3NjcmlwdD5cIjogXCJcIlxuICAgIH1cbiAgfSxcbiAgbWVzc2FnZXM6IHtcbiAgICB0aXA6IFwiXCIsXG4gICAgaW5mbzogXCJcIixcbiAgICBzdWNjZXNzOiBcIkFjdGlvbiBoYXMgYmVlbiBzdWNjZWVkZWRcIixcbiAgICB3YXJuaW5nOiBcIlwiLFxuICAgIGFsZXJ0OiBcIkFjdGlvbiBoYXMgYmVlbiBmYWlsZWRcIixcbiAgICBjb25maXJtOiBcIlRoaXMgYWN0aW9uIGNhbid0IGJlIHVuZG9uZS4gQ29udGludWU/XCIsXG4gICAgYXN5bmM6IFwiUGxlYXNlLCB3YWl0Li4uXCIsXG4gICAgXCJhc3luYy1ibG9ja1wiOiBcIkxvYWRpbmdcIlxuICB9LFxuICBmb3JtYXRFcnJvcihlcnIpIHtcbiAgICBpZiAoZXJyLnJlc3BvbnNlKSB7XG4gICAgICBpZiAoIWVyci5yZXNwb25zZS5kYXRhKSByZXR1cm4gJzUwMCBBUEkgU2VydmVyIEVycm9yJ1xuICAgICAgaWYgKGVyci5yZXNwb25zZS5kYXRhLmVycm9ycykge1xuICAgICAgICByZXR1cm4gZXJyLnJlc3BvbnNlLmRhdGEuZXJyb3JzLm1hcChvID0+IG8uZGV0YWlsKS5qb2luKCc8YnI+JylcbiAgICAgIH1cbiAgICAgIGlmIChlcnIucmVzcG9uc2Uuc3RhdHVzVGV4dCkge1xuICAgICAgICByZXR1cm4gYCR7ZXJyLnJlc3BvbnNlLnN0YXR1c30gJHtlcnIucmVzcG9uc2Uuc3RhdHVzVGV4dH06ICR7ZXJyLnJlc3BvbnNlLmRhdGF9YFxuICAgICAgfVxuICAgIH1cbiAgICBpZiAoZXJyLm1lc3NhZ2UpIHJldHVybiBlcnIubWVzc2FnZVxuICAgIHJldHVybiBlcnJcbiAgfSxcbiAgZHVyYXRpb25zOiB7XG4gICAgZ2xvYmFsOiA1MDAwLFxuICAgIHN1Y2Nlc3M6IG51bGwsXG4gICAgaW5mbzogbnVsbCxcbiAgICB0aXA6IG51bGwsXG4gICAgd2FybmluZzogbnVsbCxcbiAgICBhbGVydDogbnVsbFxuICB9LFxuICBtaW5EdXJhdGlvbnM6IHtcbiAgICBhc3luYzogMTAwMCxcbiAgICBcImFzeW5jLWJsb2NrXCI6IDEwMDBcbiAgfSxcbn1cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE9wdGlvbnMge1xuICBjb25zdHJ1Y3RvcihvcHRpb25zID0ge30sIGdsb2JhbCA9IGRlZmF1bHRzKSB7XG4gICAgT2JqZWN0LmFzc2lnbih0aGlzLCB0aGlzLmRlZmF1bHRzRGVlcChnbG9iYWwsIG9wdGlvbnMpKVxuICB9XG5cbiAgaWNvbih0eXBlKSB7XG4gICAgaWYgKHRoaXMuaWNvbnMuZW5hYmxlZCkgcmV0dXJuIGAke3RoaXMuaWNvbnMucHJlZml4fSR7dGhpcy5pY29uc1t0eXBlXX0ke3RoaXMuaWNvbnMuc3VmZml4fWBcbiAgICByZXR1cm4gJydcbiAgfVxuXG4gIGxhYmVsKHR5cGUpIHtcbiAgICByZXR1cm4gdGhpcy5sYWJlbHNbdHlwZV1cbiAgfVxuXG4gIGR1cmF0aW9uKHR5cGUpIHtcbiAgICBsZXQgZHVyYXRpb24gPSB0aGlzLmR1cmF0aW9uc1t0eXBlXVxuICAgIHJldHVybiBkdXJhdGlvbiA9PT0gbnVsbCA/IHRoaXMuZHVyYXRpb25zLmdsb2JhbCA6IGR1cmF0aW9uXG4gIH1cblxuICB0b1NlY3ModmFsdWUpIHtcbiAgICByZXR1cm4gYCR7dmFsdWUgLyAxMDAwfXNgXG4gIH1cblxuICBhcHBseVJlcGxhY2VtZW50cyhzdHIsIHR5cGUpIHtcbiAgICBpZiAoIXN0cikgcmV0dXJuIHRoaXMubWVzc2FnZXNbdHlwZV0gfHwgXCJcIlxuICAgIGZvciAoY29uc3QgbiBvZiBbJ2dlbmVyYWwnLCB0eXBlXSkge1xuICAgICAgaWYgKCF0aGlzLnJlcGxhY2VtZW50c1tuXSkgY29udGludWVcbiAgICAgIGZvciAoY29uc3QgayBpbiB0aGlzLnJlcGxhY2VtZW50c1tuXSkge1xuICAgICAgICBzdHIgPSBzdHIucmVwbGFjZShrLCB0aGlzLnJlcGxhY2VtZW50c1tuXVtrXSlcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHN0clxuICB9XG5cbiAgb3ZlcnJpZGUob3B0aW9ucykge1xuICAgIGlmIChvcHRpb25zKSByZXR1cm4gbmV3IE9wdGlvbnMob3B0aW9ucywgdGhpcylcbiAgICByZXR1cm4gdGhpc1xuICB9XG5cbiAgZGVmYXVsdHNEZWVwKGRlZmF1bHRzLCBvdmVycmlkZXMpIHtcbiAgICBsZXQgcmVzdWx0ID0ge31cbiAgICBmb3IgKGNvbnN0IGsgaW4gZGVmYXVsdHMpIHtcbiAgICAgIGlmIChvdmVycmlkZXMuaGFzT3duUHJvcGVydHkoaykpIHtcbiAgICAgICAgcmVzdWx0W2tdID0gdHlwZW9mIGRlZmF1bHRzW2tdID09PSBcIm9iamVjdFwiICYmIGRlZmF1bHRzW2tdICE9PSBudWxsID8gdGhpcy5kZWZhdWx0c0RlZXAoZGVmYXVsdHNba10sIG92ZXJyaWRlc1trXSkgOiBvdmVycmlkZXNba11cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlc3VsdFtrXSA9IGRlZmF1bHRzW2tdXG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiByZXN1bHRcbiAgfVxufVxuIiwiaW1wb3J0IEVsZW0gZnJvbSBcIi4vZWxlbVwiXG5pbXBvcnQge1xuICBtQ29uc3RzXG59IGZyb20gXCIuL2NvbnN0YW50c1wiXG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIGV4dGVuZHMgRWxlbSB7XG4gIGNvbnN0cnVjdG9yKG1zZywgdHlwZSA9ICdtb2RhbCcsIG9wdGlvbnMsIG9uT2ssIG9uQ2FuY2VsKSB7XG4gICAgbGV0IGFuaW1hdGlvbkR1cmF0aW9uID0gYGFuaW1hdGlvbi1kdXJhdGlvbjogJHtvcHRpb25zLnRvU2VjcyhvcHRpb25zLmFuaW1hdGlvbkR1cmF0aW9uKX07YFxuICAgIHN1cGVyKGRvY3VtZW50LmJvZHksIG1Db25zdHMuaWRzLndyYXBwZXIsIG51bGwsIGFuaW1hdGlvbkR1cmF0aW9uLCBvcHRpb25zKVxuICAgIHRoaXNbbUNvbnN0cy5pZHMuY29uZmlybU9rXSA9IG9uT2tcbiAgICB0aGlzW21Db25zdHMuaWRzLmNvbmZpcm1DYW5jZWxdID0gb25DYW5jZWxcbiAgICB0aGlzLmNsYXNzTmFtZSA9IGAke21Db25zdHMucHJlZml4fS0ke3R5cGV9YFxuICAgIGlmICghWydjb25maXJtJywgJ2FzeW5jLWJsb2NrJywgJ21vZGFsJ10uaW5jbHVkZXModHlwZSkpIHR5cGUgPSAnbW9kYWwnXG4gICAgdGhpcy51cGRhdGVUeXBlKHR5cGUpXG4gICAgdGhpcy5zZXRJbm5lckh0bWwobXNnKVxuICAgIHRoaXMuaW5zZXJ0KClcbiAgfVxuXG4gIHNldElubmVySHRtbChodG1sKSB7XG4gICAgbGV0IGlubmVySFRNTCA9IHRoaXMub3B0aW9ucy5hcHBseVJlcGxhY2VtZW50cyhodG1sLCB0aGlzLnR5cGUpXG4gICAgc3dpdGNoICh0aGlzLnR5cGUpIHtcbiAgICAgIGNhc2UgXCJjb25maXJtXCI6XG4gICAgICAgIGxldCBidXR0b25zID0gW2A8YnV0dG9uIGNsYXNzPScke21Db25zdHMua2xhc3MuYnV0dG9ufSAke21Db25zdHMua2xhc3Muc3VjY2Vzc0J0bn0naWQ9JyR7bUNvbnN0cy5pZHMuY29uZmlybU9rfSc+JHt0aGlzLm9wdGlvbnMubGFiZWxzLmNvbmZpcm1Pa308L2J1dHRvbj5gXVxuICAgICAgICBpZiAodGhpc1ttQ29uc3RzLmlkcy5jb25maXJtQ2FuY2VsXSAhPT0gZmFsc2UpIHtcbiAgICAgICAgICBidXR0b25zLnB1c2goYDxidXR0b24gY2xhc3M9JyR7bUNvbnN0cy5rbGFzcy5idXR0b259ICR7bUNvbnN0cy5rbGFzcy5jYW5jZWxCdG59J2lkPScke21Db25zdHMuaWRzLmNvbmZpcm1DYW5jZWx9Jz4ke3RoaXMub3B0aW9ucy5sYWJlbHMuY29uZmlybUNhbmNlbH08L2J1dHRvbj5gKVxuICAgICAgICB9XG4gICAgICAgIGlubmVySFRNTCA9IGAke3RoaXMub3B0aW9ucy5pY29uKHRoaXMudHlwZSl9PGRpdiBjbGFzcz0nJHttQ29uc3RzLmtsYXNzLnRpdGxlfSc+JHt0aGlzLm9wdGlvbnMubGFiZWwodGhpcy50eXBlKX08L2Rpdj48ZGl2IGNsYXNzPVwiJHttQ29uc3RzLmtsYXNzLmNvbnRlbnR9XCI+JHtpbm5lckhUTUx9PC9kaXY+PGRpdiBjbGFzcz0nJHttQ29uc3RzLmtsYXNzLmJ1dHRvbnN9ICR7bUNvbnN0cy5rbGFzcy5idXR0b25zfS0ke2J1dHRvbnMubGVuZ3RofSc+JHtidXR0b25zLmpvaW4oJycpfTwvZGl2PmBcbiAgICAgICAgYnJlYWtcbiAgICAgIGNhc2UgXCJhc3luYy1ibG9ja1wiOlxuICAgICAgICBpbm5lckhUTUwgPSBgJHtpbm5lckhUTUx9PGRpdiBjbGFzcz1cIiR7bUNvbnN0cy5rbGFzcy5kb3RBbmltYXRpb259XCI+PC9kaXY+YFxuICAgIH1cbiAgICB0aGlzLm5ld05vZGUuaW5uZXJIVE1MID0gYDxkaXYgY2xhc3M9XCIke21Db25zdHMua2xhc3MuYm9keX0gJHt0aGlzLmNsYXNzTmFtZX1cIj4ke2lubmVySFRNTH08L2Rpdj5gXG4gIH1cblxuICBrZXl1cExpc3RlbmVyKGUpIHtcbiAgICBpZiAodGhpcy50eXBlID09PSAnYXN5bmMtYmxvY2snKSByZXR1cm4gZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgc3dpdGNoIChlLmNvZGUpIHtcbiAgICAgIGNhc2UgJ0VzY2FwZSc6XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgICB0aGlzLmRlbGV0ZSgpXG4gICAgICBjYXNlICdUYWInOlxuICAgICAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICAgICAgaWYgKHRoaXMudHlwZSAhPT0gJ2NvbmZpcm0nIHx8IHRoaXNbbUNvbnN0cy5pZHMuY29uZmlybUNhbmNlbF0gPT09IGZhbHNlKSByZXR1cm4gdHJ1ZVxuICAgICAgICBsZXQgbmV4dCA9IHRoaXMub2tCdG5cbiAgICAgICAgaWYgKGUuc2hpZnRLZXkpIHtcbiAgICAgICAgICBpZiAoZG9jdW1lbnQuYWN0aXZlRWxlbWVudC5pZCA9PSBtQ29uc3RzLmlkcy5jb25maXJtT2spIG5leHQgPSB0aGlzLmNhbmNlbEJ0blxuICAgICAgICB9IGVsc2UgaWYgKGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQuaWQgIT09IG1Db25zdHMuaWRzLmNvbmZpcm1DYW5jZWwpIG5leHQgPSB0aGlzLmNhbmNlbEJ0blxuICAgICAgICBuZXh0LmZvY3VzKClcbiAgICB9XG4gIH1cbiAgYWZ0ZXJJbnNlcnQoKSB7XG4gICAgdGhpcy5saXN0ZW5lciA9IGUgPT4gdGhpcy5rZXl1cExpc3RlbmVyKGUpXG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIHRoaXMubGlzdGVuZXIpXG4gICAgc3dpdGNoICh0aGlzLnR5cGUpIHtcbiAgICAgIGNhc2UgJ2FzeW5jLWJsb2NrJzpcbiAgICAgICAgdGhpcy5zdGFydCA9IERhdGUubm93KClcbiAgICAgICAgYnJlYWtcbiAgICAgIGNhc2UgJ2NvbmZpcm0nOlxuICAgICAgICB0aGlzLm9rQnRuLmZvY3VzKClcbiAgICAgICAgdGhpcy5hZGRFdmVudChcImNsaWNrXCIsIGUgPT4ge1xuICAgICAgICAgIGlmIChlLnRhcmdldC5ub2RlTmFtZSAhPT0gXCJCVVRUT05cIikgcmV0dXJuIGZhbHNlXG4gICAgICAgICAgdGhpcy5kZWxldGUoKVxuICAgICAgICAgIGlmICh0aGlzW2UudGFyZ2V0LmlkXSkgdGhpc1tlLnRhcmdldC5pZF0oKVxuICAgICAgICB9KVxuICAgICAgICBicmVha1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgZG9jdW1lbnQuYWN0aXZlRWxlbWVudC5ibHVyKClcbiAgICAgICAgdGhpcy5hZGRFdmVudChcImNsaWNrXCIsIGUgPT4ge1xuICAgICAgICAgIGlmIChlLnRhcmdldC5pZCA9PT0gdGhpcy5uZXdOb2RlLmlkKSB0aGlzLmRlbGV0ZSgpXG4gICAgICAgIH0pXG4gICAgfVxuICB9XG5cbiAgYWZ0ZXJEZWxldGUoKSB7XG4gICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIHRoaXMubGlzdGVuZXIpXG4gIH1cblxuICBnZXQgb2tCdG4oKSB7XG4gICAgcmV0dXJuIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKG1Db25zdHMuaWRzLmNvbmZpcm1PaylcbiAgfVxuXG4gIGdldCBjYW5jZWxCdG4oKSB7XG4gICAgcmV0dXJuIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKG1Db25zdHMuaWRzLmNvbmZpcm1DYW5jZWwpXG4gIH1cbn1cbiIsImV4cG9ydCBkZWZhdWx0IGNsYXNzIHtcbiAgY29uc3RydWN0b3IoY2FsbGJhY2ssIGRlbGF5KSB7XG4gICAgdGhpcy5jYWxsYmFjayA9IGNhbGxiYWNrXG4gICAgdGhpcy5yZW1haW5pbmcgPSBkZWxheVxuICAgIHRoaXMucmVzdW1lKClcbiAgfVxuICBwYXVzZSgpIHtcbiAgICB0aGlzLnBhdXNlZCA9IHRydWVcbiAgICB3aW5kb3cuY2xlYXJUaW1lb3V0KHRoaXMudGltZXJJZClcbiAgICB0aGlzLnJlbWFpbmluZyAtPSBuZXcgRGF0ZSgpIC0gdGhpcy5zdGFydFxuICB9XG4gIHJlc3VtZSgpIHtcbiAgICB0aGlzLnBhdXNlZCA9IGZhbHNlXG4gICAgdGhpcy5zdGFydCA9IG5ldyBEYXRlKClcbiAgICB3aW5kb3cuY2xlYXJUaW1lb3V0KHRoaXMudGltZXJJZClcbiAgICB0aGlzLnRpbWVySWQgPSB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICB3aW5kb3cuY2xlYXJUaW1lb3V0KHRoaXMudGltZXJJZClcbiAgICAgIHRoaXMuY2FsbGJhY2soKVxuICAgIH0sIHRoaXMucmVtYWluaW5nKVxuICB9XG4gIHRvZ2dsZSgpIHtcbiAgICBpZiAodGhpcy5wYXVzZWQpIHRoaXMucmVzdW1lKClcbiAgICBlbHNlIHRoaXMucGF1c2UoKVxuICB9XG59XG4iLCJpbXBvcnQgRWxlbSBmcm9tIFwiLi9lbGVtXCJcbmltcG9ydCBUaW1lciBmcm9tIFwiLi90aW1lclwiXG5cbmltcG9ydCB7XG4gIHRDb25zdHMsXG4gIGVDb25zdHNcbn0gZnJvbSBcIi4vY29uc3RhbnRzXCJcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgZXh0ZW5kcyBFbGVtIHtcbiAgY29uc3RydWN0b3IobXNnLCB0eXBlLCBvcHRpb25zLCBwYXJlbnQpIHtcbiAgICBzdXBlcihcbiAgICAgIHBhcmVudCxcbiAgICAgIGAke3RDb25zdHMucHJlZml4fS0ke01hdGguZmxvb3IoRGF0ZS5ub3coKSAtIE1hdGgucmFuZG9tKCkgKiAxMDApfWAsXG4gICAgICBgJHt0Q29uc3RzLnByZWZpeH0gJHt0Q29uc3RzLnByZWZpeH0tJHt0eXBlfWAsXG4gICAgICBgYW5pbWF0aW9uLWR1cmF0aW9uOiAke29wdGlvbnMudG9TZWNzKG9wdGlvbnMuYW5pbWF0aW9uRHVyYXRpb24pfTtgLFxuICAgICAgb3B0aW9uc1xuICAgIClcbiAgICB0aGlzLnVwZGF0ZVR5cGUodHlwZSlcbiAgICB0aGlzLnNldElubmVySHRtbChtc2cpXG4gIH1cblxuICBzZXRJbm5lckh0bWwoaHRtbCkge1xuICAgIGlmICh0aGlzLnR5cGUgPT09ICdhbGVydCcgJiYgaHRtbCkgaHRtbCA9IHRoaXMub3B0aW9ucy5mb3JtYXRFcnJvcihodG1sKVxuICAgIGh0bWwgPSB0aGlzLm9wdGlvbnMuYXBwbHlSZXBsYWNlbWVudHMoaHRtbCwgdGhpcy50eXBlKVxuICAgIHRoaXMubmV3Tm9kZS5pbm5lckhUTUwgPSBgPGRpdiBjbGFzcz1cImF3bi10b2FzdC13cmFwcGVyXCI+JHt0aGlzLnByb2dyZXNzQmFyfSR7dGhpcy5sYWJlbH08ZGl2IGNsYXNzPVwiJHt0Q29uc3RzLmtsYXNzLmNvbnRlbnR9XCI+JHtodG1sfTwvZGl2PjxzcGFuIGNsYXNzPVwiJHt0Q29uc3RzLmtsYXNzLmljb259XCI+JHt0aGlzLm9wdGlvbnMuaWNvbih0aGlzLnR5cGUpfTwvc3Bhbj48L2Rpdj5gXG4gIH1cblxuICBiZWZvcmVJbnNlcnQoKSB7XG4gICAgaWYgKHRoaXMucGFyZW50LmNoaWxkRWxlbWVudENvdW50ID49IHRoaXMub3B0aW9ucy5tYXhOb3RpZmljYXRpb25zKSB7XG4gICAgICBsZXQgZWxlbWVudHMgPSBBcnJheS5mcm9tKHRoaXMucGFyZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUodENvbnN0cy5wcmVmaXgpKVxuICAgICAgdGhpcy5kZWxldGUoZWxlbWVudHMuZmluZChlID0+ICF0aGlzLmlzRGVsZXRlZChlKSkpXG4gICAgfVxuICB9XG4gIGFmdGVySW5zZXJ0KCkge1xuICAgIGlmICh0aGlzLnR5cGUgPT0gXCJhc3luY1wiKSByZXR1cm4gdGhpcy5zdGFydCA9IERhdGUubm93KClcblxuICAgIHRoaXMuYWRkRXZlbnQoXCJjbGlja1wiLCAoKSA9PiB0aGlzLmRlbGV0ZSgpKVxuXG4gICAgaWYgKHRoaXMuZHVyYXRpb24gPD0gMCkgcmV0dXJuXG4gICAgdGhpcy50aW1lciA9IG5ldyBUaW1lcigoKSA9PiB0aGlzLmRlbGV0ZSgpLCB0aGlzLmR1cmF0aW9uKVxuICAgIGZvciAoY29uc3QgZSBvZiBbXCJtb3VzZWVudGVyXCIsIFwibW91c2VsZWF2ZVwiXSkge1xuICAgICAgdGhpcy5hZGRFdmVudChlLCAoKSA9PiB7XG4gICAgICAgIGlmICh0aGlzLmlzRGVsZXRlZCgpKSByZXR1cm5cbiAgICAgICAgdGhpcy50b2dnbGVDbGFzcyh0Q29uc3RzLmtsYXNzLnByb2dyZXNzQmFyUGF1c2UpXG4gICAgICAgIHRoaXMudGltZXIudG9nZ2xlKClcbiAgICAgIH0pXG4gICAgfVxuICB9XG5cbiAgaXNEZWxldGVkKGVsID0gdGhpcy5lbCkge1xuICAgIHJldHVybiBlbC5jbGFzc0xpc3QuY29udGFpbnMoZUNvbnN0cy5rbGFzcy5oaWRpbmcpXG4gIH1cbiAgZ2V0IHByb2dyZXNzQmFyKCkge1xuICAgIGlmICh0aGlzLmR1cmF0aW9uIDw9IDAgfHwgdGhpcy50eXBlID09PSAnYXN5bmMnKSByZXR1cm4gXCJcIlxuICAgIHJldHVybiBgPGRpdiBjbGFzcz0nJHt0Q29uc3RzLmtsYXNzLnByb2dyZXNzQmFyfScgc3R5bGU9XCJhbmltYXRpb24tZHVyYXRpb246JHt0aGlzLm9wdGlvbnMudG9TZWNzKHRoaXMuZHVyYXRpb24pfTtcIj48L2Rpdj5gXG4gIH1cbiAgZ2V0IGxhYmVsKCkge1xuICAgIHJldHVybiBgPGIgY2xhc3M9XCIke3RDb25zdHMua2xhc3MubGFiZWx9XCI+JHt0aGlzLm9wdGlvbnMubGFiZWwodGhpcy50eXBlKX08L2I+YFxuICB9XG5cbn1cbiIsImltcG9ydCBjb3Vyc2VBcGkgZnJvbSAnLi90cmFpbmluZ3MvdHJhaW5pbmdzJztcclxuaW1wb3J0IG1vZHVsZUFwaSBmcm9tICcuL21vZHVsZSc7XHJcbmltcG9ydCBwYXltZW50c0FwaSBmcm9tICcuL3BheW1lbnRzJztcclxuaW1wb3J0IHN1cnZleUFwaSBmcm9tICcuL3N1cnZleSc7XHJcbmltcG9ydCBjb21tb25BcGkgZnJvbSAnLi9jb21tb24nO1xyXG5pbXBvcnQgcXVpekFwaSBmcm9tICcuL3F1aXonO1xyXG5pbXBvcnQgdXNlcnNBcGkgZnJvbSAnLi91c2Vycyc7XHJcbmltcG9ydCBzdHJlYW1BcGkgZnJvbSAnLi9zdHJlYW0vc3RyZWFtJztcclxuaW1wb3J0IGNwZUFwaSBmcm9tICcuL2NwZS9jcGUnO1xyXG5pbXBvcnQgZ2VuZXJpY0FwaSBmcm9tICcuL3N0b3JhZ2UvZ2VuZXJpYyc7XHJcbmltcG9ydCB0ZW1wbGF0ZXNBcGkgZnJvbSAnLi9zdG9yYWdlL3RlbXBsYXRlcyc7XHJcbmltcG9ydCBhc3Nlc3NtZW50QXBpIGZyb20gJy4vc3RvcmFnZS9hc3Nlc3NtZW50Q29uZmlnJztcclxuaW1wb3J0IHN0YXRzQXBpIGZyb20gJy4vc3RvcmFnZS9wYXltZW50U3RhdHMnO1xyXG5pbXBvcnQgbW9kdWxlc0RhdGFBcGkgZnJvbSAnLi9zdG9yYWdlL21vZHVsZXNEYXRhLmpzJztcclxuaW1wb3J0IGFscGhhSnVkZ2VBcGkgZnJvbSAnLi9qdWRnZS9hbHBoYUp1ZGdlLmpzJztcclxuaW1wb3J0IHsgQ29udGVudFR5cGUgfSBmcm9tICcuLi91dGlsL2NvbnRlbnRUeXBlcy5qcyc7XHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gYmluZFNpdGVBcGkoYXBwTmFtZSkge1xyXG4gICAgY29uc3QgZW52ID0ge1xyXG4gICAgICAgIGludGVyb3BIb3N0LFxyXG4gICAgICAgIGludGVyb3BBcHBJZCxcclxuICAgICAgICBwYXJhbXMsXHJcbiAgICAgICAgcG9zdCxcclxuICAgICAgICBnZXQsXHJcbiAgICAgICAgaW50ZXJvcFBsYXRmb3JtSG9zdCxcclxuICAgICAgICBpbnRlcm9wQWRtaW5BbHBoYUp1ZGdlSG9zdFxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBhY3Rpb25zID0ge1xyXG4gICAgICAgIC4uLmNvdXJzZUFwaShlbnYpLFxyXG4gICAgICAgIC4uLm1vZHVsZUFwaShlbnYpLFxyXG4gICAgICAgIC4uLnBheW1lbnRzQXBpKGVudiksXHJcbiAgICAgICAgLi4uc3VydmV5QXBpKGVudiksXHJcbiAgICAgICAgLi4uY29tbW9uQXBpKGVudiksXHJcbiAgICAgICAgLi4ucXVpekFwaShlbnYpLFxyXG4gICAgICAgIC4uLnVzZXJzQXBpKGVudiksXHJcbiAgICAgICAgLi4uc3RyZWFtQXBpKGVudiksXHJcbiAgICAgICAgLi4uY3BlQXBpKGVudiksXHJcbiAgICAgICAgLi4uZ2VuZXJpY0FwaShlbnYpLFxyXG4gICAgICAgIC4uLnRlbXBsYXRlc0FwaShlbnYpLFxyXG4gICAgICAgIC4uLmFzc2Vzc21lbnRBcGkoZW52KSxcclxuICAgICAgICAuLi5zdGF0c0FwaShlbnYpLFxyXG4gICAgICAgIC4uLm1vZHVsZXNEYXRhQXBpKGVudiksXHJcbiAgICAgICAgLi4uYWxwaGFKdWRnZUFwaShlbnYpXHJcbiAgICB9O1xyXG5cclxuICAgIGlmIChhcHBOYW1lID09PSBudWxsKSB7XHJcbiAgICAgICAgcmV0dXJuIE9iamVjdC5rZXlzKGFjdGlvbnMpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gYWN0aW9ucztcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBpbnRlcm9wSG9zdChlbmRwb2ludCkge1xyXG4gICAgICAgIHN3aXRjaCAoYXBwTmFtZSkge1xyXG4gICAgICAgICAgICBjYXNlICdkaWdpdGFsJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiAnaHR0cHM6Ly9kaWdpdGFsLnNvZnR1bmkuYmcvJyArIGVuZHBvaW50O1xyXG4gICAgICAgICAgICBjYXNlICdjcmVhdGl2ZSc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJ2h0dHBzOi8vY3JlYXRpdmUuc29mdHVuaS5iZy8nICsgZW5kcG9pbnQ7XHJcbiAgICAgICAgICAgIGNhc2UgJ2FpJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiAnaHR0cHM6Ly9haS5zb2Z0dW5pLmJnLycgKyBlbmRwb2ludDtcclxuICAgICAgICAgICAgY2FzZSAnZmluYW5jZWFjYWRlbXknOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdodHRwczovL2ZpbmFuY2VhY2FkZW15LmJnLycgKyBlbmRwb2ludDtcclxuICAgICAgICAgICAgY2FzZSAnZGV2ZGlnaXRhbCc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJ2h0dHBzOi8vZGV2LmRpZ2l0YWwuc29mdHVuaS5iZy8nICsgZW5kcG9pbnQ7XHJcbiAgICAgICAgICAgIGNhc2UgJ2RldnNvZnR1bmknOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdodHRwczovL2Rldi5zb2Z0dW5pLmJnLycgKyBlbmRwb2ludDtcclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIHJldHVybiAnaHR0cHM6Ly9zb2Z0dW5pLmJnLycgKyBlbmRwb2ludDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gaW50ZXJvcEFwcElkKCkge1xyXG4gICAgICAgIHN3aXRjaCAoYXBwTmFtZSkge1xyXG4gICAgICAgICAgICBjYXNlICdkaWdpdGFsJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiAnZGlnaXRhbC5zb2Z0dW5pLmJnJztcclxuICAgICAgICAgICAgY2FzZSAnY3JlYXRpdmUnOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdjcmVhdGl2ZS5zb2Z0dW5pLmJnJztcclxuICAgICAgICAgICAgY2FzZSAnYWknOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdhaS5zb2Z0dW5pLmJnJztcclxuICAgICAgICAgICAgY2FzZSAnZmluYW5jZWFjYWRlbXknOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdmaW5hbmNlYWNhZGVteS5iZyc7XHJcbiAgICAgICAgICAgIGNhc2UgJ2RldmRpZ2l0YWwnOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdkaWdpdGFsLnNvZnR1bmkuYmcnO1xyXG4gICAgICAgICAgICBjYXNlICdkZXZzb2Z0dW5pJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiAnc29mdHVuaS5iZyc7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJ3NvZnR1bmkuYmcnO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBpbnRlcm9wUGxhdGZvcm1Ib3N0KCkge1xyXG4gICAgICAgIHN3aXRjaCAoYXBwTmFtZSkge1xyXG4gICAgICAgICAgICBjYXNlICdkaWdpdGFsJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiAnaHR0cHM6Ly9wbGF0Zm9ybS5zb2Z0dW5pLmJnJztcclxuICAgICAgICAgICAgY2FzZSAnY3JlYXRpdmUnOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdodHRwczovL3BsYXRmb3JtLnNvZnR1bmkuYmcnO1xyXG4gICAgICAgICAgICBjYXNlICdhaSc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJ2h0dHBzOi8vcGxhdGZvcm0uc29mdHVuaS5iZyc7XHJcbiAgICAgICAgICAgIGNhc2UgJ2ZpbmFuY2VhY2FkZW15JzpcclxuICAgICAgICAgICAgICAgIHJldHVybiAnaHR0cHM6Ly9wbGF0Zm9ybS5maW5hbmNlYWNhZGVteS5iZyc7XHJcbiAgICAgICAgICAgIGNhc2UgJ2RldmRpZ2l0YWwnOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdodHRwczovL2Rldi5wbGF0Zm9ybS5zb2Z0dW5pLmJnJztcclxuICAgICAgICAgICAgY2FzZSAnZGV2c29mdHVuaSc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJ2h0dHBzOi8vZGV2LnBsYXRmb3JtLnNvZnR1bmkuYmcnO1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdodHRwczovL3BsYXRmb3JtLnNvZnR1bmkuYmcnO1xyXG5cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gaW50ZXJvcEFkbWluQWxwaGFKdWRnZUhvc3QoKSB7XHJcbiAgICAgICAgc3dpdGNoIChhcHBOYW1lKSB7XHJcbiAgICAgICAgICAgIGNhc2UgJ2RldnNvZnR1bmknOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIFwiaHR0cHM6Ly9hZG1pbi5kZXYuYWxwaGEuanVkZ2Uuc29mdHVuaS5vcmdcIlxyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIFwiaHR0cHM6Ly9hZG1pbi5hbHBoYS5qdWRnZS5zb2Z0dW5pLm9yZ1wiO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxubGV0IGhvc3RzID0gW1xyXG4gICAgJ2h0dHBzOi8vZGlnaXRhbC5zb2Z0dW5pLmJnLycsXHJcbiAgICAnaHR0cHM6Ly9jcmVhdGl2ZS5zb2Z0dW5pLmJnLycsXHJcbiAgICAnaHR0cHM6Ly9haS5zb2Z0dW5pLmJnLycsXHJcbiAgICAnaHR0cHM6Ly9maW5hbmNlYWNhZGVteS5iZy8nLFxyXG4gICAgJ2h0dHBzOi8vZGV2LmRpZ2l0YWwuc29mdHVuaS5iZy8nLFxyXG4gICAgJ2h0dHBzOi8vZGV2LnNvZnR1bmkuYmcvJyxcclxuICAgICdodHRwczovL3NvZnR1bmkuYmcvJ1xyXG5dXHJcblxyXG5sZXQgcGxhdGZvcm1Ib3N0cyA9IFtcclxuICAgICdodHRwczovL3BsYXRmb3JtLmZpbmFuY2VhY2FkZW15LmJnJyxcclxuICAgICdodHRwczovL2Rldi5wbGF0Zm9ybS5zb2Z0dW5pLmJnJyxcclxuICAgICdodHRwczovL3BsYXRmb3JtLnNvZnR1bmkuYmcnXHJcbl1cclxuXHJcbmxldCBqdWRnZUhvc3RzID0gW1xyXG4gICAgXCJodHRwczovL2FkbWluLmFscGhhLmp1ZGdlLnNvZnR1bmkub3JnXCIsXHJcbiAgICBcImh0dHBzOi8vZGV2LmFkbWluLmFscGhhLmp1ZGdlLnNvZnR1bmkub3JnXCIsXHJcbiAgICBcImh0dHBzOi8vYWxwaGEuanVkZ2Uuc29mdHVuaS5vcmdcIixcclxuICAgIFwiaHR0cHM6Ly9kZXYuYWxwaGEuanVkZ2Uuc29mdHVuaS5vcmdcIixcclxuXVxyXG5cclxuZnVuY3Rpb24gcGFyYW1zKHBhcmFtcyA9IHt9KSB7XHJcbiAgICByZXR1cm4gT2JqZWN0LmFzc2lnbih7XHJcbiAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgcGFnZTogMSxcclxuICAgICAgICBwYWdlU2l6ZTogMTAsXHJcbiAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgIGZpbHRlcjogJydcclxuICAgIH0sIHBhcmFtcyk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHBvc3QodXJsLCBwYXJhbXMsIGNvbnRlbnRUeXBlID0gQ29udGVudFR5cGUuVXJsRm9ybUVuY29kZWQsIGFzQmxvYiA9IGZhbHNlKSB7XHJcbiAgICBsZXQgYm9keSA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoKTtcclxuICAgIGlmKGNvbnRlbnRUeXBlID09PSBDb250ZW50VHlwZS5BcHBsaWNhdGlvbkpzb24pIHtcclxuICAgICAgICBib2R5ID0gSlNPTi5zdHJpbmdpZnkocGFyYW1zKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgZm9yIChsZXQga2V5IG9mIE9iamVjdC5rZXlzKHBhcmFtcykpIHtcclxuICAgICAgICAgICAgYm9keS5hcHBlbmQoa2V5LCBwYXJhbXNba2V5XSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHJlcSA9IHtcclxuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiBjb250ZW50VHlwZVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYm9keVxyXG4gICAgfTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2godXJsLCByZXEpO1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgIT09IDIwMCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ1Vuc3VjY2Vzc2Z1bCByZXF1ZXN0Jyk7XHJcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihwYXJhbXMpO1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBsZXQgZXJyb3IgPSBuZXcgRXJyb3IoYCR7cmVzcG9uc2Uuc3RhdHVzfTogJHtyZXNwb25zZS5zdGF0dXNUZXh0fSBhdCAke3Jlc3BvbnNlLnVybH1gKTtcclxuICAgICAgICAgICAgZXJyb3IuX3N0YXR1cyA9IHJlc3BvbnNlLnN0YXR1cztcclxuICAgICAgICAgICAgdGhyb3cgZXJyb3I7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChyZXNwb25zZS5yZWRpcmVjdGVkIHx8IHJlc3BvbnNlLnN0YXR1cyA9PSAzMDIpIHtcclxuICAgICAgICAgICAgbGV0IHVybERvbWFpbiA9IGhvc3RzLmZpbmQoeCA9PiB1cmwuc3RhcnRzV2l0aCh4KSk7XHJcbiAgICAgICAgICAgIGxldCBwbGF0Zm9ybURvbWFpbiA9IHBsYXRmb3JtSG9zdHMuZmluZCh4ID0+IHVybC5zdGFydHNXaXRoKHgpKTtcclxuICAgICAgICAgICAgbGV0IGp1ZGdlRG9tYWluID0ganVkZ2VIb3N0cy5maW5kKHggPT4gdXJsLnN0YXJ0c1dpdGgoeCkpO1xyXG5cclxuICAgICAgICAgICAgaWYoIXVybERvbWFpbikge1xyXG4gICAgICAgICAgICAgICAgdXJsRG9tYWluID0gcGxhdGZvcm1Eb21haW47XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmKCF1cmxEb21haW4pIHtcclxuICAgICAgICAgICAgICAgIHVybERvbWFpbiA9IGp1ZGdlRG9tYWluO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGBSZXF1ZXN0IGVycm9yIGZldGNoaW5nIGZyb20gJHt1cmx9LCB5b3UncmUgcHJvYmFibHkgbm90IGxvZ2dlZCBpbiAnJHt1cmxEb21haW59Jy5gKTtcclxuICAgICAgICAgICAgY29uc3QgZXJyb3IgPSBuZXcgRXJyb3IoYFJlcXVlc3QgZXJyb3IsIHlvdSdyZSBwcm9iYWJseSBub3QgbG9nZ2VkIGluIDxhIGhyZWY9XCIke3VybERvbWFpbn1cIiB0YXJnZXQ9XCJfYmxhbmtcIj4ke3VybERvbWFpbn08L2E+LiBQbGVhc2UgbG9naW4gdG8gPGEgaHJlZj1cIiR7dXJsRG9tYWlufVwiIHRhcmdldD1cIl9ibGFua1wiPiR7dXJsRG9tYWlufTwvYT4gYW5kIHRyeSBhZ2Fpbi5gKTtcclxuICAgICAgICAgICAgZXJyb3IuX3VybCA9IHVybDtcclxuICAgICAgICAgICAgdGhyb3cgZXJyb3I7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZihhc0Jsb2IpIHtcclxuICAgICAgICAgICAgbGV0IGZpbGVuYW1lID0gcmVzcG9uc2UuaGVhZGVycy5nZXQoJ0NvbnRlbnQtRGlzcG9zaXRpb24nKS5zcGxpdCgnZmlsZW5hbWU9JylbMV0uc3BsaXQoJzsnKVswXS5yZXBsYWNlQWxsKCdcXFwiJywgJycpO1xyXG4gICAgICAgICAgICBsZXQgYmxvYiA9IGF3YWl0IHJlc3BvbnNlLmJsb2IoKTtcclxuICAgICAgICAgICAgYmxvYi5maWxlbmFtZSA9IGZpbGVuYW1lO1xyXG4gICAgICAgICAgICByZXR1cm4gYmxvYjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGxldCByZXN1bHQgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XHJcbiAgICAgICAgICAgIGlmKHJlc3VsdC5FcnJvcnMpIHtcclxuICAgICAgICAgICAgICAgIGxldCBlcnJvcnNQYXJzZWQgPSBKU09OLnN0cmluZ2lmeShyZXN1bHQuRXJyb3JzLCB1bmRlZmluZWQsIDIpO1xyXG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGVycm9yc1BhcnNlZClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgaWYgKGUgaW5zdGFuY2VvZiBTeW50YXhFcnJvcikge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhyb3cgZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIGNhdGNoIChlKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihlKTtcclxuICAgICAgICB0aHJvdyBlO1xyXG4gICAgfVxyXG5cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZ2V0KHVybCwgYXNCbG9iKSB7XHJcbiAgICBjb25zdCByZXEgPSB7XHJcbiAgICAgICAgbWV0aG9kOiAnR0VUJ1xyXG4gICAgfTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICAgIGxldCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHVybCwgcmVxKTtcclxuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzICE9PSAyMDApIHtcclxuICAgICAgICAgICAgY29uc29sZS53YXJuKCdVbnN1Y2Nlc3NmdWwgcmVxdWVzdCcpO1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4ocGFyYW1zKTtcclxuICAgICAgICAgICAgY29uc29sZS53YXJuKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3Jlc3BvbnNlLnN0YXR1c1RleHR9IGF0ICR7cmVzcG9uc2UudXJsfWApO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAocmVzcG9uc2UucmVkaXJlY3RlZCkge1xyXG4gICAgICAgICAgICBpZiAodXJsLmluY2x1ZGVzKCdwbGF0Zm9ybScpKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgcGxhdGZvcm1Eb21haW4gPSBwbGF0Zm9ybUhvc3RzLmZpbmQoeCA9PiB1cmwuc3RhcnRzV2l0aCh4KSk7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGBSZXF1ZXN0IGVycm9yIGZldGNoaW5nIGZyb20gJHt1cmx9LCB5b3UncmUgcHJvYmFibHkgbm90IGxvZ2dlZCBpbiB0byB0aGUgcGxhdGZvcm0uYCk7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBlcnJvciA9IG5ldyBFcnJvcihgUmVxdWVzdCBlcnJvciwgeW91J3JlIHByb2JhYmx5IG5vdCBsb2dnZWQgaW4gPGEgaHJlZj1cIiR7cGxhdGZvcm1Eb21haW59XCIgdGFyZ2V0PVwiX2JsYW5rXCI+JHtwbGF0Zm9ybURvbWFpbn08L2E+LiBQbGVhc2UgbG9naW4gdG8gPGEgaHJlZj1cIiR7cGxhdGZvcm1Eb21haW59XCIgdGFyZ2V0PVwiX2JsYW5rXCI+JHtwbGF0Zm9ybURvbWFpbn08L2E+IGFuZCB0cnkgYWdhaW4uYCk7XHJcbiAgICAgICAgICAgICAgICBlcnJvci5fdXJsID0gdXJsO1xyXG4gICAgICAgICAgICAgICAgdGhyb3cgZXJyb3I7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXNwb25zZSA9IGF3YWl0IGZldGNoKHJlc3BvbnNlLnVybCwgcmVxKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGFzQmxvYikge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuYmxvYigpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgcmVhZGVyID0gcmVzcG9uc2UuYm9keS5nZXRSZWFkZXIoKTtcclxuICAgICAgICBjb25zdCB1dGY4RGVjb2RlciA9IG5ldyBUZXh0RGVjb2RlcigndXRmLTgnKTtcclxuICAgICAgICBsZXQgcmVzdWx0ID0gJyc7XHJcbiAgICAgICAgd2hpbGUgKHRydWUpIHtcclxuICAgICAgICAgICAgY29uc3QgeyBkb25lLCB2YWx1ZSB9ID0gYXdhaXQgcmVhZGVyLnJlYWQoKTtcclxuICAgICAgICAgICAgaWYgKGRvbmUpIHtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJlc3VsdCArPSB1dGY4RGVjb2Rlci5kZWNvZGUodmFsdWUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UocmVzdWx0KTtcclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgY2F0Y2ggKGUpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKGUpO1xyXG4gICAgICAgIHRocm93IGU7XHJcbiAgICB9XHJcblxyXG59IiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSkge1xyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0QmxvZ0J5VXJsKGJsb2dVcmwpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fY21zL25ld3MvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBmaWx0ZXI6IGBVcmx+ZXF+JyR7YmxvZ1VybH0nYFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YVswXTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRIYWxscygpIHtcclxuICAgICAgICBjb25zdCBkaXIgPSBpbnRlcm9wQXBwSWQoKSA9PSAnc29mdHVuaS5iZycgPyAnYWRtaW5pc3RyYXRpb25fdW5pdmVyc2l0eScgOiAnQWRtaW5pc3RyYXRpb24nO1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGRpciArICcvdHJhaW5pbmdsYWJzL3JlYWQnKTtcclxuXHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0U29mdHdhcmVVbml2ZXJzaXR5SGFsbHMoKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gJ2h0dHBzOi8vc29mdHVuaS5iZy9hZG1pbmlzdHJhdGlvbl91bml2ZXJzaXR5L3RyYWluaW5nbGFicy9yZWFkJztcclxuXHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gZ2V0SGFsbEJvZHkoaGFsbCkge1xyXG4gICAgICAgIGxldCBjdXJyZW50RGF0ZSA9IG5ldyBEYXRlKCk7XHJcbiAgICAgICAgLy8gc2ltcGxlc3Qgd2F5IHRvIGNvbnZlcnQgZGF0ZSB0byBJU08gZm9ybWF0IGluIGxvY2FsIFRpbWV6b25lIGFzIFNVTFMgcmVxdWlyZXNcclxuICAgICAgICBjdXJyZW50RGF0ZS5zZXRNaW51dGVzKGN1cnJlbnREYXRlLmdldE1pbnV0ZXMoKSAtIGN1cnJlbnREYXRlLmdldFRpbWV6b25lT2Zmc2V0KCkpXHJcbiAgICAgICAgbGV0IG1vZGlmaWVkT25EYXRlID0gY3VycmVudERhdGUudG9JU09TdHJpbmcoKS5zbGljZSgwLCAtMSk7XHJcblxyXG4gICAgICAgIGNvbnN0IGJvZHkgPSB7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiBoYWxsLklkLFxyXG4gICAgICAgICAgICBOYW1lQmc6IGhhbGwuTmFtZUJnLFxyXG4gICAgICAgICAgICBOYW1lRW46IGhhbGwuTmFtZUVuLFxyXG4gICAgICAgICAgICBBZGRyZXNzOiBoYWxsLkFkZHJlc3MsXHJcbiAgICAgICAgICAgIENhcGFjaXR5OiBoYWxsLkNhcGFjaXR5LFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbjogaGFsbC5EZXNjcmlwdGlvbixcclxuICAgICAgICAgICAgRGlzYWJsZVNlY3VyZUxpbms6IGhhbGwuRGlzYWJsZVNlY3VyZUxpbmssXHJcbiAgICAgICAgICAgIEZsb29yOiBoYWxsLkZsb29yLFxyXG4gICAgICAgICAgICBHb29nbGVDYWxlbmRhcklkOiBoYWxsLkdvb2dsZUNhbGVuZGFySWQsXHJcbiAgICAgICAgICAgIElzQWN0aXZlOiBoYWxsLklzQWN0aXZlLFxyXG4gICAgICAgICAgICBJc0ZlYXR1cmVkOiBoYWxsLklzRmVhdHVyZWQsXHJcbiAgICAgICAgICAgIElzUGh5c2ljYWw6IGhhbGwuSXNQaHlzaWNhbCxcclxuICAgICAgICAgICAgU2hvd09uU2NoZWR1bGU6IGhhbGwuU2hvd09uU2NoZWR1bGUsXHJcbiAgICAgICAgICAgIEJyYW5jaElkOiBoYWxsLkJyYW5jaElkLFxyXG4gICAgICAgICAgICBTZWF0c0NvbmZpZ3VyYXRpb246IGhhbGwuU2VhdHNDb25maWd1cmF0aW9uLFxyXG4gICAgICAgICAgICBTdHJlYW1pbmdUeXBlOiBoYWxsLlN0cmVhbWluZ1R5cGUsXHJcbiAgICAgICAgICAgIFlvdVR1YmVDb2RlOiBoYWxsLllvdVR1YmVDb2RlLFxyXG4gICAgICAgICAgICBTb2Z0VW5pU3RyZWFtQ29kZTogaGFsbC5Tb2Z0VW5pU3RyZWFtQ29kZSxcclxuICAgICAgICAgICAgU3RyZWFtaW5nU2VydmVyQmFzZUlkOiBoYWxsLlN0cmVhbWluZ1NlcnZlckJhc2VJZCxcclxuICAgICAgICAgICAgVWNkblN0cmVhbWluZ0NvZGU6IGhhbGwuVWNkblN0cmVhbWluZ0NvZGUsXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogaGFsbC5DcmVhdGVkT24sXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246IGhhbGwuTW9kaWZpZWRPbiB8fCBtb2RpZmllZE9uRGF0ZVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHJldHVybiBib2R5O1xyXG5cclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB1cGRhdGVIYWxsKGhhbGwpIHtcclxuICAgICAgICBsZXQgdXJpO1xyXG4gICAgICAgIGlmIChpbnRlcm9wQXBwSWQoKSA9PT0gJ3NvZnR1bmkuYmcnKSB7XHJcbiAgICAgICAgICAgIHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl91bml2ZXJzaXR5L3RyYWluaW5nbGFicy91cGRhdGUnKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB1cmkgPSBpbnRlcm9wSG9zdCgnQWRtaW5pc3RyYXRpb24vVHJhaW5pbmdMYWJzL1VwZGF0ZScpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgYm9keSA9IGdldEhhbGxCb2R5KGhhbGwpO1xyXG5cclxuICAgICAgICBpZiAoaW50ZXJvcEFwcElkKCkgIT09ICdzb2Z0dW5pLmJnJykge1xyXG4gICAgICAgICAgICBkZWxldGUgYm9keS5CcmFuY2hJZDtcclxuICAgICAgICAgICAgZGVsZXRlIGJvZHkuU2VhdHNDb25maWd1cmF0aW9uO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB1cGRhdGVTb2Z0d2FyZVVuaXZlcnNpdHlIYWxsKGhhbGwpIHtcclxuICAgICAgICBsZXQgdXJpID0gJ2h0dHBzOi8vc29mdHVuaS5iZy9hZG1pbmlzdHJhdGlvbl91bml2ZXJzaXR5L3RyYWluaW5nbGFicy91cGRhdGUnO1xyXG5cclxuICAgICAgICBjb25zdCBib2R5ID0gZ2V0SGFsbEJvZHkoaGFsbCk7XHJcblxyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldEJsb2dCeVVybCxcclxuICAgICAgICBnZXRIYWxscyxcclxuICAgICAgICB1cGRhdGVIYWxsLFxyXG4gICAgICAgIGdldFNvZnR3YXJlVW5pdmVyc2l0eUhhbGxzLFxyXG4gICAgICAgIHVwZGF0ZVNvZnR3YXJlVW5pdmVyc2l0eUhhbGxcclxuICAgIH07XHJcbn0iLCJpbXBvcnQgbmF2ZXRBcGlGYWN0b3J5IGZyb20gJy4vbmF2ZXQnO1xyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCwgZ2V0LCBpbnRlcm9wUGxhdGZvcm1Ib3N0IH0pIHtcclxuICAgIGNvbnN0IG5hdmV0QXBpID0gbmF2ZXRBcGlGYWN0b3J5KCk7XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0QXBwbGljYXRpb25zQnlJbnN0YW5jZUlkKGluc3RhbmNlSWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBgJHtpbnRlcm9wUGxhdGZvcm1Ib3N0KCl9L2FkbWluaXN0cmF0aW9uL2NwZWNlcnRpZmljYXRlYXBwbGljYXRpb25zL3JlYWQ/YXBwSWQ9JHtpbnRlcm9wQXBwSWQoKX1gO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnQ3JlYXRlZE9uLWRlc2MtYXNjJyxcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogYFRyYWluaW5nSWR+ZXF+JHtpbnN0YW5jZUlkfWBcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0QXBwbGljYXRpb25zKHF1ZXJ5LCBwYWdlKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gYCR7aW50ZXJvcFBsYXRmb3JtSG9zdCgpfS9hZG1pbmlzdHJhdGlvbi9jcGVjZXJ0aWZpY2F0ZWFwcGxpY2F0aW9ucy9yZWFkP2FwcElkPSR7aW50ZXJvcEFwcElkKCl9YDtcclxuXHJcbiAgICAgICAgY29uc3QgZmlsdGVyVG9rZW5zID0gW107XHJcbiAgICAgICAgaWYgKHF1ZXJ5Lmluc3RhbmNlSWQpIHtcclxuICAgICAgICAgICAgZmlsdGVyVG9rZW5zLnB1c2goYChUcmFpbmluZ0lkfmVxfiR7cXVlcnkuaW5zdGFuY2VJZH0pYCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChxdWVyeS5pbnN0YW5jZU5hbWUpIHtcclxuICAgICAgICAgICAgZmlsdGVyVG9rZW5zLnB1c2goYChUcmFpbmluZ05hbWV+Y29udGFpbnN+JyR7dG9rZW5pemUocXVlcnkuaW5zdGFuY2VOYW1lKS5qb2luKCdcXCd+YW5kflRyYWluaW5nTmFtZX5jb250YWluc35cXCcnKX0nKWApO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAocXVlcnkubmFtZXMpIHtcclxuICAgICAgICAgICAgY29uc3QgbmFtZVRva2VucyA9IHRva2VuaXplKHF1ZXJ5Lm5hbWVzKTtcclxuICAgICAgICAgICAgbGV0IG5hbWVGaWx0ZXIgPSAnJztcclxuICAgICAgICAgICAgaWYgKG5hbWVUb2tlbnMubGVuZ3RoID09IDEpIHtcclxuICAgICAgICAgICAgICAgIG5hbWVGaWx0ZXIgPSBgKEZpcnN0TmFtZX5jb250YWluc34nJHtuYW1lVG9rZW5zWzBdfSd+b3J+TWlkZGxlTmFtZX5jb250YWluc34nJHtuYW1lVG9rZW5zWzBdfSd+b3J+TGFzdE5hbWV+Y29udGFpbnN+JyR7bmFtZVRva2Vuc1swXX0nKWA7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAobmFtZVRva2Vucy5sZW5ndGggPT0gMikge1xyXG4gICAgICAgICAgICAgICAgbmFtZUZpbHRlciA9IGAoRmlyc3ROYW1lfmNvbnRhaW5zficke25hbWVUb2tlbnNbMF19J35hbmR+KE1pZGRsZU5hbWV+Y29udGFpbnN+JyR7bmFtZVRva2Vuc1sxXX0nfm9yfkxhc3ROYW1lfmNvbnRhaW5zficke25hbWVUb2tlbnNbMV19JykpYDtcclxuICAgICAgICAgICAgfSBlbHNlIGlmIChuYW1lVG9rZW5zLmxlbmd0aCA9PSAzKSB7XHJcbiAgICAgICAgICAgICAgICBuYW1lRmlsdGVyID0gYChGaXJzdE5hbWV+Y29udGFpbnN+JyR7bmFtZVRva2Vuc1swXX0nfmFuZH5NaWRkbGVOYW1lfmNvbnRhaW5zficke25hbWVUb2tlbnNbMV19J35hbmR+TGFzdE5hbWV+Y29udGFpbnN+JyR7bmFtZVRva2Vuc1syXX0nKWA7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGZpbHRlclRva2Vucy5wdXNoKG5hbWVGaWx0ZXIpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAocXVlcnkuU1NOKSB7XHJcbiAgICAgICAgICAgIGZpbHRlclRva2Vucy5wdXNoKGBTU05+Y29udGFpbnN+JyR7cXVlcnkuU1NOfSdgKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnQ3JlYXRlZE9uLWRlc2MnLFxyXG4gICAgICAgICAgICBwYWdlU2l6ZTogcGFnZSA/IDI1IDogMjAwMCxcclxuICAgICAgICAgICAgcGFnZTogcGFnZSA/IHBhZ2UgOiAxLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGZpbHRlclRva2Vucy5qb2luKCd+YW5kficpXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0QXBwWmlwKGlkKSB7XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7aW50ZXJvcFBsYXRmb3JtSG9zdCgpfS9hZG1pbmlzdHJhdGlvbi9jcGVjZXJ0aWZpY2F0ZWFwcGxpY2F0aW9ucy9nZXRmaWxlc3ppcD9pZD0ke2lkfWApO1xyXG5cclxuICAgICAgICBjb25zdCBibG9iID0gYXdhaXQgcmVzLmJsb2IoKTtcclxuICAgICAgICBjb25zdCBzZXJpYWxpemVkQmxvYiA9IG5ldyBVaW50OEFycmF5KGF3YWl0IGJsb2IuYXJyYXlCdWZmZXIoKSk7XHJcbiAgXHJcbiAgICAgICAgY29uc3QgYmxvYkRhdGEgPSB7XHJcbiAgICAgICAgICAgIHR5cGU6IGJsb2IudHlwZSxcclxuICAgICAgICAgICAgYnVmZmVyOiBBcnJheS5mcm9tKHNlcmlhbGl6ZWRCbG9iKVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHJldHVybiBibG9iRGF0YTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLy8gIyMjIEV4dGVybmFsIHN0b3JhZ2Ugb2YgYXBwbGljYXRpb24gZGF0YSAodXNlcyBsZWN0dXJlcyBpbnNpZGUgYSBmaXhlZCBjb3Vyc2UgaW5zdGFuY2UpXHJcblxyXG4gICAgY29uc3Qgc3RvcmVJZCA9IHtcclxuICAgICAgICAnc29mdHVuaS5iZyc6IDMxMjQsXHJcbiAgICAgICAgJ2RpZ2l0YWwuc29mdHVuaS5iZyc6IDIzMzYsXHJcbiAgICAgICAgJ2NyZWF0aXZlLnNvZnR1bmkuYmcnOiAxMTkzLFxyXG4gICAgICAgICdhaS5zb2Z0dW5pLmJnJzogOCxcclxuICAgICAgICAnZmluYW5jZWFjYWRlbXkuYmcnOiAyMjhcclxuICAgIH07XHJcblxyXG4gICAgY29uc3Qgc3RhdHVzTW9kZWwgPSB7XHJcbiAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgSWQ6ICcnLFxyXG4gICAgICAgIFRyYWluaW5nSWQ6ICcnLFxyXG4gICAgICAgIE5hbWVCZzogJycsXHJcbiAgICAgICAgTmFtZUVuOiAnJyxcclxuICAgICAgICBIYXNNYW51YWxOdW1iZXJPZlN0dWR5SG91cnM6ICcnLFxyXG4gICAgICAgIE51bWJlck9mU3R1ZHlIb3VyczogJycsXHJcbiAgICAgICAgSXNFeGNsdWRlZEZyb21DZXJ0aWZpY2F0ZTogJycsXHJcbiAgICAgICAgSGFzSG9tZXdvcms6ICcnLFxyXG4gICAgICAgIFJlc291cmNlTWFpbHNTdGF0ZTogJycsXHJcbiAgICAgICAgSG9tZXdvcmtNYWlsc1N0YXRlOiAnJyxcclxuICAgICAgICBKdWRnZUNvbnRlc3RJZDogJycsXHJcbiAgICAgICAgT3JkZXJCeTogJycsXHJcbiAgICAgICAgRGVzY3JpcHRpb25CZzogJycsXHJcbiAgICAgICAgRGVzY3JpcHRpb25FbjogJycsXHJcbiAgICAgICAgRXhjbHVkZUZyb21DYWxlbmRhcjogJycsXHJcbiAgICAgICAgSGFzTGl2ZVN0cmVhbTogJycsXHJcbiAgICAgICAgQ3JlYXRlZE9uOiAnJyxcclxuICAgICAgICBNb2RpZmllZE9uOiAnJ1xyXG4gICAgfTtcclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRBcHBTdGF0dXMoaWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2xlY3R1cmVzL3JlYWQ/Zm9yZWlnbktleUlkPSR7c3RvcmVJZFtpbnRlcm9wQXBwSWQoKV19YCk7XHJcbiAgICAgICAgbGV0IGZpbHRlciA9ICcnO1xyXG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KGlkKSkge1xyXG4gICAgICAgICAgICBmaWx0ZXIgPSBgTmFtZUVufmVxficke2lkLmpvaW4oJ1xcJ35vcn5OYW1lRW5+ZXF+XFwnJyl9J2A7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgZmlsdGVyID0gYE5hbWVFbn5lcX4nJHtpZH0nYDtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwLFxyXG4gICAgICAgICAgICBmaWx0ZXJcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0QXBwU3RhdHVzQnlJbnN0YW5jZUlkKGlkKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9sZWN0dXJlcy9yZWFkP2ZvcmVpZ25LZXlJZD0ke3N0b3JlSWRbaW50ZXJvcEFwcElkKCldfWApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMCxcclxuICAgICAgICAgICAgZmlsdGVyOiBgTmFtZUJnfmVxficke2lkfSdgXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmksIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVN0YXR1cyhzdGF0dXMpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2xlY3R1cmVzL2NyZWF0ZT9mb3JlaWduS2V5SWQ9JHtzdG9yZUlkW2ludGVyb3BBcHBJZCgpXX1gKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gT2JqZWN0LmFzc2lnbihwYXJhbXMoe30pLCBzdGF0dXNNb2RlbCk7XHJcbiAgICAgICAgZm9yIChsZXQgZmllbGQgaW4gYm9keSkge1xyXG4gICAgICAgICAgICBib2R5W2ZpZWxkXSA9IHN0YXR1c1tmaWVsZF0gPT09IHVuZGVmaW5lZCA/IGJvZHlbZmllbGRdIDogc3RhdHVzW2ZpZWxkXTtcclxuICAgICAgICB9XHJcbiAgICAgICAgYm9keS5UcmFpbmluZ0lkID0gc3RvcmVJZFtpbnRlcm9wQXBwSWQoKV07XHJcblxyXG4gICAgICAgIGxldCBzdGFydERhdGUgPSBuZXcgRGF0ZSgpO1xyXG4gICAgICAgIGxldCBlbmREYXRlID0gbmV3IERhdGUoc3RhcnREYXRlKTtcclxuICAgICAgICBlbmREYXRlLnNldFVUQ0RhdGUoZW5kRGF0ZS5nZXRVVENEYXRlKCkgICsgMSk7XHJcbiAgICAgICAgYm9keVtgRGF0ZXNJbmZvWzBdLlN0YXJ0YF0gPSBzdGFydERhdGUudG9JU09TdHJpbmcoKTtcclxuICAgICAgICBib2R5W2BEYXRlc0luZm9bMF0uRW5kYF0gPSBlbmREYXRlLnRvSVNPU3RyaW5nKCk7XHJcbiAgICAgICAgYm9keVtgRGF0ZXNJbmZvWzBdLkV4dHJhSW5mb3JtYXRpb25gXSA9ICcnO1xyXG5cclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCkgeyBib2R5W2tdID0gJyc7IH0gfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmksIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVN0YXR1cyhzdGF0dXMpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2xlY3R1cmVzL3VwZGF0ZT9mb3JlaWduS2V5SWQ9JHtzdG9yZUlkW2ludGVyb3BBcHBJZCgpXX1gKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gT2JqZWN0LmFzc2lnbihwYXJhbXMoe30pLCBzdGF0dXNNb2RlbCk7XHJcbiAgICAgICAgZm9yIChsZXQgZmllbGQgaW4gYm9keSkge1xyXG4gICAgICAgICAgICBib2R5W2ZpZWxkXSA9IHN0YXR1c1tmaWVsZF0gPT09IHVuZGVmaW5lZCA/IGJvZHlbZmllbGRdIDogc3RhdHVzW2ZpZWxkXTtcclxuICAgICAgICB9XHJcbiAgICAgICAgYm9keS5UcmFpbmluZ0lkID0gc3RvcmVJZFtpbnRlcm9wQXBwSWQoKV07XHJcblxyXG4gICAgICAgIGxldCBzdGFydERhdGUgPSBuZXcgRGF0ZSgpO1xyXG4gICAgICAgIGxldCBlbmREYXRlID0gbmV3IERhdGUoc3RhcnREYXRlKTtcclxuICAgICAgICBlbmREYXRlLnNldFVUQ0RhdGUoZW5kRGF0ZS5nZXRVVENEYXRlKCkgICsgMSk7XHJcbiAgICAgICAgYm9keVtgRGF0ZXNJbmZvWzBdLlN0YXJ0YF0gPSBzdGFydERhdGUudG9JU09TdHJpbmcoKTtcclxuICAgICAgICBib2R5W2BEYXRlc0luZm9bMF0uRW5kYF0gPSBlbmREYXRlLnRvSVNPU3RyaW5nKCk7XHJcbiAgICAgICAgYm9keVtgRGF0ZXNJbmZvWzBdLkV4dHJhSW5mb3JtYXRpb25gXSA9ICcnO1xyXG5cclxuICAgICAgICBib2R5LkNyZWF0ZWRPbiA9ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNyc7XHJcbiAgICAgICAgYm9keS5Nb2RpZmllZE9uID0gJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JztcclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCkgeyBib2R5W2tdID0gJyc7IH0gfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmksIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGRlc3Ryb3lTdGF0dXMoc3RhdHVzKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9sZWN0dXJlcy9kZXN0cm95P2ZvcmVpZ25LZXlJZD0ke3N0b3JlSWRbaW50ZXJvcEFwcElkKCldfWApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgT2JqZWN0LmFzc2lnbihib2R5LCBzdGF0dXMpO1xyXG4gICAgICAgIGJvZHkuVHJhaW5pbmdJZCA9IHN0b3JlSWRbaW50ZXJvcEFwcElkKCldO1xyXG4gICAgICAgIGJvZHkuQ3JlYXRlZE9uID0gJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JztcclxuICAgICAgICBib2R5Lk1vZGlmaWVkT24gPSAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICAuLi5uYXZldEFwaSxcclxuICAgICAgICBnZXRBcHBsaWNhdGlvbnNCeUluc3RhbmNlSWQsXHJcbiAgICAgICAgZ2V0QXBwbGljYXRpb25zLFxyXG4gICAgICAgIGdldEFwcFppcCxcclxuICAgICAgICBnZXRBcHBTdGF0dXMsXHJcbiAgICAgICAgZ2V0QXBwU3RhdHVzQnlJbnN0YW5jZUlkLFxyXG4gICAgICAgIGNyZWF0ZVN0YXR1cyxcclxuICAgICAgICB1cGRhdGVTdGF0dXMsXHJcbiAgICAgICAgZGVzdHJveVN0YXR1c1xyXG4gICAgfTtcclxufVxyXG5cclxuZnVuY3Rpb24gdG9rZW5pemUoYXNTdHJpbmcpIHtcclxuICAgIHJldHVybiBhc1N0cmluZy5zcGxpdCgnICcpLm1hcCh0ID0+IHQudHJpbSgpKS5maWx0ZXIodCA9PiB0Lmxlbmd0aCA+IDApO1xyXG59IiwiaW1wb3J0IEpTT041IGZyb20gJy4uLy4uLy4uL25vZGVfbW9kdWxlcy9qc29uNS9kaXN0L2luZGV4Lm1pbic7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAoKSB7XHJcbiAgICBjb25zdCBob3N0ID0gJ2h0dHBzOi8vaXMubmF2ZXQuZ292ZXJubWVudC5iZy9mdXJpYS9Qcm9qZWN0cy9uYXBvby9pbmRleC5uZXcucGhwJztcclxuXHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0KHVybCkge1xyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKHVybCk7XHJcbiAgICAgICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XHJcbiAgICAgICAgcmV0dXJuIHRleHQ7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gcG9zdEZvcm0odXJsLCBib2R5KSB7XHJcbiAgICAgICAgT2JqZWN0LmFzc2lnbihib2R5LCB7IGFwcGxpY2F0aW9uOiAnQUpBWERhdGFQcm92aWRlcicsIG5vQ2FjaGU6IERhdGUubm93KCkgfSk7XHJcbiAgICAgICAgY29uc3QgcXVlcnkgPSBbXTtcclxuICAgICAgICBmb3IgKGxldCBwYXJhbSBpbiBib2R5KSB7XHJcbiAgICAgICAgICAgIHF1ZXJ5LnB1c2goYCR7cGFyYW19PSR7ZW5jb2RlVVJJQ29tcG9uZW50KGJvZHlbcGFyYW1dKX1gKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2godXJsLCB7XHJcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAnQ29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZDsgY2hhcnNldD11dGYtOCdcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYm9keTogcXVlcnkuam9pbignJicpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIHJlcy50ZXh0KCk7XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gcGFyc2VSZXNwb25zZShkYXRhKSB7XHJcbiAgICAgICAgbGV0IGpzb247XHJcbiAgICAgICAganNvbiA9IEpTT041LnBhcnNlKGRhdGEpO1xyXG5cclxuICAgICAgICBpZiAoanNvbi5oYXNPd25Qcm9wZXJ0eSgnb2JqJykpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHBhcnNlT2JqZWN0KGpzb24ub2JqKTtcclxuICAgICAgICB9IGVsc2UgaWYgKGpzb24uaGFzT3duUHJvcGVydHkoJ29ianMnKSkge1xyXG4gICAgICAgICAgICByZXR1cm4ganNvbi5vYmpzLm1hcChwYXJzZU9iamVjdCk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChqc29uLmhhc093blByb3BlcnR5KCdkYXRhJykgfHwganNvbi5zdGF0dXMgIT0gMCkge1xyXG4gICAgICAgICAgICByZXR1cm4ganNvbjtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGpzb24pO1xyXG4gICAgICAgICAgICBpZiAoanNvbi5zdGF0dXMgPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignWW91ciBzZXNzaW9uIGhhcyBleHBpcmVkLiBQbGVhc2UgZW50ZXIgeW91ciBjcmVkZW50aWFscyBhZ2Fpbi4nKTtcclxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignWW91ciBzZXNzaW9uIGhhcyBleHBpcmVkLiBQbGVhc2UgZW50ZXIgeW91ciBjcmVkZW50aWFscyBhZ2Fpbi4nKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1VuYWJsZSB0byBwYXJzZSBkYXRhOiBubyBrZXlzIFtvYmpdIG9yIFtvYmpzXSBmb3VuZC4gU2VlIGNvbnNvbGUgZm9yIGRldGFpbHMuJyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIHBhcnNlT2JqZWN0KG9iaikge1xyXG4gICAgICAgICAgICBjb25zdCBwYXJzZWQgPSB7fTtcclxuICAgICAgICAgICAgZm9yIChsZXQgcHJvcCBpbiBvYmopIHtcclxuICAgICAgICAgICAgICAgIHBhcnNlZFtwcm9wXSA9IG9ialtwcm9wXS52YWx1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gcGFyc2VkO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRFeHRyYUNvdXJzZUluZm8oaWQpIHtcclxuICAgICAgICBjb25zdCBib2R5ID0ge1xyXG4gICAgICAgICAgICBpbnZva2U6IGBUYkNvdXJzZUdyb3Vwc01hbmFnZXIuZ2V0QnlDb3Vyc2VHcm91cElkKCR7aWR9KWAsXHJcbiAgICAgICAgfTtcclxuICAgICAgICByZXR1cm4gcGFyc2VSZXNwb25zZShhd2FpdCBwb3N0Rm9ybShob3N0LCBib2R5KSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRDdXJyZW50Q291cnNlcygpIHtcclxuICAgICAgICBjb25zdCBib2R5ID0ge1xyXG4gICAgICAgICAgICBpbnZva2U6ICdWaWV3Q291cnNlR3JvdXBMaXN0TWFuYWdlci5jdXN0b21HZXRCeVByb3ZpZGVySWRBbmRDb3Vyc2VTdGF0dXNJZCgyOTI5LDIpJyxcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKGF3YWl0IHBvc3RGb3JtKGhvc3QsIGJvZHkpKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXROYXZldENsb3NlZENvdXJzZXMoKSB7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHtcclxuICAgICAgICAgICAgaW52b2tlOiAnVmlld0ZpbmlzaGVkQ291cnNlR3JvdXBMaXN0TWFuYWdlci5jdXN0b21HZXRCeVByb3ZpZGVySWRBbmRDb3Vyc2VTdGF0dXNJZE5vdEFyY2hpdmVkKDI5MjkpJyxcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKGF3YWl0IHBvc3RGb3JtKGhvc3QsIGJvZHkpKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXROYXZldEFyY2hpdmVkQ291cnNlcygpIHtcclxuICAgICAgICBjb25zdCBib2R5ID0ge1xyXG4gICAgICAgICAgICBpbnZva2U6ICdWaWV3RmluaXNoZWRDb3Vyc2VHcm91cExpc3RNYW5hZ2VyLmN1c3RvbUdldEJ5UHJvdmlkZXJJZEFuZENvdXJzZVN0YXR1c0lkQXJjaGl2ZWQoMjkyOSknLFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UoYXdhaXQgcG9zdEZvcm0oaG9zdCwgYm9keSkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldE5hdmV0Q291cnNlSW5mbyhpZCwgdHlwZSA9ICdjdXJyZW50Jykge1xyXG4gICAgICAgIGxldCBleHRyYUluZm8gPSBnZXRFeHRyYUNvdXJzZUluZm8oaWQpO1xyXG4gICAgICAgIGxldCBjb3Vyc2VMaXN0ID0gW107XHJcbiAgICAgICAgc3dpdGNoICh0eXBlKSB7XHJcbiAgICAgICAgICAgIGNhc2UgJ2N1cnJlbnQnOlxyXG4gICAgICAgICAgICAgICAgY291cnNlTGlzdCA9IGdldE5hdmV0Q3VycmVudENvdXJzZXMoKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICdjb25jbHVkZWQnOlxyXG4gICAgICAgICAgICAgICAgY291cnNlTGlzdCA9IGdldE5hdmV0Q2xvc2VkQ291cnNlcygpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgJ2FyY2hpdmUnOlxyXG4gICAgICAgICAgICAgICAgY291cnNlTGlzdCA9IGdldE5hdmV0QXJjaGl2ZWRDb3Vyc2VzKCk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICAgICAgW2V4dHJhSW5mbywgY291cnNlTGlzdF0gPSBhd2FpdCBQcm9taXNlLmFsbChbZXh0cmFJbmZvLCBjb3Vyc2VMaXN0XSk7XHJcbiAgICAgICAgY29uc3Qgc2VsZWN0ZWQgPSBjb3Vyc2VMaXN0LmZpbmQoYyA9PiBjLmlkID09IGlkKTtcclxuICAgICAgICBzZWxlY3RlZC5fZXh0cmEgPSBleHRyYUluZm9bMF07XHJcblxyXG4gICAgICAgIHJldHVybiBzZWxlY3RlZDtcclxuICAgIH1cclxuXHJcbiAgICAvKiBSZXBsYWNlZCwgYmVjYXVzZSBpdCBkb2Vzbid0IHByb3ZpZGUgdGhlIG5lY2Vzc2FyeSBpbmZvcm1hdGlvbiAqL1xyXG4gICAgLypcclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldE5hdmV0Q291cnNlSW5mbyhpZCkge1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSB7XHJcbiAgICAgICAgICAgIGludm9rZTogYFZpZXdDb3Vyc2VJbmZvTWFuYWdlci5nZXRCeUlkKCR7aWR9KWBcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKGF3YWl0IHBvc3RGb3JtKGhvc3QsIGJvZHkpKTtcclxuICAgIH1cclxuICAgICovXHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRTdHVkZW50cyhpZCkge1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSB7XHJcbiAgICAgICAgICAgIGludm9rZTogYFZpZXdDbGllbnRDb3Vyc2VzTWFuYWdlci5nZXRCeUNvdXJzZUdyb3VwSWQoJHtpZH0pYFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UoYXdhaXQgcG9zdEZvcm0oaG9zdCwgYm9keSkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldE5hdmV0U3R1ZGVudEluZm8oY2xpZW50SWQpIHtcclxuICAgICAgICBjb25zdCBib2R5ID0ge1xyXG4gICAgICAgICAgICBpbnZva2U6IGBUYkNsaWVudHNNYW5hZ2VyLmdldEJ5SWQoJHtjbGllbnRJZH0pYCxcclxuICAgICAgICAgICAgaWQ6IGNsaWVudElkXHJcbiAgICAgICAgfTtcclxuICAgICAgICByZXR1cm4gcGFyc2VSZXNwb25zZShhd2FpdCBwb3N0Rm9ybShob3N0LCBib2R5KSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRFeGlzdGluZ0ZpbGVzKGNvdXJzZUlkLCBpZCkge1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSB7XHJcbiAgICAgICAgICAgIGludm9rZTogYFRiQ2xpZW50c1JlcXVpcmVkRG9jdW1lbnRzTWFuYWdlci5jdXN0b21HZXRWYWxpZEJ5Q291cnNlR3JvdXBBbmRDbGllbnQoJHtjb3Vyc2VJZH0sJHtpZH0pYCxcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKGF3YWl0IHBvc3RGb3JtKGhvc3QsIGJvZHkpKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB1cGxvYWRGaWxlKGZvcm1EYXRhKSB7XHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZmV0Y2goaG9zdCwge1xyXG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICAgICAgYm9keTogZm9ybURhdGFcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3Qgb3V0cHV0ID0gYXdhaXQgcmVzdWx0LnRleHQoKTtcclxuICAgICAgICBpZiAob3V0cHV0LnNlYXJjaCgvc3RhdHVzOlxcczAvKSAhPSAtMSkge1xyXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1lvdXIgc2Vzc2lvbiBoYXMgZXhwaXJlZC4gUGxlYXNlIGVudGVyIHlvdXIgY3JlZGVudGlhbHMgYWdhaW4uJyk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIG91dHB1dDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gdXBsb2FkTWVkaWNhbChjb3Vyc2VJZCwgaWQsIGZpbGVEZXNjcmlwdG9yKSB7XHJcbiAgICAgICAgbGV0IGJsb2I7XHJcbiAgICAgICAgbGV0IGZpbGVuYW1lO1xyXG4gICAgICAgIGlmIChmaWxlRGVzY3JpcHRvci5maWxlVXJsICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgYmxvYiA9IGF3YWl0IChhd2FpdCBmZXRjaChmaWxlRGVzY3JpcHRvci5maWxlVXJsKSkuYmxvYigpO1xyXG4gICAgICAgICAgICBmaWxlbmFtZSA9IGZpbGVEZXNjcmlwdG9yLm5hbWU7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgYmxvYiA9IGZpbGVEZXNjcmlwdG9yLmZpbGU7XHJcbiAgICAgICAgICAgIGZpbGVuYW1lID0gZmlsZURlc2NyaXB0b3IuZmlsZS5uYW1lO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xyXG5cclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2lkJywgbnVsbCk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnRfY291cnNlX2dyb3VwX2lkJywgY291cnNlSWQpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaXNfdmFsaWQnLCB0cnVlKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ29pZF9maWxlX2FjdGlvbicsICd1cGxvYWQnKTtcclxuXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdvaWRfZmlsZScsIGJsb2IsIGZpbGVuYW1lKTtcclxuXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnZva2UnLCAnVGJDbGllbnRzUmVxdWlyZWREb2N1bWVudHNNYW5hZ2VyLmNyZWF0ZU9iamVjdCgpJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdhcHBsaWNhdGlvbicsICdBSkFYRGF0YVByb3ZpZGVyJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdwcm90b2NvbCcsICdkYXRhSUZyYW1lJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdudWxsJywgJycpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaW50X2NvZGVfY291cnNlX2dyb3VwX3JlcXVpcmVkX2RvY3VtZW50c190eXBlX2lkJywgMSk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnRfY2xpZW50X2lkJywgaWQpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndmNfZGVzY2lwdGlvbicsICfQvNC10LTQuNGG0LjQvdGB0LrQviAoYXV0byknKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2R0X2RvY3VtZW50X2RhdGUnLCAnJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCd2Y19kb2N1bWVudF9yZWdfbm8nLCAnJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCd2Y19kb2N1bWVudF9wcm5fbm8nLCAnJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdkdF9kb2N1bWVudF9vZmZpY2lhbF9kYXRlJywgJycpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnYm9vbF9iZWZvcmVfZGF0ZScsIGZhbHNlKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludF9jb2RlX2V4dF9yZWdpc3Rlcl9pZCcsIG51bGwpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndGl0bGUnLCAnPGRpdiBjbGFzcz1cXCduYXBvby10aXRsZS1kYXJrXFwnPtCc0LXQtNC40YbQuNC90YHQutC+INGB0LLQuNC00LXRgtC10LvRgdGC0LLQvjo8L2Rpdj4nKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2FzeW5jX2lmcmFtZV9pZCcsICdhc3luY19pZnJhbWVfMzE1MicpO1xyXG5cclxuICAgICAgICByZXR1cm4gdXBsb2FkRmlsZShmb3JtRGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gdXBsb2FkRGlwbG9tYShjb3Vyc2VJZCwgaWQsIGZpbGVEZXNjcmlwdG9yLCByZWdfbm8sIHBybl9ubywgZG9jX2RhdGUpIHtcclxuICAgICAgICBsZXQgYmxvYjtcclxuICAgICAgICBsZXQgZmlsZW5hbWU7XHJcbiAgICAgICAgaWYgKGZpbGVEZXNjcmlwdG9yLmZpbGVVcmwgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICBibG9iID0gYXdhaXQgKGF3YWl0IGZldGNoKGZpbGVEZXNjcmlwdG9yLmZpbGVVcmwpKS5ibG9iKCk7XHJcbiAgICAgICAgICAgIGZpbGVuYW1lID0gZmlsZURlc2NyaXB0b3IubmFtZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBibG9iID0gZmlsZURlc2NyaXB0b3IuZmlsZTtcclxuICAgICAgICAgICAgZmlsZW5hbWUgPSBmaWxlRGVzY3JpcHRvci5maWxlLm5hbWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IGZvcm1EYXRhID0gbmV3IEZvcm1EYXRhKCk7XHJcblxyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaWQnLCBudWxsKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludF9jb3Vyc2VfZ3JvdXBfaWQnLCBjb3Vyc2VJZCk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpc192YWxpZCcsIHRydWUpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaW50X2NvZGVfZWR1Y2F0aW9uX2lkJywgMzEpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnMzQxLXRleHQnLCAn0LfQsNCy0YrRgNGI0LXQvdC+INGB0YDQtdC00L3QviDQvtCx0YDQsNC30L7QstCw0L3QuNC1ICjQuNC70Lgg0L/Qvi3QstC40YHQvtC60L4pJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCd2Y19kb2N1bWVudF9yZWdfbm8nLCByZWdfbm8pO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndmNfZG9jdW1lbnRfcHJuX25vJywgcHJuX25vKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ29pZF9maWxlX2FjdGlvbicsICd1cGxvYWQnKTtcclxuXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdvaWRfZmlsZScsIGJsb2IsIGZpbGVuYW1lKTtcclxuXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnZva2UnLCAnVGJDbGllbnRzUmVxdWlyZWREb2N1bWVudHNNYW5hZ2VyLmNyZWF0ZU9iamVjdCgpJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdhcHBsaWNhdGlvbicsICdBSkFYRGF0YVByb3ZpZGVyJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdwcm90b2NvbCcsICdkYXRhSUZyYW1lJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdudWxsJywgJycpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaW50X2NsaWVudF9pZCcsIGlkKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX2Rlc2NpcHRpb24nLCAn0LTQuNC/0LvQvtC80LAgKGF1dG8pJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdkdF9kb2N1bWVudF9kYXRlJywgJycpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnZHRfZG9jdW1lbnRfb2ZmaWNpYWxfZGF0ZScsIGRvY19kYXRlKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2Jvb2xfYmVmb3JlX2RhdGUnLCBmYWxzZSk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnRfY29kZV9leHRfcmVnaXN0ZXJfaWQnLCBudWxsKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3RpdGxlJywgJzxkaXYgY2xhc3M9XFwnbmFwb28tdGl0bGUtZGFya1xcJz7QktGF0L7QtNGP0YnQviDQvNC40L3QuNC80LDQu9C90L4g0L7QsdGA0LDQt9C+0LLQsNGC0LXQu9C90L4g0YDQsNCy0L3QuNGJ0LU6PC9kaXY+Jyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdyZXNwSW5mbycsICcnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2V4dHJhSW5mbycsICcnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2NoZWNrLWluLWVkdS1idXR0b24nLCAn0J/RgNC+0LLQtdGA0Lgg0LIg0YDQtdCz0LjRgdGC0YDQuNGC0LUnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2FzeW5jX2lmcmFtZV9pZCcsICdhc3luY19pZnJhbWVfMzc0Jyk7XHJcblxyXG4gICAgICAgIHJldHVybiB1cGxvYWRGaWxlKGZvcm1EYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBvcGVuTmF2ZXRGaWxlKGlkKSB7XHJcbiAgICAgICAgY29uc3QgdXJsID0gYCR7aG9zdH0/YXBwbGljYXRpb249QUpBWERhdGFQcm92aWRlciZpbnZva2U9VGJDbGllbnRzUmVxdWlyZWREb2N1bWVudHNNYW5hZ2VyLmN1c3RvbURvd25sb2FkRmlsZSgke2lkfSxcIm9pZF9maWxlXCIpYDtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCh1cmwpO1xyXG5cclxuICAgICAgICBjb25zdCBibG9iID0gYXdhaXQgcmVzLmJsb2IoKTtcclxuICAgICAgICBjb25zdCBzZXJpYWxpemVkQmxvYiA9IG5ldyBVaW50OEFycmF5KGF3YWl0IGJsb2IuYXJyYXlCdWZmZXIoKSk7XHJcbiAgXHJcbiAgICAgICAgbGV0IGJsb2JEYXRhID0ge1xyXG4gICAgICAgICAgICB0eXBlOiBibG9iLnR5cGUsXHJcbiAgICAgICAgICAgIGJ1ZmZlcjogQXJyYXkuZnJvbShzZXJpYWxpemVkQmxvYilcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICByZXR1cm4gYmxvYkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZGVsZXRlTmF2ZXRGaWxlKGlkKSB7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHtcclxuICAgICAgICAgICAgaW52b2tlOiBgVGJDbGllbnRzUmVxdWlyZWREb2N1bWVudHNNYW5hZ2VyLmN1c3RvbVNldFRvRmFsc2UoJHtpZH0pYCxcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKGF3YWl0IHBvc3RGb3JtKGhvc3QsIGJvZHkpKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyogRXhwZXJpbWVudGFsICovXHJcbiAgICBhc3luYyBmdW5jdGlvbiBuYXZldExvZ2luKHVzZXJuYW1lLCBwYXNzd29yZCkge1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSB7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlOiAnY2xpZW50JyxcclxuICAgICAgICAgICAgcmVxdWVzdDogJ2xvZ2luJyxcclxuICAgICAgICAgICAgdXNlcm5hbWUsXHJcbiAgICAgICAgICAgIHBhc3N3b3JkXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgY29uc3QgaGVhZGVyID0gZW5jb2RlVVJJQ29tcG9uZW50KEpTT04uc3RyaW5naWZ5KGJvZHkpKTtcclxuXHJcbiAgICAgICAgY29uc3QgdXJsID0gJy9yZXNwb25zZSc7XHJcblxyXG4gICAgICAgIGxldCByZXF1ZXN0ID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XHJcbiAgICAgICAgcmVxdWVzdC5vbnJlYWR5c3RhdGVjaGFuZ2UgPSAoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChyZXF1ZXN0LnJlYWR5U3RhdGUgPT0gNCAmJiAocmVxdWVzdC5zdGF0dXMgPT0gMjAwIHx8IHdpbmRvdy5sb2NhdGlvbi5ocmVmLmluZGV4T2YoJ2h0dHAnKSA9PSAtMSkpIHtcclxuICAgICAgICAgICAgICAgIGxldCB1ZGF0ID0gSlNPTi5wYXJzZShyZXF1ZXN0LnJlc3BvbnNlVGV4dCk7XHJcbiAgICAgICAgICAgICAgICBpZiAodWRhdC5zdGF0dXMgPT0gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gJy8nO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Vycm9yOiAnICsgdWRhdC5lcnJvcl9jb2RlKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHJlcXVlc3QgPSBudWxsO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgY29uc3QgY2FjaGUgPSAnPycgKyBuZXcgRGF0ZSgpLmdldFRpbWUoKTtcclxuICAgICAgICByZXF1ZXN0Lm9wZW4oJ0dFVCcsIHVybCArIGNhY2hlLCB0cnVlKTtcclxuICAgICAgICByZXF1ZXN0LnNldFJlcXVlc3RIZWFkZXIoJ0FDQ1NTQ1RSTCcsIGhlYWRlcik7XHJcbiAgICAgICAgcmVxdWVzdC5zZW5kKG51bGwpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEdyYWR1YXRlSW5mbyhpZCkge1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSB7XHJcbiAgICAgICAgICAgIGludm9rZTogYFJlZkNsaWVudHNDb3Vyc2VzTWFuYWdlci5nZXRCeUlkKCR7aWR9KWAsXHJcbiAgICAgICAgfTtcclxuICAgICAgICByZXR1cm4gcGFyc2VSZXNwb25zZShhd2FpdCBwb3N0Rm9ybShob3N0LCBib2R5KSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRDZXJ0aWZpY2F0ZShpZCkge1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSB7XHJcbiAgICAgICAgICAgIGludm9rZTogYFZpZXdDbGllbnRzQ291cnNlc0RvY3VtZW50c01hbmFnZXIuZ2V0QnlDbGllbnRDb3Vyc2VzSWQoJHtpZH0pYCxcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKGF3YWl0IHBvc3RGb3JtKGhvc3QsIGJvZHkpKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBvcGVuTmF2ZXRDZXJ0aWZpY2F0ZShpZCwgcGFnZSkge1xyXG4gICAgICAgIGNvbnN0IHVybCA9IGAke2hvc3R9P2FwcGxpY2F0aW9uPUFKQVhEYXRhUHJvdmlkZXImaW52b2tlPVRiQ2xpZW50c0NvdXJzZXNEb2N1bWVudHNNYW5hZ2VyLmN1c3RvbURvd25sb2FkRmlsZSgke2lkfSwgXCJkb2N1bWVudF8ke3BhZ2V9X2ZpbGVcIilgO1xyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKHVybCk7XHJcbiAgICAgICAgY29uc3QgYmxvYiA9IGF3YWl0IHJlcy5ibG9iKCk7XHJcbiAgICAgICAgaWYgKGJsb2IudHlwZSA9PSAndGV4dC9qYXZhc2NyaXB0Jykge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdZb3VyIHNlc3Npb24gaGFzIGV4cGlyZWQuIFBsZWFzZSBlbnRlciB5b3VyIGNyZWRlbnRpYWxzIGFnYWluLicpO1xyXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1lvdXIgc2Vzc2lvbiBoYXMgZXhwaXJlZC4gUGxlYXNlIGVudGVyIHlvdXIgY3JlZGVudGlhbHMgYWdhaW4uJyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCBzZXJpYWxpemVkQmxvYiA9IG5ldyBVaW50OEFycmF5KGF3YWl0IGJsb2IuYXJyYXlCdWZmZXIoKSk7XHJcbiAgXHJcbiAgICAgICAgbGV0IGJsb2JEYXRhID0ge1xyXG4gICAgICAgICAgICB0eXBlOiBibG9iLnR5cGUsXHJcbiAgICAgICAgICAgIGJ1ZmZlcjogQXJyYXkuZnJvbShzZXJpYWxpemVkQmxvYilcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICByZXR1cm4gYmxvYkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gdXBsb2FkTmF2ZXRDZXJ0aWZpY2F0ZShtZXRhLCBmaWxlRGVzY3JpcHRvcnMpIHtcclxuICAgICAgICBjb25zdCBmaWxlcyA9IGF3YWl0IFByb21pc2UuYWxsKGZpbGVEZXNjcmlwdG9ycy5tYXAoYXN5bmMgZGVzY3JpcHRvciA9PiB7XHJcbiAgICAgICAgICAgIGlmIChkZXNjcmlwdG9yID09PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICAgICAgfSBlbHNlIGlmIChkZXNjcmlwdG9yLmZpbGVVcmwgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgICAgICBibG9iOiBhd2FpdCAoYXdhaXQgZmV0Y2goZGVzY3JpcHRvci5maWxlVXJsKSkuYmxvYigpLFxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGVuYW1lOiBkZXNjcmlwdG9yLm5hbWVcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGJsb2I6IGRlc2NyaXB0b3IuZmlsZSxcclxuICAgICAgICAgICAgICAgICAgICBmaWxlbmFtZTogZGVzY3JpcHRvci5maWxlLm5hbWVcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KSk7XHJcblxyXG5cclxuICAgICAgICBjb25zdCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xyXG5cclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2lkJywgbWV0YS5pZCk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnRfY2xpZW50c19jb3Vyc2VzX2lkJywgbWV0YS5pbnRfY2xpZW50c19jb3Vyc2VzX2lkKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludF9kb2N1bWVudF90eXBlX2lkJywgbWV0YS5pbnRfZG9jdW1lbnRfdHlwZV9pZCk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCc2MDgtdGV4dCcsICfQo9C00L7RgdGC0L7QstC10YDQtdC90LjQtSDQt9CwINC/0YDQvtGE0LXRgdC40L7QvdCw0LvQvdC+INC+0LHRg9GH0LXQvdC40LUnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludF9jb3Vyc2VfZmluaXNoZWRfeWVhcicsIG1ldGEuaW50X2NvdXJzZV9maW5pc2hlZF95ZWFyKTsgLy8gbmVlZCB0aGlzIGFkZGVkXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCd2Y19kb2N1bWVudF9wcm5fbm8nLCAnJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCc2MTItdGV4dCcsICcnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX29yaWdpbmFsX3Bybl9ubycsIG1ldGEudmNfZG9jdW1lbnRfcHJuX25vKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX2RvY3VtZW50X3JlZ19ubycsIG1ldGEudmNfZG9jdW1lbnRfcmVnX25vKTsgLy8gbmVlZCB0aGlzIGFkZGVkXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCd2Y19kb2N1bWVudF9wcm90JywgbWV0YS52Y19kb2N1bWVudF9wcm90KTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ251bV90aGVvcnlfcmVzdWx0JywgbWV0YS5udW1fdGhlb3J5X3Jlc3VsdCk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdudW1fcHJhY3RpY2VfcmVzdWx0JywgbWV0YS5udW1fcHJhY3RpY2VfcmVzdWx0KTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX3F1YWxpZmljYXRpb25fbmFtZScsIG1ldGEudmNfcXVhbGlmaWNhdGlvbl9uYW1lKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX3F1YWxpZmljYXRpb2pfbGV2ZWwnLCBtZXRhLnZjX3F1YWxpZmljYXRpb2pfbGV2ZWwpO1xyXG5cclxuICAgICAgICBpZiAoZmlsZXNbMF0gIT09IG51bGwpIHtcclxuICAgICAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdkb2N1bWVudF8xX2ZpbGVfYWN0aW9uJywgJ3VwbG9hZCcpO1xyXG4gICAgICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2RvY3VtZW50XzFfZmlsZScsIGZpbGVzWzBdLmJsb2IsIGZpbGVzWzBdLmZpbGVuYW1lKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2RvY3VtZW50XzFfZmlsZV9hY3Rpb24nLCAnJyk7XHJcbiAgICAgICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnZG9jdW1lbnRfMV9maWxlJywgbmV3IEJsb2IoWycnXSksICcnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChmaWxlc1sxXSAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2RvY3VtZW50XzJfZmlsZV9hY3Rpb24nLCAndXBsb2FkJyk7XHJcbiAgICAgICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnZG9jdW1lbnRfMl9maWxlJywgZmlsZXNbMV0uYmxvYiwgZmlsZXNbMV0uZmlsZW5hbWUpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnZG9jdW1lbnRfMl9maWxlX2FjdGlvbicsICcnKTtcclxuICAgICAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdkb2N1bWVudF8yX2ZpbGUnLCBuZXcgQmxvYihbJyddKSwgJycpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnZva2UnLCBgVGJDbGllbnRzQ291cnNlc0RvY3VtZW50c01hbmFnZXIudXBkYXRlT2JqZWN0KCR7bWV0YS5pZH0pYCk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdhcHBsaWNhdGlvbicsICdBSkFYRGF0YVByb3ZpZGVyJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdwcm90b2NvbCcsICdkYXRhSUZyYW1lJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdkdF9kb2N1bWVudF9kYXRlJywgbWV0YS5kdF9kb2N1bWVudF9kYXRlKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX2RvY3VtZW50X3R5cGVfbmFtZScsIG1ldGEudmNfZG9jdW1lbnRfdHlwZV9uYW1lKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludF9kb2N1bWVudF9zdGF0dXMnLCBtZXRhLmludF9kb2N1bWVudF9zdGF0dXMpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnYm9vbF93aXRoX25vdGUnLCBtZXRhLmJvb2xfd2l0aF9ub3RlKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2FzeW5jX2lmcmFtZV9pZCcsICdhc3luY19pZnJhbWVfNjM5Jyk7XHJcblxyXG5cclxuICAgICAgICByZXR1cm4gdXBsb2FkRmlsZShmb3JtRGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gdXBkYXRlTmF2ZXRTdHVkZW50KGlkLCBzdHVkZW50KSB7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IE9iamVjdC5hc3NpZ24oe30sIHN0dWRlbnQsIHtcclxuICAgICAgICAgICAgaW52b2tlOiBgUmVmQ2xpZW50c0NvdXJzZXNNYW5hZ2VyLnVwZGF0ZU9iamVjdCgke2lkfSlgLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKGF3YWl0IHBvc3RGb3JtKGhvc3QsIGJvZHkpKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBjcmVhdGVEb2N1bWVudChzdHVkZW50SWQsIGNsaWVudElkLCBkYXRhKSB7XHJcbiAgICAgICAgY29uc3QgZm9ybURhdGEgPSBuZXcgRm9ybURhdGEoKTtcclxuICAgICAgICBcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2lkJywgbnVsbCk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnRfY2xpZW50c19jb3Vyc2VzX2lkJywgbnVsbCk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnRfZG9jdW1lbnRfdHlwZV9pZCcsICcnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJzMwNC10ZXh0JywgJ9Cj0LTQvtGB0YLQvtCy0LXRgNC10L3QuNC1INC30LAg0L/RgNC+0YTQtdGB0LjQvtC90LDQu9C90L4g0L7QsdGD0YfQtdC90LjQtScpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaW50X2NvdXJzZV9maW5pc2hlZF95ZWFyJywgZGF0YS5pbnRfY291cnNlX2ZpbmlzaGVkX3llYXIpOyAvLyBuZWVkIHRoaXMgYWRkZWRcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX2RvY3VtZW50X3Bybl9ubycsICcnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJzMwOC10ZXh0JywgJycpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndmNfZG9jdW1lbnRfcmVnX25vJywgZGF0YS52Y19kb2N1bWVudF9yZWdfbm8pOyAvLyBuZWVkIHRoaXMgYWRkZWRcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX2RvY3VtZW50X3Byb3QnLCAnJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdudW1fdGhlb3J5X3Jlc3VsdCcsIDApO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnbnVtX3ByYWN0aWNlX3Jlc3VsdCcsIDApO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndmNfcXVhbGlmaWNhdGlvbl9uYW1lJywgJycpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndmNfcXVhbGlmaWNhdGlval9sZXZlbCcsICcnKTtcclxuXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdkb2N1bWVudF8xX2ZpbGVfYWN0aW9uJywgJycpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnZG9jdW1lbnRfMV9maWxlJywgbmV3IEJsb2IoWycnXSksICcnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2RvY3VtZW50XzJfZmlsZV9hY3Rpb24nLCAnJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdkb2N1bWVudF8yX2ZpbGUnLCBuZXcgQmxvYihbJyddKSwgJycpO1xyXG5cclxuICAgICAgICBcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludm9rZScsICdDdXN0b21FdmVudHNNYW5hZ2VyLmN1c3RvbVRiQ2xpZW50c0NvdXJzZXNEb2N1bWVudHMoMSknKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2FwcGxpY2F0aW9uJywgJ0FKQVhEYXRhUHJvdmlkZXInKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3Byb3RvY29sJywgJ2RhdGFJRnJhbWUnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludF9wcm92aWRlcl9pZCcsIDI5MjkpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgncmVmX2NsaWVudHNfY291cnNlc19pZF90Jywgc3R1ZGVudElkKTsgLy9kYXRhLmlkXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCd0Yl9jbGllbnRzX2lkX3QnLCBjbGllbnRJZCk7IC8vZGF0YS5pbnRfY2xpZW50X2lkXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdkdF9kb2N1bWVudF9kYXRlX3QnLCAnJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnRfY2xpZW50X2NvdXJzZV9pZF90Jywgc3R1ZGVudElkKTsgLy9kYXRhLmlkXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnRfZG9jdW1lbnRfdHlwZV9pZF90JywgMik7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCd2Y19kb2N1bWVudF9wcm5fbm9fdCcsICcnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX2RvY3VtZW50X3JlZ19ub190JywgZGF0YS52Y19kb2N1bWVudF9yZWdfbm8pOyAvLyBuZWVkIHRoaXMgYWRkZWQsIHNhbWUgYXMgYWJvdmVcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludF9kb2N1bWVudF9zdGF0dXMnLCAwKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2FzeW5jX2lmcmFtZV9pZCcsICdhc3luY19pZnJhbWVfMzI5Jyk7XHJcblxyXG5cclxuICAgICAgICByZXR1cm4gdXBsb2FkRmlsZShmb3JtRGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBnZXROYXZldEN1cnJlbnRDb3Vyc2VzLFxyXG4gICAgICAgIGdldE5hdmV0Q2xvc2VkQ291cnNlcyxcclxuICAgICAgICBnZXROYXZldEFyY2hpdmVkQ291cnNlcyxcclxuICAgICAgICBnZXROYXZldENvdXJzZUluZm8sXHJcbiAgICAgICAgZ2V0TmF2ZXRTdHVkZW50cyxcclxuICAgICAgICBnZXROYXZldFN0dWRlbnRJbmZvLFxyXG4gICAgICAgIGdldE5hdmV0RXhpc3RpbmdGaWxlcyxcclxuICAgICAgICB1cGxvYWRNZWRpY2FsLFxyXG4gICAgICAgIHVwbG9hZERpcGxvbWEsXHJcbiAgICAgICAgb3Blbk5hdmV0RmlsZSxcclxuICAgICAgICBkZWxldGVOYXZldEZpbGUsXHJcbiAgICAgICAgZ2V0R3JhZHVhdGVJbmZvLFxyXG4gICAgICAgIGdldE5hdmV0Q2VydGlmaWNhdGUsXHJcbiAgICAgICAgb3Blbk5hdmV0Q2VydGlmaWNhdGUsXHJcbiAgICAgICAgdXBsb2FkTmF2ZXRDZXJ0aWZpY2F0ZSxcclxuICAgICAgICB1cGRhdGVOYXZldFN0dWRlbnQsXHJcbiAgICAgICAgY3JlYXRlRG9jdW1lbnQsXHJcbiAgICAgICAgZ2V0RXh0cmFDb3Vyc2VJbmZvXHJcbiAgICB9O1xyXG59IiwiaW1wb3J0IHsgQ29udGVudFR5cGUgfSBmcm9tIFwiLi4vLi4vdXRpbC9jb250ZW50VHlwZXMuanNcIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCwgZ2V0LCBpbnRlcm9wUGxhdGZvcm1Ib3N0LCBpbnRlcm9wQWRtaW5BbHBoYUp1ZGdlSG9zdCB9KSB7XHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRDb250ZXN0Q29tcGV0ZVJlc3VsdHMoY29udGVzdElkKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gYCR7aW50ZXJvcEFkbWluQWxwaGFKdWRnZUhvc3QoKX0vYXBpL2NvbnRlc3RzL0V4cG9ydFJlc3VsdHNgO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSB7XHJcbiAgICAgICAgICAgIGlkOiBjb250ZXN0SWQsXHJcbiAgICAgICAgICAgIHR5cGU6IDAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGxldCBibG9iID0gYXdhaXQgcG9zdCh1cmksIGJvZHksIENvbnRlbnRUeXBlLkFwcGxpY2F0aW9uSnNvbiwgdHJ1ZSk7XHJcbiAgICAgICAgY29uc3Qgc2VyaWFsaXplZEJsb2IgPSBuZXcgVWludDhBcnJheShhd2FpdCBibG9iLmFycmF5QnVmZmVyKCkpO1xyXG4gICAgICAgIGNvbnN0IGJsb2JEYXRhID0ge1xyXG4gICAgICAgICAgICB0eXBlOiBibG9iLnR5cGUsXHJcbiAgICAgICAgICAgIGZpbGVuYW1lOiBibG9iLmZpbGVuYW1lLFxyXG4gICAgICAgICAgICBidWZmZXI6IEFycmF5LmZyb20oc2VyaWFsaXplZEJsb2IpXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgcmV0dXJuIGJsb2JEYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldENvbnRlc3RQcmFjdGljZVJlc3VsdHMoY29udGVzdElkKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gYCR7aW50ZXJvcEFkbWluQWxwaGFKdWRnZUhvc3QoKX0vYXBpL2NvbnRlc3RzL0V4cG9ydFJlc3VsdHNgO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSB7XHJcbiAgICAgICAgICAgIGlkOiBjb250ZXN0SWQsXHJcbiAgICAgICAgICAgIHR5cGU6IDEgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgbGV0IGJsb2IgPSBhd2FpdCBwb3N0KHVyaSwgYm9keSwgQ29udGVudFR5cGUuQXBwbGljYXRpb25Kc29uLCB0cnVlKTtcclxuICAgICAgICBjb25zdCBzZXJpYWxpemVkQmxvYiA9IG5ldyBVaW50OEFycmF5KGF3YWl0IGJsb2IuYXJyYXlCdWZmZXIoKSk7XHJcbiAgICAgICAgY29uc3QgYmxvYkRhdGEgPSB7XHJcbiAgICAgICAgICAgIHR5cGU6IGJsb2IudHlwZSxcclxuICAgICAgICAgICAgZmlsZW5hbWU6IGJsb2IuZmlsZW5hbWUsXHJcbiAgICAgICAgICAgIGJ1ZmZlcjogQXJyYXkuZnJvbShzZXJpYWxpemVkQmxvYilcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICByZXR1cm4gYmxvYkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBnZXRDb250ZXN0Q29tcGV0ZVJlc3VsdHMsXHJcbiAgICAgICAgZ2V0Q29udGVzdFByYWN0aWNlUmVzdWx0c1xyXG4gICAgfTtcclxufSIsImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCB9KSB7XHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRNb2R1bGVzSW5Qcm9mZXNzaW9uKHByb2Zlc3Npb25JZCkge1xyXG4gICAgICAgIGNvbnN0IHVybCA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChpbnRlcm9wQXBwSWQoKSA9PT0gJ3NvZnR1bmkuYmcnKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3Byb2Zlc3Npb25zL2xldmVsZ3JvdXBzaW5wcm9mZXNzaW9uaW5zdGFuY2VzL3JlYWQ/Zm9yZWlnbktleUlkPSR7cHJvZmVzc2lvbklkfWApO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGludGVyb3BIb3N0KGBBZG1pbmlzdHJhdGlvbl9Qcm9mZXNzaW9ucy9Db3Vyc2VHcm91cHNJblByb2Zlc3Npb25JbnN0YW5jZXMvUmVhZD9mb3JlaWduS2V5SWQ9JHtwcm9mZXNzaW9uSWR9YCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KSgpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVybCwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0TW9kdWxlcygpIHtcclxuICAgICAgICBjb25zdCB1cmwgPSAgaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX0xldmVscy9sZXZlbHMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJsLCBib2R5KSkuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRJbnN0YW5jZXNJbk1vZHVsZShtb2R1bGVJZCkge1xyXG4gICAgICAgIGNvbnN0IHVybCA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChpbnRlcm9wQXBwSWQoKSA9PT0gJ3NvZnR1bmkuYmcnKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX2xldmVscy9sZXZlbGluc3RhbmNlcy9yZWFkP2ltcG9ydExldmVsSWQ9JHttb2R1bGVJZH0mbGV2ZWxJZD0ke21vZHVsZUlkfWApO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGludGVyb3BIb3N0KGBBZG1pbmlzdHJhdGlvbl9MZXZlbHMvTGV2ZWxJbnN0YW5jZXMvUmVhZD9pbXBvcnRMZXZlbElkPSR7bW9kdWxlSWR9JmxldmVsSWQ9JHttb2R1bGVJZH0mZm9yZWlnbktleUlkPSR7bW9kdWxlSWR9YCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KSgpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmwsIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEluc3RhbmNlSW5Nb2R1bGUobW9kdWxlSWQsIG1vZHVsZUluc3RhbmNlSWQpIHtcclxuICAgICAgICBjb25zdCB1cmwgPSAoKCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoaW50ZXJvcEFwcElkKCkgPT09ICdzb2Z0dW5pLmJnJykge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl9sZXZlbHMvbGV2ZWxpbnN0YW5jZXMvcmVhZD9pbXBvcnRMZXZlbElkPSR7bW9kdWxlSWR9JmxldmVsSWQ9JHttb2R1bGVJZH1gKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdChgQWRtaW5pc3RyYXRpb25fTGV2ZWxzL0xldmVsSW5zdGFuY2VzL1JlYWQ/aW1wb3J0TGV2ZWxJZD0ke21vZHVsZUlkfSZsZXZlbElkPSR7bW9kdWxlSWR9JmZvcmVpZ25LZXlJZD0ke21vZHVsZUlkfWApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSkoKTtcclxuXHJcbiAgICAgICAgbGV0IGZpbHRlciA9IGBJZH5lcX4ke21vZHVsZUluc3RhbmNlSWR9YDtcclxuXHJcbiAgICAgICAgaWYoQXJyYXkuaXNBcnJheShtb2R1bGVJbnN0YW5jZUlkKSkge1xyXG4gICAgICAgICAgICBmaWx0ZXIgPSBgSWR+ZXF+JHttb2R1bGVJbnN0YW5jZUlkLmpvaW4oJ35vcn5JZH5lcX4nKX1gO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogZmlsdGVyXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVybCwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gc2VhcmNoTW9kdWxlcyhxdWVyeSkge1xyXG4gICAgICAgIGNvbnN0IHVybCA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl9sZXZlbHMvbGV2ZWxzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSBgTmFtZUJnfmNvbnRhaW5zficke3F1ZXJ5LnNwbGl0KCcgJykuZmlsdGVyKHMgPT4gcy5sZW5ndGggPiAwKS5qb2luKCdcXCd+YW5kfk5hbWVCZ35jb250YWluc35cXCcnKX0nYDtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMCxcclxuICAgICAgICAgICAgZmlsdGVyLFxyXG4gICAgICAgICAgICBzb3J0OiAnQ3JlYXRlZE9uLWRlc2MnXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmwsIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgZ2V0TW9kdWxlc0luUHJvZmVzc2lvbixcclxuICAgICAgICBnZXRNb2R1bGVzLFxyXG4gICAgICAgIGdldEluc3RhbmNlc0luTW9kdWxlLFxyXG4gICAgICAgIHNlYXJjaE1vZHVsZXMsXHJcbiAgICAgICAgZ2V0SW5zdGFuY2VJbk1vZHVsZVxyXG4gICAgfTtcclxufSIsImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCwgZ2V0LCBpbnRlcm9wUGxhdGZvcm1Ib3N0IH0pIHtcclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFBheW1lbnRzRm9yUGFja2FnZShwYWNrYWdlTmFtZSkge1xyXG4gICAgICAgIC8vIFRoaXMgZmllbGQgZG9lcyBub3Qgd29yayB3aXRoIG11bHRpcGxlIHZhbHVlc1xyXG4gICAgICAgIC8qXHJcbiAgICAgICAgY29uc3QgZmlsdGVyID0gKCgpID0+IHtcclxuICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkocGFja2FnZUlkKSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGBQYXltZW50UGFja2FnZXNBc1N0cmluZ35lcX4nJHtwYWNrYWdlSWQuam9pbignXFwnfm9yflBheW1lbnRQYWNrYWdlc0FzU3RyaW5nfmVxflxcJycpfSdgO1xyXG4gICAgICAgICAgICAgICAgLy9yZXR1cm4gYFBheW1lbnRTdGF0dXN+ZXF+NH5hbmR+KFBheW1lbnRQYWNrYWdlc0FzU3RyaW5nfmVxficke3BhY2thZ2VJZC5qb2luKCdcXCd+b3J+UGF5bWVudFBhY2thZ2VzQXNTdHJpbmd+ZXF+XFwnJyl9JylgO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGBQYXltZW50UGFja2FnZXNBc1N0cmluZ35lcX4nJHtwYWNrYWdlSWR9J2A7XHJcbiAgICAgICAgICAgICAgICAvL3JldHVybiBgUGF5bWVudFN0YXR1c35lcX40fmFuZH5QYXltZW50UGFja2FnZXNBc1N0cmluZ35lcX4ke3BhY2thZ2VJZH1gO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSkoKTtcclxuICAgICAgICAqL1xyXG5cclxuICAgICAgICBjb25zdCB1cmwgPSBgJHtpbnRlcm9wUGxhdGZvcm1Ib3N0KCl9L2FkbWluaXN0cmF0aW9uL3BheW1lbnRzL3JlYWQ/YXBwSWQ9JHtpbnRlcm9wQXBwSWQoKX1gO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogYFBheW1lbnRTdGF0dXN+ZXF+NH5hbmR+UGF5bWVudFBhY2thZ2VzQXNTdHJpbmd+ZXF+JyR7cGFja2FnZU5hbWV9J2BcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJsLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRQYWNrYWdlc0ZvclByb2R1Y3QocHJvZHVjdElkKSB7XHJcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkocHJvZHVjdElkKSAmJiBwcm9kdWN0SWQubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB7IERhdGE6IFtdIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KHByb2R1Y3RJZCkpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBgTmFtZX5kb2Vzbm90Y29udGFpbn4nSUknfmFuZH4oUHJvZHVjdC5JZH5lcX4ke3Byb2R1Y3RJZC5qb2luKCd+b3J+UHJvZHVjdC5JZH5lcX4nKX0pYDtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBgTmFtZX5kb2Vzbm90Y29udGFpbn4nSUknfmFuZH5Qcm9kdWN0LklkfmVxfiR7cHJvZHVjdElkfWA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KSgpO1xyXG4gICAgICAgIGNvbnN0IHVybCA9IGAke2ludGVyb3BQbGF0Zm9ybUhvc3QoKX0vYWRtaW5pc3RyYXRpb24vcGF5bWVudHBhY2thZ2VzL3JlYWQ/YXBwSWQ9JHtpbnRlcm9wQXBwSWQoKX1gO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMCxcclxuICAgICAgICAgICAgZmlsdGVyXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVybCwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0UHJvZHVjdHNGb3JNb2R1bGUobW9kdWxlSWQpIHtcclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSAoKCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShtb2R1bGVJZCkpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBgTmFtZX5kb2Vzbm90Y29udGFpbn4nSUknfmFuZH4oTGV2ZWxJbnN0YW5jZUlkfmVxfiR7bW9kdWxlSWQuam9pbignfm9yfkxldmVsSW5zdGFuY2VJZH5lcX4nKX0pYDtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBgTmFtZX5kb2Vzbm90Y29udGFpbn4nSUknfmFuZH5MZXZlbEluc3RhbmNlSWR+ZXF+JHttb2R1bGVJZH1gO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSkoKTtcclxuICAgICAgICBjb25zdCB1cmwgPSBgJHtpbnRlcm9wUGxhdGZvcm1Ib3N0KCl9L2FkbWluaXN0cmF0aW9uL2xldmVsaW5zdGFuY2Vwcm9kdWN0cy9yZWFkP2FwcElkPSR7aW50ZXJvcEFwcElkKCl9YDtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAsXHJcbiAgICAgICAgICAgIGZpbHRlclxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmwsIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFByb2R1Y3RzRm9yQ291cnNlKGluc3RhbmNlSWQsIHR5cGUgPSAnb3BlbicpIHtcclxuICAgICAgICBjb25zdCBlcFN0cmluZ3MgPSAoKCkgPT4ge1xyXG4gICAgICAgICAgICBzd2l0Y2ggKHR5cGUpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgJ29wZW4nOlxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhdGg6ICdmYXN0dHJhY2tpbnN0YW5jZXByb2R1Y3RzJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW06ICdGYXN0VHJhY2tJbnN0YW5jZUlkJ1xyXG4gICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KSgpO1xyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KGluc3RhbmNlSWQpKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gYCgke2VwU3RyaW5ncy5wYXJhbX1+ZXF+JHtpbnN0YW5jZUlkLmpvaW4oYH5vcn4ke2VwU3RyaW5ncy5wYXJhbX1+ZXF+YCl9KWA7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gYCR7ZXBTdHJpbmdzLnBhcmFtfX5lcX4ke2luc3RhbmNlSWR9YDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKCk7XHJcbiAgICAgICAgY29uc3QgdXJsID0gYCR7aW50ZXJvcFBsYXRmb3JtSG9zdCgpfS9hZG1pbmlzdHJhdGlvbi8ke2VwU3RyaW5ncy5wYXRofS9yZWFkP2FwcElkPSR7aW50ZXJvcEFwcElkKCl9YDtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAsXHJcbiAgICAgICAgICAgIGZpbHRlclxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmwsIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgZ2V0UGF5bWVudHNGb3JQYWNrYWdlLFxyXG4gICAgICAgIGdldFBhY2thZ2VzRm9yUHJvZHVjdCxcclxuICAgICAgICBnZXRQcm9kdWN0c0Zvck1vZHVsZSxcclxuICAgICAgICBnZXRQcm9kdWN0c0ZvckNvdXJzZVxyXG4gICAgfTtcclxufSIsImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCwgZ2V0IH0pIHtcclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBjcmVhdGVRdWl6SW5zdGFuY2UocGF5bG9hZCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90ZXN0c3lzdGVtL3Rlc3RzL2NyZWF0ZScpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnLFxyXG4gICAgICAgICAgICBJZDogMCxcclxuICAgICAgICAgICAgTmFtZTogcGF5bG9hZC5uYW1lLFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbjogcGF5bG9hZC5kZXNjcmlwdGlvbixcclxuICAgICAgICAgICAgUXVlc3Rpb25zQ291bnQ6IDBcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIGF3YWl0IHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBhZGRRdWVzdGlvbihxdWl6SWQsIHF1ZXN0aW9uKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3Rlc3RzeXN0ZW0vdGVzdHF1ZXN0aW9ucy9jcmVhdGU/Zm9yZWlnbktleUlkPSR7cXVpeklkfWApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnLFxyXG4gICAgICAgICAgICBJZDogMCxcclxuICAgICAgICAgICAgVHlwZTogMSxcclxuICAgICAgICAgICAgQ29udGVudDogcXVlc3Rpb24sXHJcbiAgICAgICAgICAgIENvcnJlY3RBbnN3ZXJQb2ludHM6IDEsXHJcbiAgICAgICAgICAgIFdyb25nQW5zd2VyUG9pbnRzOiAwLFxyXG4gICAgICAgICAgICBLZWVwQW5zd2Vyc09yZGVyOiBmYWxzZSxcclxuICAgICAgICAgICAgU2hvd0NvcnJlY3RBbnN3ZXJzQ291bnQ6IGZhbHNlLFxyXG4gICAgICAgICAgICBDb3JyZWN0Q291bnQ6IDAsXHJcbiAgICAgICAgICAgIFdyb25nQ291bnQ6IDAsXHJcbiAgICAgICAgICAgIEFsbENvdW50OiAwLFxyXG4gICAgICAgICAgICBQZXJjZW50Q29ycmVjdDogMFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gYXdhaXQgcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGFkZEFuc3dlcihxdWVzdGlvbklkLCBhbnN3ZXIsIGlzQ29ycmVjdCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90ZXN0c3lzdGVtL3Rlc3RxdWVzdGlvbmFuc3dlcnMvY3JlYXRlP2ZvcmVpZ25LZXlJZD0ke3F1ZXN0aW9uSWR9YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiAwLFxyXG4gICAgICAgICAgICBRdWVzdGlvbklkOiAwLFxyXG4gICAgICAgICAgICBDb250ZW50OiBhbnN3ZXIsXHJcbiAgICAgICAgICAgIElzQ29ycmVjdDogaXNDb3JyZWN0LFxyXG4gICAgICAgICAgICBTZWxlY3RlZENvdW50OiAwXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBhd2FpdCBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0QWxsUXVpemVzQnlOYW1lKGNvbnRhaW5pbmdOYW1lLCBwYWdlU2l6ZSwgcGFnZSkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90ZXN0c3lzdGVtL3Rlc3RzL3JlYWRgKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiBgTmFtZX5jb250YWluc34nJHtjb250YWluaW5nTmFtZX0nYCxcclxuICAgICAgICAgICAgcGFnZVNpemUsXHJcbiAgICAgICAgICAgIHBhZ2VcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIGF3YWl0IHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRRdWVzdGlvbnNCeUlkKHF1aXpJZCwgcGFnZVNpemUsIHBhZ2UpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdGVzdHN5c3RlbS90ZXN0cXVlc3Rpb25zL3JlYWQ/Zm9yZWlnbktleUlkPSR7cXVpeklkfWApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnLFxyXG4gICAgICAgICAgICBwYWdlU2l6ZSxcclxuICAgICAgICAgICAgcGFnZVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gYXdhaXQgcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEFuc3dlcnNCeVF1ZXN0aW9uSWQocXVlc3Rpb25JZCwgcGFnZVNpemUsIHBhZ2UpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdGVzdHN5c3RlbS90ZXN0cXVlc3Rpb25hbnN3ZXJzL3JlYWQ/Zm9yZWlnbktleUlkPSR7cXVlc3Rpb25JZH1gKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgcGFnZVNpemUsXHJcbiAgICAgICAgICAgIHBhZ2VcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIGF3YWl0IHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGNyZWF0ZVF1aXpJbnN0YW5jZSxcclxuICAgICAgICBhZGRRdWVzdGlvbixcclxuICAgICAgICBhZGRBbnN3ZXIsXHJcbiAgICAgICAgZ2V0QWxsUXVpemVzQnlOYW1lLFxyXG4gICAgICAgIGdldFF1ZXN0aW9uc0J5SWQsXHJcbiAgICAgICAgZ2V0QW5zd2Vyc0J5UXVlc3Rpb25JZFxyXG4gICAgfTtcclxufSIsImltcG9ydCBnZW5lcmljQXBpRmFjdG9yeSBmcm9tICcuL2dlbmVyaWMnO1xyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCwgZ2V0IH0pIHtcclxuICAgIGNvbnN0IGdlbmVyaWNBcGkgPSBnZW5lcmljQXBpRmFjdG9yeSh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCwgZ2V0IH0pO1xyXG5cclxuXHJcbiAgICBjb25zdCBzdG9yZUlkID0ge1xyXG4gICAgICAgICdzb2Z0dW5pLmJnJzogMzc5NyxcclxuICAgICAgICAnZGlnaXRhbC5zb2Z0dW5pLmJnJzogMzU1NixcclxuICAgICAgICAnY3JlYXRpdmUuc29mdHVuaS5iZyc6IDE0MTEsXHJcbiAgICAgICAgJ2FpLnNvZnR1bmkuYmcnOiA2LFxyXG4gICAgICAgICdmaW5hbmNlYWNhZGVteS5iZyc6IDczXHJcbiAgICB9O1xyXG5cclxuICAgIGZ1bmN0aW9uIHNlcmlhbGl6ZShkYXRhKSB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgSWQ6IGRhdGEuSWQgfHwgMCxcclxuICAgICAgICAgICAgVHJhaW5pbmdJZDogc3RvcmVJZFtpbnRlcm9wQXBwSWQoKV0sXHJcbiAgICAgICAgICAgIE5hbWVCZzogJzAwMDAwMDAwMDAnICsgZGF0YS5FeGFtSWQsXHJcbiAgICAgICAgICAgIE5hbWVFbjogJzAwMDAwMDAwMDAnLFxyXG4gICAgICAgICAgICBIYXNNYW51YWxOdW1iZXJPZlN0dWR5SG91cnM6IHRydWUsXHJcbiAgICAgICAgICAgIE51bWJlck9mU3R1ZHlIb3VyczogMCxcclxuICAgICAgICAgICAgSXNFeGNsdWRlZEZyb21DZXJ0aWZpY2F0ZTogZmFsc2UsXHJcbiAgICAgICAgICAgIEhhc0hvbWV3b3JrOiBmYWxzZSxcclxuICAgICAgICAgICAgUmVzb3VyY2VNYWlsc1N0YXRlOiAwLFxyXG4gICAgICAgICAgICBIb21ld29ya01haWxzU3RhdGU6IDAsXHJcbiAgICAgICAgICAgIEp1ZGdlQ29udGVzdElkOiAnJyxcclxuICAgICAgICAgICAgT3JkZXJCeTogMCxcclxuICAgICAgICAgICAgRGVzY3JpcHRpb25CZzogJzAwMDAwMDAwMDAnICsgSlNPTi5zdHJpbmdpZnkoZGF0YS5Db25maWcpLFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkVuOiAnMDAwMDAwMDAwMCcsXHJcbiAgICAgICAgICAgIEV4Y2x1ZGVGcm9tQ2FsZW5kYXI6IGZhbHNlLFxyXG4gICAgICAgICAgICBIYXNMaXZlU3RyZWFtOiBmYWxzZSxcclxuICAgICAgICAgICAgQ3JlYXRlZE9uOiAnJyxcclxuICAgICAgICAgICAgTW9kaWZpZWRPbjogJydcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIHBhcnNlKGVudHJ5KSB7XHJcbiAgICAgICAgaWYgKGVudHJ5KSB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICBJZDogZW50cnkuSWQsXHJcbiAgICAgICAgICAgICAgICBFeGFtSWQ6IE51bWJlcigoZW50cnkuTmFtZUJnIHx8ICcnKS5zbGljZSgxMCkpLFxyXG4gICAgICAgICAgICAgICAgQ29uZmlnOiBKU09OLnBhcnNlKChlbnRyeS5EZXNjcmlwdGlvbkJnIHx8ICcnKS5zbGljZSgxMCkpLFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldENvbmZpZ3MoZXhhbUlkcykge1xyXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBnZW5lcmljQXBpLmdldEVudHJpZXMoc3RvcmVJZFtpbnRlcm9wQXBwSWQoKV0sIGBOYW1lQmd+ZXF+JyR7ZXhhbUlkcy5tYXAoaWQgPT4gJzAwMDAwMDAwMDAnICsgaWQpLmpvaW4oJ1xcJ35vcn5OYW1lQmd+ZXF+XFwnJyl9J2ApO1xyXG4gICAgICAgIHJldHVybiBkYXRhLm1hcChwYXJzZSk7O1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldENvbmZpZ0J5RXhhbUlkKGV4YW1JZCkge1xyXG4gICAgICAgIGNvbnN0IGNvbmZpZyA9IGF3YWl0IGdlbmVyaWNBcGkuZ2V0RW50cmllcyhzdG9yZUlkW2ludGVyb3BBcHBJZCgpXSwgYE5hbWVCZ35lcX4nMDAwMDAwMDAwMCR7ZXhhbUlkfSdgKTtcclxuICAgICAgICByZXR1cm4gcGFyc2UoY29uZmlnLkRhdGFbMF0pO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHNhdmVDb25maWcoY29uZmlnKSB7XHJcbiAgICAgICAgY29uc3Qgb3BlcmF0aW9uID0gY29uZmlnLklkID8gZ2VuZXJpY0FwaS51cGRhdGVFbnRyeSA6IGdlbmVyaWNBcGkuY3JlYXRlRW50cnk7XHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgb3BlcmF0aW9uKHNlcmlhbGl6ZShjb25maWcpKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBhcnNlKHJlc3VsdC5EYXRhWzBdKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBkZWxldGVDb25maWcoY29uZmlnKSB7XHJcbiAgICAgICAgcmV0dXJuIGdlbmVyaWNBcGkuZGVzdHJveUVudHJ5KHNlcmlhbGl6ZShjb25maWcpKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldENvbmZpZ3MsXHJcbiAgICAgICAgZ2V0Q29uZmlnQnlFeGFtSWQsXHJcbiAgICAgICAgc2F2ZUNvbmZpZyxcclxuICAgICAgICBkZWxldGVDb25maWdcclxuICAgIH07XHJcbn0iLCJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KSB7XHJcblxyXG4gICAgLyogRW50cnkgbW9kZWw6XHJcblxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgSWQ6IGRhdGEuSWQsXHJcbiAgICAgICAgICAgIFRyYWluaW5nSWQ6IHN0b3JlSWRbaW50ZXJvcEFwcElkKCldLFxyXG4gICAgICAgICAgICBOYW1lQmc6ICcnLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU3RyaW5nICgzLTIwMClcclxuICAgICAgICAgICAgTmFtZUVuOiAnJywgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFN0cmluZyAoMy0yMDApXHJcbiAgICAgICAgICAgIE51bWJlck9mU3R1ZHlIb3VyczogMCwgICAgICAgICAgICAgICAgICBJbnRlZ2VyXHJcbiAgICAgICAgICAgIElzRXhjbHVkZWRGcm9tQ2VydGlmaWNhdGU6IGZhbHNlLCAgICAgICBCb29sZWFuXHJcbiAgICAgICAgICAgIEhhc0hvbWV3b3JrOiBmYWxzZSwgICAgICAgICAgICAgICAgICAgICBCb29sZWFuXHJcbiAgICAgICAgICAgIFJlc291cmNlTWFpbHNTdGF0ZTogMCxcclxuICAgICAgICAgICAgSG9tZXdvcmtNYWlsc1N0YXRlOiAwLFxyXG4gICAgICAgICAgICBKdWRnZUNvbnRlc3RJZDogJycsICAgICAgICAgICAgICAgICAgICAgSW50ZWdlciAoY2Fubm90IGJlIGVtcHR5KVxyXG4gICAgICAgICAgICBPcmRlckJ5OiAwLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSW50ZWdlclxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkJnOiAnJywgICAgICAgICAgICAgICAgICAgICAgU3RyaW5nICgxMC02MDAwKVxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkVuOiAnJywgICAgICAgICAgICAgICAgICAgICAgU3RyaW5nICgxMC02MDAwKVxyXG4gICAgICAgICAgICBFeGNsdWRlRnJvbUNhbGVuZGFyOiBmYWxzZSwgICAgICAgICAgICAgQm9vbGVhblxyXG4gICAgICAgICAgICBIYXNMaXZlU3RyZWFtOiBmYWxzZSwgICAgICAgICAgICAgICAgICAgQm9vbGVhblxyXG4gICAgICAgICAgICBDcmVhdGVkT246ICcnLFxyXG4gICAgICAgICAgICBNb2RpZmllZE9uOiAnJ1xyXG4gICAgICAgIH07XHJcbiAgICAqL1xyXG5cclxuICAgIGNvbnN0IHNldHRpbmdzU3RvcmVJZCA9IHtcclxuICAgICAgICAnc29mdHVuaS5iZyc6IDUyOSxcclxuICAgICAgICAnZGlnaXRhbC5zb2Z0dW5pLmJnJzogMTA2NCxcclxuICAgICAgICAnY3JlYXRpdmUuc29mdHVuaS5iZyc6IDEwMSxcclxuICAgICAgICAnYWkuc29mdHVuaS5iZyc6IDUsXHJcbiAgICAgICAgJ2ZpbmFuY2VhY2FkZW15LmJnJzogMjRcclxuICAgIH07XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0U3RvcmVTZXR0aW5ncyhzdG9yZUlkKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9mYXN0dHJhY2tpbnN0YW5jZXMvcmVhZD9mb3JlaWduS2V5SWQ9JHtzZXR0aW5nc1N0b3JlSWRbaW50ZXJvcEFwcElkKCldfWApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBmaWx0ZXI6IGBJZH5lcX4ke3N0b3JlSWR9YFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjb25zdCBzdG9yZSA9IChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGFbMF07XHJcbiAgICAgICAgY29uc3QgYXNKc29uID0gKHN0b3JlLkRlc2NyaXB0aW9uQmcgfHwgJycpLnNsaWNlKDEwKSArIChzdG9yZS5EZXNjcmlwdGlvbkVuIHx8ICcnKS5zbGljZSgxMCk7XHJcblxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICBzZXR0aW5nczogSlNPTi5wYXJzZShhc0pzb24pLFxyXG4gICAgICAgICAgICAgICAgX01vZGlmaWVkT246IHN0b3JlLk1vZGlmaWVkT24gfHwgc3RvcmUuQ3JlYXRlZE9uXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gc2F2ZVN0b3JlU2V0dGluZ3Moc3RvcmVJZCwgc2V0dGluZ3MpIHtcclxuICAgICAgICBjb25zdCBjdXJyZW50VXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9mYXN0dHJhY2tpbnN0YW5jZXMvcmVhZD9mb3JlaWduS2V5SWQ9JHtzZXR0aW5nc1N0b3JlSWRbaW50ZXJvcEFwcElkKCldfWApO1xyXG4gICAgICAgIGNvbnN0IGN1cnJlbnRCb2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgZmlsdGVyOiBgSWR+ZXF+JHtzdG9yZUlkfWBcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgY3VycmVudCA9IChhd2FpdCBwb3N0KGN1cnJlbnRVcmksIGN1cnJlbnRCb2R5KSkuRGF0YVswXTtcclxuICAgICAgICBkZWxldGUgY3VycmVudC5TaGFyZXNMaXZlU3RyZWFtV2l0aFRyYWluaW5ncztcclxuXHJcbiAgICAgICAgaWYgKHNldHRpbmdzLmhhc093blByb3BlcnR5KCdfTW9kaWZpZWRPbicpICYmIHNldHRpbmdzLmhhc093blByb3BlcnR5KCdzZXR0aW5ncycpKSB7XHJcbiAgICAgICAgICAgIHNldHRpbmdzID0gc2V0dGluZ3Muc2V0dGluZ3M7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCBhc0pzb24gPSBKU09OLnN0cmluZ2lmeShzZXR0aW5ncyk7XHJcbiAgICAgICAgY3VycmVudC5EZXNjcmlwdGlvbkJnID0gJzAwMDAwMDAwMDAnICsgYXNKc29uLnNsaWNlKDAsIDEwMDAwKTtcclxuICAgICAgICBjdXJyZW50LkRlc2NyaXB0aW9uRW4gPSAnMDAwMDAwMDAwMCcgKyBhc0pzb24uc2xpY2UoMTAwMDApO1xyXG4gICAgICAgIC8vQ2VydGlmaWNhdGUgdHlwZSBpcyBub3cgcmVxdWlyZWQgKDggPSBOb25lKVxyXG4gICAgICAgIGN1cnJlbnQuQ2VydGlmaWNhdGVUeXBlID0gODtcclxuXHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9mYXN0dHJhY2tpbnN0YW5jZXMvdXBkYXRlP2ZvcmVpZ25LZXlJZD0ke3NldHRpbmdzU3RvcmVJZFtpbnRlcm9wQXBwSWQoKV19YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHtcclxuICAgICAgICAgICAgJ3NvcnQnOiAnJyxcclxuICAgICAgICAgICAgJ2dyb3VwJzogJycsXHJcbiAgICAgICAgICAgICdmaWx0ZXInOiAnJyxcclxuICAgICAgICAgICAgLi4uY3VycmVudCxcclxuICAgICAgICAgICAgQ3JlYXRlZE9uOiAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnLFxyXG4gICAgICAgICAgICBNb2RpZmllZE9uOiAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnXHJcbiAgICAgICAgfTtcclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCkgeyBib2R5W2tdID0gJyc7IH0gfSk7XHJcblxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGFbMF07XHJcbiAgICAgICAgICAgIHJldHVybiBKU09OLnBhcnNlKChyZXN1bHQuRGVzY3JpcHRpb25CZyB8fCAnJykuc2xpY2UoMTApKTtcclxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4gICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRFbnRyaWVzKHN0b3JlSWQsIGZpbHRlcikge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvbGVjdHVyZXMvcmVhZD9mb3JlaWduS2V5SWQ9JHtzdG9yZUlkfWApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMCxcclxuICAgICAgICB9KTtcclxuICAgICAgICBpZiAoZmlsdGVyKSB7XHJcbiAgICAgICAgICAgIGJvZHkuZmlsdGVyID0gZmlsdGVyO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gdXBkYXRlRW50cnkoZW50cnkpIHtcclxuICAgICAgICBsZXQgc3RhcnREYXRlID0gbmV3IERhdGUoKTtcclxuICAgICAgICBsZXQgZW5kRGF0ZSA9IG5ldyBEYXRlKHN0YXJ0RGF0ZSk7XHJcbiAgICAgICAgZW5kRGF0ZS5zZXRVVENEYXRlKGVuZERhdGUuZ2V0VVRDRGF0ZSgpICArIDEpO1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvbGVjdHVyZXMvdXBkYXRlP2ZvcmVpZ25LZXlJZD0ke2VudHJ5LlRyYWluaW5nSWR9YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiBlbnRyeS5JZCxcclxuICAgICAgICAgICAgVHJhaW5pbmdJZDogZW50cnkuVHJhaW5pbmdJZCxcclxuICAgICAgICAgICAgTmFtZUJnOiBlbnRyeS5OYW1lQmcsXHJcbiAgICAgICAgICAgIE5hbWVFbjogZW50cnkuTmFtZUVuLFxyXG4gICAgICAgICAgICBIYXNNYW51YWxOdW1iZXJPZlN0dWR5SG91cnM6IHRydWUsXHJcbiAgICAgICAgICAgIE51bWJlck9mU3R1ZHlIb3VyczogZW50cnkuTnVtYmVyT2ZTdHVkeUhvdXJzLFxyXG4gICAgICAgICAgICBJc0V4Y2x1ZGVkRnJvbUNlcnRpZmljYXRlOiBlbnRyeS5Jc0V4Y2x1ZGVkRnJvbUNlcnRpZmljYXRlLFxyXG4gICAgICAgICAgICBIYXNIb21ld29yazogZW50cnkuSGFzSG9tZXdvcmssXHJcbiAgICAgICAgICAgIFJlc291cmNlTWFpbHNTdGF0ZTogZW50cnkuUmVzb3VyY2VNYWlsc1N0YXRlLFxyXG4gICAgICAgICAgICBIb21ld29ya01haWxzU3RhdGU6IGVudHJ5LkhvbWV3b3JrTWFpbHNTdGF0ZSxcclxuICAgICAgICAgICAgSnVkZ2VDb250ZXN0SWQ6IGVudHJ5Lkp1ZGdlQ29udGVzdElkLFxyXG4gICAgICAgICAgICBPcmRlckJ5OiBlbnRyeS5PcmRlckJ5LFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkJnOiBlbnRyeS5EZXNjcmlwdGlvbkJnLFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkVuOiBlbnRyeS5EZXNjcmlwdGlvbkVuLFxyXG4gICAgICAgICAgICBFeGNsdWRlRnJvbUNhbGVuZGFyOiBlbnRyeS5FeGNsdWRlRnJvbUNhbGVuZGFyLFxyXG4gICAgICAgICAgICBIYXNMaXZlU3RyZWFtOiBlbnRyeS5IYXNMaXZlU3RyZWFtLFxyXG4gICAgICAgICAgICBDcmVhdGVkT246ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcyMDE5LTA3LTMxVDE3OjM5OjAyLjMxNycsXHJcbiAgICAgICAgICAgIERhdGVzSW5mbzogW1xyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIFN0YXJ0OiBzdGFydERhdGUudG9JU09TdHJpbmcoKSxcclxuICAgICAgICAgICAgICAgICAgICBFbmQ6IGVuZERhdGUudG9JU09TdHJpbmcoKSxcclxuICAgICAgICAgICAgICAgICAgICBFeHRyYUluZm9ybWF0aW9uOiAnJ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBdIFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNlcmlhbGl6ZURhdGVzSW5mbyhib2R5KTtcclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCkgeyBib2R5W2tdID0gJyc7IH0gfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gY3JlYXRlRW50cnkoZW50cnkpIHtcclxuICAgICAgICBsZXQgc3RhcnREYXRlID0gbmV3IERhdGUoKTtcclxuICAgICAgICBsZXQgZW5kRGF0ZSA9IG5ldyBEYXRlKHN0YXJ0RGF0ZSk7XHJcbiAgICAgICAgZW5kRGF0ZS5zZXRVVENEYXRlKGVuZERhdGUuZ2V0VVRDRGF0ZSgpICArIDEpO1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvbGVjdHVyZXMvY3JlYXRlP2ZvcmVpZ25LZXlJZD0ke2VudHJ5LlRyYWluaW5nSWR9YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiBlbnRyeS5JZCxcclxuICAgICAgICAgICAgVHJhaW5pbmdJZDogZW50cnkuVHJhaW5pbmdJZCxcclxuICAgICAgICAgICAgTmFtZUJnOiBlbnRyeS5OYW1lQmcsXHJcbiAgICAgICAgICAgIE5hbWVFbjogZW50cnkuTmFtZUVuLFxyXG4gICAgICAgICAgICBIYXNNYW51YWxOdW1iZXJPZlN0dWR5SG91cnM6IHRydWUsXHJcbiAgICAgICAgICAgIE51bWJlck9mU3R1ZHlIb3VyczogZW50cnkuTnVtYmVyT2ZTdHVkeUhvdXJzLFxyXG4gICAgICAgICAgICBJc0V4Y2x1ZGVkRnJvbUNlcnRpZmljYXRlOiBlbnRyeS5Jc0V4Y2x1ZGVkRnJvbUNlcnRpZmljYXRlLFxyXG4gICAgICAgICAgICBIYXNIb21ld29yazogZW50cnkuSGFzSG9tZXdvcmssXHJcbiAgICAgICAgICAgIFJlc291cmNlTWFpbHNTdGF0ZTogZW50cnkuUmVzb3VyY2VNYWlsc1N0YXRlLFxyXG4gICAgICAgICAgICBIb21ld29ya01haWxzU3RhdGU6IGVudHJ5LkhvbWV3b3JrTWFpbHNTdGF0ZSxcclxuICAgICAgICAgICAgSnVkZ2VDb250ZXN0SWQ6IGVudHJ5Lkp1ZGdlQ29udGVzdElkLFxyXG4gICAgICAgICAgICBPcmRlckJ5OiBlbnRyeS5PcmRlckJ5LFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkJnOiBlbnRyeS5EZXNjcmlwdGlvbkJnLFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkVuOiBlbnRyeS5EZXNjcmlwdGlvbkVuLFxyXG4gICAgICAgICAgICBFeGNsdWRlRnJvbUNhbGVuZGFyOiBlbnRyeS5FeGNsdWRlRnJvbUNhbGVuZGFyLFxyXG4gICAgICAgICAgICBIYXNMaXZlU3RyZWFtOiBlbnRyeS5IYXNMaXZlU3RyZWFtLFxyXG4gICAgICAgICAgICBDcmVhdGVkT246ICcnLFxyXG4gICAgICAgICAgICBNb2RpZmllZE9uOiAnJyxcclxuICAgICAgICAgICAgRGF0ZXNJbmZvOiBbXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgU3RhcnQ6IHN0YXJ0RGF0ZS50b0lTT1N0cmluZygpLFxyXG4gICAgICAgICAgICAgICAgICAgIEVuZDogZW5kRGF0ZS50b0lTT1N0cmluZygpLFxyXG4gICAgICAgICAgICAgICAgICAgIEV4dHJhSW5mb3JtYXRpb246ICcnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIF0gXHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNlcmlhbGl6ZURhdGVzSW5mbyhib2R5KTtcclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCkgeyBib2R5W2tdID0gJyc7IH0gfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZGVzdHJveUVudHJ5KGVudHJ5KSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9sZWN0dXJlcy9kZXN0cm95P2ZvcmVpZ25LZXlJZD0ke2VudHJ5LlRyYWluaW5nSWR9YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJydcclxuICAgICAgICB9KTtcclxuICAgICAgICBPYmplY3QuYXNzaWduKGJvZHksIGVudHJ5KTtcclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCkgeyBib2R5W2tdID0gJyc7IH0gfSk7XHJcbiAgICAgICAgYm9keS5DcmVhdGVkT24gPSAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnO1xyXG4gICAgICAgIGJvZHkuTW9kaWZpZWRPbiA9ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNyc7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gc2VyaWFsaXplRGF0ZXNJbmZvKGJvZHkpIHtcclxuICAgICAgICBjb25zdCBkYXRlc0luZm8gPSBib2R5LkRhdGVzSW5mbztcclxuICAgICAgICBkZWxldGUgYm9keS5EYXRlc0luZm87XHJcbiAgICAgICAgXHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRlc0luZm8ubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgY29uc3QgZGF0ZSA9IGRhdGVzSW5mb1tpXTtcclxuICAgICAgICAgICAgYm9keVtgRGF0ZXNJbmZvWyR7aX1dLlN0YXJ0YF0gPSBkYXRlLlN0YXJ0O1xyXG4gICAgICAgICAgICBib2R5W2BEYXRlc0luZm9bJHtpfV0uRW5kYF0gPSBkYXRlLkVuZDtcclxuICAgICAgICAgICAgYm9keVtgRGF0ZXNJbmZvWyR7aX1dLkV4dHJhSW5mb3JtYXRpb25gXSA9IGRhdGUuRXh0cmFJbmZvcm1hdGlvbjtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBnZXRTdG9yZVNldHRpbmdzLFxyXG4gICAgICAgIHNhdmVTdG9yZVNldHRpbmdzLFxyXG4gICAgICAgIGdldEVudHJpZXMsXHJcbiAgICAgICAgdXBkYXRlRW50cnksXHJcbiAgICAgICAgY3JlYXRlRW50cnksXHJcbiAgICAgICAgZGVzdHJveUVudHJ5XHJcbiAgICB9O1xyXG59IiwiaW1wb3J0IGdlbmVyaWNBcGlGYWN0b3J5IGZyb20gJy4vZ2VuZXJpYyc7XHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSkge1xyXG4gICAgY29uc3QgZ2VuZXJpY0FwaSA9IGdlbmVyaWNBcGlGYWN0b3J5KHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSk7XHJcblxyXG5cclxuICAgIGNvbnN0IHN0b3JlSWQgPSB7XHJcbiAgICAgICAgJ3NvZnR1bmkuYmcnOiA0NDkyLFxyXG4gICAgICAgICdkaWdpdGFsLnNvZnR1bmkuYmcnOiAzODE1LFxyXG4gICAgICAgICdjcmVhdGl2ZS5zb2Z0dW5pLmJnJzogMTYxMixcclxuICAgICAgICAnYWkuc29mdHVuaS5iZyc6IDlcclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBnZXRNb2R1bGVEYXRhU2V0dGluZ3M6ICgpID0+IGdlbmVyaWNBcGkuZ2V0U3RvcmVTZXR0aW5ncyhzdG9yZUlkW2ludGVyb3BBcHBJZCgpXSksXHJcbiAgICAgICAgc2F2ZU1vZHVsZURhdGFTZXR0aW5nczogKHNldHRpbmdzKSA9PiBnZW5lcmljQXBpLnNhdmVTdG9yZVNldHRpbmdzKHN0b3JlSWRbaW50ZXJvcEFwcElkKCldLCBzZXR0aW5ncyksXHJcbiAgICB9O1xyXG59IiwiaW1wb3J0IGdlbmVyaWNBcGlGYWN0b3J5IGZyb20gJy4vZ2VuZXJpYyc7XHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSkge1xyXG4gICAgY29uc3QgZ2VuZXJpY0FwaSA9IGdlbmVyaWNBcGlGYWN0b3J5KHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSk7XHJcblxyXG5cclxuICAgIGNvbnN0IHN0b3JlSWQgPSB7XHJcbiAgICAgICAgJ3NvZnR1bmkuYmcnOiAzODMzLFxyXG4gICAgICAgICdkaWdpdGFsLnNvZnR1bmkuYmcnOiAzNTgyLFxyXG4gICAgICAgICdjcmVhdGl2ZS5zb2Z0dW5pLmJnJzogMTQyOCxcclxuICAgICAgICAnYWkuc29mdHVuaS5iZyc6IDEwXHJcbiAgICB9O1xyXG5cclxuICAgIGZ1bmN0aW9uIHNlcmlhbGl6ZShkYXRhKSB7XHJcbiAgICAgICAgY29uc3QgcGF5bG9hZCA9IHtcclxuICAgICAgICAgICAgUGF5bWVudHNCeURhdGU6IGRhdGEuUGF5bWVudHNCeURhdGUsXHJcbiAgICAgICAgICAgIFJldGVudGlvbkJ5RGF0ZTogZGF0YS5SZXRlbnRpb25CeURhdGUsXHJcbiAgICAgICAgICAgIE9ubGluZVBheW1lbnRzOiBkYXRhLk9ubGluZVBheW1lbnRzIHx8IDAsXHJcbiAgICAgICAgICAgIE9ubGluZVJldGVudGlvbjogZGF0YS5PbmxpbmVSZXRlbnRpb24gfHwgMCxcclxuICAgICAgICAgICAgU2l0ZVBheW1lbnRzOiBkYXRhLlNpdGVQYXltZW50cyB8fCAwLFxyXG4gICAgICAgICAgICBTaXRlUmV0ZW50aW9uOiBkYXRhLlNpdGVSZXRlbnRpb24gfHwgMFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgY29uc3QgYXNKc29uID0gSlNPTi5zdHJpbmdpZnkocGF5bG9hZCk7XHJcblxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiBkYXRhLklkIHx8IDAsXHJcbiAgICAgICAgICAgIFRyYWluaW5nSWQ6IHN0b3JlSWRbaW50ZXJvcEFwcElkKCldLFxyXG4gICAgICAgICAgICBOYW1lQmc6ICcwMDAwMDAwMDAwJyArIChkYXRhLk5hbWVCZyArICc6OicgKyBkYXRhLk5hbWVFbiArICc6OicgKyBkYXRhLkxldmVsSWQpLFxyXG4gICAgICAgICAgICBOYW1lRW46ICcwMDAwMDAwMDAwJyArIEpTT04uc3RyaW5naWZ5KGRhdGEuRGF0ZUNvbmZpZyksXHJcbiAgICAgICAgICAgIEhhc01hbnVhbE51bWJlck9mU3R1ZHlIb3VyczogdHJ1ZSxcclxuICAgICAgICAgICAgTnVtYmVyT2ZTdHVkeUhvdXJzOiBkYXRhLlN0YXJ0SW5kZXggfHwgMCxcclxuICAgICAgICAgICAgSXNFeGNsdWRlZEZyb21DZXJ0aWZpY2F0ZTogZmFsc2UsXHJcbiAgICAgICAgICAgIEp1ZGdlQ29udGVzdElkOiBkYXRhLkxldmVsSWQsXHJcbiAgICAgICAgICAgIEhhc0hvbWV3b3JrOiBmYWxzZSxcclxuICAgICAgICAgICAgUmVzb3VyY2VNYWlsc1N0YXRlOiAwLFxyXG4gICAgICAgICAgICBIb21ld29ya01haWxzU3RhdGU6IDAsXHJcbiAgICAgICAgICAgIE9yZGVyQnk6IGRhdGEuSW5zdGFuY2VJZCxcclxuICAgICAgICAgICAgRGVzY3JpcHRpb25CZzogJzAwMDAwMDAwMDAnICsgYXNKc29uLnNsaWNlKDAsIDU5ODApLFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkVuOiAnMDAwMDAwMDAwMCcgKyBhc0pzb24uc2xpY2UoNTk4MCksXHJcbiAgICAgICAgICAgIEV4Y2x1ZGVGcm9tQ2FsZW5kYXI6ICFkYXRhLklzTWFpblByb2dyYW0sXHJcbiAgICAgICAgICAgIEhhc0xpdmVTdHJlYW06IGZhbHNlLFxyXG4gICAgICAgICAgICBDcmVhdGVkT246ICcnLFxyXG4gICAgICAgICAgICBNb2RpZmllZE9uOiAnJ1xyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gcGFyc2UoZW50cnkpIHtcclxuICAgICAgICBpZiAoZW50cnkpIHtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHBheWxvYWRKc29uID0gKGVudHJ5LkRlc2NyaXB0aW9uQmcgfHwgJycpLnNsaWNlKDEwKSArIChlbnRyeS5EZXNjcmlwdGlvbkVuIHx8ICcnKS5zbGljZSgxMCk7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBwYXlsb2FkID0gSlNPTi5wYXJzZShwYXlsb2FkSnNvbik7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBuYW1lc0FuZExldmVsID0gZW50cnkuTmFtZUJnLnNsaWNlKDEwKS5zcGxpdCgnOjonKTtcclxuXHJcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgICAgIElkOiBlbnRyeS5JZCxcclxuICAgICAgICAgICAgICAgICAgICBJbnN0YW5jZUlkOiBOdW1iZXIoZW50cnkuT3JkZXJCeSkgfHwgbnVsbCxcclxuICAgICAgICAgICAgICAgICAgICBMZXZlbElkOiBOdW1iZXIobmFtZXNBbmRMZXZlbFsyXSkgfHwgZW50cnkuSnVkZ2VDb250ZXN0SWQsXHJcbiAgICAgICAgICAgICAgICAgICAgTmFtZUJnOiBuYW1lc0FuZExldmVsWzBdLFxyXG4gICAgICAgICAgICAgICAgICAgIE5hbWVFbjogbmFtZXNBbmRMZXZlbFsxXSxcclxuICAgICAgICAgICAgICAgICAgICBEYXRlQ29uZmlnOiBKU09OLnBhcnNlKChlbnRyeS5OYW1lRW4gfHwgJycpLnNsaWNlKDEwKSksXHJcbiAgICAgICAgICAgICAgICAgICAgU3RhcnRJbmRleDogZW50cnkuTnVtYmVyT2ZTdHVkeUhvdXJzLFxyXG4gICAgICAgICAgICAgICAgICAgIFBheW1lbnRzQnlEYXRlOiBwYXlsb2FkLlBheW1lbnRzQnlEYXRlLFxyXG4gICAgICAgICAgICAgICAgICAgIFJldGVudGlvbkJ5RGF0ZTogcGF5bG9hZC5SZXRlbnRpb25CeURhdGUsXHJcbiAgICAgICAgICAgICAgICAgICAgT25saW5lUGF5bWVudHM6IHBheWxvYWQuT25saW5lUGF5bWVudHMgfHwgMCxcclxuICAgICAgICAgICAgICAgICAgICBPbmxpbmVSZXRlbnRpb246IHBheWxvYWQuT25saW5lUmV0ZW50aW9uIHx8IDAsXHJcbiAgICAgICAgICAgICAgICAgICAgU2l0ZVBheW1lbnRzOiBwYXlsb2FkLlNpdGVQYXltZW50cyB8fCAwLFxyXG4gICAgICAgICAgICAgICAgICAgIFNpdGVSZXRlbnRpb246IHBheWxvYWQuU2l0ZVJldGVudGlvbiB8fCAwLFxyXG4gICAgICAgICAgICAgICAgICAgIElzTWFpblByb2dyYW06ICFlbnRyeS5FeGNsdWRlRnJvbUNhbGVuZGFyLFxyXG4gICAgICAgICAgICAgICAgICAgIE1vZGlmaWVkT246IGVudHJ5Lk1vZGlmaWVkT24gfHwgZW50cnkuQ3JlYXRlZE9uXHJcbiAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Rlc3Ryb3lpbmcgaW5jb21wYXRpYmxlIGVudHJ5Jyk7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlbnRyeSk7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbiAgICAgICAgICAgICAgICBnZW5lcmljQXBpLmRlc3Ryb3lFbnRyeShlbnRyeSk7XHJcblxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFN0YXRzKGluc3RhbmNlSWRzKSB7XHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGdlbmVyaWNBcGkuZ2V0RW50cmllcyhzdG9yZUlkW2ludGVyb3BBcHBJZCgpXSwgYE9yZGVyQnl+ZXF+JHtpbnN0YW5jZUlkcy5qb2luKCd+b3J+T3JkZXJCeX5lcX4nKX1gKTtcclxuICAgICAgICByZXR1cm4gZGF0YS5tYXAocGFyc2UpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFN0YXRzQnlJbnN0YW5jZUlkKGluc3RhbmNlSWQpIHtcclxuICAgICAgICBjb25zdCBjb25maWcgPSBhd2FpdCBnZW5lcmljQXBpLmdldEVudHJpZXMoc3RvcmVJZFtpbnRlcm9wQXBwSWQoKV0sIGBPcmRlckJ5fmVxfiR7aW5zdGFuY2VJZH1gKTtcclxuICAgICAgICByZXR1cm4gcGFyc2UoY29uZmlnWzBdKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRTdGF0c0J5U3RhcnRJbmRleChzdGFydCwgZW5kKSB7XHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGdlbmVyaWNBcGkuZ2V0RW50cmllcyhzdG9yZUlkW2ludGVyb3BBcHBJZCgpXSwgYE51bWJlck9mU3R1ZHlIb3Vyc35ndGV+JHtzdGFydH1+YW5kfk51bWJlck9mU3R1ZHlIb3Vyc35sdGV+JHtlbmR9YCk7XHJcbiAgICAgICAgcmV0dXJuIGRhdGEubWFwKHBhcnNlKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBzYXZlU3RhdHMoc3RhdHMpIHtcclxuICAgICAgICBjb25zdCBvcGVyYXRpb24gPSBzdGF0cy5JZCA/IGdlbmVyaWNBcGkudXBkYXRlRW50cnkgOiBnZW5lcmljQXBpLmNyZWF0ZUVudHJ5O1xyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IG9wZXJhdGlvbihzZXJpYWxpemUoc3RhdHMpKTtcclxuXHJcbiAgICAgICAgaWYocmVzdWx0LkVycm9ycykge1xyXG4gICAgICAgICAgICBjb25zdCBlcnJvciA9IG5ldyBFcnJvcignUmVxdWVzdCByZXR1cm5lZCBFcnJvcnMnKTtcclxuICAgICAgICAgICAgZXJyb3IuX2Vycm9yT2JqZWN0ID0gcmVzdWx0LkVycm9ycztcclxuICAgICAgICAgICAgdGhyb3cgZXJyb3I7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhKU09OLnN0cmluZ2lmeShyZXN1bHQpKTtcclxuICAgICAgICByZXR1cm4gcGFyc2UocmVzdWx0LkRhdGFbMF0pO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGRlbGV0ZVN0YXRzKHN0YXRzKSB7XHJcbiAgICAgICAgcmV0dXJuIGdlbmVyaWNBcGkuZGVzdHJveUVudHJ5KHNlcmlhbGl6ZShzdGF0cykpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgZ2V0U3RhdHNTZXR0aW5nczogKCkgPT4gZ2VuZXJpY0FwaS5nZXRTdG9yZVNldHRpbmdzKHN0b3JlSWRbaW50ZXJvcEFwcElkKCldKSxcclxuICAgICAgICBzYXZlU3RhdHNTZXR0aW5nczogKHNldHRpbmdzKSA9PiBnZW5lcmljQXBpLnNhdmVTdG9yZVNldHRpbmdzKHN0b3JlSWRbaW50ZXJvcEFwcElkKCldLCBzZXR0aW5ncyksXHJcbiAgICAgICAgZ2V0U3RhdHMsXHJcbiAgICAgICAgZ2V0U3RhdHNCeUluc3RhbmNlSWQsXHJcbiAgICAgICAgZ2V0U3RhdHNCeVN0YXJ0SW5kZXgsXHJcbiAgICAgICAgc2F2ZVN0YXRzLFxyXG4gICAgICAgIGRlbGV0ZVN0YXRzXHJcbiAgICB9O1xyXG59IiwiaW1wb3J0IGdlbmVyaWNBcGlGYWN0b3J5IGZyb20gJy4vZ2VuZXJpYyc7XHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSkge1xyXG4gICAgY29uc3QgZ2VuZXJpY0FwaSA9IGdlbmVyaWNBcGlGYWN0b3J5KHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSk7XHJcblxyXG5cclxuICAgIGNvbnN0IHRlbXBsYXRlU3RvcmVJZCA9IHtcclxuICAgICAgICAnc29mdHVuaS5iZyc6IDM1MTksXHJcbiAgICAgICAgJ2RpZ2l0YWwuc29mdHVuaS5iZyc6IDM0NDAsXHJcbiAgICAgICAgJ2NyZWF0aXZlLnNvZnR1bmkuYmcnOiAxMzAwLFxyXG4gICAgICAgICdhaS5zb2Z0dW5pLmJnJzogNyxcclxuICAgICAgICAnZmluYW5jZWFjYWRlbXkuYmcnOiA3NFxyXG4gICAgfTtcclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRUZW1wbGF0ZVN0b3JlU2V0dGluZ3MoKSB7XHJcbiAgICAgICAgcmV0dXJuIGdlbmVyaWNBcGkuZ2V0U3RvcmVTZXR0aW5ncyh0ZW1wbGF0ZVN0b3JlSWRbaW50ZXJvcEFwcElkKCldKTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiB0ZW1wbGF0ZVRvRW50cnkoZGF0YSkge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiBkYXRhLklkIHx8IDAsXHJcbiAgICAgICAgICAgIFRyYWluaW5nSWQ6IHRlbXBsYXRlU3RvcmVJZFtpbnRlcm9wQXBwSWQoKV0sXHJcbiAgICAgICAgICAgIE5hbWVCZzogJzAwMDAwMDAwMDAnICsgZGF0YS5OYW1lLFxyXG4gICAgICAgICAgICBOYW1lRW46ICcwMDAwMDAwMDAwJyArIEpTT04uc3RyaW5naWZ5KGRhdGEuQ2F0ZWdvcnkpLFxyXG4gICAgICAgICAgICBIYXNNYW51YWxOdW1iZXJPZlN0dWR5SG91cnM6IHRydWUsXHJcbiAgICAgICAgICAgIE51bWJlck9mU3R1ZHlIb3VyczogMCxcclxuICAgICAgICAgICAgSXNFeGNsdWRlZEZyb21DZXJ0aWZpY2F0ZTogZGF0YS5BY3RpdmUsXHJcbiAgICAgICAgICAgIEhhc0hvbWV3b3JrOiBmYWxzZSxcclxuICAgICAgICAgICAgUmVzb3VyY2VNYWlsc1N0YXRlOiAwLFxyXG4gICAgICAgICAgICBIb21ld29ya01haWxzU3RhdGU6IDAsXHJcbiAgICAgICAgICAgIEp1ZGdlQ29udGVzdElkOiAnJyxcclxuICAgICAgICAgICAgT3JkZXJCeTogMCxcclxuICAgICAgICAgICAgRGVzY3JpcHRpb25CZzogJzAwMDAwMDAwMDAnICsgZGF0YS5Db250ZW50LFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkVuOiAoJzAwMDAwMDAwMDAnICsgKGRhdGEuSW5zdGFuY2VJZCB8fCAnJykpLnNsaWNlKC0xMCksXHJcbiAgICAgICAgICAgIEV4Y2x1ZGVGcm9tQ2FsZW5kYXI6IGRhdGEuQ29tcG91bmQsXHJcbiAgICAgICAgICAgIEhhc0xpdmVTdHJlYW06IGZhbHNlLFxyXG4gICAgICAgICAgICBDcmVhdGVkT246ICcnLFxyXG4gICAgICAgICAgICBNb2RpZmllZE9uOiAnJ1xyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gZW50cnlUb1RlbXBsYXRlKGVudHJ5KSB7XHJcbiAgICAgICAgaWYgKGVudHJ5KSB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICBJZDogZW50cnkuSWQsXHJcbiAgICAgICAgICAgICAgICBOYW1lOiBlbnRyeS5OYW1lQmcuc2xpY2UoMTApLFxyXG4gICAgICAgICAgICAgICAgQ2F0ZWdvcnk6IEpTT04ucGFyc2UoZW50cnkuTmFtZUVuLnNsaWNlKDEwKSkgfHwgW10sXHJcbiAgICAgICAgICAgICAgICBBY3RpdmU6IGVudHJ5LklzRXhjbHVkZWRGcm9tQ2VydGlmaWNhdGUsXHJcbiAgICAgICAgICAgICAgICBDb21wb3VuZDogZW50cnkuRXhjbHVkZUZyb21DYWxlbmRhcixcclxuICAgICAgICAgICAgICAgIENvbnRlbnQ6IChlbnRyeS5EZXNjcmlwdGlvbkJnIHx8ICcnKS5zbGljZSgxMCksXHJcbiAgICAgICAgICAgICAgICBJbnN0YW5jZUlkOiBOdW1iZXIoZW50cnkuRGVzY3JpcHRpb25FbikgfHwgbnVsbFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFRlbXBsYXRlcygpIHtcclxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgZ2VuZXJpY0FwaS5nZXRFbnRyaWVzKHRlbXBsYXRlU3RvcmVJZFtpbnRlcm9wQXBwSWQoKV0pO1xyXG4gICAgICAgIHJldHVybiBkYXRhXHJcbiAgICAgICAgICAgIC5tYXAoZW50cnlUb1RlbXBsYXRlKVxyXG4gICAgICAgICAgICAuc29ydCgoYSwgYikgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuICgoYi5BY3RpdmUgPyAxIDogMCkgLSAoYS5BY3RpdmUgPyAxIDogMCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfHwgKChiLkNvbXBvdW5kID8gMSA6IDApIC0gKGEuQ29tcG91bmQgPyAxIDogMCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfHwgYS5OYW1lLmxvY2FsZUNvbXBhcmUoYi5OYW1lKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0VGVtcGxhdGVCeU5hbWUobmFtZSkge1xyXG4gICAgICAgIGNvbnN0IHRlbXBsYXRlID0gYXdhaXQgZ2VuZXJpY0FwaS5nZXRFbnRyaWVzKHRlbXBsYXRlU3RvcmVJZFtpbnRlcm9wQXBwSWQoKV0sIGBOYW1lQmd+ZXF+JyR7bmFtZX0nYCk7XHJcbiAgICAgICAgcmV0dXJuIGVudHJ5VG9UZW1wbGF0ZSh0ZW1wbGF0ZVswXSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0VGVtcGxhdGVCeUluc3RhbmNlSWQoaW5zdGFuY2VJZCkge1xyXG4gICAgICAgIGNvbnN0IHRlbXBsYXRlID0gYXdhaXQgZ2VuZXJpY0FwaS5nZXRFbnRyaWVzKHRlbXBsYXRlU3RvcmVJZFtpbnRlcm9wQXBwSWQoKV0sIGBEZXNjcmlwdGlvbkVufmVxficke2luc3RhbmNlSWR9J2ApO1xyXG4gICAgICAgIHJldHVybiBlbnRyeVRvVGVtcGxhdGUodGVtcGxhdGVbMF0pO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHNhdmVUZW1wbGF0ZSh0ZW1wbGF0ZSkge1xyXG4gICAgICAgIGNvbnN0IG9wZXJhdGlvbiA9IHRlbXBsYXRlLklkID8gZ2VuZXJpY0FwaS51cGRhdGVFbnRyeSA6IGdlbmVyaWNBcGkuY3JlYXRlRW50cnk7XHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgb3BlcmF0aW9uKHRlbXBsYXRlVG9FbnRyeSh0ZW1wbGF0ZSkpO1xyXG5cclxuICAgICAgICByZXR1cm4gZW50cnlUb1RlbXBsYXRlKHJlc3VsdC5EYXRhWzBdKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBkZWxldGVUZW1wbGF0ZSh0ZW1wbGF0ZSkge1xyXG4gICAgICAgIHJldHVybiBnZW5lcmljQXBpLmRlc3Ryb3lFbnRyeSh0ZW1wbGF0ZVRvRW50cnkodGVtcGxhdGUpKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldFRlbXBsYXRlU3RvcmVTZXR0aW5ncyxcclxuICAgICAgICBnZXRUZW1wbGF0ZXMsXHJcbiAgICAgICAgZ2V0VGVtcGxhdGVCeU5hbWUsXHJcbiAgICAgICAgZ2V0VGVtcGxhdGVCeUluc3RhbmNlSWQsXHJcbiAgICAgICAgc2F2ZVRlbXBsYXRlLFxyXG4gICAgICAgIGRlbGV0ZVRlbXBsYXRlXHJcbiAgICB9O1xyXG59IiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSkge1xyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEluc3RhbmNlQ29uZmlnKGluc3RhbmNlSWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBgaHR0cHM6Ly9zZXMtd2ViZXh0LmdpdGh1Yi5pby9zdHJlYW0vJHtpbnN0YW5jZUlkfS5qc29uYDtcclxuXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZ2V0KHVyaSk7XHJcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldEluc3RhbmNlQ29uZmlnXHJcbiAgICB9O1xyXG59IiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0IH0pIHtcclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFN1cnZleXMocGFnZSwgcXVlcnksIGZpbHRlciwgcGFnZVNpemUgPSAzMCkge1xyXG4gICAgICAgIGlmIChwYWdlU2l6ZSA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgcGFnZVNpemUgPSAzMDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IHVybCA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl9zdXJ2ZXlzL3N1cnZleXMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnQWN0aXZlVG8tZGVzYycsXHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiBwYWdlU2l6ZSxcclxuICAgICAgICAgICAgcGFnZVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGlmIChxdWVyeSkge1xyXG4gICAgICAgICAgICBib2R5LmZpbHRlciA9IGBOYW1lfmNvbnRhaW5zficke3F1ZXJ5fSdgO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGZpbHRlcikge1xyXG4gICAgICAgICAgICBib2R5LmZpbHRlciArPSBgfmFuZH4oJHtmaWx0ZXJ9KWBcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVybCwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0U3VydmV5c0J5TmFtZUFuZFN0YXJ0QW5kRW5kRGF0ZShwYWdlLCBuYW1lLCBzdGFydERhdGUsIGVuZERhdGUsIHBhZ2VTaXplID0gMzApIHtcclxuICAgICAgICBpZiAocGFnZVNpemUgPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplID0gMzA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCB1cmwgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fc3VydmV5cy9zdXJ2ZXlzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJ0FjdGl2ZVRvLWRlc2MnLFxyXG4gICAgICAgICAgICBwYWdlU2l6ZTogcGFnZVNpemUsXHJcbiAgICAgICAgICAgIHBhZ2VcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgYm9keS5maWx0ZXIgPSBgTmFtZX5jb250YWluc34nJHtuYW1lfSd+YW5kfkFjdGl2ZUZyb21+Z3RlfmRhdGV0aW1lJyR7c3RhcnREYXRlfSd+YW5kfkFjdGl2ZUZyb21+bHR+ZGF0ZXRpbWUnJHtlbmREYXRlfSdgO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmwsIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFN1cnZleUJ5SWQoc3VydmV5SWQpIHtcclxuICAgICAgICBjb25zdCB1cmwgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fc3VydmV5cy9zdXJ2ZXlzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgZmlsdGVyOiAnSWR+ZXF+JyArIHN1cnZleUlkLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmwsIGJvZHkpKS5EYXRhWzBdO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFN1cnZleUFuc3dlcnMoc3VydmV5SWQpIHtcclxuICAgICAgICBjb25zdCB1cmwgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fc3VydmV5cy91c2VycG9sbGFuc3dlcnMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJ1N1cnZleUlkfmVxficgKyBzdXJ2ZXlJZFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmwsIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFN1cnZleVRlbXBsYXRlcygpIHtcclxuICAgICAgICBjb25zdCB1cmwgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fc3VydmV5cy9zdXJ2ZXlzZWN0aW9udGVtcGxhdGVzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAwLFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmwsIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFN1cnZleVF1ZXN0aW9uc0J5VGVtcGxhdGVJZCh0ZW1wbGF0ZUlkKSB7XHJcbiAgICAgICAgY29uc3QgdXJsID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3N1cnZleXMvcG9sbHF1ZXN0aW9ucy9yZWFkcG9sbHF1ZXN0aW9ucz9zdXJ2ZXlTZWN0aW9uVGVtcGxhdGVJZD0ke3RlbXBsYXRlSWR9YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwMCxcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJsLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRTdXJ2ZXlTZWN0aW9uc0J5VGVtcGxhdGVJZCh0ZW1wbGF0ZUlkKSB7XHJcbiAgICAgICAgY29uc3QgdXJsID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3N1cnZleXMvc3VydmV5c2VjdGlvbnMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogYFN1cnZleVNlY3Rpb25UZW1wbGF0ZUlkfmVxfiR7dGVtcGxhdGVJZH1gXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVybCwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0U3VydmV5U2VjdGlvbnNCeUlkKHNlY3Rpb25JZCkge1xyXG4gICAgICAgIGNvbnN0IHVybCA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl9zdXJ2ZXlzL3N1cnZleXNlY3Rpb25zL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAwLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGBJZH5lcX4ke0FycmF5LmlzQXJyYXkoc2VjdGlvbklkKSA/IHNlY3Rpb25JZC5qb2luKCd+b3J+SWR+ZXF+JykgOiBzZWN0aW9uSWR9YFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmwsIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGZpbmRTZWN0aW9uc0J5VHJhaW5pbmcobmFtZUJnKSB7XHJcbiAgICAgICAgY29uc3QgdXJsID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3N1cnZleXMvc3VydmV5c2VjdGlvbnMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGBUcmFpbmluZ35lcX4nJHtuYW1lQmd9J35hbmR+TmFtZX5kb2Vzbm90Y29udGFpbn4n0L7QsdGB0LvRg9C20LLQsNC90LUnfmFuZH5OYW1lfmRvZXNub3Rjb250YWlufifQuNC90YTQvtGA0LzQsNGG0LjRjyd+YW5kfk5hbWV+ZG9lc25vdGNvbnRhaW5+J9GB0LLRitGA0LfQsNC90Lgg0YEg0LrRg9GA0YHQsCdgXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVybCwgYm9keSkpLkRhdGEubWFwKHMgPT4gcy5OYW1lKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBmaW5kQW5zd2Vyc0J5U2VjdGlvbihzZWN0aW9uTmFtZXMpIHtcclxuICAgICAgICBjb25zdCB1cmwgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fc3VydmV5cy91c2VycG9sbGFuc3dlcnMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJ1NlY3Rpb25+ZXF+XFwnJyArIHNlY3Rpb25OYW1lcy5qb2luKCdcXCd+b3J+U2VjdGlvbn5lcX5cXCcnKSArICdcXCcnXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmwsIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGZpbmRTdXJ2ZXlCeVRyYWluaW5nKG5hbWVCZykge1xyXG4gICAgICAgIGNvbnN0IHNlY3Rpb25zID0gYXdhaXQgZmluZFNlY3Rpb25zQnlUcmFpbmluZyhuYW1lQmcpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKHNlY3Rpb25zKTtcclxuICAgICAgICBjb25zdCBhbnN3ZXJzID0gYXdhaXQgZmluZEFuc3dlcnNCeVNlY3Rpb24oc2VjdGlvbnMpO1xyXG4gICAgICAgIGNvbnN0IHN1cnZleXMgPSBbLi4uYW5zd2Vycy5yZWR1Y2UoKHAsIGMpID0+IHsgcC5hZGQoYy5TdXJ2ZXlJZCk7IHJldHVybiBwOyB9LCBuZXcgU2V0KCkpXTtcclxuXHJcbiAgICAgICAgcmV0dXJuIFByb21pc2UuYWxsKHN1cnZleXMubWFwKGdldFN1cnZleUJ5SWQpKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldFN1cnZleXMsXHJcbiAgICAgICAgZ2V0U3VydmV5c0J5TmFtZUFuZFN0YXJ0QW5kRW5kRGF0ZSxcclxuICAgICAgICBnZXRTdXJ2ZXlCeUlkLFxyXG4gICAgICAgIGdldFN1cnZleUFuc3dlcnMsXHJcbiAgICAgICAgZ2V0U3VydmV5VGVtcGxhdGVzLFxyXG4gICAgICAgIGdldFN1cnZleVF1ZXN0aW9uc0J5VGVtcGxhdGVJZCxcclxuICAgICAgICBnZXRTdXJ2ZXlTZWN0aW9uc0J5VGVtcGxhdGVJZCxcclxuICAgICAgICBnZXRTdXJ2ZXlTZWN0aW9uc0J5SWQsXHJcbiAgICAgICAgZmluZFN1cnZleUJ5VHJhaW5pbmdcclxuICAgIH07XHJcbn0iLCJpbXBvcnQgeyBwYXJzZUNyb3NzQnJvd3NlckZpbGUgfSBmcm9tICcuLi91dGlsJztcclxuXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KSB7XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0SG9tZXdvcmtSZXN1bHRzKGluc3RhbmNlSWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fY3JtL2ludGVybmFsY291cnNlY3JtcHJvZmlsZXMvcmVhZGludGVybmFsY291cnNlY3JtcHJvZmlsZXMvJHtpbnN0YW5jZUlkfWApO1xyXG5cclxuICAgICAgICByZXR1cm4gYXdhaXQgZmV0Y2hOZXh0KCk7XHJcblxyXG4gICAgICAgIGFzeW5jIGZ1bmN0aW9uIGZldGNoTmV4dChwYWdlID0gMSkge1xyXG4gICAgICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgICAgIHNvcnQ6ICdDcmVhdGVkT24tZGVzYycsXHJcbiAgICAgICAgICAgICAgICBwYWdlU2l6ZTogMTAwMCxcclxuICAgICAgICAgICAgICAgIHBhZ2VcclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHBvc3QodXJpLCBib2R5KTtcclxuXHJcbiAgICAgICAgICAgIGxldCByZXN1bHQgPSByZXNwb25zZS5EYXRhO1xyXG5cclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLlRvdGFsID4gcGFnZSAqIDEwMDApIHtcclxuICAgICAgICAgICAgICAgIHJlc3VsdCA9IHJlc3VsdC5jb25jYXQoYXdhaXQgZmV0Y2hOZXh0KHBhZ2UgKyAxKSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFByb3RvY29sKGluc3RhbmNlSWQpIHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdXNlcnNpbmNvdXJzZXMvZXhwb3J0dHJhaW5pbmdwcm90b2NvbC8ke2luc3RhbmNlSWR9YCksIHtcclxuICAgICAgICAgICAgJ2NyZWRlbnRpYWxzJzogJ2luY2x1ZGUnLFxyXG4gICAgICAgICAgICAnaGVhZGVycyc6IHtcclxuICAgICAgICAgICAgICAgICdIb3N0JzogJ3NvZnR1bmkuYmcnLFxyXG4gICAgICAgICAgICAgICAgJ1VzZXItQWdlbnQnOiAnTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NDsgcnY6OTcuMCkgR2Vja28vMjAxMDAxMDEgRmlyZWZveC85Ny4wJyxcclxuICAgICAgICAgICAgICAgICdBY2NlcHQnOiAndGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2UvYXZpZixpbWFnZS93ZWJwLCovKjtxPTAuOCcsXHJcbiAgICAgICAgICAgICAgICAnQWNjZXB0LUxhbmd1YWdlJzogJ2VuLVVTLGVuO3E9MC41JyxcclxuICAgICAgICAgICAgICAgICdBY2NlcHQtRW5jb2RpbmcnOiAnZ3ppcCwgZGVmbGF0ZSwgYnInLFxyXG4gICAgICAgICAgICAgICAgJ0Nvbm5lY3Rpb24nOiAna2VlcC1hbGl2ZScsXHJcbiAgICAgICAgICAgICAgICAnUmVmZXJlcic6IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdXNlcnNpbnRyYWluaW5nc21hbmFnZW1lbnQnKSxcclxuICAgICAgICAgICAgICAgICdVcGdyYWRlLUluc2VjdXJlLVJlcXVlc3RzJzogMSxcclxuICAgICAgICAgICAgICAgICdTZWMtRmV0Y2gtRGVzdCc6ICdkb2N1bWVudCcsXHJcbiAgICAgICAgICAgICAgICAnU2VjLUZldGNoLU1vZGUnOiAnbmF2aWdhdGUnLFxyXG4gICAgICAgICAgICAgICAgJ1NlYy1GZXRjaC1TaXRlJzogJ3NhbWUtb3JpZ2luJyxcclxuICAgICAgICAgICAgICAgICdTZWMtRmV0Y2gtVXNlcic6ICc/MScsXHJcbiAgICAgICAgICAgICAgICAnUHJhZ21hJzogJ25vLWNhY2hlJyxcclxuICAgICAgICAgICAgICAgICdDYWNoZS1Db250cm9sJzogJ25vLWNhY2hlJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAnbWV0aG9kJzogJ0dFVCcsXHJcbiAgICAgICAgICAgICdtb2RlJzogJ2NvcnMnXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGNvbnN0IGJsb2IgPSBhd2FpdCByZXNwb25zZS5ibG9iKCk7XHJcbiAgICAgICAgY29uc3Qgc2VyaWFsaXplZEJsb2IgPSBuZXcgVWludDhBcnJheShhd2FpdCBibG9iLmFycmF5QnVmZmVyKCkpO1xyXG4gIFxyXG4gICAgICAgIGNvbnN0IGJsb2JEYXRhID0ge1xyXG4gICAgICAgICAgICB0eXBlOiBibG9iLnR5cGUsXHJcbiAgICAgICAgICAgIGJ1ZmZlcjogQXJyYXkuZnJvbShzZXJpYWxpemVkQmxvYilcclxuICAgICAgICB9O1xyXG4gICAgICAgIFxyXG4gICAgICAgIHJldHVybiBibG9iRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB1cGxvYWRGaWxlKHVybCwgZm9ybURhdGEpIHtcclxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBmZXRjaCh1cmwsIHtcclxuICAgICAgICAgICAgY3JlZGVudGlhbHM6ICdpbmNsdWRlJyxcclxuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgICAgIGJvZHk6IGZvcm1EYXRhLFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHVwbG9hZEV4YW1SZXN1bHRzKGV4YW1OYW1lLCBleGFtSWQsIGNvbWJvLCBmaWxlRGVzY3JpcHRvcikge1xyXG4gICAgICAgIGNvbnN0IHVybCA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvZXhhbXMvaW1wb3J0ZXhhbXJlc3VsdHMnKTtcclxuICAgICAgICBjb25zdCB7IGJsb2IsIGZpbGVuYW1lIH0gPSBhd2FpdCBwYXJzZUNyb3NzQnJvd3NlckZpbGUoZmlsZURlc2NyaXB0b3IpO1xyXG5cclxuICAgICAgICBjb25zdCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xyXG5cclxuICAgICAgICBjb25zdCBydnQgPSBhd2FpdCBvYnRhaW5SVlQoKTtcclxuXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdfX1JlcXVlc3RWZXJpZmljYXRpb25Ub2tlbicsIHJ2dCk7XHJcblxyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnRXhhbUlkX2lucHV0JywgZXhhbU5hbWUpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnRXhhbUlkJywgZXhhbUlkKTtcclxuXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdSZXN1bHRzRmlsZScsIGJsb2IsIGZpbGVuYW1lKTtcclxuXHJcbiAgICAgICAgaWYgKGNvbWJvLmltcG9ydFByYWN0aWNlKSB7XHJcbiAgICAgICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnSW1wb3J0UHJlZmVyZW5jZXMnLCAxKTsgICAgLy8gUHJhY3RpY2VcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGNvbWJvLmltcG9ydFF1aXopIHtcclxuICAgICAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdJbXBvcnRQcmVmZXJlbmNlcycsIDIpOyAgICAvLyBRdWl6XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ1VzZXJuYW1lQ29sdW1uJywgMSk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdSZXN1bHRDb2x1bW4nLCAyKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ0NvbW1lbnRDb2x1bW4nLCAzKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ1RoZW9yeVJlc3VsdENvbHVtbicsIDQpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnVGhlb3J5Q29tbWVudENvbHVtbicsIDUpO1xyXG5cclxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB1cGxvYWRGaWxlKHVybCwgZm9ybURhdGEpO1xyXG4gICAgICAgIHJldHVybiBwcm9jZXNzRXhhbVJlc3VsdE91dGNvbWUocmVzdWx0KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBwcm9jZXNzRXhhbVJlc3VsdE91dGNvbWUocmVzdWx0KSB7XHJcbiAgICAgICAgY29uc3QgcGFnZSA9IGF3YWl0IHJlc3VsdC50ZXh0KCk7XHJcblxyXG4gICAgICAgIGNvbnN0IHN1Y2Nlc3NQYXR0ZXJuID0gLzxoMz7Qo9GB0L/QtdGI0L3QuCDQt9Cw0L/QuNGB0Lg6KC4rPyk8XFwvaDM+L3VzO1xyXG4gICAgICAgIGNvbnN0IGZhaWx1cmVQYXR0ZXJuID0gLzxoMz7QndC10YPRgdC/0LXRiNC90Lgg0LfQsNC/0LjRgdC4OiguKz8pPFxcL2gzPi91cztcclxuICAgICAgICBjb25zdCB1c2VybGlzdFBhdHRlcm4gPSAvPHA+Lio/0KPRgdC/0LXRiNC90L4g0LHRj9GF0LAg0LLQvNGK0LrQvdCw0YLQuCDRgNC10LfRg9C70YLQsNGC0LjRgtC1INC90LAg0YHQu9C10LTQvdC40YLQtSDQv9C+0YLRgNC10LHQuNGC0LXQu9C4OiguKz8pPFxcL3A+L3VzO1xyXG5cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb25zdCBzdWNjZXNzZnVsID0gTnVtYmVyKHN1Y2Nlc3NQYXR0ZXJuLmV4ZWMocGFnZSlbMV0udHJpbSgpKTtcclxuICAgICAgICAgICAgY29uc3QgZmFpbGVkID0gTnVtYmVyKGZhaWx1cmVQYXR0ZXJuLmV4ZWMocGFnZSlbMV0udHJpbSgpKTtcclxuICAgICAgICAgICAgY29uc3QgbGlzdCA9IHVzZXJsaXN0UGF0dGVybi5leGVjKHBhZ2UpWzFdLnRyaW0oKS5zcGxpdCgnLCcpLm1hcCh1ID0+IHUudHJpbSgpKTtcclxuXHJcbiAgICAgICAgICAgIHJldHVybiB7IHN1Y2Nlc3NmdWwsIGZhaWxlZCwgbGlzdCB9O1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignRXJyb3IgcHJvY2Vzc2luZyBmaWxlJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIG9idGFpblJWVCgpIHtcclxuICAgICAgICBjb25zdCB1cmwgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2V4YW1zL2ltcG9ydGV4YW1yZXN1bHRzJyk7XHJcbiAgICAgICAgY29uc3QgcGFnZURhdGEgPSBhd2FpdCBnZXQodXJsKTtcclxuICAgICAgICBjb25zdCBwYXR0ZXJuID0gLzxpbnB1dC4qP25hbWU9XCJfX1JlcXVlc3RWZXJpZmljYXRpb25Ub2tlblwiLio/dmFsdWU9XCIoLis/KVwiLio/Pi9pO1xyXG4gICAgICAgIGNvbnN0IHJ2dCA9IHBhdHRlcm4uZXhlYyhwYWdlRGF0YSlbMV07XHJcblxyXG4gICAgICAgIHJldHVybiBydnQ7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBnZXRIb21ld29ya1Jlc3VsdHMsXHJcbiAgICAgICAgZ2V0UHJvdG9jb2wsXHJcbiAgICAgICAgdXBsb2FkRXhhbVJlc3VsdHNcclxuICAgIH07XHJcbn1cclxuIiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSkge1xyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0RXZlbnRzKGluc3RhbmNlSWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3RyYWluaW5nZ3JvdXBsZWN0dXJlcy9yZWFkJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICdTdGFydERhdGVUaW1lLWFzYycsXHJcbiAgICAgICAgICAgIHBhZ2U6IDEsXHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiBgVHJhaW5pbmdJZH5lcX4ke2luc3RhbmNlSWR9YFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB1cGRhdGVFdmVudChldmVudCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdHJhaW5pbmdncm91cGxlY3R1cmVzL3VwZGF0ZScpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnLFxyXG4gICAgICAgICAgICBJZDogZXZlbnQuSWQsXHJcbiAgICAgICAgICAgIFRyYWluaW5nR3JvdXBJZDogZXZlbnQuVHJhaW5pbmdHcm91cElkLFxyXG4gICAgICAgICAgICBUcmFpbmluZ0dyb3VwTmFtZTogZXZlbnQuVHJhaW5pbmdHcm91cE5hbWUsXHJcbiAgICAgICAgICAgIExlY3R1cmVJZDogZXZlbnQuTGVjdHVyZUlkLFxyXG4gICAgICAgICAgICBMZWN0dXJlTmFtZTogZXZlbnQuTGVjdHVyZU5hbWUsXHJcbiAgICAgICAgICAgIFRyYWluaW5nSWQ6IGV2ZW50LlRyYWluaW5nSWQsXHJcbiAgICAgICAgICAgIFN0YXJ0RGF0ZVRpbWU6IGV2ZW50LlN0YXJ0RGF0ZVRpbWUsXHJcbiAgICAgICAgICAgIEVuZERhdGVUaW1lOiBldmVudC5FbmREYXRlVGltZSxcclxuICAgICAgICAgICAgSGFzTGl2ZVN0cmVhbTogZXZlbnQuSGFzTGl2ZVN0cmVhbSxcclxuICAgICAgICAgICAgVHJhaW5pbmdMYWJJZDogZXZlbnQuVHJhaW5pbmdMYWJJZCxcclxuICAgICAgICAgICAgVHJhaW5pbmdMYWJOYW1lOiBldmVudC5UcmFpbmluZ0xhYk5hbWUsXHJcbiAgICAgICAgICAgIExhc3RFZGl0ZWRVc2VybmFtZTogJycsXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogJycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcnLFxyXG4gICAgICAgICAgICBUcmFpbmluZ0dyb3VwSWRfaW5wdXQ6ICcnLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBjcmVhdGVFdmVudChldmVudCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdHJhaW5pbmdncm91cGxlY3R1cmVzL2NyZWF0ZScpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnLFxyXG4gICAgICAgICAgICBJZDogZXZlbnQuSWQsXHJcbiAgICAgICAgICAgIFRyYWluaW5nR3JvdXBJZDogZXZlbnQuVHJhaW5pbmdHcm91cElkLFxyXG4gICAgICAgICAgICBUcmFpbmluZ0dyb3VwTmFtZTogZXZlbnQuVHJhaW5pbmdHcm91cE5hbWUsXHJcbiAgICAgICAgICAgIExlY3R1cmVJZDogZXZlbnQuTGVjdHVyZUlkLFxyXG4gICAgICAgICAgICBMZWN0dXJlTmFtZTogZXZlbnQuTGVjdHVyZU5hbWUsXHJcbiAgICAgICAgICAgIFRyYWluaW5nSWQ6IGV2ZW50LlRyYWluaW5nSWQsXHJcbiAgICAgICAgICAgIFN0YXJ0RGF0ZVRpbWU6IGV2ZW50LlN0YXJ0RGF0ZVRpbWUsXHJcbiAgICAgICAgICAgIEVuZERhdGVUaW1lOiBldmVudC5FbmREYXRlVGltZSxcclxuICAgICAgICAgICAgSGFzTGl2ZVN0cmVhbTogZXZlbnQuSGFzTGl2ZVN0cmVhbSxcclxuICAgICAgICAgICAgVHJhaW5pbmdMYWJJZDogZXZlbnQuVHJhaW5pbmdMYWJJZCxcclxuICAgICAgICAgICAgVHJhaW5pbmdMYWJOYW1lOiBldmVudC5UcmFpbmluZ0xhYk5hbWUsXHJcbiAgICAgICAgICAgIExhc3RFZGl0ZWRVc2VybmFtZTogJycsXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogJycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcnLFxyXG4gICAgICAgICAgICBUcmFpbmluZ0dyb3VwSWRfaW5wdXQ6ICcnLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBkZXN0cm95RXZlbnQoZXZlbnQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3RyYWluaW5nZ3JvdXBsZWN0dXJlcy9kZXN0cm95Jyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJydcclxuICAgICAgICB9KTtcclxuICAgICAgICBPYmplY3QuYXNzaWduKGJvZHksIGV2ZW50KTtcclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCkgeyBib2R5W2tdID0gJyc7IH0gfSk7XHJcbiAgICAgICAgYm9keS5DcmVhdGVkT24gPSAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnO1xyXG4gICAgICAgIGJvZHkuTW9kaWZpZWRPbiA9ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNyc7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0RXZlbnRzQnlEYXRlKHN0YXJ0RGF0ZSwgZW5kRGF0ZSkge1xyXG4gICAgICAgIC8vIERhdGUgZm9ybWF0IHl5eXktbW0tZGQgZXhhbXBsZTogMjAyMC0wMy0yNVxyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdHJhaW5pbmdncm91cGxlY3R1cmVzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJ1N0YXJ0RGF0ZVRpbWUtYXNjJyxcclxuICAgICAgICAgICAgcGFnZTogMSxcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAwLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogYFN0YXJ0RGF0ZVRpbWV+Z3RlfmRhdGV0aW1lJyR7c3RhcnREYXRlfVQwMC0wMC0wMCd+YW5kfkVuZERhdGVUaW1lfmx0ZX5kYXRldGltZScke2VuZERhdGV9VDIzLTU5LTU5J2BcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0RXZlbnRzQnlJZChldmVudElkKSB7XHJcbiAgICAgICAgLy8gRGF0ZSBmb3JtYXQgeXl5eS1tbS1kZCBleGFtcGxlOiAyMDIwLTAzLTI1XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy90cmFpbmluZ2dyb3VwbGVjdHVyZXMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnU3RhcnREYXRlVGltZS1hc2MnLFxyXG4gICAgICAgICAgICBwYWdlOiAxLFxyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMCxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGBJZH5lcX4ke2V2ZW50SWR9YFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldEV2ZW50cyxcclxuICAgICAgICB1cGRhdGVFdmVudCxcclxuICAgICAgICBjcmVhdGVFdmVudCxcclxuICAgICAgICBkZXN0cm95RXZlbnQsXHJcbiAgICAgICAgZ2V0RXZlbnRzQnlEYXRlLFxyXG4gICAgICAgIGdldEV2ZW50c0J5SWRcclxuICAgIH07XHJcbn0iLCJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KSB7XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0RXhhbXNCeUlkKGlkcykge1xyXG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KGlkcykgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgaWRzID0gW2lkc107XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChpZHMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuIFtdO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2V4YW1zL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAwLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGBJZH5lcX4ke2lkcy5qb2luKCd+b3J+SWR+ZXF+Jyl9YFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRFeGFtc0J5Q291cnNlKG5hbWVCZywgaW5zdGFuY2VJZCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvZXhhbXMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChpbnRlcm9wQXBwSWQoKSA9PT0gJ3NvZnR1bmkuYmcnKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gYFRyYWluaW5nTmFtZXNTdHJpbmd+Y29udGFpbnN+JyR7bmFtZUJnfSdgO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuICcnO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSkoKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAwLFxyXG4gICAgICAgICAgICBmaWx0ZXJcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvc3QodXJpLCBib2R5KTtcclxuICAgICAgICByZXR1cm4gZGF0YS5EYXRhLmZpbHRlcihlID0+IGUuUHJpbWFyeVRyYWluaW5ncy5maWx0ZXIodCA9PiB0LklkID09IGluc3RhbmNlSWQpLmxlbmd0aCA+IDAgfHwgZS5SZXRha2VuVHJhaW5pbmdzLmZpbHRlcih0ID0+IHQuSWQgPT0gaW5zdGFuY2VJZCkubGVuZ3RoID4gMCk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0RXhhbXNCeU5hbWUocXVlcnkpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2V4YW1zL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSAoKCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShxdWVyeSkpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBgKE5hbWVCZ35jb250YWluc34nJHtxdWVyeS5qb2luKCdcXCd+b3J+TmFtZUJnfmNvbnRhaW5zflxcJycpfScpfm9yfihOYW1lRW5+Y29udGFpbnN+JyR7cXVlcnkuam9pbignXFwnfm9yfk5hbWVFbn5jb250YWluc35cXCcnKX0nKWA7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gYE5hbWVCZ35jb250YWluc34nJHtxdWVyeX0nfm9yfk5hbWVFbn5jb250YWluc34nJHtxdWVyeX0nYDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICdDcmVhdGVkT24tZGVzYycsXHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAyMCxcclxuICAgICAgICAgICAgZmlsdGVyXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkocXVlcnkpKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGZ1bGxNYXRjaCA9IGF3YWl0IGdldEV4YW1zQnlOYW1lKHF1ZXJ5LmpvaW4oJyAnKSk7XHJcbiAgICAgICAgICAgIGNvbnN0IGZpbHRlcmVkID0gZGF0YS5EYXRhLmZpbHRlcihyID0+IGZ1bGxNYXRjaC5zb21lKHggPT4geC5JZCA9PSByLklkKSA9PSBmYWxzZSk7XHJcbiAgICAgICAgICAgIHJldHVybiBmdWxsTWF0Y2guY29uY2F0KGZpbHRlcmVkLnNsaWNlKDAsIDIwIC0gZnVsbE1hdGNoLmxlbmd0aCkpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiBkYXRhLkRhdGE7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEV4YW1Hcm91cHNCeUV4YW1JZChleGFtSWQpIHtcclxuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShleGFtSWQpID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIGV4YW1JZCA9IFtleGFtSWRdO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoZXhhbUlkLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBbXTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9leGFtZ3JvdXBzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAwLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGBFeGFtSWR+ZXF+JHtleGFtSWQuam9pbignfm9yfkV4YW1JZH5lcX4nKX1gXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmksIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEV4YW1Hcm91cHNCeURhdGUoc3RhcnREYXRlLCBlbmREYXRlKSB7XHJcbiAgICAgICAgLy8gRGF0ZSBmb3JtYXQgeXl5eS1tbS1kZCBleGFtcGxlOiAyMDIwLTAzLTI1XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9leGFtZ3JvdXBzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJ1N0YXJ0VGltZS1hc2MnLFxyXG4gICAgICAgICAgICBwYWdlOiAxLFxyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDAsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiBgU3RhcnRUaW1lfmd0ZX5kYXRldGltZScke3N0YXJ0RGF0ZX1UMDAtMDAtMDAnfmFuZH5FbmRUaW1lfmx0ZX5kYXRldGltZScke2VuZERhdGV9VDIzLTU5LTU5J2BcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0RW5yb2xsZWRCeUdyb3VwSWQoZXhhbUdyb3VwSWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2V4YW1ncm91cHBhcnRpY2lwYW50cy9yZWFkP2ZvcmVpZ25LZXlJZD0ke2V4YW1Hcm91cElkfWApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDBcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gY3JlYXRlRXhhbShleGFtKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9leGFtcy9jcmVhdGUnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgSWQ6IGV4YW0uSWQsXHJcbiAgICAgICAgICAgIE5hbWVCZzogZXhhbS5OYW1lQmcsXHJcbiAgICAgICAgICAgIE5hbWVFbjogZXhhbS5OYW1lRW4sXHJcbiAgICAgICAgICAgIFR5cGU6IGV4YW0uVHlwZSxcclxuICAgICAgICAgICAgQWxsb3dDaG9vc2luZ1NlYXRzV2l0aENvbXB1dGVyOiBleGFtLkFsbG93Q2hvb3NpbmdTZWF0c1dpdGhDb21wdXRlcixcclxuICAgICAgICAgICAgQWxsb3dBbGxVc2Vyc0luVHJhaW5pbmdzVG9TaXRFeGFtOiBleGFtLkFsbG93QWxsVXNlcnNJblRyYWluaW5nc1RvU2l0RXhhbSxcclxuICAgICAgICAgICAgRXhhbUdyb3VwRW5yb2xsbWVudERlYWRsaW5lOiBleGFtLkV4YW1Hcm91cEVucm9sbG1lbnREZWFkbGluZSxcclxuICAgICAgICAgICAgVHJhaW5pbmdOYW1lc1N0cmluZzogJycsXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogJycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcnXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICAvLyBUd28tc3RlcCBwcm9jZXNzIGlzIG5lY2Vzc2FyeSBiZWNhdXNlIG9mIGEgc2VydmVyIGJ1ZyB3aGVuIHRoZSBleGFtIGhhcyBhc3NvY2lhdGVkIHRyYWluaW5nIGluc3RhbmNlc1xyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHBvc3QodXJpLCBib2R5KTtcclxuICAgICAgICBpZiAocmVzdWx0LkVycm9ycyAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGl0ZW0gPSByZXN1bHQuRGF0YVswXTtcclxuICAgICAgICAgICAgaXRlbS5QcmltYXJ5VHJhaW5pbmdzID0gZXhhbS5QcmltYXJ5VHJhaW5pbmdzO1xyXG4gICAgICAgICAgICBpdGVtLlJldGFrZW5UcmFpbmluZ3MgPSBleGFtLlJldGFrZW5UcmFpbmluZ3M7XHJcblxyXG4gICAgICAgICAgICBjb25zdCBkZWFkbGluZSA9IG5ldyBEYXRlKE51bWJlcihpdGVtLkV4YW1Hcm91cEVucm9sbG1lbnREZWFkbGluZS5tYXRjaCgvXFxkKy8pWzBdKSk7XHJcbiAgICAgICAgICAgIGl0ZW0uRXhhbUdyb3VwRW5yb2xsbWVudERlYWRsaW5lID0gTnVtYmVyLmlzTmFOKGRlYWRsaW5lKSA/ICcnIDogZGVhZGxpbmUudG9JU09TdHJpbmcoKTtcclxuXHJcbiAgICAgICAgICAgIHJldHVybiB1cGRhdGVFeGFtKGl0ZW0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB1cGRhdGVFeGFtKGV4YW0pIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2V4YW1zL3VwZGF0ZScpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnLFxyXG4gICAgICAgICAgICBJZDogZXhhbS5JZCxcclxuICAgICAgICAgICAgTmFtZUJnOiBleGFtLk5hbWVCZyxcclxuICAgICAgICAgICAgTmFtZUVuOiBleGFtLk5hbWVFbixcclxuICAgICAgICAgICAgVHlwZTogZXhhbS5UeXBlLFxyXG4gICAgICAgICAgICBBbGxvd0Nob29zaW5nU2VhdHNXaXRoQ29tcHV0ZXI6IGV4YW0uQWxsb3dDaG9vc2luZ1NlYXRzV2l0aENvbXB1dGVyLFxyXG4gICAgICAgICAgICBBbGxvd0FsbFVzZXJzSW5UcmFpbmluZ3NUb1NpdEV4YW06IGV4YW0uQWxsb3dBbGxVc2Vyc0luVHJhaW5pbmdzVG9TaXRFeGFtLFxyXG4gICAgICAgICAgICBFeGFtR3JvdXBFbnJvbGxtZW50RGVhZGxpbmU6IGV4YW0uRXhhbUdyb3VwRW5yb2xsbWVudERlYWRsaW5lLFxyXG4gICAgICAgICAgICBUcmFpbmluZ05hbWVzU3RyaW5nOiAnJyxcclxuICAgICAgICAgICAgQ3JlYXRlZE9uOiAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnLFxyXG4gICAgICAgICAgICBNb2RpZmllZE9uOiAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICBleGFtLlByaW1hcnlUcmFpbmluZ3MuZm9yRWFjaCh0cmFpbmluZ3NUb0JvZHkoJ1ByaW1hcnlUcmFpbmluZ3MnKSk7XHJcbiAgICAgICAgZXhhbS5SZXRha2VuVHJhaW5pbmdzLmZvckVhY2godHJhaW5pbmdzVG9Cb2R5KCdSZXRha2VuVHJhaW5pbmdzJykpO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG5cclxuICAgICAgICBmdW5jdGlvbiB0cmFpbmluZ3NUb0JvZHkocHJvcE5hbWUpIHtcclxuICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICh0cmFpbmluZywgaW5kZXgpIHtcclxuICAgICAgICAgICAgICAgIGJvZHlbYCR7cHJvcE5hbWV9WyR7aW5kZXh9XS5JZGBdID0gdHJhaW5pbmcuSWQ7XHJcbiAgICAgICAgICAgICAgICBib2R5W2Ake3Byb3BOYW1lfVske2luZGV4fV0uTmFtZWBdID0gdHJhaW5pbmcuTmFtZUJnO1xyXG4gICAgICAgICAgICAgICAgYm9keVtgJHtwcm9wTmFtZX1bJHtpbmRleH1dLk5hbWVCZ2BdID0gdHJhaW5pbmcuTmFtZUJnO1xyXG4gICAgICAgICAgICAgICAgYm9keVtgJHtwcm9wTmFtZX1bJHtpbmRleH1dLk5hbWVFbmBdID0gdHJhaW5pbmcuTmFtZUVuO1xyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBjcmVhdGVFeGFtR3JvdXAoZ3JvdXApIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2V4YW1ncm91cHMvY3JlYXRlJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiAnMCcsXHJcbiAgICAgICAgICAgIEV4YW1JZDogZ3JvdXAuRXhhbUlkLFxyXG4gICAgICAgICAgICBFeGFtTmFtZTogJycsXHJcbiAgICAgICAgICAgIFN0YXJ0VGltZTogZ3JvdXAuU3RhcnRUaW1lLFxyXG4gICAgICAgICAgICBFbmRUaW1lOiBncm91cC5FbmRUaW1lLFxyXG4gICAgICAgICAgICBUcmFpbmluZ0xhYklkOiBncm91cC5UcmFpbmluZ0xhYklkLFxyXG4gICAgICAgICAgICBKdWRnZVN5c3RlbUNvbnRlc3RJZDogZ3JvdXAuSnVkZ2VTeXN0ZW1Db250ZXN0SWQsXHJcbiAgICAgICAgICAgIFRlc3RTeXN0ZW1UZXN0SWQ6IGdyb3VwLlRlc3RTeXN0ZW1UZXN0SWQsXHJcbiAgICAgICAgICAgIEV4YW1Hcm91cFBhcnRpY2lwYW50c0NvdW50OiBncm91cC5FeGFtR3JvdXBQYXJ0aWNpcGFudHNDb3VudCxcclxuICAgICAgICAgICAgTGltaXQ6IGdyb3VwLkxpbWl0LFxyXG4gICAgICAgICAgICBJc0FkZGVkVG9Hb29nbGVDYWxlbmRhcjogZ3JvdXAuSXNBZGRlZFRvR29vZ2xlQ2FsZW5kYXIsXHJcbiAgICAgICAgICAgIEN1c3RvbUVucm9sbG1lbnRTdWNjZXNzTWVzc2FnZTogZ3JvdXAuQ3VzdG9tRW5yb2xsbWVudFN1Y2Nlc3NNZXNzYWdlLFxyXG4gICAgICAgICAgICBDcmVhdGVkT246ICcnLFxyXG4gICAgICAgICAgICBNb2RpZmllZE9uOiAnJ1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB1cGRhdGVFeGFtR3JvdXAoZ3JvdXApIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2V4YW1ncm91cHMvdXBkYXRlJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiBncm91cC5JZCxcclxuICAgICAgICAgICAgRXhhbUlkOiBncm91cC5FeGFtSWQsXHJcbiAgICAgICAgICAgIEV4YW1OYW1lOiBncm91cC5FeGFtTmFtZSxcclxuICAgICAgICAgICAgU3RhcnRUaW1lOiBncm91cC5TdGFydFRpbWUsXHJcbiAgICAgICAgICAgIEVuZFRpbWU6IGdyb3VwLkVuZFRpbWUsXHJcbiAgICAgICAgICAgIFRyYWluaW5nTGFiSWQ6IGdyb3VwLlRyYWluaW5nTGFiSWQsXHJcbiAgICAgICAgICAgIEp1ZGdlU3lzdGVtQ29udGVzdElkOiBncm91cC5KdWRnZVN5c3RlbUNvbnRlc3RJZCxcclxuICAgICAgICAgICAgVGVzdFN5c3RlbVRlc3RJZDogZ3JvdXAuVGVzdFN5c3RlbVRlc3RJZCxcclxuICAgICAgICAgICAgRXhhbUdyb3VwUGFydGljaXBhbnRzQ291bnQ6IGdyb3VwLkV4YW1Hcm91cFBhcnRpY2lwYW50c0NvdW50LFxyXG4gICAgICAgICAgICBMaW1pdDogZ3JvdXAuTGltaXQsXHJcbiAgICAgICAgICAgIElzQWRkZWRUb0dvb2dsZUNhbGVuZGFyOiBncm91cC5Jc0FkZGVkVG9Hb29nbGVDYWxlbmRhcixcclxuICAgICAgICAgICAgQ3VzdG9tRW5yb2xsbWVudFN1Y2Nlc3NNZXNzYWdlOiBncm91cC5DdXN0b21FbnJvbGxtZW50U3VjY2Vzc01lc3NhZ2UsXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JyxcclxuICAgICAgICAgICAgTW9kaWZpZWRPbjogJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3J1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBkZXN0cm95RXhhbUdyb3VwKGdyb3VwKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9leGFtZ3JvdXBzL2Rlc3Ryb3knKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJ1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIE9iamVjdC5hc3NpZ24oYm9keSwgZ3JvdXApO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuICAgICAgICBib2R5LkNyZWF0ZWRPbiA9ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNyc7XHJcbiAgICAgICAgYm9keS5Nb2RpZmllZE9uID0gJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JztcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldEV4YW1zQnlJZCxcclxuICAgICAgICBnZXRFeGFtc0J5Q291cnNlLFxyXG4gICAgICAgIGdldEV4YW1zQnlOYW1lLFxyXG4gICAgICAgIGdldEV4YW1Hcm91cHNCeUV4YW1JZCxcclxuICAgICAgICBnZXRFbnJvbGxlZEJ5R3JvdXBJZCxcclxuICAgICAgICBnZXRFeGFtR3JvdXBzQnlEYXRlLFxyXG4gICAgICAgIGNyZWF0ZUV4YW0sXHJcbiAgICAgICAgdXBkYXRlRXhhbSxcclxuICAgICAgICBjcmVhdGVFeGFtR3JvdXAsXHJcbiAgICAgICAgdXBkYXRlRXhhbUdyb3VwLFxyXG4gICAgICAgIGRlc3Ryb3lFeGFtR3JvdXBcclxuICAgIH07XHJcbn1cclxuIiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSkge1xyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEluc2FuY2VHcm91cHMoaW5zdGFuY2VJZCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdHJhaW5pbmdncm91cHMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGBUcmFpbmluZ0lkfmVxfiR7aW5zdGFuY2VJZH1gXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmksIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEdyb3VwQnlJZChncm91cElkKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy90cmFpbmluZ2dyb3Vwcy9yZWFkJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogYElkfmVxfiR7Z3JvdXBJZH1gXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmksIGJvZHkpKS5EYXRhWzBdO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVRyYWluaW5nR3JvdXAoZ3JvdXApIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3RyYWluaW5nZ3JvdXBzL2NyZWF0ZScpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnLFxyXG4gICAgICAgICAgICBJZDogZ3JvdXAuSWQsXHJcbiAgICAgICAgICAgIFRyYWluaW5nSWQ6IGdyb3VwLlRyYWluaW5nSWQsXHJcbiAgICAgICAgICAgIFRyYWluaW5nTmFtZTogZ3JvdXAuVHJhaW5pbmdOYW1lLFxyXG4gICAgICAgICAgICBUcmFpbmluZ0xhYklkOiBncm91cC5UcmFpbmluZ0xhYklkLFxyXG4gICAgICAgICAgICBOYW1lOiBncm91cC5OYW1lLFxyXG4gICAgICAgICAgICBEYXlPZldlZWs6IGdyb3VwLkRheU9mV2VlayxcclxuICAgICAgICAgICAgU3RhcnRUaW1lOiBncm91cC5TdGFydFRpbWUsXHJcbiAgICAgICAgICAgIEVuZFRpbWU6IGdyb3VwLkVuZFRpbWUsXHJcbiAgICAgICAgICAgIFNraXBXZWVrc0NvdW50OiBncm91cC5Ta2lwV2Vla3NDb3VudCxcclxuICAgICAgICAgICAgV2Vla0xlY3R1cmVOdW1iZXI6IGdyb3VwLldlZWtMZWN0dXJlTnVtYmVyLFxyXG4gICAgICAgICAgICBQZW9wbGVMaW1pdDogZ3JvdXAuUGVvcGxlTGltaXQsXHJcbiAgICAgICAgICAgIFRha2VuUGxhY2VzOiBncm91cC5UYWtlblBsYWNlcyxcclxuICAgICAgICAgICAgSXNBZGRlZFRvR29vZ2xlQ2FsZW5kYXI6IGdyb3VwLklzQWRkZWRUb0dvb2dsZUNhbGVuZGFyLFxyXG4gICAgICAgICAgICBDcmVhdGVkT246ICcnLFxyXG4gICAgICAgICAgICBNb2RpZmllZE9uOiAnJ1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBkZXN0cm95R3JvdXAoZ3JvdXApIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3RyYWluaW5nZ3JvdXBzL2Rlc3Ryb3knKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJ1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIE9iamVjdC5hc3NpZ24oYm9keSwgZ3JvdXApO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuICAgICAgICBib2R5LkNyZWF0ZWRPbiA9ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNyc7XHJcbiAgICAgICAgYm9keS5Nb2RpZmllZE9uID0gJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JztcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldEluc2FuY2VHcm91cHMsXHJcbiAgICAgICAgZ2V0R3JvdXBCeUlkLFxyXG4gICAgICAgIGNyZWF0ZVRyYWluaW5nR3JvdXAsXHJcbiAgICAgICAgZGVzdHJveUdyb3VwXHJcbiAgICB9O1xyXG59IiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSkge1xyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0SW5zdGFuY2VMZWN0dXJlcyhpbnN0YW5jZUlkKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9sZWN0dXJlcy9yZWFkP2ZvcmVpZ25LZXlJZD0ke2luc3RhbmNlSWR9YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICdPcmRlckJ5LWFzYycsXHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAsXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmksIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldExlY3R1cmVzRm9yRXhhbXNCeVRyYWluaW5nSWQodHJhaW5pbmdJZCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvbGVjdHVyZXMvcmVhZD9mb3JlaWduS2V5SWQ9JHt0cmFpbmluZ0lkfWApO1xyXG4gICAgICAgIGNvbnN0IGV4YW1LZXl3b3JkcyA9IFsnZXhhbScsICdkZWZlbmNlJywgJ2RlZmVuc2UnLCAn0LjQt9C/0LjRgicsICfQt9Cw0YnQuNGC0LAnXTtcclxuICAgICAgICBjb25zdCBleGFtRXhjbHVkZUtleXdvcmRzID0gWydwcmVwYXJhdGlvbicsICfQv9C+0LTQs9C+0YLQvtCy0LrQsCddO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnT3JkZXJCeS1hc2MnLFxyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGAoTmFtZUJnfmNvbnRhaW5zficke2V4YW1LZXl3b3Jkcy5qb2luKCdcXCd+b3J+TmFtZUJnfmNvbnRhaW5zflxcJycpfScpfmFuZH4oTmFtZUJnfmRvZXNub3Rjb250YWluficke2V4YW1FeGNsdWRlS2V5d29yZHMuam9pbignXFwnfmFuZH5OYW1lQmd+ZG9lc25vdGNvbnRhaW5+XFwnJyl9JylgXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmksIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUxlY3R1cmUobGVjdHVyZSkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGxlY3R1cmUpO1xyXG5cclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2xlY3R1cmVzL3VwZGF0ZT9mb3JlaWduS2V5SWQ9JHtsZWN0dXJlLlRyYWluaW5nSWR9YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiBsZWN0dXJlLklkLFxyXG4gICAgICAgICAgICBUcmFpbmluZ0lkOiBsZWN0dXJlLlRyYWluaW5nSWQsXHJcbiAgICAgICAgICAgIE5hbWVCZzogbGVjdHVyZS5OYW1lQmcsXHJcbiAgICAgICAgICAgIE5hbWVFbjogbGVjdHVyZS5OYW1lRW4sXHJcbiAgICAgICAgICAgIEhhc01hbnVhbE51bWJlck9mU3R1ZHlIb3VyczogbGVjdHVyZS5IYXNNYW51YWxOdW1iZXJPZlN0dWR5SG91cnMsXHJcbiAgICAgICAgICAgIE51bWJlck9mU3R1ZHlIb3VyczogbGVjdHVyZS5OdW1iZXJPZlN0dWR5SG91cnMsXHJcbiAgICAgICAgICAgIElzRXhjbHVkZWRGcm9tQ2VydGlmaWNhdGU6IGxlY3R1cmUuSXNFeGNsdWRlZEZyb21DZXJ0aWZpY2F0ZSxcclxuICAgICAgICAgICAgSGFzSG9tZXdvcms6IGxlY3R1cmUuSGFzSG9tZXdvcmssXHJcbiAgICAgICAgICAgIFJlc291cmNlTWFpbHNTdGF0ZTogbGVjdHVyZS5SZXNvdXJjZU1haWxzU3RhdGUsXHJcbiAgICAgICAgICAgIEhvbWV3b3JrTWFpbHNTdGF0ZTogbGVjdHVyZS5Ib21ld29ya01haWxzU3RhdGUsXHJcbiAgICAgICAgICAgIEp1ZGdlQ29udGVzdElkOiBsZWN0dXJlLkp1ZGdlQ29udGVzdElkLFxyXG4gICAgICAgICAgICBBbHBoYUp1ZGdlQ29udGVzdElkOiBsZWN0dXJlLkFscGhhSnVkZ2VDb250ZXN0SWQsXHJcbiAgICAgICAgICAgIE9yZGVyQnk6IGxlY3R1cmUuT3JkZXJCeSxcclxuICAgICAgICAgICAgRGVzY3JpcHRpb25CZzogbGVjdHVyZS5EZXNjcmlwdGlvbkJnLFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkVuOiBsZWN0dXJlLkRlc2NyaXB0aW9uRW4sXHJcbiAgICAgICAgICAgIERhdGVzSW5mbzogbGVjdHVyZS5EYXRlc0luZm8gfHwgW10sXHJcbiAgICAgICAgICAgIExlY3R1cmVyOiBsZWN0dXJlLkxlY3R1cmVyLFxyXG4gICAgICAgICAgICBMZWN0dXJlVHlwZTogbGVjdHVyZS5MZWN0dXJlVHlwZSxcclxuICAgICAgICAgICAgRXhjbHVkZUZyb21DYWxlbmRhcjogbGVjdHVyZS5FeGNsdWRlRnJvbUNhbGVuZGFyLFxyXG4gICAgICAgICAgICBIYXNMaXZlU3RyZWFtOiBsZWN0dXJlLkhhc0xpdmVTdHJlYW0sXHJcbiAgICAgICAgICAgIEV4YW1QYXNzd29yZDogbGVjdHVyZS5FeGFtUGFzc3dvcmQsXHJcbiAgICAgICAgICAgIERpc2NvcmRDaGFubmVsOiBsZWN0dXJlLkRpc2NvcmRDaGFubmVsLFxyXG4gICAgICAgICAgICBTbGlkb0NvZGU6IGxlY3R1cmUuU2xpZG9Db2RlLFxyXG4gICAgICAgICAgICBDcmVhdGVkT246ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcyMDE5LTA3LTMxVDE3OjM5OjAyLjMxNydcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXJpYWxpemVEYXRlc0luZm8oYm9keSk7XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZUxlY3R1cmUobGVjdHVyZSkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvbGVjdHVyZXMvY3JlYXRlP2ZvcmVpZ25LZXlJZD0ke2xlY3R1cmUuVHJhaW5pbmdJZH1gKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgSWQ6IGxlY3R1cmUuSWQsXHJcbiAgICAgICAgICAgIFRyYWluaW5nSWQ6IGxlY3R1cmUuVHJhaW5pbmdJZCxcclxuICAgICAgICAgICAgTmFtZUJnOiBsZWN0dXJlLk5hbWVCZyxcclxuICAgICAgICAgICAgTmFtZUVuOiBsZWN0dXJlLk5hbWVFbixcclxuICAgICAgICAgICAgSGFzTWFudWFsTnVtYmVyT2ZTdHVkeUhvdXJzOiBsZWN0dXJlLkhhc01hbnVhbE51bWJlck9mU3R1ZHlIb3VycyxcclxuICAgICAgICAgICAgTnVtYmVyT2ZTdHVkeUhvdXJzOiBsZWN0dXJlLk51bWJlck9mU3R1ZHlIb3VycyxcclxuICAgICAgICAgICAgSXNFeGNsdWRlZEZyb21DZXJ0aWZpY2F0ZTogbGVjdHVyZS5Jc0V4Y2x1ZGVkRnJvbUNlcnRpZmljYXRlLFxyXG4gICAgICAgICAgICBIYXNIb21ld29yazogbGVjdHVyZS5IYXNIb21ld29yayxcclxuICAgICAgICAgICAgUmVzb3VyY2VNYWlsc1N0YXRlOiBsZWN0dXJlLlJlc291cmNlTWFpbHNTdGF0ZSxcclxuICAgICAgICAgICAgSG9tZXdvcmtNYWlsc1N0YXRlOiBsZWN0dXJlLkhvbWV3b3JrTWFpbHNTdGF0ZSxcclxuICAgICAgICAgICAgSnVkZ2VDb250ZXN0SWQ6IGxlY3R1cmUuSnVkZ2VDb250ZXN0SWQsXHJcbiAgICAgICAgICAgIEFscGhhSnVkZ2VDb250ZXN0SWQ6IGxlY3R1cmUuQWxwaGFKdWRnZUNvbnRlc3RJZCxcclxuICAgICAgICAgICAgT3JkZXJCeTogbGVjdHVyZS5PcmRlckJ5LFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkJnOiBsZWN0dXJlLkRlc2NyaXB0aW9uQmcsXHJcbiAgICAgICAgICAgIERlc2NyaXB0aW9uRW46IGxlY3R1cmUuRGVzY3JpcHRpb25FbixcclxuICAgICAgICAgICAgRGF0ZXNJbmZvOiBsZWN0dXJlLkRhdGVzSW5mbyB8fCBbXSxcclxuICAgICAgICAgICAgTGVjdHVyZXI6IGxlY3R1cmUuTGVjdHVyZXIsXHJcbiAgICAgICAgICAgIExlY3R1cmVUeXBlOiBsZWN0dXJlLkxlY3R1cmVUeXBlLFxyXG4gICAgICAgICAgICBFeGNsdWRlRnJvbUNhbGVuZGFyOiBsZWN0dXJlLkV4Y2x1ZGVGcm9tQ2FsZW5kYXIsXHJcbiAgICAgICAgICAgIEhhc0xpdmVTdHJlYW06IGxlY3R1cmUuSGFzTGl2ZVN0cmVhbSxcclxuICAgICAgICAgICAgRXhhbVBhc3N3b3JkOiBsZWN0dXJlLkV4YW1QYXNzd29yZCxcclxuICAgICAgICAgICAgRGlzY29yZENoYW5uZWw6IGxlY3R1cmUuRGlzY29yZENoYW5uZWwsXHJcbiAgICAgICAgICAgIFNsaWRvQ29kZTogbGVjdHVyZS5TbGlkb0NvZGUsXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogJycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcnXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgc2VyaWFsaXplRGF0ZXNJbmZvKGJvZHkpO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBkZXN0cm95TGVjdHVyZShsZWN0dXJlKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9sZWN0dXJlcy9kZXN0cm95P2ZvcmVpZ25LZXlJZD0ke2xlY3R1cmUuVHJhaW5pbmdJZH1gKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJ1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIE9iamVjdC5hc3NpZ24oYm9keSwgbGVjdHVyZSk7XHJcbiAgICAgICAgc2VyaWFsaXplRGF0ZXNJbmZvKGJvZHkpO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuICAgICAgICBib2R5LkNyZWF0ZWRPbiA9ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNyc7XHJcbiAgICAgICAgYm9keS5Nb2RpZmllZE9uID0gJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JztcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRMZWN0dXJlRGV0YWlscyh0cmFpbmluZ0lkLCBsZWN0dXJlSWQpIHtcclxuICAgICAgICBjb25zdCB1cmwgPSBpbnRlcm9wSG9zdChgdHJhaW5pbmdzL3RyYWluaW5ncy9nZXRsZWN0dXJlZGV0YWlscz90cmFpbmluZ0lkPSR7dHJhaW5pbmdJZH0mbGVjdHVyZUlkPSR7bGVjdHVyZUlkfWApO1xyXG4gICAgICAgIHJldHVybiBnZXQodXJsKTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBzZXJpYWxpemVEYXRlc0luZm8oYm9keSkge1xyXG4gICAgICAgIGNvbnN0IGRhdGVzSW5mbyA9IGJvZHkuRGF0ZXNJbmZvO1xyXG4gICAgICAgIGRlbGV0ZSBib2R5LkRhdGVzSW5mbztcclxuICAgICAgICBcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGVzSW5mby5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBjb25zdCBkYXRlID0gZGF0ZXNJbmZvW2ldO1xyXG4gICAgICAgICAgICBib2R5W2BEYXRlc0luZm9bJHtpfV0uU3RhcnRgXSA9IGRhdGUuU3RhcnQ7XHJcbiAgICAgICAgICAgIGJvZHlbYERhdGVzSW5mb1ske2l9XS5FbmRgXSA9IGRhdGUuRW5kO1xyXG4gICAgICAgICAgICBib2R5W2BEYXRlc0luZm9bJHtpfV0uRXh0cmFJbmZvcm1hdGlvbmBdID0gZGF0ZS5FeHRyYUluZm9ybWF0aW9uO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldEluc3RhbmNlTGVjdHVyZXMsXHJcbiAgICAgICAgdXBkYXRlTGVjdHVyZSxcclxuICAgICAgICBjcmVhdGVMZWN0dXJlLFxyXG4gICAgICAgIGRlc3Ryb3lMZWN0dXJlLFxyXG4gICAgICAgIGdldExlY3R1cmVEZXRhaWxzLFxyXG4gICAgICAgIGdldExlY3R1cmVzRm9yRXhhbXNCeVRyYWluaW5nSWRcclxuICAgIH07XHJcbn0iLCJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KSB7XHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRTZW1pbmFyc0J5RGF0ZShzdGFydERhdGUsIGVuZERhdGUpIHtcclxuICAgICAgICAvLyBEYXRlIGZvcm1hdCB5eXl5LW1tLWRkIGV4YW1wbGU6IDIwMjAtMDMtMjVcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3NlbWluYXJzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJ1N0YXJ0RGF0ZS1hc2MnLFxyXG4gICAgICAgICAgICBwYWdlOiAxLFxyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDAsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiBgU3RhcnREYXRlfmd0ZX5kYXRldGltZScke3N0YXJ0RGF0ZX1UMDAtMDAtMDAnfmFuZH5FbmREYXRlfmx0ZX5kYXRldGltZScke2VuZERhdGV9VDIzLTU5LTU5J2BcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBnZXRTZW1pbmFyc0J5RGF0ZVxyXG4gICAgfTtcclxufSIsImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCwgZ2V0IH0pIHtcclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFNraWxsc0J5SW5zdGFuY2UobmFtZSwgaW5zdGFuY2VJZCkge1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDAsXHJcbiAgICAgICAgICAgIHNvcnQ6ICdPcmRlckJ5LWFzYydcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgYm9keS5maWx0ZXIgPSBgTWVyZ2VkVHJhaW5pbmdzfmNvbnRhaW5zficke25hbWV9J2A7XHJcblxyXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICAgICAgICAgIHBvc3QoaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9mYXN0dHJhY2tpbnN0YW5jZXNraWxscy9yZWFkJyksIGJvZHkpLFxyXG4gICAgICAgICAgICBwb3N0KGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvY291cnNlaW5zdGFuY2Vza2lsbHMvcmVhZCcpLCBib2R5KSxcclxuICAgICAgICBdKTtcclxuICAgICAgICBsZXQgcmVzcG9uc2UgPSBbXTtcclxuICAgICAgICByZXNwb25zZSA9IHJlc3BvbnNlLmNvbmNhdChkYXRhWzBdLkRhdGEuZmlsdGVyKGkgPT4gaS5UcmFpbmluZ3MuZmlsdGVyKHQgPT4gdC5JZCA9PSBpbnN0YW5jZUlkKS5sZW5ndGggPiAwKS5tYXAocyA9PiB7IHMuVHlwZSA9ICdvcGVuJzsgcmV0dXJuIHM7IH0pKTtcclxuICAgICAgICByZXNwb25zZSA9IHJlc3BvbnNlLmNvbmNhdChkYXRhWzFdLkRhdGEuZmlsdGVyKGkgPT4gaS5UcmFpbmluZ3MuZmlsdGVyKHQgPT4gdC5JZCA9PSBpbnN0YW5jZUlkKS5sZW5ndGggPiAwKS5tYXAocyA9PiB7IHMuVHlwZSA9ICdtYWluJzsgcmV0dXJuIHM7IH0pKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVNraWxsKHNraWxsKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy8ke3NraWxsLlR5cGUgPT09ICdtYWluJyA/ICdjb3Vyc2VpbnN0YW5jZXNraWxscycgOiAnZmFzdHRyYWNraW5zdGFuY2Vza2lsbHMnfS91cGRhdGVgKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgSWQ6IHNraWxsLklkLFxyXG4gICAgICAgICAgICBUZXh0Qmc6IHNraWxsLlRleHRCZyxcclxuICAgICAgICAgICAgT3JkZXJCeTogc2tpbGwuT3JkZXJCeSxcclxuICAgICAgICAgICAgTWVyZ2VkVHJhaW5pbmdzOiBza2lsbC5NZXJnZWRUcmFpbmluZ3MsXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JyxcclxuICAgICAgICAgICAgTW9kaWZpZWRPbjogJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3J1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc2tpbGwuVHJhaW5pbmdzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHRyYWluaW5nID0gc2tpbGwuVHJhaW5pbmdzW2ldO1xyXG4gICAgICAgICAgICBib2R5W2BUcmFpbmluZ3NbJHtpfV0uSWRgXSA9IHRyYWluaW5nLklkO1xyXG4gICAgICAgICAgICBib2R5W2BUcmFpbmluZ3NbJHtpfV0uTmFtZWBdID0gdHJhaW5pbmcuTmFtZTtcclxuICAgICAgICAgICAgYm9keVtgVHJhaW5pbmdzWyR7aX1dLk5hbWVCZ2BdID0gdHJhaW5pbmcuTmFtZUJnO1xyXG4gICAgICAgICAgICBib2R5W2BUcmFpbmluZ3NbJHtpfV0uTmFtZUVuYF0gPSB0cmFpbmluZy5OYW1lRW47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgICAgIHJlc3VsdC5EYXRhWzBdLlR5cGUgPSBza2lsbC5UeXBlO1xyXG5cclxuICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVNraWxsKHNraWxsKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy8ke3NraWxsLlR5cGUgPT09ICdtYWluJyA/ICdjb3Vyc2VpbnN0YW5jZXNraWxscycgOiAnZmFzdHRyYWNraW5zdGFuY2Vza2lsbHMnfS9jcmVhdGVgKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgSWQ6IHNraWxsLklkLFxyXG4gICAgICAgICAgICBUZXh0Qmc6IHNraWxsLlRleHRCZyxcclxuICAgICAgICAgICAgT3JkZXJCeTogc2tpbGwuT3JkZXJCeSxcclxuICAgICAgICAgICAgTWVyZ2VkVHJhaW5pbmdzOiBza2lsbC5NZXJnZWRUcmFpbmluZ3MsXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogJycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcnXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBza2lsbC5UcmFpbmluZ3MubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgY29uc3QgdHJhaW5pbmcgPSBza2lsbC5UcmFpbmluZ3NbaV07XHJcbiAgICAgICAgICAgIGJvZHlbYFRyYWluaW5nc1ske2l9XS5JZGBdID0gdHJhaW5pbmcuSWQ7XHJcbiAgICAgICAgICAgIGJvZHlbYFRyYWluaW5nc1ske2l9XS5OYW1lYF0gPSB0cmFpbmluZy5OYW1lO1xyXG4gICAgICAgICAgICBib2R5W2BUcmFpbmluZ3NbJHtpfV0uTmFtZUJnYF0gPSB0cmFpbmluZy5OYW1lQmc7XHJcbiAgICAgICAgICAgIGJvZHlbYFRyYWluaW5nc1ske2l9XS5OYW1lRW5gXSA9IHRyYWluaW5nLk5hbWVFbjtcclxuICAgICAgICB9XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICAgICAgcmVzdWx0LkRhdGFbMF0uVHlwZSA9IHNraWxsLlR5cGU7XHJcblxyXG4gICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZGVzdHJveVNraWxsKHNraWxsKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy8ke3NraWxsLlR5cGUgPT09ICdtYWluJyA/ICdjb3Vyc2VpbnN0YW5jZXNraWxscycgOiAnZmFzdHRyYWNraW5zdGFuY2Vza2lsbHMnfS9kZXN0cm95YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJydcclxuICAgICAgICB9KTtcclxuICAgICAgICBPYmplY3QuYXNzaWduKGJvZHksIHNraWxsKTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNraWxsLlRyYWluaW5ncy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBjb25zdCB0cmFpbmluZyA9IHNraWxsLlRyYWluaW5nc1tpXTtcclxuICAgICAgICAgICAgYm9keVtgVHJhaW5pbmdzWyR7aX1dLklkYF0gPSB0cmFpbmluZy5JZDtcclxuICAgICAgICAgICAgYm9keVtgVHJhaW5pbmdzWyR7aX1dLk5hbWVgXSA9IHRyYWluaW5nLk5hbWU7XHJcbiAgICAgICAgICAgIGJvZHlbYFRyYWluaW5nc1ske2l9XS5OYW1lQmdgXSA9IHRyYWluaW5nLk5hbWVCZztcclxuICAgICAgICAgICAgYm9keVtgVHJhaW5pbmdzWyR7aX1dLk5hbWVFbmBdID0gdHJhaW5pbmcuTmFtZUVuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBkZWxldGUgYm9keS5UcmFpbmluZ3M7XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG4gICAgICAgIGJvZHkuQ3JlYXRlZE9uID0gJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JztcclxuICAgICAgICBib2R5Lk1vZGlmaWVkT24gPSAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHNlYXJjaFNraWxscyhxdWVyeSwgdHlwZSkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvJHt0eXBlID09PSAnbWFpbicgPyAnY291cnNlaW5zdGFuY2Vza2lsbHMnIDogJ2Zhc3R0cmFja2luc3RhbmNlc2tpbGxzJ30vcmVhZGApO1xyXG5cclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDE1LFxyXG4gICAgICAgICAgICBzb3J0OiAnT3JkZXJCeS1hc2MnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGBUZXh0Qmd+Y29udGFpbnN+JyR7cXVlcnl9J2BcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvc3QodXJpLCBib2R5KTtcclxuICAgICAgICBkYXRhLkRhdGEuZm9yRWFjaChzID0+IHMuVHlwZSA9IHR5cGUpO1xyXG5cclxuICAgICAgICByZXR1cm4gZGF0YS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgZ2V0U2tpbGxzQnlJbnN0YW5jZSxcclxuICAgICAgICB1cGRhdGVTa2lsbCxcclxuICAgICAgICBjcmVhdGVTa2lsbCxcclxuICAgICAgICBkZXN0cm95U2tpbGwsXHJcbiAgICAgICAgc2VhcmNoU2tpbGxzXHJcbiAgICB9O1xyXG59IiwiaW1wb3J0IGV2ZW50c0FwaUZhY3RvcnkgZnJvbSAnLi9ldmVudHMnO1xyXG5pbXBvcnQgbGVjdHVyZXNBcGlGYWN0b3J5IGZyb20gJy4vbGVjdHVyZXMnO1xyXG5pbXBvcnQgc2tpbGxzQXBpRmFjdG9yeSBmcm9tICcuL3NraWxscyc7XHJcbmltcG9ydCBncm91cHNBcGlGYWN0b3J5IGZyb20gJy4vZ3JvdXBzJztcclxuaW1wb3J0IGV4YW1BcGlGYWN0b3J5IGZyb20gJy4vZXhhbXMnO1xyXG5pbXBvcnQgYXNzZXNzbWVudEFwaUZhY3RvcnkgZnJvbSAnLi9hc3Nlc3NtZW50JztcclxuaW1wb3J0IHNlbWluYXJzQXBpRmFjdG9yeSBmcm9tICcuL3NlbWluYXJzJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCwgZ2V0LCBpbnRlcm9wUGxhdGZvcm1Ib3N0IH0pIHtcclxuICAgIGNvbnN0IGV2ZW50c0FwaSA9IGV2ZW50c0FwaUZhY3RvcnkoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KTtcclxuICAgIGNvbnN0IGxlY3R1cmVzQXBpID0gbGVjdHVyZXNBcGlGYWN0b3J5KHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSk7XHJcbiAgICBjb25zdCBza2lsbHNBcGkgPSBza2lsbHNBcGlGYWN0b3J5KHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSk7XHJcbiAgICBjb25zdCBncm91cHNBcGkgPSBncm91cHNBcGlGYWN0b3J5KHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSk7XHJcbiAgICBjb25zdCBleGFtc0FwaSA9IGV4YW1BcGlGYWN0b3J5KHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSk7XHJcbiAgICBjb25zdCBhc3Nlc3NtZW50QXBpID0gYXNzZXNzbWVudEFwaUZhY3RvcnkoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KTtcclxuICAgIGNvbnN0IHNlbWluYXJzQXBpID0gc2VtaW5hcnNBcGlGYWN0b3J5KHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSk7XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gc2VhcmNoQnlOYW1lKGJvZHkpIHtcclxuICAgICAgICBjb25zdCBxdWVyeSA9IGJvZHkucXVlcnkuZmlsdGVyKGYgPT4gZi5sZW5ndGggPiAwKTtcclxuXHJcbiAgICAgICAgY29uc3QgY291cnNlcyA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgICAgICAgYm9keS5tYWluICYmIGdldE1haW5JbnN0YW5jZXMoYm9keS5wYWdlLCBxdWVyeSksXHJcbiAgICAgICAgICAgIGJvZHkub3BlbiAmJiBnZXRPcGVuSW5zdGFuY2VzKGJvZHkucGFnZSwgcXVlcnkpLFxyXG4gICAgICAgICAgICBib2R5LmdlbmVyYWwgJiYgZ2V0R2VuZXJhbEluc3RhbmNlcyhib2R5LnBhZ2UsIHF1ZXJ5KVxyXG4gICAgICAgIF0pO1xyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xyXG4gICAgICAgIGZvciAobGV0IGNvdXJzZSBvZiAoY291cnNlc1swXSB8fCBbXSkpIHtcclxuICAgICAgICAgICAgcmVzdWx0LnB1c2goe1xyXG4gICAgICAgICAgICAgICAgSWQ6IGNvdXJzZS5JZCxcclxuICAgICAgICAgICAgICAgIE5hbWVCZzogY291cnNlLk5hbWVCZyxcclxuICAgICAgICAgICAgICAgIFR5cGU6ICdtYWluJyxcclxuICAgICAgICAgICAgICAgIENvdXJzZUlkOiBjb3Vyc2UuQ291cnNlSWRcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZvciAobGV0IGNvdXJzZSBvZiAoY291cnNlc1sxXSB8fCBbXSkpIHtcclxuICAgICAgICAgICAgcmVzdWx0LnB1c2goe1xyXG4gICAgICAgICAgICAgICAgSWQ6IGNvdXJzZS5JZCxcclxuICAgICAgICAgICAgICAgIE5hbWVCZzogY291cnNlLk5hbWVCZyxcclxuICAgICAgICAgICAgICAgIFR5cGU6ICdvcGVuJyxcclxuICAgICAgICAgICAgICAgIENvdXJzZUlkOiBjb3Vyc2UuQ291cnNlSWRcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZvciAobGV0IGNvdXJzZSBvZiAoY291cnNlc1syXSB8fCBbXSkpIHtcclxuICAgICAgICAgICAgcmVzdWx0LnB1c2goe1xyXG4gICAgICAgICAgICAgICAgSWQ6IGNvdXJzZS5JZCxcclxuICAgICAgICAgICAgICAgIE5hbWVCZzogY291cnNlLk5hbWVCZyxcclxuICAgICAgICAgICAgICAgIFR5cGU6ICdnZW5lcmFsJyxcclxuICAgICAgICAgICAgICAgIENvdXJzZUlkOiBjb3Vyc2UuQ291cnNlSWRcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gc2VhcmNoVHJhaW5pbmdzQnlOYW1lKG5hbWUsIGV4YWN0ID0gZmFsc2UpIHtcclxuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShuYW1lKSA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICBuYW1lID0gW25hbWVdO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3RyYWluaW5ncy9yZWFkJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiA1MCxcclxuICAgICAgICAgICAgZmlsdGVyOiBleGFjdFxyXG4gICAgICAgICAgICAgICAgPyBgTmFtZUJnfmVxficke25hbWUuZmlsdGVyKHMgPT4gcy5sZW5ndGggPiAwKS5qb2luKCdcXCd+b3J+TmFtZUJnfmVxflxcJycpfSdgXHJcbiAgICAgICAgICAgICAgICA6IGBOYW1lQmd+Y29udGFpbnN+JyR7bmFtZS5maWx0ZXIocyA9PiBzLmxlbmd0aCA+IDApLmpvaW4oJ1xcJ35vcn5OYW1lQmd+Y29udGFpbnN+XFwnJyl9J2AsXHJcbiAgICAgICAgICAgIHNvcnQ6ICdTdGFydERhdGUtZGVzYycsXHJcbiAgICAgICAgICAgIHBhZ2U6IDFcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gc2VhcmNoQ291cnNlcyhxdWVyeSkge1xyXG4gICAgICAgIGNvbnN0IHVybCA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvY291cnNlcy9yZWFkJyk7XHJcbiAgICAgICAgY29uc3QgZmlsdGVyID0gYE5hbWV+Y29udGFpbnN+JyR7cXVlcnkuc3BsaXQoJyAnKS5maWx0ZXIocyA9PiBzLmxlbmd0aCA+IDApLmpvaW4oJ1xcJ35hbmR+TmFtZX5jb250YWluc35cXCcnKX0nYDtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMCxcclxuICAgICAgICAgICAgZmlsdGVyLFxyXG4gICAgICAgICAgICBzb3J0OiAnQ3JlYXRlZE9uLWRlc2MnXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IChhd2FpdCBwb3N0KHVybCwgYm9keSkpLkRhdGE7XHJcbiAgICAgICAgcmVzdWx0LmZvckVhY2gociA9PiB7XHJcbiAgICAgICAgICAgIHIuTmFtZUJnID0gci5OYW1lO1xyXG4gICAgICAgICAgICByLk5hbWVFbiA9IHIuTmFtZTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBzZWFyY2hDb3Vyc2VJbnN0YW5jZXNCeUNvdXJzZU5hbWVBbmRJbnN0YW5jZUlkKGNvdXJzZU5hbWVzLCBpbnN0YW5jZUlkcywgZmlsdGVyID0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoY291cnNlTmFtZXMpID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIGNvdXJzZU5hbWVzID0gW2NvdXJzZU5hbWVzXTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IHVybCA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvY291cnNlcy9yZWFkJyk7XHJcbiAgICAgICAgY29uc3QgY291cnNlc0ZpbHRlciA9IGBOYW1lfmNvbnRhaW5zficke2NvdXJzZU5hbWVzLmZpbHRlcihzID0+IHMubGVuZ3RoID4gMCkuam9pbignXFwnfmFuZH5OYW1lfmNvbnRhaW5zflxcJycpfSdgO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGNvdXJzZXNGaWx0ZXIsXHJcbiAgICAgICAgICAgIHNvcnQ6ICdDcmVhdGVkT24tZGVzYydcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gKGF3YWl0IHBvc3QodXJsLCBib2R5KSkuRGF0YTtcclxuICAgICAgICByZXN1bHQuZm9yRWFjaChyID0+IHtcclxuICAgICAgICAgICAgci5OYW1lQmcgPSByLk5hbWU7XHJcbiAgICAgICAgICAgIHIuTmFtZUVuID0gci5OYW1lO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBsZXQgY291cnNlSW5zdGFuY2VzUHJvbWlzZXMgPSBbXTtcclxuICAgICAgICByZXN1bHQuZm9yRWFjaChjID0+IHtcclxuICAgICAgICAgICAgY291cnNlSW5zdGFuY2VzUHJvbWlzZXMucHVzaChnZXRDb3Vyc2VJbnN0YW5jZXMoYy5JZCwgZmlsdGVyKSk7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KGluc3RhbmNlSWRzKSA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICBpbnN0YW5jZUlkcyA9IFtpbnN0YW5jZUlkc107XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgYWxsQ291cnNlSW5zdGFuY2VzID0gKGF3YWl0IFByb21pc2UuYWxsKGNvdXJzZUluc3RhbmNlc1Byb21pc2VzKSkucmVkdWNlKChhLCBjKSA9PiBhLmNvbmNhdChjKSwgW10pO1xyXG4gICAgICAgIGxldCBmaWx0ZXJlZENvdXJzZUluc3RhbmNlcyA9IGluc3RhbmNlSWRzLmxlbmd0aCA9PSAwXHJcbiAgICAgICAgICAgID8gYWxsQ291cnNlSW5zdGFuY2VzXHJcbiAgICAgICAgICAgIDogYWxsQ291cnNlSW5zdGFuY2VzLmZpbHRlcihjaSA9PiBpbnN0YW5jZUlkcy5pbmNsdWRlcyhjaS5JZCkpO1xyXG5cclxuICAgICAgICByZXR1cm4gZmlsdGVyZWRDb3Vyc2VJbnN0YW5jZXM7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0TWFpbkluc3RhbmNlcyhwYWdlLCBxdWVyeSkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdXNlcnNpbmNvdXJzZXMvcmVhZGNvdXJzZWluc3RhbmNlcycpO1xyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9IHF1ZXJ5Lm1hcChlID0+IGBOYW1lQmd+Y29udGFpbnN+JyR7ZX0nYCkuam9pbignfmFuZH4nKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJ0lzQWN0aXZlLWRlc2N+Q3JlYXRlZE9uLWRlc2MnLFxyXG4gICAgICAgICAgICBwYWdlLFxyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMjUsXHJcbiAgICAgICAgICAgIGZpbHRlclxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgICAgIHJldHVybiBkYXRhLkRhdGEubWFwKGUgPT4gKHtcclxuICAgICAgICAgICAgSWQ6IGUuSWQsXHJcbiAgICAgICAgICAgIE5hbWVCZzogZS5OYW1lQmcsXHJcbiAgICAgICAgICAgIENvdXJzZUlkOiBlLkNvdXJzZUlkXHJcbiAgICAgICAgfSkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldE9wZW5JbnN0YW5jZXMocGFnZSwgcXVlcnkpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnL2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy91c2Vyc2luZmFzdHRyYWNrcy9yZWFkZmFzdHRyYWNraW5zdGFuY2VzJyk7XHJcbiAgICAgICAgY29uc3QgZmlsdGVyID0gcXVlcnkubWFwKGUgPT4gYE5hbWVCZ35jb250YWluc34nJHtlfSdgKS5qb2luKCd+YW5kficpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnSXNBY3RpdmUtZGVzY35DcmVhdGVkT24tZGVzYycsXHJcbiAgICAgICAgICAgIHBhZ2UsXHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAyNSxcclxuICAgICAgICAgICAgZmlsdGVyXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICAgICAgcmV0dXJuIGRhdGEuRGF0YS5tYXAoZSA9PiAoe1xyXG4gICAgICAgICAgICBJZDogZS5JZCxcclxuICAgICAgICAgICAgTmFtZUJnOiBlLk5hbWVCZyxcclxuICAgICAgICAgICAgQ291cnNlSWQ6IGUuQ291cnNlSWRcclxuICAgICAgICB9KSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0R2VuZXJhbEluc3RhbmNlcyhwYWdlLCBxdWVyeSkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdXNlcnNpbmdlbmVyYWxjb3Vyc2VpbnN0YW5jZXMvcmVhZGdlbmVyYWxjb3Vyc2VpbnN0YW5jZXMnKTtcclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSBxdWVyeS5tYXAoZSA9PiBgTmFtZUJnfmNvbnRhaW5zficke2V9J2ApLmpvaW4oJ35hbmR+Jyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICdJc0FjdGl2ZS1kZXNjfkNyZWF0ZWRPbi1kZXNjJyxcclxuICAgICAgICAgICAgcGFnZSxcclxuICAgICAgICAgICAgcGFnZVNpemU6IDI1LFxyXG4gICAgICAgICAgICBmaWx0ZXJcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvc3QodXJpLCBib2R5KTtcclxuICAgICAgICByZXR1cm4gZGF0YS5EYXRhLm1hcChlID0+ICh7XHJcbiAgICAgICAgICAgIElkOiBlLklkLFxyXG4gICAgICAgICAgICBOYW1lQmc6IGUuTmFtZUJnLFxyXG4gICAgICAgICAgICBDb3Vyc2VJZDogZS5Db3Vyc2VJZFxyXG4gICAgICAgIH0pKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRDb3Vyc2VEYXRhKGNvdXJzZUlkKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9jb3Vyc2VzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgZmlsdGVyOiBgSWR+ZXF+JyR7Y291cnNlSWR9J2BcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGFbMF07XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0Q291cnNlSW5zdGFuY2VzKGNvdXJzZUlkLCBmaWx0ZXIgPSB1bmRlZmluZWQpIHtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJ1N0YXJ0RGF0ZS1kZXNjJyxcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgICAgICAoZmlsdGVyID09IHVuZGVmaW5lZCB8fCBmaWx0ZXIubWFpbiA9PT0gdHJ1ZSlcclxuICAgICAgICAgICAgICAgID8gcG9zdChpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2NvdXJzZWluc3RhbmNlcy9yZWFkP2ZvcmVpZ25LZXlJZD0ke2NvdXJzZUlkfWApLCBib2R5KVxyXG4gICAgICAgICAgICAgICAgOiBQcm9taXNlLnJlc29sdmUodHJ1ZSksXHJcbiAgICAgICAgICAgIChmaWx0ZXIgPT0gdW5kZWZpbmVkIHx8IGZpbHRlci5tYWluID09PSB0cnVlKVxyXG4gICAgICAgICAgICAgICAgPyBwb3N0KGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvZmFzdHRyYWNraW5zdGFuY2VzL3JlYWQ/Zm9yZWlnbktleUlkPSR7Y291cnNlSWR9YCksIGJvZHkpXHJcbiAgICAgICAgICAgICAgICA6IFByb21pc2UucmVzb2x2ZSh0cnVlKSxcclxuICAgICAgICAgICAgKGZpbHRlciA9PSB1bmRlZmluZWQgfHwgZmlsdGVyLmdlbmVyYWwgPT09IHRydWUpXHJcbiAgICAgICAgICAgICAgICA/IHBvc3QoaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9nZW5lcmFsY291cnNlaW5zdGFuY2VzL3JlYWQ/Zm9yZWlnbktleUlkPSR7Y291cnNlSWR9YCksIGJvZHkpXHJcbiAgICAgICAgICAgICAgICA6IFByb21pc2UucmVzb2x2ZSh0cnVlKVxyXG4gICAgICAgIF0pO1xyXG5cclxuICAgICAgICBsZXQgcmVzcG9uc2UgPSBbXTtcclxuXHJcbiAgICAgICAgcmVzcG9uc2UgPSByZXNwb25zZS5jb25jYXQoZGF0YVswXS5EYXRhICE9IHVuZGVmaW5lZCA/IGRhdGFbMF0uRGF0YS5tYXAoYyA9PiB7IGMuSW5zdGFuY2VSZWZUeXBlID0gJ21haW4nOyByZXR1cm4gYzsgfSkgOiBbXSk7XHJcbiAgICAgICAgcmVzcG9uc2UgPSByZXNwb25zZS5jb25jYXQoZGF0YVsxXS5EYXRhICE9IHVuZGVmaW5lZCA/IGRhdGFbMV0uRGF0YS5tYXAoYyA9PiB7IGMuSW5zdGFuY2VSZWZUeXBlID0gJ29wZW4nOyByZXR1cm4gYzsgfSkgOiBbXSk7XHJcbiAgICAgICAgcmVzcG9uc2UgPSByZXNwb25zZS5jb25jYXQoZGF0YVsyXS5EYXRhICE9IHVuZGVmaW5lZCA/IGRhdGFbMl0uRGF0YS5tYXAoYyA9PiB7IGMuSW5zdGFuY2VSZWZUeXBlID0gJ2dlbmVyYWwnOyByZXR1cm4gYzsgfSkgOiBbXSk7XHJcblxyXG4gICAgICAgIHJldHVybiByZXNwb25zZTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRJbnN0YW5jZURhdGEoaW5zdGFuY2VJZCwgY291cnNlSWQsIHR5cGUpIHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBpZiAodHlwZSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGdldEluc3RhbmNlRGF0YUJ5VHlwZShpbnN0YW5jZUlkLCBjb3Vyc2VJZCwgdHlwZSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBxdWVyeVJlc3VsdHMgPSBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICAgICAgICAgICAgICAgICAgZ2V0SW5zdGFuY2VEYXRhQnlUeXBlKGluc3RhbmNlSWQsIGNvdXJzZUlkLCAnbWFpbicpLFxyXG4gICAgICAgICAgICAgICAgICAgIGdldEluc3RhbmNlRGF0YUJ5VHlwZShpbnN0YW5jZUlkLCBjb3Vyc2VJZCwgJ29wZW4nKSxcclxuICAgICAgICAgICAgICAgICAgICBnZXRJbnN0YW5jZURhdGFCeVR5cGUoaW5zdGFuY2VJZCwgY291cnNlSWQsICdnZW5lcmFsJylcclxuICAgICAgICAgICAgICAgIF0pO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHF1ZXJ5UmVzdWx0cy5maWx0ZXIoZSA9PiBlICE9PSB1bmRlZmluZWQpWzBdO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0SW5zdGFuY2VEYXRhQnlUeXBlKGluc3RhbmNlSWQsIGNvdXJzZUlkLCB0eXBlKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gKCgpID0+IHtcclxuICAgICAgICAgICAgc3dpdGNoICh0eXBlKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlICdtYWluJzpcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9jb3Vyc2VpbnN0YW5jZXMvcmVhZD9mb3JlaWduS2V5SWQ9JHtjb3Vyc2VJZH1gKTtcclxuICAgICAgICAgICAgICAgIGNhc2UgJ29wZW4nOlxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2Zhc3R0cmFja2luc3RhbmNlcy9yZWFkP2ZvcmVpZ25LZXlJZD0ke2NvdXJzZUlkfWApO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAnZ2VuZXJhbCc6XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvZ2VuZXJhbGNvdXJzZWluc3RhbmNlcy9yZWFkP2ZvcmVpZ25LZXlJZD0ke2NvdXJzZUlkfWApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSkoKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgZmlsdGVyOiBgSWR+ZXF+JHtpbnN0YW5jZUlkfWBcclxuICAgICAgICB9KTtcclxuICAgICAgICBjb25zdCBpbnN0YW5jZSA9IChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGFbMF07XHJcbiAgICAgICAgaWYgKGluc3RhbmNlICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgaW5zdGFuY2UuSW5zdGFuY2VSZWZUeXBlID0gdHlwZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGluc3RhbmNlO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEluc3RhbmNlT3ZlcnZpZXcoaW5zdGFuY2VJZHMpIHtcclxuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShpbnN0YW5jZUlkcykgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgaW5zdGFuY2VJZHMgPSBbaW5zdGFuY2VJZHNdO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3RyYWluaW5ncy9yZWFkJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGBUcmFpbmluZ0lkfmVxfiR7aW5zdGFuY2VJZHMuam9pbignfm9yflRyYWluaW5nSWR+ZXF+Jyl9YFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiB1cGRhdGVDb3Vyc2UoY291cnNlKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9jb3Vyc2VzL3VwZGF0ZScpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnLFxyXG4gICAgICAgICAgICBJZDogY291cnNlLklkLFxyXG4gICAgICAgICAgICBOYW1lOiBjb3Vyc2UuTmFtZSxcclxuICAgICAgICAgICAgRGVzY3JpcHRpb25CZzogY291cnNlLkRlc2NyaXB0aW9uQmcsXHJcbiAgICAgICAgICAgIERlc2NyaXB0aW9uRW46IGNvdXJzZS5EZXNjcmlwdGlvbkVuLFxyXG4gICAgICAgICAgICBVcmxOYW1lOiBjb3Vyc2UuVXJsTmFtZSxcclxuICAgICAgICAgICAgSWNvblVybDogY291cnNlLkljb25VcmwsXHJcbiAgICAgICAgICAgIENyZWRpdHM6IGNvdXJzZS5DcmVkaXRzLFxyXG4gICAgICAgICAgICBJc0FjdGl2ZTogY291cnNlLklzQWN0aXZlLFxyXG4gICAgICAgICAgICBJc0hpZGRlbjogY291cnNlLklzSGlkZGVuLFxyXG4gICAgICAgICAgICBPcmRlckJ5OiBjb3Vyc2UuT3JkZXJCeSxcclxuICAgICAgICAgICAgTWVyZ2VkVGFnczogY291cnNlLk1lcmdlZFRhZ3MsXHJcbiAgICAgICAgICAgIENvdXJzZUNhdGVnb3J5SWQ6IGNvdXJzZS5Db3Vyc2VDYXRlZ29yeUlkLFxyXG4gICAgICAgICAgICBDb3Vyc2VEaWZmaWN1bHR5TGV2ZWw6IGNvdXJzZS5Db3Vyc2VEaWZmaWN1bHR5TGV2ZWwsXHJcbiAgICAgICAgICAgIENvdXJzZURpZmZpY3VsdHlMZXZlbERlc2NyaXB0aW9uQmc6IGNvdXJzZS5Db3Vyc2VEaWZmaWN1bHR5TGV2ZWxEZXNjcmlwdGlvbkJnLFxyXG4gICAgICAgICAgICBDb3Vyc2VEaWZmaWN1bHR5TGV2ZWxEZXNjcmlwdGlvbkVuOiBjb3Vyc2UuQ291cnNlRGlmZmljdWx0eUxldmVsRGVzY3JpcHRpb25FbixcclxuICAgICAgICAgICAgQ3JlYXRlZE9uOiBjb3Vyc2UuQ3JlYXRlZE9uLFxyXG4gICAgICAgICAgICBNb2RpZmllZE9uOiBjb3Vyc2UuTW9kaWZpZWRPbiB8fCBjb3Vyc2UuQ3JlYXRlZE9uLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB1cGRhdGVJbnN0YW5jZShpbnN0YW5jZSkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoaW5zdGFuY2UuSW5zdGFuY2VSZWZUeXBlKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlICdtYWluJzpcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9jb3Vyc2VpbnN0YW5jZXMvdXBkYXRlP2ZvcmVpZ25LZXlJZD0ke2luc3RhbmNlLkNvdXJzZUlkfWApO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAnb3Blbic6XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvZmFzdHRyYWNraW5zdGFuY2VzL3VwZGF0ZT9mb3JlaWduS2V5SWQ9JHtpbnN0YW5jZS5Db3Vyc2VJZH1gKTtcclxuICAgICAgICAgICAgICAgIGNhc2UgJ2dlbmVyYWwnOlxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2dlbmVyYWxjb3Vyc2VpbnN0YW5jZXMvdXBkYXRlP2ZvcmVpZ25LZXlJZD0ke2luc3RhbmNlLkNvdXJzZUlkfWApO1xyXG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9mYXN0dHJhY2tpbnN0YW5jZXMvdXBkYXRlP2ZvcmVpZ25LZXlJZD0ke2luc3RhbmNlLkNvdXJzZUlkfWApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSkoKTtcclxuXHJcbiAgICAgICAgY29uc3QgYm9keSA9IE9iamVjdC5hc3NpZ24oe30sIGluc3RhbmNlLCB7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246IGluc3RhbmNlLk1vZGlmaWVkT24gfHwgaW5zdGFuY2UuQ3JlYXRlZE9uXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGRlbGV0ZSBib2R5Lkluc3RhbmNlUmVmVHlwZTtcclxuICAgICAgICBkZWxldGUgYm9keS5TaGFyZXNMaXZlU3RyZWFtV2l0aFRyYWluaW5ncztcclxuXHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFN0dWRlbnRzKGluc3RhbmNlSWQsIHR5cGUgPSAnbWFpbicpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSAoKCkgPT4ge1xyXG4gICAgICAgICAgICBzd2l0Y2ggKHR5cGUpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgJ21haW4nOlxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3VzZXJzaW5jb3Vyc2VzL3JlYWQ/Zm9yZWlnbktleUlkPSR7aW5zdGFuY2VJZH1gKTtcclxuICAgICAgICAgICAgICAgIGNhc2UgJ29wZW4nOlxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3VzZXJzaW5mYXN0dHJhY2tzL3JlYWQ/Zm9yZWlnbktleUlkPSR7aW5zdGFuY2VJZH1gKTtcclxuICAgICAgICAgICAgICAgIGNhc2UgJ2dlbmVyYWwnOlxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3VzZXJzaW5nZW5lcmFsY291cnNlaW5zdGFuY2VzL3JlYWQ/Zm9yZWlnbktleUlkPSR7aW5zdGFuY2VJZH1gKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKCk7XHJcblxyXG4gICAgICAgIHJldHVybiBhd2FpdCBmZXRjaE5leHQoKTtcclxuXHJcbiAgICAgICAgYXN5bmMgZnVuY3Rpb24gZmV0Y2hOZXh0KHBhZ2UgPSAxKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICAgICAgc29ydDogJ0NyZWF0ZWRPbi1kZXNjJyxcclxuICAgICAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwLFxyXG4gICAgICAgICAgICAgICAgcGFnZVxyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgcG9zdCh1cmksIGJvZHkpO1xyXG5cclxuICAgICAgICAgICAgbGV0IHJlc3VsdCA9IHJlc3BvbnNlLkRhdGE7XHJcblxyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuVG90YWwgPiBwYWdlICogMTAwMCkge1xyXG4gICAgICAgICAgICAgICAgcmVzdWx0ID0gcmVzdWx0LmNvbmNhdChhd2FpdCBmZXRjaE5leHQocGFnZSArIDEpKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldENvdXJzZUV2ZW50cyhpbnN0YW5jZUlkKSB7XHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgICAgICAgZ2V0TWFpbkJ5SWQoaW5zdGFuY2VJZCksXHJcbiAgICAgICAgICAgIGdldE9wZW5CeUlkKGluc3RhbmNlSWQpLFxyXG4gICAgICAgICAgICBnZXRHZW5lcmFsQnlJZChpbnN0YW5jZUlkKSxcclxuICAgICAgICAgICAgZXZlbnRzQXBpLmdldEV2ZW50cyhpbnN0YW5jZUlkKVxyXG4gICAgICAgIF0pO1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgMzsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmIChkYXRhW2ldLlRvdGFsID4gMCkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgSWQ6IGRhdGFbaV0uRGF0YVswXS5JZCxcclxuICAgICAgICAgICAgICAgICAgICBDb3Vyc2VJZDogZGF0YVtpXS5EYXRhWzBdLkNvdXJzZUlkLFxyXG4gICAgICAgICAgICAgICAgICAgIE5hbWVCZzogZGF0YVtpXS5EYXRhWzBdLk5hbWVCZyxcclxuICAgICAgICAgICAgICAgICAgICBFdmVudHM6IGRhdGFbM10sXHJcbiAgICAgICAgICAgICAgICAgICAgSW5zdGFuY2VSZWZUeXBlOiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwOiAnbWFpbicsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDE6ICdvcGVuJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgMjogJ2dlbmVyYWwnXHJcbiAgICAgICAgICAgICAgICAgICAgfSlbaV1cclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdFcnJvciBmZXRjaGluZyBpbnN0YW5jZSBkYXRhOiBBbGwgc2VhcmNoZXMgcmV0dXJuZWQgMCBtYXRjaGVzJyk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0QW55QnlJZChpbnN0YW5jZUlkKSB7XHJcbiAgICAgICAgaWYoQXJyYXkuaXNBcnJheShpbnN0YW5jZUlkKSAmJiBpbnN0YW5jZUlkLmxlbmd0aCA9PT0gMCl7XHJcbiAgICAgICAgICAgIHJldHVybiBbXTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgICAgICAgZ2V0TWFpbkJ5SWQoaW5zdGFuY2VJZCksXHJcbiAgICAgICAgICAgIGdldE9wZW5CeUlkKGluc3RhbmNlSWQpLFxyXG4gICAgICAgICAgICBnZXRHZW5lcmFsQnlJZChpbnN0YW5jZUlkKVxyXG4gICAgICAgIF0pO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHJlc3VsdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBjb25zdCBpbnN0YW5jZSA9IHJlc3VsdFtpXTtcclxuICAgICAgICAgICAgaWYgKGluc3RhbmNlLlRvdGFsID4gMCkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgdHlwZSA9ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgMDogJ21haW4nLFxyXG4gICAgICAgICAgICAgICAgICAgIDE6ICdvcGVuJyxcclxuICAgICAgICAgICAgICAgICAgICAyOiAnZ2VuZXJhbCdcclxuICAgICAgICAgICAgICAgIH0pW2ldO1xyXG4gICAgICAgICAgICAgICAgaW5zdGFuY2UuRGF0YS5mb3JFYWNoKGkgPT4gaS5JbnN0YW5jZVJlZlR5cGUgPSB0eXBlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc3VsdC5yZWR1Y2UoKHAsIGMpID0+IHAuY29uY2F0KGMuRGF0YSksIFtdKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRNYWluQnlJZChpbnN0YW5jZUlkKSB7XHJcbiAgICAgICAgY29uc3QgZmlsdGVyID0gKCgpID0+IHtcclxuICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoaW5zdGFuY2VJZCkpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBgSWR+ZXF+JHtpbnN0YW5jZUlkLmpvaW4oJ35vcn5JZH5lcX4nKX1gO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGBJZH5lcX4ke2luc3RhbmNlSWR9YDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKCk7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy91c2Vyc2luY291cnNlcy9yZWFkY291cnNlaW5zdGFuY2VzJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwMCxcclxuICAgICAgICAgICAgZmlsdGVyXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0T3BlbkJ5SWQoaW5zdGFuY2VJZCkge1xyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KGluc3RhbmNlSWQpKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gYElkfmVxfiR7aW5zdGFuY2VJZC5qb2luKCd+b3J+SWR+ZXF+Jyl9YDtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBgSWR+ZXF+JHtpbnN0YW5jZUlkfWA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KSgpO1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdXNlcnNpbmZhc3R0cmFja3MvcmVhZGZhc3R0cmFja2luc3RhbmNlcycpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDAsXHJcbiAgICAgICAgICAgIGZpbHRlclxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEdlbmVyYWxCeUlkKGluc3RhbmNlSWQpIHtcclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSAoKCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShpbnN0YW5jZUlkKSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGBJZH5lcX4ke2luc3RhbmNlSWQuam9pbignfm9yfklkfmVxficpfWA7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gYElkfmVxfiR7aW5zdGFuY2VJZH1gO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSkoKTtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3VzZXJzaW5nZW5lcmFsY291cnNlaW5zdGFuY2VzL3JlYWRnZW5lcmFsY291cnNlaW5zdGFuY2VzJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwMCxcclxuICAgICAgICAgICAgZmlsdGVyXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0SW5zdGFuY2VQYWdlKGluc3RhbmNlSWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgdHJhaW5pbmdzL3RyYWluaW5ncy9nZXRjb3Vyc2VkZXRhaWxzP2lkPSR7aW5zdGFuY2VJZH1gKTtcclxuICAgICAgICByZXR1cm4gZ2V0KHVyaSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0SW5zdGFuY2VGdWxsUGFnZSh1cmwpIHtcclxuICAgICAgICByZXR1cm4gZ2V0KHVybCk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0VHJhaW5lck5hbWVzKGluc3RhbmNlSWQpIHtcclxuICAgICAgICByZXR1cm4gKGF3YWl0IGZldGNoKGludGVyb3BIb3N0KGBrZW5kb3JlbW90ZWRhdGEvZ2V0dHJhaW5lcnNieXRyYWluaW5nP3RyYWluaW5nSWQ9JHtpbnN0YW5jZUlkfWApLCB7XHJcbiAgICAgICAgICAgICdjcmVkZW50aWFscyc6ICdpbmNsdWRlJyxcclxuICAgICAgICAgICAgJ2hlYWRlcnMnOiB7XHJcbiAgICAgICAgICAgICAgICAnVXNlci1BZ2VudCc6ICdNb3ppbGxhLzUuMCAoV2luZG93cyBOVCAxMC4wOyBXaW42NDsgeDY0OyBydjo5Ni4wKSBHZWNrby8yMDEwMDEwMSBGaXJlZm94Lzk2LjAnLFxyXG4gICAgICAgICAgICAgICAgJ0FjY2VwdCc6ICcqLyonLFxyXG4gICAgICAgICAgICAgICAgJ0FjY2VwdC1MYW5ndWFnZSc6ICdlbi1VUyxlbjtxPTAuNScsXHJcbiAgICAgICAgICAgICAgICAnWC1SZXF1ZXN0ZWQtV2l0aCc6ICdYTUxIdHRwUmVxdWVzdCcsXHJcbiAgICAgICAgICAgICAgICAnUHJhZ21hJzogJ25vLWNhY2hlJyxcclxuICAgICAgICAgICAgICAgICdDYWNoZS1Db250cm9sJzogJ25vLWNhY2hlJyxcclxuICAgICAgICAgICAgICAgICdTZWMtRmV0Y2gtRGVzdCc6ICdlbXB0eScsXHJcbiAgICAgICAgICAgICAgICAnU2VjLUZldGNoLU1vZGUnOiAnbm8tY29ycycsXHJcbiAgICAgICAgICAgICAgICAnU2VjLUZldGNoLVNpdGUnOiAnc2FtZS1vcmlnaW4nXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICdtZXRob2QnOiAnR0VUJyxcclxuICAgICAgICAgICAgJ21vZGUnOiAnY29ycydcclxuICAgICAgICB9KSkuanNvbigpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgLi4uZXZlbnRzQXBpLFxyXG4gICAgICAgIC4uLmxlY3R1cmVzQXBpLFxyXG4gICAgICAgIC4uLnNraWxsc0FwaSxcclxuICAgICAgICAuLi5ncm91cHNBcGksXHJcbiAgICAgICAgLi4uZXhhbXNBcGksXHJcbiAgICAgICAgLi4uYXNzZXNzbWVudEFwaSxcclxuICAgICAgICAuLi5zZW1pbmFyc0FwaSxcclxuICAgICAgICBzZWFyY2hCeU5hbWUsXHJcbiAgICAgICAgc2VhcmNoQ291cnNlcyxcclxuICAgICAgICBnZXRDb3Vyc2VEYXRhLFxyXG4gICAgICAgIGdldENvdXJzZUluc3RhbmNlcyxcclxuICAgICAgICBnZXRJbnN0YW5jZURhdGEsXHJcbiAgICAgICAgZ2V0SW5zdGFuY2VPdmVydmlldyxcclxuICAgICAgICB1cGRhdGVDb3Vyc2UsXHJcbiAgICAgICAgdXBkYXRlSW5zdGFuY2UsXHJcbiAgICAgICAgZ2V0U3R1ZGVudHMsXHJcbiAgICAgICAgZ2V0Q291cnNlRXZlbnRzLFxyXG4gICAgICAgIGdldEFueUJ5SWQsXHJcbiAgICAgICAgZ2V0SW5zdGFuY2VQYWdlLFxyXG4gICAgICAgIGdldEluc3RhbmNlRnVsbFBhZ2UsXHJcbiAgICAgICAgZ2V0VHJhaW5lck5hbWVzLFxyXG4gICAgICAgIHNlYXJjaENvdXJzZUluc3RhbmNlc0J5Q291cnNlTmFtZUFuZEluc3RhbmNlSWQsXHJcbiAgICAgICAgc2VhcmNoVHJhaW5pbmdzQnlOYW1lXHJcbiAgICB9O1xyXG59IiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSkge1xyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0VHJhaW5pbmdzQnlUcmFpbmVyKHVzZXJJZCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChpbnRlcm9wQXBwSWQoKSA9PT0gJ3NvZnR1bmkuYmcnKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3VzZXJzL3RyYWluZXJzaW50cmFpbmluZ3MvcmVhZHRyYWluaW5nc29mdHJhaW5lcj90cmFpbmVySWQ9JHt1c2VySWR9YCk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gaW50ZXJvcEhvc3QoYEFkbWluaXN0cmF0aW9uX1VzZXJzL1RyYWluZXJzSW5UcmFpbmluZ3MvUmVhZD9mb3JlaWduS2V5PSR7dXNlcklkfSZmb3JlaWduS2V5SWQ9JHt1c2VySWR9YCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KSgpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwLFxyXG4gICAgICAgICAgICBzb3J0OiAnTW9kaWZpZWRPbi1kZXNjJ1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICAgICAgcmVzdWx0LkRhdGEuZm9yRWFjaCh0ID0+IHtcclxuICAgICAgICAgICAgdC5EZXNjcmlwdGlvbkJnID0gdC5EZXNjcmlwdGlvbkJnIHx8ICcnO1xyXG4gICAgICAgICAgICB0LkRlc2NyaXB0aW9uRW4gPSB0LkRlc2NyaXB0aW9uRW4gfHwgJyc7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0VHJhaW5lckJ5SWQodXNlcklkKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gKCgpID0+IHtcclxuICAgICAgICAgICAgaWYgKGludGVyb3BBcHBJZCgpID09PSAnc29mdHVuaS5iZycpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdXNlcnMvdHJhaW5lcnNpbnRyYWluaW5ncy9yZWFkJyk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gaW50ZXJvcEhvc3QoJ0FkbWluaXN0cmF0aW9uX1VzZXJzL1RyYWluZXJzL1JlYWQnKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogYFVzZXJJZH5lcX4nJHt1c2VySWR9J2BcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB1cGRhdGVUcmFpbmluZ0J5VHJhaW5lcih0cmFpbmluZykge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChpbnRlcm9wQXBwSWQoKSA9PT0gJ3NvZnR1bmkuYmcnKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3VzZXJzL3RyYWluZXJzaW50cmFpbmluZ3MvVXBkYXRlVHJhaW5lckluVHJhaW5pbmcnKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdCgnQWRtaW5pc3RyYXRpb25fVXNlcnMvVHJhaW5lcnNJblRyYWluaW5ncy9VcGRhdGUnKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKCk7XHJcblxyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBUcmFpbmluZ0lkOiB0cmFpbmluZy5UcmFpbmluZ0lkLFxyXG4gICAgICAgICAgICBUcmFpbmluZ05hbWU6IHRyYWluaW5nLlRyYWluaW5nTmFtZSxcclxuICAgICAgICAgICAgVHJhaW5lckZpcnN0TmFtZTogdHJhaW5pbmcuVHJhaW5lckZpcnN0TmFtZSxcclxuICAgICAgICAgICAgVHJhaW5lckxhc3ROYW1lOiB0cmFpbmluZy5UcmFpbmVyTGFzdE5hbWUsXHJcbiAgICAgICAgICAgIFRyYWluZXJJZDogdHJhaW5pbmcuVHJhaW5lcklkLFxyXG4gICAgICAgICAgICBUcmFpbmVyT3JkZXJCeTogdHJhaW5pbmcuVHJhaW5lck9yZGVyQnksXHJcbiAgICAgICAgICAgIElzUHVibGljVHJhaW5lcjogdHJhaW5pbmcuSXNQdWJsaWNUcmFpbmVyLFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkJnOiB0cmFpbmluZy5EZXNjcmlwdGlvbkJnLFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkVuOiB0cmFpbmluZy5EZXNjcmlwdGlvbkVuLFxyXG4gICAgICAgICAgICBUcmFpbmVyUGhvdG9QYXRoOiB0cmFpbmluZy5UcmFpbmVyUGhvdG9QYXRoLFxyXG4gICAgICAgICAgICBDcmVhdGVkT246ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNydcclxuICAgICAgICB9KTtcclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCB8fCBib2R5W2tdID09PSB1bmRlZmluZWQpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVRyYWluaW5nQnlUcmFpbmVyKHRyYWluaW5nKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEFwcElkKCkgPT09ICdzb2Z0dW5pLmJnJyA/XHJcbiAgICAgICAgICAgIGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl91c2Vycy90cmFpbmVyc2ludHJhaW5pbmdzL0FkZFRyYWluZXJUb1RyYWluaW5nP3VzZXJJZD0ke3RyYWluaW5nLlRyYWluZXJJZH1gKSA6XHJcbiAgICAgICAgICAgIGludGVyb3BIb3N0KGBBZG1pbmlzdHJhdGlvbl9Vc2Vycy9UcmFpbmVyc0luVHJhaW5pbmdzL0NyZWF0ZT9mb3JlaWduS2V5PSR7dHJhaW5pbmcuVHJhaW5lcklkfWApO1xyXG5cclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgVHJhaW5pbmdJZDogdHJhaW5pbmcuVHJhaW5pbmdJZCxcclxuICAgICAgICAgICAgVHJhaW5pbmdOYW1lOiB0cmFpbmluZy5UcmFpbmluZ05hbWUsXHJcbiAgICAgICAgICAgIFRyYWluZXJGaXJzdE5hbWU6IHRyYWluaW5nLlRyYWluZXJGaXJzdE5hbWUsXHJcbiAgICAgICAgICAgIFRyYWluZXJMYXN0TmFtZTogdHJhaW5pbmcuVHJhaW5lckxhc3ROYW1lLFxyXG4gICAgICAgICAgICBUcmFpbmVySWQ6IHRyYWluaW5nLlRyYWluZXJJZCxcclxuICAgICAgICAgICAgVHJhaW5lck9yZGVyQnk6IHRyYWluaW5nLlRyYWluZXJPcmRlckJ5LFxyXG4gICAgICAgICAgICBJc1B1YmxpY1RyYWluZXI6IHRyYWluaW5nLklzUHVibGljVHJhaW5lcixcclxuICAgICAgICAgICAgRGVzY3JpcHRpb25CZzogdHJhaW5pbmcuRGVzY3JpcHRpb25CZyxcclxuICAgICAgICAgICAgRGVzY3JpcHRpb25FbjogdHJhaW5pbmcuRGVzY3JpcHRpb25FbixcclxuICAgICAgICAgICAgVHJhaW5lclBob3RvUGF0aDogdHJhaW5pbmcuVHJhaW5lclBob3RvUGF0aCxcclxuICAgICAgICAgICAgQ3JlYXRlZE9uOiAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnLFxyXG4gICAgICAgICAgICBNb2RpZmllZE9uOiAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwgfHwgYm9keVtrXSA9PT0gdW5kZWZpbmVkKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBzZWFyY2hVc2VycyhxdWVyeSwgZXhjbHVkZSkge1xyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgICAgICAgc2VhcmNoVXNlcnNCeU5hbWUocXVlcnksIGV4Y2x1ZGUpLFxyXG4gICAgICAgICAgICBzZWFyY2hVc2Vyc0J5VXNlck5hbWUocXVlcnksIGV4Y2x1ZGUpXHJcbiAgICAgICAgXSk7XHJcblxyXG4gICAgICAgIHJldHVybiByZXN1bHRbMF0uY29uY2F0KHJlc3VsdFsxXSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZGVzdHJveVRyYWluaW5nT2ZUcmFpbmVyKHRyYWluaW5nKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEFwcElkKCkgPT09ICdzb2Z0dW5pLmJnJyA/XHJcbiAgICAgICAgICAgIGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl91c2Vycy90cmFpbmVyc2ludHJhaW5pbmdzL0RlbGV0ZVRyYWluZXJGcm9tVHJhaW5pbmcnKSA6XHJcbiAgICAgICAgICAgIGludGVyb3BIb3N0KCdBZG1pbmlzdHJhdGlvbl9Vc2Vycy9UcmFpbmVyc0luVHJhaW5pbmdzL0Rlc3Ryb3knKTtcclxuXHJcbiAgICAgICAgY29uc3QgYm9keSA9IE9iamVjdC5hc3NpZ24ocGFyYW1zKCksIHRyYWluaW5nKTtcclxuICAgICAgICBib2R5LkNyZWF0ZWRPbiA9ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNyc7XHJcbiAgICAgICAgYm9keS5Nb2RpZmllZE9uID0gJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JztcclxuXHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwgfHwgYm9keVtrXSA9PT0gdW5kZWZpbmVkKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBzZWFyY2hVc2Vyc0J5TmFtZShuYW1lLCBleGNsdWRlKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3VzZXJzL3VzZXJzL3JlYWQnKTtcclxuXHJcbiAgICAgICAgbGV0IGZpbHRlciA9IG5hbWUuaW5jbHVkZXMoJyAnKSA/XHJcbiAgICAgICAgICAgIGAoRmlyc3ROYW1lRW5+ZXF+JyR7bmFtZS5zcGxpdCgnICcpWzBdfSd+YW5kfkxhc3ROYW1lRW5+c3RhcnRzd2l0aH4nJHtuYW1lLnNwbGl0KCcgJylbMV19Jyl+b3J+KEZpcnN0TmFtZUJnfmVxficke25hbWUuc3BsaXQoJyAnKVswXX0nfmFuZH5MYXN0TmFtZUJnfnN0YXJ0c3dpdGh+JyR7bmFtZS5zcGxpdCgnICcpWzFdfScpYCA6XHJcbiAgICAgICAgICAgIGBGaXJzdE5hbWVFbn5jb250YWluc34nJHtuYW1lfSd+b3J+TGFzdE5hbWVFbn5jb250YWluc34nJHtuYW1lfSd+b3J+Rmlyc3ROYW1lQmd+Y29udGFpbnN+JyR7bmFtZX0nfm9yfkxhc3ROYW1lQmd+Y29udGFpbnN+JyR7bmFtZX0nYDtcclxuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShleGNsdWRlKSkge1xyXG4gICAgICAgICAgICBmaWx0ZXIgPSBgKCR7ZmlsdGVyfSl+YW5kfihJZH5uZXF+JyR7ZXhjbHVkZS5qb2luKCdcXCd+YW5kfklkfm5lcX5cXCcnKX0nKWA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnVXNlck5hbWUtYXNjJyxcclxuICAgICAgICAgICAgcGFnZVNpemU6IDUsXHJcbiAgICAgICAgICAgIGZpbHRlclxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBzZWFyY2hVc2Vyc0J5VXNlck5hbWUobmFtZSwgZXhjbHVkZSkge1xyXG4gICAgICAgIGlmIChuYW1lLmluY2x1ZGVzKCcgJykpIHtcclxuICAgICAgICAgICAgcmV0dXJuIFtdO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdXNlcnMvdXNlcnMvcmVhZCcpO1xyXG5cclxuICAgICAgICBsZXQgZmlsdGVyID0gYFVzZXJOYW1lfmNvbnRhaW5zficke25hbWV9J2A7XHJcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoZXhjbHVkZSkpIHtcclxuICAgICAgICAgICAgZmlsdGVyID0gYCgke2ZpbHRlcn0pfmFuZH4oSWR+bmVxficke2V4Y2x1ZGUuam9pbignXFwnfmFuZH5JZH5uZXF+XFwnJyl9JylgO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJ1VzZXJOYW1lLWFzYycsXHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiA1LFxyXG4gICAgICAgICAgICBmaWx0ZXJcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0VHJhaW5lcnNCeVRyYWluaW5nKHRyYWluaW5nSWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgQWRtaW5pc3RyYXRpb25fVHJhaW5pbmdzL1RyYWluaW5nc1dpdGhUcmFpbmVycy9SZWFkP2ZvcmVpZ25LZXk9JHt0cmFpbmluZ0lkfSZmb3JlaWduS2V5SWQ9JHt0cmFpbmluZ0lkfWApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAsXHJcbiAgICAgICAgICAgIHNvcnQ6ICdPcmRlckJ5LWFzYydcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgICAgIHJlc3VsdC5EYXRhLmZvckVhY2godCA9PiB7XHJcbiAgICAgICAgICAgIHQuRGVzY3JpcHRpb25CZyA9IHQuRGVzY3JpcHRpb25CZyB8fCAnJztcclxuICAgICAgICAgICAgdC5EZXNjcmlwdGlvbkVuID0gdC5EZXNjcmlwdGlvbkVuIHx8ICcnO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcmVzdWx0LkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBnZXRUcmFpbmluZ3NCeVRyYWluZXIsXHJcbiAgICAgICAgZ2V0VHJhaW5lckJ5SWQsXHJcbiAgICAgICAgdXBkYXRlVHJhaW5pbmdCeVRyYWluZXIsXHJcbiAgICAgICAgY3JlYXRlVHJhaW5pbmdCeVRyYWluZXIsXHJcbiAgICAgICAgZGVzdHJveVRyYWluaW5nT2ZUcmFpbmVyLFxyXG4gICAgICAgIHNlYXJjaFVzZXJzLFxyXG4gICAgICAgIGdldFRyYWluZXJzQnlUcmFpbmluZ1xyXG4gICAgfTtcclxufSIsImV4cG9ydCBhc3luYyBmdW5jdGlvbiBwYXJzZUNyb3NzQnJvd3NlckZpbGUoZmlsZURlc2NyaXB0b3IpIHtcclxuICAgIGxldCBibG9iO1xyXG4gICAgbGV0IGZpbGVuYW1lO1xyXG4gICAgaWYgKGZpbGVEZXNjcmlwdG9yLmZpbGVVcmwgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgIGJsb2IgPSBhd2FpdCAoYXdhaXQgZmV0Y2goZmlsZURlc2NyaXB0b3IuZmlsZVVybCkpLmJsb2IoKTtcclxuICAgICAgICBmaWxlbmFtZSA9IGZpbGVEZXNjcmlwdG9yLm5hbWU7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIGJsb2IgPSBmaWxlRGVzY3JpcHRvci5maWxlO1xyXG4gICAgICAgIGZpbGVuYW1lID0gZmlsZURlc2NyaXB0b3IuZmlsZS5uYW1lO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7IGJsb2IsIGZpbGVuYW1lIH07XHJcbn0iLCIvLy8gPHJlZmVyZW5jZSBwYXRoPVwiLi9hcGkuZC50c1wiIC8+XHJcblxyXG5pbXBvcnQgeyB1dWlkIH0gZnJvbSAnLi9wYXJzZSc7XHJcbmltcG9ydCBiaW5kU2l0ZUFwaSBmcm9tICcuLi9hcGkvYXBpLWluZGV4JztcclxuaW1wb3J0IEFXTiBmcm9tICcuLi8uLi9ub2RlX21vZHVsZXMvYXdlc29tZS1ub3RpZmljYXRpb25zL3NyYy9pbmRleC5qcyc7XHJcblxyXG5jb25zdCBkaXNwYXRjaGVyID0ge307XHJcblxyXG5sZXQgYmdQb3J0O1xyXG5zdGFydFNlc0FwaVBvcnQoKTtcclxuXHJcbmZ1bmN0aW9uIHN0YXJ0U2VzQXBpUG9ydCgpIHtcclxuICAgIGJnUG9ydCA9IGJyb3dzZXIucnVudGltZS5jb25uZWN0KHsgbmFtZTogJ3Nlcy1hcGktcG9ydCcgfSk7XHJcbiAgICBiZ1BvcnQub25NZXNzYWdlLmFkZExpc3RlbmVyKG9uTWVzc2FnZSk7XHJcbiAgICBiZ1BvcnQub25EaXNjb25uZWN0LmFkZExpc3RlbmVyKCgpID0+IHtcclxuICAgICAgICBzdGFydFNlc0FwaVBvcnQoKTtcclxuICAgIH0pO1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXREYXRhKHR5cGUsIHBhcmFtcykge1xyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICBjb25zdCBfdXVpZCA9IHV1aWQoKTtcclxuICAgICAgICBiZ1BvcnQucG9zdE1lc3NhZ2Uoe1xyXG4gICAgICAgICAgICBfdXVpZCxcclxuICAgICAgICAgICAgYXBwTmFtZTogaW50ZXJvcEFwcE5hbWUoKSxcclxuICAgICAgICAgICAgdHlwZSxcclxuICAgICAgICAgICAgcGFyYW1zXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGRpc3BhdGNoZXJbX3V1aWRdID0geyByZXNvbHZlLCByZWplY3QsIHR5cGUgfTtcclxuICAgIH0pO1xyXG59XHJcblxyXG5mdW5jdGlvbiBvbk1lc3NhZ2UobSkge1xyXG4gICAgY29uc3QgdXVpZCA9IG0uX3V1aWQ7XHJcbiAgICBpZiAobS5fcmVqZWN0ZWQpIHtcclxuICAgICAgICBjb25zb2xlLmluZm8oJ09wZXJhdGlvbiByZWplY3Q6JywgZGlzcGF0Y2hlclt1dWlkXS50eXBlKTtcclxuICAgICAgICBjb25zdCBlcnJvciA9IG5ldyBFcnJvcihtLl9lcnJvcik7XHJcbiAgICAgICAgbGV0IG5vdGlmaWVyID0gbmV3IEFXTigpO1xyXG4gICAgICAgIG5vdGlmaWVyLmFsZXJ0KGAke20uX2Vycm9yfWAsIHtkdXJhdGlvbnM6IHthbGVydDogMTAwMDB9fSk7XHJcbiAgICAgICAgLy9tYXliZSB1cGRhdGUgdG8gc2hvdyBvbmx5IGluIGRlYnVnIG1vZGUsIHByb3ZpZGluZyBtb3JlIGRldGFpbGVkIGVycm9yIGluZm9ybWF0aW9uIHVzaW5nIHRoZSBfbWV0YSBwcm9wZXJ0eVxyXG4gICAgICAgIGNvbnNvbGUuZGlyKGVycm9yKTtcclxuXHJcbiAgICAgICAgZXJyb3IuX21ldGEgPSBtLl9tZXRhO1xyXG4gICAgICAgIGRpc3BhdGNoZXJbdXVpZF0ucmVqZWN0KGVycm9yKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgZGlzcGF0Y2hlclt1dWlkXS5yZXNvbHZlKG0uZGF0YSk7XHJcbiAgICB9XHJcbiAgICBkZWxldGUgZGlzcGF0Y2hlclt1dWlkXTtcclxufVxyXG5cclxuZnVuY3Rpb24gaW50ZXJvcEFwcE5hbWUoKSB7XHJcbiAgICBzd2l0Y2ggKHdpbmRvdy5sb2NhdGlvbi5ob3N0LnNsaWNlKDAsIDcpKSB7XHJcbiAgICAgICAgY2FzZSAnZGlnaXRhbCc6XHJcbiAgICAgICAgICAgIHJldHVybiAnZGlnaXRhbCc7XHJcbiAgICAgICAgY2FzZSAnY3JlYXRpdic6XHJcbiAgICAgICAgICAgIHJldHVybiAnY3JlYXRpdmUnO1xyXG4gICAgICAgIGNhc2UgJ2FpLnNvZnQnOlxyXG4gICAgICAgICAgICByZXR1cm4gJ2FpJztcclxuICAgICAgICBjYXNlICdmaW5hbmNlJzpcclxuICAgICAgICAgICAgcmV0dXJuICdmaW5hbmNlYWNhZGVteSc7XHJcbiAgICAgICAgY2FzZSAnZGV2LmRpZyc6XHJcbiAgICAgICAgICAgIHJldHVybiAnZGV2ZGlnaXRhbCc7XHJcbiAgICAgICAgY2FzZSAnZGV2LnNvZic6XHJcbiAgICAgICAgICAgIHJldHVybiAnZGV2c29mdHVuaSc7XHJcbiAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgcmV0dXJuICdwcm9ncmFtbWluZyc7XHJcbiAgICB9XHJcbn1cclxuXHJcbi8qKiBAdHlwZSB7U1VBUEl9ICovXHJcbmNvbnN0IGFjdGlvbnMgPSBiaW5kU2l0ZUFwaShudWxsKVxyXG4gICAgLm1hcChhID0+ICh7XHJcbiAgICAgICAgbmFtZTogYSxcclxuICAgICAgICBmdW5jOiAoLi4ucGFyYW1zKSA9PiBnZXREYXRhKGEsIHBhcmFtcylcclxuICAgIH0pKVxyXG4gICAgLnJlZHVjZSgocCwgYykgPT4ge1xyXG4gICAgICAgIHBbYy5uYW1lXSA9IGMuZnVuYztcclxuICAgICAgICByZXR1cm4gcDtcclxuICAgIH0sIHt9KTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGFjdGlvbnM7XHJcbiIsImltcG9ydCBhcGlDb25uZWN0IGZyb20gJy4vYXBpLWNvbm5lY3QnO1xyXG5cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgQ29tbW9uIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QmxvZ0J5VXJsKGJsb2dVcmwpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEJsb2dCeVVybChibG9nVXJsKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEhhbGxzKCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0SGFsbHMoKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUhhbGwoaGFsbCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QudXBkYXRlSGFsbChoYWxsKTtcclxufVxyXG5cclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcbi8vICMjIyBNb2R1bGUgRGF0YVxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNb2R1bGVzSW5Qcm9mZXNzaW9uKHByb2Zlc3Npb25JZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0TW9kdWxlc0luUHJvZmVzc2lvbihwcm9mZXNzaW9uSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TW9kdWxlcygpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldE1vZHVsZXMoKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEluc3RhbmNlc0luTW9kdWxlKG1vZHVsZUlkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRJbnN0YW5jZXNJbk1vZHVsZShtb2R1bGVJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZWFyY2hNb2R1bGVzKHF1ZXJ5KSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5zZWFyY2hNb2R1bGVzKHF1ZXJ5KTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEluc3RhbmNlSW5Nb2R1bGUobW9kdWxlSWQsIG1vZHVsZUluc3RhbmNlSWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEluc3RhbmNlSW5Nb2R1bGUobW9kdWxlSWQsIG1vZHVsZUluc3RhbmNlSWQpO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIFBheW1lbnRzIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UGF5bWVudHNGb3JQYWNrYWdlKHBhY2thZ2VOYW1lKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRQYXltZW50c0ZvclBhY2thZ2UocGFja2FnZU5hbWUpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UGFja2FnZXNGb3JQcm9kdWN0KHByb2R1Y3RJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0UGFja2FnZXNGb3JQcm9kdWN0KHByb2R1Y3RJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRQcm9kdWN0c0Zvck1vZHVsZShtb2R1bGVJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0UHJvZHVjdHNGb3JNb2R1bGUobW9kdWxlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UHJvZHVjdHNGb3JDb3Vyc2UoaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0UHJvZHVjdHNGb3JDb3Vyc2UoaW5zdGFuY2VJZCk7XHJcbn1cclxuXHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIFBheW1lbnRzIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q29udGVzdENvbXBldGVSZXN1bHRzKGNvbnRlc3RJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0Q29udGVzdENvbXBldGVSZXN1bHRzKGNvbnRlc3RJZCk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgUXVpeiBEYXRhXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVF1aXpJbnN0YW5jZShwYXlsb2FkKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5jcmVhdGVRdWl6SW5zdGFuY2UocGF5bG9hZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhZGRRdWl6UXVlc3Rpb24ocXVpeklkLCBjb250ZW50KSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5hZGRRdWVzdGlvbihxdWl6SWQsIGNvbnRlbnQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYWRkUXVpelF1ZXN0aW9uQW5zd2VyKHF1ZXN0aW9uSWQsIGFuc3dlciwgaXNDb3JyZWN0KSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5hZGRBbnN3ZXIocXVlc3Rpb25JZCwgYW5zd2VyLCBpc0NvcnJlY3QpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWxsUXVpemVzQnlOYW1lKGNvbnRhaW5pbmdOYW1lLCBwYWdlU2l6ZSwgcGFnZSkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0QWxsUXVpemVzQnlOYW1lKGNvbnRhaW5pbmdOYW1lLCBwYWdlU2l6ZSwgcGFnZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRRdWVzdGlvbnNCeUlkKHF1aXpJZCwgcGFnZVNpemUsIHBhZ2UpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldFF1ZXN0aW9uc0J5SWQocXVpeklkLCBwYWdlU2l6ZSwgcGFnZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBbnN3ZXJzQnlRdWVzdGlvbklkKHF1ZXN0aW9uSWQsIHBhZ2VTaXplLCBwYWdlKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXRBbnN3ZXJzQnlRdWVzdGlvbklkKHF1ZXN0aW9uSWQsIHBhZ2VTaXplLCBwYWdlKTtcclxufVxyXG5cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgU3VydmV5IERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U3VydmV5cyhwYWdlLCBxdWVyeSwgcGFnZVNpemUpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldFN1cnZleXMocGFnZSwgcXVlcnksIHBhZ2VTaXplKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFN1cnZleXNCeU5hbWVBbmRTdGFydEFuZEVuZERhdGUocGFnZSwgbmFtZSwgc3RhcnREYXRlLCBlbmREYXRlLCBwYWdlU2l6ZSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0U3VydmV5c0J5TmFtZUFuZFN0YXJ0QW5kRW5kRGF0ZShwYWdlLCBuYW1lLCBzdGFydERhdGUsIGVuZERhdGUsIHBhZ2VTaXplKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFN1cnZleUJ5SWQoc3VydmV5SWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldFN1cnZleUJ5SWQoc3VydmV5SWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U3VydmV5QW5zd2VycyhzdXJ2ZXlJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0U3VydmV5QW5zd2VycyhzdXJ2ZXlJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTdXJ2ZXlUZW1wbGF0ZXMoKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRTdXJ2ZXlUZW1wbGF0ZXMoKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFN1cnZleVF1ZXN0aW9uc0J5VGVtcGxhdGVJZCh0ZW1wbGF0ZUlkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRTdXJ2ZXlRdWVzdGlvbnNCeVRlbXBsYXRlSWQodGVtcGxhdGVJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTdXJ2ZXlTZWN0aW9uc0J5VGVtcGxhdGVJZCh0ZW1wbGF0ZUlkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRTdXJ2ZXlTZWN0aW9uc0J5VGVtcGxhdGVJZCh0ZW1wbGF0ZUlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFN1cnZleVNlY3Rpb25zQnlJZChzZWN0aW9uSWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldFN1cnZleVNlY3Rpb25zQnlJZChzZWN0aW9uSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmluZFN1cnZleUJ5VHJhaW5pbmcobmFtZUJnKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5maW5kU3VydmV5QnlUcmFpbmluZyhuYW1lQmcpO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIFVzZXIgRGF0YVxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRUcmFpbmluZ3NCeVRyYWluZXIodXNlcklkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRUcmFpbmluZ3NCeVRyYWluZXIodXNlcklkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRyYWluZXJCeUlkKHVzZXJJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0VHJhaW5lckJ5SWQodXNlcklkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVRyYWluaW5nQnlUcmFpbmVyKHRyYWluaW5nKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC51cGRhdGVUcmFpbmluZ0J5VHJhaW5lcih0cmFpbmluZyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVUcmFpbmluZ0J5VHJhaW5lcih0cmFpbmluZykge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuY3JlYXRlVHJhaW5pbmdCeVRyYWluZXIodHJhaW5pbmcpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVzdHJveVRyYWluaW5nT2ZUcmFpbmVyKHRyYWluaW5nKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5kZXN0cm95VHJhaW5pbmdPZlRyYWluZXIodHJhaW5pbmcpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2VhcmNoVXNlcnMocXVlcnksIGV4Y2x1ZGUpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LnNlYXJjaFVzZXJzKHF1ZXJ5LCBleGNsdWRlKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRyYWluZXJzQnlUcmFpbmluZyh0cmFpbmluZ0lkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRUcmFpbmVyc0J5VHJhaW5pbmcodHJhaW5pbmdJZCk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgQ291cnNlIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2VhcmNoQnlOYW1lKGJvZHkpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LnNlYXJjaEJ5TmFtZShib2R5KTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNlYXJjaENvdXJzZXMocXVlcnkpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LnNlYXJjaENvdXJzZXMocXVlcnkpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q291cnNlRGF0YShjb3Vyc2VJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0Q291cnNlRGF0YShjb3Vyc2VJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb3Vyc2VJbnN0YW5jZXMoY291cnNlSWQsIGZpbHRlciA9IHVuZGVmaW5lZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0Q291cnNlSW5zdGFuY2VzKGNvdXJzZUlkLCBmaWx0ZXIgPSB1bmRlZmluZWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SW5zdGFuY2VEYXRhKGluc3RhbmNlSWQsIGNvdXJzZUlkLCB0eXBlKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRJbnN0YW5jZURhdGEoaW5zdGFuY2VJZCwgY291cnNlSWQsIHR5cGUpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlQ291cnNlKGNvdXJzZSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QudXBkYXRlQ291cnNlKGNvdXJzZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGRhdGVJbnN0YW5jZShpbnN0YW5jZSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QudXBkYXRlSW5zdGFuY2UoaW5zdGFuY2UpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U3R1ZGVudHMoaW5zdGFuY2VJZCwgdHlwZSA9ICdtYWluJykge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0U3R1ZGVudHMoaW5zdGFuY2VJZCwgdHlwZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb3Vyc2VFdmVudHMoaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0Q291cnNlRXZlbnRzKGluc3RhbmNlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QW55QnlJZChpbnN0YW5jZUlkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRBbnlCeUlkKGluc3RhbmNlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SW5zdGFuY2VQYWdlKGluc3RhbmNlSWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEluc3RhbmNlUGFnZShpbnN0YW5jZUlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEluc3RhbmNlRnVsbFBhZ2UodXJsKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRJbnN0YW5jZUZ1bGxQYWdlKHVybCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRUcmFpbmVyTmFtZXMoaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0VHJhaW5lck5hbWVzKGluc3RhbmNlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2VhcmNoQ291cnNlSW5zdGFuY2VzQnlDb3Vyc2VOYW1lQW5kSW5zdGFuY2VJZChjb3Vyc2VOYW1lLCBpbnN0YW5jZUlkLCBmaWx0ZXIgPSB1bmRlZmluZWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LnNlYXJjaENvdXJzZUluc3RhbmNlc0J5Q291cnNlTmFtZUFuZEluc3RhbmNlSWQoY291cnNlTmFtZSwgaW5zdGFuY2VJZCwgZmlsdGVyID0gdW5kZWZpbmVkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNlYXJjaFRyYWluaW5nc0J5TmFtZShuYW1lLCBleGFjdCA9IGZhbHNlKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5zZWFyY2hUcmFpbmluZ3NCeU5hbWUobmFtZSwgZXhhY3QpO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIEV4YW0gRGF0YVxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRFeGFtc0J5Q291cnNlKG5hbWVCZywgaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0RXhhbXNCeUNvdXJzZShuYW1lQmcsIGluc3RhbmNlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RXhhbXNCeU5hbWUocXVlcnkpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEV4YW1zQnlOYW1lKHF1ZXJ5KTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEV4YW1Hcm91cHNCeUV4YW1JZChleGFtSWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEV4YW1Hcm91cHNCeUV4YW1JZChleGFtSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RW5yb2xsZWRCeUdyb3VwSWQoZXhhbUdyb3VwSWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEVucm9sbGVkQnlHcm91cElkKGV4YW1Hcm91cElkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZUV4YW0oZXhhbSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuY3JlYXRlRXhhbShleGFtKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUV4YW0oZXhhbSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QudXBkYXRlRXhhbShleGFtKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZUV4YW1Hcm91cChncm91cCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuY3JlYXRlRXhhbUdyb3VwKGdyb3VwKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUV4YW1Hcm91cChncm91cCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QudXBkYXRlRXhhbUdyb3VwKGdyb3VwKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlc3Ryb3lFeGFtR3JvdXAoZ3JvdXApIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmRlc3Ryb3lFeGFtR3JvdXAoZ3JvdXApO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIEV2ZW50IERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RXZlbnRzKGluc3RhbmNlSWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEV2ZW50cyhpbnN0YW5jZUlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUV2ZW50KGV2ZW50KSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC51cGRhdGVFdmVudChldmVudCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVFdmVudChldmVudCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuY3JlYXRlRXZlbnQoZXZlbnQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVzdHJveUV2ZW50KGV2ZW50KSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5kZXN0cm95RXZlbnQoZXZlbnQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RXZlbnRzQnlEYXRlKHN0YXJ0RGF0ZSwgZW5kRGF0ZSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0RXZlbnRzQnlEYXRlKHN0YXJ0RGF0ZSwgZW5kRGF0ZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRFdmVudHNCeUlkKGV2ZW50SWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEV2ZW50c0J5SWQoZXZlbnRJZCk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgR3JvdXAgRGF0YVxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRJbnNhbmNlR3JvdXBzKGluc3RhbmNlSWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEluc2FuY2VHcm91cHMoaW5zdGFuY2VJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRHcm91cEJ5SWQoZ3JvdXBJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0R3JvdXBCeUlkKGdyb3VwSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlVHJhaW5pbmdHcm91cChncm91cCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuY3JlYXRlVHJhaW5pbmdHcm91cChncm91cCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXN0cm95R3JvdXAoZ3JvdXApIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmRlc3Ryb3lHcm91cChncm91cCk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgTGVjdHVyZSBEYXRhXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEluc3RhbmNlTGVjdHVyZXMoaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0SW5zdGFuY2VMZWN0dXJlcyhpbnN0YW5jZUlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUxlY3R1cmUobGVjdHVyZSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QudXBkYXRlTGVjdHVyZShsZWN0dXJlKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZUxlY3R1cmUobGVjdHVyZSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuY3JlYXRlTGVjdHVyZShsZWN0dXJlKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlc3Ryb3lMZWN0dXJlKGxlY3R1cmUpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmRlc3Ryb3lMZWN0dXJlKGxlY3R1cmUpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TGVjdHVyZURldGFpbHModHJhaW5pbmdJZCwgbGVjdHVyZUlkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRMZWN0dXJlRGV0YWlscyh0cmFpbmluZ0lkLCBsZWN0dXJlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TGVjdHVyZXNGb3JFeGFtc0J5VHJhaW5pbmdJZCh0cmFpbmluZ0lkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRMZWN0dXJlc0ZvckV4YW1zQnlUcmFpbmluZ0lkKHRyYWluaW5nSWQpO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIFNraWxsIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2tpbGxzQnlJbnN0YW5jZShuYW1lLCBpbnN0YW5jZUlkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRTa2lsbHNCeUluc3RhbmNlKG5hbWUsIGluc3RhbmNlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlU2tpbGwoc2tpbGwpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LnVwZGF0ZVNraWxsKHNraWxsKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVNraWxsKHNraWxsKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5jcmVhdGVTa2lsbChza2lsbCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXN0cm95U2tpbGwoc2tpbGwpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmRlc3Ryb3lTa2lsbChza2lsbCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZWFyY2hTa2lsbHMocXVlcnksIHR5cGUpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LnNlYXJjaFNraWxscyhxdWVyeSwgdHlwZSk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgU3RyZWFtIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SW5zdGFuY2VDb25maWcoaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0SW5zdGFuY2VDb25maWcoaW5zdGFuY2VJZCk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgQ1BFIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QXBwbGljYXRpb25zQnlJbnN0YW5jZUlkKGluc3RhbmNlSWQpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldEFwcGxpY2F0aW9uc0J5SW5zdGFuY2VJZChpbnN0YW5jZUlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFwcGxpY2F0aW9ucyhxdWVyeSwgcGFnZSkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0QXBwbGljYXRpb25zKHF1ZXJ5LCBwYWdlKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFwcFppcChpZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0QXBwWmlwKGlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFwcFN0YXR1cyhpZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0QXBwU3RhdHVzKGlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFwcFN0YXR1c0J5SW5zdGFuY2VJZChpZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0QXBwU3RhdHVzQnlJbnN0YW5jZUlkKGlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVN0YXR1cyhzdGF0dXMpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmNyZWF0ZVN0YXR1cyhzdGF0dXMpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlU3RhdHVzKHN0YXR1cykge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QudXBkYXRlU3RhdHVzKHN0YXR1cyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXN0cm95U3RhdHVzKHN0YXR1cykge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZGVzdHJveVN0YXR1cyhzdGF0dXMpO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIE5BVkVUIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRDdXJyZW50Q291cnNlcygpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldE5hdmV0Q3VycmVudENvdXJzZXMoKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE5hdmV0Q2xvc2VkQ291cnNlcygpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldE5hdmV0Q2xvc2VkQ291cnNlcygpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRBcmNoaXZlZENvdXJzZXMoKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXROYXZldEFyY2hpdmVkQ291cnNlcygpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRDb3Vyc2VJbmZvKGlkLCB0eXBlKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXROYXZldENvdXJzZUluZm8oaWQsIHR5cGUpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRTdHVkZW50cyhpZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0TmF2ZXRTdHVkZW50cyhpZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXROYXZldFN0dWRlbnRJbmZvKGNsaWVudElkKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXROYXZldFN0dWRlbnRJbmZvKGNsaWVudElkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE5hdmV0RXhpc3RpbmdGaWxlcyhjb3Vyc2VJZCwgaWQpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldE5hdmV0RXhpc3RpbmdGaWxlcyhjb3Vyc2VJZCwgaWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBsb2FkTWVkaWNhbChjb3Vyc2VJZCwgaWQsIGZpbGVEZXNjcmlwdG9yKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC51cGxvYWRNZWRpY2FsKGNvdXJzZUlkLCBpZCwgZmlsZURlc2NyaXB0b3IpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBsb2FkRGlwbG9tYShjb3Vyc2VJZCwgaWQsIGZpbGVEZXNjcmlwdG9yLCByZWdfbm8sIHBybl9ubywgZG9jX2RhdGUpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LnVwbG9hZERpcGxvbWEoY291cnNlSWQsIGlkLCBmaWxlRGVzY3JpcHRvciwgcmVnX25vLCBwcm5fbm8sIGRvY19kYXRlKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG9wZW5OYXZldEZpbGUoaWQpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0Lm9wZW5OYXZldEZpbGUoaWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVsZXRlTmF2ZXRGaWxlKGlkKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5kZWxldGVOYXZldEZpbGUoaWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0R3JhZHVhdGVJbmZvKGlkKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXRHcmFkdWF0ZUluZm8oaWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRDZXJ0aWZpY2F0ZShpZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0TmF2ZXRDZXJ0aWZpY2F0ZShpZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBvcGVuTmF2ZXRDZXJ0aWZpY2F0ZShpZCwgcGFnZSkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3Qub3Blbk5hdmV0Q2VydGlmaWNhdGUoaWQsIHBhZ2UpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBsb2FkTmF2ZXRDZXJ0aWZpY2F0ZShtZXRhLCBmaWxlRGVzY3JpcHRvcnMpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LnVwbG9hZE5hdmV0Q2VydGlmaWNhdGUobWV0YSwgZmlsZURlc2NyaXB0b3JzKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZU5hdmV0U3R1ZGVudChpZCwgc3R1ZGVudCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QudXBkYXRlTmF2ZXRTdHVkZW50KGlkLCBzdHVkZW50KTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZURvY3VtZW50KHN0dWRlbnRJZCwgY2xpZW50SWQsIGRhdGEpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmNyZWF0ZURvY3VtZW50KHN0dWRlbnRJZCwgY2xpZW50SWQsIGRhdGEpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RXh0cmFDb3Vyc2VJbmZvKGlkKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXRFeHRyYUNvdXJzZUluZm8oaWQpO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIEdlbmVyaWMgRGF0YSBTdG9yZVxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTdG9yZVNldHRpbmdzKHN0b3JlSWQpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldFN0b3JlU2V0dGluZ3Moc3RvcmVJZCk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgVGVtcGxhdGVzIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VGVtcGxhdGVTdG9yZVNldHRpbmdzKCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0VGVtcGxhdGVTdG9yZVNldHRpbmdzKCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRUZW1wbGF0ZXMoKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXRUZW1wbGF0ZXMoKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRlbXBsYXRlQnlOYW1lKG5hbWUpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldFRlbXBsYXRlQnlOYW1lKG5hbWUpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VGVtcGxhdGVCeUluc3RhbmNlSWQoaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0VGVtcGxhdGVCeUluc3RhbmNlSWQoaW5zdGFuY2VJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzYXZlVGVtcGxhdGUodGVtcGxhdGUpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LnNhdmVUZW1wbGF0ZSh0ZW1wbGF0ZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWxldGVUZW1wbGF0ZSh0ZW1wbGF0ZSkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZGVsZXRlVGVtcGxhdGUodGVtcGxhdGUpO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIEFzc2Vzc21lbnQgRGF0YVxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRIb21ld29ya1Jlc3VsdHMoaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0SG9tZXdvcmtSZXN1bHRzKGluc3RhbmNlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UHJvdG9jb2woaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0UHJvdG9jb2woaW5zdGFuY2VJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGxvYWRFeGFtUmVzdWx0cyhleGFtTmFtZSwgZXhhbUlkLCBjb21ibywgZmlsZURlc2NyaXB0b3IpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LnVwbG9hZEV4YW1SZXN1bHRzKGV4YW1OYW1lLCBleGFtSWQsIGNvbWJvLCBmaWxlRGVzY3JpcHRvcik7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb25maWdzKGV4YW1JZHMpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldENvbmZpZ3MoZXhhbUlkcyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb25maWdCeUV4YW1JZChleGFtSWQpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldENvbmZpZ0J5RXhhbUlkKGV4YW1JZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzYXZlQ29uZmlnKGNvbmZpZykge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3Quc2F2ZUNvbmZpZyhjb25maWcpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVsZXRlQ29uZmlnKGNvbmZpZykge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZGVsZXRlQ29uZmlnKGNvbmZpZyk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgU2VtaW5hciBEYXRhXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2VtaW5hcnNCeURhdGUoc3RhcnREYXRlLCBlbmREYXRlKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXRTZW1pbmFyc0J5RGF0ZShzdGFydERhdGUsIGVuZERhdGUpO1xyXG59IiwiZXhwb3J0IGNsYXNzIENvbnRlbnRUeXBlIHtcclxuICAgIC8vIFByaXZhdGUgRmllbGRzXHJcbiAgICBzdGF0aWMgI19VcmxGb3JtRW5jb2RlZCA9ICdhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWQ7IGNoYXJzZXQ9VVRGLTgnO1xyXG4gICAgc3RhdGljICNfQXBwbGljdGlvbkpzb24gPSAnYXBwbGljYXRpb24vanNvbic7XHJcblxyXG4gICAgLy8gQWNjZXNzb3JzIGZvciBcImdldFwiIGZ1bmN0aW9ucyBvbmx5IChubyBcInNldFwiIGZ1bmN0aW9ucylcclxuICAgIHN0YXRpYyBnZXQgVXJsRm9ybUVuY29kZWQoKSB7IHJldHVybiB0aGlzLiNfVXJsRm9ybUVuY29kZWQ7IH1cclxuICAgIHN0YXRpYyBnZXQgQXBwbGljYXRpb25Kc29uKCkgeyByZXR1cm4gdGhpcy4jX0FwcGxpY3Rpb25Kc29uOyB9XHJcbn0iLCJpbXBvcnQgeyBpc1NWRywgY3JlYXRlRnJhZ21lbnRGcm9tLCBFVkVOVF9MSVNURU5FUlMgfSBmcm9tICcuL3V0aWxzJztcclxuXHJcbi8qKlxyXG4gKiBUaGUgdGFnIG5hbWUgYW5kIGNyZWF0ZSBhbiBodG1sIHRvZ2V0aGVyIHdpdGggdGhlIGF0dHJpYnV0ZXNcclxuICpcclxuICogQHBhcmFtICB7U3RyaW5nfSB0YWdOYW1lIG5hbWUgYXMgc3RyaW5nLCBlLmcuICdkaXYnLCAnc3BhbicsICdzdmcnXHJcbiAqIEBwYXJhbSAge09iamVjdH0gYXR0cnMgaHRtbCBhdHRyaWJ1dGVzIGUuZy4gZGF0YS0sIHdpZHRoLCBzcmNcclxuICogQHBhcmFtICB7QXJyYXl9IGNoaWxkcmVuIGh0bWwgbm9kZXMgZnJvbSBpbnNpZGUgZGUgZWxlbWVudHNcclxuICogQHJldHVybiB7SFRNTEVsZW1lbnR8U1ZHRWxlbWVudH0gaHRtbCBub2RlIHdpdGggYXR0cnNcclxuICovXHJcbmZ1bmN0aW9uIGNyZWF0ZUVsZW1lbnRzKHRhZ05hbWUsIGF0dHJzLCBjaGlsZHJlbikge1xyXG4gICAgY29uc3QgZWxlbWVudCA9IGlzU1ZHKHRhZ05hbWUpXHJcbiAgICAgICAgPyBkb2N1bWVudC5jcmVhdGVFbGVtZW50TlMoJ2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJywgdGFnTmFtZSlcclxuICAgICAgICA6IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQodGFnTmFtZSk7XHJcblxyXG4gICAgLy8gb25lIG9yIG11bHRpcGxlIHdpbGwgYmUgZXZhbHVhdGVkIHRvIGFwcGVuZCBhcyBzdHJpbmcgb3IgSFRNTEVsZW1lbnRcclxuICAgIGNvbnN0IGZyYWdtZW50ID0gY3JlYXRlRnJhZ21lbnRGcm9tKGNoaWxkcmVuKTtcclxuICAgIGVsZW1lbnQuYXBwZW5kQ2hpbGQoZnJhZ21lbnQpO1xyXG5cclxuICAgIE9iamVjdC5rZXlzKGF0dHJzIHx8IHt9KS5mb3JFYWNoKHByb3AgPT4ge1xyXG4gICAgICAgIGlmIChwcm9wID09PSAnc3R5bGUnKSB7XHJcbiAgICAgICAgICAgIC8vIGUuZy4gb3JpZ2luOiA8ZWxlbWVudCBzdHlsZT17eyBwcm9wOiB2YWx1ZSB9fSAvPlxyXG4gICAgICAgICAgICBPYmplY3QuYXNzaWduKGVsZW1lbnQuc3R5bGUsIGF0dHJzW3Byb3BdKTtcclxuICAgICAgICB9IGVsc2UgaWYgKHByb3AgPT09ICdyZWYnICYmIHR5cGVvZiBhdHRycy5yZWYgPT09ICdmdW5jdGlvbicpIHtcclxuICAgICAgICAgICAgYXR0cnMucmVmKGVsZW1lbnQsIGF0dHJzKTtcclxuICAgICAgICB9IGVsc2UgaWYgKHByb3AgPT09ICdjbGFzc05hbWUnKSB7XHJcbiAgICAgICAgICAgIGVsZW1lbnQuc2V0QXR0cmlidXRlKCdjbGFzcycsIGF0dHJzW3Byb3BdKTtcclxuICAgICAgICB9IGVsc2UgaWYgKHByb3AgPT09ICd4bGlua0hyZWYnKSB7XHJcbiAgICAgICAgICAgIGVsZW1lbnQuc2V0QXR0cmlidXRlTlMoJ2h0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsnLCAneGxpbms6aHJlZicsIGF0dHJzW3Byb3BdKTtcclxuICAgICAgICB9IGVsc2UgaWYgKHByb3AgPT09ICdkYW5nZXJvdXNseVNldElubmVySFRNTCcpIHtcclxuICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVuZGVyc2NvcmUtZGFuZ2xlXHJcbiAgICAgICAgICAgIGVsZW1lbnQuaW5uZXJIVE1MID0gYXR0cnNbcHJvcF0uX19odG1sO1xyXG4gICAgICAgIH0gZWxzZSBpZiAocHJvcCBpbiBFVkVOVF9MSVNURU5FUlMpIHtcclxuICAgICAgICAgICAgZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKEVWRU5UX0xJU1RFTkVSU1twcm9wXSwgYXR0cnNbcHJvcF0pO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIC8vIGFueSBvdGhlciBwcm9wIHdpbGwgYmUgc2V0IGFzIGF0dHJpYnV0ZVxyXG4gICAgICAgICAgICBlbGVtZW50LnNldEF0dHJpYnV0ZShwcm9wLCBhdHRyc1twcm9wXSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIGVsZW1lbnQ7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBUaGUgSlNYVGFnIHdpbGwgYmUgdW53cmFwcGVkIHJldHVybmluZyB0aGUgaHRtbFxyXG4gKlxyXG4gKiBAcGFyYW0gIHtGdW5jdGlvbn0gSlNYVGFnIG5hbWUgYXMgc3RyaW5nLCBlLmcuICdkaXYnLCAnc3BhbicsICdzdmcnXHJcbiAqIEBwYXJhbSAge09iamVjdH0gZWxlbWVudFByb3BzIGN1c3RvbSBqc3ggYXR0cmlidXRlcyBlLmcuIGZuLCBzdHJpbmdzXHJcbiAqIEBwYXJhbSAge0FycmF5fSBjaGlsZHJlbiBodG1sIG5vZGVzIGZyb20gaW5zaWRlIGRlIGVsZW1lbnRzXHJcbiAqXHJcbiAqIEByZXR1cm4ge0Z1bmN0aW9ufSByZXR1cm5zIGRlICdkb20nIChmbikgZXhlY3V0ZWQsIGxlYXZpbmcgdGhlIEhUTUxFbGVtZW50XHJcbiAqXHJcbiAqIEpTWFRhZzogIGZ1bmN0aW9uIENvbXAocHJvcHMpIHtcclxuICogICByZXR1cm4gZG9tKFwic3BhblwiLCBudWxsLCBwcm9wcy5udW0pO1xyXG4gKiB9XHJcbiAqL1xyXG5mdW5jdGlvbiBjb21wb3NlVG9GdW5jdGlvbihKU1hUYWcsIGVsZW1lbnRQcm9wcywgY2hpbGRyZW4pIHtcclxuICAgIGNvbnN0IHByb3BzID0gT2JqZWN0LmFzc2lnbih7fSwgSlNYVGFnLmRlZmF1bHRQcm9wcyB8fCB7fSwgZWxlbWVudFByb3BzLCB7IGNoaWxkcmVuIH0pO1xyXG4gICAgY29uc3QgYnJpZGdlID0gKEpTWFRhZy5wcm90b3R5cGUgJiYgSlNYVGFnLnByb3RvdHlwZS5yZW5kZXIpID8gbmV3IEpTWFRhZyhwcm9wcykucmVuZGVyIDogSlNYVGFnO1xyXG4gICAgY29uc3QgcmVzdWx0ID0gYnJpZGdlKHByb3BzKTtcclxuXHJcbiAgICBzd2l0Y2ggKHJlc3VsdCkge1xyXG4gICAgICAgIGNhc2UgJ0ZSQUdNRU5UJzpcclxuICAgICAgICAgICAgcmV0dXJuIGNyZWF0ZUZyYWdtZW50RnJvbShjaGlsZHJlbik7XHJcblxyXG4gICAgICAgIC8vIFBvcnRhbHMgYXJlIHVzZWZ1bCB0byByZW5kZXIgbW9kYWxzXHJcbiAgICAgICAgLy8gYWxsb3cgcmVuZGVyIG9uIGEgZGlmZmVyZW50IGVsZW1lbnQgdGhhbiB0aGUgcGFyZW50IG9mIHRoZSBjaGFpblxyXG4gICAgICAgIC8vIGFuZCBsZWF2ZSBhIGNvbW1lbnQgaW5zdGVhZFxyXG4gICAgICAgIGNhc2UgJ1BPUlRBTCc6XHJcbiAgICAgICAgICAgIGJyaWRnZS50YXJnZXQuYXBwZW5kQ2hpbGQoY3JlYXRlRnJhZ21lbnRGcm9tKGNoaWxkcmVuKSk7XHJcbiAgICAgICAgICAgIHJldHVybiBkb2N1bWVudC5jcmVhdGVDb21tZW50KCdQb3J0YWwgVXNlZCcpO1xyXG4gICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGRvbShlbGVtZW50LCBhdHRycywgLi4uY2hpbGRyZW4pIHtcclxuICAgIC8vIEN1c3RvbSBDb21wb25lbnRzIHdpbGwgYmUgZnVuY3Rpb25zXHJcbiAgICBpZiAodHlwZW9mIGVsZW1lbnQgPT09ICdmdW5jdGlvbicpIHtcclxuICAgICAgICBpZiAoZWxlbWVudC5oYXNPd25Qcm9wZXJ0eSgncHJvcFR5cGVzJykpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgcHJvcCBvZiBlbGVtZW50LnByb3BUeXBlcykge1xyXG4gICAgICAgICAgICAgICAgaWYgKGF0dHJzLmhhc093blByb3BlcnR5KHByb3ApID09PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEpTWCBFcnJvcjogTWlzc2luZyBwcm9wZXJ0eSAnJHtwcm9wfScgZnJvbSAnJHtlbGVtZW50Lm5hbWV9JyBpbnZvY2F0aW9uYCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gZS5nLiBjb25zdCBDdXN0b21UYWcgPSAoeyB3IH0pID0+IDxzcGFuIHdpZHRoPXt3fSAvPlxyXG4gICAgICAgIC8vIHdpbGwgYmUgdXNlZFxyXG4gICAgICAgIC8vIGUuZy4gPEN1c3RvbVRhZyB3PXsxfSAvPlxyXG4gICAgICAgIC8vIGJlY29tZXM6IEN1c3RvbVRhZyh7IHc6IDF9KVxyXG4gICAgICAgIHJldHVybiBjb21wb3NlVG9GdW5jdGlvbihlbGVtZW50LCBhdHRycywgY2hpbGRyZW4pO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIHJlZ3VsYXIgaHRtbCBjb21wb25lbnRzIHdpbGwgYmUgc3RyaW5ncyB0byBjcmVhdGUgdGhlIGVsZW1lbnRzXHJcbiAgICAvLyB0aGlzIGlzIGhhbmRsZWQgYnkgdGhlIGJhYmVsIHBsdWdpbnNcclxuICAgIGlmICh0eXBlb2YgZWxlbWVudCA9PT0gJ3N0cmluZycpIHtcclxuICAgICAgICByZXR1cm4gY3JlYXRlRWxlbWVudHMoZWxlbWVudCwgYXR0cnMsIGNoaWxkcmVuKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gY29uc29sZS5lcnJvcihganN4LXJlbmRlciBkb2VzIG5vdCBoYW5kbGUgJHt0eXBlb2YgdGFnfWApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBkb207XHJcbmV4cG9ydCBjb25zdCBGcmFnbWVudCA9ICgpID0+ICdGUkFHTUVOVCc7XHJcbmV4cG9ydCBjb25zdCBwb3J0YWxDcmVhdG9yID0gbm9kZSA9PiB7XHJcbiAgICBmdW5jdGlvbiBQb3J0YWwoKSB7XHJcbiAgICAgICAgcmV0dXJuICdQT1JUQUwnO1xyXG4gICAgfVxyXG5cclxuICAgIFBvcnRhbC50YXJnZXQgPSBkb2N1bWVudC5ib2R5O1xyXG5cclxuICAgIGlmIChub2RlICYmIG5vZGUubm9kZVR5cGUgPT09IE5vZGUuRUxFTUVOVF9OT0RFKSB7XHJcbiAgICAgICAgUG9ydGFsLnRhcmdldCA9IG5vZGU7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIFBvcnRhbDtcclxufTtcclxuIiwiZXhwb3J0IGZ1bmN0aW9uIGlzU1ZHKGVsZW1lbnQpIHtcclxuICAgIGNvbnN0IHBhdHQgPSBuZXcgUmVnRXhwKGBeJHtlbGVtZW50fSRgLCAnaScpO1xyXG4gICAgY29uc3QgU1ZHVGFncyA9IFsncGF0aCcsICdzdmcnLCAndXNlJywgJ2cnXTtcclxuXHJcbiAgICByZXR1cm4gU1ZHVGFncy5zb21lKHRhZyA9PiBwYXR0LnRlc3QodGFnKSk7XHJcbn1cclxuXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlRnJhZ21lbnRGcm9tKGNoaWxkcmVuKSB7XHJcbiAgICAvLyBmcmFnbWVudHMgd2lsbCBoZWxwIGxhdGVyIHRvIGFwcGVuZCBtdWx0aXBsZSBjaGlsZHJlbiB0byB0aGUgaW5pdGlhbCBub2RlXHJcbiAgICBjb25zdCBmcmFnbWVudCA9IGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKTtcclxuXHJcbiAgICBmdW5jdGlvbiBwcm9jZXNzRE9NTm9kZXMoY2hpbGQpIHtcclxuICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgIGNoaWxkIGluc3RhbmNlb2YgSFRNTEVsZW1lbnQgfHxcclxuICAgICAgICAgICAgY2hpbGQgaW5zdGFuY2VvZiBTVkdFbGVtZW50IHx8XHJcbiAgICAgICAgICAgIGNoaWxkIGluc3RhbmNlb2YgQ29tbWVudCB8fFxyXG4gICAgICAgICAgICBjaGlsZCBpbnN0YW5jZW9mIERvY3VtZW50RnJhZ21lbnRcclxuICAgICAgICApIHtcclxuICAgICAgICAgICAgZnJhZ21lbnQuYXBwZW5kQ2hpbGQoY2hpbGQpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIGNoaWxkID09PSAnc3RyaW5nJyB8fCB0eXBlb2YgY2hpbGQgPT09ICdudW1iZXInKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHRleHRub2RlID0gZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUoY2hpbGQpO1xyXG4gICAgICAgICAgICBmcmFnbWVudC5hcHBlbmRDaGlsZCh0ZXh0bm9kZSk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChjaGlsZCBpbnN0YW5jZW9mIEFycmF5KSB7XHJcbiAgICAgICAgICAgIGNoaWxkLmZvckVhY2gocHJvY2Vzc0RPTU5vZGVzKTtcclxuICAgICAgICB9IGVsc2UgaWYgKGNoaWxkID09PSBmYWxzZSB8fCBjaGlsZCA9PT0gbnVsbCkge1xyXG4gICAgICAgICAgICAvLyBleHByZXNzaW9uIGV2YWx1YXRlZCBhcyBmYWxzZSBlLmcuIHtmYWxzZSAmJiA8RWxlbSAvPn1cclxuICAgICAgICAgICAgLy8gZXhwcmVzc2lvbiBldmFsdWF0ZWQgYXMgZmFsc2UgZS5nLiB7bnVsbCAmJiA8RWxlbSAvPn1cclxuICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBjaGlsZCA9PT0gJ2Z1bmN0aW9uJykge1xyXG5cclxuICAgICAgICB9IGVsc2UgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSAnZGV2ZWxvcG1lbnQnKSB7XHJcbiAgICAgICAgICAgIC8vIGxhdGVyIG90aGVyIHRoaW5ncyBjb3VsZCBub3QgYmUgSFRNTEVsZW1lbnQgbm9yIHN0cmluZ3NcclxuICAgICAgICAgICAgY29uc29sZS5sb2coY2hpbGQsICdpcyBub3QgYXBwZW5kYWJsZScpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBjaGlsZHJlbi5mb3JFYWNoKHByb2Nlc3NET01Ob2Rlcyk7XHJcblxyXG4gICAgcmV0dXJuIGZyYWdtZW50O1xyXG59XHJcblxyXG4vLyBNYXAgZnJvbSBKU1ggcHJvcGVydHkgKGUuZy4gb25DbGljaykgdG8gZXZlbnQgbmFtZSAoZS5nLiAnY2xpY2snKS5cclxuZXhwb3J0IGNvbnN0IEVWRU5UX0xJU1RFTkVSUyA9IHtcclxuICAgIC8vIENsaXBib2FyZCBFdmVudHNcclxuICAgIG9uQ29weTogJ2NvcHknLFxyXG4gICAgb25DdXQ6ICdjdXQnLFxyXG4gICAgb25QYXN0ZTogJ3Bhc3RlJyxcclxuXHJcbiAgICAvLyBDb21wb3NpdGlvbiBFdmVudHNcclxuICAgIG9uQ29tcG9zaXRpb25FbmQ6ICdjb21wb3NpdGlvbmVuZCcsXHJcbiAgICBvbkNvbXBvc2l0aW9uU3RhcnQ6ICdjb21wb3NpdGlvbnN0YXJ0JyxcclxuICAgIG9uQ29tcG9zaXRpb25VcGRhdGU6ICdjb21wb3NpdGlvbnVwZGF0ZScsXHJcblxyXG4gICAgLy8gRm9jdXMgRXZlbnRzXHJcbiAgICBvbkZvY3VzOiAnZm9jdXMnLFxyXG4gICAgb25CbHVyOiAnYmx1cicsXHJcblxyXG4gICAgLy8gRm9ybSBFdmVudHNcclxuICAgIG9uQ2hhbmdlOiAnY2hhbmdlJyxcclxuICAgIG9uQmVmb3JlSW5wdXQ6ICdiZWZvcmVpbnB1dCcsXHJcbiAgICBvbklucHV0OiAnaW5wdXQnLFxyXG4gICAgb25SZXNldDogJ3Jlc2V0JyxcclxuICAgIG9uU3VibWl0OiAnc3VibWl0JyxcclxuICAgIG9uSW52YWxpZDogJ2ludmFsaWQnLFxyXG5cclxuICAgIC8vIEltYWdlIEV2ZW50c1xyXG4gICAgb25Mb2FkOiAnbG9hZCcsXHJcbiAgICBvbkVycm9yOiAnZXJyb3InLFxyXG5cclxuICAgIC8vIEtleWJvYXJkIEV2ZW50c1xyXG4gICAgb25LZXlEb3duOiAna2V5ZG93bicsXHJcbiAgICBvbktleVByZXNzOiAna2V5cHJlc3MnLFxyXG4gICAgb25LZXlVcDogJ2tleXVwJyxcclxuXHJcbiAgICAvLyBNZWRpYSBFdmVudHNcclxuICAgIG9uQWJvcnQ6ICdhYm9ydCcsXHJcbiAgICBvbkNhblBsYXk6ICdjYW5wbGF5JyxcclxuICAgIG9uQ2FuUGxheVRocm91Z2g6ICdjYW5wbGF5dGhyb3VnaCcsXHJcbiAgICBvbkR1cmF0aW9uQ2hhbmdlOiAnZHVyYXRpb25jaGFuZ2UnLFxyXG4gICAgb25FbXB0aWVkOiAnZW1wdGllZCcsXHJcbiAgICBvbkVuY3J5cHRlZDogJ2VuY3J5cHRlZCcsXHJcbiAgICBvbkVuZGVkOiAnZW5kZWQnLFxyXG4gICAgb25Mb2FkZWREYXRhOiAnbG9hZGVkZGF0YScsXHJcbiAgICBvbkxvYWRlZE1ldGFkYXRhOiAnbG9hZGVkbWV0YWRhdGEnLFxyXG4gICAgb25Mb2FkU3RhcnQ6ICdsb2Fkc3RhcnQnLFxyXG4gICAgb25QYXVzZTogJ3BhdXNlJyxcclxuICAgIG9uUGxheTogJ3BsYXknLFxyXG4gICAgb25QbGF5aW5nOiAncGxheWluZycsXHJcbiAgICBvblByb2dyZXNzOiAncHJvZ3Jlc3MnLFxyXG4gICAgb25SYXRlQ2hhbmdlOiAncmF0ZWNoYW5nZScsXHJcbiAgICBvblNlZWtlZDogJ3NlZWtlZCcsXHJcbiAgICBvblNlZWtpbmc6ICdzZWVraW5nJyxcclxuICAgIG9uU3RhbGxlZDogJ3N0YWxsZWQnLFxyXG4gICAgb25TdXNwZW5kOiAnc3VzcGVuZCcsXHJcbiAgICBvblRpbWVVcGRhdGU6ICd0aW1ldXBkYXRlJyxcclxuICAgIG9uVm9sdW1lQ2hhbmdlOiAndm9sdW1lY2hhbmdlJyxcclxuICAgIG9uV2FpdGluZzogJ3dhaXRpbmcnLFxyXG5cclxuICAgIC8vIE1vdXNlRXZlbnRzXHJcbiAgICBvbkNsaWNrOiAnY2xpY2snLFxyXG4gICAgb25Db250ZXh0TWVudTogJ2NvbnRleHRtZW51JyxcclxuICAgIG9uRG91YmxlQ2xpY2s6ICdkb3VibGVjbGljaycsXHJcbiAgICBvbkRyYWc6ICdkcmFnJyxcclxuICAgIG9uRHJhZ0VuZDogJ2RyYWdlbmQnLFxyXG4gICAgb25EcmFnRW50ZXI6ICdkcmFnZW50ZXInLFxyXG4gICAgb25EcmFnRXhpdDogJ2RyYWdleGl0JyxcclxuICAgIG9uRHJhZ0xlYXZlOiAnZHJhZ2xlYXZlJyxcclxuICAgIG9uRHJhZ092ZXI6ICdkcmFnb3ZlcicsXHJcbiAgICBvbkRyYWdTdGFydDogJ2RyYWdzdGFydCcsXHJcbiAgICBvbkRyb3A6ICdkcm9wJyxcclxuICAgIG9uTW91c2VEb3duOiAnbW91c2Vkb3duJyxcclxuICAgIG9uTW91c2VFbnRlcjogJ21vdXNlZW50ZXInLFxyXG4gICAgb25Nb3VzZUxlYXZlOiAnbW91c2VsZWF2ZScsXHJcbiAgICBvbk1vdXNlTW92ZTogJ21vdXNlbW92ZScsXHJcbiAgICBvbk1vdXNlT3V0OiAnbW91c2VvdXQnLFxyXG4gICAgb25Nb3VzZU92ZXI6ICdtb3VzZW92ZXInLFxyXG4gICAgb25Nb3VzZVVwOiAnbW91c2V1cCcsXHJcblxyXG4gICAgLy8gU2VsZWN0aW9uIEV2ZW50c1xyXG4gICAgb25TZWxlY3Q6ICdzZWxlY3QnLFxyXG5cclxuICAgIC8vIFRvdWNoIEV2ZW50c1xyXG4gICAgb25Ub3VjaENhbmNlbDogJ3RvdWNoY2FuY2VsJyxcclxuICAgIG9uVG91Y2hFbmQ6ICd0b3VjaGVuZCcsXHJcbiAgICBvblRvdWNoTW92ZTogJ3RvdWNobW92ZScsXHJcbiAgICBvblRvdWNoU3RhcnQ6ICd0b3VjaHN0YXJ0JyxcclxuXHJcbiAgICAvLyBQb2ludGVyIEV2ZW50c1xyXG4gICAgb25Qb2ludGVyRG93bjogJ3BvaW50ZXJkb3duJyxcclxuICAgIG9uUG9pbnRlck1vdmU6ICdwb2ludGVybW92ZScsXHJcbiAgICBvblBvaW50ZXJVcDogJ3BvaW50ZXJ1cCcsXHJcbiAgICBvblBvaW50ZXJDYW5jZWw6ICdwb2ludGVyY2FuY2VsJyxcclxuICAgIG9uUG9pbnRlckVudGVyOiAncG9pbnRlcmVudGVyJyxcclxuICAgIG9uUG9pbnRlckxlYXZlOiAncG9pbnRlcmxlYXZlJyxcclxuICAgIG9uUG9pbnRlck92ZXI6ICdwb2ludGVyb3ZlcicsXHJcbiAgICBvblBvaW50ZXJPdXQ6ICdwb2ludGVyb3V0JyxcclxuXHJcbiAgICAvLyBVSSBFdmVudHNcclxuICAgIG9uU2Nyb2xsOiAnc2Nyb2xsJyxcclxuXHJcbiAgICAvLyBXaGVlbCBFdmVudHNcclxuICAgIG9uV2hlZWw6ICd3aGVlbCcsXHJcblxyXG4gICAgLy8gQW5pbWF0aW9uIEV2ZW50c1xyXG4gICAgb25BbmltYXRpb25TdGFydDogJ2FuaW1hdGlvbnN0YXJ0JyxcclxuICAgIG9uQW5pbWF0aW9uRW5kOiAnYW5pbWF0aW9uZW5kJyxcclxuICAgIG9uQW5pbWF0aW9uSXRlcmF0aW9uOiAnYW5pbWF0aW9uaXRlcmF0aW9uJyxcclxuXHJcbiAgICAvLyBUcmFuc2l0aW9uIEV2ZW50c1xyXG4gICAgb25UcmFuc2l0aW9uRW5kOiAndHJhbnNpdGlvbmVuZCcsXHJcbn07IiwiZnVuY3Rpb24gcXVlcnlTdHJpbmcocXVlcnkpIHtcclxuICAgIGlmICghcXVlcnkpIHtcclxuICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIHJldHVybiBxdWVyeVxyXG4gICAgICAgIC5zcGxpdCgnPycpWzFdXHJcbiAgICAgICAgLnNwbGl0KCcmJylcclxuICAgICAgICAubWFwKGEgPT4gYS5zcGxpdCgnPScpKVxyXG4gICAgICAgIC5yZWR1Y2UoKGEsIGMpID0+IHtcclxuICAgICAgICAgICAgYVtjWzBdXSA9IGNbMV07XHJcbiAgICAgICAgICAgIHJldHVybiBhO1xyXG4gICAgICAgIH0sIHt9KTtcclxufVxyXG5cclxuLyoqXHJcbiAqIENhbGN1bGF0ZSBudW1iZXIgb2YgZGF5cyBwYXNzaW5nIGJldHdlZW4gdHdvIGRhdGVzXHJcbiAqIEBwYXJhbSB7RGF0ZX0gYSBTdGFydGluZyBkYXRlXHJcbiAqIEBwYXJhbSB7RGF0ZX0gYiBFbmRpbmcgZGF0ZVxyXG4gKiBAcmV0dXJucyB7bnVtYmVyfSBOdW1iZXIgb2YgZGF5c1xyXG4gKi9cclxuZnVuY3Rpb24gZGF0ZURpZmYoYSwgYikge1xyXG4gICAgaWYgKGEuZ2V0RnVsbFllYXIoKSA9PSBiLmdldEZ1bGxZZWFyKCkgJiZcclxuICAgICAgICBhLmdldE1vbnRoKCkgPT0gYi5nZXRNb250aCgpICYmXHJcbiAgICAgICAgYS5nZXREYXRlKCkgPT0gYi5nZXREYXRlKCkpIHtcclxuICAgICAgICByZXR1cm4gMDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIChiIC0gYSkgPiAwID8gTWF0aC5jZWlsKChiIC0gYSkgLyA4NjQwMDAwMCkgOiBNYXRoLmZsb29yKChiIC0gYSkgLyA4NjQwMDAwMCk7XHJcbiAgICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGRhdGVEaWZmVG9EYXlzKGRheXMpIHtcclxuICAgIGlmIChkYXlzID09IDApIHtcclxuICAgICAgICByZXR1cm4gJ1RvZGF5JztcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgaWYgKGRheXMgPD0gMCkge1xyXG4gICAgICAgICAgICByZXR1cm4gYEluICR7LWRheXN9IGRheSR7ZGF5cyA9PSAtMSA/ICcnIDogJ3MnfWA7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIGAke2RheXN9IGRheSR7ZGF5cyA9PSAxID8gJycgOiAncyd9IGFnb2A7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG4vKipcclxuICogSXMgdGhlIGRhdGUgaW4gdGhlIGxhc3QgZGF5IG9mIGEgbW9udGhcclxuICogQHBhcmFtIHtEYXRlfSBkYXRlXHJcbiAqIEByZXR1cm5zIHtib29sZWFufVxyXG4gKi9cclxuZnVuY3Rpb24gaXNMYXN0RGF5KGRhdGUpIHtcclxuICAgIGNvbnN0IG5leHREYXkgPSBuZXcgRGF0ZShkYXRlKTtcclxuICAgIG5leHREYXkuc2V0RGF0ZShuZXh0RGF5LmdldERhdGUoKSArIDEpO1xyXG4gICAgcmV0dXJuIChkYXRlLmdldE1vbnRoKCkgIT0gbmV4dERheS5nZXRNb250aCgpKTtcclxufVxyXG5cclxuLyoqXHJcbiAqIElzIHRoZSBkYXRlIGluIHRoZSBsYXN0IHdlZWsgb2YgYSBtb250aFxyXG4gKiBAcGFyYW0ge0RhdGV9IGRhdGVcclxuICogQHJldHVybnMge2Jvb2xlYW59XHJcbiAqL1xyXG5mdW5jdGlvbiBpc0xhc3RXZWVrKGRhdGUpIHtcclxuICAgIGNvbnN0IG5leHRXZWVrID0gbmV3IERhdGUoZGF0ZSk7XHJcbiAgICBuZXh0V2Vlay5zZXREYXRlKG5leHRXZWVrLmdldERhdGUoKSArIDcpO1xyXG4gICAgcmV0dXJuIChkYXRlLmdldE1vbnRoKCkgIT0gbmV4dFdlZWsuZ2V0TW9udGgoKSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZvcm1hdERhdGUoZGF0ZSkge1xyXG4gICAgY29uc3QgYXNTdHJpbmcgPSBkYXRlLnRvTG9jYWxlRGF0ZVN0cmluZygnZW4tVVMnLCB7XHJcbiAgICAgICAgbW9udGg6ICdzaG9ydCcsXHJcbiAgICAgICAgeWVhcjogJ251bWVyaWMnXHJcbiAgICB9KTtcclxuICAgIHJldHVybiBgJHtkYXRlLmdldERhdGUoKX0gJHthc1N0cmluZ31gO1xyXG59XHJcblxyXG5mdW5jdGlvbiBmb3JtYXRUaW1lKGRhdGUpIHtcclxuICAgIHJldHVybiBkYXRlLnRvTG9jYWxlVGltZVN0cmluZygnZW4tVVMnLCB7XHJcbiAgICAgICAgaG91cjogJ251bWVyaWMnLFxyXG4gICAgICAgIG1pbnV0ZTogJ251bWVyaWMnLFxyXG4gICAgICAgIC8vIGhvdXIxMjogZmFsc2UsXHJcbiAgICAgICAgaG91ckN5Y2xlOiAnaDIzJ1xyXG4gICAgfSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZvcm1hdExvY2FsZURhdGUoZGF0ZSkge1xyXG4gICAgY29uc3QgZGF5ID0gZGF0ZS5nZXREYXRlKCk7XHJcbiAgICBjb25zdCBtb250aCA9IFtcclxuICAgICAgICAn0Y/QvdGD0LDRgNC4JyxcclxuICAgICAgICAn0YTQtdCy0YDRg9Cw0YDQuCcsXHJcbiAgICAgICAgJ9C80LDRgNGCJyxcclxuICAgICAgICAn0LDQv9GA0LjQuycsXHJcbiAgICAgICAgJ9C80LDQuScsXHJcbiAgICAgICAgJ9GO0L3QuCcsXHJcbiAgICAgICAgJ9GO0LvQuCcsXHJcbiAgICAgICAgJ9Cw0LLQs9GD0YHRgicsXHJcbiAgICAgICAgJ9GB0LXQv9GC0LXQvNCy0YDQuCcsXHJcbiAgICAgICAgJ9C+0LrRgtC+0LzQstGA0LgnLFxyXG4gICAgICAgICfQvdC+0LXQvNCy0YDQuCcsXHJcbiAgICAgICAgJ9C00LXQutC10LzQstGA0LgnXHJcbiAgICBdW2RhdGUuZ2V0TW9udGgoKV07XHJcbiAgICByZXR1cm4gYCR7ZGF5fSAke21vbnRofWA7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZvcm1hdExvY2FsZVdlZWtkYXkoZGF5LCBnZXRBZGopIHtcclxuICAgIGNvbnN0IHdlZWtkYXkgPSBbXHJcbiAgICAgICAgJ9C90LXQtNC10LvRjycsXHJcbiAgICAgICAgJ9C/0L7QvdC10LTQtdC70L3QuNC6JyxcclxuICAgICAgICAn0LLRgtC+0YDQvdC40LonLFxyXG4gICAgICAgICfRgdGA0Y/QtNCwJyxcclxuICAgICAgICAn0YfQtdGC0LLRitGA0YLRitC6JyxcclxuICAgICAgICAn0L/QtdGC0YrQuicsXHJcbiAgICAgICAgJ9GB0YrQsdC+0YLQsCcsXHJcbiAgICBdW2RheV07XHJcbiAgICBpZiAoZ2V0QWRqKSB7XHJcbiAgICAgICAgcmV0dXJuIFt3ZWVrZGF5LCBbXHJcbiAgICAgICAgICAgICfQstGB0Y/QutCwJyxcclxuICAgICAgICAgICAgJ9Cy0YHQtdC60LgnLFxyXG4gICAgICAgICAgICAn0LLRgdC10LrQuCcsXHJcbiAgICAgICAgICAgICfQstGB0Y/QutCwJyxcclxuICAgICAgICAgICAgJ9Cy0YHQtdC60LgnLFxyXG4gICAgICAgICAgICAn0LLRgdC10LrQuCcsXHJcbiAgICAgICAgICAgICfQstGB0Y/QutCwJyxcclxuICAgICAgICBdW2RheV1dO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHdlZWtkYXk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBHZXQgYSBuZXcgZGF0ZSBvZmZzZXQgYnkgdGhlIHNwZWNpZmllZCBudW1iZXIgb2YgZGF5c1xyXG4gKiBAcGFyYW0ge0RhdGV9IGRhdGUgQmFzZSBkYXRlXHJcbiAqIEBwYXJhbSB7bnVtYmVyfSBkYXlzIEhvdyBtYW55IGRheXMgdG8gb2Zmc2V0XHJcbiAqIEByZXR1cm5zIHtEYXRlfVxyXG4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIGdldE9mZnNldEJ5RGF5cyhkYXRlLCBkYXlzKSB7XHJcbiAgICBjb25zdCByZXN1bHQgPSBuZXcgRGF0ZShkYXRlKTtcclxuICAgIHJlc3VsdC5zZXRVVENEYXRlKHJlc3VsdC5nZXRVVENEYXRlKCkgKyBkYXlzKTtcclxuICAgIHJldHVybiByZXN1bHQ7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBPZmZzZXQgdGhlIGdpdmVuIGRhdGUgaW4gcGxhY2UgYnkgdGhlIHNwZWNpZmllZCBudW1iZXIgb2YgZGF5c1xyXG4gKiBAcGFyYW0ge0RhdGV9IGRhdGUgQmFzZSBkYXRlXHJcbiAqIEBwYXJhbSB7bnVtYmVyfSBkYXlzIEhvdyBtYW55IGRheXMgdG8gb2Zmc2V0XHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gb2Zmc2V0QnlEYXlzKGRhdGUsIGRheXMpIHtcclxuICAgIGRhdGUuc2V0VVRDRGF0ZShkYXRlLmdldFVUQ0RhdGUoKSArIGRheXMpO1xyXG59XHJcblxyXG4vKipcclxuICogQ3JlYXRlIGRhdGUgaW5kZXggYXMgc3RyaW5nXHJcbiAqIEBwYXJhbSB7RGF0ZXxzdHJpbmd9IGRhdGUgQmFzZSBkYXRlXHJcbiAqIEByZXR1cm5zIHtzdHJpbmd9XHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGF0ZUluZGV4KGRhdGUpIHtcclxuICAgIGlmICh0eXBlb2YgZGF0ZSA9PSAnc3RyaW5nJykge1xyXG4gICAgICAgIGRhdGUgPSBuZXcgRGF0ZShkYXRlKTtcclxuICAgIH1cclxuICAgIHJldHVybiBkYXRlLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBwcmV0dHlKU09OKG9iaikge1xyXG4gICAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KG9iaiwgbnVsbCwgMikucmVwbGFjZSgvIC9nbWksICcmbmJzcDsnKS5yZXBsYWNlKC9cXG4vZ21pLCAnPGJyPicpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRNb25kYXkoZGF0ZSkge1xyXG4gICAgY29uc3QgbW9uZGF5ID0gbmV3IERhdGUoYCR7ZGF0ZS5nZXRGdWxsWWVhcigpfS0ke2RhdGUuZ2V0TW9udGgoKSArIDF9LSR7ZGF0ZS5nZXREYXRlKCl9IDEyOjAwOjAwYCk7XHJcbiAgICBtb25kYXkuc2V0RGF0ZShtb25kYXkuZ2V0RGF0ZSgpIC0gKChtb25kYXkuZ2V0RGF5KCkgKyA2KSAlIDcpKTtcclxuICAgIHJldHVybiBtb25kYXk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGdldFN1bmRheShkYXRlKSB7XHJcbiAgICBjb25zdCBzdW5kYXkgPSBuZXcgRGF0ZShgJHtkYXRlLmdldEZ1bGxZZWFyKCl9LSR7ZGF0ZS5nZXRNb250aCgpICsgMX0tJHtkYXRlLmdldERhdGUoKX0gMjM6NTk6NTlgKTtcclxuICAgIHN1bmRheS5zZXREYXRlKHN1bmRheS5nZXREYXRlKCkgKyAoKDcgLSBzdW5kYXkuZ2V0RGF5KCkpICUgNykpO1xyXG4gICAgcmV0dXJuIHN1bmRheTtcclxufVxyXG5cclxuY29uc3QgbW9udGhOYW1lID0ge1xyXG4gICAgMTogJ0phbnVhcnknLFxyXG4gICAgMjogJ0ZlYnJ1YXJ5JyxcclxuICAgIDM6ICdNYXJjaCcsXHJcbiAgICA0OiAnQXByaWwnLFxyXG4gICAgNTogJ01heScsXHJcbiAgICA2OiAnSnVuZScsXHJcbiAgICA3OiAnSnVseScsXHJcbiAgICA4OiAnQXVndXN0JyxcclxuICAgIDk6ICdTZXB0ZW1iZXInLFxyXG4gICAgMTA6ICdPY3RvYmVyJyxcclxuICAgIDExOiAnTm92ZW1iZXInLFxyXG4gICAgMTI6ICdEZWNlbWJlcicsXHJcbn07XHJcblxyXG5cclxuY29uc3QgbG9jYWxlTW9udGhOYW1lID0ge1xyXG4gICAgMTogJ9GP0L3Rg9Cw0YDQuCcsXHJcbiAgICAyOiAn0YTQtdCy0YDRg9Cw0YDQuCcsXHJcbiAgICAzOiAn0LzQsNGA0YInLFxyXG4gICAgNDogJ9Cw0L/RgNC40LsnLFxyXG4gICAgNTogJ9C80LDQuScsXHJcbiAgICA2OiAn0Y7QvdC4JyxcclxuICAgIDc6ICfRjtC70LgnLFxyXG4gICAgODogJ9Cw0LLQs9GD0YHRgicsXHJcbiAgICA5OiAn0YHQtdC/0YLQtdC80LLRgNC4JyxcclxuICAgIDEwOiAn0L7QutGC0L7QvNCy0YDQuCcsXHJcbiAgICAxMTogJ9C90L7QtdC80LLRgNC4JyxcclxuICAgIDEyOiAn0LTQtdC60LXQvNCy0YDQuCcsXHJcbn07XHJcblxyXG5mdW5jdGlvbiB0b0Fzc29jQXJyYXkocCwgYywgaSwgYSkge1xyXG4gICAgcFtjLklkXSA9IGM7XHJcbiAgICByZXR1cm4gcDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHRvQ3VzdG9tQXNzb2NBcnJheShpbmRleE5hbWUsIG92ZXJ3cml0ZSA9IGZhbHNlKSB7XHJcbiAgICByZXR1cm4gKHAsIGMsIGksIGEpID0+IHtcclxuICAgICAgICBpZiAocFtjW2luZGV4TmFtZV1dICE9PSB1bmRlZmluZWQgJiYgb3ZlcndyaXRlID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KHBbY1tpbmRleE5hbWVdXSkpIHtcclxuICAgICAgICAgICAgICAgIHBbY1tpbmRleE5hbWVdXS5wdXNoKGMpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcFtjW2luZGV4TmFtZV1dID0gW3BbY1tpbmRleE5hbWVdXSwgY107XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBwW2NbaW5kZXhOYW1lXV0gPSBjO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gcDtcclxuICAgIH07XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBAcGFyYW0ge0FycmF5PFNVUGF5bWVudD59IGRhdGEgXHJcbiAqIEByZXR1cm5zIHtBcnJheTxQYXltZW50Vmlld01vZGVsPn1cclxuICovXHJcbmZ1bmN0aW9uIHBheW1lbnRzVG9NYXRyaXgoZGF0YSkge1xyXG4gICAgY29uc3QgdGVtcGxhdGUgPSBbXHJcbiAgICAgICAgJ0lkJyxcclxuICAgICAgICAnUGF5bWVudE51bWJlcicsXHJcbiAgICAgICAgJ01vZHVsZU5hbWVFbicsXHJcbiAgICAgICAgJ1BheW1lbnRQYWNrYWdlc0FzU3RyaW5nJyxcclxuICAgICAgICAnUGFpZEZvclVzZXJOYW1lJyxcclxuICAgICAgICAnUHJpY2UnLFxyXG4gICAgICAgICdFZHVjYXRpb25hbEZvcm0nLFxyXG4gICAgICAgICdQYXltZW50RGF0ZVRpbWUnXHJcbiAgICBdO1xyXG4gICAgY29uc3QgcGFyc2VkID0gZGF0YS5tYXAoZSA9PiB7XHJcbiAgICAgICAgZS5FZHVjYXRpb25hbEZvcm0gPSBlLkVkdWNhdGlvbmFsRm9ybSA9PSAxID8gJ29ubGluZScgOiAnb25zaXRlJztcclxuICAgICAgICBjb25zdCBlbnRyeSA9IFtdO1xyXG4gICAgICAgIGZvciAobGV0IHByb3Agb2YgdGVtcGxhdGUpIHtcclxuICAgICAgICAgICAgaWYgKHByb3AgPT09ICdQYXltZW50RGF0ZVRpbWUnKSB7XHJcbiAgICAgICAgICAgICAgICBlbnRyeS5wdXNoKG5ldyBEYXRlKGVbcHJvcF0pKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGVudHJ5LnB1c2goZVtwcm9wXSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGVudHJ5O1xyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIFt0ZW1wbGF0ZSwgLi4ucGFyc2VkXTtcclxufVxyXG5cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiB1dWlkKCkge1xyXG4gICAgcmV0dXJuICd4eHh4eHh4eC14eHh4LTR4eHgteXh4eC14eHh4eHh4eHh4eHgnLnJlcGxhY2UoL1t4eV0vZywgZnVuY3Rpb24gKGMpIHtcclxuICAgICAgICBsZXQgciA9IE1hdGgucmFuZG9tKCkgKiAxNiB8IDAsXHJcbiAgICAgICAgICAgIHYgPSBjID09ICd4JyA/IHIgOiAociAmIDB4MyB8IDB4OCk7XHJcbiAgICAgICAgcmV0dXJuIHYudG9TdHJpbmcoMTYpO1xyXG4gICAgfSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBub3JtYWxpemVEYXRlVGltZShkYXRldGltZSkge1xyXG4gICAgaWYgKCFkYXRldGltZSkge1xyXG4gICAgICAgIHJldHVybiAnJztcclxuICAgIH0gZWxzZSBpZiAoZGF0ZXRpbWUudG9TdHJpbmcoKS5pbmNsdWRlcygnRGF0ZSgnKSkge1xyXG4gICAgICAgIGNvbnN0IG1hdGNoID0gL0RhdGVcXCgoLispXFwpLy5leGVjKGRhdGV0aW1lKTtcclxuICAgICAgICBpZiAobWF0Y2ggIT09IG51bGwpIHtcclxuICAgICAgICAgICAgY29uc3QgZCA9IG5ldyBEYXRlKE51bWJlcihtYXRjaFsxXSkpO1xyXG4gICAgICAgICAgICByZXR1cm4gYCR7KCcwMDAwJyArIGQuZ2V0RnVsbFllYXIoKSkuc2xpY2UoLTQpfS0ke3B0KGQuZ2V0TW9udGgoKSArIDEpfS0ke3B0KGQuZ2V0RGF0ZSgpKX1UJHtwdChkLmdldEhvdXJzKCkpfToke3B0KGQuZ2V0TWludXRlcygpKX1gO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiBkYXRldGltZTtcclxuICAgICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJldHVybiBkYXRldGltZTtcclxuICAgIH1cclxufVxyXG5cclxuZnVuY3Rpb24gcHQocykge1xyXG4gICAgcmV0dXJuIGAwJHtzfWAuc2xpY2UoLTIpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBodG1sVG9UZXh0KGh0bWwpIHtcclxuICAgIGNvbnN0IGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgZGl2LmlubmVySFRNTCA9IGh0bWw7XHJcblxyXG4gICAgcmV0dXJuIGRpdi50ZXh0Q29udGVudDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGluc3RhbmNlTWV0YUZyb21IcmVmKGhyZWYpIHtcclxuICAgIGNvbnN0IGluc3RhbmNlTWV0YSA9IHF1ZXJ5U3RyaW5nKGhyZWYpO1xyXG4gICAgaW5zdGFuY2VNZXRhLkluc3RhbmNlUmVmVHlwZSA9ICgoKSA9PiB7XHJcbiAgICAgICAgc3dpdGNoIChpbnN0YW5jZU1ldGEudHlwZSkge1xyXG4gICAgICAgICAgICBjYXNlICdjb3Vyc2UnOiByZXR1cm4gJ21haW4nO1xyXG4gICAgICAgICAgICBjYXNlICdmYXN0LXRyYWNrJzogcmV0dXJuICdvcGVuJztcclxuICAgICAgICAgICAgY2FzZSAnZ2VuZXJhbC1jb3Vyc2UtaW5zdGFuY2UnOiByZXR1cm4gJ2dlbmVyYWwnO1xyXG4gICAgICAgIH1cclxuICAgIH0pKCk7XHJcblxyXG4gICAgcmV0dXJuIGluc3RhbmNlTWV0YTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGhhc1ZhbHVlKHZhbHVlKSB7XHJcbiAgICByZXR1cm4gKHZhbHVlICE9PSBudWxsICYmIHZhbHVlICE9PSB1bmRlZmluZWQgJiYgdmFsdWUgIT09ICcnKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHZhbHVlT3JFbXB0eSh2YWx1ZSwgYWx0ID0gJycpIHtcclxuICAgIGlmICh2YWx1ZSA9PT0gbnVsbCB8fCB2YWx1ZSA9PT0gdW5kZWZpbmVkIHx8IHZhbHVlID09PSAnJykge1xyXG4gICAgICAgIHJldHVybiBhbHQ7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJldHVybiB2YWx1ZTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHN1bUFycmF5TWF4KGFycikge1xyXG4gICAgaWYgKGFyclswXS5sZW5ndGggPT0gMCAmJiBhcnJbMV0ubGVuZ3RoID09IDApIHtcclxuICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuXHJcbiAgICBsZXQgcmVzdWx0ID0gMDtcclxuXHJcbiAgICBpZiAoYXJyWzBdLmxlbmd0aCA+IDApIHtcclxuICAgICAgICByZXN1bHQgKz0gTWF0aC5tYXgoLi4uYXJyWzBdKTtcclxuICAgIH1cclxuICAgIGlmIChhcnJbMV0ubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIHJlc3VsdCArPSBNYXRoLm1heCguLi5hcnJbMV0pO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiByZXN1bHQ7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IHtcclxuICAgIHF1ZXJ5U3RyaW5nLFxyXG4gICAgZGF0ZURpZmYsXHJcbiAgICBkYXRlRGlmZlRvRGF5cyxcclxuICAgIGlzTGFzdERheSxcclxuICAgIGlzTGFzdFdlZWssXHJcbiAgICBmb3JtYXREYXRlLFxyXG4gICAgZm9ybWF0VGltZSxcclxuICAgIGZvcm1hdExvY2FsZURhdGUsXHJcbiAgICBmb3JtYXRMb2NhbGVXZWVrZGF5LFxyXG4gICAgcHJldHR5SlNPTixcclxuICAgIGdldE1vbmRheSxcclxuICAgIGdldFN1bmRheSxcclxuICAgIG1vbnRoTmFtZSxcclxuICAgIGxvY2FsZU1vbnRoTmFtZSxcclxuICAgIHRvQXNzb2NBcnJheSxcclxuICAgIHBheW1lbnRzVG9NYXRyaXgsXHJcbiAgICBodG1sVG9UZXh0XHJcbn07XHJcblxyXG5cclxuZXhwb3J0IHtcclxuICAgIHF1ZXJ5U3RyaW5nLFxyXG4gICAgZGF0ZURpZmYsXHJcbiAgICBkYXRlRGlmZlRvRGF5cyxcclxuICAgIGlzTGFzdERheSxcclxuICAgIGlzTGFzdFdlZWssXHJcbiAgICBmb3JtYXREYXRlLFxyXG4gICAgZm9ybWF0VGltZSxcclxuICAgIGZvcm1hdExvY2FsZURhdGUsXHJcbiAgICBmb3JtYXRMb2NhbGVXZWVrZGF5LFxyXG4gICAgcHJldHR5SlNPTixcclxuICAgIGdldE1vbmRheSxcclxuICAgIGdldFN1bmRheSxcclxuICAgIG1vbnRoTmFtZSxcclxuICAgIGxvY2FsZU1vbnRoTmFtZSxcclxuICAgIHRvQXNzb2NBcnJheSxcclxuICAgIHBheW1lbnRzVG9NYXRyaXgsXHJcbiAgICBodG1sVG9UZXh0XHJcbn07IiwiaW1wb3J0IHsgdXVpZCB9IGZyb20gJy4vcGFyc2UnO1xyXG5pbXBvcnQgZG9tLCB7IEZyYWdtZW50IH0gZnJvbSAnLi4vdXRpbC9qc3gtcmVuZGVyLW1vZC9kb20nO1xyXG5cclxuLyoqXHJcbiAqIFxyXG4gKiBAcGFyYW0geyp9IHR5cGUgXHJcbiAqIEBwYXJhbSB7Kn0gY29udGVudCBcclxuICogQHBhcmFtIHsqfSBhdHRyaWJ1dGVzIFxyXG4gKiBAcGFyYW0ge3tmb3JjZVR5cGU6ICdUZXh0JyB8ICdIVE1MJ319IG9wdGlvbnMgXHJcbiAqIEByZXR1cm5zIFxyXG4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIGVsZW1lbnQodHlwZSwgY29udGVudCwgYXR0cmlidXRlcywgb3B0aW9ucyA9IHVuZGVmaW5lZCkge1xyXG4gICAgY29uc3QgcmVzdWx0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCh0eXBlKTtcclxuXHJcbiAgICBpZiAoYXR0cmlidXRlcykge1xyXG4gICAgICAgIGZvciAobGV0IGF0dHIgb2YgT2JqZWN0LmtleXMoYXR0cmlidXRlcykpIHtcclxuICAgICAgICAgICAgcmVzdWx0W2F0dHJdID0gYXR0cmlidXRlc1thdHRyXTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcmVzdWx0LmFwcGVuZCA9IGFwcGVuZC5iaW5kKHJlc3VsdCk7XHJcblxyXG4gICAgcmVzdWx0LmFwcGVuZFRvID0gKHBhcmVudCkgPT4ge1xyXG4gICAgICAgIHBhcmVudC5hcHBlbmQocmVzdWx0KTtcclxuICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgfTtcclxuXHJcbiAgICBpZiAoY29udGVudCAhPT0gdW5kZWZpbmVkICYmIGNvbnRlbnQgIT09IG51bGwpIHtcclxuICAgICAgICByZXN1bHQuYXBwZW5kKGNvbnRlbnQsIG9wdGlvbnMpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxufVxyXG5cclxuZnVuY3Rpb24gYXBwZW5kKGNoaWxkLCBvcHRpb25zID0gdW5kZWZpbmVkKSB7XHJcbiAgICBpZiAodHlwZW9mIChjaGlsZCkgPT09ICdzdHJpbmcnIHx8IHR5cGVvZiAoY2hpbGQpID09PSAnbnVtYmVyJykge1xyXG4gICAgICAgIGlmIChvcHRpb25zPy5mb3JjZVR5cGUgIT0gJ1RleHQnICYmIChvcHRpb25zPy5mb3JjZVR5cGUgPT09ICdIVE1MJyB8fCBjaGlsZC50b1N0cmluZygpLnRyaW0oKVswXSA9PT0gJzwnKSkge1xyXG4gICAgICAgICAgICB0aGlzLmlubmVySFRNTCA9IGNoaWxkO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGNoaWxkID0gZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUoY2hpbGQpO1xyXG4gICAgICAgICAgICB0aGlzLmFwcGVuZENoaWxkKGNoaWxkKTtcclxuICAgICAgICB9XHJcbiAgICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkoY2hpbGQpKSB7XHJcbiAgICAgICAgZm9yIChsZXQgbm9kZSBvZiBjaGlsZCkge1xyXG4gICAgICAgICAgICBhcHBlbmQuY2FsbCh0aGlzLCBub2RlKTtcclxuICAgICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIHRoaXMuYXBwZW5kQ2hpbGQoY2hpbGQpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRoaXM7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiByZXBsYWNlQ29udGVudHMobm9kZSwgbmV3Q29udGVudHMpIHtcclxuICAgIGNvbnN0IGNOb2RlID0gbm9kZS5jbG9uZU5vZGUoZmFsc2UpO1xyXG4gICAgYXBwZW5kLmNhbGwoY05vZGUsIG5ld0NvbnRlbnRzKTtcclxuICAgIHRyeSB7XHJcbiAgICAgICAgbm9kZS5wYXJlbnROb2RlLnJlcGxhY2VDaGlsZChjTm9kZSwgbm9kZSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmluZm8oJ05vZGUgaGFzIG5vIHBhcmVudCBvciBhbm90aGVyIHByb2JsZW0gb2NjdXJlZCcpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBjTm9kZTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHN3YXAob2xkTm9kZSwgbmV3Tm9kZSkge1xyXG4gICAgb2xkTm9kZS5wYXJlbnROb2RlLnJlcGxhY2VDaGlsZChuZXdOb2RlLCBvbGROb2RlKTtcclxuICAgIHJldHVybiBuZXdOb2RlO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU3Bpbm5lcih7IGlkIH0pIHtcclxuICAgIGNvbnN0IG5vZGUgPSBlbGVtZW50KCdkaXYnLCBbXHJcbiAgICAgICAgZWxlbWVudCgnZGl2JywgbnVsbCwgeyBjbGFzc0xpc3Q6ICdzay1jdWJlIHNrLWN1YmUxJyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3NrLWN1YmUgc2stY3ViZTInIH0pLFxyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAnc2stY3ViZSBzay1jdWJlMycgfSksXHJcbiAgICAgICAgZWxlbWVudCgnZGl2JywgbnVsbCwgeyBjbGFzc0xpc3Q6ICdzay1jdWJlIHNrLWN1YmU0JyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3NrLWN1YmUgc2stY3ViZTUnIH0pLFxyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAnc2stY3ViZSBzay1jdWJlNicgfSksXHJcbiAgICAgICAgZWxlbWVudCgnZGl2JywgbnVsbCwgeyBjbGFzc0xpc3Q6ICdzay1jdWJlIHNrLWN1YmU3JyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3NrLWN1YmUgc2stY3ViZTgnIH0pLFxyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAnc2stY3ViZSBzay1jdWJlOScgfSksXHJcbiAgICBdLCB7IGNsYXNzTGlzdDogJ3NrLWN1YmUtZ3JpZCcgfSk7XHJcbiAgICBpZiAoaWQpIHtcclxuICAgICAgICBub2RlLnNldEF0dHJpYnV0ZSgnaWQnLCBpZCk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIG5vZGU7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBMb2FkaW5nKHsgaWQsIGNvbG9yID0gJ3doaXRlJyB9KSB7XHJcbiAgICBjb25zdCBub2RlID0gZWxlbWVudCgnZGl2JywgW1xyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAncmVjdDEnIH0pLFxyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAncmVjdDInIH0pLFxyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAncmVjdDMnIH0pLFxyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAncmVjdDQnIH0pLFxyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAncmVjdDUnIH0pLFxyXG4gICAgXSwgeyBjbGFzc0xpc3Q6IGdldENsYXNzKCkgfSk7XHJcbiAgICBpZiAoaWQpIHtcclxuICAgICAgICBub2RlLnNldEF0dHJpYnV0ZSgnaWQnLCBpZCk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIG5vZGU7XHJcblxyXG5cclxuICAgIGZ1bmN0aW9uIGdldENsYXNzKCkge1xyXG4gICAgICAgIHJldHVybiBgc3Bpbm5lciAke2NvbG9yfWA7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBSZW1vdGUoeyBzcmMsIHBhcnNlLCBjb21wb25lbnQsIGNvbG9yID0gJ3doaXRlJywgb25SZWFkeSwgb25FcnJvciB9KSB7XHJcbiAgICBjb25zdCBpZCA9IHV1aWQoKTtcclxuICAgIHJlc29sdmUoKTtcclxuXHJcbiAgICBjb25zdCBsb2FkZXIgPSBMb2FkaW5nKHsgaWQsIGNvbG9yIH0pO1xyXG5cclxuICAgIHJldHVybiBsb2FkZXI7XHJcblxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHJlc29sdmUoKSB7XHJcbiAgICAgICAgbGV0IGRhdGEgPSBhd2FpdCAoYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGF3YWl0IChzcmMgaW5zdGFuY2VvZiBQcm9taXNlKSA/IHNyYyA6IHNyYygpO1xyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAob25FcnJvcikge1xyXG4gICAgICAgICAgICAgICAgICAgIG9uRXJyb3IoZSwgbG9hZGVyKTtcclxuICAgICAgICAgICAgICAgICAgICB0aHJvdyBlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY29uc3QgcmV0cnlCdG4gPSBlbGVtZW50KCdidXR0b24nLCBbXHJcbiAgICAgICAgICAgICAgICAgICAgZWxlbWVudCgnaScsIG51bGwsIHsgY2xhc3NOYW1lOiAnZ2x5cGhpY29uIGdseXBoaWNvbi1yZXBlYXQnIH0pLFxyXG4gICAgICAgICAgICAgICAgICAgICdSZXRyeSdcclxuICAgICAgICAgICAgICAgIF0sIHsgc3R5bGU6ICdiYWNrZ3JvdW5kLWNvbG9yOiBncmVlbicgfSk7XHJcbiAgICAgICAgICAgICAgICByZXRyeUJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICByZXBsYWNlU2VsZihSZW1vdGUoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzcmMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhcnNlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb21wb25lbnQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yXHJcbiAgICAgICAgICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZWxlbWVudCgnZGl2JywgW1xyXG4gICAgICAgICAgICAgICAgICAgIGVsZW1lbnQoJ2knLCBudWxsLCB7IGNsYXNzTmFtZTogJ2dseXBoaWNvbiBnbHlwaGljb24tcmVtb3ZlJywgc3R5bGU6ICdjb2xvcjogcmVkJyB9KSxcclxuICAgICAgICAgICAgICAgICAgICBlLm1lc3NhZ2UsXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0cnlCdG5cclxuICAgICAgICAgICAgICAgIF0sIHsgaWQ6IGlkIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSkoKTtcclxuXHJcbiAgICAgICAgaWYgKHBhcnNlKSB7XHJcbiAgICAgICAgICAgIGRhdGEgPSBwYXJzZShkYXRhKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJlcGxhY2VTZWxmKGRhdGEpO1xyXG5cclxuICAgICAgICBmdW5jdGlvbiByZXBsYWNlU2VsZihkYXRhKSB7XHJcbiAgICAgICAgICAgIC8vY29uc3QgbG9hZGVyID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaWQpO1xyXG4gICAgICAgICAgICBjb25zdCBwYXJlbnQgPSBsb2FkZXIucGFyZW50Tm9kZTtcclxuXHJcbiAgICAgICAgICAgIGlmIChjb21wb25lbnQpIHtcclxuICAgICAgICAgICAgICAgIHBhcmVudC5pbnNlcnRCZWZvcmUoY29tcG9uZW50KGRhdGEpLCBsb2FkZXIpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgYXBwZW5kKGRhdGEpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vYXdhaXQgbmV3IFByb21pc2UocmVzb2x2ZSA9PiBzZXRUaW1lb3V0KDEwLCByZXNvbHZlKSk7XHJcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaWQpKTtcclxuICAgICAgICAgICAgbG9hZGVyLnJlbW92ZSgpO1xyXG4gICAgICAgICAgICBpZiAob25SZWFkeSkge1xyXG4gICAgICAgICAgICAgICAgb25SZWFkeSgpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBmdW5jdGlvbiBhcHBlbmQoY2hpbGQpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgKGNoaWxkKSA9PT0gJ3N0cmluZycgfHwgdHlwZW9mIChjaGlsZCkgPT09ICdudW1iZXInKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNoaWxkLnRvU3RyaW5nKCkudHJpbSgpWzBdID09PSAnPCcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZnJhZ21lbnQgPSBlbGVtZW50KCdkaXYnLCBjaGlsZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZyYWdtZW50LmNoaWxkTm9kZXMuZm9yRWFjaChuID0+IHBhcmVudC5pbnNlcnRCZWZvcmUobi5jbG9uZU5vZGUodHJ1ZSksIGxvYWRlcikpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhcmVudC5pbnNlcnRCZWZvcmUoZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUoY2hpbGQpLCBsb2FkZXIpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheShjaGlsZCkpIHtcclxuICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBub2RlIG9mIGNoaWxkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFwcGVuZChub2RlKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHBhcmVudC5pbnNlcnRCZWZvcmUoY2hpbGQsIGxvYWRlcik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBZZXMoKSB7XHJcbiAgICBjb25zdCBlbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2knKTtcclxuICAgIGVsLmNsYXNzTmFtZSA9ICdnbHlwaGljb24gZ2x5cGhpY29uLW9rJztcclxuICAgIGVsLnN0eWxlLmNvbG9yID0gJ2dyZWVuJztcclxuICAgIHJldHVybiBlbDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIE5vKCkge1xyXG4gICAgY29uc3QgZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdpJyk7XHJcbiAgICBlbC5jbGFzc05hbWUgPSAnZ2x5cGhpY29uIGdseXBoaWNvbi1yZW1vdmUnO1xyXG4gICAgZWwuc3R5bGUuY29sb3IgPSAncmVkJztcclxuICAgIHJldHVybiBlbDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFF1ZXN0aW9uKFt0aXRsZSwgYW5zd2Vyc10pIHtcclxuICAgIHJldHVybiBlbGVtZW50KCdkaXYnLCBbXHJcbiAgICAgICAgZWxlbWVudCgnaDInLCB0aXRsZSksXHJcbiAgICAgICAgZWxlbWVudCgndWwnLCBPYmplY3QuZW50cmllcyhhbnN3ZXJzKS5tYXAoKFthLCBpc0NvcnJlY3RdKSA9PiBlbGVtZW50KCdsaScsIGEsIHsgY2xhc3NMaXN0OiBpc0NvcnJlY3QgPyAnY29ycmVjdC1hbnN3ZXInIDogJ25vbmUnIH0sIHRydWUpKSlcclxuICAgIF0sIHsgY2xhc3NMaXN0OiAncXVlc3Rpb24tY29udGFpbmVyJyB9KTtcclxufTtcclxuXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQWxlcnQoKSB7XHJcbiAgICBjb25zdCBlbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2knKTtcclxuICAgIGVsLmNsYXNzTmFtZSA9ICdnbHlwaGljb24gZ2x5cGhpY29uLXdhcm5pbmctc2lnbic7XHJcbiAgICBlbC5zdHlsZS5jb2xvciA9ICdvcmFuZ2UnO1xyXG4gICAgcmV0dXJuIGVsO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQ29udGFpbmVyKHsgY2hpbGRyZW4sIGNsYXNzTmFtZSB9KSB7XHJcbiAgICBjb25zdCBzZWN0aW9uID0gZWxlbWVudCgnc2VjdGlvbicsIGNoaWxkcmVuLCB7XHJcbiAgICAgICAgY2xhc3NOYW1lOiBjbGFzc05hbWUgPyAnZXZlbnQtY29udGFpbmVyJyA6ICdjb250YWluZXInXHJcbiAgICB9KTtcclxuICAgIGNvbnN0IGVsID0gZWxlbWVudCgnZGl2Jywgc2VjdGlvbiwge1xyXG4gICAgICAgIGNsYXNzTmFtZTogY2xhc3NOYW1lID8gY2xhc3NOYW1lIDogJ2NvbnRhaW5lciBhZG1pbmlzdHJhdGlvbi1jb250YWluZXIgc2VzLWNvbnRhaW5lcidcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIGVsO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gcG9wdXBUYWJsZShkYXRhKSB7XHJcbiAgICBsZXQgaHRtbCA9IGBcclxuICAgICAgICA8c3R5bGU+XHJcbiAgICAgICAgICAgIHRhYmxlIHtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdHIsIHRkLCB0aCB7XHJcbiAgICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCBibGFjaztcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDAuMjVlbSAwLjVlbTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIDwvc3R5bGU+XHJcbiAgICAgICAgYDtcclxuICAgIGh0bWwgKz0gJzx0YWJsZT48dGhlYWQ+PHRyPic7XHJcbiAgICBmb3IgKGxldCBjb2wgb2YgZGF0YVswXSkge1xyXG4gICAgICAgIGh0bWwgKz0gYDx0aD4ke2NvbH08L3RoPmA7XHJcbiAgICB9XHJcbiAgICBodG1sICs9ICc8L3RyPjwvdGhlYWQ+PHRib2R5Pic7XHJcbiAgICBmb3IgKGxldCByb3cgPSAxOyByb3cgPCBkYXRhLmxlbmd0aDsgcm93KyspIHtcclxuICAgICAgICBodG1sICs9ICc8dHI+JztcclxuICAgICAgICBmb3IgKGxldCBjb2wgb2YgZGF0YVtyb3ddKSB7XHJcbiAgICAgICAgICAgIGh0bWwgKz0gYDx0ZD4ke2NvbH08L3RkPmA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGh0bWwgKz0gJzwvdHI+JztcclxuICAgIH1cclxuICAgIGh0bWwgKz0gJzwvdGJvZHk+PC90YWJsZT4nO1xyXG4gICAgcmV0dXJuIGh0bWw7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRFZGl0b3JEZWNvcmF0aW9uKGVsZW1lbnQpIHtcclxuICAgIGZ1bmN0aW9uIGVuYWJsZSgpIHtcclxuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5hZGQoJ2VuYWJsZWQnKTtcclxuICAgIH1cclxuICAgIGZ1bmN0aW9uIGRpc2FibGUoKSB7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdlbmFibGVkJyk7XHJcbiAgICB9XHJcbiAgICBmdW5jdGlvbiB3b3JraW5nKCkge1xyXG4gICAgICAgIGVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnZW5hYmxlZCcpO1xyXG4gICAgICAgIGVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnd29ya2luZycpO1xyXG4gICAgfVxyXG4gICAgZnVuY3Rpb24gdXBkYXRlZCgpIHtcclxuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ3dvcmtpbmcnKTtcclxuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5hZGQoJ3VwZGF0ZWQnKTtcclxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IGVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgndXBkYXRlZCcpLCAzMDAwKTtcclxuICAgIH1cclxuICAgIGZ1bmN0aW9uIGZhaWx1cmUoKSB7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCd3b3JraW5nJyk7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QuYWRkKCdmYWlsZWQnKTtcclxuICAgIH1cclxuICAgIGZ1bmN0aW9uIF9jbGVhcigpIHtcclxuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ2VuYWJsZWQnKTtcclxuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ3dvcmtpbmcnKTtcclxuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ3VwZGF0ZWQnKTtcclxuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ2ZhaWxlZCcpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgZW5hYmxlLFxyXG4gICAgICAgIGRpc2FibGUsXHJcbiAgICAgICAgd29ya2luZyxcclxuICAgICAgICB1cGRhdGVkLFxyXG4gICAgICAgIGZhaWx1cmUsXHJcbiAgICAgICAgX2NsZWFyXHJcbiAgICB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gYXBwbHlCZWdpblJlcXVlc3QoZWxlbWVudCkge1xyXG4gICAgZWxlbWVudC5jaGlsZE5vZGVzLmZvckVhY2goYyA9PiBjLmNoaWxkTm9kZXMuZm9yRWFjaChuID0+IG4uZGlzYWJsZWQgPSB0cnVlKSk7XHJcbiAgICBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ2VuYWJsZWQnKTtcclxuICAgIGVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnZmFpbGVkJyk7XHJcbiAgICBlbGVtZW50LmNsYXNzTGlzdC5hZGQoJ3dvcmtpbmcnKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGFwcGx5UmVxdWVzdFN1Y2Nlc3MoZWxlbWVudCkge1xyXG4gICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCd3b3JraW5nJyk7XHJcbiAgICBlbGVtZW50LmNsYXNzTGlzdC5hZGQoJ3VwZGF0ZWQnKTtcclxuICAgIHNldFRpbWVvdXQoKCkgPT4gZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCd1cGRhdGVkJyksIDMwMDApO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gYXBwbHlSZXF1ZXN0RXJyb3IocmVmRWxlbWVudCwgZXJyb3JDb250YWluZXIsIGZpZWxkcykge1xyXG4gICAgcmVmRWxlbWVudC5jaGlsZE5vZGVzLmZvckVhY2goYyA9PiBjLmNoaWxkTm9kZXMuZm9yRWFjaChuID0+IG4uZGlzYWJsZWQgPSBmYWxzZSkpO1xyXG4gICAgcmVmRWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCd3b3JraW5nJyk7XHJcbiAgICByZWZFbGVtZW50LmNsYXNzTGlzdC5hZGQoJ2ZhaWxlZCcpO1xyXG4gICAgY29uc29sZS53YXJuKGVycm9yQ29udGFpbmVyKTtcclxuICAgIGlmIChlcnJvckNvbnRhaW5lci5tZXNzYWdlICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICBhbGVydChlcnJvckNvbnRhaW5lci5tZXNzYWdlKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgZm9yIChsZXQgZXJyb3Igb2YgT2JqZWN0LmtleXMoZXJyb3JDb250YWluZXIpKSB7XHJcbiAgICAgICAgICAgIGlmIChlcnJvci5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgYWxlcnQoZXJyb3JDb250YWluZXJbZXJyb3JdLmVycm9ycy5qb2luKCdcXG4nKSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBmaWVsZCA9IGZpZWxkc1tlcnJvcl07XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBtZXNzYWdlIG9mIGVycm9yQ29udGFpbmVyW2Vycm9yXS5lcnJvcnMpIHtcclxuICAgICAgICAgICAgICAgICAgICBmaWVsZC5hcHBlbmRDaGlsZChlbGVtZW50KCdwJywgbWVzc2FnZSkpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlQ2hlY2tib3gobmFtZSwgZGF0YSwgdGV4dCwgb25DaGFuZ2UsIGRlZmF1bHRWYWx1ZSA9IGZhbHNlKSB7XHJcbiAgICBjb25zdCBpZCA9ICdzZXMtJyArIG5hbWU7XHJcbiAgICBsZXQgdmFsdWUgPSByZWFkUHJldklucHV0KCk7XHJcbiAgICBkYXRhW25hbWVdID0gdmFsdWU7XHJcbiAgICBsZXQgZWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2lucHV0Jyk7XHJcbiAgICBlbGVtZW50LnR5cGUgPSAnY2hlY2tib3gnO1xyXG4gICAgZWxlbWVudC5pZCA9IGlkO1xyXG4gICAgZWxlbWVudC5uYW1lID0gbmFtZTtcclxuICAgIGxldCBsYWJlbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xhYmVsJyk7XHJcbiAgICBsYWJlbC5odG1sRm9yID0gaWQ7XHJcbiAgICBsYWJlbC50ZXh0Q29udGVudCA9IHRleHQ7XHJcblxyXG4gICAgLypcclxuICAgIGxldCBlbGVtZW50ID0gPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNsYXNzTmFtZT1cInNlcy1jaGVja1wiIGlkPXtpZH0gbmFtZT17bmFtZX0gLz47XHJcbiAgICBsZXQgbGFiZWwgPSA8bGFiZWwgZm9yPXtpZH0+e3RleHR9PC9sYWJlbD47XHJcbiAgICAqL1xyXG4gICAgZWxlbWVudC5jaGVja2VkID0gdmFsdWU7XHJcbiAgICBlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsIHRvZ2dsZSk7XHJcblxyXG4gICAgZnVuY3Rpb24gcmVhZFByZXZJbnB1dCgpIHtcclxuICAgICAgICBsZXQgcHJldklucHV0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaWQpO1xyXG4gICAgICAgIGlmIChwcmV2SW5wdXQpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHByZXZJbnB1dC5jaGVja2VkO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiBkZWZhdWx0VmFsdWU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIHRvZ2dsZShlKSB7XHJcbiAgICAgICAgdmFsdWUgPSBlLnRhcmdldC5jaGVja2VkO1xyXG4gICAgICAgIGRhdGFbbmFtZV0gPSB2YWx1ZTtcclxuICAgICAgICByZWRyYXcoKTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiByZWRyYXcoKSB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgb25DaGFuZ2UoKTtcclxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyLm1lc3NhZ2UpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBjaGVja2JveCA9IHtcclxuICAgICAgICBlbGVtZW50LFxyXG4gICAgICAgIGxhYmVsXHJcbiAgICB9O1xyXG5cclxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShjaGVja2JveCwgJ3ZhbHVlJywge1xyXG4gICAgICAgIGdldDogKCkgPT4gdmFsdWUsXHJcbiAgICAgICAgc2V0OiAobmV3VmFsdWUpID0+IHtcclxuICAgICAgICAgICAgdmFsdWUgPSBuZXdWYWx1ZTtcclxuICAgICAgICAgICAgZWxlbWVudC5jaGVja2VkID0gdmFsdWU7XHJcbiAgICAgICAgICAgIGRhdGFbbmFtZV0gPSB2YWx1ZTtcclxuICAgICAgICAgICAgcmVkcmF3KCk7XHJcbiAgICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIGNoZWNrYm94O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdGFibGUoZGF0YSwgbGF5b3V0KSB7XHJcbiAgICBjb25zdCB0aGVhZCA9IGVsZW1lbnQoJ3RoZWFkJywgZWxlbWVudCgndHInLCBsYXlvdXQubWFwKGggPT4gZWxlbWVudCgndGgnLCBoLmxhYmVsKSkpKTtcclxuICAgIGNvbnN0IHRib2R5ID0gZWxlbWVudCgndGJvZHknLCBkYXRhLm1hcChyID0+IGVsZW1lbnQoJ3RyJywgbGF5b3V0Lm1hcChoID0+IGVsZW1lbnQoJ3RkJywgcltoLm5hbWVdKSkpKSk7XHJcblxyXG4gICAgY29uc3QgdGFibGUgPSBlbGVtZW50KCd0YWJsZScsIFt0aGVhZCwgdGJvZHldKTtcclxuICAgIHRhYmxlLnRoZWFkID0gdGhlYWQ7XHJcbiAgICB0YWJsZS50Ym9keSA9IHRib2R5O1xyXG5cclxuICAgIHJldHVybiB0YWJsZTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIEF1dG9jb21wbGV0ZSh7IHZhbHVlcywgY3VycmVudCB9KSB7XHJcbiAgICBsZXQgYXV0b2NvbXBsZXRlID0gZWxlbWVudCgnZGl2JywgW1xyXG4gICAgICAgIGVsZW1lbnQoJ2lucHV0JywgdW5kZWZpbmVkLCB7IGNsYXNzTmFtZTogJ3Nlcy1zZWFyY2gtYXV0b2NvbXBsZXRlLWlucHV0JyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBlbGVtZW50KCd1bCcpLCB7IGNsYXNzTmFtZTogJ3Nlcy1zZWFyY2gtYXV0b2NvbXBsZXRlLXN1Z2dlc3Rpb25zJyB9KVxyXG4gICAgXSwgeyBjbGFzc05hbWU6ICdzZXMtc2VhcmNoLWF1dG9jb21wbGV0ZS1jb250YWluZXInIH0pO1xyXG5cclxuICAgIGNvbnN0IHN1Z2dlc3Rpb25zQ29udGFpbmVyID0gYXV0b2NvbXBsZXRlLnF1ZXJ5U2VsZWN0b3IoJy5zZXMtc2VhcmNoLWF1dG9jb21wbGV0ZS1zdWdnZXN0aW9ucycpO1xyXG4gICAgY29uc3QgaW5wdXQgPSBhdXRvY29tcGxldGUucXVlcnlTZWxlY3RvcignLnNlcy1zZWFyY2gtYXV0b2NvbXBsZXRlLWlucHV0Jyk7XHJcbiAgICBsZXQgc2VsZWN0ZWRJbmRleCA9IHVuZGVmaW5lZDtcclxuXHJcbiAgICBpZiAoY3VycmVudCAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICBpbnB1dC52YWx1ZSA9IGN1cnJlbnQ7XHJcbiAgICB9XHJcblxyXG4gICAgYXV0b2NvbXBsZXRlLmdldFZhbHVlID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHJldHVybiBpbnB1dC52YWx1ZTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBzZWFyY2hIYW5kbGVyKGUpIHtcclxuICAgICAgICBjb25zdCBpbnB1dFZhbCA9IGUuY3VycmVudFRhcmdldC52YWx1ZTtcclxuICAgICAgICBsZXQgcmVzdWx0cyA9IHZhbHVlcztcclxuICAgICAgICBpZiAoaW5wdXRWYWwubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICByZXN1bHRzID0gdmFsdWVzLmZpbHRlcih4ID0+IHgudG9Mb3dlckNhc2UoKS5pbmRleE9mKGlucHV0VmFsLnRvTG93ZXJDYXNlKCkpID4gLTEpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBzaG93U3VnZ2VzdGlvbnMocmVzdWx0cywgaW5wdXRWYWwpO1xyXG4gICAgICAgIGlmIChlLmtleUNvZGUgPT09IDM4IHx8IGUua2V5Q29kZSA9PT0gNDAgfHwgZS5rZXlDb2RlID09PSAxMykge1xyXG4gICAgICAgICAgICBzY3JvbGxSZXN1bHRzKGUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBzaG93U3VnZ2VzdGlvbnMocmVzdWx0cywgaW5wdXRWYWwpIHtcclxuICAgICAgICBsZXQgc3VnZ2VzdGlvbnMgPSBzdWdnZXN0aW9uc0NvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCd1bCcpO1xyXG4gICAgICAgIHJlcGxhY2VDb250ZW50cyhzdWdnZXN0aW9ucywgJycpO1xyXG4gICAgICAgIHN1Z2dlc3Rpb25zID0gc3VnZ2VzdGlvbnNDb250YWluZXIucXVlcnlTZWxlY3RvcigndWwnKTs7XHJcblxyXG4gICAgICAgIGlmIChyZXN1bHRzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCByZXN1bHRzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgaXRlbSA9IHJlc3VsdHNbaV07XHJcbiAgICAgICAgICAgICAgICBjb25zdCBtYXRjaCA9IGl0ZW0ubWF0Y2gobmV3IFJlZ0V4cChpbnB1dFZhbCwgJ2knKSk7XHJcbiAgICAgICAgICAgICAgICBpdGVtID0gaXRlbS5yZXBsYWNlKG1hdGNoWzBdLCBgPHN0cm9uZz4ke21hdGNoWzBdfTwvc3Ryb25nPmApO1xyXG4gICAgICAgICAgICAgICAgbGV0IG5ld0xpID0gZWxlbWVudCgnbGknLCBpdGVtLCB1bmRlZmluZWQsIHsgZm9yY2VUeXBlOiBcIkhUTUxcIiB9KTtcclxuICAgICAgICAgICAgICAgIHN1Z2dlc3Rpb25zLmFwcGVuZENoaWxkKG5ld0xpKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBzdWdnZXN0aW9ucy5jbGFzc0xpc3QuYWRkKCdoYXMtc3VnZ2VzdGlvbnMnKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBzdWdnZXN0aW9ucy5jbGFzc0xpc3QucmVtb3ZlKCdoYXMtc3VnZ2VzdGlvbnMnKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gdXNlU3VnZ2VzdGlvbihlKSB7XHJcbiAgICAgICAgaW5wdXQudmFsdWUgPSBlLnRhcmdldC50ZXh0Q29udGVudDtcclxuICAgICAgICBpbnB1dC5mb2N1cygpO1xyXG4gICAgICAgIGxldCBzdWdnZXN0aW9ucyA9IHN1Z2dlc3Rpb25zQ29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoJ3VsJyk7XHJcbiAgICAgICAgcmVwbGFjZUNvbnRlbnRzKHN1Z2dlc3Rpb25zLCAnJyk7XHJcbiAgICAgICAgc3VnZ2VzdGlvbnMgPSBzdWdnZXN0aW9uc0NvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCd1bCcpO1xyXG4gICAgICAgIHN1Z2dlc3Rpb25zLmNsYXNzTGlzdC5yZW1vdmUoJ2hhcy1zdWdnZXN0aW9ucycpO1xyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIHNjcm9sbFJlc3VsdHMoZSkge1xyXG4gICAgICAgIGxldCBhbGxTdWdnZXN0aW9ucyA9IFsuLi5zdWdnZXN0aW9uc0NvbnRhaW5lci5xdWVyeVNlbGVjdG9yQWxsKCd1bCBsaScpXTtcclxuICAgICAgICBsZXQgb2xkSW5kZXggPSB1bmRlZmluZWQ7XHJcbiAgICAgICAgbGV0IGluZGV4Q2hhbmdlID0gMTtcclxuXHJcbiAgICAgICAgLy8gZW50ZXJcclxuICAgICAgICBpZiAoZS5rZXlDb2RlID09PSAxMykge1xyXG4gICAgICAgICAgICBpbnB1dC52YWx1ZSA9IGFsbFN1Z2dlc3Rpb25zW3NlbGVjdGVkSW5kZXhdLnRleHRDb250ZW50O1xyXG4gICAgICAgICAgICBzZWxlY3RlZEluZGV4ID0gdW5kZWZpbmVkO1xyXG4gICAgICAgICAgICBsZXQgc3VnZ2VzdGlvbnMgPSBzdWdnZXN0aW9uc0NvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCd1bCcpO1xyXG4gICAgICAgICAgICBzdWdnZXN0aW9ucy5jbGFzc0xpc3QucmVtb3ZlKCdoYXMtc3VnZ2VzdGlvbnMnKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGUua2V5Q29kZSA9PT0gNDApIHtcclxuICAgICAgICAgICAgLy8gZG93biBhcnJvd1xyXG4gICAgICAgICAgICBpbmRleENoYW5nZSA9IDE7XHJcbiAgICAgICAgfSBlbHNlIGlmIChlLmtleUNvZGUgPT09IDM4KSB7XHJcbiAgICAgICAgICAgIC8vIHVwIGFycm93XHJcbiAgICAgICAgICAgIGluZGV4Q2hhbmdlID0gLTE7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoc2VsZWN0ZWRJbmRleCA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgc2VsZWN0ZWRJbmRleCA9IGluZGV4Q2hhbmdlID09PSAxID8gMCA6IGFsbFN1Z2dlc3Rpb25zLmxlbmd0aCAtIDE7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgb2xkSW5kZXggPSBzZWxlY3RlZEluZGV4O1xyXG4gICAgICAgICAgICBzZWxlY3RlZEluZGV4ID0gKChzZWxlY3RlZEluZGV4ICsgaW5kZXhDaGFuZ2UpICsgYWxsU3VnZ2VzdGlvbnMubGVuZ3RoKSAlIGFsbFN1Z2dlc3Rpb25zLmxlbmd0aDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChvbGRJbmRleCAhPT0gdW5kZWZpbmVkICYmIG9sZEluZGV4IDwgYWxsU3VnZ2VzdGlvbnMubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgIGFsbFN1Z2dlc3Rpb25zW29sZEluZGV4XS5jbGFzc0xpc3QucmVtb3ZlKCdzZWxlY3RlZCcpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgYWxsU3VnZ2VzdGlvbnNbc2VsZWN0ZWRJbmRleF0uY2xhc3NMaXN0LmFkZCgnc2VsZWN0ZWQnKTtcclxuICAgIH1cclxuXHJcbiAgICBpbnB1dC5hZGRFdmVudExpc3RlbmVyKCdrZXl1cCcsIHNlYXJjaEhhbmRsZXIpO1xyXG4gICAgc3VnZ2VzdGlvbnNDb250YWluZXIuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCB1c2VTdWdnZXN0aW9uKTtcclxuICAgIHJldHVybiBhdXRvY29tcGxldGU7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBDcmVhdGVzIGEgc3BhbiBlbGVtZW50IHRoYXQgcmVwcmVzZW50cyBhIGRvd25sb2FkIHByb2dyZXNzIGJhclxyXG4gKiBAcGFyYW0geyB7ZG93bmxvYWRGdW5jdGlvbjogKG9uUHJvZ3Jlc3M6IGltcG9ydCgnLi91dGlsLmpzJykuT25Qcm9ncmVzc0Z1bmN0aW9uKSwgcmV0dXJuRnVuY3Rpb246IGZ1bmN0aW9ufSB9IHNldHRpbmdzIENvbnRhaW5zIHRoZSBmdW5jdGlvbiB0aGF0IHdpbGwgZG93bmxvYWQgdGhlIHJlc291cmNlcywgd2hpY2ggd2lsbCBiZSBjYWxsZWQgd2l0aCBvblByb2dyZXNzXHJcbiAqIGFuZCB0aGUgcmV0dXJuRnVuY3Rpb24gd2hpY2ggd2lsbCBiZSBjYWxsZWQgd2l0aCB0aGUgcmVzdWx0cyBhZnRlciB0aGUgZG93bmxvYWQgZmluaXNoZXNcclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBEb3dubG9hZFByb2dyZXNzQmFyKHsgZG93bmxvYWRGdW5jdGlvbiwgcmV0dXJuRnVuY3Rpb24gfSkge1xyXG4gICAgY29uc3QgcGVyY2VudCA9IDxzcGFuPjAlPC9zcGFuPjtcclxuICAgIGNvbnN0IGJhciA9IDxzcGFuIHN0eWxlPXt7IHBhZGRpbmc6ICcwIDAuNWVtJywgZGlzcGxheTogJ2lubGluZS1ibG9jaycsIHdpZHRoOiAnMjUlJywgYmFja2dyb3VuZDogJ2xpbmVhci1ncmFkaWVudCh0byByaWdodCwgI2ZmYTAwMCAwJSwgI2VlZSAwKScgfX0+e3BlcmNlbnR9INCh0LLQsNC70Y/QvdC1PC9zcGFuPjtcclxuICAgIGRvd25sb2FkRnVuY3Rpb24ob25Qcm9ncmVzcykudGhlbihkYXRhID0+IHtcclxuICAgICAgICBpZiAocmV0dXJuRnVuY3Rpb24pIHtcclxuICAgICAgICAgICAgcmV0dXJuRnVuY3Rpb24oZGF0YSlcclxuICAgICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gYmFyO1xyXG5cclxuICAgIGZ1bmN0aW9uIG9uUHJvZ3Jlc3MoY29tcGxldGVkLCB0b3RhbCwgcmVzcG9uc2UsIGluZGV4KSB7XHJcbiAgICAgICAgY29uc3QgcHJvZ3Jlc3MgPSBNYXRoLmZsb29yKGNvbXBsZXRlZCAvIHRvdGFsICogMTAwKTtcclxuICAgICAgICBwZXJjZW50LnRleHRDb250ZW50ID0gcHJvZ3Jlc3MgKyAnJSc7XHJcbiAgICAgICAgYmFyLnN0eWxlLmJhY2tncm91bmQgPSBgbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZmZhMDAwICR7cHJvZ3Jlc3N9JSwgI2VlZSAwKWA7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IHtcclxuICAgIGVsZW1lbnRcclxufTsiLCIvKiBnbG9iYWxzIHhsc3gsIEpTWmlwICovXHJcblxyXG5pbXBvcnQgcGFyc2UgZnJvbSAnLi9wYXJzZSc7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaW1wb3J0UXVpekZyb21YbHN4KGJsb2IpIHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcclxuICAgICAgICByZWFkZXIub25sb2FkID0gZnVuY3Rpb24gKGUpIHtcclxuICAgICAgICAgICAgY29uc3QgZmlsZURhdGEgPSBlLnRhcmdldC5yZXN1bHQ7XHJcbiAgICAgICAgICAgIGNvbnN0IHdiID0geGxzeC5yZWFkKGZpbGVEYXRhLCB7XHJcbiAgICAgICAgICAgICAgICB0eXBlOiAnYmluYXJ5J1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgY29uc3QgZmlyc3RTaGVldCA9IHdiLlNoZWV0c1t3Yi5TaGVldE5hbWVzWzBdXTtcclxuICAgICAgICAgICAgY29uc3QgYXBpRGF0YSA9IHhsc3gudXRpbHNcclxuICAgICAgICAgICAgICAgIC5zaGVldF90b19qc29uKGZpcnN0U2hlZXQsIHsgaGVhZGVyOiAxIH0pXHJcbiAgICAgICAgICAgICAgICAuc2xpY2UoMSkgLy8gcmVtb3ZlIGZpcnN0IHJvd1xyXG4gICAgICAgICAgICAgICAgLnJlZHVjZSgoZGF0YSwgY3VycmVudFJvdykgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChjdXJyZW50Um93Lmxlbmd0aCAhPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjb3JyZWN0QW5zd2VySW5kZXggPSBjdXJyZW50Um93LnBvcCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBxdWVzdGlvbiA9IGN1cnJlbnRSb3dbMF07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGFsbEFuc3dlcnMgPSBjdXJyZW50Um93LnNsaWNlKDEpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjb3JyZWN0QW5zd2VyID0gY3VycmVudFJvd1tjb3JyZWN0QW5zd2VySW5kZXhdO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YVtxdWVzdGlvbl0gPSBhbGxBbnN3ZXJzLnJlZHVjZSgoYW5zd2VycywgYSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGEgIT0gdW5kZWZpbmVkICYmIGEudG9TdHJpbmcoKS50cmltKCkgIT09ICcnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2Vyc1thXSA9IGEgPT09IGNvcnJlY3RBbnN3ZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGFuc3dlcnM7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sIHt9KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBkYXRhO1xyXG4gICAgICAgICAgICAgICAgfSwge30pO1xyXG5cclxuICAgICAgICAgICAgcmVzb2x2ZShhcGlEYXRhKTtcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICByZWFkZXIucmVhZEFzQmluYXJ5U3RyaW5nKGJsb2IpO1xyXG4gICAgfSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBpbXBvcnRGcm9tWGxzeChibG9iLCB1c2VDZWxsRGF0ZXMgPSBmYWxzZSkge1xyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xyXG4gICAgICAgIHJlYWRlci5vbmxvYWQgPSBmdW5jdGlvbiAoZSkge1xyXG4gICAgICAgICAgICBjb25zdCBmaWxlID0gZS50YXJnZXQucmVzdWx0O1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgY29uc3Qgd2IgPSB4bHN4LnJlYWQoZmlsZSwge1xyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6ICdiaW5hcnknLFxyXG4gICAgICAgICAgICAgICAgICAgIGNlbGxEYXRlczogdXNlQ2VsbERhdGVzXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGZpcnN0U2hlZXQgPSB3Yi5TaGVldHNbd2IuU2hlZXROYW1lc1swXV07XHJcbiAgICAgICAgICAgICAgICBjb25zdCBkYXRhID0geGxzeC51dGlscy5zaGVldF90b19qc29uKGZpcnN0U2hlZXQsIHsgaGVhZGVyOiAxIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgIHJlc29sdmUoZGF0YSk7XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ0Vycm9yIHBhcnNpbmcgWExTWCBmaWxlLCBtYWtlIHN1cmUgdGhlIGxpYnJhcnkgaXMgbG9hZGVkJyk7XHJcbiAgICAgICAgICAgICAgICByZWplY3QoZXJyKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgcmVhZGVyLm9uZXJyb3IgPSBmdW5jdGlvbiAoZSkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygnRXJyb3IgcmVhZGluZyBmaWxlJyk7XHJcbiAgICAgICAgICAgIHJlamVjdChlKTtcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICByZWFkZXIucmVhZEFzQmluYXJ5U3RyaW5nKGJsb2IpO1xyXG4gICAgfSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiB0b1hsc3hGaWxlKHRhYmxlLCBuYW1lID0gJ091dHB1dCcsIHdzX25hbWUpIHtcclxuICAgIGlmICh3c19uYW1lID09PSB1bmRlZmluZWQpIHtcclxuICAgICAgICB3c19uYW1lID0gbmFtZS5zbGljZSgwLCAzMSk7XHJcbiAgICB9XHJcbiAgICBjb25zdCB3YiA9IHhsc3gudXRpbHMuYm9va19uZXcoKSwgd3MgPSB4bHN4LnV0aWxzLmFvYV90b19zaGVldCh0YWJsZSk7XHJcbiAgICAvLyB3Yi5Xb3JrYm9vayA9IHsgVmlld3M6IFsnV2luZG93MiddIH07XHJcbiAgICB4bHN4LnV0aWxzLmJvb2tfYXBwZW5kX3NoZWV0KHdiLCB3cywgd3NfbmFtZSk7XHJcbiAgICBjb25zdCBkYXRhID0geGxzeC53cml0ZSh3Yiwge1xyXG4gICAgICAgIHR5cGU6ICdhcnJheScsXHJcbiAgICAgICAgYm9va1R5cGU6ICd4bHN4J1xyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgZmlsZSA9IG5ldyBGaWxlKFtkYXRhXSwgbmFtZSArICcueGxzeCcsIHsgdHlwZTogJ2FwcGxpY2F0aW9uL3ZuZC5vcGVueG1sZm9ybWF0cy1vZmZpY2Vkb2N1bWVudC5zcHJlYWRzaGVldG1sLnNoZWV0JyB9KTtcclxuXHJcbiAgICByZXR1cm4gZmlsZTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHRvTGVnYWN5WGxzRmlsZSh0YWJsZSwgbmFtZSA9ICdPdXRwdXQnLCB3c19uYW1lKSB7XHJcbiAgICBpZiAod3NfbmFtZSA9PT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgd3NfbmFtZSA9IG5hbWUuc2xpY2UoMCwgMzEpO1xyXG4gICAgfVxyXG4gICAgY29uc3Qgd2IgPSB4bHN4LnV0aWxzLmJvb2tfbmV3KCksIHdzID0geGxzeC51dGlscy5hb2FfdG9fc2hlZXQodGFibGUpO1xyXG4gICAgd2IuV29ya2Jvb2sgPSB7IFZpZXdzOiBbJ1dpbmRvdzInXSB9O1xyXG4gICAgeGxzeC51dGlscy5ib29rX2FwcGVuZF9zaGVldCh3Yiwgd3MsIHdzX25hbWUpO1xyXG4gICAgY29uc3QgZGF0YSA9IHhsc3gud3JpdGUod2IsIHtcclxuICAgICAgICB0eXBlOiAnYXJyYXknLFxyXG4gICAgICAgIGJvb2tUeXBlOiAnYmlmZjgnXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCBmaWxlID0gbmV3IEZpbGUoW2RhdGFdLCBuYW1lICsgJy54bHMnLCB7IHR5cGU6ICdhcHBsaWNhdGlvbi92bmQubXMtZXhjZWwnIH0pO1xyXG5cclxuICAgIHJldHVybiBmaWxlO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZXhwb3J0VG9YbHN4KHRhYmxlLCBuYW1lID0gJ091dHB1dCcsIHdzX25hbWUpIHtcclxuICAgIGNvbnN0IGZpbGVuYW1lID0gYCR7bmFtZX0ueGxzeGA7XHJcbiAgICBpZiAod3NfbmFtZSA9PT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgd3NfbmFtZSA9IG5hbWUuc2xpY2UoMCwgMzEpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFNoZWV0IG5hbWUgY2Fubm90IGNvbnRhaW46IFxcIC8gPyAqIFsgXVxyXG4gICAgY29uc3Qgc2hlZXRSZWdleCA9IC9bXFxbXFxdXFxcXFxcL1xcKl0vZ2k7XHJcbiAgICBpZiAoc2hlZXRSZWdleC50ZXN0KHdzX25hbWUpKSB7XHJcbiAgICAgICAgd3NfbmFtZSA9IHdzX25hbWUucmVwbGFjZShzaGVldFJlZ2V4LCAnLScpO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHdiID0geGxzeC51dGlscy5ib29rX25ldygpLCB3cyA9IHhsc3gudXRpbHMuYW9hX3RvX3NoZWV0KHRhYmxlKTtcclxuICAgIHhsc3gudXRpbHMuYm9va19hcHBlbmRfc2hlZXQod2IsIHdzLCB3c19uYW1lKTtcclxuICAgIHhsc3gud3JpdGVGaWxlKHdiLCBmaWxlbmFtZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBleHBvcnRQYXltZW50c1RvWGxzeChkYXRhLCB5ZWFyLCBtb250aCkge1xyXG4gICAgY29uc3QgZmlsZW5hbWUgPSBgUGF5bWVudHMtJHtwYXJzZS5tb250aE5hbWVbbW9udGhdfS0ke3llYXJ9Lnhsc3hgO1xyXG4gICAgY29uc3Qgd3NfbmFtZSA9IGBQYXltZW50cyAke3BhcnNlLm1vbnRoTmFtZVttb250aF19ICR7eWVhcn1gO1xyXG4gICAgY29uc3Qgd2IgPSB4bHN4LnV0aWxzLmJvb2tfbmV3KCksIHdzID0geGxzeC51dGlscy5hb2FfdG9fc2hlZXQoZGF0YSk7XHJcbiAgICB4bHN4LnV0aWxzLmJvb2tfYXBwZW5kX3NoZWV0KHdiLCB3cywgd3NfbmFtZSk7XHJcbiAgICB4bHN4LndyaXRlRmlsZSh3YiwgZmlsZW5hbWUpO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZXhwb3J0VG9Kc29uKGRhdGEsIG5hbWUgPSAnT3V0cHV0Jykge1xyXG4gICAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKFtkYXRhXSwgeyB0eXBlOiAnYXBwbGljYXRpb24vanNvbicgfSk7XHJcbiAgICBpZiAod2luZG93Lm5hdmlnYXRvci5tc1NhdmVPck9wZW5CbG9iKSB7XHJcbiAgICAgICAgd2luZG93Lm5hdmlnYXRvci5tc1NhdmVCbG9iKGJsb2IsIG5hbWUgKyAnLmpzb24nKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdmFyIGVsZW0gPSB3aW5kb3cuZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xyXG4gICAgICAgIGVsZW0uaHJlZiA9IHdpbmRvdy5VUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xyXG4gICAgICAgIGVsZW0uZG93bmxvYWQgPSBuYW1lICsgJy5qc29uJztcclxuICAgICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGVsZW0pO1xyXG4gICAgICAgIGVsZW0uY2xpY2soKTtcclxuICAgICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGVsZW0pO1xyXG4gICAgfVxyXG59XHJcblxyXG4vKipcclxuICogQHBhcmFtIHt7Zm9sZGVyOiBzdHJpbmcsIGZpbGVzOiBGaWxlW119W119IGZpbGVzIFxyXG4gKi9cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHppcEZpbGVzKGZpbGVzKSB7XHJcbiAgICBjb25zdCB6aXAgPSBuZXcgSlNaaXAoKTtcclxuICAgIGZvciAobGV0IGVudHJ5IG9mIGZpbGVzKSB7XHJcbiAgICAgICAgY29uc3QgY3VycmVudCA9IHppcC5mb2xkZXIoZW50cnkuZm9sZGVyKTtcclxuICAgICAgICBjdXJyZW50LmZpbGUoZW50cnkuZmlsZXMucGhvdG8ubmFtZSwgYXdhaXQgYmxvYlRvQmFzZTY0KGVudHJ5LmZpbGVzLnBob3RvLmZpbGUpLCB7IGJhc2U2NDogdHJ1ZSB9KTtcclxuICAgICAgICBjdXJyZW50LmZpbGUoZW50cnkuZmlsZXMubWVkaWNhbC5uYW1lLCBhd2FpdCBibG9iVG9CYXNlNjQoZW50cnkuZmlsZXMubWVkaWNhbC5maWxlKSwgeyBiYXNlNjQ6IHRydWUgfSk7XHJcbiAgICAgICAgY3VycmVudC5maWxlKGVudHJ5LmZpbGVzLmRpcGxvbWEubmFtZSwgYXdhaXQgYmxvYlRvQmFzZTY0KGVudHJ5LmZpbGVzLmRpcGxvbWEuZmlsZSksIHsgYmFzZTY0OiB0cnVlIH0pO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHppcC5nZW5lcmF0ZUFzeW5jKHsgdHlwZTogJ2Jsb2InIH0pO1xyXG5cclxuICAgIGZ1bmN0aW9uIGJsb2JUb0Jhc2U2NChibG9iKSB7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKHJlc29sdmUgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xyXG4gICAgICAgICAgICByZWFkZXIub25sb2FkID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgZGF0YVVybCA9IHJlYWRlci5yZXN1bHQ7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBiYXNlNjQgPSBkYXRhVXJsLnNwbGl0KCcsJylbMV07XHJcbiAgICAgICAgICAgICAgICByZXNvbHZlKGJhc2U2NCk7XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIHJlYWRlci5yZWFkQXNEYXRhVVJMKGJsb2IpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxufVxyXG5cclxuY29uc3QgbWltZXMgPSB7XHJcbiAgICAnYm1wJzogJ2ltYWdlL2JtcCcsXHJcbiAgICAnZ2lmJzogJ2ltYWdlL2dpZicsXHJcbiAgICAnanBlZyc6ICdpbWFnZS9qcGVnJyxcclxuICAgICdqcGcnOiAnaW1hZ2UvanBlZycsXHJcbiAgICAncG5nJzogJ2ltYWdlL3BuZycsXHJcbiAgICAncGRmJzogJ2FwcGxpY2F0aW9uL3BkZicsXHJcbiAgICAndGlmJzogJ2ltYWdlL3RpZmYnLFxyXG4gICAgJ3RpZmYnOiAnaW1hZ2UvdGlmZicsXHJcbiAgICAnd2VicCc6ICdpbWFnZS93ZWJwJyxcclxuICAgICd6aXAnOiAnYXBwbGljYXRpb24vemlwJyxcclxuICAgICc3eic6ICdhcHBsaWNhdGlvbi94LTd6LWNvbXByZXNzZWQnLFxyXG4gICAgJ3Rhcic6ICdhcHBsaWNhdGlvbi94LXRhcicsXHJcbiAgICAncmFyJzogJ2FwcGxpY2F0aW9uL3ZuZC5yYXInXHJcbn07XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0TWltZShleHRlbnNpb24pIHtcclxuICAgIGV4dGVuc2lvbiA9IGV4dGVuc2lvbi50b0xvY2FsZUxvd2VyQ2FzZSgpO1xyXG4gICAgcmV0dXJuIG1pbWVzW2V4dGVuc2lvbl0gfHwgJ2FwcGxpY2F0aW9uL29jdGV0LXN0cmVhbSc7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBvcGVuRmlsZShmaWxlLCBuYW1lID0gJ291dHB1dC50eHQnKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIHZhciBlbGVtID0gd2luZG93LmRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcclxuICAgICAgICBlbGVtLnRhcmdldCA9ICdfYmxhbmsnO1xyXG4gICAgICAgIGVsZW0uZG93bmxvYWQgPSBuYW1lO1xyXG4gICAgICAgIGNvbnN0IGhyZWYgPSB3aW5kb3cuVVJMLmNyZWF0ZU9iamVjdFVSTChmaWxlKTtcclxuICAgICAgICBlbGVtLmhyZWYgPSBocmVmO1xyXG4gICAgICAgIGVsZW0uY2xpY2soKTtcclxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IFVSTC5yZXZva2VPYmplY3RVUkwoaHJlZiksIDYwMDAwKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGRvd25sb2FkKGJsb2IsIG5hbWUgPSAnb3V0cHV0LnR4dCcpIHtcclxuICAgIGlmICh3aW5kb3cubmF2aWdhdG9yLm1zU2F2ZU9yT3BlbkJsb2IpIHtcclxuICAgICAgICB3aW5kb3cubmF2aWdhdG9yLm1zU2F2ZUJsb2IoYmxvYiwgbmFtZSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIHZhciBlbGVtID0gd2luZG93LmRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcclxuICAgICAgICBlbGVtLnRhcmdldCA9ICdfYmxhbmsnO1xyXG4gICAgICAgIGNvbnN0IGhyZWYgPSB3aW5kb3cuVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTtcclxuICAgICAgICBlbGVtLmhyZWYgPSBocmVmO1xyXG4gICAgICAgIGVsZW0uZG93bmxvYWQgPSBuYW1lO1xyXG4gICAgICAgIGVsZW0uY2xpY2soKTtcclxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IFVSTC5yZXZva2VPYmplY3RVUkwoaHJlZiksIDYwMDAwKTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyb3NzQnJvd3NlckZpbGVVcGxvYWQoYXBpQ2FsbCwgZmlsZSkge1xyXG4gICAgaWYgKCEhd2luZG93LmNocm9tZSkge1xyXG4gICAgICAgIGNvbnN0IGZpbGVVcmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGZpbGUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGFwaUNhbGwoeyBmaWxlVXJsLCBuYW1lOiBmaWxlLm5hbWUgfSk7XHJcbiAgICAgICAgVVJMLnJldm9rZU9iamVjdFVSTChmaWxlVXJsKTtcclxuICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gYXdhaXQgYXBpQ2FsbCh7IGZpbGUgfSk7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRTdWJzaXRlKCkge1xyXG4gICAgc3dpdGNoICh3aW5kb3cubG9jYXRpb24uaG9zdC5zdWJzdHIoMCwgNykpIHtcclxuICAgICAgICBjYXNlICdkaWdpdGFsJzpcclxuICAgICAgICAgICAgcmV0dXJuICdkaWdpdGFsJztcclxuICAgICAgICBjYXNlICdjcmVhdGl2JzpcclxuICAgICAgICAgICAgcmV0dXJuICdjcmVhdGl2ZSc7XHJcbiAgICAgICAgY2FzZSAncGxhdGZvcic6XHJcbiAgICAgICAgICAgIHJldHVybiAncGxhdGZvcm0nO1xyXG4gICAgICAgIGNhc2UgJ2FpLnNvZnQnOlxyXG4gICAgICAgICAgICByZXR1cm4gJ2FpJztcclxuICAgICAgICBjYXNlICdmaW5hbmNlJzpcclxuICAgICAgICAgICAgcmV0dXJuICdmaW5hbmNlYWNhZGVteSc7XHJcbiAgICAgICAgY2FzZSAnZGV2LmRpZyc6XHJcbiAgICAgICAgICAgIHJldHVybiAnZGV2ZGlnaXRhbCc7XHJcbiAgICAgICAgY2FzZSAnZGV2LnNvZic6XHJcbiAgICAgICAgICAgIHJldHVybiAnZGV2c29mdHVuaSc7XHJcbiAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgcmV0dXJuICdwcm9ncmFtbWluZyc7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBoYXNDUE9BY2Nlc3MoKSB7XHJcbiAgICByZXR1cm4gWydkaWdpdGFsJywgJ2NyZWF0aXZlJywgJ3Byb2dyYW1taW5nJywgJ2RldmRpZ2l0YWwnLCAnZGV2c29mdHVuaSddLmluY2x1ZGVzKGdldFN1YnNpdGUoKSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBpc0FkbWluKCkge1xyXG4gICAgY29uc3QgZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJ2FbaHJlZj1cIi9hZG1pbmlzdHJhdGlvbi9uYXZpZ2F0aW9uXCIgaV0nKTtcclxuICAgIGlmIChlLmxlbmd0aCA+IDApIHsgcmV0dXJuIHRydWU7IH1cclxuICAgIGVsc2UgeyByZXR1cm4gZmFsc2U7IH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHNlcmlhbGl6ZUNhbGxzKGZuQXJyYXksIGRlbGF5KSB7XHJcbiAgICBjb25zdCBjYWxsQXJyYXkgPSBbXTtcclxuXHJcbiAgICBpZiAoZGVsYXkgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZm5BcnJheS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBjb25zdCBoYW5kbGVyID0gKHJlcywgcmVqKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KGFzeW5jICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBmbkFycmF5W2ldKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcyhyZXN1bHQpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZWooZXJyKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9LCBpICogZGVsYXkpO1xyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBjb25zdCBwciA9IG5ldyBQcm9taXNlKGhhbmRsZXIpO1xyXG5cclxuICAgICAgICAgICAgY2FsbEFycmF5LnB1c2gocHIpO1xyXG4gICAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBmbkFycmF5Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGhhbmRsZXIgPSAocmVzLCByZWopID0+IHtcclxuICAgICAgICAgICAgICAgIGlmIChpID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNhbGxBcnJheVtpIC0gMV0uZmluYWxseShhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBmbkFycmF5W2ldKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXMocmVzdWx0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWooZXJyKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBmbkFycmF5W2ldKCkudGhlbihyZXMpLmNhdGNoKHJlaik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIGNvbnN0IHByID0gbmV3IFByb21pc2UoaGFuZGxlcik7XHJcblxyXG4gICAgICAgICAgICBjYWxsQXJyYXkucHVzaChwcik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBjYWxsQXJyYXk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB3aXRoUHJvZ3Jlc3MoY2FsbEFycmF5LCBvbkNoYW5nZSwgZGVsYXkgPSAxMCkge1xyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICAvLyBGYWlsc2F2ZSBmb3IgZW1wdHkgY2FsbEFycmF5XHJcbiAgICAgICAgaWYgKGNhbGxBcnJheS5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgICAgICBvbkNoYW5nZSh1bmRlZmluZWQsIDAsIDEsIDEpO1xyXG4gICAgICAgICAgICByZXNvbHZlKFtdKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCByZXNvbHZlZCA9IDA7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBbXTtcclxuICAgICAgICBjYWxsTmV4dCgwKTtcclxuXHJcbiAgICAgICAgZnVuY3Rpb24gY2FsbE5leHQoaSkge1xyXG4gICAgICAgICAgICBpZiAoaSA+PSBjYWxsQXJyYXkubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBjYWxsQXJyYXlbaV1cclxuICAgICAgICAgICAgICAgICAgICAudGhlbihyZXMgPT4gb25SZXNvbHZlKHJlcywgaSkpXHJcbiAgICAgICAgICAgICAgICAgICAgLmNhdGNoKG9uRXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiBjYWxsTmV4dChpICsgMSksIGRlbGF5KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZnVuY3Rpb24gb25SZXNvbHZlKHJlcywgaW5kZXgpIHtcclxuICAgICAgICAgICAgcmVzb2x2ZWQrKztcclxuICAgICAgICAgICAgaWYgKG9uQ2hhbmdlKSB7XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZShyZXMsIGluZGV4LCByZXNvbHZlZCwgY2FsbEFycmF5Lmxlbmd0aCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmVzcG9uc2VbaW5kZXhdID0gcmVzO1xyXG4gICAgICAgICAgICBpZiAocmVzb2x2ZWQgPT09IGNhbGxBcnJheS5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgIHJlc29sdmUocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBmdW5jdGlvbiBvbkVycm9yKGUpIHtcclxuICAgICAgICAgICAgcmVqZWN0KGUpO1xyXG4gICAgICAgIH1cclxuICAgIH0pO1xyXG59XHJcblxyXG4vKipcclxuICogQHR5cGVkZWYgeyhjb21wbGV0ZWQ6IG51bWJlciwgdG90YWw6IG51bWJlciwgcmVzcG9uc2UsIGluZGV4OiBudW1iZXIpID0+IHZvaWR9IE9uUHJvZ3Jlc3NGdW5jdGlvblxyXG4gKi9cclxuXHJcbi8qKlxyXG4gKiBAdHlwZWRlZiB7KCkgPT4gUHJvbWlzZX0gQXN5bmNGdW5jdGlvblxyXG4gKi9cclxuXHJcbi8qKlxyXG4gKiBJbml0aWF0ZSByZW1vdGUgY2FsbHMgYXQgaW50ZXJ2YWxzXHJcbiAqIEBwYXJhbSB7QXJyYXk8QXN5bmNGdW5jdGlvbj59IGZuQXJyYXkgXHJcbiAqIEBwYXJhbSB7T25Qcm9ncmVzc0Z1bmN0aW9ufSBvblByb2dyZXNzIFxyXG4gKiBAcGFyYW0ge251bWJlcn0gW2RlbGF5PTEwXVxyXG4gKiBAcmV0dXJucyBcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkaXN0cmlidXRlKGZuQXJyYXksIG9uUHJvZ3Jlc3MsIGRlbGF5ID0gMTApIHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgY29uc3QgdG90YWwgPSBmbkFycmF5Lmxlbmd0aDtcclxuICAgICAgICBsZXQgY29tcGxldGVkID0gMDtcclxuICAgICAgICBsZXQgcmVzb2x2ZWQgPSAwO1xyXG5cclxuICAgICAgICAvLyBGYWlsc2F2ZSBmb3IgZW1wdHkgZm5BcnJheVxyXG4gICAgICAgIGlmICh0b3RhbCA9PSAwKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2Ygb25Qcm9ncmVzcyA9PSAnZnVuY3Rpb24nKSB7XHJcbiAgICAgICAgICAgICAgICBvblByb2dyZXNzKHVuZGVmaW5lZCwgMCwgMSwgMSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmVzb2x2ZShbXSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCBjYWxscyA9IGZuQXJyYXkubWFwKChmbiwgaSkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBjYWxsID0ge1xyXG4gICAgICAgICAgICAgICAgZm4sXHJcbiAgICAgICAgICAgICAgICBzZW50OiBmYWxzZSxcclxuICAgICAgICAgICAgICAgIGNhbmNlbGxlZDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICByZXNwb25zZTogdW5kZWZpbmVkLFxyXG4gICAgICAgICAgICAgICAgdGltZXI6IG51bGwsXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIGNhbGwub25DYWxsID0gb25DYWxsLmJpbmQoY2FsbCwgaSk7XHJcbiAgICAgICAgICAgIGNhbGwuY2FuY2VsID0gb25DYW5jZWwuYmluZChjYWxsKTtcclxuICAgICAgICAgICAgY2FsbC50aW1lciA9IHNldFRpbWVvdXQoY2FsbC5vbkNhbGwsIGkgKiBkZWxheSk7XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gY2FsbDtcclxuICAgICAgICB9KTtcclxuICAgICAgICBjYWxscy5mb3JFYWNoKChjLCBpKSA9PiBjLm5leHQgPSBjYWxsc1tpICsgMV0pO1xyXG5cclxuICAgICAgICBhc3luYyBmdW5jdGlvbiBvbkNhbGwoaSkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5zZW50ID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICBjbGVhclRpbWVvdXQodGhpcy50aW1lcik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMuY2FuY2VsbGVkID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNlbnQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBwcm9taXNlID0gdGhpcy5mbigpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmVzcG9uc2UgPSBhd2FpdCBwcm9taXNlO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm9taXNlLl9jYWNoZUhpdCAmJiB0aGlzLm5leHQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5uZXh0Lm9uQ2FsbCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICByZXNvbHZlZCsrO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNhbmNlbGxlZCA9PSBmYWxzZSAmJiByZXNvbHZlZCA9PT0gdG90YWwpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShjYWxscy5tYXAoYyA9PiBjLnJlc3BvbnNlKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgb25FcnJvcihlcnIpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNvbXBsZXRlZCsrO1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIG9uUHJvZ3Jlc3MgPT0gJ2Z1bmN0aW9uJykge1xyXG4gICAgICAgICAgICAgICAgb25Qcm9ncmVzcyhjb21wbGV0ZWQsIHRvdGFsLCB0aGlzLnJlc3BvbnNlLCBpKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZnVuY3Rpb24gb25DYW5jZWwoKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNhbmNlbGxlZCA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jYW5jZWxsZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuc2VudCA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aGlzLnRpbWVyKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm9uQ2FsbCgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBmdW5jdGlvbiBvbkVycm9yKGUpIHtcclxuICAgICAgICAgICAgY2FsbHMuZm9yRWFjaChjID0+IGMuY2FuY2VsKCkpO1xyXG4gICAgICAgICAgICBpZiAoZSBpbnN0YW5jZW9mIEVycm9yKSB7XHJcbiAgICAgICAgICAgICAgICBlLl9yZXNwb25zZXMgPSBjYWxscy5tYXAoYyA9PiBjLnJlc3BvbnNlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZWplY3QoZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBhc3NlcnRUZW1wbGF0ZSh0ZW1wbGF0ZSwgdGFyZ2V0LCBib3R0b20gPSBmYWxzZSkge1xyXG4gICAgaWYgKHRlbXBsYXRlLkRhdGEgIT09IHVuZGVmaW5lZCAmJiB0ZW1wbGF0ZS5Ub3RhbCAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgdGVtcGxhdGUgPSB0ZW1wbGF0ZS5EYXRhO1xyXG4gICAgICAgIHRhcmdldCA9IHRhcmdldC5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChBcnJheS5pc0FycmF5KHRlbXBsYXRlKSkge1xyXG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KHRhcmdldCkpIHtcclxuICAgICAgICAgICAgaWYgKGJvdHRvbSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgYXNzZXJ0VGVtcGxhdGUodGVtcGxhdGVbMF0sIHRhcmdldFswXSwgdHJ1ZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdUYXJnZXQgdHlwZSBtaXNtYXRjaCcpO1xyXG4gICAgICAgIH1cclxuICAgIH0gZWxzZSBpZiAodHlwZW9mIHRlbXBsYXRlID09PSAnb2JqZWN0Jykge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGFyZ2V0ID09PSAnb2JqZWN0Jykge1xyXG4gICAgICAgICAgICBjb25zdCBtb2RlbCA9IE9iamVjdC5rZXlzKHRlbXBsYXRlKTtcclxuICAgICAgICAgICAgZm9yIChsZXQgcHJvcCBvZiBtb2RlbCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRhcmdldC5oYXNPd25Qcm9wZXJ0eShwcm9wKSA9PT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdNaXNzaW5nIHByb3BlcnR5IG9uIHRhcmdldDogJyArIHByb3ApO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignVGFyZ2V0IHR5cGUgbWlzbWF0Y2gnKTtcclxuICAgICAgICB9XHJcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiB0ZW1wbGF0ZSAhPT0gdHlwZW9mIHRhcmdldCkge1xyXG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1RhcmdldCB0eXBlIG1pc21hdGNoJyk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0TG9jYWxlKCkge1xyXG4gICAgcmV0dXJuICdiZyc7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVUaHJvdHRsZWRFeGVjdXRvcihjYWxsYmFjaywgZGVsYXkpIHtcclxuICAgIGxldCB0aW1lciA9IG51bGw7XHJcblxyXG4gICAgcmV0dXJuIGZ1bmN0aW9uICguLi5wYXJhbXMpIHtcclxuICAgICAgICBjbGVhcigpO1xyXG4gICAgICAgIHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgIGNsZWFyKCk7XHJcbiAgICAgICAgICAgIGNhbGxiYWNrKC4uLnBhcmFtcyk7XHJcbiAgICAgICAgfSwgZGVsYXkpO1xyXG4gICAgfTtcclxuXHJcbiAgICBmdW5jdGlvbiBjbGVhcigpIHtcclxuICAgICAgICBpZiAodGltZXIgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVyKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBpY29uQXNzZXQobmFtZSkge1xyXG4gICAgcmV0dXJuIGJyb3dzZXIucnVudGltZS5nZXRVUkwoYGljb25zLyR7bmFtZX0ucG5nYCk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBlc2NhcGVIVE1MKHN0cikge1xyXG4gICAgcmV0dXJuIHN0ci5yZXBsYWNlKC9bJjw+XS9nLFxyXG4gICAgICAgIHRhZyA9PiAoe1xyXG4gICAgICAgICAgICAnJic6ICcmYW1wOycsXHJcbiAgICAgICAgICAgICc8JzogJyZsdDsnLFxyXG4gICAgICAgICAgICAnPic6ICcmZ3Q7J1xyXG4gICAgICAgIH1bdGFnXSkpXHJcbn07XHJcblxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGdldEZ1bmRhbWVudGFsTGV2ZWxJZHMoYXBwbmFtZSkge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICAncHJvZ3JhbW1pbmcnOiBbXHJcbiAgICAgICAgICAgIDE5LFxyXG4gICAgICAgICAgICA0NCxcclxuICAgICAgICAgICAgNTcsXHJcbiAgICAgICAgICAgIDcwLFxyXG4gICAgICAgICAgICAxMDZcclxuICAgICAgICBdLFxyXG4gICAgICAgICdkaWdpdGFsJzogW1xyXG4gICAgICAgICAgICA2LFxyXG4gICAgICAgICAgICA3LFxyXG4gICAgICAgICAgICA4LFxyXG4gICAgICAgICAgICAyMyxcclxuICAgICAgICAgICAgMjQsXHJcbiAgICAgICAgICAgIDI1LFxyXG4gICAgICAgICAgICAyNyxcclxuICAgICAgICAgICAgMzMsXHJcbiAgICAgICAgICAgIDM1LFxyXG4gICAgICAgICAgICA0MFxyXG4gICAgICAgIF0sXHJcbiAgICAgICAgJ2NyZWF0aXZlJzogW1xyXG4gICAgICAgICAgICAyMyxcclxuICAgICAgICAgICAgMjQsXHJcbiAgICAgICAgICAgIDQyLFxyXG4gICAgICAgICAgICA1MlxyXG4gICAgICAgIF1cclxuICAgIH1bYXBwbmFtZV07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRQcm9mZXNzaW9uSW5zdGFuY2VJZHMoYXBwbmFtZSkge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICAvLyBDb21tZW50ZWQgYXJlIGZvciBRQVxyXG4gICAgICAgICdwcm9ncmFtbWluZyc6IFtcclxuICAgICAgICAgICAgMTAwNyxcclxuICAgICAgICAgICAgMTAwOSxcclxuICAgICAgICAgICAgMTAxMCxcclxuICAgICAgICAgICAgMTAxMSxcclxuICAgICAgICAgICAgMTAxMixcclxuICAgICAgICAgICAgMTAxMyxcclxuICAgICAgICAgICAgMTAxNCxcclxuICAgICAgICAgICAgMTAxNSxcclxuICAgICAgICAgICAgMTAxNixcclxuICAgICAgICAgICAgMTAxNyxcclxuICAgICAgICAgICAgMTAxOCxcclxuICAgICAgICAgICAgMTAyMCxcclxuICAgICAgICAgICAgMTAyMixcclxuICAgICAgICAgICAgMTAyMyxcclxuICAgICAgICAgICAgMTAyNCxcclxuICAgICAgICAgICAgMTAyNSxcclxuICAgICAgICAgICAgMTAyNixcclxuICAgICAgICAgICAgLy8gMTAyOCxcclxuICAgICAgICAgICAgMTAyOSxcclxuICAgICAgICAgICAgMTAzMCxcclxuICAgICAgICAgICAgMTAzMSxcclxuICAgICAgICAgICAgMTAzMixcclxuICAgICAgICAgICAgMTAzMyxcclxuICAgICAgICAgICAgMTAzNCxcclxuICAgICAgICAgICAgMTAzNSxcclxuICAgICAgICAgICAgMTAzNixcclxuICAgICAgICAgICAgMTAzNyxcclxuICAgICAgICAgICAgMTAzOCxcclxuICAgICAgICAgICAgMTAzOSxcclxuICAgICAgICAgICAgMTA0MCxcclxuICAgICAgICAgICAgMTA0MSxcclxuICAgICAgICAgICAgMTA0MixcclxuICAgICAgICAgICAgMTA0MyxcclxuICAgICAgICAgICAgMTA0NCxcclxuICAgICAgICAgICAgMTA0NSxcclxuICAgICAgICAgICAgMTA0NixcclxuICAgICAgICAgICAgMTA0NyxcclxuICAgICAgICAgICAgMTA0OCxcclxuICAgICAgICAgICAgMTA0OSxcclxuICAgICAgICAgICAgMTA1MCxcclxuICAgICAgICAgICAgMTA1MSxcclxuICAgICAgICAgICAgMTA1MixcclxuICAgICAgICAgICAgMTA1MyxcclxuICAgICAgICAgICAgMTA1NCxcclxuICAgICAgICAgICAgMTA1NSxcclxuICAgICAgICAgICAgMTA1NixcclxuICAgICAgICAgICAgMTA1NyxcclxuICAgICAgICAgICAgMTA1OCxcclxuICAgICAgICAgICAgMTA1OSxcclxuICAgICAgICAgICAgMTA2MCxcclxuICAgICAgICAgICAgMTA2MSxcclxuICAgICAgICAgICAgMTA2MixcclxuICAgICAgICAgICAgMTA2MyxcclxuICAgICAgICAgICAgMTA2NCxcclxuICAgICAgICAgICAgMTA2NSxcclxuICAgICAgICAgICAgMTA2NixcclxuICAgICAgICAgICAgLy8gMTA2NyxcclxuICAgICAgICAgICAgLy8gMTA2OCxcclxuICAgICAgICAgICAgLy8gMTA2OSxcclxuICAgICAgICAgICAgMTA3MCxcclxuICAgICAgICAgICAgMTA3MSxcclxuICAgICAgICAgICAgMTA3MixcclxuICAgICAgICAgICAgMTA3MyxcclxuICAgICAgICAgICAgMTA3NCxcclxuICAgICAgICAgICAgMTA3NSxcclxuICAgICAgICAgICAgMTA3NixcclxuICAgICAgICAgICAgMTA3NyxcclxuICAgICAgICAgICAgMTA3OFxyXG4gICAgICAgIF0sXHJcbiAgICAgICAgJ2RpZ2l0YWwnOiBbXHJcbiAgICAgICAgICAgIDEsXHJcbiAgICAgICAgICAgIDMsXHJcbiAgICAgICAgICAgIDQsXHJcbiAgICAgICAgICAgIDUsXHJcbiAgICAgICAgICAgIDYsXHJcbiAgICAgICAgICAgIDcsXHJcbiAgICAgICAgICAgIDgsXHJcbiAgICAgICAgICAgIDlcclxuICAgICAgICBdLFxyXG4gICAgICAgICdjcmVhdGl2ZSc6IFtcclxuICAgICAgICAgICAgMSxcclxuICAgICAgICAgICAgMyxcclxuICAgICAgICAgICAgNCxcclxuICAgICAgICAgICAgNVxyXG4gICAgICAgIF0sXHJcbiAgICAgICAgJ2RldmRpZ2l0YWwnOiBbXHJcbiAgICAgICAgICAgIDEsXHJcbiAgICAgICAgICAgIDMsXHJcbiAgICAgICAgICAgIDQsXHJcbiAgICAgICAgICAgIDUsXHJcbiAgICAgICAgICAgIDYsXHJcbiAgICAgICAgICAgIDcsXHJcbiAgICAgICAgICAgIDgsXHJcbiAgICAgICAgICAgIDlcclxuICAgICAgICBdLFxyXG4gICAgICAgICdhaSc6W11cclxuICAgIH1bYXBwbmFtZV07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRFeGNsdWRlZE1vZHVsZXMoYXBwbmFtZSkge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICAncHJvZ3JhbW1pbmcnOiBbXHJcbiAgICAgICAgICAgIDJcclxuICAgICAgICBdXHJcbiAgICB9W2FwcG5hbWVdO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0RXhjbHVkZWRNb2R1bGVJbnN0YW5jZXMoYXBwbmFtZSkge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICAnZGlnaXRhbCc6IFtcclxuICAgICAgICAgICAgNSxcclxuICAgICAgICAgICAgNTBcclxuICAgICAgICBdLFxyXG4gICAgICAgICdjcmVhdGl2ZSc6IFtcclxuICAgICAgICAgICAgMSxcclxuICAgICAgICAgICAgMTQsXHJcbiAgICAgICAgICAgIDI4LFxyXG4gICAgICAgICAgICA0NlxyXG4gICAgICAgIF0sXHJcbiAgICAgICAgJ2RldmRpZ2l0YWwnOiBbXHJcbiAgICAgICAgICAgIDUsXHJcbiAgICAgICAgICAgIDUwXHJcbiAgICAgICAgXSxcclxuICAgIH1bYXBwbmFtZV07XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBAZGVzY3JpcHRpb24gUm91bmRzIHVwIGEgbnVtYmVyIHVwIHRvIHNwZWNpZmllZCBudW1iZXIgb2YgZGVjaW1hbCBwbGFjZXMgdXNpbmcgYSBzcGVjaWZpZWQgbnVtYmVyIG9mIGRlY2ltYWwgcGxhY2VzIGFzIHByZWNpc2lvbi5cclxuICogVGhpcyBhbGxvd3MgY29ycmVjdCByb3VuZGluZyBvZiBwcm9ibGVtYXRpYyBmbG9hdGluZyBwb2ludCBudW1iZXJzIGxpa2UgXCI1NS4wMDAwMDAwMDAwMDAwMVwiIG9yIFwiMC40NjAwMDAwMDAwMDAwMDFcIlxyXG4gKiBAcGFyYW0ge051bWJlcn0gbnVtYmVyIFRoZSBudW1iZXIgdG8gcm91bmQgdXBcclxuICogQHBhcmFtIHtOdW1iZXJ9IGRlY2ltYWxQbGFjZXNUb1JvdW5kVG8gVGhlIG51bWJlciBvZiBkZWNpbWFsIHBsYWNlcyB0byByb3VuZCB0b1xyXG4gKiBAcGFyYW0ge051bWJlcn0gZGVjaW1hbFBsYWNlc1ByZWNpc2lvbiBUaGUgbnVtYmVyIG9mIGRlY2ltYWwgcGxhY2VzIHRoYXQgc2hvdWxkIGJlIGNvbnNpZGVyZWQgZm9yIHRoZSByb3VuZGluZy4gU2hvdWxkIGJlIGxhcmdlciB0aGFuIGRlY2ltYWxQbGFjZXNUb1JvdW5kVG9cclxuICogQHJldHVybnMgVGhlIHJvdW5kZWQgbnVtYmVyXHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gcm91bmRVcFdpdGhQcmVjaXNpb24obnVtYmVyLCBkZWNpbWFsUGxhY2VzVG9Sb3VuZFRvLCBkZWNpbWFsUGxhY2VzUHJlY2lzaW9uKSB7XHJcbiAgICBpZiAoZGVjaW1hbFBsYWNlc1ByZWNpc2lvbiA8PSBkZWNpbWFsUGxhY2VzVG9Sb3VuZFRvKSB7XHJcbiAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ2RlY2ltYWxQbGFjZXNQcmVjaXNpb24gc2hvdWxkIGJlIGxhcmdlciB0aGFuIGRlY2ltYWxQbGFjZXNUb1JvdW5kVG8nKTtcclxuICAgIH1cclxuXHJcbiAgICBsZXQgcHJlY2lzaW9uVmFsdWUgPSAxMCAqKiBkZWNpbWFsUGxhY2VzUHJlY2lzaW9uO1xyXG4gICAgbGV0IHJvdW5kaW5nVmFsdWUgPSAxMCAqKiBkZWNpbWFsUGxhY2VzVG9Sb3VuZFRvO1xyXG4gICAgbGV0IHJvdW5kaW5nVmFsdWVCaWdJbnQgPSBCaWdJbnQocm91bmRpbmdWYWx1ZSk7XHJcbiAgICBsZXQgcHJlY2lzaW9uRGlmZmVyZW5jZVZhbHVlID0gQmlnSW50KHByZWNpc2lvblZhbHVlIC8gcm91bmRpbmdWYWx1ZSk7XHJcblxyXG4gICAgbGV0IGJpZ0ludCA9IEJpZ0ludChNYXRoLnRydW5jKG51bWJlciAqIHByZWNpc2lvblZhbHVlKSk7XHJcbiAgICBsZXQgcm91bmRlZFBsYWNlc051bWJlclBhcnQgPSBiaWdJbnQgLyBwcmVjaXNpb25EaWZmZXJlbmNlVmFsdWU7XHJcblxyXG4gICAgbGV0IHByZWNpc2lvbkRpZmZlcmVuY2VMZWZ0b3ZlciA9IGJpZ0ludCAlIHByZWNpc2lvbkRpZmZlcmVuY2VWYWx1ZTtcclxuICAgIHJvdW5kZWRQbGFjZXNOdW1iZXJQYXJ0ICs9IHByZWNpc2lvbkRpZmZlcmVuY2VMZWZ0b3ZlciA+IDAgPyAxbiA6IDBuO1xyXG5cclxuICAgIGxldCBudW1iZXJQYXJ0ID0gcm91bmRlZFBsYWNlc051bWJlclBhcnQgLyByb3VuZGluZ1ZhbHVlQmlnSW50O1xyXG4gICAgbGV0IGRlY2ltYWxQYXJ0ID0gcm91bmRlZFBsYWNlc051bWJlclBhcnQgJSByb3VuZGluZ1ZhbHVlQmlnSW50O1xyXG5cclxuICAgIGxldCByb3VuZGVkTnVtID0gTnVtYmVyKGAke251bWJlclBhcnR9LiR7ZGVjaW1hbFBhcnQudG9TdHJpbmcoKS5wYWRTdGFydChkZWNpbWFsUGxhY2VzVG9Sb3VuZFRvLCAnMCcpfWApO1xyXG4gICAgcmV0dXJuIHJvdW5kZWROdW07XHJcbn0iLCIhZnVuY3Rpb24odSxEKXtcIm9iamVjdFwiPT10eXBlb2YgZXhwb3J0cyYmXCJ1bmRlZmluZWRcIiE9dHlwZW9mIG1vZHVsZT9tb2R1bGUuZXhwb3J0cz1EKCk6XCJmdW5jdGlvblwiPT10eXBlb2YgZGVmaW5lJiZkZWZpbmUuYW1kP2RlZmluZShEKTp1LkpTT041PUQoKX0odGhpcyxmdW5jdGlvbigpe1widXNlIHN0cmljdFwiO2Z1bmN0aW9uIHUodSxEKXtyZXR1cm4gdShEPXtleHBvcnRzOnt9fSxELmV4cG9ydHMpLEQuZXhwb3J0c312YXIgRD11KGZ1bmN0aW9uKHUpe3ZhciBEPXUuZXhwb3J0cz1cInVuZGVmaW5lZFwiIT10eXBlb2Ygd2luZG93JiZ3aW5kb3cuTWF0aD09TWF0aD93aW5kb3c6XCJ1bmRlZmluZWRcIiE9dHlwZW9mIHNlbGYmJnNlbGYuTWF0aD09TWF0aD9zZWxmOkZ1bmN0aW9uKFwicmV0dXJuIHRoaXNcIikoKTtcIm51bWJlclwiPT10eXBlb2YgX19nJiYoX19nPUQpfSksZT11KGZ1bmN0aW9uKHUpe3ZhciBEPXUuZXhwb3J0cz17dmVyc2lvbjpcIjIuNi41XCJ9O1wibnVtYmVyXCI9PXR5cGVvZiBfX2UmJihfX2U9RCl9KSx0PShlLnZlcnNpb24sZnVuY3Rpb24odSl7cmV0dXJuXCJvYmplY3RcIj09dHlwZW9mIHU/bnVsbCE9PXU6XCJmdW5jdGlvblwiPT10eXBlb2YgdX0pLHI9ZnVuY3Rpb24odSl7aWYoIXQodSkpdGhyb3cgVHlwZUVycm9yKHUrXCIgaXMgbm90IGFuIG9iamVjdCFcIik7cmV0dXJuIHV9LEY9ZnVuY3Rpb24odSl7dHJ5e3JldHVybiEhdSgpfWNhdGNoKHUpe3JldHVybiEwfX0sbj0hRihmdW5jdGlvbigpe3JldHVybiA3IT1PYmplY3QuZGVmaW5lUHJvcGVydHkoe30sXCJhXCIse2dldDpmdW5jdGlvbigpe3JldHVybiA3fX0pLmF9KSxDPUQuZG9jdW1lbnQsQT10KEMpJiZ0KEMuY3JlYXRlRWxlbWVudCksaT0hbiYmIUYoZnVuY3Rpb24oKXtyZXR1cm4gNyE9T2JqZWN0LmRlZmluZVByb3BlcnR5KCh1PVwiZGl2XCIsQT9DLmNyZWF0ZUVsZW1lbnQodSk6e30pLFwiYVwiLHtnZXQ6ZnVuY3Rpb24oKXtyZXR1cm4gN319KS5hO3ZhciB1fSksRT1PYmplY3QuZGVmaW5lUHJvcGVydHksbz17ZjpuP09iamVjdC5kZWZpbmVQcm9wZXJ0eTpmdW5jdGlvbih1LEQsZSl7aWYocih1KSxEPWZ1bmN0aW9uKHUsRCl7aWYoIXQodSkpcmV0dXJuIHU7dmFyIGUscjtpZihEJiZcImZ1bmN0aW9uXCI9PXR5cGVvZihlPXUudG9TdHJpbmcpJiYhdChyPWUuY2FsbCh1KSkpcmV0dXJuIHI7aWYoXCJmdW5jdGlvblwiPT10eXBlb2YoZT11LnZhbHVlT2YpJiYhdChyPWUuY2FsbCh1KSkpcmV0dXJuIHI7aWYoIUQmJlwiZnVuY3Rpb25cIj09dHlwZW9mKGU9dS50b1N0cmluZykmJiF0KHI9ZS5jYWxsKHUpKSlyZXR1cm4gcjt0aHJvdyBUeXBlRXJyb3IoXCJDYW4ndCBjb252ZXJ0IG9iamVjdCB0byBwcmltaXRpdmUgdmFsdWVcIil9KEQsITApLHIoZSksaSl0cnl7cmV0dXJuIEUodSxELGUpfWNhdGNoKHUpe31pZihcImdldFwiaW4gZXx8XCJzZXRcImluIGUpdGhyb3cgVHlwZUVycm9yKFwiQWNjZXNzb3JzIG5vdCBzdXBwb3J0ZWQhXCIpO3JldHVyblwidmFsdWVcImluIGUmJih1W0RdPWUudmFsdWUpLHV9fSxhPW4/ZnVuY3Rpb24odSxELGUpe3JldHVybiBvLmYodSxELGZ1bmN0aW9uKHUsRCl7cmV0dXJue2VudW1lcmFibGU6ISgxJnUpLGNvbmZpZ3VyYWJsZTohKDImdSksd3JpdGFibGU6ISg0JnUpLHZhbHVlOkR9fSgxLGUpKX06ZnVuY3Rpb24odSxELGUpe3JldHVybiB1W0RdPWUsdX0sYz17fS5oYXNPd25Qcm9wZXJ0eSxCPWZ1bmN0aW9uKHUsRCl7cmV0dXJuIGMuY2FsbCh1LEQpfSxzPTAsZj1NYXRoLnJhbmRvbSgpLGw9dShmdW5jdGlvbih1KXt2YXIgdD1EW1wiX19jb3JlLWpzX3NoYXJlZF9fXCJdfHwoRFtcIl9fY29yZS1qc19zaGFyZWRfX1wiXT17fSk7KHUuZXhwb3J0cz1mdW5jdGlvbih1LEQpe3JldHVybiB0W3VdfHwodFt1XT12b2lkIDAhPT1EP0Q6e30pfSkoXCJ2ZXJzaW9uc1wiLFtdKS5wdXNoKHt2ZXJzaW9uOmUudmVyc2lvbixtb2RlOlwiZ2xvYmFsXCIsY29weXJpZ2h0OlwiwqkgMjAxOSBEZW5pcyBQdXNoa2FyZXYgKHpsb2lyb2NrLnJ1KVwifSl9KShcIm5hdGl2ZS1mdW5jdGlvbi10by1zdHJpbmdcIixGdW5jdGlvbi50b1N0cmluZyksZD11KGZ1bmN0aW9uKHUpe3ZhciB0LHI9XCJTeW1ib2woXCIuY29uY2F0KHZvaWQgMD09PSh0PVwic3JjXCIpP1wiXCI6dCxcIilfXCIsKCsrcytmKS50b1N0cmluZygzNikpLEY9KFwiXCIrbCkuc3BsaXQoXCJ0b1N0cmluZ1wiKTtlLmluc3BlY3RTb3VyY2U9ZnVuY3Rpb24odSl7cmV0dXJuIGwuY2FsbCh1KX0sKHUuZXhwb3J0cz1mdW5jdGlvbih1LGUsdCxuKXt2YXIgQz1cImZ1bmN0aW9uXCI9PXR5cGVvZiB0O0MmJihCKHQsXCJuYW1lXCIpfHxhKHQsXCJuYW1lXCIsZSkpLHVbZV0hPT10JiYoQyYmKEIodCxyKXx8YSh0LHIsdVtlXT9cIlwiK3VbZV06Ri5qb2luKFN0cmluZyhlKSkpKSx1PT09RD91W2VdPXQ6bj91W2VdP3VbZV09dDphKHUsZSx0KTooZGVsZXRlIHVbZV0sYSh1LGUsdCkpKX0pKEZ1bmN0aW9uLnByb3RvdHlwZSxcInRvU3RyaW5nXCIsZnVuY3Rpb24oKXtyZXR1cm5cImZ1bmN0aW9uXCI9PXR5cGVvZiB0aGlzJiZ0aGlzW3JdfHxsLmNhbGwodGhpcyl9KX0pLHY9ZnVuY3Rpb24odSxELGUpe2lmKGZ1bmN0aW9uKHUpe2lmKFwiZnVuY3Rpb25cIiE9dHlwZW9mIHUpdGhyb3cgVHlwZUVycm9yKHUrXCIgaXMgbm90IGEgZnVuY3Rpb24hXCIpfSh1KSx2b2lkIDA9PT1EKXJldHVybiB1O3N3aXRjaChlKXtjYXNlIDE6cmV0dXJuIGZ1bmN0aW9uKGUpe3JldHVybiB1LmNhbGwoRCxlKX07Y2FzZSAyOnJldHVybiBmdW5jdGlvbihlLHQpe3JldHVybiB1LmNhbGwoRCxlLHQpfTtjYXNlIDM6cmV0dXJuIGZ1bmN0aW9uKGUsdCxyKXtyZXR1cm4gdS5jYWxsKEQsZSx0LHIpfX1yZXR1cm4gZnVuY3Rpb24oKXtyZXR1cm4gdS5hcHBseShELGFyZ3VtZW50cyl9fSxwPWZ1bmN0aW9uKHUsdCxyKXt2YXIgRixuLEMsQSxpPXUmcC5GLEU9dSZwLkcsbz11JnAuUyxjPXUmcC5QLEI9dSZwLkIscz1FP0Q6bz9EW3RdfHwoRFt0XT17fSk6KERbdF18fHt9KS5wcm90b3R5cGUsZj1FP2U6ZVt0XXx8KGVbdF09e30pLGw9Zi5wcm90b3R5cGV8fChmLnByb3RvdHlwZT17fSk7Zm9yKEYgaW4gRSYmKHI9dCkscilDPSgobj0haSYmcyYmdm9pZCAwIT09c1tGXSk/czpyKVtGXSxBPUImJm4/dihDLEQpOmMmJlwiZnVuY3Rpb25cIj09dHlwZW9mIEM/dihGdW5jdGlvbi5jYWxsLEMpOkMscyYmZChzLEYsQyx1JnAuVSksZltGXSE9QyYmYShmLEYsQSksYyYmbFtGXSE9QyYmKGxbRl09Qyl9O0QuY29yZT1lLHAuRj0xLHAuRz0yLHAuUz00LHAuUD04LHAuQj0xNixwLlc9MzIscC5VPTY0LHAuUj0xMjg7dmFyIGgsbT1wLGc9TWF0aC5jZWlsLHk9TWF0aC5mbG9vcix3PWZ1bmN0aW9uKHUpe3JldHVybiBpc05hTih1PSt1KT8wOih1PjA/eTpnKSh1KX0sUz0oaD0hMSxmdW5jdGlvbih1LEQpe3ZhciBlLHQscj1TdHJpbmcoZnVuY3Rpb24odSl7aWYobnVsbD09dSl0aHJvdyBUeXBlRXJyb3IoXCJDYW4ndCBjYWxsIG1ldGhvZCBvbiAgXCIrdSk7cmV0dXJuIHV9KHUpKSxGPXcoRCksbj1yLmxlbmd0aDtyZXR1cm4gRjwwfHxGPj1uP2g/XCJcIjp2b2lkIDA6KGU9ci5jaGFyQ29kZUF0KEYpKTw1NTI5Nnx8ZT41NjMxOXx8RisxPT09bnx8KHQ9ci5jaGFyQ29kZUF0KEYrMSkpPDU2MzIwfHx0PjU3MzQzP2g/ci5jaGFyQXQoRik6ZTpoP3Iuc2xpY2UoRixGKzIpOnQtNTYzMjArKGUtNTUyOTY8PDEwKSs2NTUzNn0pO20obS5QLFwiU3RyaW5nXCIse2NvZGVQb2ludEF0OmZ1bmN0aW9uKHUpe3JldHVybiBTKHRoaXMsdSl9fSk7ZS5TdHJpbmcuY29kZVBvaW50QXQ7dmFyIGI9TWF0aC5tYXgseD1NYXRoLm1pbixOPVN0cmluZy5mcm9tQ2hhckNvZGUsUD1TdHJpbmcuZnJvbUNvZGVQb2ludDttKG0uUyttLkYqKCEhUCYmMSE9UC5sZW5ndGgpLFwiU3RyaW5nXCIse2Zyb21Db2RlUG9pbnQ6ZnVuY3Rpb24odSl7Zm9yKHZhciBELGUsdCxyPWFyZ3VtZW50cyxGPVtdLG49YXJndW1lbnRzLmxlbmd0aCxDPTA7bj5DOyl7aWYoRD0rcltDKytdLHQ9MTExNDExMSwoKGU9dyhlPUQpKTwwP2IoZSt0LDApOngoZSx0KSkhPT1EKXRocm93IFJhbmdlRXJyb3IoRCtcIiBpcyBub3QgYSB2YWxpZCBjb2RlIHBvaW50XCIpO0YucHVzaChEPDY1NTM2P04oRCk6Tig1NTI5NisoKEQtPTY1NTM2KT4+MTApLEQlMTAyNCs1NjMyMCkpfXJldHVybiBGLmpvaW4oXCJcIil9fSk7ZS5TdHJpbmcuZnJvbUNvZGVQb2ludDt2YXIgXyxJLE8saixWLEosTSxrLEwsVCx6LEgsJCxSLEc9e1NwYWNlX1NlcGFyYXRvcjovW1xcdTE2ODBcXHUyMDAwLVxcdTIwMEFcXHUyMDJGXFx1MjA1RlxcdTMwMDBdLyxJRF9TdGFydDovW1xceEFBXFx4QjVcXHhCQVxceEMwLVxceEQ2XFx4RDgtXFx4RjZcXHhGOC1cXHUwMkMxXFx1MDJDNi1cXHUwMkQxXFx1MDJFMC1cXHUwMkU0XFx1MDJFQ1xcdTAyRUVcXHUwMzcwLVxcdTAzNzRcXHUwMzc2XFx1MDM3N1xcdTAzN0EtXFx1MDM3RFxcdTAzN0ZcXHUwMzg2XFx1MDM4OC1cXHUwMzhBXFx1MDM4Q1xcdTAzOEUtXFx1MDNBMVxcdTAzQTMtXFx1MDNGNVxcdTAzRjctXFx1MDQ4MVxcdTA0OEEtXFx1MDUyRlxcdTA1MzEtXFx1MDU1NlxcdTA1NTlcXHUwNTYxLVxcdTA1ODdcXHUwNUQwLVxcdTA1RUFcXHUwNUYwLVxcdTA1RjJcXHUwNjIwLVxcdTA2NEFcXHUwNjZFXFx1MDY2RlxcdTA2NzEtXFx1MDZEM1xcdTA2RDVcXHUwNkU1XFx1MDZFNlxcdTA2RUVcXHUwNkVGXFx1MDZGQS1cXHUwNkZDXFx1MDZGRlxcdTA3MTBcXHUwNzEyLVxcdTA3MkZcXHUwNzRELVxcdTA3QTVcXHUwN0IxXFx1MDdDQS1cXHUwN0VBXFx1MDdGNFxcdTA3RjVcXHUwN0ZBXFx1MDgwMC1cXHUwODE1XFx1MDgxQVxcdTA4MjRcXHUwODI4XFx1MDg0MC1cXHUwODU4XFx1MDg2MC1cXHUwODZBXFx1MDhBMC1cXHUwOEI0XFx1MDhCNi1cXHUwOEJEXFx1MDkwNC1cXHUwOTM5XFx1MDkzRFxcdTA5NTBcXHUwOTU4LVxcdTA5NjFcXHUwOTcxLVxcdTA5ODBcXHUwOTg1LVxcdTA5OENcXHUwOThGXFx1MDk5MFxcdTA5OTMtXFx1MDlBOFxcdTA5QUEtXFx1MDlCMFxcdTA5QjJcXHUwOUI2LVxcdTA5QjlcXHUwOUJEXFx1MDlDRVxcdTA5RENcXHUwOUREXFx1MDlERi1cXHUwOUUxXFx1MDlGMFxcdTA5RjFcXHUwOUZDXFx1MEEwNS1cXHUwQTBBXFx1MEEwRlxcdTBBMTBcXHUwQTEzLVxcdTBBMjhcXHUwQTJBLVxcdTBBMzBcXHUwQTMyXFx1MEEzM1xcdTBBMzVcXHUwQTM2XFx1MEEzOFxcdTBBMzlcXHUwQTU5LVxcdTBBNUNcXHUwQTVFXFx1MEE3Mi1cXHUwQTc0XFx1MEE4NS1cXHUwQThEXFx1MEE4Ri1cXHUwQTkxXFx1MEE5My1cXHUwQUE4XFx1MEFBQS1cXHUwQUIwXFx1MEFCMlxcdTBBQjNcXHUwQUI1LVxcdTBBQjlcXHUwQUJEXFx1MEFEMFxcdTBBRTBcXHUwQUUxXFx1MEFGOVxcdTBCMDUtXFx1MEIwQ1xcdTBCMEZcXHUwQjEwXFx1MEIxMy1cXHUwQjI4XFx1MEIyQS1cXHUwQjMwXFx1MEIzMlxcdTBCMzNcXHUwQjM1LVxcdTBCMzlcXHUwQjNEXFx1MEI1Q1xcdTBCNURcXHUwQjVGLVxcdTBCNjFcXHUwQjcxXFx1MEI4M1xcdTBCODUtXFx1MEI4QVxcdTBCOEUtXFx1MEI5MFxcdTBCOTItXFx1MEI5NVxcdTBCOTlcXHUwQjlBXFx1MEI5Q1xcdTBCOUVcXHUwQjlGXFx1MEJBM1xcdTBCQTRcXHUwQkE4LVxcdTBCQUFcXHUwQkFFLVxcdTBCQjlcXHUwQkQwXFx1MEMwNS1cXHUwQzBDXFx1MEMwRS1cXHUwQzEwXFx1MEMxMi1cXHUwQzI4XFx1MEMyQS1cXHUwQzM5XFx1MEMzRFxcdTBDNTgtXFx1MEM1QVxcdTBDNjBcXHUwQzYxXFx1MEM4MFxcdTBDODUtXFx1MEM4Q1xcdTBDOEUtXFx1MEM5MFxcdTBDOTItXFx1MENBOFxcdTBDQUEtXFx1MENCM1xcdTBDQjUtXFx1MENCOVxcdTBDQkRcXHUwQ0RFXFx1MENFMFxcdTBDRTFcXHUwQ0YxXFx1MENGMlxcdTBEMDUtXFx1MEQwQ1xcdTBEMEUtXFx1MEQxMFxcdTBEMTItXFx1MEQzQVxcdTBEM0RcXHUwRDRFXFx1MEQ1NC1cXHUwRDU2XFx1MEQ1Ri1cXHUwRDYxXFx1MEQ3QS1cXHUwRDdGXFx1MEQ4NS1cXHUwRDk2XFx1MEQ5QS1cXHUwREIxXFx1MERCMy1cXHUwREJCXFx1MERCRFxcdTBEQzAtXFx1MERDNlxcdTBFMDEtXFx1MEUzMFxcdTBFMzJcXHUwRTMzXFx1MEU0MC1cXHUwRTQ2XFx1MEU4MVxcdTBFODJcXHUwRTg0XFx1MEU4N1xcdTBFODhcXHUwRThBXFx1MEU4RFxcdTBFOTQtXFx1MEU5N1xcdTBFOTktXFx1MEU5RlxcdTBFQTEtXFx1MEVBM1xcdTBFQTVcXHUwRUE3XFx1MEVBQVxcdTBFQUJcXHUwRUFELVxcdTBFQjBcXHUwRUIyXFx1MEVCM1xcdTBFQkRcXHUwRUMwLVxcdTBFQzRcXHUwRUM2XFx1MEVEQy1cXHUwRURGXFx1MEYwMFxcdTBGNDAtXFx1MEY0N1xcdTBGNDktXFx1MEY2Q1xcdTBGODgtXFx1MEY4Q1xcdTEwMDAtXFx1MTAyQVxcdTEwM0ZcXHUxMDUwLVxcdTEwNTVcXHUxMDVBLVxcdTEwNURcXHUxMDYxXFx1MTA2NVxcdTEwNjZcXHUxMDZFLVxcdTEwNzBcXHUxMDc1LVxcdTEwODFcXHUxMDhFXFx1MTBBMC1cXHUxMEM1XFx1MTBDN1xcdTEwQ0RcXHUxMEQwLVxcdTEwRkFcXHUxMEZDLVxcdTEyNDhcXHUxMjRBLVxcdTEyNERcXHUxMjUwLVxcdTEyNTZcXHUxMjU4XFx1MTI1QS1cXHUxMjVEXFx1MTI2MC1cXHUxMjg4XFx1MTI4QS1cXHUxMjhEXFx1MTI5MC1cXHUxMkIwXFx1MTJCMi1cXHUxMkI1XFx1MTJCOC1cXHUxMkJFXFx1MTJDMFxcdTEyQzItXFx1MTJDNVxcdTEyQzgtXFx1MTJENlxcdTEyRDgtXFx1MTMxMFxcdTEzMTItXFx1MTMxNVxcdTEzMTgtXFx1MTM1QVxcdTEzODAtXFx1MTM4RlxcdTEzQTAtXFx1MTNGNVxcdTEzRjgtXFx1MTNGRFxcdTE0MDEtXFx1MTY2Q1xcdTE2NkYtXFx1MTY3RlxcdTE2ODEtXFx1MTY5QVxcdTE2QTAtXFx1MTZFQVxcdTE2RUUtXFx1MTZGOFxcdTE3MDAtXFx1MTcwQ1xcdTE3MEUtXFx1MTcxMVxcdTE3MjAtXFx1MTczMVxcdTE3NDAtXFx1MTc1MVxcdTE3NjAtXFx1MTc2Q1xcdTE3NkUtXFx1MTc3MFxcdTE3ODAtXFx1MTdCM1xcdTE3RDdcXHUxN0RDXFx1MTgyMC1cXHUxODc3XFx1MTg4MC1cXHUxODg0XFx1MTg4Ny1cXHUxOEE4XFx1MThBQVxcdTE4QjAtXFx1MThGNVxcdTE5MDAtXFx1MTkxRVxcdTE5NTAtXFx1MTk2RFxcdTE5NzAtXFx1MTk3NFxcdTE5ODAtXFx1MTlBQlxcdTE5QjAtXFx1MTlDOVxcdTFBMDAtXFx1MUExNlxcdTFBMjAtXFx1MUE1NFxcdTFBQTdcXHUxQjA1LVxcdTFCMzNcXHUxQjQ1LVxcdTFCNEJcXHUxQjgzLVxcdTFCQTBcXHUxQkFFXFx1MUJBRlxcdTFCQkEtXFx1MUJFNVxcdTFDMDAtXFx1MUMyM1xcdTFDNEQtXFx1MUM0RlxcdTFDNUEtXFx1MUM3RFxcdTFDODAtXFx1MUM4OFxcdTFDRTktXFx1MUNFQ1xcdTFDRUUtXFx1MUNGMVxcdTFDRjVcXHUxQ0Y2XFx1MUQwMC1cXHUxREJGXFx1MUUwMC1cXHUxRjE1XFx1MUYxOC1cXHUxRjFEXFx1MUYyMC1cXHUxRjQ1XFx1MUY0OC1cXHUxRjREXFx1MUY1MC1cXHUxRjU3XFx1MUY1OVxcdTFGNUJcXHUxRjVEXFx1MUY1Ri1cXHUxRjdEXFx1MUY4MC1cXHUxRkI0XFx1MUZCNi1cXHUxRkJDXFx1MUZCRVxcdTFGQzItXFx1MUZDNFxcdTFGQzYtXFx1MUZDQ1xcdTFGRDAtXFx1MUZEM1xcdTFGRDYtXFx1MUZEQlxcdTFGRTAtXFx1MUZFQ1xcdTFGRjItXFx1MUZGNFxcdTFGRjYtXFx1MUZGQ1xcdTIwNzFcXHUyMDdGXFx1MjA5MC1cXHUyMDlDXFx1MjEwMlxcdTIxMDdcXHUyMTBBLVxcdTIxMTNcXHUyMTE1XFx1MjExOS1cXHUyMTFEXFx1MjEyNFxcdTIxMjZcXHUyMTI4XFx1MjEyQS1cXHUyMTJEXFx1MjEyRi1cXHUyMTM5XFx1MjEzQy1cXHUyMTNGXFx1MjE0NS1cXHUyMTQ5XFx1MjE0RVxcdTIxNjAtXFx1MjE4OFxcdTJDMDAtXFx1MkMyRVxcdTJDMzAtXFx1MkM1RVxcdTJDNjAtXFx1MkNFNFxcdTJDRUItXFx1MkNFRVxcdTJDRjJcXHUyQ0YzXFx1MkQwMC1cXHUyRDI1XFx1MkQyN1xcdTJEMkRcXHUyRDMwLVxcdTJENjdcXHUyRDZGXFx1MkQ4MC1cXHUyRDk2XFx1MkRBMC1cXHUyREE2XFx1MkRBOC1cXHUyREFFXFx1MkRCMC1cXHUyREI2XFx1MkRCOC1cXHUyREJFXFx1MkRDMC1cXHUyREM2XFx1MkRDOC1cXHUyRENFXFx1MkREMC1cXHUyREQ2XFx1MkREOC1cXHUyRERFXFx1MkUyRlxcdTMwMDUtXFx1MzAwN1xcdTMwMjEtXFx1MzAyOVxcdTMwMzEtXFx1MzAzNVxcdTMwMzgtXFx1MzAzQ1xcdTMwNDEtXFx1MzA5NlxcdTMwOUQtXFx1MzA5RlxcdTMwQTEtXFx1MzBGQVxcdTMwRkMtXFx1MzBGRlxcdTMxMDUtXFx1MzEyRVxcdTMxMzEtXFx1MzE4RVxcdTMxQTAtXFx1MzFCQVxcdTMxRjAtXFx1MzFGRlxcdTM0MDAtXFx1NERCNVxcdTRFMDAtXFx1OUZFQVxcdUEwMDAtXFx1QTQ4Q1xcdUE0RDAtXFx1QTRGRFxcdUE1MDAtXFx1QTYwQ1xcdUE2MTAtXFx1QTYxRlxcdUE2MkFcXHVBNjJCXFx1QTY0MC1cXHVBNjZFXFx1QTY3Ri1cXHVBNjlEXFx1QTZBMC1cXHVBNkVGXFx1QTcxNy1cXHVBNzFGXFx1QTcyMi1cXHVBNzg4XFx1QTc4Qi1cXHVBN0FFXFx1QTdCMC1cXHVBN0I3XFx1QTdGNy1cXHVBODAxXFx1QTgwMy1cXHVBODA1XFx1QTgwNy1cXHVBODBBXFx1QTgwQy1cXHVBODIyXFx1QTg0MC1cXHVBODczXFx1QTg4Mi1cXHVBOEIzXFx1QThGMi1cXHVBOEY3XFx1QThGQlxcdUE4RkRcXHVBOTBBLVxcdUE5MjVcXHVBOTMwLVxcdUE5NDZcXHVBOTYwLVxcdUE5N0NcXHVBOTg0LVxcdUE5QjJcXHVBOUNGXFx1QTlFMC1cXHVBOUU0XFx1QTlFNi1cXHVBOUVGXFx1QTlGQS1cXHVBOUZFXFx1QUEwMC1cXHVBQTI4XFx1QUE0MC1cXHVBQTQyXFx1QUE0NC1cXHVBQTRCXFx1QUE2MC1cXHVBQTc2XFx1QUE3QVxcdUFBN0UtXFx1QUFBRlxcdUFBQjFcXHVBQUI1XFx1QUFCNlxcdUFBQjktXFx1QUFCRFxcdUFBQzBcXHVBQUMyXFx1QUFEQi1cXHVBQUREXFx1QUFFMC1cXHVBQUVBXFx1QUFGMi1cXHVBQUY0XFx1QUIwMS1cXHVBQjA2XFx1QUIwOS1cXHVBQjBFXFx1QUIxMS1cXHVBQjE2XFx1QUIyMC1cXHVBQjI2XFx1QUIyOC1cXHVBQjJFXFx1QUIzMC1cXHVBQjVBXFx1QUI1Qy1cXHVBQjY1XFx1QUI3MC1cXHVBQkUyXFx1QUMwMC1cXHVEN0EzXFx1RDdCMC1cXHVEN0M2XFx1RDdDQi1cXHVEN0ZCXFx1RjkwMC1cXHVGQTZEXFx1RkE3MC1cXHVGQUQ5XFx1RkIwMC1cXHVGQjA2XFx1RkIxMy1cXHVGQjE3XFx1RkIxRFxcdUZCMUYtXFx1RkIyOFxcdUZCMkEtXFx1RkIzNlxcdUZCMzgtXFx1RkIzQ1xcdUZCM0VcXHVGQjQwXFx1RkI0MVxcdUZCNDNcXHVGQjQ0XFx1RkI0Ni1cXHVGQkIxXFx1RkJEMy1cXHVGRDNEXFx1RkQ1MC1cXHVGRDhGXFx1RkQ5Mi1cXHVGREM3XFx1RkRGMC1cXHVGREZCXFx1RkU3MC1cXHVGRTc0XFx1RkU3Ni1cXHVGRUZDXFx1RkYyMS1cXHVGRjNBXFx1RkY0MS1cXHVGRjVBXFx1RkY2Ni1cXHVGRkJFXFx1RkZDMi1cXHVGRkM3XFx1RkZDQS1cXHVGRkNGXFx1RkZEMi1cXHVGRkQ3XFx1RkZEQS1cXHVGRkRDXXxcXHVEODAwW1xcdURDMDAtXFx1REMwQlxcdURDMEQtXFx1REMyNlxcdURDMjgtXFx1REMzQVxcdURDM0NcXHVEQzNEXFx1REMzRi1cXHVEQzREXFx1REM1MC1cXHVEQzVEXFx1REM4MC1cXHVEQ0ZBXFx1REQ0MC1cXHVERDc0XFx1REU4MC1cXHVERTlDXFx1REVBMC1cXHVERUQwXFx1REYwMC1cXHVERjFGXFx1REYyRC1cXHVERjRBXFx1REY1MC1cXHVERjc1XFx1REY4MC1cXHVERjlEXFx1REZBMC1cXHVERkMzXFx1REZDOC1cXHVERkNGXFx1REZEMS1cXHVERkQ1XXxcXHVEODAxW1xcdURDMDAtXFx1REM5RFxcdURDQjAtXFx1RENEM1xcdURDRDgtXFx1RENGQlxcdUREMDAtXFx1REQyN1xcdUREMzAtXFx1REQ2M1xcdURFMDAtXFx1REYzNlxcdURGNDAtXFx1REY1NVxcdURGNjAtXFx1REY2N118XFx1RDgwMltcXHVEQzAwLVxcdURDMDVcXHVEQzA4XFx1REMwQS1cXHVEQzM1XFx1REMzN1xcdURDMzhcXHVEQzNDXFx1REMzRi1cXHVEQzU1XFx1REM2MC1cXHVEQzc2XFx1REM4MC1cXHVEQzlFXFx1RENFMC1cXHVEQ0YyXFx1RENGNFxcdURDRjVcXHVERDAwLVxcdUREMTVcXHVERDIwLVxcdUREMzlcXHVERDgwLVxcdUREQjdcXHVEREJFXFx1RERCRlxcdURFMDBcXHVERTEwLVxcdURFMTNcXHVERTE1LVxcdURFMTdcXHVERTE5LVxcdURFMzNcXHVERTYwLVxcdURFN0NcXHVERTgwLVxcdURFOUNcXHVERUMwLVxcdURFQzdcXHVERUM5LVxcdURFRTRcXHVERjAwLVxcdURGMzVcXHVERjQwLVxcdURGNTVcXHVERjYwLVxcdURGNzJcXHVERjgwLVxcdURGOTFdfFxcdUQ4MDNbXFx1REMwMC1cXHVEQzQ4XFx1REM4MC1cXHVEQ0IyXFx1RENDMC1cXHVEQ0YyXXxcXHVEODA0W1xcdURDMDMtXFx1REMzN1xcdURDODMtXFx1RENBRlxcdURDRDAtXFx1RENFOFxcdUREMDMtXFx1REQyNlxcdURENTAtXFx1REQ3MlxcdURENzZcXHVERDgzLVxcdUREQjJcXHVEREMxLVxcdUREQzRcXHVERERBXFx1REREQ1xcdURFMDAtXFx1REUxMVxcdURFMTMtXFx1REUyQlxcdURFODAtXFx1REU4NlxcdURFODhcXHVERThBLVxcdURFOERcXHVERThGLVxcdURFOURcXHVERTlGLVxcdURFQThcXHVERUIwLVxcdURFREVcXHVERjA1LVxcdURGMENcXHVERjBGXFx1REYxMFxcdURGMTMtXFx1REYyOFxcdURGMkEtXFx1REYzMFxcdURGMzJcXHVERjMzXFx1REYzNS1cXHVERjM5XFx1REYzRFxcdURGNTBcXHVERjVELVxcdURGNjFdfFxcdUQ4MDVbXFx1REMwMC1cXHVEQzM0XFx1REM0Ny1cXHVEQzRBXFx1REM4MC1cXHVEQ0FGXFx1RENDNFxcdURDQzVcXHVEQ0M3XFx1REQ4MC1cXHVEREFFXFx1REREOC1cXHVERERCXFx1REUwMC1cXHVERTJGXFx1REU0NFxcdURFODAtXFx1REVBQVxcdURGMDAtXFx1REYxOV18XFx1RDgwNltcXHVEQ0EwLVxcdURDREZcXHVEQ0ZGXFx1REUwMFxcdURFMEItXFx1REUzMlxcdURFM0FcXHVERTUwXFx1REU1Qy1cXHVERTgzXFx1REU4Ni1cXHVERTg5XFx1REVDMC1cXHVERUY4XXxcXHVEODA3W1xcdURDMDAtXFx1REMwOFxcdURDMEEtXFx1REMyRVxcdURDNDBcXHVEQzcyLVxcdURDOEZcXHVERDAwLVxcdUREMDZcXHVERDA4XFx1REQwOVxcdUREMEItXFx1REQzMFxcdURENDZdfFxcdUQ4MDhbXFx1REMwMC1cXHVERjk5XXxcXHVEODA5W1xcdURDMDAtXFx1REM2RVxcdURDODAtXFx1REQ0M118W1xcdUQ4MENcXHVEODFDLVxcdUQ4MjBcXHVEODQwLVxcdUQ4NjhcXHVEODZBLVxcdUQ4NkNcXHVEODZGLVxcdUQ4NzJcXHVEODc0LVxcdUQ4NzldW1xcdURDMDAtXFx1REZGRl18XFx1RDgwRFtcXHVEQzAwLVxcdURDMkVdfFxcdUQ4MTFbXFx1REMwMC1cXHVERTQ2XXxcXHVEODFBW1xcdURDMDAtXFx1REUzOFxcdURFNDAtXFx1REU1RVxcdURFRDAtXFx1REVFRFxcdURGMDAtXFx1REYyRlxcdURGNDAtXFx1REY0M1xcdURGNjMtXFx1REY3N1xcdURGN0QtXFx1REY4Rl18XFx1RDgxQltcXHVERjAwLVxcdURGNDRcXHVERjUwXFx1REY5My1cXHVERjlGXFx1REZFMFxcdURGRTFdfFxcdUQ4MjFbXFx1REMwMC1cXHVERkVDXXxcXHVEODIyW1xcdURDMDAtXFx1REVGMl18XFx1RDgyQ1tcXHVEQzAwLVxcdUREMUVcXHVERDcwLVxcdURFRkJdfFxcdUQ4MkZbXFx1REMwMC1cXHVEQzZBXFx1REM3MC1cXHVEQzdDXFx1REM4MC1cXHVEQzg4XFx1REM5MC1cXHVEQzk5XXxcXHVEODM1W1xcdURDMDAtXFx1REM1NFxcdURDNTYtXFx1REM5Q1xcdURDOUVcXHVEQzlGXFx1RENBMlxcdURDQTVcXHVEQ0E2XFx1RENBOS1cXHVEQ0FDXFx1RENBRS1cXHVEQ0I5XFx1RENCQlxcdURDQkQtXFx1RENDM1xcdURDQzUtXFx1REQwNVxcdUREMDctXFx1REQwQVxcdUREMEQtXFx1REQxNFxcdUREMTYtXFx1REQxQ1xcdUREMUUtXFx1REQzOVxcdUREM0ItXFx1REQzRVxcdURENDAtXFx1REQ0NFxcdURENDZcXHVERDRBLVxcdURENTBcXHVERDUyLVxcdURFQTVcXHVERUE4LVxcdURFQzBcXHVERUMyLVxcdURFREFcXHVERURDLVxcdURFRkFcXHVERUZDLVxcdURGMTRcXHVERjE2LVxcdURGMzRcXHVERjM2LVxcdURGNEVcXHVERjUwLVxcdURGNkVcXHVERjcwLVxcdURGODhcXHVERjhBLVxcdURGQThcXHVERkFBLVxcdURGQzJcXHVERkM0LVxcdURGQ0JdfFxcdUQ4M0FbXFx1REMwMC1cXHVEQ0M0XFx1REQwMC1cXHVERDQzXXxcXHVEODNCW1xcdURFMDAtXFx1REUwM1xcdURFMDUtXFx1REUxRlxcdURFMjFcXHVERTIyXFx1REUyNFxcdURFMjdcXHVERTI5LVxcdURFMzJcXHVERTM0LVxcdURFMzdcXHVERTM5XFx1REUzQlxcdURFNDJcXHVERTQ3XFx1REU0OVxcdURFNEJcXHVERTRELVxcdURFNEZcXHVERTUxXFx1REU1MlxcdURFNTRcXHVERTU3XFx1REU1OVxcdURFNUJcXHVERTVEXFx1REU1RlxcdURFNjFcXHVERTYyXFx1REU2NFxcdURFNjctXFx1REU2QVxcdURFNkMtXFx1REU3MlxcdURFNzQtXFx1REU3N1xcdURFNzktXFx1REU3Q1xcdURFN0VcXHVERTgwLVxcdURFODlcXHVERThCLVxcdURFOUJcXHVERUExLVxcdURFQTNcXHVERUE1LVxcdURFQTlcXHVERUFCLVxcdURFQkJdfFxcdUQ4NjlbXFx1REMwMC1cXHVERUQ2XFx1REYwMC1cXHVERkZGXXxcXHVEODZEW1xcdURDMDAtXFx1REYzNFxcdURGNDAtXFx1REZGRl18XFx1RDg2RVtcXHVEQzAwLVxcdURDMURcXHVEQzIwLVxcdURGRkZdfFxcdUQ4NzNbXFx1REMwMC1cXHVERUExXFx1REVCMC1cXHVERkZGXXxcXHVEODdBW1xcdURDMDAtXFx1REZFMF18XFx1RDg3RVtcXHVEQzAwLVxcdURFMURdLyxJRF9Db250aW51ZTovW1xceEFBXFx4QjVcXHhCQVxceEMwLVxceEQ2XFx4RDgtXFx4RjZcXHhGOC1cXHUwMkMxXFx1MDJDNi1cXHUwMkQxXFx1MDJFMC1cXHUwMkU0XFx1MDJFQ1xcdTAyRUVcXHUwMzAwLVxcdTAzNzRcXHUwMzc2XFx1MDM3N1xcdTAzN0EtXFx1MDM3RFxcdTAzN0ZcXHUwMzg2XFx1MDM4OC1cXHUwMzhBXFx1MDM4Q1xcdTAzOEUtXFx1MDNBMVxcdTAzQTMtXFx1MDNGNVxcdTAzRjctXFx1MDQ4MVxcdTA0ODMtXFx1MDQ4N1xcdTA0OEEtXFx1MDUyRlxcdTA1MzEtXFx1MDU1NlxcdTA1NTlcXHUwNTYxLVxcdTA1ODdcXHUwNTkxLVxcdTA1QkRcXHUwNUJGXFx1MDVDMVxcdTA1QzJcXHUwNUM0XFx1MDVDNVxcdTA1QzdcXHUwNUQwLVxcdTA1RUFcXHUwNUYwLVxcdTA1RjJcXHUwNjEwLVxcdTA2MUFcXHUwNjIwLVxcdTA2NjlcXHUwNjZFLVxcdTA2RDNcXHUwNkQ1LVxcdTA2RENcXHUwNkRGLVxcdTA2RThcXHUwNkVBLVxcdTA2RkNcXHUwNkZGXFx1MDcxMC1cXHUwNzRBXFx1MDc0RC1cXHUwN0IxXFx1MDdDMC1cXHUwN0Y1XFx1MDdGQVxcdTA4MDAtXFx1MDgyRFxcdTA4NDAtXFx1MDg1QlxcdTA4NjAtXFx1MDg2QVxcdTA4QTAtXFx1MDhCNFxcdTA4QjYtXFx1MDhCRFxcdTA4RDQtXFx1MDhFMVxcdTA4RTMtXFx1MDk2M1xcdTA5NjYtXFx1MDk2RlxcdTA5NzEtXFx1MDk4M1xcdTA5ODUtXFx1MDk4Q1xcdTA5OEZcXHUwOTkwXFx1MDk5My1cXHUwOUE4XFx1MDlBQS1cXHUwOUIwXFx1MDlCMlxcdTA5QjYtXFx1MDlCOVxcdTA5QkMtXFx1MDlDNFxcdTA5QzdcXHUwOUM4XFx1MDlDQi1cXHUwOUNFXFx1MDlEN1xcdTA5RENcXHUwOUREXFx1MDlERi1cXHUwOUUzXFx1MDlFNi1cXHUwOUYxXFx1MDlGQ1xcdTBBMDEtXFx1MEEwM1xcdTBBMDUtXFx1MEEwQVxcdTBBMEZcXHUwQTEwXFx1MEExMy1cXHUwQTI4XFx1MEEyQS1cXHUwQTMwXFx1MEEzMlxcdTBBMzNcXHUwQTM1XFx1MEEzNlxcdTBBMzhcXHUwQTM5XFx1MEEzQ1xcdTBBM0UtXFx1MEE0MlxcdTBBNDdcXHUwQTQ4XFx1MEE0Qi1cXHUwQTREXFx1MEE1MVxcdTBBNTktXFx1MEE1Q1xcdTBBNUVcXHUwQTY2LVxcdTBBNzVcXHUwQTgxLVxcdTBBODNcXHUwQTg1LVxcdTBBOERcXHUwQThGLVxcdTBBOTFcXHUwQTkzLVxcdTBBQThcXHUwQUFBLVxcdTBBQjBcXHUwQUIyXFx1MEFCM1xcdTBBQjUtXFx1MEFCOVxcdTBBQkMtXFx1MEFDNVxcdTBBQzctXFx1MEFDOVxcdTBBQ0ItXFx1MEFDRFxcdTBBRDBcXHUwQUUwLVxcdTBBRTNcXHUwQUU2LVxcdTBBRUZcXHUwQUY5LVxcdTBBRkZcXHUwQjAxLVxcdTBCMDNcXHUwQjA1LVxcdTBCMENcXHUwQjBGXFx1MEIxMFxcdTBCMTMtXFx1MEIyOFxcdTBCMkEtXFx1MEIzMFxcdTBCMzJcXHUwQjMzXFx1MEIzNS1cXHUwQjM5XFx1MEIzQy1cXHUwQjQ0XFx1MEI0N1xcdTBCNDhcXHUwQjRCLVxcdTBCNERcXHUwQjU2XFx1MEI1N1xcdTBCNUNcXHUwQjVEXFx1MEI1Ri1cXHUwQjYzXFx1MEI2Ni1cXHUwQjZGXFx1MEI3MVxcdTBCODJcXHUwQjgzXFx1MEI4NS1cXHUwQjhBXFx1MEI4RS1cXHUwQjkwXFx1MEI5Mi1cXHUwQjk1XFx1MEI5OVxcdTBCOUFcXHUwQjlDXFx1MEI5RVxcdTBCOUZcXHUwQkEzXFx1MEJBNFxcdTBCQTgtXFx1MEJBQVxcdTBCQUUtXFx1MEJCOVxcdTBCQkUtXFx1MEJDMlxcdTBCQzYtXFx1MEJDOFxcdTBCQ0EtXFx1MEJDRFxcdTBCRDBcXHUwQkQ3XFx1MEJFNi1cXHUwQkVGXFx1MEMwMC1cXHUwQzAzXFx1MEMwNS1cXHUwQzBDXFx1MEMwRS1cXHUwQzEwXFx1MEMxMi1cXHUwQzI4XFx1MEMyQS1cXHUwQzM5XFx1MEMzRC1cXHUwQzQ0XFx1MEM0Ni1cXHUwQzQ4XFx1MEM0QS1cXHUwQzREXFx1MEM1NVxcdTBDNTZcXHUwQzU4LVxcdTBDNUFcXHUwQzYwLVxcdTBDNjNcXHUwQzY2LVxcdTBDNkZcXHUwQzgwLVxcdTBDODNcXHUwQzg1LVxcdTBDOENcXHUwQzhFLVxcdTBDOTBcXHUwQzkyLVxcdTBDQThcXHUwQ0FBLVxcdTBDQjNcXHUwQ0I1LVxcdTBDQjlcXHUwQ0JDLVxcdTBDQzRcXHUwQ0M2LVxcdTBDQzhcXHUwQ0NBLVxcdTBDQ0RcXHUwQ0Q1XFx1MENENlxcdTBDREVcXHUwQ0UwLVxcdTBDRTNcXHUwQ0U2LVxcdTBDRUZcXHUwQ0YxXFx1MENGMlxcdTBEMDAtXFx1MEQwM1xcdTBEMDUtXFx1MEQwQ1xcdTBEMEUtXFx1MEQxMFxcdTBEMTItXFx1MEQ0NFxcdTBENDYtXFx1MEQ0OFxcdTBENEEtXFx1MEQ0RVxcdTBENTQtXFx1MEQ1N1xcdTBENUYtXFx1MEQ2M1xcdTBENjYtXFx1MEQ2RlxcdTBEN0EtXFx1MEQ3RlxcdTBEODJcXHUwRDgzXFx1MEQ4NS1cXHUwRDk2XFx1MEQ5QS1cXHUwREIxXFx1MERCMy1cXHUwREJCXFx1MERCRFxcdTBEQzAtXFx1MERDNlxcdTBEQ0FcXHUwRENGLVxcdTBERDRcXHUwREQ2XFx1MEREOC1cXHUwRERGXFx1MERFNi1cXHUwREVGXFx1MERGMlxcdTBERjNcXHUwRTAxLVxcdTBFM0FcXHUwRTQwLVxcdTBFNEVcXHUwRTUwLVxcdTBFNTlcXHUwRTgxXFx1MEU4MlxcdTBFODRcXHUwRTg3XFx1MEU4OFxcdTBFOEFcXHUwRThEXFx1MEU5NC1cXHUwRTk3XFx1MEU5OS1cXHUwRTlGXFx1MEVBMS1cXHUwRUEzXFx1MEVBNVxcdTBFQTdcXHUwRUFBXFx1MEVBQlxcdTBFQUQtXFx1MEVCOVxcdTBFQkItXFx1MEVCRFxcdTBFQzAtXFx1MEVDNFxcdTBFQzZcXHUwRUM4LVxcdTBFQ0RcXHUwRUQwLVxcdTBFRDlcXHUwRURDLVxcdTBFREZcXHUwRjAwXFx1MEYxOFxcdTBGMTlcXHUwRjIwLVxcdTBGMjlcXHUwRjM1XFx1MEYzN1xcdTBGMzlcXHUwRjNFLVxcdTBGNDdcXHUwRjQ5LVxcdTBGNkNcXHUwRjcxLVxcdTBGODRcXHUwRjg2LVxcdTBGOTdcXHUwRjk5LVxcdTBGQkNcXHUwRkM2XFx1MTAwMC1cXHUxMDQ5XFx1MTA1MC1cXHUxMDlEXFx1MTBBMC1cXHUxMEM1XFx1MTBDN1xcdTEwQ0RcXHUxMEQwLVxcdTEwRkFcXHUxMEZDLVxcdTEyNDhcXHUxMjRBLVxcdTEyNERcXHUxMjUwLVxcdTEyNTZcXHUxMjU4XFx1MTI1QS1cXHUxMjVEXFx1MTI2MC1cXHUxMjg4XFx1MTI4QS1cXHUxMjhEXFx1MTI5MC1cXHUxMkIwXFx1MTJCMi1cXHUxMkI1XFx1MTJCOC1cXHUxMkJFXFx1MTJDMFxcdTEyQzItXFx1MTJDNVxcdTEyQzgtXFx1MTJENlxcdTEyRDgtXFx1MTMxMFxcdTEzMTItXFx1MTMxNVxcdTEzMTgtXFx1MTM1QVxcdTEzNUQtXFx1MTM1RlxcdTEzODAtXFx1MTM4RlxcdTEzQTAtXFx1MTNGNVxcdTEzRjgtXFx1MTNGRFxcdTE0MDEtXFx1MTY2Q1xcdTE2NkYtXFx1MTY3RlxcdTE2ODEtXFx1MTY5QVxcdTE2QTAtXFx1MTZFQVxcdTE2RUUtXFx1MTZGOFxcdTE3MDAtXFx1MTcwQ1xcdTE3MEUtXFx1MTcxNFxcdTE3MjAtXFx1MTczNFxcdTE3NDAtXFx1MTc1M1xcdTE3NjAtXFx1MTc2Q1xcdTE3NkUtXFx1MTc3MFxcdTE3NzJcXHUxNzczXFx1MTc4MC1cXHUxN0QzXFx1MTdEN1xcdTE3RENcXHUxN0REXFx1MTdFMC1cXHUxN0U5XFx1MTgwQi1cXHUxODBEXFx1MTgxMC1cXHUxODE5XFx1MTgyMC1cXHUxODc3XFx1MTg4MC1cXHUxOEFBXFx1MThCMC1cXHUxOEY1XFx1MTkwMC1cXHUxOTFFXFx1MTkyMC1cXHUxOTJCXFx1MTkzMC1cXHUxOTNCXFx1MTk0Ni1cXHUxOTZEXFx1MTk3MC1cXHUxOTc0XFx1MTk4MC1cXHUxOUFCXFx1MTlCMC1cXHUxOUM5XFx1MTlEMC1cXHUxOUQ5XFx1MUEwMC1cXHUxQTFCXFx1MUEyMC1cXHUxQTVFXFx1MUE2MC1cXHUxQTdDXFx1MUE3Ri1cXHUxQTg5XFx1MUE5MC1cXHUxQTk5XFx1MUFBN1xcdTFBQjAtXFx1MUFCRFxcdTFCMDAtXFx1MUI0QlxcdTFCNTAtXFx1MUI1OVxcdTFCNkItXFx1MUI3M1xcdTFCODAtXFx1MUJGM1xcdTFDMDAtXFx1MUMzN1xcdTFDNDAtXFx1MUM0OVxcdTFDNEQtXFx1MUM3RFxcdTFDODAtXFx1MUM4OFxcdTFDRDAtXFx1MUNEMlxcdTFDRDQtXFx1MUNGOVxcdTFEMDAtXFx1MURGOVxcdTFERkItXFx1MUYxNVxcdTFGMTgtXFx1MUYxRFxcdTFGMjAtXFx1MUY0NVxcdTFGNDgtXFx1MUY0RFxcdTFGNTAtXFx1MUY1N1xcdTFGNTlcXHUxRjVCXFx1MUY1RFxcdTFGNUYtXFx1MUY3RFxcdTFGODAtXFx1MUZCNFxcdTFGQjYtXFx1MUZCQ1xcdTFGQkVcXHUxRkMyLVxcdTFGQzRcXHUxRkM2LVxcdTFGQ0NcXHUxRkQwLVxcdTFGRDNcXHUxRkQ2LVxcdTFGREJcXHUxRkUwLVxcdTFGRUNcXHUxRkYyLVxcdTFGRjRcXHUxRkY2LVxcdTFGRkNcXHUyMDNGXFx1MjA0MFxcdTIwNTRcXHUyMDcxXFx1MjA3RlxcdTIwOTAtXFx1MjA5Q1xcdTIwRDAtXFx1MjBEQ1xcdTIwRTFcXHUyMEU1LVxcdTIwRjBcXHUyMTAyXFx1MjEwN1xcdTIxMEEtXFx1MjExM1xcdTIxMTVcXHUyMTE5LVxcdTIxMURcXHUyMTI0XFx1MjEyNlxcdTIxMjhcXHUyMTJBLVxcdTIxMkRcXHUyMTJGLVxcdTIxMzlcXHUyMTNDLVxcdTIxM0ZcXHUyMTQ1LVxcdTIxNDlcXHUyMTRFXFx1MjE2MC1cXHUyMTg4XFx1MkMwMC1cXHUyQzJFXFx1MkMzMC1cXHUyQzVFXFx1MkM2MC1cXHUyQ0U0XFx1MkNFQi1cXHUyQ0YzXFx1MkQwMC1cXHUyRDI1XFx1MkQyN1xcdTJEMkRcXHUyRDMwLVxcdTJENjdcXHUyRDZGXFx1MkQ3Ri1cXHUyRDk2XFx1MkRBMC1cXHUyREE2XFx1MkRBOC1cXHUyREFFXFx1MkRCMC1cXHUyREI2XFx1MkRCOC1cXHUyREJFXFx1MkRDMC1cXHUyREM2XFx1MkRDOC1cXHUyRENFXFx1MkREMC1cXHUyREQ2XFx1MkREOC1cXHUyRERFXFx1MkRFMC1cXHUyREZGXFx1MkUyRlxcdTMwMDUtXFx1MzAwN1xcdTMwMjEtXFx1MzAyRlxcdTMwMzEtXFx1MzAzNVxcdTMwMzgtXFx1MzAzQ1xcdTMwNDEtXFx1MzA5NlxcdTMwOTlcXHUzMDlBXFx1MzA5RC1cXHUzMDlGXFx1MzBBMS1cXHUzMEZBXFx1MzBGQy1cXHUzMEZGXFx1MzEwNS1cXHUzMTJFXFx1MzEzMS1cXHUzMThFXFx1MzFBMC1cXHUzMUJBXFx1MzFGMC1cXHUzMUZGXFx1MzQwMC1cXHU0REI1XFx1NEUwMC1cXHU5RkVBXFx1QTAwMC1cXHVBNDhDXFx1QTREMC1cXHVBNEZEXFx1QTUwMC1cXHVBNjBDXFx1QTYxMC1cXHVBNjJCXFx1QTY0MC1cXHVBNjZGXFx1QTY3NC1cXHVBNjdEXFx1QTY3Ri1cXHVBNkYxXFx1QTcxNy1cXHVBNzFGXFx1QTcyMi1cXHVBNzg4XFx1QTc4Qi1cXHVBN0FFXFx1QTdCMC1cXHVBN0I3XFx1QTdGNy1cXHVBODI3XFx1QTg0MC1cXHVBODczXFx1QTg4MC1cXHVBOEM1XFx1QThEMC1cXHVBOEQ5XFx1QThFMC1cXHVBOEY3XFx1QThGQlxcdUE4RkRcXHVBOTAwLVxcdUE5MkRcXHVBOTMwLVxcdUE5NTNcXHVBOTYwLVxcdUE5N0NcXHVBOTgwLVxcdUE5QzBcXHVBOUNGLVxcdUE5RDlcXHVBOUUwLVxcdUE5RkVcXHVBQTAwLVxcdUFBMzZcXHVBQTQwLVxcdUFBNERcXHVBQTUwLVxcdUFBNTlcXHVBQTYwLVxcdUFBNzZcXHVBQTdBLVxcdUFBQzJcXHVBQURCLVxcdUFBRERcXHVBQUUwLVxcdUFBRUZcXHVBQUYyLVxcdUFBRjZcXHVBQjAxLVxcdUFCMDZcXHVBQjA5LVxcdUFCMEVcXHVBQjExLVxcdUFCMTZcXHVBQjIwLVxcdUFCMjZcXHVBQjI4LVxcdUFCMkVcXHVBQjMwLVxcdUFCNUFcXHVBQjVDLVxcdUFCNjVcXHVBQjcwLVxcdUFCRUFcXHVBQkVDXFx1QUJFRFxcdUFCRjAtXFx1QUJGOVxcdUFDMDAtXFx1RDdBM1xcdUQ3QjAtXFx1RDdDNlxcdUQ3Q0ItXFx1RDdGQlxcdUY5MDAtXFx1RkE2RFxcdUZBNzAtXFx1RkFEOVxcdUZCMDAtXFx1RkIwNlxcdUZCMTMtXFx1RkIxN1xcdUZCMUQtXFx1RkIyOFxcdUZCMkEtXFx1RkIzNlxcdUZCMzgtXFx1RkIzQ1xcdUZCM0VcXHVGQjQwXFx1RkI0MVxcdUZCNDNcXHVGQjQ0XFx1RkI0Ni1cXHVGQkIxXFx1RkJEMy1cXHVGRDNEXFx1RkQ1MC1cXHVGRDhGXFx1RkQ5Mi1cXHVGREM3XFx1RkRGMC1cXHVGREZCXFx1RkUwMC1cXHVGRTBGXFx1RkUyMC1cXHVGRTJGXFx1RkUzM1xcdUZFMzRcXHVGRTRELVxcdUZFNEZcXHVGRTcwLVxcdUZFNzRcXHVGRTc2LVxcdUZFRkNcXHVGRjEwLVxcdUZGMTlcXHVGRjIxLVxcdUZGM0FcXHVGRjNGXFx1RkY0MS1cXHVGRjVBXFx1RkY2Ni1cXHVGRkJFXFx1RkZDMi1cXHVGRkM3XFx1RkZDQS1cXHVGRkNGXFx1RkZEMi1cXHVGRkQ3XFx1RkZEQS1cXHVGRkRDXXxcXHVEODAwW1xcdURDMDAtXFx1REMwQlxcdURDMEQtXFx1REMyNlxcdURDMjgtXFx1REMzQVxcdURDM0NcXHVEQzNEXFx1REMzRi1cXHVEQzREXFx1REM1MC1cXHVEQzVEXFx1REM4MC1cXHVEQ0ZBXFx1REQ0MC1cXHVERDc0XFx1RERGRFxcdURFODAtXFx1REU5Q1xcdURFQTAtXFx1REVEMFxcdURFRTBcXHVERjAwLVxcdURGMUZcXHVERjJELVxcdURGNEFcXHVERjUwLVxcdURGN0FcXHVERjgwLVxcdURGOURcXHVERkEwLVxcdURGQzNcXHVERkM4LVxcdURGQ0ZcXHVERkQxLVxcdURGRDVdfFxcdUQ4MDFbXFx1REMwMC1cXHVEQzlEXFx1RENBMC1cXHVEQ0E5XFx1RENCMC1cXHVEQ0QzXFx1RENEOC1cXHVEQ0ZCXFx1REQwMC1cXHVERDI3XFx1REQzMC1cXHVERDYzXFx1REUwMC1cXHVERjM2XFx1REY0MC1cXHVERjU1XFx1REY2MC1cXHVERjY3XXxcXHVEODAyW1xcdURDMDAtXFx1REMwNVxcdURDMDhcXHVEQzBBLVxcdURDMzVcXHVEQzM3XFx1REMzOFxcdURDM0NcXHVEQzNGLVxcdURDNTVcXHVEQzYwLVxcdURDNzZcXHVEQzgwLVxcdURDOUVcXHVEQ0UwLVxcdURDRjJcXHVEQ0Y0XFx1RENGNVxcdUREMDAtXFx1REQxNVxcdUREMjAtXFx1REQzOVxcdUREODAtXFx1RERCN1xcdUREQkVcXHVEREJGXFx1REUwMC1cXHVERTAzXFx1REUwNVxcdURFMDZcXHVERTBDLVxcdURFMTNcXHVERTE1LVxcdURFMTdcXHVERTE5LVxcdURFMzNcXHVERTM4LVxcdURFM0FcXHVERTNGXFx1REU2MC1cXHVERTdDXFx1REU4MC1cXHVERTlDXFx1REVDMC1cXHVERUM3XFx1REVDOS1cXHVERUU2XFx1REYwMC1cXHVERjM1XFx1REY0MC1cXHVERjU1XFx1REY2MC1cXHVERjcyXFx1REY4MC1cXHVERjkxXXxcXHVEODAzW1xcdURDMDAtXFx1REM0OFxcdURDODAtXFx1RENCMlxcdURDQzAtXFx1RENGMl18XFx1RDgwNFtcXHVEQzAwLVxcdURDNDZcXHVEQzY2LVxcdURDNkZcXHVEQzdGLVxcdURDQkFcXHVEQ0QwLVxcdURDRThcXHVEQ0YwLVxcdURDRjlcXHVERDAwLVxcdUREMzRcXHVERDM2LVxcdUREM0ZcXHVERDUwLVxcdURENzNcXHVERDc2XFx1REQ4MC1cXHVEREM0XFx1RERDQS1cXHVERENDXFx1REREMC1cXHVERERBXFx1REREQ1xcdURFMDAtXFx1REUxMVxcdURFMTMtXFx1REUzN1xcdURFM0VcXHVERTgwLVxcdURFODZcXHVERTg4XFx1REU4QS1cXHVERThEXFx1REU4Ri1cXHVERTlEXFx1REU5Ri1cXHVERUE4XFx1REVCMC1cXHVERUVBXFx1REVGMC1cXHVERUY5XFx1REYwMC1cXHVERjAzXFx1REYwNS1cXHVERjBDXFx1REYwRlxcdURGMTBcXHVERjEzLVxcdURGMjhcXHVERjJBLVxcdURGMzBcXHVERjMyXFx1REYzM1xcdURGMzUtXFx1REYzOVxcdURGM0MtXFx1REY0NFxcdURGNDdcXHVERjQ4XFx1REY0Qi1cXHVERjREXFx1REY1MFxcdURGNTdcXHVERjVELVxcdURGNjNcXHVERjY2LVxcdURGNkNcXHVERjcwLVxcdURGNzRdfFxcdUQ4MDVbXFx1REMwMC1cXHVEQzRBXFx1REM1MC1cXHVEQzU5XFx1REM4MC1cXHVEQ0M1XFx1RENDN1xcdURDRDAtXFx1RENEOVxcdUREODAtXFx1RERCNVxcdUREQjgtXFx1RERDMFxcdURERDgtXFx1RERERFxcdURFMDAtXFx1REU0MFxcdURFNDRcXHVERTUwLVxcdURFNTlcXHVERTgwLVxcdURFQjdcXHVERUMwLVxcdURFQzlcXHVERjAwLVxcdURGMTlcXHVERjFELVxcdURGMkJcXHVERjMwLVxcdURGMzldfFxcdUQ4MDZbXFx1RENBMC1cXHVEQ0U5XFx1RENGRlxcdURFMDAtXFx1REUzRVxcdURFNDdcXHVERTUwLVxcdURFODNcXHVERTg2LVxcdURFOTlcXHVERUMwLVxcdURFRjhdfFxcdUQ4MDdbXFx1REMwMC1cXHVEQzA4XFx1REMwQS1cXHVEQzM2XFx1REMzOC1cXHVEQzQwXFx1REM1MC1cXHVEQzU5XFx1REM3Mi1cXHVEQzhGXFx1REM5Mi1cXHVEQ0E3XFx1RENBOS1cXHVEQ0I2XFx1REQwMC1cXHVERDA2XFx1REQwOFxcdUREMDlcXHVERDBCLVxcdUREMzZcXHVERDNBXFx1REQzQ1xcdUREM0RcXHVERDNGLVxcdURENDdcXHVERDUwLVxcdURENTldfFxcdUQ4MDhbXFx1REMwMC1cXHVERjk5XXxcXHVEODA5W1xcdURDMDAtXFx1REM2RVxcdURDODAtXFx1REQ0M118W1xcdUQ4MENcXHVEODFDLVxcdUQ4MjBcXHVEODQwLVxcdUQ4NjhcXHVEODZBLVxcdUQ4NkNcXHVEODZGLVxcdUQ4NzJcXHVEODc0LVxcdUQ4NzldW1xcdURDMDAtXFx1REZGRl18XFx1RDgwRFtcXHVEQzAwLVxcdURDMkVdfFxcdUQ4MTFbXFx1REMwMC1cXHVERTQ2XXxcXHVEODFBW1xcdURDMDAtXFx1REUzOFxcdURFNDAtXFx1REU1RVxcdURFNjAtXFx1REU2OVxcdURFRDAtXFx1REVFRFxcdURFRjAtXFx1REVGNFxcdURGMDAtXFx1REYzNlxcdURGNDAtXFx1REY0M1xcdURGNTAtXFx1REY1OVxcdURGNjMtXFx1REY3N1xcdURGN0QtXFx1REY4Rl18XFx1RDgxQltcXHVERjAwLVxcdURGNDRcXHVERjUwLVxcdURGN0VcXHVERjhGLVxcdURGOUZcXHVERkUwXFx1REZFMV18XFx1RDgyMVtcXHVEQzAwLVxcdURGRUNdfFxcdUQ4MjJbXFx1REMwMC1cXHVERUYyXXxcXHVEODJDW1xcdURDMDAtXFx1REQxRVxcdURENzAtXFx1REVGQl18XFx1RDgyRltcXHVEQzAwLVxcdURDNkFcXHVEQzcwLVxcdURDN0NcXHVEQzgwLVxcdURDODhcXHVEQzkwLVxcdURDOTlcXHVEQzlEXFx1REM5RV18XFx1RDgzNFtcXHVERDY1LVxcdURENjlcXHVERDZELVxcdURENzJcXHVERDdCLVxcdUREODJcXHVERDg1LVxcdUREOEJcXHVEREFBLVxcdUREQURcXHVERTQyLVxcdURFNDRdfFxcdUQ4MzVbXFx1REMwMC1cXHVEQzU0XFx1REM1Ni1cXHVEQzlDXFx1REM5RVxcdURDOUZcXHVEQ0EyXFx1RENBNVxcdURDQTZcXHVEQ0E5LVxcdURDQUNcXHVEQ0FFLVxcdURDQjlcXHVEQ0JCXFx1RENCRC1cXHVEQ0MzXFx1RENDNS1cXHVERDA1XFx1REQwNy1cXHVERDBBXFx1REQwRC1cXHVERDE0XFx1REQxNi1cXHVERDFDXFx1REQxRS1cXHVERDM5XFx1REQzQi1cXHVERDNFXFx1REQ0MC1cXHVERDQ0XFx1REQ0NlxcdURENEEtXFx1REQ1MFxcdURENTItXFx1REVBNVxcdURFQTgtXFx1REVDMFxcdURFQzItXFx1REVEQVxcdURFREMtXFx1REVGQVxcdURFRkMtXFx1REYxNFxcdURGMTYtXFx1REYzNFxcdURGMzYtXFx1REY0RVxcdURGNTAtXFx1REY2RVxcdURGNzAtXFx1REY4OFxcdURGOEEtXFx1REZBOFxcdURGQUEtXFx1REZDMlxcdURGQzQtXFx1REZDQlxcdURGQ0UtXFx1REZGRl18XFx1RDgzNltcXHVERTAwLVxcdURFMzZcXHVERTNCLVxcdURFNkNcXHVERTc1XFx1REU4NFxcdURFOUItXFx1REU5RlxcdURFQTEtXFx1REVBRl18XFx1RDgzOFtcXHVEQzAwLVxcdURDMDZcXHVEQzA4LVxcdURDMThcXHVEQzFCLVxcdURDMjFcXHVEQzIzXFx1REMyNFxcdURDMjYtXFx1REMyQV18XFx1RDgzQVtcXHVEQzAwLVxcdURDQzRcXHVEQ0QwLVxcdURDRDZcXHVERDAwLVxcdURENEFcXHVERDUwLVxcdURENTldfFxcdUQ4M0JbXFx1REUwMC1cXHVERTAzXFx1REUwNS1cXHVERTFGXFx1REUyMVxcdURFMjJcXHVERTI0XFx1REUyN1xcdURFMjktXFx1REUzMlxcdURFMzQtXFx1REUzN1xcdURFMzlcXHVERTNCXFx1REU0MlxcdURFNDdcXHVERTQ5XFx1REU0QlxcdURFNEQtXFx1REU0RlxcdURFNTFcXHVERTUyXFx1REU1NFxcdURFNTdcXHVERTU5XFx1REU1QlxcdURFNURcXHVERTVGXFx1REU2MVxcdURFNjJcXHVERTY0XFx1REU2Ny1cXHVERTZBXFx1REU2Qy1cXHVERTcyXFx1REU3NC1cXHVERTc3XFx1REU3OS1cXHVERTdDXFx1REU3RVxcdURFODAtXFx1REU4OVxcdURFOEItXFx1REU5QlxcdURFQTEtXFx1REVBM1xcdURFQTUtXFx1REVBOVxcdURFQUItXFx1REVCQl18XFx1RDg2OVtcXHVEQzAwLVxcdURFRDZcXHVERjAwLVxcdURGRkZdfFxcdUQ4NkRbXFx1REMwMC1cXHVERjM0XFx1REY0MC1cXHVERkZGXXxcXHVEODZFW1xcdURDMDAtXFx1REMxRFxcdURDMjAtXFx1REZGRl18XFx1RDg3M1tcXHVEQzAwLVxcdURFQTFcXHVERUIwLVxcdURGRkZdfFxcdUQ4N0FbXFx1REMwMC1cXHVERkUwXXxcXHVEODdFW1xcdURDMDAtXFx1REUxRF18XFx1REI0MFtcXHVERDAwLVxcdURERUZdL30sVT17aXNTcGFjZVNlcGFyYXRvcjpmdW5jdGlvbih1KXtyZXR1cm5cInN0cmluZ1wiPT10eXBlb2YgdSYmRy5TcGFjZV9TZXBhcmF0b3IudGVzdCh1KX0saXNJZFN0YXJ0Q2hhcjpmdW5jdGlvbih1KXtyZXR1cm5cInN0cmluZ1wiPT10eXBlb2YgdSYmKHU+PVwiYVwiJiZ1PD1cInpcInx8dT49XCJBXCImJnU8PVwiWlwifHxcIiRcIj09PXV8fFwiX1wiPT09dXx8Ry5JRF9TdGFydC50ZXN0KHUpKX0saXNJZENvbnRpbnVlQ2hhcjpmdW5jdGlvbih1KXtyZXR1cm5cInN0cmluZ1wiPT10eXBlb2YgdSYmKHU+PVwiYVwiJiZ1PD1cInpcInx8dT49XCJBXCImJnU8PVwiWlwifHx1Pj1cIjBcIiYmdTw9XCI5XCJ8fFwiJFwiPT09dXx8XCJfXCI9PT11fHxcIuKAjFwiPT09dXx8XCLigI1cIj09PXV8fEcuSURfQ29udGludWUudGVzdCh1KSl9LGlzRGlnaXQ6ZnVuY3Rpb24odSl7cmV0dXJuXCJzdHJpbmdcIj09dHlwZW9mIHUmJi9bMC05XS8udGVzdCh1KX0saXNIZXhEaWdpdDpmdW5jdGlvbih1KXtyZXR1cm5cInN0cmluZ1wiPT10eXBlb2YgdSYmL1swLTlBLUZhLWZdLy50ZXN0KHUpfX07ZnVuY3Rpb24gWigpe2ZvcihUPVwiZGVmYXVsdFwiLHo9XCJcIixIPSExLCQ9MTs7KXtSPXEoKTt2YXIgdT1YW1RdKCk7aWYodSlyZXR1cm4gdX19ZnVuY3Rpb24gcSgpe2lmKF9bal0pcmV0dXJuIFN0cmluZy5mcm9tQ29kZVBvaW50KF8uY29kZVBvaW50QXQoaikpfWZ1bmN0aW9uIFcoKXt2YXIgdT1xKCk7cmV0dXJuXCJcXG5cIj09PXU/KFYrKyxKPTApOnU/Sis9dS5sZW5ndGg6SisrLHUmJihqKz11Lmxlbmd0aCksdX12YXIgWD17ZGVmYXVsdDpmdW5jdGlvbigpe3N3aXRjaChSKXtjYXNlXCJcXHRcIjpjYXNlXCJcXHZcIjpjYXNlXCJcXGZcIjpjYXNlXCIgXCI6Y2FzZVwiwqBcIjpjYXNlXCJcXHVmZWZmXCI6Y2FzZVwiXFxuXCI6Y2FzZVwiXFxyXCI6Y2FzZVwiXFx1MjAyOFwiOmNhc2VcIlxcdTIwMjlcIjpyZXR1cm4gdm9pZCBXKCk7Y2FzZVwiL1wiOnJldHVybiBXKCksdm9pZChUPVwiY29tbWVudFwiKTtjYXNlIHZvaWQgMDpyZXR1cm4gVygpLEsoXCJlb2ZcIil9aWYoIVUuaXNTcGFjZVNlcGFyYXRvcihSKSlyZXR1cm4gWFtJXSgpO1coKX0sY29tbWVudDpmdW5jdGlvbigpe3N3aXRjaChSKXtjYXNlXCIqXCI6cmV0dXJuIFcoKSx2b2lkKFQ9XCJtdWx0aUxpbmVDb21tZW50XCIpO2Nhc2VcIi9cIjpyZXR1cm4gVygpLHZvaWQoVD1cInNpbmdsZUxpbmVDb21tZW50XCIpfXRocm93IHR1KFcoKSl9LG11bHRpTGluZUNvbW1lbnQ6ZnVuY3Rpb24oKXtzd2l0Y2goUil7Y2FzZVwiKlwiOnJldHVybiBXKCksdm9pZChUPVwibXVsdGlMaW5lQ29tbWVudEFzdGVyaXNrXCIpO2Nhc2Ugdm9pZCAwOnRocm93IHR1KFcoKSl9VygpfSxtdWx0aUxpbmVDb21tZW50QXN0ZXJpc2s6ZnVuY3Rpb24oKXtzd2l0Y2goUil7Y2FzZVwiKlwiOnJldHVybiB2b2lkIFcoKTtjYXNlXCIvXCI6cmV0dXJuIFcoKSx2b2lkKFQ9XCJkZWZhdWx0XCIpO2Nhc2Ugdm9pZCAwOnRocm93IHR1KFcoKSl9VygpLFQ9XCJtdWx0aUxpbmVDb21tZW50XCJ9LHNpbmdsZUxpbmVDb21tZW50OmZ1bmN0aW9uKCl7c3dpdGNoKFIpe2Nhc2VcIlxcblwiOmNhc2VcIlxcclwiOmNhc2VcIlxcdTIwMjhcIjpjYXNlXCJcXHUyMDI5XCI6cmV0dXJuIFcoKSx2b2lkKFQ9XCJkZWZhdWx0XCIpO2Nhc2Ugdm9pZCAwOnJldHVybiBXKCksSyhcImVvZlwiKX1XKCl9LHZhbHVlOmZ1bmN0aW9uKCl7c3dpdGNoKFIpe2Nhc2VcIntcIjpjYXNlXCJbXCI6cmV0dXJuIEsoXCJwdW5jdHVhdG9yXCIsVygpKTtjYXNlXCJuXCI6cmV0dXJuIFcoKSxRKFwidWxsXCIpLEsoXCJudWxsXCIsbnVsbCk7Y2FzZVwidFwiOnJldHVybiBXKCksUShcInJ1ZVwiKSxLKFwiYm9vbGVhblwiLCEwKTtjYXNlXCJmXCI6cmV0dXJuIFcoKSxRKFwiYWxzZVwiKSxLKFwiYm9vbGVhblwiLCExKTtjYXNlXCItXCI6Y2FzZVwiK1wiOnJldHVyblwiLVwiPT09VygpJiYoJD0tMSksdm9pZChUPVwic2lnblwiKTtjYXNlXCIuXCI6cmV0dXJuIHo9VygpLHZvaWQoVD1cImRlY2ltYWxQb2ludExlYWRpbmdcIik7Y2FzZVwiMFwiOnJldHVybiB6PVcoKSx2b2lkKFQ9XCJ6ZXJvXCIpO2Nhc2VcIjFcIjpjYXNlXCIyXCI6Y2FzZVwiM1wiOmNhc2VcIjRcIjpjYXNlXCI1XCI6Y2FzZVwiNlwiOmNhc2VcIjdcIjpjYXNlXCI4XCI6Y2FzZVwiOVwiOnJldHVybiB6PVcoKSx2b2lkKFQ9XCJkZWNpbWFsSW50ZWdlclwiKTtjYXNlXCJJXCI6cmV0dXJuIFcoKSxRKFwibmZpbml0eVwiKSxLKFwibnVtZXJpY1wiLDEvMCk7Y2FzZVwiTlwiOnJldHVybiBXKCksUShcImFOXCIpLEsoXCJudW1lcmljXCIsTmFOKTtjYXNlJ1wiJzpjYXNlXCInXCI6cmV0dXJuIEg9J1wiJz09PVcoKSx6PVwiXCIsdm9pZChUPVwic3RyaW5nXCIpfXRocm93IHR1KFcoKSl9LGlkZW50aWZpZXJOYW1lU3RhcnRFc2NhcGU6ZnVuY3Rpb24oKXtpZihcInVcIiE9PVIpdGhyb3cgdHUoVygpKTtXKCk7dmFyIHU9WSgpO3N3aXRjaCh1KXtjYXNlXCIkXCI6Y2FzZVwiX1wiOmJyZWFrO2RlZmF1bHQ6aWYoIVUuaXNJZFN0YXJ0Q2hhcih1KSl0aHJvdyBGdSgpfXorPXUsVD1cImlkZW50aWZpZXJOYW1lXCJ9LGlkZW50aWZpZXJOYW1lOmZ1bmN0aW9uKCl7c3dpdGNoKFIpe2Nhc2VcIiRcIjpjYXNlXCJfXCI6Y2FzZVwi4oCMXCI6Y2FzZVwi4oCNXCI6cmV0dXJuIHZvaWQoeis9VygpKTtjYXNlXCJcXFxcXCI6cmV0dXJuIFcoKSx2b2lkKFQ9XCJpZGVudGlmaWVyTmFtZUVzY2FwZVwiKX1pZighVS5pc0lkQ29udGludWVDaGFyKFIpKXJldHVybiBLKFwiaWRlbnRpZmllclwiLHopO3orPVcoKX0saWRlbnRpZmllck5hbWVFc2NhcGU6ZnVuY3Rpb24oKXtpZihcInVcIiE9PVIpdGhyb3cgdHUoVygpKTtXKCk7dmFyIHU9WSgpO3N3aXRjaCh1KXtjYXNlXCIkXCI6Y2FzZVwiX1wiOmNhc2VcIuKAjFwiOmNhc2VcIuKAjVwiOmJyZWFrO2RlZmF1bHQ6aWYoIVUuaXNJZENvbnRpbnVlQ2hhcih1KSl0aHJvdyBGdSgpfXorPXUsVD1cImlkZW50aWZpZXJOYW1lXCJ9LHNpZ246ZnVuY3Rpb24oKXtzd2l0Y2goUil7Y2FzZVwiLlwiOnJldHVybiB6PVcoKSx2b2lkKFQ9XCJkZWNpbWFsUG9pbnRMZWFkaW5nXCIpO2Nhc2VcIjBcIjpyZXR1cm4gej1XKCksdm9pZChUPVwiemVyb1wiKTtjYXNlXCIxXCI6Y2FzZVwiMlwiOmNhc2VcIjNcIjpjYXNlXCI0XCI6Y2FzZVwiNVwiOmNhc2VcIjZcIjpjYXNlXCI3XCI6Y2FzZVwiOFwiOmNhc2VcIjlcIjpyZXR1cm4gej1XKCksdm9pZChUPVwiZGVjaW1hbEludGVnZXJcIik7Y2FzZVwiSVwiOnJldHVybiBXKCksUShcIm5maW5pdHlcIiksSyhcIm51bWVyaWNcIiwkKigxLzApKTtjYXNlXCJOXCI6cmV0dXJuIFcoKSxRKFwiYU5cIiksSyhcIm51bWVyaWNcIixOYU4pfXRocm93IHR1KFcoKSl9LHplcm86ZnVuY3Rpb24oKXtzd2l0Y2goUil7Y2FzZVwiLlwiOnJldHVybiB6Kz1XKCksdm9pZChUPVwiZGVjaW1hbFBvaW50XCIpO2Nhc2VcImVcIjpjYXNlXCJFXCI6cmV0dXJuIHorPVcoKSx2b2lkKFQ9XCJkZWNpbWFsRXhwb25lbnRcIik7Y2FzZVwieFwiOmNhc2VcIlhcIjpyZXR1cm4geis9VygpLHZvaWQoVD1cImhleGFkZWNpbWFsXCIpfXJldHVybiBLKFwibnVtZXJpY1wiLDAqJCl9LGRlY2ltYWxJbnRlZ2VyOmZ1bmN0aW9uKCl7c3dpdGNoKFIpe2Nhc2VcIi5cIjpyZXR1cm4geis9VygpLHZvaWQoVD1cImRlY2ltYWxQb2ludFwiKTtjYXNlXCJlXCI6Y2FzZVwiRVwiOnJldHVybiB6Kz1XKCksdm9pZChUPVwiZGVjaW1hbEV4cG9uZW50XCIpfWlmKCFVLmlzRGlnaXQoUikpcmV0dXJuIEsoXCJudW1lcmljXCIsJCpOdW1iZXIoeikpO3orPVcoKX0sZGVjaW1hbFBvaW50TGVhZGluZzpmdW5jdGlvbigpe2lmKFUuaXNEaWdpdChSKSlyZXR1cm4geis9VygpLHZvaWQoVD1cImRlY2ltYWxGcmFjdGlvblwiKTt0aHJvdyB0dShXKCkpfSxkZWNpbWFsUG9pbnQ6ZnVuY3Rpb24oKXtzd2l0Y2goUil7Y2FzZVwiZVwiOmNhc2VcIkVcIjpyZXR1cm4geis9VygpLHZvaWQoVD1cImRlY2ltYWxFeHBvbmVudFwiKX1yZXR1cm4gVS5pc0RpZ2l0KFIpPyh6Kz1XKCksdm9pZChUPVwiZGVjaW1hbEZyYWN0aW9uXCIpKTpLKFwibnVtZXJpY1wiLCQqTnVtYmVyKHopKX0sZGVjaW1hbEZyYWN0aW9uOmZ1bmN0aW9uKCl7c3dpdGNoKFIpe2Nhc2VcImVcIjpjYXNlXCJFXCI6cmV0dXJuIHorPVcoKSx2b2lkKFQ9XCJkZWNpbWFsRXhwb25lbnRcIil9aWYoIVUuaXNEaWdpdChSKSlyZXR1cm4gSyhcIm51bWVyaWNcIiwkKk51bWJlcih6KSk7eis9VygpfSxkZWNpbWFsRXhwb25lbnQ6ZnVuY3Rpb24oKXtzd2l0Y2goUil7Y2FzZVwiK1wiOmNhc2VcIi1cIjpyZXR1cm4geis9VygpLHZvaWQoVD1cImRlY2ltYWxFeHBvbmVudFNpZ25cIil9aWYoVS5pc0RpZ2l0KFIpKXJldHVybiB6Kz1XKCksdm9pZChUPVwiZGVjaW1hbEV4cG9uZW50SW50ZWdlclwiKTt0aHJvdyB0dShXKCkpfSxkZWNpbWFsRXhwb25lbnRTaWduOmZ1bmN0aW9uKCl7aWYoVS5pc0RpZ2l0KFIpKXJldHVybiB6Kz1XKCksdm9pZChUPVwiZGVjaW1hbEV4cG9uZW50SW50ZWdlclwiKTt0aHJvdyB0dShXKCkpfSxkZWNpbWFsRXhwb25lbnRJbnRlZ2VyOmZ1bmN0aW9uKCl7aWYoIVUuaXNEaWdpdChSKSlyZXR1cm4gSyhcIm51bWVyaWNcIiwkKk51bWJlcih6KSk7eis9VygpfSxoZXhhZGVjaW1hbDpmdW5jdGlvbigpe2lmKFUuaXNIZXhEaWdpdChSKSlyZXR1cm4geis9VygpLHZvaWQoVD1cImhleGFkZWNpbWFsSW50ZWdlclwiKTt0aHJvdyB0dShXKCkpfSxoZXhhZGVjaW1hbEludGVnZXI6ZnVuY3Rpb24oKXtpZighVS5pc0hleERpZ2l0KFIpKXJldHVybiBLKFwibnVtZXJpY1wiLCQqTnVtYmVyKHopKTt6Kz1XKCl9LHN0cmluZzpmdW5jdGlvbigpe3N3aXRjaChSKXtjYXNlXCJcXFxcXCI6cmV0dXJuIFcoKSx2b2lkKHorPWZ1bmN0aW9uKCl7c3dpdGNoKHEoKSl7Y2FzZVwiYlwiOnJldHVybiBXKCksXCJcXGJcIjtjYXNlXCJmXCI6cmV0dXJuIFcoKSxcIlxcZlwiO2Nhc2VcIm5cIjpyZXR1cm4gVygpLFwiXFxuXCI7Y2FzZVwiclwiOnJldHVybiBXKCksXCJcXHJcIjtjYXNlXCJ0XCI6cmV0dXJuIFcoKSxcIlxcdFwiO2Nhc2VcInZcIjpyZXR1cm4gVygpLFwiXFx2XCI7Y2FzZVwiMFwiOmlmKFcoKSxVLmlzRGlnaXQocSgpKSl0aHJvdyB0dShXKCkpO3JldHVyblwiXFwwXCI7Y2FzZVwieFwiOnJldHVybiBXKCksZnVuY3Rpb24oKXt2YXIgdT1cIlwiLEQ9cSgpO2lmKCFVLmlzSGV4RGlnaXQoRCkpdGhyb3cgdHUoVygpKTtpZih1Kz1XKCksRD1xKCksIVUuaXNIZXhEaWdpdChEKSl0aHJvdyB0dShXKCkpO3JldHVybiB1Kz1XKCksU3RyaW5nLmZyb21Db2RlUG9pbnQocGFyc2VJbnQodSwxNikpfSgpO2Nhc2VcInVcIjpyZXR1cm4gVygpLFkoKTtjYXNlXCJcXG5cIjpjYXNlXCJcXHUyMDI4XCI6Y2FzZVwiXFx1MjAyOVwiOnJldHVybiBXKCksXCJcIjtjYXNlXCJcXHJcIjpyZXR1cm4gVygpLFwiXFxuXCI9PT1xKCkmJlcoKSxcIlwiO2Nhc2VcIjFcIjpjYXNlXCIyXCI6Y2FzZVwiM1wiOmNhc2VcIjRcIjpjYXNlXCI1XCI6Y2FzZVwiNlwiOmNhc2VcIjdcIjpjYXNlXCI4XCI6Y2FzZVwiOVwiOmNhc2Ugdm9pZCAwOnRocm93IHR1KFcoKSl9cmV0dXJuIFcoKX0oKSk7Y2FzZSdcIic6cmV0dXJuIEg/KFcoKSxLKFwic3RyaW5nXCIseikpOnZvaWQoeis9VygpKTtjYXNlXCInXCI6cmV0dXJuIEg/dm9pZCh6Kz1XKCkpOihXKCksSyhcInN0cmluZ1wiLHopKTtjYXNlXCJcXG5cIjpjYXNlXCJcXHJcIjp0aHJvdyB0dShXKCkpO2Nhc2VcIlxcdTIwMjhcIjpjYXNlXCJcXHUyMDI5XCI6IWZ1bmN0aW9uKHUpe2NvbnNvbGUud2FybihcIkpTT041OiAnXCIrbnUodSkrXCInIGluIHN0cmluZ3MgaXMgbm90IHZhbGlkIEVDTUFTY3JpcHQ7IGNvbnNpZGVyIGVzY2FwaW5nXCIpfShSKTticmVhaztjYXNlIHZvaWQgMDp0aHJvdyB0dShXKCkpfXorPVcoKX0sc3RhcnQ6ZnVuY3Rpb24oKXtzd2l0Y2goUil7Y2FzZVwie1wiOmNhc2VcIltcIjpyZXR1cm4gSyhcInB1bmN0dWF0b3JcIixXKCkpfVQ9XCJ2YWx1ZVwifSxiZWZvcmVQcm9wZXJ0eU5hbWU6ZnVuY3Rpb24oKXtzd2l0Y2goUil7Y2FzZVwiJFwiOmNhc2VcIl9cIjpyZXR1cm4gej1XKCksdm9pZChUPVwiaWRlbnRpZmllck5hbWVcIik7Y2FzZVwiXFxcXFwiOnJldHVybiBXKCksdm9pZChUPVwiaWRlbnRpZmllck5hbWVTdGFydEVzY2FwZVwiKTtjYXNlXCJ9XCI6cmV0dXJuIEsoXCJwdW5jdHVhdG9yXCIsVygpKTtjYXNlJ1wiJzpjYXNlXCInXCI6cmV0dXJuIEg9J1wiJz09PVcoKSx2b2lkKFQ9XCJzdHJpbmdcIil9aWYoVS5pc0lkU3RhcnRDaGFyKFIpKXJldHVybiB6Kz1XKCksdm9pZChUPVwiaWRlbnRpZmllck5hbWVcIik7dGhyb3cgdHUoVygpKX0sYWZ0ZXJQcm9wZXJ0eU5hbWU6ZnVuY3Rpb24oKXtpZihcIjpcIj09PVIpcmV0dXJuIEsoXCJwdW5jdHVhdG9yXCIsVygpKTt0aHJvdyB0dShXKCkpfSxiZWZvcmVQcm9wZXJ0eVZhbHVlOmZ1bmN0aW9uKCl7VD1cInZhbHVlXCJ9LGFmdGVyUHJvcGVydHlWYWx1ZTpmdW5jdGlvbigpe3N3aXRjaChSKXtjYXNlXCIsXCI6Y2FzZVwifVwiOnJldHVybiBLKFwicHVuY3R1YXRvclwiLFcoKSl9dGhyb3cgdHUoVygpKX0sYmVmb3JlQXJyYXlWYWx1ZTpmdW5jdGlvbigpe2lmKFwiXVwiPT09UilyZXR1cm4gSyhcInB1bmN0dWF0b3JcIixXKCkpO1Q9XCJ2YWx1ZVwifSxhZnRlckFycmF5VmFsdWU6ZnVuY3Rpb24oKXtzd2l0Y2goUil7Y2FzZVwiLFwiOmNhc2VcIl1cIjpyZXR1cm4gSyhcInB1bmN0dWF0b3JcIixXKCkpfXRocm93IHR1KFcoKSl9LGVuZDpmdW5jdGlvbigpe3Rocm93IHR1KFcoKSl9fTtmdW5jdGlvbiBLKHUsRCl7cmV0dXJue3R5cGU6dSx2YWx1ZTpELGxpbmU6Vixjb2x1bW46Sn19ZnVuY3Rpb24gUSh1KXtmb3IodmFyIEQ9MCxlPXU7RDxlLmxlbmd0aDtEKz0xKXt2YXIgdD1lW0RdO2lmKHEoKSE9PXQpdGhyb3cgdHUoVygpKTtXKCl9fWZ1bmN0aW9uIFkoKXtmb3IodmFyIHU9XCJcIixEPTQ7RC0tID4wOyl7dmFyIGU9cSgpO2lmKCFVLmlzSGV4RGlnaXQoZSkpdGhyb3cgdHUoVygpKTt1Kz1XKCl9cmV0dXJuIFN0cmluZy5mcm9tQ29kZVBvaW50KHBhcnNlSW50KHUsMTYpKX12YXIgdXU9e3N0YXJ0OmZ1bmN0aW9uKCl7aWYoXCJlb2ZcIj09PU0udHlwZSl0aHJvdyBydSgpO0R1KCl9LGJlZm9yZVByb3BlcnR5TmFtZTpmdW5jdGlvbigpe3N3aXRjaChNLnR5cGUpe2Nhc2VcImlkZW50aWZpZXJcIjpjYXNlXCJzdHJpbmdcIjpyZXR1cm4gaz1NLnZhbHVlLHZvaWQoST1cImFmdGVyUHJvcGVydHlOYW1lXCIpO2Nhc2VcInB1bmN0dWF0b3JcIjpyZXR1cm4gdm9pZCBldSgpO2Nhc2VcImVvZlwiOnRocm93IHJ1KCl9fSxhZnRlclByb3BlcnR5TmFtZTpmdW5jdGlvbigpe2lmKFwiZW9mXCI9PT1NLnR5cGUpdGhyb3cgcnUoKTtJPVwiYmVmb3JlUHJvcGVydHlWYWx1ZVwifSxiZWZvcmVQcm9wZXJ0eVZhbHVlOmZ1bmN0aW9uKCl7aWYoXCJlb2ZcIj09PU0udHlwZSl0aHJvdyBydSgpO0R1KCl9LGJlZm9yZUFycmF5VmFsdWU6ZnVuY3Rpb24oKXtpZihcImVvZlwiPT09TS50eXBlKXRocm93IHJ1KCk7XCJwdW5jdHVhdG9yXCIhPT1NLnR5cGV8fFwiXVwiIT09TS52YWx1ZT9EdSgpOmV1KCl9LGFmdGVyUHJvcGVydHlWYWx1ZTpmdW5jdGlvbigpe2lmKFwiZW9mXCI9PT1NLnR5cGUpdGhyb3cgcnUoKTtzd2l0Y2goTS52YWx1ZSl7Y2FzZVwiLFwiOnJldHVybiB2b2lkKEk9XCJiZWZvcmVQcm9wZXJ0eU5hbWVcIik7Y2FzZVwifVwiOmV1KCl9fSxhZnRlckFycmF5VmFsdWU6ZnVuY3Rpb24oKXtpZihcImVvZlwiPT09TS50eXBlKXRocm93IHJ1KCk7c3dpdGNoKE0udmFsdWUpe2Nhc2VcIixcIjpyZXR1cm4gdm9pZChJPVwiYmVmb3JlQXJyYXlWYWx1ZVwiKTtjYXNlXCJdXCI6ZXUoKX19LGVuZDpmdW5jdGlvbigpe319O2Z1bmN0aW9uIER1KCl7dmFyIHU7c3dpdGNoKE0udHlwZSl7Y2FzZVwicHVuY3R1YXRvclwiOnN3aXRjaChNLnZhbHVlKXtjYXNlXCJ7XCI6dT17fTticmVhaztjYXNlXCJbXCI6dT1bXX1icmVhaztjYXNlXCJudWxsXCI6Y2FzZVwiYm9vbGVhblwiOmNhc2VcIm51bWVyaWNcIjpjYXNlXCJzdHJpbmdcIjp1PU0udmFsdWV9aWYodm9pZCAwPT09TClMPXU7ZWxzZXt2YXIgRD1PW08ubGVuZ3RoLTFdO0FycmF5LmlzQXJyYXkoRCk/RC5wdXNoKHUpOkRba109dX1pZihudWxsIT09dSYmXCJvYmplY3RcIj09dHlwZW9mIHUpTy5wdXNoKHUpLEk9QXJyYXkuaXNBcnJheSh1KT9cImJlZm9yZUFycmF5VmFsdWVcIjpcImJlZm9yZVByb3BlcnR5TmFtZVwiO2Vsc2V7dmFyIGU9T1tPLmxlbmd0aC0xXTtJPW51bGw9PWU/XCJlbmRcIjpBcnJheS5pc0FycmF5KGUpP1wiYWZ0ZXJBcnJheVZhbHVlXCI6XCJhZnRlclByb3BlcnR5VmFsdWVcIn19ZnVuY3Rpb24gZXUoKXtPLnBvcCgpO3ZhciB1PU9bTy5sZW5ndGgtMV07ST1udWxsPT11P1wiZW5kXCI6QXJyYXkuaXNBcnJheSh1KT9cImFmdGVyQXJyYXlWYWx1ZVwiOlwiYWZ0ZXJQcm9wZXJ0eVZhbHVlXCJ9ZnVuY3Rpb24gdHUodSl7cmV0dXJuIEN1KHZvaWQgMD09PXU/XCJKU09ONTogaW52YWxpZCBlbmQgb2YgaW5wdXQgYXQgXCIrVitcIjpcIitKOlwiSlNPTjU6IGludmFsaWQgY2hhcmFjdGVyICdcIitudSh1KStcIicgYXQgXCIrVitcIjpcIitKKX1mdW5jdGlvbiBydSgpe3JldHVybiBDdShcIkpTT041OiBpbnZhbGlkIGVuZCBvZiBpbnB1dCBhdCBcIitWK1wiOlwiK0opfWZ1bmN0aW9uIEZ1KCl7cmV0dXJuIEN1KFwiSlNPTjU6IGludmFsaWQgaWRlbnRpZmllciBjaGFyYWN0ZXIgYXQgXCIrVitcIjpcIisoSi09NSkpfWZ1bmN0aW9uIG51KHUpe3ZhciBEPXtcIidcIjpcIlxcXFwnXCIsJ1wiJzonXFxcXFwiJyxcIlxcXFxcIjpcIlxcXFxcXFxcXCIsXCJcXGJcIjpcIlxcXFxiXCIsXCJcXGZcIjpcIlxcXFxmXCIsXCJcXG5cIjpcIlxcXFxuXCIsXCJcXHJcIjpcIlxcXFxyXCIsXCJcXHRcIjpcIlxcXFx0XCIsXCJcXHZcIjpcIlxcXFx2XCIsXCJcXDBcIjpcIlxcXFwwXCIsXCJcXHUyMDI4XCI6XCJcXFxcdTIwMjhcIixcIlxcdTIwMjlcIjpcIlxcXFx1MjAyOVwifTtpZihEW3VdKXJldHVybiBEW3VdO2lmKHU8XCIgXCIpe3ZhciBlPXUuY2hhckNvZGVBdCgwKS50b1N0cmluZygxNik7cmV0dXJuXCJcXFxceFwiKyhcIjAwXCIrZSkuc3Vic3RyaW5nKGUubGVuZ3RoKX1yZXR1cm4gdX1mdW5jdGlvbiBDdSh1KXt2YXIgRD1uZXcgU3ludGF4RXJyb3IodSk7cmV0dXJuIEQubGluZU51bWJlcj1WLEQuY29sdW1uTnVtYmVyPUosRH1yZXR1cm57cGFyc2U6ZnVuY3Rpb24odSxEKXtfPVN0cmluZyh1KSxJPVwic3RhcnRcIixPPVtdLGo9MCxWPTEsSj0wLE09dm9pZCAwLGs9dm9pZCAwLEw9dm9pZCAwO2Rve009WigpLHV1W0ldKCl9d2hpbGUoXCJlb2ZcIiE9PU0udHlwZSk7cmV0dXJuXCJmdW5jdGlvblwiPT10eXBlb2YgRD9mdW5jdGlvbiB1KEQsZSx0KXt2YXIgcj1EW2VdO2lmKG51bGwhPXImJlwib2JqZWN0XCI9PXR5cGVvZiByKWZvcih2YXIgRiBpbiByKXt2YXIgbj11KHIsRix0KTt2b2lkIDA9PT1uP2RlbGV0ZSByW0ZdOnJbRl09bn1yZXR1cm4gdC5jYWxsKEQsZSxyKX0oe1wiXCI6TH0sXCJcIixEKTpMfSxzdHJpbmdpZnk6ZnVuY3Rpb24odSxELGUpe3ZhciB0LHIsRixuPVtdLEM9XCJcIixBPVwiXCI7aWYobnVsbD09RHx8XCJvYmplY3RcIiE9dHlwZW9mIER8fEFycmF5LmlzQXJyYXkoRCl8fChlPUQuc3BhY2UsRj1ELnF1b3RlLEQ9RC5yZXBsYWNlciksXCJmdW5jdGlvblwiPT10eXBlb2YgRClyPUQ7ZWxzZSBpZihBcnJheS5pc0FycmF5KEQpKXt0PVtdO2Zvcih2YXIgaT0wLEU9RDtpPEUubGVuZ3RoO2krPTEpe3ZhciBvPUVbaV0sYT12b2lkIDA7XCJzdHJpbmdcIj09dHlwZW9mIG8/YT1vOihcIm51bWJlclwiPT10eXBlb2Ygb3x8byBpbnN0YW5jZW9mIFN0cmluZ3x8byBpbnN0YW5jZW9mIE51bWJlcikmJihhPVN0cmluZyhvKSksdm9pZCAwIT09YSYmdC5pbmRleE9mKGEpPDAmJnQucHVzaChhKX19cmV0dXJuIGUgaW5zdGFuY2VvZiBOdW1iZXI/ZT1OdW1iZXIoZSk6ZSBpbnN0YW5jZW9mIFN0cmluZyYmKGU9U3RyaW5nKGUpKSxcIm51bWJlclwiPT10eXBlb2YgZT9lPjAmJihlPU1hdGgubWluKDEwLE1hdGguZmxvb3IoZSkpLEE9XCIgICAgICAgICAgXCIuc3Vic3RyKDAsZSkpOlwic3RyaW5nXCI9PXR5cGVvZiBlJiYoQT1lLnN1YnN0cigwLDEwKSksYyhcIlwiLHtcIlwiOnV9KTtmdW5jdGlvbiBjKHUsRCl7dmFyIGU9RFt1XTtzd2l0Y2gobnVsbCE9ZSYmKFwiZnVuY3Rpb25cIj09dHlwZW9mIGUudG9KU09ONT9lPWUudG9KU09ONSh1KTpcImZ1bmN0aW9uXCI9PXR5cGVvZiBlLnRvSlNPTiYmKGU9ZS50b0pTT04odSkpKSxyJiYoZT1yLmNhbGwoRCx1LGUpKSxlIGluc3RhbmNlb2YgTnVtYmVyP2U9TnVtYmVyKGUpOmUgaW5zdGFuY2VvZiBTdHJpbmc/ZT1TdHJpbmcoZSk6ZSBpbnN0YW5jZW9mIEJvb2xlYW4mJihlPWUudmFsdWVPZigpKSxlKXtjYXNlIG51bGw6cmV0dXJuXCJudWxsXCI7Y2FzZSEwOnJldHVyblwidHJ1ZVwiO2Nhc2UhMTpyZXR1cm5cImZhbHNlXCJ9cmV0dXJuXCJzdHJpbmdcIj09dHlwZW9mIGU/QihlKTpcIm51bWJlclwiPT10eXBlb2YgZT9TdHJpbmcoZSk6XCJvYmplY3RcIj09dHlwZW9mIGU/QXJyYXkuaXNBcnJheShlKT9mdW5jdGlvbih1KXtpZihuLmluZGV4T2YodSk+PTApdGhyb3cgVHlwZUVycm9yKFwiQ29udmVydGluZyBjaXJjdWxhciBzdHJ1Y3R1cmUgdG8gSlNPTjVcIik7bi5wdXNoKHUpO3ZhciBEPUM7Qys9QTtmb3IodmFyIGUsdD1bXSxyPTA7cjx1Lmxlbmd0aDtyKyspe3ZhciBGPWMoU3RyaW5nKHIpLHUpO3QucHVzaCh2b2lkIDAhPT1GP0Y6XCJudWxsXCIpfWlmKDA9PT10Lmxlbmd0aCllPVwiW11cIjtlbHNlIGlmKFwiXCI9PT1BKXt2YXIgaT10LmpvaW4oXCIsXCIpO2U9XCJbXCIraStcIl1cIn1lbHNle3ZhciBFPVwiLFxcblwiK0Msbz10LmpvaW4oRSk7ZT1cIltcXG5cIitDK28rXCIsXFxuXCIrRCtcIl1cIn1yZXR1cm4gbi5wb3AoKSxDPUQsZX0oZSk6ZnVuY3Rpb24odSl7aWYobi5pbmRleE9mKHUpPj0wKXRocm93IFR5cGVFcnJvcihcIkNvbnZlcnRpbmcgY2lyY3VsYXIgc3RydWN0dXJlIHRvIEpTT041XCIpO24ucHVzaCh1KTt2YXIgRD1DO0MrPUE7Zm9yKHZhciBlLHIsRj10fHxPYmplY3Qua2V5cyh1KSxpPVtdLEU9MCxvPUY7RTxvLmxlbmd0aDtFKz0xKXt2YXIgYT1vW0VdLEI9YyhhLHUpO2lmKHZvaWQgMCE9PUIpe3ZhciBmPXMoYSkrXCI6XCI7XCJcIiE9PUEmJihmKz1cIiBcIiksZis9QixpLnB1c2goZil9fWlmKDA9PT1pLmxlbmd0aCllPVwie31cIjtlbHNlIGlmKFwiXCI9PT1BKXI9aS5qb2luKFwiLFwiKSxlPVwie1wiK3IrXCJ9XCI7ZWxzZXt2YXIgbD1cIixcXG5cIitDO3I9aS5qb2luKGwpLGU9XCJ7XFxuXCIrQytyK1wiLFxcblwiK0QrXCJ9XCJ9cmV0dXJuIG4ucG9wKCksQz1ELGV9KGUpOnZvaWQgMH1mdW5jdGlvbiBCKHUpe2Zvcih2YXIgRD17XCInXCI6LjEsJ1wiJzouMn0sZT17XCInXCI6XCJcXFxcJ1wiLCdcIic6J1xcXFxcIicsXCJcXFxcXCI6XCJcXFxcXFxcXFwiLFwiXFxiXCI6XCJcXFxcYlwiLFwiXFxmXCI6XCJcXFxcZlwiLFwiXFxuXCI6XCJcXFxcblwiLFwiXFxyXCI6XCJcXFxcclwiLFwiXFx0XCI6XCJcXFxcdFwiLFwiXFx2XCI6XCJcXFxcdlwiLFwiXFwwXCI6XCJcXFxcMFwiLFwiXFx1MjAyOFwiOlwiXFxcXHUyMDI4XCIsXCJcXHUyMDI5XCI6XCJcXFxcdTIwMjlcIn0sdD1cIlwiLHI9MDtyPHUubGVuZ3RoO3IrKyl7dmFyIG49dVtyXTtzd2l0Y2gobil7Y2FzZVwiJ1wiOmNhc2UnXCInOkRbbl0rKyx0Kz1uO2NvbnRpbnVlO2Nhc2VcIlxcMFwiOmlmKFUuaXNEaWdpdCh1W3IrMV0pKXt0Kz1cIlxcXFx4MDBcIjtjb250aW51ZX19aWYoZVtuXSl0Kz1lW25dO2Vsc2UgaWYobjxcIiBcIil7dmFyIEM9bi5jaGFyQ29kZUF0KDApLnRvU3RyaW5nKDE2KTt0Kz1cIlxcXFx4XCIrKFwiMDBcIitDKS5zdWJzdHJpbmcoQy5sZW5ndGgpfWVsc2UgdCs9bn12YXIgQT1GfHxPYmplY3Qua2V5cyhEKS5yZWR1Y2UoZnVuY3Rpb24odSxlKXtyZXR1cm4gRFt1XTxEW2VdP3U6ZX0pO3JldHVybiBBKyh0PXQucmVwbGFjZShuZXcgUmVnRXhwKEEsXCJnXCIpLGVbQV0pKStBfWZ1bmN0aW9uIHModSl7aWYoMD09PXUubGVuZ3RoKXJldHVybiBCKHUpO3ZhciBEPVN0cmluZy5mcm9tQ29kZVBvaW50KHUuY29kZVBvaW50QXQoMCkpO2lmKCFVLmlzSWRTdGFydENoYXIoRCkpcmV0dXJuIEIodSk7Zm9yKHZhciBlPUQubGVuZ3RoO2U8dS5sZW5ndGg7ZSsrKWlmKCFVLmlzSWRDb250aW51ZUNoYXIoU3RyaW5nLmZyb21Db2RlUG9pbnQodS5jb2RlUG9pbnRBdChlKSkpKXJldHVybiBCKHUpO3JldHVybiB1fX19fSk7XG4iLCIvLyBUaGUgbW9kdWxlIGNhY2hlXG52YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307XG5cbi8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG5mdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuXHR2YXIgY2FjaGVkTW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0aWYgKGNhY2hlZE1vZHVsZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0cmV0dXJuIGNhY2hlZE1vZHVsZS5leHBvcnRzO1xuXHR9XG5cdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG5cdHZhciBtb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdID0ge1xuXHRcdC8vIG5vIG1vZHVsZS5pZCBuZWVkZWRcblx0XHQvLyBubyBtb2R1bGUubG9hZGVkIG5lZWRlZFxuXHRcdGV4cG9ydHM6IHt9XG5cdH07XG5cblx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG5cdF9fd2VicGFja19tb2R1bGVzX19bbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG5cdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG5cdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbn1cblxuIiwiLy8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbl9fd2VicGFja19yZXF1aXJlX18ubiA9IChtb2R1bGUpID0+IHtcblx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG5cdFx0KCkgPT4gKG1vZHVsZVsnZGVmYXVsdCddKSA6XG5cdFx0KCkgPT4gKG1vZHVsZSk7XG5cdF9fd2VicGFja19yZXF1aXJlX18uZChnZXR0ZXIsIHsgYTogZ2V0dGVyIH0pO1xuXHRyZXR1cm4gZ2V0dGVyO1xufTsiLCIvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9ucyBmb3IgaGFybW9ueSBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSAoZXhwb3J0cywgZGVmaW5pdGlvbikgPT4ge1xuXHRmb3IodmFyIGtleSBpbiBkZWZpbml0aW9uKSB7XG5cdFx0aWYoX193ZWJwYWNrX3JlcXVpcmVfXy5vKGRlZmluaXRpb24sIGtleSkgJiYgIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBrZXkpKSB7XG5cdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywga2V5LCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZGVmaW5pdGlvbltrZXldIH0pO1xuXHRcdH1cblx0fVxufTsiLCJfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSAob2JqLCBwcm9wKSA9PiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iaiwgcHJvcCkpIiwiLy8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5yID0gKGV4cG9ydHMpID0+IHtcblx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG5cdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG5cdH1cblx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbn07IiwiaW1wb3J0IGRvbSBmcm9tICcuLi91dGlsL2pzeC1yZW5kZXItbW9kL2RvbSc7XHJcbmltcG9ydCB7IGdldFN1YnNpdGUsIGlzQWRtaW4gfSBmcm9tICcuLi91dGlsL3V0aWwnO1xyXG5pbXBvcnQgeyBSZW1vdGUgfSBmcm9tICcuLi91dGlsL3RlbXBsYXRlJztcclxuaW1wb3J0ICogYXMgU2VzQXBpIGZyb20gJy4uL3V0aWwvYXBpJztcclxuXHJcbmNvbnN0IGFwcE5hbWUgPSBnZXRTdWJzaXRlKCk7XHJcbmlmIChhcHBOYW1lID09ICdkaWdpdGFsJyB8fCBhcHBOYW1lID09ICdjcmVhdGl2ZScpIHtcclxuICAgIGluamVjdEJ1dHRvbigpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBpbmplY3RCdXR0b24oKSB7XHJcbiAgICBpZiAoaXNBZG1pbigpKSB7XHJcbiAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnLnNlcy1kaXYnKS5mb3JFYWNoKGUgPT4gZS5yZW1vdmUoKSk7XHJcblxyXG4gICAgICAgIGNvbnN0IGJsb2dVcmwgPSAvXFwvYmxvZ1xcLyguKykvLmV4ZWMod2luZG93LmxvY2F0aW9uLnBhdGhuYW1lKVsxXTtcclxuICAgICAgICBpZiAoYmxvZ1VybCkge1xyXG4gICAgICAgICAgICBjb25zdCBjb250ZW50ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnYXJ0aWNsZT5kaXYucm93Lm5vLW1hcmdpbi1vZmZzZXQuYm90dG9tLWJ1ZmZlci1sZycpWzBdO1xyXG4gICAgICAgICAgICBjb25zdCBlbGVtZW50ID0gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJvdyBuby1tYXJnaW4tb2Zmc2V0IGJvdHRvbS1idWZmZXItbGcgc2VzLWRpdlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxSZW1vdGUgc3JjPXsoKSA9PiBnZXRCbG9nSWQoYmxvZ1VybCl9IGNvbXBvbmVudD17ZWRpdEJ0bn0gY29sb3I9XCJibGFja1wiIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj4pO1xyXG4gICAgICAgICAgICBjb250ZW50LnBhcmVudEVsZW1lbnQuaW5zZXJ0QmVmb3JlKGVsZW1lbnQsIGNvbnRlbnQpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuZnVuY3Rpb24gZWRpdEJ0bihibG9nSWQpIHtcclxuICAgIGlmIChibG9nSWQgPT09IG51bGwpIHtcclxuICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuICg8YSBjbGFzcz1cImJ0bi1wcmltYXJ5IHB1cnBsZS1idG4gc2VzLWJ0blwiIGhyZWY9e2AvYWRtaW5pc3RyYXRpb25fY21zL25ld3MvZWRpdC8ke2Jsb2dJZH1gfT5FZGl0IGFydGljbGU8L2E+KTtcclxuICAgIH1cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZ2V0QmxvZ0lkKHVybCkge1xyXG4gICAgY29uc3QgYmxvZyA9IGF3YWl0IFNlc0FwaS5nZXRCbG9nQnlVcmwodXJsKTtcclxuICAgIGlmIChibG9nKSB7XHJcbiAgICAgICAgcmV0dXJuIGJsb2cuSWQ7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG59Il0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9