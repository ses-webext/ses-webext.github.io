/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/awesome-notifications/src/constants.js":
/*!*************************************************************!*\
  !*** ./node_modules/awesome-notifications/src/constants.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "eConsts": () => (/* binding */ eConsts),
/* harmony export */   "mConsts": () => (/* binding */ mConsts),
/* harmony export */   "tConsts": () => (/* binding */ tConsts)
/* harmony export */ });
const libName = "awn"
const prefix = {
  popup: `${libName}-popup`,
  toast: `${libName}-toast`,
  btn: `${libName}-btn`,
  confirm: `${libName}-confirm`
}

// Constants for toasts
const tConsts = {
  prefix: prefix.toast,
  klass: {
    label: `${prefix.toast}-label`,
    content: `${prefix.toast}-content`,
    icon: `${prefix.toast}-icon`,
    progressBar: `${prefix.toast}-progress-bar`,
    progressBarPause: `${prefix.toast}-progress-bar-paused`
  },
  ids: {
    container: `${prefix.toast}-container`
  }
}

// Constants for popups
const mConsts = {
  prefix: prefix.popup,
  klass: {
    buttons: `${libName}-buttons`,
    button: prefix.btn,
    successBtn: `${prefix.btn}-success`,
    cancelBtn: `${prefix.btn}-cancel`,
    title: `${prefix.popup}-title`,
    body: `${prefix.popup}-body`,
    content: `${prefix.popup}-content`,
    dotAnimation: `${prefix.popup}-loading-dots`
  },
  ids: {
    wrapper: `${prefix.popup}-wrapper`,
    confirmOk: `${prefix.confirm}-ok`,
    confirmCancel: `${prefix.confirm}-cancel`
  }
}

const eConsts = {
  klass: {
    hiding: `${libName}-hiding`
  },
  lib: libName
}


/***/ }),

/***/ "./node_modules/awesome-notifications/src/elem.js":
/*!********************************************************!*\
  !*** ./node_modules/awesome-notifications/src/elem.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./constants */ "./node_modules/awesome-notifications/src/constants.js");


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (class {
    constructor(parent, id, klass, style, options) {
        this.newNode = document.createElement('div')
        if (id) this.newNode.id = id
        if (klass) this.newNode.className = klass
        if (style) this.newNode.style.cssText = style
        this.parent = parent
        this.options = options
    }
    beforeInsert() {}
    afterInsert() {}
    insert() {
        this.beforeInsert()
        this.el = this.parent.appendChild(this.newNode)
        this.afterInsert()
        return this
    }

    replace(el) {
        if (!this.getElement()) return
        return this.beforeDelete().then(() => {
            this.updateType(el.type)
            this.parent.replaceChild(el.newNode, this.el)
            this.el = this.getElement(el.newNode)
            this.afterInsert()
            return this
        })
    }

    beforeDelete(el = this.el) {
        let timeLeft = 0
        if (this.start) {
            timeLeft = this.options.minDurations[this.type] + this.start - Date.now()
            if (timeLeft < 0) timeLeft = 0
        }

        return new Promise(resolve => {
            setTimeout(() => {
                el.classList.add(_constants__WEBPACK_IMPORTED_MODULE_0__.eConsts.klass.hiding)
                setTimeout(resolve, this.options.animationDuration)
            }, timeLeft)
        })
    }

    delete(el = this.el) {
        if (!this.getElement(el)) return null
        return this.beforeDelete(el).then(() => {
            el.remove()
            this.afterDelete()
        })
    }
    afterDelete() {}

    getElement(el = this.el) {
        if (!el) return null
        return document.getElementById(el.id)
    }

    addEvent(name, func) {
        this.el.addEventListener(name, func)
    }

    toggleClass(klass) {
        this.el.classList.toggle(klass)
    }
    updateType(type) {
        this.type = type
        this.duration = this.options.duration(this.type)
    }
});

/***/ }),

/***/ "./node_modules/awesome-notifications/src/index.js":
/*!*********************************************************!*\
  !*** ./node_modules/awesome-notifications/src/index.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Notifier)
/* harmony export */ });
/* harmony import */ var _options__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./options */ "./node_modules/awesome-notifications/src/options.js");
/* harmony import */ var _toast__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./toast */ "./node_modules/awesome-notifications/src/toast.js");
/* harmony import */ var _popup__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./popup */ "./node_modules/awesome-notifications/src/popup.js");
/* harmony import */ var _elem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./elem */ "./node_modules/awesome-notifications/src/elem.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./constants */ "./node_modules/awesome-notifications/src/constants.js");







class Notifier {
  constructor(options = {}) {
    this.options = new _options__WEBPACK_IMPORTED_MODULE_0__["default"](options)
  }

  tip(msg, options) {
    return this._addToast(msg, "tip", options).el
  }

  info(msg, options) {
    return this._addToast(msg, "info", options).el
  }

  success(msg, options) {
    return this._addToast(msg, "success", options).el
  }

  warning(msg, options) {
    return this._addToast(msg, "warning", options).el
  }

  alert(msg, options) {
    return this._addToast(msg, "alert", options).el
  }

  async (promise, onResolve, onReject, msg, options) {
    let asyncToast = this._addToast(msg, "async", options)
    return this._afterAsync(promise, onResolve, onReject, options, asyncToast)
  }

  confirm(msg, onOk, onCancel, options) {
    return this._addPopup(msg, "confirm", options, onOk, onCancel)
  }

  asyncBlock(promise, onResolve, onReject, msg, options) {
    let asyncBlock = this._addPopup(msg, "async-block", options)
    return this._afterAsync(promise, onResolve, onReject, options, asyncBlock)
  }

  modal(msg, className, options) {
    return this._addPopup(msg, className, options)
  }

  closeToasts() {
    let c = this.container
    while (c.firstChild) {
      c.removeChild(c.firstChild)
    }
  }

  // Tools
  _addPopup(msg, className, options, onOk, onCancel) {
    return new _popup__WEBPACK_IMPORTED_MODULE_2__["default"](msg, className, this.options.override(options), onOk, onCancel)
  }

  _addToast(msg, type, options, old) {
    options = this.options.override(options)
    let newToast = new _toast__WEBPACK_IMPORTED_MODULE_1__["default"](msg, type, options, this.container)
    if (old) {
      if (old instanceof _popup__WEBPACK_IMPORTED_MODULE_2__["default"]) return old.delete().then(() => newToast.insert())
      let i = old.replace(newToast)
      return i
    }
    return newToast.insert()
  }

  _afterAsync(promise, onResolve, onReject, options, oldElement) {
    return promise.then(
      this._responseHandler(onResolve, "success", options, oldElement),
      this._responseHandler(onReject, "alert", options, oldElement)
    )
  }

  _responseHandler(payload, toastName, options, oldElement) {
    return result => {
      switch (typeof payload) {
        case 'undefined':
        case 'string':
          let msg = toastName === 'alert' ? payload || result : payload
          this._addToast(msg, toastName, options, oldElement)
          break
        default:
          oldElement.delete().then(() => {
            if (payload) payload(result)
          })
      }
    }
  }

  _createContainer() {
    return new _elem__WEBPACK_IMPORTED_MODULE_3__["default"](document.body, _constants__WEBPACK_IMPORTED_MODULE_4__.tConsts.ids.container, `awn-${this.options.position}`).insert().el
  }

  get container() {
    return document.getElementById(_constants__WEBPACK_IMPORTED_MODULE_4__.tConsts.ids.container) || this._createContainer()
  }
}


/***/ }),

/***/ "./node_modules/awesome-notifications/src/options.js":
/*!***********************************************************!*\
  !*** ./node_modules/awesome-notifications/src/options.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Options)
/* harmony export */ });
const defaults = {
  maxNotifications: 10,
  animationDuration: 300,
  position: "bottom-right",
  labels: {
    tip: "Tip",
    info: "Info",
    success: "Success",
    warning: "Attention",
    alert: "Error",
    async: "Loading",
    confirm: "Confirmation required",
    confirmOk: "OK",
    confirmCancel: "Cancel"
  },
  icons: {
    tip: "question-circle",
    info: "info-circle",
    success: "check-circle",
    warning: "exclamation-circle",
    alert: "exclamation-triangle",
    async: "cog fa-spin",
    confirm: "exclamation-triangle",
    prefix: "<i class='fa fas fa-fw fa-",
    suffix: "'></i>",
    enabled: true
  },
  replacements: {
    tip: null,
    info: null,
    success: null,
    warning: null,
    alert: null,
    async: null,
    "async-block": null,
    modal: null,
    confirm: null,
    general: {
      "<script>": "",
      "</script>": ""
    }
  },
  messages: {
    tip: "",
    info: "",
    success: "Action has been succeeded",
    warning: "",
    alert: "Action has been failed",
    confirm: "This action can't be undone. Continue?",
    async: "Please, wait...",
    "async-block": "Loading"
  },
  formatError(err) {
    if (err.response) {
      if (!err.response.data) return '500 API Server Error'
      if (err.response.data.errors) {
        return err.response.data.errors.map(o => o.detail).join('<br>')
      }
      if (err.response.statusText) {
        return `${err.response.status} ${err.response.statusText}: ${err.response.data}`
      }
    }
    if (err.message) return err.message
    return err
  },
  durations: {
    global: 5000,
    success: null,
    info: null,
    tip: null,
    warning: null,
    alert: null
  },
  minDurations: {
    async: 1000,
    "async-block": 1000
  },
}
class Options {
  constructor(options = {}, global = defaults) {
    Object.assign(this, this.defaultsDeep(global, options))
  }

  icon(type) {
    if (this.icons.enabled) return `${this.icons.prefix}${this.icons[type]}${this.icons.suffix}`
    return ''
  }

  label(type) {
    return this.labels[type]
  }

  duration(type) {
    let duration = this.durations[type]
    return duration === null ? this.durations.global : duration
  }

  toSecs(value) {
    return `${value / 1000}s`
  }

  applyReplacements(str, type) {
    if (!str) return this.messages[type] || ""
    for (const n of ['general', type]) {
      if (!this.replacements[n]) continue
      for (const k in this.replacements[n]) {
        str = str.replace(k, this.replacements[n][k])
      }
    }
    return str
  }

  override(options) {
    if (options) return new Options(options, this)
    return this
  }

  defaultsDeep(defaults, overrides) {
    let result = {}
    for (const k in defaults) {
      if (overrides.hasOwnProperty(k)) {
        result[k] = typeof defaults[k] === "object" && defaults[k] !== null ? this.defaultsDeep(defaults[k], overrides[k]) : overrides[k]
      } else {
        result[k] = defaults[k]
      }
    }
    return result
  }
}


/***/ }),

/***/ "./node_modules/awesome-notifications/src/popup.js":
/*!*********************************************************!*\
  !*** ./node_modules/awesome-notifications/src/popup.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _elem__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./elem */ "./node_modules/awesome-notifications/src/elem.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./constants */ "./node_modules/awesome-notifications/src/constants.js");



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (class extends _elem__WEBPACK_IMPORTED_MODULE_0__["default"] {
  constructor(msg, type = 'modal', options, onOk, onCancel) {
    let animationDuration = `animation-duration: ${options.toSecs(options.animationDuration)};`
    super(document.body, _constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.wrapper, null, animationDuration, options)
    this[_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmOk] = onOk
    this[_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmCancel] = onCancel
    this.className = `${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.prefix}-${type}`
    if (!['confirm', 'async-block', 'modal'].includes(type)) type = 'modal'
    this.updateType(type)
    this.setInnerHtml(msg)
    this.insert()
  }

  setInnerHtml(html) {
    let innerHTML = this.options.applyReplacements(html, this.type)
    switch (this.type) {
      case "confirm":
        let buttons = [`<button class='${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.button} ${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.successBtn}'id='${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmOk}'>${this.options.labels.confirmOk}</button>`]
        if (this[_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmCancel] !== false) {
          buttons.push(`<button class='${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.button} ${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.cancelBtn}'id='${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmCancel}'>${this.options.labels.confirmCancel}</button>`)
        }
        innerHTML = `${this.options.icon(this.type)}<div class='${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.title}'>${this.options.label(this.type)}</div><div class="${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.content}">${innerHTML}</div><div class='${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.buttons} ${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.buttons}-${buttons.length}'>${buttons.join('')}</div>`
        break
      case "async-block":
        innerHTML = `${innerHTML}<div class="${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.dotAnimation}"></div>`
    }
    this.newNode.innerHTML = `<div class="${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.body} ${this.className}">${innerHTML}</div>`
  }

  keyupListener(e) {
    if (this.type === 'async-block') return e.preventDefault()
    switch (e.code) {
      case 'Escape':
        e.preventDefault()
        this.delete()
      case 'Tab':
        e.preventDefault()
        if (this.type !== 'confirm' || this[_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmCancel] === false) return true
        let next = this.okBtn
        if (e.shiftKey) {
          if (document.activeElement.id == _constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmOk) next = this.cancelBtn
        } else if (document.activeElement.id !== _constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmCancel) next = this.cancelBtn
        next.focus()
    }
  }
  afterInsert() {
    this.listener = e => this.keyupListener(e)
    window.addEventListener("keydown", this.listener)
    switch (this.type) {
      case 'async-block':
        this.start = Date.now()
        break
      case 'confirm':
        this.okBtn.focus()
        this.addEvent("click", e => {
          if (e.target.nodeName !== "BUTTON") return false
          this.delete()
          if (this[e.target.id]) this[e.target.id]()
        })
        break
      default:
        document.activeElement.blur()
        this.addEvent("click", e => {
          if (e.target.id === this.newNode.id) this.delete()
        })
    }
  }

  afterDelete() {
    window.removeEventListener("keydown", this.listener)
  }

  get okBtn() {
    return document.getElementById(_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmOk)
  }

  get cancelBtn() {
    return document.getElementById(_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmCancel)
  }
});


/***/ }),

/***/ "./node_modules/awesome-notifications/src/timer.js":
/*!*********************************************************!*\
  !*** ./node_modules/awesome-notifications/src/timer.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (class {
  constructor(callback, delay) {
    this.callback = callback
    this.remaining = delay
    this.resume()
  }
  pause() {
    this.paused = true
    window.clearTimeout(this.timerId)
    this.remaining -= new Date() - this.start
  }
  resume() {
    this.paused = false
    this.start = new Date()
    window.clearTimeout(this.timerId)
    this.timerId = window.setTimeout(() => {
      window.clearTimeout(this.timerId)
      this.callback()
    }, this.remaining)
  }
  toggle() {
    if (this.paused) this.resume()
    else this.pause()
  }
});


/***/ }),

/***/ "./node_modules/awesome-notifications/src/toast.js":
/*!*********************************************************!*\
  !*** ./node_modules/awesome-notifications/src/toast.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _elem__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./elem */ "./node_modules/awesome-notifications/src/elem.js");
/* harmony import */ var _timer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./timer */ "./node_modules/awesome-notifications/src/timer.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./constants */ "./node_modules/awesome-notifications/src/constants.js");





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (class extends _elem__WEBPACK_IMPORTED_MODULE_0__["default"] {
  constructor(msg, type, options, parent) {
    super(
      parent,
      `${_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.prefix}-${Math.floor(Date.now() - Math.random() * 100)}`,
      `${_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.prefix} ${_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.prefix}-${type}`,
      `animation-duration: ${options.toSecs(options.animationDuration)};`,
      options
    )
    this.updateType(type)
    this.setInnerHtml(msg)
  }

  setInnerHtml(html) {
    if (this.type === 'alert' && html) html = this.options.formatError(html)
    html = this.options.applyReplacements(html, this.type)
    this.newNode.innerHTML = `<div class="awn-toast-wrapper">${this.progressBar}${this.label}<div class="${_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.klass.content}">${html}</div><span class="${_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.klass.icon}">${this.options.icon(this.type)}</span></div>`
  }

  beforeInsert() {
    if (this.parent.childElementCount >= this.options.maxNotifications) {
      let elements = Array.from(this.parent.getElementsByClassName(_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.prefix))
      this.delete(elements.find(e => !this.isDeleted(e)))
    }
  }
  afterInsert() {
    if (this.type == "async") return this.start = Date.now()

    this.addEvent("click", () => this.delete())

    if (this.duration <= 0) return
    this.timer = new _timer__WEBPACK_IMPORTED_MODULE_1__["default"](() => this.delete(), this.duration)
    for (const e of ["mouseenter", "mouseleave"]) {
      this.addEvent(e, () => {
        if (this.isDeleted()) return
        this.toggleClass(_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.klass.progressBarPause)
        this.timer.toggle()
      })
    }
  }

  isDeleted(el = this.el) {
    return el.classList.contains(_constants__WEBPACK_IMPORTED_MODULE_2__.eConsts.klass.hiding)
  }
  get progressBar() {
    if (this.duration <= 0 || this.type === 'async') return ""
    return `<div class='${_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.klass.progressBar}' style="animation-duration:${this.options.toSecs(this.duration)};"></div>`
  }
  get label() {
    return `<b class="${_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.klass.label}">${this.options.label(this.type)}</b>`
  }

});


/***/ }),

/***/ "./src/api/api-index.js":
/*!******************************!*\
  !*** ./src/api/api-index.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ bindSiteApi)
/* harmony export */ });
/* harmony import */ var _trainings_trainings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./trainings/trainings */ "./src/api/trainings/trainings.js");
/* harmony import */ var _module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./module */ "./src/api/module.js");
/* harmony import */ var _payments__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./payments */ "./src/api/payments.js");
/* harmony import */ var _survey__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./survey */ "./src/api/survey.js");
/* harmony import */ var _common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./common */ "./src/api/common.js");
/* harmony import */ var _quiz__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./quiz */ "./src/api/quiz.js");
/* harmony import */ var _users__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./users */ "./src/api/users.js");
/* harmony import */ var _stream_stream__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./stream/stream */ "./src/api/stream/stream.js");
/* harmony import */ var _cpe_cpe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./cpe/cpe */ "./src/api/cpe/cpe.js");
/* harmony import */ var _storage_generic__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./storage/generic */ "./src/api/storage/generic.js");
/* harmony import */ var _storage_templates__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./storage/templates */ "./src/api/storage/templates.js");
/* harmony import */ var _storage_assessmentConfig__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./storage/assessmentConfig */ "./src/api/storage/assessmentConfig.js");
/* harmony import */ var _storage_paymentStats__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./storage/paymentStats */ "./src/api/storage/paymentStats.js");
/* harmony import */ var _storage_modulesData_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./storage/modulesData.js */ "./src/api/storage/modulesData.js");
/* harmony import */ var _judge_alphaJudge_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./judge/alphaJudge.js */ "./src/api/judge/alphaJudge.js");
/* harmony import */ var _util_contentTypes_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../util/contentTypes.js */ "./src/util/contentTypes.js");
















function bindSiteApi(appName) {
  const env = {
    interopHost,
    interopAppId,
    params,
    post,
    get,
    interopPlatformHost,
    interopAdminAlphaJudgeHost
  };
  const actions = { ...(0,_trainings_trainings__WEBPACK_IMPORTED_MODULE_0__["default"])(env),
    ...(0,_module__WEBPACK_IMPORTED_MODULE_1__["default"])(env),
    ...(0,_payments__WEBPACK_IMPORTED_MODULE_2__["default"])(env),
    ...(0,_survey__WEBPACK_IMPORTED_MODULE_3__["default"])(env),
    ...(0,_common__WEBPACK_IMPORTED_MODULE_4__["default"])(env),
    ...(0,_quiz__WEBPACK_IMPORTED_MODULE_5__["default"])(env),
    ...(0,_users__WEBPACK_IMPORTED_MODULE_6__["default"])(env),
    ...(0,_stream_stream__WEBPACK_IMPORTED_MODULE_7__["default"])(env),
    ...(0,_cpe_cpe__WEBPACK_IMPORTED_MODULE_8__["default"])(env),
    ...(0,_storage_generic__WEBPACK_IMPORTED_MODULE_9__["default"])(env),
    ...(0,_storage_templates__WEBPACK_IMPORTED_MODULE_10__["default"])(env),
    ...(0,_storage_assessmentConfig__WEBPACK_IMPORTED_MODULE_11__["default"])(env),
    ...(0,_storage_paymentStats__WEBPACK_IMPORTED_MODULE_12__["default"])(env),
    ...(0,_storage_modulesData_js__WEBPACK_IMPORTED_MODULE_13__["default"])(env),
    ...(0,_judge_alphaJudge_js__WEBPACK_IMPORTED_MODULE_14__["default"])(env)
  };

  if (appName === null) {
    return Object.keys(actions);
  } else {
    return actions;
  }

  function interopHost(endpoint) {
    switch (appName) {
      case 'digital':
        return 'https://digital.softuni.bg/' + endpoint;

      case 'creative':
        return 'https://creative.softuni.bg/' + endpoint;

      case 'ai':
        return 'https://ai.softuni.bg/' + endpoint;

      case 'financeacademy':
        return 'https://financeacademy.bg/' + endpoint;

      case 'devdigital':
        return 'https://dev.digital.softuni.bg/' + endpoint;

      case 'devsoftuni':
        return 'https://dev.softuni.bg/' + endpoint;

      default:
        return 'https://softuni.bg/' + endpoint;
    }
  }

  function interopAppId() {
    switch (appName) {
      case 'digital':
        return 'digital.softuni.bg';

      case 'creative':
        return 'creative.softuni.bg';

      case 'ai':
        return 'ai.softuni.bg';

      case 'financeacademy':
        return 'financeacademy.bg';

      case 'devdigital':
        return 'digital.softuni.bg';

      case 'devsoftuni':
        return 'softuni.bg';

      default:
        return 'softuni.bg';
    }
  }

  function interopPlatformHost() {
    switch (appName) {
      case 'digital':
        return 'https://platform.softuni.bg';

      case 'creative':
        return 'https://platform.softuni.bg';

      case 'ai':
        return 'https://platform.softuni.bg';

      case 'financeacademy':
        return 'https://platform.financeacademy.bg';

      case 'devdigital':
        return 'https://dev.platform.softuni.bg';

      case 'devsoftuni':
        return 'https://dev.platform.softuni.bg';

      default:
        return 'https://platform.softuni.bg';
    }
  }

  function interopAdminAlphaJudgeHost() {
    switch (appName) {
      case 'devsoftuni':
        return "https://admin.dev.alpha.judge.softuni.org";

      default:
        return "https://admin.alpha.judge.softuni.org";
    }
  }
}
let hosts = ['https://digital.softuni.bg/', 'https://creative.softuni.bg/', 'https://ai.softuni.bg/', 'https://financeacademy.bg/', 'https://dev.digital.softuni.bg/', 'https://dev.softuni.bg/', 'https://softuni.bg/'];
let platformHosts = ['https://platform.financeacademy.bg', 'https://dev.platform.softuni.bg', 'https://platform.softuni.bg'];
let judgeHosts = ["https://admin.alpha.judge.softuni.org", "https://dev.admin.alpha.judge.softuni.org", "https://alpha.judge.softuni.org", "https://dev.alpha.judge.softuni.org"];

function params(params = {}) {
  return Object.assign({
    sort: '',
    page: 1,
    pageSize: 10,
    group: '',
    filter: ''
  }, params);
}

async function post(url, params, contentType = _util_contentTypes_js__WEBPACK_IMPORTED_MODULE_15__.ContentType.UrlFormEncoded, asBlob = false) {
  let body = new URLSearchParams();

  if (contentType === _util_contentTypes_js__WEBPACK_IMPORTED_MODULE_15__.ContentType.ApplicationJson) {
    body = JSON.stringify(params);
  } else {
    for (let key of Object.keys(params)) {
      body.append(key, params[key]);
    }
  }

  const req = {
    method: 'POST',
    headers: {
      'Content-Type': contentType
    },
    body
  };

  try {
    const response = await fetch(url, req);

    if (response.status !== 200) {
      console.warn('Unsuccessful request');
      console.warn(params);
      console.warn(response);
      let error = new Error(`${response.status}: ${response.statusText} at ${response.url}`);
      error._status = response.status;
      throw error;
    }

    if (response.redirected || response.status == 302) {
      let urlDomain = hosts.find(x => url.startsWith(x));
      let platformDomain = platformHosts.find(x => url.startsWith(x));
      let judgeDomain = judgeHosts.find(x => url.startsWith(x));

      if (!urlDomain) {
        urlDomain = platformDomain;
      }

      if (!urlDomain) {
        urlDomain = judgeDomain;
      }

      console.error(`Request error fetching from ${url}, you're probably not logged in '${urlDomain}'.`);
      const error = new Error(`Request error, you're probably not logged in <a href="${urlDomain}" target="_blank">${urlDomain}</a>. Please login to <a href="${urlDomain}" target="_blank">${urlDomain}</a> and try again.`);
      error._url = url;
      throw error;
    }

    if (asBlob) {
      let filename = response.headers.get('Content-Disposition').split('filename=')[1].split(';')[0].replaceAll('\"', '');
      let blob = await response.blob();
      blob.filename = filename;
      return blob;
    }

    try {
      let result = await response.json();

      if (result.Errors) {
        let errorsParsed = JSON.stringify(result.Errors, undefined, 2);
        throw new Error(errorsParsed);
      }

      return result;
    } catch (e) {
      if (e instanceof SyntaxError) {
        return response;
      } else {
        throw e;
      }
    }
  } catch (e) {
    console.error(e);
    throw e;
  }
}

async function get(url, asBlob) {
  const req = {
    method: 'GET'
  };

  try {
    let response = await fetch(url, req);

    if (response.status !== 200) {
      console.warn('Unsuccessful request');
      console.warn(params);
      console.warn(response);
      throw new Error(`${response.statusText} at ${response.url}`);
    }

    if (response.redirected) {
      if (url.includes('platform')) {
        let platformDomain = platformHosts.find(x => url.startsWith(x));
        console.error(`Request error fetching from ${url}, you're probably not logged in to the platform.`);
        const error = new Error(`Request error, you're probably not logged in <a href="${platformDomain}" target="_blank">${platformDomain}</a>. Please login to <a href="${platformDomain}" target="_blank">${platformDomain}</a> and try again.`);
        error._url = url;
        throw error;
      } else {
        response = await fetch(response.url, req);
      }
    }

    if (asBlob) {
      return response.blob();
    }

    const reader = response.body.getReader();
    const utf8Decoder = new TextDecoder('utf-8');
    let result = '';

    while (true) {
      const {
        done,
        value
      } = await reader.read();

      if (done) {
        break;
      }

      result += utf8Decoder.decode(value);
    }

    try {
      return JSON.parse(result);
    } catch (e) {
      return result;
    }
  } catch (e) {
    console.error(e);
    throw e;
  }
}

/***/ }),

/***/ "./src/api/common.js":
/*!***************************!*\
  !*** ./src/api/common.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getBlogByUrl(blogUrl) {
    const uri = interopHost('administration_cms/news/read');
    const body = params({
      filter: `Url~eq~'${blogUrl}'`
    });
    return (await post(uri, body)).Data[0];
  }

  async function getHalls() {
    const dir = interopAppId() == 'softuni.bg' ? 'administration_university' : 'Administration';
    const uri = interopHost(dir + '/traininglabs/read');
    const body = params({
      pageSize: 1000
    });
    return post(uri, body);
  }

  async function getSoftwareUniversityHalls() {
    const uri = 'https://softuni.bg/administration_university/traininglabs/read';
    const body = params({
      pageSize: 1000
    });
    return post(uri, body);
  }

  function getHallBody(hall) {
    let currentDate = new Date(); // simplest way to convert date to ISO format in local Timezone as SULS requires

    currentDate.setMinutes(currentDate.getMinutes() - currentDate.getTimezoneOffset());
    let modifiedOnDate = currentDate.toISOString().slice(0, -1);
    const body = {
      sort: '',
      group: '',
      filter: '',
      Id: hall.Id,
      NameBg: hall.NameBg,
      NameEn: hall.NameEn,
      Address: hall.Address,
      Capacity: hall.Capacity,
      Description: hall.Description,
      DisableSecureLink: hall.DisableSecureLink,
      Floor: hall.Floor,
      GoogleCalendarId: hall.GoogleCalendarId,
      IsActive: hall.IsActive,
      IsFeatured: hall.IsFeatured,
      IsPhysical: hall.IsPhysical,
      ShowOnSchedule: hall.ShowOnSchedule,
      BranchId: hall.BranchId,
      SeatsConfiguration: hall.SeatsConfiguration,
      StreamingType: hall.StreamingType,
      YouTubeCode: hall.YouTubeCode,
      SoftUniStreamCode: hall.SoftUniStreamCode,
      StreamingServerBaseId: hall.StreamingServerBaseId,
      UcdnStreamingCode: hall.UcdnStreamingCode,
      CreatedOn: hall.CreatedOn,
      ModifiedOn: hall.ModifiedOn || modifiedOnDate
    };
    return body;
  }

  async function updateHall(hall) {
    let uri;

    if (interopAppId() === 'softuni.bg') {
      uri = interopHost('administration_university/traininglabs/update');
    } else {
      uri = interopHost('Administration/TrainingLabs/Update');
    }

    const body = getHallBody(hall);

    if (interopAppId() !== 'softuni.bg') {
      delete body.BranchId;
      delete body.SeatsConfiguration;
    }

    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function updateSoftwareUniversityHall(hall) {
    let uri = 'https://softuni.bg/administration_university/traininglabs/update';
    const body = getHallBody(hall);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  return {
    getBlogByUrl,
    getHalls,
    updateHall,
    getSoftwareUniversityHalls,
    updateSoftwareUniversityHall
  };
}

/***/ }),

/***/ "./src/api/cpe/cpe.js":
/*!****************************!*\
  !*** ./src/api/cpe/cpe.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _navet__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./navet */ "./src/api/cpe/navet.js");

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get,
  interopPlatformHost
}) {
  const navetApi = (0,_navet__WEBPACK_IMPORTED_MODULE_0__["default"])();

  async function getApplicationsByInstanceId(instanceId) {
    const uri = `${interopPlatformHost()}/administration/cpecertificateapplications/read?appId=${interopAppId()}`;
    const body = params({
      sort: 'CreatedOn-desc-asc',
      pageSize: 1000,
      filter: `TrainingId~eq~${instanceId}`
    });
    return (await post(uri, body)).Data;
  }

  async function getApplications(query, page) {
    const uri = `${interopPlatformHost()}/administration/cpecertificateapplications/read?appId=${interopAppId()}`;
    const filterTokens = [];

    if (query.instanceId) {
      filterTokens.push(`(TrainingId~eq~${query.instanceId})`);
    }

    if (query.instanceName) {
      filterTokens.push(`(TrainingName~contains~'${tokenize(query.instanceName).join('\'~and~TrainingName~contains~\'')}')`);
    }

    if (query.names) {
      const nameTokens = tokenize(query.names);
      let nameFilter = '';

      if (nameTokens.length == 1) {
        nameFilter = `(FirstName~contains~'${nameTokens[0]}'~or~MiddleName~contains~'${nameTokens[0]}'~or~LastName~contains~'${nameTokens[0]}')`;
      } else if (nameTokens.length == 2) {
        nameFilter = `(FirstName~contains~'${nameTokens[0]}'~and~(MiddleName~contains~'${nameTokens[1]}'~or~LastName~contains~'${nameTokens[1]}'))`;
      } else if (nameTokens.length == 3) {
        nameFilter = `(FirstName~contains~'${nameTokens[0]}'~and~MiddleName~contains~'${nameTokens[1]}'~and~LastName~contains~'${nameTokens[2]}')`;
      }

      filterTokens.push(nameFilter);
    }

    if (query.SSN) {
      filterTokens.push(`SSN~contains~'${query.SSN}'`);
    }

    const body = params({
      sort: 'CreatedOn-desc',
      pageSize: page ? 25 : 2000,
      page: page ? page : 1,
      filter: filterTokens.join('~and~')
    });
    return post(uri, body);
  }

  async function getAppZip(id) {
    const res = await fetch(`${interopPlatformHost()}/administration/cpecertificateapplications/getfileszip?id=${id}`);
    const blob = await res.blob();
    const serializedBlob = new Uint8Array(await blob.arrayBuffer());
    const blobData = {
      type: blob.type,
      buffer: Array.from(serializedBlob)
    };
    return blobData;
  } // ### External storage of application data (uses lectures inside a fixed course instance)


  const storeId = {
    'softuni.bg': 3124,
    'digital.softuni.bg': 2336,
    'creative.softuni.bg': 1193,
    'ai.softuni.bg': 8,
    'financeacademy.bg': 228
  };
  const statusModel = {
    sort: '',
    group: '',
    filter: '',
    Id: '',
    TrainingId: '',
    NameBg: '',
    NameEn: '',
    HasManualNumberOfStudyHours: '',
    NumberOfStudyHours: '',
    IsExcludedFromCertificate: '',
    HasHomework: '',
    ResourceMailsState: '',
    HomeworkMailsState: '',
    JudgeContestId: '',
    OrderBy: '',
    DescriptionBg: '',
    DescriptionEn: '',
    ExcludeFromCalendar: '',
    HasLiveStream: '',
    CreatedOn: '',
    ModifiedOn: ''
  };

  async function getAppStatus(id) {
    const uri = interopHost(`administration_trainings/lectures/read?foreignKeyId=${storeId[interopAppId()]}`);
    let filter = '';

    if (Array.isArray(id)) {
      filter = `NameEn~eq~'${id.join('\'~or~NameEn~eq~\'')}'`;
    } else {
      filter = `NameEn~eq~'${id}'`;
    }

    const body = params({
      pageSize: 1000,
      filter
    });
    return (await post(uri, body)).Data;
  }

  async function getAppStatusByInstanceId(id) {
    const uri = interopHost(`administration_trainings/lectures/read?foreignKeyId=${storeId[interopAppId()]}`);
    const body = params({
      pageSize: 1000,
      filter: `NameBg~eq~'${id}'`
    });
    return (await post(uri, body)).Data;
  }

  async function createStatus(status) {
    const uri = interopHost(`administration_trainings/lectures/create?foreignKeyId=${storeId[interopAppId()]}`);
    const body = Object.assign(params({}), statusModel);

    for (let field in body) {
      body[field] = status[field] === undefined ? body[field] : status[field];
    }

    body.TrainingId = storeId[interopAppId()];
    let startDate = new Date();
    let endDate = new Date(startDate);
    endDate.setUTCDate(endDate.getUTCDate() + 1);
    body[`DatesInfo[0].Start`] = startDate.toISOString();
    body[`DatesInfo[0].End`] = endDate.toISOString();
    body[`DatesInfo[0].ExtraInformation`] = '';
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return (await post(uri, body)).Data;
  }

  async function updateStatus(status) {
    const uri = interopHost(`administration_trainings/lectures/update?foreignKeyId=${storeId[interopAppId()]}`);
    const body = Object.assign(params({}), statusModel);

    for (let field in body) {
      body[field] = status[field] === undefined ? body[field] : status[field];
    }

    body.TrainingId = storeId[interopAppId()];
    let startDate = new Date();
    let endDate = new Date(startDate);
    endDate.setUTCDate(endDate.getUTCDate() + 1);
    body[`DatesInfo[0].Start`] = startDate.toISOString();
    body[`DatesInfo[0].End`] = endDate.toISOString();
    body[`DatesInfo[0].ExtraInformation`] = '';
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return (await post(uri, body)).Data;
  }

  async function destroyStatus(status) {
    const uri = interopHost(`administration_trainings/lectures/destroy?foreignKeyId=${storeId[interopAppId()]}`);
    const body = params({
      sort: '',
      group: '',
      filter: ''
    });
    Object.assign(body, status);
    body.TrainingId = storeId[interopAppId()];
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  return { ...navetApi,
    getApplicationsByInstanceId,
    getApplications,
    getAppZip,
    getAppStatus,
    getAppStatusByInstanceId,
    createStatus,
    updateStatus,
    destroyStatus
  };
}

function tokenize(asString) {
  return asString.split(' ').map(t => t.trim()).filter(t => t.length > 0);
}

/***/ }),

/***/ "./src/api/cpe/navet.js":
/*!******************************!*\
  !*** ./src/api/cpe/navet.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_json5_dist_index_min__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/json5/dist/index.min */ "./node_modules/json5/dist/index.min.js");
/* harmony import */ var _node_modules_json5_dist_index_min__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_json5_dist_index_min__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__() {
  const host = 'https://is.navet.government.bg/furia/Projects/napoo/index.new.php';

  async function get(url) {
    const res = await fetch(url);
    const text = await res.text();
    return text;
  }

  async function postForm(url, body) {
    Object.assign(body, {
      application: 'AJAXDataProvider',
      noCache: Date.now()
    });
    const query = [];

    for (let param in body) {
      query.push(`${param}=${encodeURIComponent(body[param])}`);
    }

    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-type': 'application/x-www-form-urlencoded; charset=utf-8'
      },
      body: query.join('&')
    });
    return res.text();
  }

  function parseResponse(data) {
    let json;
    json = _node_modules_json5_dist_index_min__WEBPACK_IMPORTED_MODULE_0___default().parse(data);

    if (json.hasOwnProperty('obj')) {
      return parseObject(json.obj);
    } else if (json.hasOwnProperty('objs')) {
      return json.objs.map(parseObject);
    } else if (json.hasOwnProperty('data') || json.status != 0) {
      return json;
    } else {
      console.error(json);

      if (json.status == 0) {
        console.error('Your session has expired. Please enter your credentials again.');
        throw new Error('Your session has expired. Please enter your credentials again.');
      } else {
        throw new TypeError('Unable to parse data: no keys [obj] or [objs] found. See console for details.');
      }
    }

    function parseObject(obj) {
      const parsed = {};

      for (let prop in obj) {
        parsed[prop] = obj[prop].value;
      }

      return parsed;
    }
  }

  async function getExtraCourseInfo(id) {
    const body = {
      invoke: `TbCourseGroupsManager.getByCourseGroupId(${id})`
    };
    return parseResponse(await postForm(host, body));
  }

  async function getNavetCurrentCourses() {
    const body = {
      invoke: 'ViewCourseGroupListManager.customGetByProviderIdAndCourseStatusId(2929,2)'
    };
    return parseResponse(await postForm(host, body));
  }

  async function getNavetClosedCourses() {
    const body = {
      invoke: 'ViewFinishedCourseGroupListManager.customGetByProviderIdAndCourseStatusIdNotArchived(2929)'
    };
    return parseResponse(await postForm(host, body));
  }

  async function getNavetArchivedCourses() {
    const body = {
      invoke: 'ViewFinishedCourseGroupListManager.customGetByProviderIdAndCourseStatusIdArchived(2929)'
    };
    return parseResponse(await postForm(host, body));
  }

  async function getNavetCourseInfo(id, type = 'current') {
    let extraInfo = getExtraCourseInfo(id);
    let courseList = [];

    switch (type) {
      case 'current':
        courseList = getNavetCurrentCourses();
        break;

      case 'concluded':
        courseList = getNavetClosedCourses();
        break;

      case 'archive':
        courseList = getNavetArchivedCourses();
        break;
    }

    [extraInfo, courseList] = await Promise.all([extraInfo, courseList]);
    const selected = courseList.find(c => c.id == id);
    selected._extra = extraInfo[0];
    return selected;
  }
  /* Replaced, because it doesn't provide the necessary information */

  /*
  async function getNavetCourseInfo(id) {
      const body = {
          invoke: `ViewCourseInfoManager.getById(${id})`
      };
      return parseResponse(await postForm(host, body));
  }
  */


  async function getNavetStudents(id) {
    const body = {
      invoke: `ViewClientCoursesManager.getByCourseGroupId(${id})`
    };
    return parseResponse(await postForm(host, body));
  }

  async function getNavetStudentInfo(clientId) {
    const body = {
      invoke: `TbClientsManager.getById(${clientId})`,
      id: clientId
    };
    return parseResponse(await postForm(host, body));
  }

  async function getNavetExistingFiles(courseId, id) {
    const body = {
      invoke: `TbClientsRequiredDocumentsManager.customGetValidByCourseGroupAndClient(${courseId},${id})`
    };
    return parseResponse(await postForm(host, body));
  }

  async function uploadFile(formData) {
    const result = await fetch(host, {
      method: 'POST',
      body: formData
    });
    const output = await result.text();

    if (output.search(/status:\s0/) != -1) {
      throw new Error('Your session has expired. Please enter your credentials again.');
    } else {
      return output;
    }
  }

  async function uploadMedical(courseId, id, fileDescriptor) {
    let blob;
    let filename;

    if (fileDescriptor.fileUrl !== undefined) {
      blob = await (await fetch(fileDescriptor.fileUrl)).blob();
      filename = fileDescriptor.name;
    } else {
      blob = fileDescriptor.file;
      filename = fileDescriptor.file.name;
    }

    const formData = new FormData();
    formData.append('id', null);
    formData.append('int_course_group_id', courseId);
    formData.append('is_valid', true);
    formData.append('oid_file_action', 'upload');
    formData.append('oid_file', blob, filename);
    formData.append('invoke', 'TbClientsRequiredDocumentsManager.createObject()');
    formData.append('application', 'AJAXDataProvider');
    formData.append('protocol', 'dataIFrame');
    formData.append('null', '');
    formData.append('int_code_course_group_required_documents_type_id', 1);
    formData.append('int_client_id', id);
    formData.append('vc_desciption', 'медицинско (auto)');
    formData.append('dt_document_date', '');
    formData.append('vc_document_reg_no', '');
    formData.append('vc_document_prn_no', '');
    formData.append('dt_document_official_date', '');
    formData.append('bool_before_date', false);
    formData.append('int_code_ext_register_id', null);
    formData.append('title', '<div class=\'napoo-title-dark\'>Медицинско свидетелство:</div>');
    formData.append('async_iframe_id', 'async_iframe_3152');
    return uploadFile(formData);
  }

  async function uploadDiploma(courseId, id, fileDescriptor, reg_no, prn_no, doc_date) {
    let blob;
    let filename;

    if (fileDescriptor.fileUrl !== undefined) {
      blob = await (await fetch(fileDescriptor.fileUrl)).blob();
      filename = fileDescriptor.name;
    } else {
      blob = fileDescriptor.file;
      filename = fileDescriptor.file.name;
    }

    const formData = new FormData();
    formData.append('id', null);
    formData.append('int_course_group_id', courseId);
    formData.append('is_valid', true);
    formData.append('int_code_education_id', 31);
    formData.append('341-text', 'завършено средно образование (или по-високо)');
    formData.append('vc_document_reg_no', reg_no);
    formData.append('vc_document_prn_no', prn_no);
    formData.append('oid_file_action', 'upload');
    formData.append('oid_file', blob, filename);
    formData.append('invoke', 'TbClientsRequiredDocumentsManager.createObject()');
    formData.append('application', 'AJAXDataProvider');
    formData.append('protocol', 'dataIFrame');
    formData.append('null', '');
    formData.append('int_client_id', id);
    formData.append('vc_desciption', 'диплома (auto)');
    formData.append('dt_document_date', '');
    formData.append('dt_document_official_date', doc_date);
    formData.append('bool_before_date', false);
    formData.append('int_code_ext_register_id', null);
    formData.append('title', '<div class=\'napoo-title-dark\'>Входящо минимално образователно равнище:</div>');
    formData.append('respInfo', '');
    formData.append('extraInfo', '');
    formData.append('check-in-edu-button', 'Провери в регистрите');
    formData.append('async_iframe_id', 'async_iframe_374');
    return uploadFile(formData);
  }

  async function openNavetFile(id) {
    const url = `${host}?application=AJAXDataProvider&invoke=TbClientsRequiredDocumentsManager.customDownloadFile(${id},"oid_file")`;
    const res = await fetch(url);
    const blob = await res.blob();
    const serializedBlob = new Uint8Array(await blob.arrayBuffer());
    let blobData = {
      type: blob.type,
      buffer: Array.from(serializedBlob)
    };
    return blobData;
  }

  async function deleteNavetFile(id) {
    const body = {
      invoke: `TbClientsRequiredDocumentsManager.customSetToFalse(${id})`
    };
    return parseResponse(await postForm(host, body));
  }
  /* Experimental */


  async function navetLogin(username, password) {
    const body = {
      response: 'client',
      request: 'login',
      username,
      password
    };
    const header = encodeURIComponent(JSON.stringify(body));
    const url = '/response';
    let request = new XMLHttpRequest();

    request.onreadystatechange = () => {
      if (request.readyState == 4 && (request.status == 200 || window.location.href.indexOf('http') == -1)) {
        let udat = JSON.parse(request.responseText);

        if (udat.status == 1) {
          window.location.href = '/';
        } else {
          throw new Error('Error: ' + udat.error_code);
        }

        request = null;
      }
    };

    const cache = '?' + new Date().getTime();
    request.open('GET', url + cache, true);
    request.setRequestHeader('ACCSSCTRL', header);
    request.send(null);
  }

  async function getGraduateInfo(id) {
    const body = {
      invoke: `RefClientsCoursesManager.getById(${id})`
    };
    return parseResponse(await postForm(host, body));
  }

  async function getNavetCertificate(id) {
    const body = {
      invoke: `ViewClientsCoursesDocumentsManager.getByClientCoursesId(${id})`
    };
    return parseResponse(await postForm(host, body));
  }

  async function openNavetCertificate(id, page) {
    const url = `${host}?application=AJAXDataProvider&invoke=TbClientsCoursesDocumentsManager.customDownloadFile(${id}, "document_${page}_file")`;
    const res = await fetch(url);
    const blob = await res.blob();

    if (blob.type == 'text/javascript') {
      console.error('Your session has expired. Please enter your credentials again.');
      throw new Error('Your session has expired. Please enter your credentials again.');
    }

    const serializedBlob = new Uint8Array(await blob.arrayBuffer());
    let blobData = {
      type: blob.type,
      buffer: Array.from(serializedBlob)
    };
    return blobData;
  }

  async function uploadNavetCertificate(meta, fileDescriptors) {
    const files = await Promise.all(fileDescriptors.map(async descriptor => {
      if (descriptor === null) {
        return null;
      } else if (descriptor.fileUrl !== undefined) {
        return {
          blob: await (await fetch(descriptor.fileUrl)).blob(),
          filename: descriptor.name
        };
      } else {
        return {
          blob: descriptor.file,
          filename: descriptor.file.name
        };
      }
    }));
    const formData = new FormData();
    formData.append('id', meta.id);
    formData.append('int_clients_courses_id', meta.int_clients_courses_id);
    formData.append('int_document_type_id', meta.int_document_type_id);
    formData.append('608-text', 'Удостоверение за професионално обучение');
    formData.append('int_course_finished_year', meta.int_course_finished_year); // need this added

    formData.append('vc_document_prn_no', '');
    formData.append('612-text', '');
    formData.append('vc_original_prn_no', meta.vc_document_prn_no);
    formData.append('vc_document_reg_no', meta.vc_document_reg_no); // need this added

    formData.append('vc_document_prot', meta.vc_document_prot);
    formData.append('num_theory_result', meta.num_theory_result);
    formData.append('num_practice_result', meta.num_practice_result);
    formData.append('vc_qualification_name', meta.vc_qualification_name);
    formData.append('vc_qualificatioj_level', meta.vc_qualificatioj_level);

    if (files[0] !== null) {
      formData.append('document_1_file_action', 'upload');
      formData.append('document_1_file', files[0].blob, files[0].filename);
    } else {
      formData.append('document_1_file_action', '');
      formData.append('document_1_file', new Blob(['']), '');
    }

    if (files[1] !== null) {
      formData.append('document_2_file_action', 'upload');
      formData.append('document_2_file', files[1].blob, files[1].filename);
    } else {
      formData.append('document_2_file_action', '');
      formData.append('document_2_file', new Blob(['']), '');
    }

    formData.append('invoke', `TbClientsCoursesDocumentsManager.updateObject(${meta.id})`);
    formData.append('application', 'AJAXDataProvider');
    formData.append('protocol', 'dataIFrame');
    formData.append('dt_document_date', meta.dt_document_date);
    formData.append('vc_document_type_name', meta.vc_document_type_name);
    formData.append('int_document_status', meta.int_document_status);
    formData.append('bool_with_note', meta.bool_with_note);
    formData.append('async_iframe_id', 'async_iframe_639');
    return uploadFile(formData);
  }

  async function updateNavetStudent(id, student) {
    const body = Object.assign({}, student, {
      invoke: `RefClientsCoursesManager.updateObject(${id})`
    });
    return parseResponse(await postForm(host, body));
  }

  async function createDocument(studentId, clientId, data) {
    const formData = new FormData();
    formData.append('id', null);
    formData.append('int_clients_courses_id', null);
    formData.append('int_document_type_id', '');
    formData.append('304-text', 'Удостоверение за професионално обучение');
    formData.append('int_course_finished_year', data.int_course_finished_year); // need this added

    formData.append('vc_document_prn_no', '');
    formData.append('308-text', '');
    formData.append('vc_document_reg_no', data.vc_document_reg_no); // need this added

    formData.append('vc_document_prot', '');
    formData.append('num_theory_result', 0);
    formData.append('num_practice_result', 0);
    formData.append('vc_qualification_name', '');
    formData.append('vc_qualificatioj_level', '');
    formData.append('document_1_file_action', '');
    formData.append('document_1_file', new Blob(['']), '');
    formData.append('document_2_file_action', '');
    formData.append('document_2_file', new Blob(['']), '');
    formData.append('invoke', 'CustomEventsManager.customTbClientsCoursesDocuments(1)');
    formData.append('application', 'AJAXDataProvider');
    formData.append('protocol', 'dataIFrame');
    formData.append('int_provider_id', 2929);
    formData.append('ref_clients_courses_id_t', studentId); //data.id

    formData.append('tb_clients_id_t', clientId); //data.int_client_id

    formData.append('dt_document_date_t', '');
    formData.append('int_client_course_id_t', studentId); //data.id

    formData.append('int_document_type_id_t', 2);
    formData.append('vc_document_prn_no_t', '');
    formData.append('vc_document_reg_no_t', data.vc_document_reg_no); // need this added, same as above

    formData.append('int_document_status', 0);
    formData.append('async_iframe_id', 'async_iframe_329');
    return uploadFile(formData);
  }

  return {
    getNavetCurrentCourses,
    getNavetClosedCourses,
    getNavetArchivedCourses,
    getNavetCourseInfo,
    getNavetStudents,
    getNavetStudentInfo,
    getNavetExistingFiles,
    uploadMedical,
    uploadDiploma,
    openNavetFile,
    deleteNavetFile,
    getGraduateInfo,
    getNavetCertificate,
    openNavetCertificate,
    uploadNavetCertificate,
    updateNavetStudent,
    createDocument,
    getExtraCourseInfo
  };
}

/***/ }),

/***/ "./src/api/judge/alphaJudge.js":
/*!*************************************!*\
  !*** ./src/api/judge/alphaJudge.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _util_contentTypes_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../util/contentTypes.js */ "./src/util/contentTypes.js");

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get,
  interopPlatformHost,
  interopAdminAlphaJudgeHost
}) {
  async function getContestCompeteResults(contestId) {
    const uri = `${interopAdminAlphaJudgeHost()}/api/contests/ExportResults`;
    const body = {
      id: contestId,
      type: 0
    };
    let blob = await post(uri, body, _util_contentTypes_js__WEBPACK_IMPORTED_MODULE_0__.ContentType.ApplicationJson, true);
    const serializedBlob = new Uint8Array(await blob.arrayBuffer());
    const blobData = {
      type: blob.type,
      filename: blob.filename,
      buffer: Array.from(serializedBlob)
    };
    return blobData;
  }

  async function getContestPracticeResults(contestId) {
    const uri = `${interopAdminAlphaJudgeHost()}/api/contests/ExportResults`;
    const body = {
      id: contestId,
      type: 1
    };
    let blob = await post(uri, body, _util_contentTypes_js__WEBPACK_IMPORTED_MODULE_0__.ContentType.ApplicationJson, true);
    const serializedBlob = new Uint8Array(await blob.arrayBuffer());
    const blobData = {
      type: blob.type,
      filename: blob.filename,
      buffer: Array.from(serializedBlob)
    };
    return blobData;
  }

  return {
    getContestCompeteResults,
    getContestPracticeResults
  };
}

/***/ }),

/***/ "./src/api/module.js":
/*!***************************!*\
  !*** ./src/api/module.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post
}) {
  async function getModulesInProfession(professionId) {
    const url = (() => {
      if (interopAppId() === 'softuni.bg') {
        return interopHost(`administration_professions/levelgroupsinprofessioninstances/read?foreignKeyId=${professionId}`);
      } else {
        return interopHost(`Administration_Professions/CourseGroupsInProfessionInstances/Read?foreignKeyId=${professionId}`);
      }
    })();

    const body = params({
      pageSize: 100
    });
    return post(url, body);
  }

  async function getModules() {
    const url = interopHost('administration_Levels/levels/read');
    const body = params({
      pageSize: 1000
    });
    return (await post(url, body)).Data;
  }

  async function getInstancesInModule(moduleId) {
    const url = (() => {
      if (interopAppId() === 'softuni.bg') {
        return interopHost(`administration_levels/levelinstances/read?importLevelId=${moduleId}&levelId=${moduleId}`);
      } else {
        return interopHost(`Administration_Levels/LevelInstances/Read?importLevelId=${moduleId}&levelId=${moduleId}&foreignKeyId=${moduleId}`);
      }
    })();

    const body = params({
      pageSize: 1000
    });
    return post(url, body);
  }

  async function getInstanceInModule(moduleId, moduleInstanceId) {
    const url = (() => {
      if (interopAppId() === 'softuni.bg') {
        return interopHost(`administration_levels/levelinstances/read?importLevelId=${moduleId}&levelId=${moduleId}`);
      } else {
        return interopHost(`Administration_Levels/LevelInstances/Read?importLevelId=${moduleId}&levelId=${moduleId}&foreignKeyId=${moduleId}`);
      }
    })();

    let filter = `Id~eq~${moduleInstanceId}`;

    if (Array.isArray(moduleInstanceId)) {
      filter = `Id~eq~${moduleInstanceId.join('~or~Id~eq~')}`;
    }

    const body = params({
      pageSize: 100,
      filter: filter
    });
    return post(url, body);
  }

  async function searchModules(query) {
    const url = interopHost('administration_levels/levels/read');
    const filter = `NameBg~contains~'${query.split(' ').filter(s => s.length > 0).join('\'~and~NameBg~contains~\'')}'`;
    const body = params({
      pageSize: 100,
      filter,
      sort: 'CreatedOn-desc'
    });
    return (await post(url, body)).Data;
  }

  return {
    getModulesInProfession,
    getModules,
    getInstancesInModule,
    searchModules,
    getInstanceInModule
  };
}

/***/ }),

/***/ "./src/api/payments.js":
/*!*****************************!*\
  !*** ./src/api/payments.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get,
  interopPlatformHost
}) {
  async function getPaymentsForPackage(packageName) {
    // This field does not work with multiple values

    /*
    const filter = (() => {
        if (Array.isArray(packageId)) {
            return `PaymentPackagesAsString~eq~'${packageId.join('\'~or~PaymentPackagesAsString~eq~\'')}'`;
            //return `PaymentStatus~eq~4~and~(PaymentPackagesAsString~eq~'${packageId.join('\'~or~PaymentPackagesAsString~eq~\'')}')`;
        } else {
            return `PaymentPackagesAsString~eq~'${packageId}'`;
            //return `PaymentStatus~eq~4~and~PaymentPackagesAsString~eq~${packageId}`;
        }
    })();
    */
    const url = `${interopPlatformHost()}/administration/payments/read?appId=${interopAppId()}`;
    const body = params({
      pageSize: 10000,
      filter: `PaymentStatus~eq~4~and~PaymentPackagesAsString~eq~'${packageName}'`
    });
    return post(url, body);
  }

  async function getPackagesForProduct(productId) {
    if (Array.isArray(productId) && productId.length === 0) {
      return {
        Data: []
      };
    }

    const filter = (() => {
      if (Array.isArray(productId)) {
        return `Name~doesnotcontain~'II'~and~(Product.Id~eq~${productId.join('~or~Product.Id~eq~')})`;
      } else {
        return `Name~doesnotcontain~'II'~and~Product.Id~eq~${productId}`;
      }
    })();

    const url = `${interopPlatformHost()}/administration/paymentpackages/read?appId=${interopAppId()}`;
    const body = params({
      pageSize: 1000,
      filter
    });
    return post(url, body);
  }

  async function getProductsForModule(moduleId) {
    const filter = (() => {
      if (Array.isArray(moduleId)) {
        return `Name~doesnotcontain~'II'~and~(LevelInstanceId~eq~${moduleId.join('~or~LevelInstanceId~eq~')})`;
      } else {
        return `Name~doesnotcontain~'II'~and~LevelInstanceId~eq~${moduleId}`;
      }
    })();

    const url = `${interopPlatformHost()}/administration/levelinstanceproducts/read?appId=${interopAppId()}`;
    const body = params({
      pageSize: 1000,
      filter
    });
    return post(url, body);
  }

  async function getProductsForCourse(instanceId, type = 'open') {
    const epStrings = (() => {
      switch (type) {
        case 'open':
          return {
            path: 'fasttrackinstanceproducts',
            param: 'FastTrackInstanceId'
          };
      }
    })();

    const filter = (() => {
      if (Array.isArray(instanceId)) {
        return `(${epStrings.param}~eq~${instanceId.join(`~or~${epStrings.param}~eq~`)})`;
      } else {
        return `${epStrings.param}~eq~${instanceId}`;
      }
    })();

    const url = `${interopPlatformHost()}/administration/${epStrings.path}/read?appId=${interopAppId()}`;
    const body = params({
      pageSize: 1000,
      filter
    });
    return post(url, body);
  }

  return {
    getPaymentsForPackage,
    getPackagesForProduct,
    getProductsForModule,
    getProductsForCourse
  };
}

/***/ }),

/***/ "./src/api/quiz.js":
/*!*************************!*\
  !*** ./src/api/quiz.js ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function createQuizInstance(payload) {
    const uri = interopHost('administration_testsystem/tests/create');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: 0,
      Name: payload.name,
      Description: payload.description,
      QuestionsCount: 0
    });
    return await post(uri, body);
  }

  async function addQuestion(quizId, question) {
    const uri = interopHost(`administration_testsystem/testquestions/create?foreignKeyId=${quizId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: 0,
      Type: 1,
      Content: question,
      CorrectAnswerPoints: 1,
      WrongAnswerPoints: 0,
      KeepAnswersOrder: false,
      ShowCorrectAnswersCount: false,
      CorrectCount: 0,
      WrongCount: 0,
      AllCount: 0,
      PercentCorrect: 0
    });
    return await post(uri, body);
  }

  async function addAnswer(questionId, answer, isCorrect) {
    const uri = interopHost(`administration_testsystem/testquestionanswers/create?foreignKeyId=${questionId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: 0,
      QuestionId: 0,
      Content: answer,
      IsCorrect: isCorrect,
      SelectedCount: 0
    });
    return await post(uri, body);
  }

  async function getAllQuizesByName(containingName, pageSize, page) {
    const uri = interopHost(`administration_testsystem/tests/read`);
    const body = params({
      sort: '',
      group: '',
      filter: `Name~contains~'${containingName}'`,
      pageSize,
      page
    });
    return await post(uri, body);
  }

  async function getQuestionsById(quizId, pageSize, page) {
    const uri = interopHost(`administration_testsystem/testquestions/read?foreignKeyId=${quizId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      pageSize,
      page
    });
    return await post(uri, body);
  }

  async function getAnswersByQuestionId(questionId, pageSize, page) {
    const uri = interopHost(`administration_testsystem/testquestionanswers/read?foreignKeyId=${questionId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      pageSize,
      page
    });
    return await post(uri, body);
  }

  return {
    createQuizInstance,
    addQuestion,
    addAnswer,
    getAllQuizesByName,
    getQuestionsById,
    getAnswersByQuestionId
  };
}

/***/ }),

/***/ "./src/api/storage/assessmentConfig.js":
/*!*********************************************!*\
  !*** ./src/api/storage/assessmentConfig.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _generic__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./generic */ "./src/api/storage/generic.js");

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  const genericApi = (0,_generic__WEBPACK_IMPORTED_MODULE_0__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const storeId = {
    'softuni.bg': 3797,
    'digital.softuni.bg': 3556,
    'creative.softuni.bg': 1411,
    'ai.softuni.bg': 6,
    'financeacademy.bg': 73
  };

  function serialize(data) {
    return {
      sort: '',
      group: '',
      filter: '',
      Id: data.Id || 0,
      TrainingId: storeId[interopAppId()],
      NameBg: '0000000000' + data.ExamId,
      NameEn: '0000000000',
      HasManualNumberOfStudyHours: true,
      NumberOfStudyHours: 0,
      IsExcludedFromCertificate: false,
      HasHomework: false,
      ResourceMailsState: 0,
      HomeworkMailsState: 0,
      JudgeContestId: '',
      OrderBy: 0,
      DescriptionBg: '0000000000' + JSON.stringify(data.Config),
      DescriptionEn: '0000000000',
      ExcludeFromCalendar: false,
      HasLiveStream: false,
      CreatedOn: '',
      ModifiedOn: ''
    };
  }

  function parse(entry) {
    if (entry) {
      return {
        Id: entry.Id,
        ExamId: Number((entry.NameBg || '').slice(10)),
        Config: JSON.parse((entry.DescriptionBg || '').slice(10))
      };
    } else {
      return undefined;
    }
  }

  async function getConfigs(examIds) {
    const data = await genericApi.getEntries(storeId[interopAppId()], `NameBg~eq~'${examIds.map(id => '0000000000' + id).join('\'~or~NameBg~eq~\'')}'`);
    return data.map(parse);
    ;
  }

  async function getConfigByExamId(examId) {
    const config = await genericApi.getEntries(storeId[interopAppId()], `NameBg~eq~'0000000000${examId}'`);
    return parse(config.Data[0]);
  }

  async function saveConfig(config) {
    const operation = config.Id ? genericApi.updateEntry : genericApi.createEntry;
    const result = await operation(serialize(config));
    return parse(result.Data[0]);
  }

  async function deleteConfig(config) {
    return genericApi.destroyEntry(serialize(config));
  }

  return {
    getConfigs,
    getConfigByExamId,
    saveConfig,
    deleteConfig
  };
}

/***/ }),

/***/ "./src/api/storage/generic.js":
/*!************************************!*\
  !*** ./src/api/storage/generic.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  /* Entry model:
        {
          sort: '',
          group: '',
          filter: '',
          Id: data.Id,
          TrainingId: storeId[interopAppId()],
          NameBg: '',                             String (3-200)
          NameEn: '',                             String (3-200)
          NumberOfStudyHours: 0,                  Integer
          IsExcludedFromCertificate: false,       Boolean
          HasHomework: false,                     Boolean
          ResourceMailsState: 0,
          HomeworkMailsState: 0,
          JudgeContestId: '',                     Integer (cannot be empty)
          OrderBy: 0,                             Integer
          DescriptionBg: '',                      String (10-6000)
          DescriptionEn: '',                      String (10-6000)
          ExcludeFromCalendar: false,             Boolean
          HasLiveStream: false,                   Boolean
          CreatedOn: '',
          ModifiedOn: ''
      };
  */
  const settingsStoreId = {
    'softuni.bg': 529,
    'digital.softuni.bg': 1064,
    'creative.softuni.bg': 101,
    'ai.softuni.bg': 5,
    'financeacademy.bg': 24
  };

  async function getStoreSettings(storeId) {
    const uri = interopHost(`administration_trainings/fasttrackinstances/read?foreignKeyId=${settingsStoreId[interopAppId()]}`);
    const body = params({
      filter: `Id~eq~${storeId}`
    });
    const store = (await post(uri, body)).Data[0];
    const asJson = (store.DescriptionBg || '').slice(10) + (store.DescriptionEn || '').slice(10);

    try {
      return {
        settings: JSON.parse(asJson),
        _ModifiedOn: store.ModifiedOn || store.CreatedOn
      };
    } catch (err) {
      console.error(err);
      return undefined;
    }
  }

  async function saveStoreSettings(storeId, settings) {
    const currentUri = interopHost(`administration_trainings/fasttrackinstances/read?foreignKeyId=${settingsStoreId[interopAppId()]}`);
    const currentBody = params({
      filter: `Id~eq~${storeId}`
    });
    const current = (await post(currentUri, currentBody)).Data[0];
    delete current.SharesLiveStreamWithTrainings;

    if (settings.hasOwnProperty('_ModifiedOn') && settings.hasOwnProperty('settings')) {
      settings = settings.settings;
    }

    const asJson = JSON.stringify(settings);
    current.DescriptionBg = '0000000000' + asJson.slice(0, 10000);
    current.DescriptionEn = '0000000000' + asJson.slice(10000); //Certificate type is now required (8 = None)

    current.CertificateType = 8;
    const uri = interopHost(`administration_trainings/fasttrackinstances/update?foreignKeyId=${settingsStoreId[interopAppId()]}`);
    const body = {
      'sort': '',
      'group': '',
      'filter': '',
      ...current,
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:01.317'
    };
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });

    try {
      const result = (await post(uri, body)).Data[0];
      return JSON.parse((result.DescriptionBg || '').slice(10));
    } catch (err) {
      console.error(err);
      return undefined;
    }
  }

  async function getEntries(storeId, filter) {
    const uri = interopHost(`administration_trainings/lectures/read?foreignKeyId=${storeId}`);
    const body = params({
      pageSize: 1000
    });

    if (filter) {
      body.filter = filter;
    }

    return (await post(uri, body)).Data;
  }

  async function updateEntry(entry) {
    let startDate = new Date();
    let endDate = new Date(startDate);
    endDate.setUTCDate(endDate.getUTCDate() + 1);
    const uri = interopHost(`administration_trainings/lectures/update?foreignKeyId=${entry.TrainingId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: entry.Id,
      TrainingId: entry.TrainingId,
      NameBg: entry.NameBg,
      NameEn: entry.NameEn,
      HasManualNumberOfStudyHours: true,
      NumberOfStudyHours: entry.NumberOfStudyHours,
      IsExcludedFromCertificate: entry.IsExcludedFromCertificate,
      HasHomework: entry.HasHomework,
      ResourceMailsState: entry.ResourceMailsState,
      HomeworkMailsState: entry.HomeworkMailsState,
      JudgeContestId: entry.JudgeContestId,
      OrderBy: entry.OrderBy,
      DescriptionBg: entry.DescriptionBg,
      DescriptionEn: entry.DescriptionEn,
      ExcludeFromCalendar: entry.ExcludeFromCalendar,
      HasLiveStream: entry.HasLiveStream,
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:02.317',
      DatesInfo: [{
        Start: startDate.toISOString(),
        End: endDate.toISOString(),
        ExtraInformation: ''
      }]
    });
    serializeDatesInfo(body);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function createEntry(entry) {
    let startDate = new Date();
    let endDate = new Date(startDate);
    endDate.setUTCDate(endDate.getUTCDate() + 1);
    const uri = interopHost(`administration_trainings/lectures/create?foreignKeyId=${entry.TrainingId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: entry.Id,
      TrainingId: entry.TrainingId,
      NameBg: entry.NameBg,
      NameEn: entry.NameEn,
      HasManualNumberOfStudyHours: true,
      NumberOfStudyHours: entry.NumberOfStudyHours,
      IsExcludedFromCertificate: entry.IsExcludedFromCertificate,
      HasHomework: entry.HasHomework,
      ResourceMailsState: entry.ResourceMailsState,
      HomeworkMailsState: entry.HomeworkMailsState,
      JudgeContestId: entry.JudgeContestId,
      OrderBy: entry.OrderBy,
      DescriptionBg: entry.DescriptionBg,
      DescriptionEn: entry.DescriptionEn,
      ExcludeFromCalendar: entry.ExcludeFromCalendar,
      HasLiveStream: entry.HasLiveStream,
      CreatedOn: '',
      ModifiedOn: '',
      DatesInfo: [{
        Start: startDate.toISOString(),
        End: endDate.toISOString(),
        ExtraInformation: ''
      }]
    });
    serializeDatesInfo(body);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function destroyEntry(entry) {
    const uri = interopHost(`administration_trainings/lectures/destroy?foreignKeyId=${entry.TrainingId}`);
    const body = params({
      sort: '',
      group: '',
      filter: ''
    });
    Object.assign(body, entry);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    return post(uri, body);
  }

  function serializeDatesInfo(body) {
    const datesInfo = body.DatesInfo;
    delete body.DatesInfo;

    for (let i = 0; i < datesInfo.length; i++) {
      const date = datesInfo[i];
      body[`DatesInfo[${i}].Start`] = date.Start;
      body[`DatesInfo[${i}].End`] = date.End;
      body[`DatesInfo[${i}].ExtraInformation`] = date.ExtraInformation;
    }
  }

  return {
    getStoreSettings,
    saveStoreSettings,
    getEntries,
    updateEntry,
    createEntry,
    destroyEntry
  };
}

/***/ }),

/***/ "./src/api/storage/modulesData.js":
/*!****************************************!*\
  !*** ./src/api/storage/modulesData.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _generic__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./generic */ "./src/api/storage/generic.js");

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  const genericApi = (0,_generic__WEBPACK_IMPORTED_MODULE_0__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const storeId = {
    'softuni.bg': 4492,
    'digital.softuni.bg': 3815,
    'creative.softuni.bg': 1612,
    'ai.softuni.bg': 9
  };
  return {
    getModuleDataSettings: () => genericApi.getStoreSettings(storeId[interopAppId()]),
    saveModuleDataSettings: settings => genericApi.saveStoreSettings(storeId[interopAppId()], settings)
  };
}

/***/ }),

/***/ "./src/api/storage/paymentStats.js":
/*!*****************************************!*\
  !*** ./src/api/storage/paymentStats.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _generic__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./generic */ "./src/api/storage/generic.js");

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  const genericApi = (0,_generic__WEBPACK_IMPORTED_MODULE_0__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const storeId = {
    'softuni.bg': 3833,
    'digital.softuni.bg': 3582,
    'creative.softuni.bg': 1428,
    'ai.softuni.bg': 10
  };

  function serialize(data) {
    const payload = {
      PaymentsByDate: data.PaymentsByDate,
      RetentionByDate: data.RetentionByDate,
      OnlinePayments: data.OnlinePayments || 0,
      OnlineRetention: data.OnlineRetention || 0,
      SitePayments: data.SitePayments || 0,
      SiteRetention: data.SiteRetention || 0
    };
    const asJson = JSON.stringify(payload);
    return {
      sort: '',
      group: '',
      filter: '',
      Id: data.Id || 0,
      TrainingId: storeId[interopAppId()],
      NameBg: '0000000000' + (data.NameBg + '::' + data.NameEn + '::' + data.LevelId),
      NameEn: '0000000000' + JSON.stringify(data.DateConfig),
      HasManualNumberOfStudyHours: true,
      NumberOfStudyHours: data.StartIndex || 0,
      IsExcludedFromCertificate: false,
      JudgeContestId: data.LevelId,
      HasHomework: false,
      ResourceMailsState: 0,
      HomeworkMailsState: 0,
      OrderBy: data.InstanceId,
      DescriptionBg: '0000000000' + asJson.slice(0, 5980),
      DescriptionEn: '0000000000' + asJson.slice(5980),
      ExcludeFromCalendar: !data.IsMainProgram,
      HasLiveStream: false,
      CreatedOn: '',
      ModifiedOn: ''
    };
  }

  function parse(entry) {
    if (entry) {
      try {
        const payloadJson = (entry.DescriptionBg || '').slice(10) + (entry.DescriptionEn || '').slice(10);
        const payload = JSON.parse(payloadJson);
        const namesAndLevel = entry.NameBg.slice(10).split('::');
        return {
          Id: entry.Id,
          InstanceId: Number(entry.OrderBy) || null,
          LevelId: Number(namesAndLevel[2]) || entry.JudgeContestId,
          NameBg: namesAndLevel[0],
          NameEn: namesAndLevel[1],
          DateConfig: JSON.parse((entry.NameEn || '').slice(10)),
          StartIndex: entry.NumberOfStudyHours,
          PaymentsByDate: payload.PaymentsByDate,
          RetentionByDate: payload.RetentionByDate,
          OnlinePayments: payload.OnlinePayments || 0,
          OnlineRetention: payload.OnlineRetention || 0,
          SitePayments: payload.SitePayments || 0,
          SiteRetention: payload.SiteRetention || 0,
          IsMainProgram: !entry.ExcludeFromCalendar,
          ModifiedOn: entry.ModifiedOn || entry.CreatedOn
        };
      } catch (err) {
        console.error('Destroying incompatible entry');
        console.log(entry);
        console.error(err);
        genericApi.destroyEntry(entry);
        return undefined;
      }
    } else {
      return undefined;
    }
  }

  async function getStats(instanceIds) {
    const data = await genericApi.getEntries(storeId[interopAppId()], `OrderBy~eq~${instanceIds.join('~or~OrderBy~eq~')}`);
    return data.map(parse);
  }

  async function getStatsByInstanceId(instanceId) {
    const config = await genericApi.getEntries(storeId[interopAppId()], `OrderBy~eq~${instanceId}`);
    return parse(config[0]);
  }

  async function getStatsByStartIndex(start, end) {
    const data = await genericApi.getEntries(storeId[interopAppId()], `NumberOfStudyHours~gte~${start}~and~NumberOfStudyHours~lte~${end}`);
    return data.map(parse);
  }

  async function saveStats(stats) {
    const operation = stats.Id ? genericApi.updateEntry : genericApi.createEntry;
    const result = await operation(serialize(stats));

    if (result.Errors) {
      const error = new Error('Request returned Errors');
      error._errorObject = result.Errors;
      throw error;
    } // console.log(JSON.stringify(result));


    return parse(result.Data[0]);
  }

  async function deleteStats(stats) {
    return genericApi.destroyEntry(serialize(stats));
  }

  return {
    getStatsSettings: () => genericApi.getStoreSettings(storeId[interopAppId()]),
    saveStatsSettings: settings => genericApi.saveStoreSettings(storeId[interopAppId()], settings),
    getStats,
    getStatsByInstanceId,
    getStatsByStartIndex,
    saveStats,
    deleteStats
  };
}

/***/ }),

/***/ "./src/api/storage/templates.js":
/*!**************************************!*\
  !*** ./src/api/storage/templates.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _generic__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./generic */ "./src/api/storage/generic.js");

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  const genericApi = (0,_generic__WEBPACK_IMPORTED_MODULE_0__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const templateStoreId = {
    'softuni.bg': 3519,
    'digital.softuni.bg': 3440,
    'creative.softuni.bg': 1300,
    'ai.softuni.bg': 7,
    'financeacademy.bg': 74
  };

  async function getTemplateStoreSettings() {
    return genericApi.getStoreSettings(templateStoreId[interopAppId()]);
  }

  function templateToEntry(data) {
    return {
      sort: '',
      group: '',
      filter: '',
      Id: data.Id || 0,
      TrainingId: templateStoreId[interopAppId()],
      NameBg: '0000000000' + data.Name,
      NameEn: '0000000000' + JSON.stringify(data.Category),
      HasManualNumberOfStudyHours: true,
      NumberOfStudyHours: 0,
      IsExcludedFromCertificate: data.Active,
      HasHomework: false,
      ResourceMailsState: 0,
      HomeworkMailsState: 0,
      JudgeContestId: '',
      OrderBy: 0,
      DescriptionBg: '0000000000' + data.Content,
      DescriptionEn: ('0000000000' + (data.InstanceId || '')).slice(-10),
      ExcludeFromCalendar: data.Compound,
      HasLiveStream: false,
      CreatedOn: '',
      ModifiedOn: ''
    };
  }

  function entryToTemplate(entry) {
    if (entry) {
      return {
        Id: entry.Id,
        Name: entry.NameBg.slice(10),
        Category: JSON.parse(entry.NameEn.slice(10)) || [],
        Active: entry.IsExcludedFromCertificate,
        Compound: entry.ExcludeFromCalendar,
        Content: (entry.DescriptionBg || '').slice(10),
        InstanceId: Number(entry.DescriptionEn) || null
      };
    } else {
      return undefined;
    }
  }

  async function getTemplates() {
    const data = await genericApi.getEntries(templateStoreId[interopAppId()]);
    return data.map(entryToTemplate).sort((a, b) => {
      return (b.Active ? 1 : 0) - (a.Active ? 1 : 0) || (b.Compound ? 1 : 0) - (a.Compound ? 1 : 0) || a.Name.localeCompare(b.Name);
    });
  }

  async function getTemplateByName(name) {
    const template = await genericApi.getEntries(templateStoreId[interopAppId()], `NameBg~eq~'${name}'`);
    return entryToTemplate(template[0]);
  }

  async function getTemplateByInstanceId(instanceId) {
    const template = await genericApi.getEntries(templateStoreId[interopAppId()], `DescriptionEn~eq~'${instanceId}'`);
    return entryToTemplate(template[0]);
  }

  async function saveTemplate(template) {
    const operation = template.Id ? genericApi.updateEntry : genericApi.createEntry;
    const result = await operation(templateToEntry(template));
    return entryToTemplate(result.Data[0]);
  }

  async function deleteTemplate(template) {
    return genericApi.destroyEntry(templateToEntry(template));
  }

  return {
    getTemplateStoreSettings,
    getTemplates,
    getTemplateByName,
    getTemplateByInstanceId,
    saveTemplate,
    deleteTemplate
  };
}

/***/ }),

/***/ "./src/api/stream/stream.js":
/*!**********************************!*\
  !*** ./src/api/stream/stream.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getInstanceConfig(instanceId) {
    const uri = `https://ses-webext.github.io/stream/${instanceId}.json`;

    try {
      const result = await get(uri);
      return result;
    } catch (err) {
      console.log(err);
      return null;
    }
  }

  return {
    getInstanceConfig
  };
}

/***/ }),

/***/ "./src/api/survey.js":
/*!***************************!*\
  !*** ./src/api/survey.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post
}) {
  async function getSurveys(page, query, filter, pageSize = 30) {
    if (pageSize == undefined) {
      pageSize = 30;
    }

    const url = interopHost('administration_surveys/surveys/read');
    const body = params({
      sort: 'ActiveTo-desc',
      pageSize: pageSize,
      page
    });

    if (query) {
      body.filter = `Name~contains~'${query}'`;
    }

    if (filter) {
      body.filter += `~and~(${filter})`;
    }

    return post(url, body);
  }

  async function getSurveysByNameAndStartAndEndDate(page, name, startDate, endDate, pageSize = 30) {
    if (pageSize == undefined) {
      pageSize = 30;
    }

    const url = interopHost('administration_surveys/surveys/read');
    const body = params({
      sort: 'ActiveTo-desc',
      pageSize: pageSize,
      page
    });
    body.filter = `Name~contains~'${name}'~and~ActiveFrom~gte~datetime'${startDate}'~and~ActiveFrom~lt~datetime'${endDate}'`;
    return post(url, body);
  }

  async function getSurveyById(surveyId) {
    const url = interopHost('administration_surveys/surveys/read');
    const body = params({
      filter: 'Id~eq~' + surveyId
    });
    return (await post(url, body)).Data[0];
  }

  async function getSurveyAnswers(surveyId) {
    const url = interopHost('administration_surveys/userpollanswers/read');
    const body = params({
      pageSize: 10000,
      filter: 'SurveyId~eq~' + surveyId
    });
    return post(url, body);
  }

  async function getSurveyTemplates() {
    const url = interopHost('administration_surveys/surveysectiontemplates/read');
    const body = params({
      pageSize: 10000
    });
    return post(url, body);
  }

  async function getSurveyQuestionsByTemplateId(templateId) {
    const url = interopHost(`administration_surveys/pollquestions/readpollquestions?surveySectionTemplateId=${templateId}`);
    const body = params({
      pageSize: 10000
    });
    return post(url, body);
  }

  async function getSurveySectionsByTemplateId(templateId) {
    const url = interopHost('administration_surveys/surveysections/read');
    const body = params({
      pageSize: 10000,
      filter: `SurveySectionTemplateId~eq~${templateId}`
    });
    return post(url, body);
  }

  async function getSurveySectionsById(sectionId) {
    const url = interopHost('administration_surveys/surveysections/read');
    const body = params({
      pageSize: 10000,
      filter: `Id~eq~${Array.isArray(sectionId) ? sectionId.join('~or~Id~eq~') : sectionId}`
    });
    return post(url, body);
  }

  async function findSectionsByTraining(nameBg) {
    const url = interopHost('administration_surveys/surveysections/read');
    const body = params({
      pageSize: 100,
      filter: `Training~eq~'${nameBg}'~and~Name~doesnotcontain~'обслужване'~and~Name~doesnotcontain~'информация'~and~Name~doesnotcontain~'свързани с курса'`
    });
    return (await post(url, body)).Data.map(s => s.Name);
  }

  async function findAnswersBySection(sectionNames) {
    const url = interopHost('administration_surveys/userpollanswers/read');
    const body = params({
      pageSize: 10000,
      filter: 'Section~eq~\'' + sectionNames.join('\'~or~Section~eq~\'') + '\''
    });
    return (await post(url, body)).Data;
  }

  async function findSurveyByTraining(nameBg) {
    const sections = await findSectionsByTraining(nameBg);
    console.log(sections);
    const answers = await findAnswersBySection(sections);
    const surveys = [...answers.reduce((p, c) => {
      p.add(c.SurveyId);
      return p;
    }, new Set())];
    return Promise.all(surveys.map(getSurveyById));
  }

  return {
    getSurveys,
    getSurveysByNameAndStartAndEndDate,
    getSurveyById,
    getSurveyAnswers,
    getSurveyTemplates,
    getSurveyQuestionsByTemplateId,
    getSurveySectionsByTemplateId,
    getSurveySectionsById,
    findSurveyByTraining
  };
}

/***/ }),

/***/ "./src/api/trainings/assessment.js":
/*!*****************************************!*\
  !*** ./src/api/trainings/assessment.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util */ "./src/api/util.js");

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getHomeworkResults(instanceId) {
    const uri = interopHost(`administration_crm/internalcoursecrmprofiles/readinternalcoursecrmprofiles/${instanceId}`);
    return await fetchNext();

    async function fetchNext(page = 1) {
      const body = params({
        sort: 'CreatedOn-desc',
        pageSize: 1000,
        page
      });
      const response = await post(uri, body);
      let result = response.Data;

      if (response.Total > page * 1000) {
        result = result.concat(await fetchNext(page + 1));
      }

      return result;
    }
  }

  async function getProtocol(instanceId) {
    const response = await fetch(interopHost(`administration_trainings/usersincourses/exporttrainingprotocol/${instanceId}`), {
      'credentials': 'include',
      'headers': {
        'Host': 'softuni.bg',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:97.0) Gecko/20100101 Firefox/97.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br',
        'Connection': 'keep-alive',
        'Referer': interopHost('administration_trainings/usersintrainingsmanagement'),
        'Upgrade-Insecure-Requests': 1,
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache'
      },
      'method': 'GET',
      'mode': 'cors'
    });
    const blob = await response.blob();
    const serializedBlob = new Uint8Array(await blob.arrayBuffer());
    const blobData = {
      type: blob.type,
      buffer: Array.from(serializedBlob)
    };
    return blobData;
  }

  async function uploadFile(url, formData) {
    const result = await fetch(url, {
      credentials: 'include',
      method: 'POST',
      body: formData
    });
    return result;
  }

  async function uploadExamResults(examName, examId, combo, fileDescriptor) {
    const url = interopHost('administration_trainings/exams/importexamresults');
    const {
      blob,
      filename
    } = await (0,_util__WEBPACK_IMPORTED_MODULE_0__.parseCrossBrowserFile)(fileDescriptor);
    const formData = new FormData();
    const rvt = await obtainRVT();
    formData.append('__RequestVerificationToken', rvt);
    formData.append('ExamId_input', examName);
    formData.append('ExamId', examId);
    formData.append('ResultsFile', blob, filename);

    if (combo.importPractice) {
      formData.append('ImportPreferences', 1); // Practice
    }

    if (combo.importQuiz) {
      formData.append('ImportPreferences', 2); // Quiz
    }

    formData.append('UsernameColumn', 1);
    formData.append('ResultColumn', 2);
    formData.append('CommentColumn', 3);
    formData.append('TheoryResultColumn', 4);
    formData.append('TheoryCommentColumn', 5);
    const result = await uploadFile(url, formData);
    return processExamResultOutcome(result);
  }

  async function processExamResultOutcome(result) {
    const page = await result.text();
    const successPattern = /<h3>Успешни записи:(.+?)<\/h3>/us;
    const failurePattern = /<h3>Неуспешни записи:(.+?)<\/h3>/us;
    const userlistPattern = /<p>.*?Успешно бяха вмъкнати резултатите на следните потребители:(.+?)<\/p>/us;

    try {
      const successful = Number(successPattern.exec(page)[1].trim());
      const failed = Number(failurePattern.exec(page)[1].trim());
      const list = userlistPattern.exec(page)[1].trim().split(',').map(u => u.trim());
      return {
        successful,
        failed,
        list
      };
    } catch (err) {
      console.error(err);
      throw new Error('Error processing file');
    }
  }

  async function obtainRVT() {
    const url = interopHost('administration_trainings/exams/importexamresults');
    const pageData = await get(url);
    const pattern = /<input.*?name="__RequestVerificationToken".*?value="(.+?)".*?>/i;
    const rvt = pattern.exec(pageData)[1];
    return rvt;
  }

  return {
    getHomeworkResults,
    getProtocol,
    uploadExamResults
  };
}

/***/ }),

/***/ "./src/api/trainings/events.js":
/*!*************************************!*\
  !*** ./src/api/trainings/events.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getEvents(instanceId) {
    const uri = interopHost('administration_trainings/traininggrouplectures/read');
    const body = params({
      sort: 'StartDateTime-asc',
      page: 1,
      pageSize: 100,
      group: '',
      filter: `TrainingId~eq~${instanceId}`
    });
    return (await post(uri, body)).Data;
  }

  async function updateEvent(event) {
    const uri = interopHost('administration_trainings/traininggrouplectures/update');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: event.Id,
      TrainingGroupId: event.TrainingGroupId,
      TrainingGroupName: event.TrainingGroupName,
      LectureId: event.LectureId,
      LectureName: event.LectureName,
      TrainingId: event.TrainingId,
      StartDateTime: event.StartDateTime,
      EndDateTime: event.EndDateTime,
      HasLiveStream: event.HasLiveStream,
      TrainingLabId: event.TrainingLabId,
      TrainingLabName: event.TrainingLabName,
      LastEditedUsername: '',
      CreatedOn: '',
      ModifiedOn: '',
      TrainingGroupId_input: ''
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function createEvent(event) {
    const uri = interopHost('administration_trainings/traininggrouplectures/create');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: event.Id,
      TrainingGroupId: event.TrainingGroupId,
      TrainingGroupName: event.TrainingGroupName,
      LectureId: event.LectureId,
      LectureName: event.LectureName,
      TrainingId: event.TrainingId,
      StartDateTime: event.StartDateTime,
      EndDateTime: event.EndDateTime,
      HasLiveStream: event.HasLiveStream,
      TrainingLabId: event.TrainingLabId,
      TrainingLabName: event.TrainingLabName,
      LastEditedUsername: '',
      CreatedOn: '',
      ModifiedOn: '',
      TrainingGroupId_input: ''
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function destroyEvent(event) {
    const uri = interopHost('administration_trainings/traininggrouplectures/destroy');
    const body = params({
      sort: '',
      group: '',
      filter: ''
    });
    Object.assign(body, event);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    return post(uri, body);
  }

  async function getEventsByDate(startDate, endDate) {
    // Date format yyyy-mm-dd example: 2020-03-25
    const uri = interopHost('administration_trainings/traininggrouplectures/read');
    const body = params({
      sort: 'StartDateTime-asc',
      page: 1,
      pageSize: 10000,
      group: '',
      filter: `StartDateTime~gte~datetime'${startDate}T00-00-00'~and~EndDateTime~lte~datetime'${endDate}T23-59-59'`
    });
    return (await post(uri, body)).Data;
  }

  async function getEventsById(eventId) {
    // Date format yyyy-mm-dd example: 2020-03-25
    const uri = interopHost('administration_trainings/traininggrouplectures/read');
    const body = params({
      sort: 'StartDateTime-asc',
      page: 1,
      pageSize: 1000,
      group: '',
      filter: `Id~eq~${eventId}`
    });
    return (await post(uri, body)).Data;
  }

  return {
    getEvents,
    updateEvent,
    createEvent,
    destroyEvent,
    getEventsByDate,
    getEventsById
  };
}

/***/ }),

/***/ "./src/api/trainings/exams.js":
/*!************************************!*\
  !*** ./src/api/trainings/exams.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getExamsById(ids) {
    if (Array.isArray(ids) == false) {
      ids = [ids];
    }

    if (ids.length == 0) {
      return [];
    }

    const uri = interopHost('administration_trainings/exams/read');
    const body = params({
      pageSize: 10000,
      filter: `Id~eq~${ids.join('~or~Id~eq~')}`
    });
    return (await post(uri, body)).Data;
  }

  async function getExamsByCourse(nameBg, instanceId) {
    const uri = interopHost('administration_trainings/exams/read');

    const filter = (() => {
      if (interopAppId() === 'softuni.bg') {
        return `TrainingNamesString~contains~'${nameBg}'`;
      } else {
        return '';
      }
    })();

    const body = params({
      pageSize: 10000,
      filter
    });
    const data = await post(uri, body);
    return data.Data.filter(e => e.PrimaryTrainings.filter(t => t.Id == instanceId).length > 0 || e.RetakenTrainings.filter(t => t.Id == instanceId).length > 0);
  }

  async function getExamsByName(query) {
    const uri = interopHost('administration_trainings/exams/read');

    const filter = (() => {
      if (Array.isArray(query)) {
        return `(NameBg~contains~'${query.join('\'~or~NameBg~contains~\'')}')~or~(NameEn~contains~'${query.join('\'~or~NameEn~contains~\'')}')`;
      } else {
        return `NameBg~contains~'${query}'~or~NameEn~contains~'${query}'`;
      }
    })();

    const body = params({
      sort: 'CreatedOn-desc',
      pageSize: 20,
      filter
    });
    const data = await post(uri, body);

    if (Array.isArray(query)) {
      const fullMatch = await getExamsByName(query.join(' '));
      const filtered = data.Data.filter(r => fullMatch.some(x => x.Id == r.Id) == false);
      return fullMatch.concat(filtered.slice(0, 20 - fullMatch.length));
    } else {
      return data.Data;
    }
  }

  async function getExamGroupsByExamId(examId) {
    if (Array.isArray(examId) == false) {
      examId = [examId];
    }

    if (examId.length == 0) {
      return [];
    }

    const uri = interopHost('administration_trainings/examgroups/read');
    const body = params({
      pageSize: 10000,
      filter: `ExamId~eq~${examId.join('~or~ExamId~eq~')}`
    });
    return (await post(uri, body)).Data;
  }

  async function getExamGroupsByDate(startDate, endDate) {
    // Date format yyyy-mm-dd example: 2020-03-25
    const uri = interopHost('administration_trainings/examgroups/read');
    const body = params({
      sort: 'StartTime-asc',
      page: 1,
      pageSize: 10000,
      group: '',
      filter: `StartTime~gte~datetime'${startDate}T00-00-00'~and~EndTime~lte~datetime'${endDate}T23-59-59'`
    });
    return (await post(uri, body)).Data;
  }

  async function getEnrolledByGroupId(examGroupId) {
    const uri = interopHost(`administration_trainings/examgroupparticipants/read?foreignKeyId=${examGroupId}`);
    const body = params({
      pageSize: 10000
    });
    return (await post(uri, body)).Data;
  }

  async function createExam(exam) {
    const uri = interopHost('administration_trainings/exams/create');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: exam.Id,
      NameBg: exam.NameBg,
      NameEn: exam.NameEn,
      Type: exam.Type,
      AllowChoosingSeatsWithComputer: exam.AllowChoosingSeatsWithComputer,
      AllowAllUsersInTrainingsToSitExam: exam.AllowAllUsersInTrainingsToSitExam,
      ExamGroupEnrollmentDeadline: exam.ExamGroupEnrollmentDeadline,
      TrainingNamesString: '',
      CreatedOn: '',
      ModifiedOn: ''
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    }); // Two-step process is necessary because of a server bug when the exam has associated training instances

    const result = await post(uri, body);

    if (result.Errors !== null) {
      return result;
    } else {
      const item = result.Data[0];
      item.PrimaryTrainings = exam.PrimaryTrainings;
      item.RetakenTrainings = exam.RetakenTrainings;
      const deadline = new Date(Number(item.ExamGroupEnrollmentDeadline.match(/\d+/)[0]));
      item.ExamGroupEnrollmentDeadline = Number.isNaN(deadline) ? '' : deadline.toISOString();
      return updateExam(item);
    }
  }

  async function updateExam(exam) {
    const uri = interopHost('administration_trainings/exams/update');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: exam.Id,
      NameBg: exam.NameBg,
      NameEn: exam.NameEn,
      Type: exam.Type,
      AllowChoosingSeatsWithComputer: exam.AllowChoosingSeatsWithComputer,
      AllowAllUsersInTrainingsToSitExam: exam.AllowAllUsersInTrainingsToSitExam,
      ExamGroupEnrollmentDeadline: exam.ExamGroupEnrollmentDeadline,
      TrainingNamesString: '',
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:01.317'
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    exam.PrimaryTrainings.forEach(trainingsToBody('PrimaryTrainings'));
    exam.RetakenTrainings.forEach(trainingsToBody('RetakenTrainings'));
    return post(uri, body);

    function trainingsToBody(propName) {
      return function (training, index) {
        body[`${propName}[${index}].Id`] = training.Id;
        body[`${propName}[${index}].Name`] = training.NameBg;
        body[`${propName}[${index}].NameBg`] = training.NameBg;
        body[`${propName}[${index}].NameEn`] = training.NameEn;
      };
    }
  }

  async function createExamGroup(group) {
    const uri = interopHost('administration_trainings/examgroups/create');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: '0',
      ExamId: group.ExamId,
      ExamName: '',
      StartTime: group.StartTime,
      EndTime: group.EndTime,
      TrainingLabId: group.TrainingLabId,
      JudgeSystemContestId: group.JudgeSystemContestId,
      TestSystemTestId: group.TestSystemTestId,
      ExamGroupParticipantsCount: group.ExamGroupParticipantsCount,
      Limit: group.Limit,
      IsAddedToGoogleCalendar: group.IsAddedToGoogleCalendar,
      CustomEnrollmentSuccessMessage: group.CustomEnrollmentSuccessMessage,
      CreatedOn: '',
      ModifiedOn: ''
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function updateExamGroup(group) {
    const uri = interopHost('administration_trainings/examgroups/update');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: group.Id,
      ExamId: group.ExamId,
      ExamName: group.ExamName,
      StartTime: group.StartTime,
      EndTime: group.EndTime,
      TrainingLabId: group.TrainingLabId,
      JudgeSystemContestId: group.JudgeSystemContestId,
      TestSystemTestId: group.TestSystemTestId,
      ExamGroupParticipantsCount: group.ExamGroupParticipantsCount,
      Limit: group.Limit,
      IsAddedToGoogleCalendar: group.IsAddedToGoogleCalendar,
      CustomEnrollmentSuccessMessage: group.CustomEnrollmentSuccessMessage,
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:01.317'
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function destroyExamGroup(group) {
    const uri = interopHost('administration_trainings/examgroups/destroy');
    const body = params({
      sort: '',
      group: '',
      filter: ''
    });
    Object.assign(body, group);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    return post(uri, body);
  }

  return {
    getExamsById,
    getExamsByCourse,
    getExamsByName,
    getExamGroupsByExamId,
    getEnrolledByGroupId,
    getExamGroupsByDate,
    createExam,
    updateExam,
    createExamGroup,
    updateExamGroup,
    destroyExamGroup
  };
}

/***/ }),

/***/ "./src/api/trainings/groups.js":
/*!*************************************!*\
  !*** ./src/api/trainings/groups.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getInsanceGroups(instanceId) {
    const uri = interopHost('administration_trainings/traininggroups/read');
    const body = params({
      pageSize: 100,
      filter: `TrainingId~eq~${instanceId}`
    });
    return (await post(uri, body)).Data;
  }

  async function getGroupById(groupId) {
    const uri = interopHost('administration_trainings/traininggroups/read');
    const body = params({
      pageSize: 100,
      filter: `Id~eq~${groupId}`
    });
    return (await post(uri, body)).Data[0];
  }

  async function createTrainingGroup(group) {
    const uri = interopHost('administration_trainings/traininggroups/create');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: group.Id,
      TrainingId: group.TrainingId,
      TrainingName: group.TrainingName,
      TrainingLabId: group.TrainingLabId,
      Name: group.Name,
      DayOfWeek: group.DayOfWeek,
      StartTime: group.StartTime,
      EndTime: group.EndTime,
      SkipWeeksCount: group.SkipWeeksCount,
      WeekLectureNumber: group.WeekLectureNumber,
      PeopleLimit: group.PeopleLimit,
      TakenPlaces: group.TakenPlaces,
      IsAddedToGoogleCalendar: group.IsAddedToGoogleCalendar,
      CreatedOn: '',
      ModifiedOn: ''
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function destroyGroup(group) {
    const uri = interopHost('administration_trainings/traininggroups/destroy');
    const body = params({
      sort: '',
      group: '',
      filter: ''
    });
    Object.assign(body, group);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    return post(uri, body);
  }

  return {
    getInsanceGroups,
    getGroupById,
    createTrainingGroup,
    destroyGroup
  };
}

/***/ }),

/***/ "./src/api/trainings/lectures.js":
/*!***************************************!*\
  !*** ./src/api/trainings/lectures.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getInstanceLectures(instanceId) {
    const uri = interopHost(`administration_trainings/lectures/read?foreignKeyId=${instanceId}`);
    const body = params({
      sort: 'OrderBy-asc',
      pageSize: 100
    });
    return (await post(uri, body)).Data;
  }

  async function getLecturesForExamsByTrainingId(trainingId) {
    const uri = interopHost(`administration_trainings/lectures/read?foreignKeyId=${trainingId}`);
    const examKeywords = ['exam', 'defence', 'defense', 'изпит', 'защита'];
    const examExcludeKeywords = ['preparation', 'подготовка'];
    const body = params({
      sort: 'OrderBy-asc',
      pageSize: 100,
      filter: `(NameBg~contains~'${examKeywords.join('\'~or~NameBg~contains~\'')}')~and~(NameBg~doesnotcontain~'${examExcludeKeywords.join('\'~and~NameBg~doesnotcontain~\'')}')`
    });
    return (await post(uri, body)).Data;
  }

  async function updateLecture(lecture) {
    console.log(lecture);
    const uri = interopHost(`administration_trainings/lectures/update?foreignKeyId=${lecture.TrainingId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: lecture.Id,
      TrainingId: lecture.TrainingId,
      NameBg: lecture.NameBg,
      NameEn: lecture.NameEn,
      HasManualNumberOfStudyHours: lecture.HasManualNumberOfStudyHours,
      NumberOfStudyHours: lecture.NumberOfStudyHours,
      IsExcludedFromCertificate: lecture.IsExcludedFromCertificate,
      HasHomework: lecture.HasHomework,
      ResourceMailsState: lecture.ResourceMailsState,
      HomeworkMailsState: lecture.HomeworkMailsState,
      JudgeContestId: lecture.JudgeContestId,
      AlphaJudgeContestId: lecture.AlphaJudgeContestId,
      OrderBy: lecture.OrderBy,
      DescriptionBg: lecture.DescriptionBg,
      DescriptionEn: lecture.DescriptionEn,
      DatesInfo: lecture.DatesInfo || [],
      Lecturer: lecture.Lecturer,
      LectureType: lecture.LectureType,
      ExcludeFromCalendar: lecture.ExcludeFromCalendar,
      HasLiveStream: lecture.HasLiveStream,
      ExamPassword: lecture.ExamPassword,
      DiscordChannel: lecture.DiscordChannel,
      SlidoCode: lecture.SlidoCode,
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:02.317'
    });
    serializeDatesInfo(body);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function createLecture(lecture) {
    const uri = interopHost(`administration_trainings/lectures/create?foreignKeyId=${lecture.TrainingId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: lecture.Id,
      TrainingId: lecture.TrainingId,
      NameBg: lecture.NameBg,
      NameEn: lecture.NameEn,
      HasManualNumberOfStudyHours: lecture.HasManualNumberOfStudyHours,
      NumberOfStudyHours: lecture.NumberOfStudyHours,
      IsExcludedFromCertificate: lecture.IsExcludedFromCertificate,
      HasHomework: lecture.HasHomework,
      ResourceMailsState: lecture.ResourceMailsState,
      HomeworkMailsState: lecture.HomeworkMailsState,
      JudgeContestId: lecture.JudgeContestId,
      AlphaJudgeContestId: lecture.AlphaJudgeContestId,
      OrderBy: lecture.OrderBy,
      DescriptionBg: lecture.DescriptionBg,
      DescriptionEn: lecture.DescriptionEn,
      DatesInfo: lecture.DatesInfo || [],
      Lecturer: lecture.Lecturer,
      LectureType: lecture.LectureType,
      ExcludeFromCalendar: lecture.ExcludeFromCalendar,
      HasLiveStream: lecture.HasLiveStream,
      ExamPassword: lecture.ExamPassword,
      DiscordChannel: lecture.DiscordChannel,
      SlidoCode: lecture.SlidoCode,
      CreatedOn: '',
      ModifiedOn: ''
    });
    serializeDatesInfo(body);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function destroyLecture(lecture) {
    const uri = interopHost(`administration_trainings/lectures/destroy?foreignKeyId=${lecture.TrainingId}`);
    const body = params({
      sort: '',
      group: '',
      filter: ''
    });
    Object.assign(body, lecture);
    serializeDatesInfo(body);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    return post(uri, body);
  }

  async function getLectureDetails(trainingId, lectureId) {
    const url = interopHost(`trainings/trainings/getlecturedetails?trainingId=${trainingId}&lectureId=${lectureId}`);
    return get(url);
  }

  function serializeDatesInfo(body) {
    const datesInfo = body.DatesInfo;
    delete body.DatesInfo;

    for (let i = 0; i < datesInfo.length; i++) {
      const date = datesInfo[i];
      body[`DatesInfo[${i}].Start`] = date.Start;
      body[`DatesInfo[${i}].End`] = date.End;
      body[`DatesInfo[${i}].ExtraInformation`] = date.ExtraInformation;
    }
  }

  return {
    getInstanceLectures,
    updateLecture,
    createLecture,
    destroyLecture,
    getLectureDetails,
    getLecturesForExamsByTrainingId
  };
}

/***/ }),

/***/ "./src/api/trainings/seminars.js":
/*!***************************************!*\
  !*** ./src/api/trainings/seminars.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getSeminarsByDate(startDate, endDate) {
    // Date format yyyy-mm-dd example: 2020-03-25
    const uri = interopHost('administration_trainings/seminars/read');
    const body = params({
      sort: 'StartDate-asc',
      page: 1,
      pageSize: 10000,
      group: '',
      filter: `StartDate~gte~datetime'${startDate}T00-00-00'~and~EndDate~lte~datetime'${endDate}T23-59-59'`
    });
    return (await post(uri, body)).Data;
  }

  return {
    getSeminarsByDate
  };
}

/***/ }),

/***/ "./src/api/trainings/skills.js":
/*!*************************************!*\
  !*** ./src/api/trainings/skills.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getSkillsByInstance(name, instanceId) {
    const body = params({
      pageSize: 10000,
      sort: 'OrderBy-asc'
    });
    body.filter = `MergedTrainings~contains~'${name}'`;
    const data = await Promise.all([post(interopHost('administration_trainings/fasttrackinstanceskills/read'), body), post(interopHost('administration_trainings/courseinstanceskills/read'), body)]);
    let response = [];
    response = response.concat(data[0].Data.filter(i => i.Trainings.filter(t => t.Id == instanceId).length > 0).map(s => {
      s.Type = 'open';
      return s;
    }));
    response = response.concat(data[1].Data.filter(i => i.Trainings.filter(t => t.Id == instanceId).length > 0).map(s => {
      s.Type = 'main';
      return s;
    }));
    return response;
  }

  async function updateSkill(skill) {
    const uri = interopHost(`administration_trainings/${skill.Type === 'main' ? 'courseinstanceskills' : 'fasttrackinstanceskills'}/update`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: skill.Id,
      TextBg: skill.TextBg,
      OrderBy: skill.OrderBy,
      MergedTrainings: skill.MergedTrainings,
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:01.317'
    });

    for (let i = 0; i < skill.Trainings.length; i++) {
      const training = skill.Trainings[i];
      body[`Trainings[${i}].Id`] = training.Id;
      body[`Trainings[${i}].Name`] = training.Name;
      body[`Trainings[${i}].NameBg`] = training.NameBg;
      body[`Trainings[${i}].NameEn`] = training.NameEn;
    }

    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    const result = await post(uri, body);
    result.Data[0].Type = skill.Type;
    return result;
  }

  async function createSkill(skill) {
    const uri = interopHost(`administration_trainings/${skill.Type === 'main' ? 'courseinstanceskills' : 'fasttrackinstanceskills'}/create`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: skill.Id,
      TextBg: skill.TextBg,
      OrderBy: skill.OrderBy,
      MergedTrainings: skill.MergedTrainings,
      CreatedOn: '',
      ModifiedOn: ''
    });

    for (let i = 0; i < skill.Trainings.length; i++) {
      const training = skill.Trainings[i];
      body[`Trainings[${i}].Id`] = training.Id;
      body[`Trainings[${i}].Name`] = training.Name;
      body[`Trainings[${i}].NameBg`] = training.NameBg;
      body[`Trainings[${i}].NameEn`] = training.NameEn;
    }

    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    const result = await post(uri, body);
    result.Data[0].Type = skill.Type;
    return result;
  }

  async function destroySkill(skill) {
    const uri = interopHost(`administration_trainings/${skill.Type === 'main' ? 'courseinstanceskills' : 'fasttrackinstanceskills'}/destroy`);
    const body = params({
      sort: '',
      group: '',
      filter: ''
    });
    Object.assign(body, skill);

    for (let i = 0; i < skill.Trainings.length; i++) {
      const training = skill.Trainings[i];
      body[`Trainings[${i}].Id`] = training.Id;
      body[`Trainings[${i}].Name`] = training.Name;
      body[`Trainings[${i}].NameBg`] = training.NameBg;
      body[`Trainings[${i}].NameEn`] = training.NameEn;
    }

    delete body.Trainings;
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    return post(uri, body);
  }

  async function searchSkills(query, type) {
    const uri = interopHost(`administration_trainings/${type === 'main' ? 'courseinstanceskills' : 'fasttrackinstanceskills'}/read`);
    const body = params({
      pageSize: 15,
      sort: 'OrderBy-asc',
      filter: `TextBg~contains~'${query}'`
    });
    const data = await post(uri, body);
    data.Data.forEach(s => s.Type = type);
    return data.Data;
  }

  return {
    getSkillsByInstance,
    updateSkill,
    createSkill,
    destroySkill,
    searchSkills
  };
}

/***/ }),

/***/ "./src/api/trainings/trainings.js":
/*!****************************************!*\
  !*** ./src/api/trainings/trainings.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _events__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./events */ "./src/api/trainings/events.js");
/* harmony import */ var _lectures__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./lectures */ "./src/api/trainings/lectures.js");
/* harmony import */ var _skills__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./skills */ "./src/api/trainings/skills.js");
/* harmony import */ var _groups__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./groups */ "./src/api/trainings/groups.js");
/* harmony import */ var _exams__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./exams */ "./src/api/trainings/exams.js");
/* harmony import */ var _assessment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./assessment */ "./src/api/trainings/assessment.js");
/* harmony import */ var _seminars__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./seminars */ "./src/api/trainings/seminars.js");







/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get,
  interopPlatformHost
}) {
  const eventsApi = (0,_events__WEBPACK_IMPORTED_MODULE_0__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const lecturesApi = (0,_lectures__WEBPACK_IMPORTED_MODULE_1__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const skillsApi = (0,_skills__WEBPACK_IMPORTED_MODULE_2__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const groupsApi = (0,_groups__WEBPACK_IMPORTED_MODULE_3__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const examsApi = (0,_exams__WEBPACK_IMPORTED_MODULE_4__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const assessmentApi = (0,_assessment__WEBPACK_IMPORTED_MODULE_5__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const seminarsApi = (0,_seminars__WEBPACK_IMPORTED_MODULE_6__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });

  async function searchByName(body) {
    const query = body.query.filter(f => f.length > 0);
    const courses = await Promise.all([body.main && getMainInstances(body.page, query), body.open && getOpenInstances(body.page, query), body.general && getGeneralInstances(body.page, query)]);
    const result = [];

    for (let course of courses[0] || []) {
      result.push({
        Id: course.Id,
        NameBg: course.NameBg,
        Type: 'main',
        CourseId: course.CourseId
      });
    }

    for (let course of courses[1] || []) {
      result.push({
        Id: course.Id,
        NameBg: course.NameBg,
        Type: 'open',
        CourseId: course.CourseId
      });
    }

    for (let course of courses[2] || []) {
      result.push({
        Id: course.Id,
        NameBg: course.NameBg,
        Type: 'general',
        CourseId: course.CourseId
      });
    }

    return result;
  }

  async function searchTrainingsByName(name, exact = false) {
    if (Array.isArray(name) == false) {
      name = [name];
    }

    const uri = interopHost('administration_trainings/trainings/read');
    const body = params({
      pageSize: 50,
      filter: exact ? `NameBg~eq~'${name.filter(s => s.length > 0).join('\'~or~NameBg~eq~\'')}'` : `NameBg~contains~'${name.filter(s => s.length > 0).join('\'~or~NameBg~contains~\'')}'`,
      sort: 'StartDate-desc',
      page: 1
    });
    return (await post(uri, body)).Data;
  }

  async function searchCourses(query) {
    const url = interopHost('administration_trainings/courses/read');
    const filter = `Name~contains~'${query.split(' ').filter(s => s.length > 0).join('\'~and~Name~contains~\'')}'`;
    const body = params({
      pageSize: 100,
      filter,
      sort: 'CreatedOn-desc'
    });
    const result = (await post(url, body)).Data;
    result.forEach(r => {
      r.NameBg = r.Name;
      r.NameEn = r.Name;
    });
    return result;
  }

  async function searchCourseInstancesByCourseNameAndInstanceId(courseNames, instanceIds, filter = undefined) {
    if (Array.isArray(courseNames) == false) {
      courseNames = [courseNames];
    }

    const url = interopHost('administration_trainings/courses/read');
    const coursesFilter = `Name~contains~'${courseNames.filter(s => s.length > 0).join('\'~and~Name~contains~\'')}'`;
    const body = params({
      pageSize: 100,
      filter: coursesFilter,
      sort: 'CreatedOn-desc'
    });
    const result = (await post(url, body)).Data;
    result.forEach(r => {
      r.NameBg = r.Name;
      r.NameEn = r.Name;
    });
    let courseInstancesPromises = [];
    result.forEach(c => {
      courseInstancesPromises.push(getCourseInstances(c.Id, filter));
    });

    if (Array.isArray(instanceIds) == false) {
      instanceIds = [instanceIds];
    }

    let allCourseInstances = (await Promise.all(courseInstancesPromises)).reduce((a, c) => a.concat(c), []);
    let filteredCourseInstances = instanceIds.length == 0 ? allCourseInstances : allCourseInstances.filter(ci => instanceIds.includes(ci.Id));
    return filteredCourseInstances;
  }

  async function getMainInstances(page, query) {
    const uri = interopHost('administration_trainings/usersincourses/readcourseinstances');
    const filter = query.map(e => `NameBg~contains~'${e}'`).join('~and~');
    const body = params({
      sort: 'IsActive-desc~CreatedOn-desc',
      page,
      pageSize: 25,
      filter
    });
    const data = await post(uri, body);
    return data.Data.map(e => ({
      Id: e.Id,
      NameBg: e.NameBg,
      CourseId: e.CourseId
    }));
  }

  async function getOpenInstances(page, query) {
    const uri = interopHost('/administration_trainings/usersinfasttracks/readfasttrackinstances');
    const filter = query.map(e => `NameBg~contains~'${e}'`).join('~and~');
    const body = params({
      sort: 'IsActive-desc~CreatedOn-desc',
      page,
      pageSize: 25,
      filter
    });
    const data = await post(uri, body);
    return data.Data.map(e => ({
      Id: e.Id,
      NameBg: e.NameBg,
      CourseId: e.CourseId
    }));
  }

  async function getGeneralInstances(page, query) {
    const uri = interopHost('administration_trainings/usersingeneralcourseinstances/readgeneralcourseinstances');
    const filter = query.map(e => `NameBg~contains~'${e}'`).join('~and~');
    const body = params({
      sort: 'IsActive-desc~CreatedOn-desc',
      page,
      pageSize: 25,
      filter
    });
    const data = await post(uri, body);
    return data.Data.map(e => ({
      Id: e.Id,
      NameBg: e.NameBg,
      CourseId: e.CourseId
    }));
  }

  async function getCourseData(courseId) {
    const uri = interopHost('administration_trainings/courses/read');
    const body = params({
      filter: `Id~eq~'${courseId}'`
    });
    return (await post(uri, body)).Data[0];
  }

  async function getCourseInstances(courseId, filter = undefined) {
    const body = params({
      sort: 'StartDate-desc',
      pageSize: 100
    });
    const data = await Promise.all([filter == undefined || filter.main === true ? post(interopHost(`administration_trainings/courseinstances/read?foreignKeyId=${courseId}`), body) : Promise.resolve(true), filter == undefined || filter.main === true ? post(interopHost(`administration_trainings/fasttrackinstances/read?foreignKeyId=${courseId}`), body) : Promise.resolve(true), filter == undefined || filter.general === true ? post(interopHost(`administration_trainings/generalcourseinstances/read?foreignKeyId=${courseId}`), body) : Promise.resolve(true)]);
    let response = [];
    response = response.concat(data[0].Data != undefined ? data[0].Data.map(c => {
      c.InstanceRefType = 'main';
      return c;
    }) : []);
    response = response.concat(data[1].Data != undefined ? data[1].Data.map(c => {
      c.InstanceRefType = 'open';
      return c;
    }) : []);
    response = response.concat(data[2].Data != undefined ? data[2].Data.map(c => {
      c.InstanceRefType = 'general';
      return c;
    }) : []);
    return response;
  }

  async function getInstanceData(instanceId, courseId, type) {
    try {
      if (type) {
        return getInstanceDataByType(instanceId, courseId, type);
      } else {
        const queryResults = await Promise.all([getInstanceDataByType(instanceId, courseId, 'main'), getInstanceDataByType(instanceId, courseId, 'open'), getInstanceDataByType(instanceId, courseId, 'general')]);
        return queryResults.filter(e => e !== undefined)[0];
      }
    } catch (e) {
      console.log(e);
    }
  }

  async function getInstanceDataByType(instanceId, courseId, type) {
    const uri = (() => {
      switch (type) {
        case 'main':
          return interopHost(`administration_trainings/courseinstances/read?foreignKeyId=${courseId}`);

        case 'open':
          return interopHost(`administration_trainings/fasttrackinstances/read?foreignKeyId=${courseId}`);

        case 'general':
          return interopHost(`administration_trainings/generalcourseinstances/read?foreignKeyId=${courseId}`);
      }
    })();

    const body = params({
      filter: `Id~eq~${instanceId}`
    });
    const instance = (await post(uri, body)).Data[0];

    if (instance !== undefined) {
      instance.InstanceRefType = type;
    }

    return instance;
  }

  async function getInstanceOverview(instanceIds) {
    if (Array.isArray(instanceIds) == false) {
      instanceIds = [instanceIds];
    }

    const uri = interopHost('administration_trainings/trainings/read');
    const body = params({
      pageSize: 1000,
      filter: `TrainingId~eq~${instanceIds.join('~or~TrainingId~eq~')}`
    });
    return (await post(uri, body)).Data;
  }

  function updateCourse(course) {
    const uri = interopHost('administration_trainings/courses/update');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: course.Id,
      Name: course.Name,
      DescriptionBg: course.DescriptionBg,
      DescriptionEn: course.DescriptionEn,
      UrlName: course.UrlName,
      IconUrl: course.IconUrl,
      Credits: course.Credits,
      IsActive: course.IsActive,
      IsHidden: course.IsHidden,
      OrderBy: course.OrderBy,
      MergedTags: course.MergedTags,
      CourseCategoryId: course.CourseCategoryId,
      CourseDifficultyLevel: course.CourseDifficultyLevel,
      CourseDifficultyLevelDescriptionBg: course.CourseDifficultyLevelDescriptionBg,
      CourseDifficultyLevelDescriptionEn: course.CourseDifficultyLevelDescriptionEn,
      CreatedOn: course.CreatedOn,
      ModifiedOn: course.ModifiedOn || course.CreatedOn
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function updateInstance(instance) {
    const uri = (() => {
      switch (instance.InstanceRefType) {
        case 'main':
          return interopHost(`administration_trainings/courseinstances/update?foreignKeyId=${instance.CourseId}`);

        case 'open':
          return interopHost(`administration_trainings/fasttrackinstances/update?foreignKeyId=${instance.CourseId}`);

        case 'general':
          return interopHost(`administration_trainings/generalcourseinstances/update?foreignKeyId=${instance.CourseId}`);

        default:
          return interopHost(`administration_trainings/fasttrackinstances/update?foreignKeyId=${instance.CourseId}`);
      }
    })();

    const body = Object.assign({}, instance, {
      sort: '',
      group: '',
      filter: '',
      ModifiedOn: instance.ModifiedOn || instance.CreatedOn
    });
    delete body.InstanceRefType;
    delete body.SharesLiveStreamWithTrainings;
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function getStudents(instanceId, type = 'main') {
    const uri = (() => {
      switch (type) {
        case 'main':
          return interopHost(`administration_trainings/usersincourses/read?foreignKeyId=${instanceId}`);

        case 'open':
          return interopHost(`administration_trainings/usersinfasttracks/read?foreignKeyId=${instanceId}`);

        case 'general':
          return interopHost(`administration_trainings/usersingeneralcourseinstances/read?foreignKeyId=${instanceId}`);
      }
    })();

    return await fetchNext();

    async function fetchNext(page = 1) {
      const body = params({
        sort: 'CreatedOn-desc',
        pageSize: 1000,
        page
      });
      const response = await post(uri, body);
      let result = response.Data;

      if (response.Total > page * 1000) {
        result = result.concat(await fetchNext(page + 1));
      }

      return result;
    }
  }

  async function getCourseEvents(instanceId) {
    const data = await Promise.all([getMainById(instanceId), getOpenById(instanceId), getGeneralById(instanceId), eventsApi.getEvents(instanceId)]);

    for (let i = 0; i < 3; i++) {
      if (data[i].Total > 0) {
        const response = {
          Id: data[i].Data[0].Id,
          CourseId: data[i].Data[0].CourseId,
          NameBg: data[i].Data[0].NameBg,
          Events: data[3],
          InstanceRefType: {
            0: 'main',
            1: 'open',
            2: 'general'
          }[i]
        };
        return response;
      }
    }

    throw new Error('Error fetching instance data: All searches returned 0 matches');
  }

  async function getAnyById(instanceId) {
    if (Array.isArray(instanceId) && instanceId.length === 0) {
      return [];
    }

    const result = await Promise.all([getMainById(instanceId), getOpenById(instanceId), getGeneralById(instanceId)]);

    for (let i = 0; i < result.length; i++) {
      const instance = result[i];

      if (instance.Total > 0) {
        const type = {
          0: 'main',
          1: 'open',
          2: 'general'
        }[i];
        instance.Data.forEach(i => i.InstanceRefType = type);
      }
    }

    return result.reduce((p, c) => p.concat(c.Data), []);
  }

  async function getMainById(instanceId) {
    const filter = (() => {
      if (Array.isArray(instanceId)) {
        return `Id~eq~${instanceId.join('~or~Id~eq~')}`;
      } else {
        return `Id~eq~${instanceId}`;
      }
    })();

    const uri = interopHost('administration_trainings/usersincourses/readcourseinstances');
    const body = params({
      pageSize: 10000,
      filter
    });
    return post(uri, body);
  }

  async function getOpenById(instanceId) {
    const filter = (() => {
      if (Array.isArray(instanceId)) {
        return `Id~eq~${instanceId.join('~or~Id~eq~')}`;
      } else {
        return `Id~eq~${instanceId}`;
      }
    })();

    const uri = interopHost('administration_trainings/usersinfasttracks/readfasttrackinstances');
    const body = params({
      pageSize: 10000,
      filter
    });
    return post(uri, body);
  }

  async function getGeneralById(instanceId) {
    const filter = (() => {
      if (Array.isArray(instanceId)) {
        return `Id~eq~${instanceId.join('~or~Id~eq~')}`;
      } else {
        return `Id~eq~${instanceId}`;
      }
    })();

    const uri = interopHost('administration_trainings/usersingeneralcourseinstances/readgeneralcourseinstances');
    const body = params({
      pageSize: 10000,
      filter
    });
    return post(uri, body);
  }

  async function getInstancePage(instanceId) {
    const uri = interopHost(`trainings/trainings/getcoursedetails?id=${instanceId}`);
    return get(uri);
  }

  async function getInstanceFullPage(url) {
    return get(url);
  }

  async function getTrainerNames(instanceId) {
    return (await fetch(interopHost(`kendoremotedata/gettrainersbytraining?trainingId=${instanceId}`), {
      'credentials': 'include',
      'headers': {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:96.0) Gecko/20100101 Firefox/96.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'X-Requested-With': 'XMLHttpRequest',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'no-cors',
        'Sec-Fetch-Site': 'same-origin'
      },
      'method': 'GET',
      'mode': 'cors'
    })).json();
  }

  return { ...eventsApi,
    ...lecturesApi,
    ...skillsApi,
    ...groupsApi,
    ...examsApi,
    ...assessmentApi,
    ...seminarsApi,
    searchByName,
    searchCourses,
    getCourseData,
    getCourseInstances,
    getInstanceData,
    getInstanceOverview,
    updateCourse,
    updateInstance,
    getStudents,
    getCourseEvents,
    getAnyById,
    getInstancePage,
    getInstanceFullPage,
    getTrainerNames,
    searchCourseInstancesByCourseNameAndInstanceId,
    searchTrainingsByName
  };
}

/***/ }),

/***/ "./src/api/users.js":
/*!**************************!*\
  !*** ./src/api/users.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getTrainingsByTrainer(userId) {
    const uri = (() => {
      if (interopAppId() === 'softuni.bg') {
        return interopHost(`administration_users/trainersintrainings/readtrainingsoftrainer?trainerId=${userId}`);
      } else {
        return interopHost(`Administration_Users/TrainersInTrainings/Read?foreignKey=${userId}&foreignKeyId=${userId}`);
      }
    })();

    const body = params({
      pageSize: 100,
      sort: 'ModifiedOn-desc'
    });
    const result = await post(uri, body);
    result.Data.forEach(t => {
      t.DescriptionBg = t.DescriptionBg || '';
      t.DescriptionEn = t.DescriptionEn || '';
    });
    return result;
  }

  async function getTrainerById(userId) {
    const uri = (() => {
      if (interopAppId() === 'softuni.bg') {
        return interopHost('administration_users/trainersintrainings/read');
      } else {
        return interopHost('Administration_Users/Trainers/Read');
      }
    })();

    const body = params({
      pageSize: 100,
      filter: `UserId~eq~'${userId}'`
    });
    return post(uri, body);
  }

  async function updateTrainingByTrainer(training) {
    const uri = (() => {
      if (interopAppId() === 'softuni.bg') {
        return interopHost('administration_users/trainersintrainings/UpdateTrainerInTraining');
      } else {
        return interopHost('Administration_Users/TrainersInTrainings/Update');
      }
    })();

    const body = params({
      TrainingId: training.TrainingId,
      TrainingName: training.TrainingName,
      TrainerFirstName: training.TrainerFirstName,
      TrainerLastName: training.TrainerLastName,
      TrainerId: training.TrainerId,
      TrainerOrderBy: training.TrainerOrderBy,
      IsPublicTrainer: training.IsPublicTrainer,
      DescriptionBg: training.DescriptionBg,
      DescriptionEn: training.DescriptionEn,
      TrainerPhotoPath: training.TrainerPhotoPath,
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:01.317'
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null || body[k] === undefined) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function createTrainingByTrainer(training) {
    const uri = interopAppId() === 'softuni.bg' ? interopHost(`administration_users/trainersintrainings/AddTrainerToTraining?userId=${training.TrainerId}`) : interopHost(`Administration_Users/TrainersInTrainings/Create?foreignKey=${training.TrainerId}`);
    const body = params({
      TrainingId: training.TrainingId,
      TrainingName: training.TrainingName,
      TrainerFirstName: training.TrainerFirstName,
      TrainerLastName: training.TrainerLastName,
      TrainerId: training.TrainerId,
      TrainerOrderBy: training.TrainerOrderBy,
      IsPublicTrainer: training.IsPublicTrainer,
      DescriptionBg: training.DescriptionBg,
      DescriptionEn: training.DescriptionEn,
      TrainerPhotoPath: training.TrainerPhotoPath,
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:01.317'
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null || body[k] === undefined) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function searchUsers(query, exclude) {
    const result = await Promise.all([searchUsersByName(query, exclude), searchUsersByUserName(query, exclude)]);
    return result[0].concat(result[1]);
  }

  async function destroyTrainingOfTrainer(training) {
    const uri = interopAppId() === 'softuni.bg' ? interopHost('administration_users/trainersintrainings/DeleteTrainerFromTraining') : interopHost('Administration_Users/TrainersInTrainings/Destroy');
    const body = Object.assign(params(), training);
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    Object.keys(body).forEach(k => {
      if (body[k] === null || body[k] === undefined) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function searchUsersByName(name, exclude) {
    const uri = interopHost('administration_users/users/read');
    let filter = name.includes(' ') ? `(FirstNameEn~eq~'${name.split(' ')[0]}'~and~LastNameEn~startswith~'${name.split(' ')[1]}')~or~(FirstNameBg~eq~'${name.split(' ')[0]}'~and~LastNameBg~startswith~'${name.split(' ')[1]}')` : `FirstNameEn~contains~'${name}'~or~LastNameEn~contains~'${name}'~or~FirstNameBg~contains~'${name}'~or~LastNameBg~contains~'${name}'`;

    if (Array.isArray(exclude)) {
      filter = `(${filter})~and~(Id~neq~'${exclude.join('\'~and~Id~neq~\'')}')`;
    }

    const body = params({
      sort: 'UserName-asc',
      pageSize: 5,
      filter
    });
    return (await post(uri, body)).Data;
  }

  async function searchUsersByUserName(name, exclude) {
    if (name.includes(' ')) {
      return [];
    }

    const uri = interopHost('administration_users/users/read');
    let filter = `UserName~contains~'${name}'`;

    if (Array.isArray(exclude)) {
      filter = `(${filter})~and~(Id~neq~'${exclude.join('\'~and~Id~neq~\'')}')`;
    }

    const body = params({
      sort: 'UserName-asc',
      pageSize: 5,
      filter
    });
    return (await post(uri, body)).Data;
  }

  async function getTrainersByTraining(trainingId) {
    const uri = interopHost(`Administration_Trainings/TrainingsWithTrainers/Read?foreignKey=${trainingId}&foreignKeyId=${trainingId}`);
    const body = params({
      pageSize: 10,
      sort: 'OrderBy-asc'
    });
    const result = await post(uri, body);
    result.Data.forEach(t => {
      t.DescriptionBg = t.DescriptionBg || '';
      t.DescriptionEn = t.DescriptionEn || '';
    });
    return result.Data;
  }

  return {
    getTrainingsByTrainer,
    getTrainerById,
    updateTrainingByTrainer,
    createTrainingByTrainer,
    destroyTrainingOfTrainer,
    searchUsers,
    getTrainersByTraining
  };
}

/***/ }),

/***/ "./src/api/util.js":
/*!*************************!*\
  !*** ./src/api/util.js ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "parseCrossBrowserFile": () => (/* binding */ parseCrossBrowserFile)
/* harmony export */ });
async function parseCrossBrowserFile(fileDescriptor) {
  let blob;
  let filename;

  if (fileDescriptor.fileUrl !== undefined) {
    blob = await (await fetch(fileDescriptor.fileUrl)).blob();
    filename = fileDescriptor.name;
  } else {
    blob = fileDescriptor.file;
    filename = fileDescriptor.file.name;
  }

  return {
    blob,
    filename
  };
}

/***/ }),

/***/ "./src/common/Emitter.js":
/*!*******************************!*\
  !*** ./src/common/Emitter.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Emitter)
/* harmony export */ });
class Emitter {
  constructor() {
    this.subscribers = new Map();
  }

  on(evtName, handler) {
    if (this.subscribers.has(evtName) == false) {
      this.subscribers.set(evtName, []);
    }

    this.subscribers.get(evtName).push(handler);
  }

  off(evtName, handler) {
    const subscribers = this.subscribers.get(evtName);

    if (subscribers) {
      const index = subscribers.indexOf(handler);

      if (index > -1) {
        subscribers.splice(index, 1);
      }
    }
  }

  emit(evtName, ...data) {
    const subscribers = this.subscribers.get(evtName);

    if (subscribers) {
      subscribers.forEach(fn => this.invoke(fn, ...data));
    }
  }

  invoke(fn, ...data) {
    if (typeof fn == 'function') {
      fn(...data);
    }
  }

}

/***/ }),

/***/ "./src/common/Modal.js":
/*!*****************************!*\
  !*** ./src/common/Modal.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModalControls": () => (/* binding */ ModalControls),
/* harmony export */   "ModalOption": () => (/* binding */ ModalOption),
/* harmony export */   "createDialog": () => (/* binding */ createDialog),
/* harmony export */   "createLoadingModal": () => (/* binding */ createLoadingModal),
/* harmony export */   "createModal": () => (/* binding */ createModal),
/* harmony export */   "default": () => (/* binding */ Modal)
/* harmony export */ });
/* harmony import */ var _util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/jsx-render-mod/dom */ "./src/util/jsx-render-mod/dom.js");
/* harmony import */ var _common_ProgressBar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../common/ProgressBar */ "./src/common/ProgressBar.js");


const icons = {
  question: 'glyphicon-question-sign',
  wait: 'glyphicon-hourglass',
  wrench: 'glyphicon-wrench',
  import: 'glyphicon-import',
  download: 'glyphicon-download-alt',
  chart: 'glyphicon-signal'
};
function Modal({
  message,
  children,
  onClose,
  icon = 'question'
}) {
  if (Array.isArray(message) == false) {
    message = [message];
  }

  const content = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "ses-modal-content"
  }, children);
  const modal = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("section", {
    className: "ses-modal"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "ses-modal-window"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "ses-modal-message"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", null, icon && (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("i", {
    className: `glyphicon ${icons[icon]} ses-modal-icon`
  })), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", null, message.map(m => (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("p", null, m)))), content, onClose !== undefined ? (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "ses-modal-close"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("a", {
    href: "javascript:void(0);",
    onClick: onClose
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("i", {
    class: "glyphicon glyphicon-remove",
    style: {
      color: 'red'
    }
  }))) : null));
  modal._content = content;
  return modal;
}
function ModalControls({
  children
}) {
  return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("table", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tbody", null, children));
}
function ModalOption({
  icon = null,
  onClick,
  children
}) {
  return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tr", {
    className: "ses-modal-active",
    onClick: onClick
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, icon), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, children));
}
/**
 * 
 * @param {string} message 
 * @param {HTMLElement | Array<HTMLElement>} children 
 * @param {Boolean} canClose 
 * @returns {InteractiveModal}
 */

function createModal(message, children, canClose = true, icon = 'question') {
  /** @type {InteractiveModal} */
  const modal = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(Modal, {
    message: message,
    onClose: canClose ? close : undefined,
    icon: icon
  }, children);

  if (canClose) {
    modal.addEventListener('click', onClick);
  }

  modal.close = close;
  modal.onClose = null;
  document.body.appendChild(modal);
  const div = modal.children[0];
  adjustPosition();
  const resizeObserver = new ResizeObserver(adjustPosition);
  resizeObserver.observe(modal._content);
  window.addEventListener('resize', adjustPosition);
  return modal;

  function onClick(e) {
    if (e.target === modal) {
      close();
    }
  }

  function close(propagate = true) {
    window.removeEventListener('resize', adjustPosition);
    resizeObserver.disconnect();
    modal.remove();

    if (typeof modal.onClose == 'function' && propagate) {
      modal.onClose();
    }
  }

  function adjustPosition() {
    const newTop = (modal.offsetHeight - div.offsetHeight) / 3;
    div.style['margin-top'] = newTop + 'px';
  }
}
/**
 * @param {string} message 
 * @param {HTMLElement | Array<HTMLElement>} content 
 * @param {Array<OptionDescriptor>} options 
 * @param {Boolean} canClose 
 * @returns {Promise<boolean>}
 */

function createDialog(message, content, options, canClose = true, icon = 'question') {
  return new Promise((resolve, reject) => {
    const controls = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(ModalControls, null, options.map(createOption.bind(null, onConfirm, onCancel)));
    const modal = createModal(message, [content, controls].flat(1), canClose, icon);

    modal.onClose = () => resolve(false);

    function onConfirm() {
      modal.close(false);
      resolve(true);
    }

    function onCancel() {
      modal.close(false);
      resolve(false);
    }
  });
}
/**
 * @param {Function} onConfirm 
 * @param {Function} onCancel 
 * @param {OptionDescriptor | OptionEntry} option 
 * @returns {ModalOption}
 */

function createOption(onConfirm, onCancel, option, optionIndex) {
  const {
    icon = null,
    label,
    role,
    onClick,
    confirmCheck
  } = Array.isArray(option) ? {
    icon: option[0],
    label: option[1],
    role: option[2],
    onClick: option[2]
  } : option;
  return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(ModalOption, {
    icon: icon,
    onClick: callback
  }, label);

  function callback(event) {
    if (role == 'ok') {
      if (typeof confirmCheck == 'function' && confirmCheck() != true) {
        return;
      }

      onConfirm();
    } else if (role == 'cancel') {
      onCancel();
    }

    if (typeof onClick == 'function') {
      onClick(event, optionIndex);
    }
  }
}
/**
 * @param {Array<string> | string} messages 
 * @returns {{nextBar: Function} & InteractiveModal}
 */


function createLoadingModal(messages) {
  if (Array.isArray(messages) == false) {
    messages = [messages];
  }

  const bars = messages.map(m => (0,_common_ProgressBar__WEBPACK_IMPORTED_MODULE_1__["default"])(400, m, onFinish));
  let finished = 0;
  let current = 0;
  const modal = createModal(bars, null, false, 'wait');
  modal.nextBar = nextBar;
  return modal;

  function nextBar() {
    if (current < bars.length) {
      return bars[current++].onProgress;
    } else {
      return null;
    }
  }

  function onFinish() {
    finished++;

    if (finished == bars.length) {
      modal.close();
    }
  }
}
/**
 * @typedef {Object} OptionDescriptor
 * @property {HTMLElement} [icon=null]
 * @property {string} label
 * @property {"ok" | "cancel"} [role=]
 * @property {Function} [onClick=]
 */

/**
 * @typedef {[HTMLElement | null, string, "ok" | "cancel" | undefined | Function]} OptionEntry
 */

/**
 * @typedef {Object} InteractiveModal
 * @property {Function} close
 * @property {(event: Event, optionIndex: number) => {}} [onClose=null]
 */

/***/ }),

/***/ "./src/common/ProgressBar.js":
/*!***********************************!*\
  !*** ./src/common/ProgressBar.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ProgressBar)
/* harmony export */ });
/* harmony import */ var _util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/jsx-render-mod/dom */ "./src/util/jsx-render-mod/dom.js");

/**
 * @param {number} width 
 * @param {string} label 
 * @returns {ProgressBarElement}
 */

function ProgressBar(width, label, onFinish) {
  const percent = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", null, "0%");
  /** @type {ProgressBarElement} */

  const bar = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
    style: {
      padding: '0 0.5em',
      display: 'inline-block',
      width: width + 'px',
      background: 'linear-gradient(to right, #ffa000 0%, #eee 0)'
    }
  }, percent, label ? ` ${label}` : null);
  bar.onProgress = onProgress;
  return bar;

  function onProgress(completed, total) {
    const progress = total == 0 ? 100 : Math.floor(completed / total * 100);
    percent.textContent = progress + '%';
    bar.style.background = `linear-gradient(to right, #ffa000 ${progress}%, #eee 0)`;

    if ((total == 0 || completed == total) && typeof onFinish == 'function') {
      onFinish();
    }
  }
}
/**
 * @typedef {ProgressBarSpan & HTMLSpanElement} ProgressBarElement
 * @property {Function} onProgress
 */

/**
 * @typedef {Object} ProgressBarSpan
 * @property {Function} onProgress
 */

/***/ }),

/***/ "./src/course/general/Description.js":
/*!*******************************************!*\
  !*** ./src/course/general/Description.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "createAssignDialog": () => (/* binding */ createAssignDialog),
/* harmony export */   "default": () => (/* binding */ Description)
/* harmony export */ });
/* harmony import */ var _common_Modal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../common/Modal */ "./src/common/Modal.js");
/* harmony import */ var _templates_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../templates/data */ "./src/templates/data.js");
/* harmony import */ var _templates_Preview__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../templates/Preview */ "./src/templates/Preview.js");
/* harmony import */ var _util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../util/jsx-render-mod/dom */ "./src/util/jsx-render-mod/dom.js");
/* harmony import */ var _util_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../util/router */ "./src/util/router.js");
/* harmony import */ var _util_template__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../util/template */ "./src/util/template.js");
/* harmony import */ var _strings__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../strings */ "./src/course/strings.js");







function Description({
  template,
  instanceData,
  allTemplates,
  api,
  categories,
  context
}) {
  let element = template ? (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])(HasTemplate, null) : (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])(NoTemplate, null);
  return element;

  function HasTemplate() {
    return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("div", null, _strings__WEBPACK_IMPORTED_MODULE_6__.TEMPLATE_READY, " ", (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_5__.Yes, null), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("button", {
      onClick: () => (0,_util_router__WEBPACK_IMPORTED_MODULE_4__.redirect)(`?courseId=${instanceData.info.CourseId}&instanceId=${instanceData.info.Id}&tab=description`)
    }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("i", {
      class: "glyphicon glyphicon-pencil"
    }), " ", _strings__WEBPACK_IMPORTED_MODULE_6__.EDIT_BUTTON), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("button", {
      onClick: onDelete
    }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("i", {
      class: "glyphicon glyphicon-trash"
    }), " ", _strings__WEBPACK_IMPORTED_MODULE_6__.DELETE_BUTTON));
  }

  function NoTemplate() {
    return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("div", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("span", {
      style: {
        fontStyle: 'italic'
      }
    }, _strings__WEBPACK_IMPORTED_MODULE_6__.NO_TEMPLATE), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("button", {
      onClick: () => createAssignDialog(categories, allTemplates, onSelect)
    }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("i", {
      class: "glyphicon glyphicon-link"
    }), " ", _strings__WEBPACK_IMPORTED_MODULE_6__.ASSIGN_BUTTON));
  }

  async function onSelect(selectedTemplate) {
    const assigned = (0,_templates_data__WEBPACK_IMPORTED_MODULE_1__.createTemplateModel)();
    assigned.Name = instanceData.info.NameBg;
    assigned.Content = selectedTemplate.Content;
    assigned.InstanceId = instanceData.info.Id;
    element = (0,_util_template__WEBPACK_IMPORTED_MODULE_5__.replaceContents)(element, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_5__.Loading, {
      color: "black"
    }));

    try {
      context.emit('TemplateSelected', assigned);
    } catch (err) {
      element = (0,_util_template__WEBPACK_IMPORTED_MODULE_5__.replaceContents)(element, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("div", null, _strings__WEBPACK_IMPORTED_MODULE_6__.ERROR_OCCURED));
      console.error(err);
    }
  }

  async function onDelete() {
    const choice = confirm((0,_strings__WEBPACK_IMPORTED_MODULE_6__.DELETE_TEMPLATE_CONFIRM)(template.Name));

    if (choice) {
      element = (0,_util_template__WEBPACK_IMPORTED_MODULE_5__.replaceContents)(element, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_5__.Loading, {
        color: "black"
      }));

      try {
        await (0,_templates_data__WEBPACK_IMPORTED_MODULE_1__.deleteTemplate)(api, template);
        allTemplates.splice(allTemplates.indexOf(template), 1);
        element = (0,_util_template__WEBPACK_IMPORTED_MODULE_5__.replaceContents)(element, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])(NoTemplate, null));
      } catch (err) {
        element = (0,_util_template__WEBPACK_IMPORTED_MODULE_5__.replaceContents)(element, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("div", null, _strings__WEBPACK_IMPORTED_MODULE_6__.ERROR_OCCURED));
        console.error(err);
      }
    }
  }
}
function createAssignDialog(categories, templates, onSelect, fragmentMode) {
  const templateList = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])(_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__.Fragment, null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("div", {
    className: "ses-scroll"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("table", {
    className: "ses-template-table",
    style: {
      width: '100%',
      borderCollapse: 'collapse'
    }
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("thead", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("tr", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("th", null, "\u0418\u043C\u0435"), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("th", null, "\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438"), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("th", null, "\u041A\u043E\u043D\u0442\u0440\u043E\u043B"))), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("tbody", null, templates.filter(t => !t.InstanceId && (fragmentMode ? t.Compound != true : t.Compound)).map(TemplateRow.bind(null, categories, templates, t => {
    dialog.close();
    onSelect(t);
  }))))), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("table", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("tbody", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("tr", {
    className: "ses-modal-active",
    onClick: () => dialog.close()
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("td", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_5__.No, null)), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("td", null, "\u041E\u0431\u0440\u0430\u0442\u043D\u043E \u0432 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0430")))));
  const dialog = (0,_common_Modal__WEBPACK_IMPORTED_MODULE_0__.createModal)('Select template', templateList);
}

function TemplateRow(categories, allTemplates, onSelect, template) {
  const usesFragments = /\[\[Ref=.+?\]\]/.test(template.Content);
  const isDynamic = usesFragments == false && /\[\[.+?\]\]/.test(template.Content);
  let active = false;
  const element = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("tr", {
    className: "ses-template-row",
    onClick: toggle
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("td", null, template.Name), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("td", null, template.Category.map(c => (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("span", {
    className: "ses-template-category"
  }, categories[c])), usesFragments ? (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("span", {
    className: "ses-template-category-auto"
  }, "\u0421\u044A\u0434\u044A\u0440\u0436\u0430 \u0444\u0440\u0430\u0433\u043C\u0435\u043D\u0442\u0438") : '', isDynamic ? (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("span", {
    className: "ses-template-category-auto"
  }, "\u0414\u0438\u043D\u0430\u043C\u0438\u0447\u0435\u043D") : ''), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("td", {
    className: "ses-center"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("button", {
    onClick: () => onSelect(template)
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("i", {
    class: "glyphicon glyphicon-link"
  }), " \u0418\u0437\u0431\u0435\u0440\u0438")));
  let preview = null;
  return element;

  function toggle(e) {
    if (e && (e.target.tagName == 'I' || e.target.tagName == 'BUTTON')) {
      return;
    }

    if (active) {
      active = false;
      preview.remove();
    } else {
      active = true;

      if (preview == null) {
        preview = generatePreview(allTemplates, template, toggle);
      }

      element.after(preview);
    }
  }
}

function generatePreview(allTemplates, template, toggle) {
  return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("tr", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("td", {
    colSpan: "3"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])(_templates_Preview__WEBPACK_IMPORTED_MODULE_2__["default"], {
    content: template.Content,
    templates: allTemplates
  }), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("div", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_3__["default"])("button", {
    style: {
      float: 'right'
    },
    onClick: () => toggle()
  }, "\u0417\u0430\u0442\u0432\u043E\u0440\u0438"))));
}

/***/ }),

/***/ "./src/course/strings.js":
/*!*******************************!*\
  !*** ./src/course/strings.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ADD_EVENT_BUTTON": () => (/* binding */ ADD_EVENT_BUTTON),
/* harmony export */   "ADD_EXAM_GROUP_BUTTON": () => (/* binding */ ADD_EXAM_GROUP_BUTTON),
/* harmony export */   "ADD_EXAM_REGULAR_BUTTON": () => (/* binding */ ADD_EXAM_REGULAR_BUTTON),
/* harmony export */   "ADD_EXAM_RETAKE_BUTTON": () => (/* binding */ ADD_EXAM_RETAKE_BUTTON),
/* harmony export */   "ADD_LECTURE_BUTTON": () => (/* binding */ ADD_LECTURE_BUTTON),
/* harmony export */   "ADD_SKILL_BUTTON": () => (/* binding */ ADD_SKILL_BUTTON),
/* harmony export */   "ADD_TRAINER_BUTTON": () => (/* binding */ ADD_TRAINER_BUTTON),
/* harmony export */   "ALLOW_MULTIPLE_EVENTS_LABEL": () => (/* binding */ ALLOW_MULTIPLE_EVENTS_LABEL),
/* harmony export */   "ALL_FILTER_HEADING": () => (/* binding */ ALL_FILTER_HEADING),
/* harmony export */   "ASSESSMENT_TAB_LINK": () => (/* binding */ ASSESSMENT_TAB_LINK),
/* harmony export */   "ASSIGN_BUTTON": () => (/* binding */ ASSIGN_BUTTON),
/* harmony export */   "AS_PROFILE_LABEL": () => (/* binding */ AS_PROFILE_LABEL),
/* harmony export */   "AUTOMATICALLY_SELECT_TRAINER_LABEL": () => (/* binding */ AUTOMATICALLY_SELECT_TRAINER_LABEL),
/* harmony export */   "BULK_EDIT_HEADING": () => (/* binding */ BULK_EDIT_HEADING),
/* harmony export */   "CACHE_DISCLAIMER": () => (/* binding */ CACHE_DISCLAIMER),
/* harmony export */   "CANCEL_BUTTON": () => (/* binding */ CANCEL_BUTTON),
/* harmony export */   "CERTIFICATE_HEADING": () => (/* binding */ CERTIFICATE_HEADING),
/* harmony export */   "CONTENT_HEADING": () => (/* binding */ CONTENT_HEADING),
/* harmony export */   "CONTROLS_HEADING": () => (/* binding */ CONTROLS_HEADING),
/* harmony export */   "COURSE_DASHBOARD_TITLE": () => (/* binding */ COURSE_DASHBOARD_TITLE),
/* harmony export */   "CREATE_FROM_EDIT_SKILL_CONFIRM": () => (/* binding */ CREATE_FROM_EDIT_SKILL_CONFIRM),
/* harmony export */   "DATE_HEADING": () => (/* binding */ DATE_HEADING),
/* harmony export */   "DELETE_BUTTON": () => (/* binding */ DELETE_BUTTON),
/* harmony export */   "DELETE_LECTURE_CONFIRM": () => (/* binding */ DELETE_LECTURE_CONFIRM),
/* harmony export */   "DELETE_SKILL_CONFIRM": () => (/* binding */ DELETE_SKILL_CONFIRM),
/* harmony export */   "DELETE_TEMPLATE_CONFIRM": () => (/* binding */ DELETE_TEMPLATE_CONFIRM),
/* harmony export */   "DELETE_TRAINER_CONFIRM": () => (/* binding */ DELETE_TRAINER_CONFIRM),
/* harmony export */   "DESCRIPTION_HEADING": () => (/* binding */ DESCRIPTION_HEADING),
/* harmony export */   "EDIT_BUTTON": () => (/* binding */ EDIT_BUTTON),
/* harmony export */   "EDIT_SKILL_CONFIRM": () => (/* binding */ EDIT_SKILL_CONFIRM),
/* harmony export */   "END_HEADING": () => (/* binding */ END_HEADING),
/* harmony export */   "ERROR_DEFAULT_MESSAGE": () => (/* binding */ ERROR_DEFAULT_MESSAGE),
/* harmony export */   "ERROR_OCCURED": () => (/* binding */ ERROR_OCCURED),
/* harmony export */   "EVENTS_TAB_LINK": () => (/* binding */ EVENTS_TAB_LINK),
/* harmony export */   "EXAMS_TAB_LINK": () => (/* binding */ EXAMS_TAB_LINK),
/* harmony export */   "EXAM_ALLOW_ALL_LABEL": () => (/* binding */ EXAM_ALLOW_ALL_LABEL),
/* harmony export */   "EXAM_DEADLINE_LABEL": () => (/* binding */ EXAM_DEADLINE_LABEL),
/* harmony export */   "EXAM_DESKTOPS_LABEL": () => (/* binding */ EXAM_DESKTOPS_LABEL),
/* harmony export */   "EXAM_MISSING_DEADLINE_LABEL": () => (/* binding */ EXAM_MISSING_DEADLINE_LABEL),
/* harmony export */   "EXAM_NAME_TEMPLATE": () => (/* binding */ EXAM_NAME_TEMPLATE),
/* harmony export */   "EXAM_TYPES": () => (/* binding */ EXAM_TYPES),
/* harmony export */   "EXAM_TYPE_LABEL": () => (/* binding */ EXAM_TYPE_LABEL),
/* harmony export */   "EXPORT_USERS_BUTTON": () => (/* binding */ EXPORT_USERS_BUTTON),
/* harmony export */   "FILTER_USERS_BUTTON": () => (/* binding */ FILTER_USERS_BUTTON),
/* harmony export */   "FILTER_USERS_TEXT": () => (/* binding */ FILTER_USERS_TEXT),
/* harmony export */   "GENERAL_TAB_LINK": () => (/* binding */ GENERAL_TAB_LINK),
/* harmony export */   "GRADE_HEADING": () => (/* binding */ GRADE_HEADING),
/* harmony export */   "GROUP_HEADING": () => (/* binding */ GROUP_HEADING),
/* harmony export */   "GROUP_SEATS_HEADING": () => (/* binding */ GROUP_SEATS_HEADING),
/* harmony export */   "HALL_HEADING": () => (/* binding */ HALL_HEADING),
/* harmony export */   "HISTORY_HEADING": () => (/* binding */ HISTORY_HEADING),
/* harmony export */   "HOMEWORK_HEADING": () => (/* binding */ HOMEWORK_HEADING),
/* harmony export */   "INCLUDE_ALL_HALLS_LABEL": () => (/* binding */ INCLUDE_ALL_HALLS_LABEL),
/* harmony export */   "INSTANCE_PAGE_LINK": () => (/* binding */ INSTANCE_PAGE_LINK),
/* harmony export */   "LECTURES_TAB_LINK": () => (/* binding */ LECTURES_TAB_LINK),
/* harmony export */   "LECTURE_TYPES": () => (/* binding */ LECTURE_TYPES),
/* harmony export */   "LINK_EXAM_BUTTON": () => (/* binding */ LINK_EXAM_BUTTON),
/* harmony export */   "LINK_SKILL_BUTTON": () => (/* binding */ LINK_SKILL_BUTTON),
/* harmony export */   "LIST_HEADING": () => (/* binding */ LIST_HEADING),
/* harmony export */   "LIVESTREAM_MISCONFIG_LABEL": () => (/* binding */ LIVESTREAM_MISCONFIG_LABEL),
/* harmony export */   "LIVE_HEADING": () => (/* binding */ LIVE_HEADING),
/* harmony export */   "LOADING_COURSE_DETAILS": () => (/* binding */ LOADING_COURSE_DETAILS),
/* harmony export */   "LOCALIZED_NAMES_LABEL": () => (/* binding */ LOCALIZED_NAMES_LABEL),
/* harmony export */   "LOG_DATA_LINK": () => (/* binding */ LOG_DATA_LINK),
/* harmony export */   "MISSING_GROUP_LABEL": () => (/* binding */ MISSING_GROUP_LABEL),
/* harmony export */   "MISSING_ROLE": () => (/* binding */ MISSING_ROLE),
/* harmony export */   "MULTIPLE_EVENTS_LABEL": () => (/* binding */ MULTIPLE_EVENTS_LABEL),
/* harmony export */   "NAME_FILTER_PLACEHOLDER": () => (/* binding */ NAME_FILTER_PLACEHOLDER),
/* harmony export */   "NAME_HEADING": () => (/* binding */ NAME_HEADING),
/* harmony export */   "NO_LABEL": () => (/* binding */ NO_LABEL),
/* harmony export */   "NO_TEMPLATE": () => (/* binding */ NO_TEMPLATE),
/* harmony export */   "ORDER_HEADING": () => (/* binding */ ORDER_HEADING),
/* harmony export */   "PARTICIPATION_TYPES": () => (/* binding */ PARTICIPATION_TYPES),
/* harmony export */   "PARTICIPATION_TYPES_CPE": () => (/* binding */ PARTICIPATION_TYPES_CPE),
/* harmony export */   "PARTICIPATION_TYPE_HEADING": () => (/* binding */ PARTICIPATION_TYPE_HEADING),
/* harmony export */   "PROFILE_BUTTON": () => (/* binding */ PROFILE_BUTTON),
/* harmony export */   "PUBLIC_NAME_HEADING": () => (/* binding */ PUBLIC_NAME_HEADING),
/* harmony export */   "PUBLIC_PHOTO_HEADING": () => (/* binding */ PUBLIC_PHOTO_HEADING),
/* harmony export */   "REGULAR_EXAMS_HEADING": () => (/* binding */ REGULAR_EXAMS_HEADING),
/* harmony export */   "RELATED_HEADING": () => (/* binding */ RELATED_HEADING),
/* harmony export */   "RELATED_INSTANCES_LABEL": () => (/* binding */ RELATED_INSTANCES_LABEL),
/* harmony export */   "RETAKE_EXAMS_HEADING": () => (/* binding */ RETAKE_EXAMS_HEADING),
/* harmony export */   "SAVE_BUTTON": () => (/* binding */ SAVE_BUTTON),
/* harmony export */   "SEARCH_BUTTON": () => (/* binding */ SEARCH_BUTTON),
/* harmony export */   "SHOW_DESCRIPTION_LABEL": () => (/* binding */ SHOW_DESCRIPTION_LABEL),
/* harmony export */   "SHOW_TRAINER_PER_LECTURE_LABEL": () => (/* binding */ SHOW_TRAINER_PER_LECTURE_LABEL),
/* harmony export */   "SKILLS_HEADING": () => (/* binding */ SKILLS_HEADING),
/* harmony export */   "START_HEADING": () => (/* binding */ START_HEADING),
/* harmony export */   "STATS_AVG_GRADE_LABEL": () => (/* binding */ STATS_AVG_GRADE_LABEL),
/* harmony export */   "STATS_CERTIFIED_LABEL": () => (/* binding */ STATS_CERTIFIED_LABEL),
/* harmony export */   "STATS_FAILED_LABEL": () => (/* binding */ STATS_FAILED_LABEL),
/* harmony export */   "STATS_HEADING": () => (/* binding */ STATS_HEADING),
/* harmony export */   "STATS_MISSING_LABEL": () => (/* binding */ STATS_MISSING_LABEL),
/* harmony export */   "STATS_USERS_LABEL": () => (/* binding */ STATS_USERS_LABEL),
/* harmony export */   "SULS_ADMIN_LINK": () => (/* binding */ SULS_ADMIN_LINK),
/* harmony export */   "TEMPLATE_EDITOR_LINK": () => (/* binding */ TEMPLATE_EDITOR_LINK),
/* harmony export */   "TEMPLATE_READY": () => (/* binding */ TEMPLATE_READY),
/* harmony export */   "TRAINERS_HEADING": () => (/* binding */ TRAINERS_HEADING),
/* harmony export */   "TRAINER_HEADING": () => (/* binding */ TRAINER_HEADING),
/* harmony export */   "TRAINER_NOT_ASSIGNED_LABEL": () => (/* binding */ TRAINER_NOT_ASSIGNED_LABEL),
/* harmony export */   "TYPE_FILTER_TEXT": () => (/* binding */ TYPE_FILTER_TEXT),
/* harmony export */   "UNLINK_BUTTON": () => (/* binding */ UNLINK_BUTTON),
/* harmony export */   "UNLINK_SKILL_CONFIRM": () => (/* binding */ UNLINK_SKILL_CONFIRM),
/* harmony export */   "USERNAME_FILTER_PLACEHOLDER": () => (/* binding */ USERNAME_FILTER_PLACEHOLDER),
/* harmony export */   "USERNAME_HEADING": () => (/* binding */ USERNAME_HEADING),
/* harmony export */   "USERS_TAB_LINK": () => (/* binding */ USERS_TAB_LINK),
/* harmony export */   "VIEW_ENROLLED_BUTTON": () => (/* binding */ VIEW_ENROLLED_BUTTON),
/* harmony export */   "VIEW_LINK": () => (/* binding */ VIEW_LINK),
/* harmony export */   "YES_LABEL": () => (/* binding */ YES_LABEL),
/* harmony export */   "typeLabels": () => (/* binding */ typeLabels)
/* harmony export */ });
// Main page
const COURSE_DASHBOARD_TITLE = 'Дашборд';
const LOADING_COURSE_DETAILS = 'Зареждане на курсовата информация&hellip;';
const LOCALIZED_NAMES_LABEL = 'Локализация на имена и описания BG/EN';
const SHOW_DESCRIPTION_LABEL = 'Покажи целите описания';
const ALLOW_MULTIPLE_EVENTS_LABEL = 'Позволи няколко събитя за една лекция';
const INCLUDE_ALL_HALLS_LABEL = 'Включи всички активни зали';
const SHOW_TRAINER_PER_LECTURE_LABEL = 'Покажи трейнър за всяка лекция';
const AUTOMATICALLY_SELECT_TRAINER_LABEL = 'Автоматично избиране при единствен лектор';
const INSTANCE_PAGE_LINK = 'Страница на инстанцията';
const SULS_ADMIN_LINK = 'SULS Администрация';
const LOG_DATA_LINK = 'Дебъг информация';
const TEMPLATE_EDITOR_LINK = 'Редактор на шаблони';
const CACHE_DISCLAIMER = 'Някои промени може да зависят от сървърния кеш, за да станат публично видими.';
const GENERAL_TAB_LINK = 'Информация';
const LECTURES_TAB_LINK = 'Лекции';
const EVENTS_TAB_LINK = 'Събития';
const EXAMS_TAB_LINK = 'Изпити';
const USERS_TAB_LINK = 'Потребители';
const ASSESSMENT_TAB_LINK = 'Оценяване'; // General tab

const SKILLS_HEADING = 'Умения';
const PUBLIC_NAME_HEADING = 'Публично име';
const PUBLIC_PHOTO_HEADING = 'Снимка';
const AS_PROFILE_LABEL = 'като в профила';
const DESCRIPTION_HEADING = 'Описание';
const TRAINERS_HEADING = 'Публични трейнъри';
const ORDER_HEADING = 'Подредба';
const CONTENT_HEADING = 'Съдържание';
const RELATED_HEADING = 'Свързани';
const CONTROLS_HEADING = 'Контрол';
const ADD_SKILL_BUTTON = 'Добави ново умение';
const LINK_SKILL_BUTTON = 'Съществуващо умение';
const NAME_HEADING = 'Име';
const USERNAME_HEADING = 'Потребителско име';
const HISTORY_HEADING = 'История';
const ADD_TRAINER_BUTTON = 'Добави трейнър';
const UNLINK_SKILL_CONFIRM = label => `Потвърдете разкачването на ${label}?\n\n(останалите свързани обучения НЯМА да бъдат засегнати)`;
const DELETE_SKILL_CONFIRM = label => `Потвърдете изтриването на ${label}?`;
const EDIT_SKILL_CONFIRM = skills => `Това умение се използва в следните обучения:\n\n${skills}\n\nСигурни ли сте, че искате да редактирате ВСИЧКИ ОБУЧЕНИЯ?`;
const CREATE_FROM_EDIT_SKILL_CONFIRM = (oldLabel, newLabel, existingTrainingsCount) => `Това ще ${existingTrainingsCount > 1 ? 'разкачи' : 'изтрие'} "${oldLabel}" и ще създаде и закачи "${newLabel}", всички останали обучения които използват "${oldLabel}" ще останат непроменени. Моля потвърдете?`;
const VIEW_LINK = 'Прегледай';
const TEMPLATE_READY = 'Шаблона е на разположение';
const EDIT_BUTTON = 'Редактирай';
const DELETE_BUTTON = 'Изтрий';
const NO_TEMPLATE = 'Не е настроен шаблон';
const ASSIGN_BUTTON = 'Приложи';
const ERROR_OCCURED = 'Възникна грешка, вижте в конзолата за детайли.';
const DELETE_TEMPLATE_CONFIRM = name => `Сигурни ли сте, че искате да изтриете шаблона "${name}"?\n(описанието на инстанцията няма да бъде засегнато)`;
const DELETE_TRAINER_CONFIRM = (firstName, lastName) => `Потвърдете премахването на трейнър ${firstName} ${lastName}?`;
const MISSING_ROLE = 'Избрания потребител няма роля "Лектор". Добавете я през администрацията и опитайте отново.';
const LIVE_HEADING = 'На живо';
const CERTIFICATE_HEADING = 'Сертификат';
const HOMEWORK_HEADING = 'Домашно';
const ADD_LECTURE_BUTTON = 'Добави лекция';
const DELETE_LECTURE_CONFIRM = label => `Потвърдете изтриването на ${label}?`;
const TRAINER_NOT_ASSIGNED_LABEL = 'Не е зададен трейнър';
const TRAINER_HEADING = 'Лектор';
const BULK_EDIT_HEADING = 'Групово редактиране';
const ADD_EVENT_BUTTON = 'Добави събитие';
const MULTIPLE_EVENTS_LABEL = ['Открити са няколко събития, ', 'кликнете за позволите редакция'];
const GROUP_HEADING = 'Група';
const DATE_HEADING = 'Дата';
const START_HEADING = 'Начало';
const END_HEADING = 'Край';
const HALL_HEADING = 'Зала'; // Exams Tab

const REGULAR_EXAMS_HEADING = 'Редовни изпити';
const RETAKE_EXAMS_HEADING = 'Поправителни изпити';
const MISSING_GROUP_LABEL = 'Няма конфигурирани групи за изпита';
const ADD_EXAM_REGULAR_BUTTON = 'Създай редовен изпит';
const ADD_EXAM_RETAKE_BUTTON = 'Създай поправителен изпит';
const LINK_EXAM_BUTTON = 'Свържи съществуващ изпит';
const ADD_EXAM_GROUP_BUTTON = 'Добави група';
const VIEW_ENROLLED_BUTTON = 'Списък';
const GROUP_SEATS_HEADING = 'Места';
const EXAM_TYPE_LABEL = 'Тип на изпита';
const EXAM_DESKTOPS_LABEL = 'Настолни компютри';
const EXAM_ALLOW_ALL_LABEL = 'За всички в обучението';
const EXAM_DEADLINE_LABEL = 'Срок за записване';
const RELATED_INSTANCES_LABEL = 'Свързани обучения';
const YES_LABEL = 'Да';
const NO_LABEL = 'Не';
const EXAM_MISSING_DEADLINE_LABEL = 'Не е настроен';
const EXAM_TYPES = {
  '0': 'N/A',
  '1': 'Практически изпит',
  '2': 'Проект',
  '3': 'Тестови изпит',
  '4': 'Автоматизирана система',
  '5': 'Устен изпит'
};
const LECTURE_TYPES = {
  '0': 'N/A',
  '1': 'Редовен изпит',
  '2': 'Поправителен изпит'
};
const ERROR_DEFAULT_MESSAGE = 'Грешка при изпълнение, вижте в конзолата за подробности';
const SAVE_BUTTON = 'Запази';
const CANCEL_BUTTON = 'Отказ';
const UNLINK_BUTTON = 'Разкачи изпита';
const SEARCH_BUTTON = 'Търси';
const EXAM_NAME_TEMPLATE = (instanceName, date, type) => {
  const typeString = type == 'regular' ? 'редовен изпит' : 'поправителен/повишителен изпит';
  return `Exam: ${instanceName} - ${typeString} - ${date}`;
}; // Users Tab

const PARTICIPATION_TYPE_HEADING = 'Форма';
const GRADE_HEADING = 'Оценка';
const PARTICIPATION_TYPES = {
  '0': 'Наблюдател',
  '1': 'Онлайн',
  '2': 'Присъствено',
  '3': 'Присъствено с гарантирано място',
  '4': 'Присъствено с негарантирано място',
  '5': 'Изчакващ',
  '6': 'Лектор',
  '7': 'Повишителен изпит',
  '8': 'Повишителен изпит - НЕ ЦПО'
};
const PARTICIPATION_TYPES_CPE = {
  '0': 'Онлайн',
  '1': 'Онлайн',
  '2': 'Присъствено',
  '3': 'Присъствено',
  '4': 'Присъствено',
  '5': 'Онлайн',
  '6': 'Лектор',
  '7': 'Повишителен изпит',
  '8': 'Повишителен изпит - НЕ ЦПО'
};
const ALL_FILTER_HEADING = 'Всички';
const PROFILE_BUTTON = 'Виж профил';
const USERNAME_FILTER_PLACEHOLDER = 'Филтрирай по потребителско име';
const NAME_FILTER_PLACEHOLDER = 'Филтрирай по имена';
const TYPE_FILTER_TEXT = 'Задръж SHIFT за комбинация';
const STATS_USERS_LABEL = 'Редовни студенти (онлайн и присъствено):';
const STATS_AVG_GRADE_LABEL = 'Среден успех:';
const STATS_CERTIFIED_LABEL = 'Сертифицирани:';
const STATS_FAILED_LABEL = 'Скъсани:';
const STATS_MISSING_LABEL = 'Редовни студенти без оценка:';
const STATS_HEADING = 'Статистика';
const LIST_HEADING = 'Списък';
const LIVESTREAM_MISCONFIG_LABEL = 'Разминаване в конфигурацията на календар и лайвстрийм';
const EXPORT_USERS_BUTTON = 'Свали списъка';
const FILTER_USERS_BUTTON = 'Филтрирай по списък';
const FILTER_USERS_TEXT = 'Изберете XLSX файл, съдържащ списък с потребителски имена';
const typeLabels = {
  '1': 'online',
  '2': 'site',
  '3': 'site',
  '4': 'site',
  '6': 'team'
};

/***/ }),

/***/ "./src/templates/Editor.js":
/*!*********************************!*\
  !*** ./src/templates/Editor.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Editor)
/* harmony export */ });
/* harmony import */ var _util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/jsx-render-mod/dom */ "./src/util/jsx-render-mod/dom.js");
/* harmony import */ var _common_Modal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../common/Modal */ "./src/common/Modal.js");
/* harmony import */ var _util_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../util/router */ "./src/util/router.js");
/* harmony import */ var _util_template__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../util/template */ "./src/util/template.js");
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./data */ "./src/templates/data.js");
/* harmony import */ var _Preview__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Preview */ "./src/templates/Preview.js");
/* harmony import */ var _util_util__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../util/util */ "./src/util/util.js");
/* harmony import */ var _util_parse__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../util/parse */ "./src/util/parse.js");
/* harmony import */ var _course_general_Description__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../course/general/Description */ "./src/course/general/Description.js");









function Editor({
  title,
  config,
  templates,
  id,
  api,
  inTemplate,
  instanceData,
  context
}) {
  const template = inTemplate || (id ? templates.find(t => t.Id == id) : (0,_data__WEBPACK_IMPORTED_MODULE_4__.createTemplateModel)());
  const input = {
    name: (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("input", {
      type: "text",
      className: "ses-wide-input",
      value: template.Name
    }),
    compound: (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("input", {
      className: "ses-check",
      type: "checkbox"
    }),
    active: (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("input", {
      className: "ses-check",
      type: "checkbox"
    }),
    categories: Object.entries(config.categories).map(([k, v]) => [k, [v, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("input", {
      className: "ses-check",
      type: "checkbox",
      value: k
    })]]),
    content: (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("textarea", null, template.Content)
  };
  let preview = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_Preview__WEBPACK_IMPORTED_MODULE_5__["default"], {
    content: template.Content,
    templates: templates,
    instanceData: instanceData
  });
  input.compound.checked = template.Compound;
  input.active.checked = template.Active;
  input.categories.forEach(([k, [label, field]]) => field.checked = template.Category.includes(k));
  const editor = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "ses-table-editor"
  }, createControls(), inTemplate == undefined && (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "ses-clear"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "ses-template-group"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("h3", null, "\u041E\u0431\u0449\u0430 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F"), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("label", {
    className: "ses-template-label"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
    className: "ses-label"
  }, "\u0418\u043C\u0435"), input.name), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("label", {
    className: "ses-template-label"
  }, input.compound, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", null, "\u0426\u044F\u043B\u043E\u0441\u0442\u0435\u043D \u0448\u0430\u0431\u043B\u043E\u043D")), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("label", {
    className: "ses-template-label"
  }, input.active, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", null, "\u0410\u043A\u0442\u0443\u0430\u043B\u0435\u043D"))), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "ses-template-group"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("h3", null, "\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044F"), input.categories.map(([k, [label, field]]) => (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("label", {
    className: "ses-template-label"
  }, field, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", null, label))))), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(ContentEditor, {
    contentField: input.content,
    regeneratePreview: regeneratePreview,
    templates: templates,
    categories: config.categories
  }), createControls());
  const decoration = (0,_util_template__WEBPACK_IMPORTED_MODULE_3__.getEditorDecoration)(editor);
  return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("h2", null, title || 'Създаване на нов шаблон'), editor, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "ses-clear"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("h3", null, "\u041F\u0440\u0435\u0433\u043B\u0435\u0434"), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("p", {
    style: {
      fontStyle: 'italic'
    }
  }, "\u0417\u0430\u0431\u0435\u043B\u0435\u0436\u043A\u0430: \u0432\u044A\u0437\u043C\u043E\u0436\u043D\u043E \u0435 \u0434\u0430 \u0438\u043C\u0430 \u0441\u0442\u0438\u043B\u0438\u0441\u0442\u0438\u0447\u043D\u0438 \u0440\u0430\u0437\u043B\u0438\u043A\u0438 \u043C\u0435\u0436\u0434\u0443 \u0442\u043E\u0437\u0438 \u0438\u0437\u0433\u043B\u0435\u0434 \u0438 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0430\u0442\u0430 \u043D\u0430 \u043A\u0443\u0440\u0441\u0430."), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "ses-template-preview"
  }, preview)));

  function regeneratePreview() {
    preview = (0,_util_template__WEBPACK_IMPORTED_MODULE_3__.swap)(preview, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_Preview__WEBPACK_IMPORTED_MODULE_5__["default"], {
      content: input.content.value,
      templates: templates,
      instanceData: instanceData
    }));
  }

  function createControls() {
    return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
      className: "ses-clear"
    }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
      className: "ses-template-group ses-template-div"
    }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("button", {
      onClick: onSave
    }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_3__.Yes, null), " \u0417\u0430\u043F\u0430\u0437\u0438"), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("button", {
      onClick: goBack
    }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_3__.No, null), " \u041E\u0442\u043A\u0430\u0437")));
  }

  function goBack() {
    if (inTemplate) {
      const courseId = (0,_util_parse__WEBPACK_IMPORTED_MODULE_7__.queryString)(document.location.search).courseId;
      (0,_util_router__WEBPACK_IMPORTED_MODULE_2__.redirect)(`?courseId=${courseId}&instanceId=${template.InstanceId}&tab=general`);
    } else {
      (0,_util_router__WEBPACK_IMPORTED_MODULE_2__.redirect)('?');
    }
  }

  async function onSave() {
    const existingName = templates.filter(t => t.Name == input.name.value);

    if (existingName.length > 0 && existingName[0].Id != template.Id) {
      return alert('Вече съществува шаблон с това име');
    }

    const usedBy = templates.filter(t => t.Content.includes(`[[Ref=${template.Name}]]`));
    const nameChanged = template.Name != input.name.value;

    if (nameChanged && usedBy.length > 0) {
      const [choices, choicePromise] = createChoices(usedBy);
      const modal = (0,_common_Modal__WEBPACK_IMPORTED_MODULE_1__.createModal)('Опитвате се да промените името на шаблон, който се използва в следните други шаблони:', choices);
      const choice = await choicePromise;
      modal.close();

      if (choice == 'skip') {
        saveCurrent();
      } else if (choice == 'update') {
        saveAll();
      }
    } else {
      saveCurrent();
    }

    async function saveCurrent() {
      const data = {
        Id: template.Id,
        Name: input.name.value,
        Category: input.categories.filter(c => c[1][1].checked).map(c => c[0]),
        Active: input.active.checked,
        Compound: input.compound.checked,
        Content: input.content.value,
        InstanceId: template.InstanceId
      };
      const currentInputs = [...editor.querySelectorAll('input, button, textarea')].filter(n => n.disabled != true);
      currentInputs.forEach(n => n.disabled = true);
      decoration.working();

      try {
        const result = await (0,_data__WEBPACK_IMPORTED_MODULE_4__.saveTemplate)(api, data);
        decoration.updated();

        if (context) {
          context.on('DescriptionUpdated', goBack);
          context.emit('TemplateUpdated', (0,_Preview__WEBPACK_IMPORTED_MODULE_5__.interpret)(data.Content, templates, instanceData));
        } else {
          goBack();
        }
      } catch (err) {
        decoration.failure();
        alert(err.message);
        console.error(err);
      } finally {
        currentInputs.forEach(n => n.disabled = false);
      }
    }

    async function saveAll() {
      const [oldName, newName] = [template.Name, input.name.value];
      const matcher = new RegExp(`\\[\\[Ref=${oldName}\\]\\]`, 'g');
      usedBy.forEach(t => t.Content = t.Content.replace(matcher, `[[Ref=${newName}]]`));
      const width = 500;
      const percent = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", null, "0%");
      const bar = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
        style: {
          padding: '0 0.5em',
          display: 'inline-block',
          width: width + 'px',
          background: 'linear-gradient(to right, #ffa000 0%, #eee 0)'
        }
      }, percent, "\xA0Working\u2026");
      const progressModal = (0,_common_Modal__WEBPACK_IMPORTED_MODULE_1__.createModal)('Обновяване на шаблони, не затваряйте страницата', bar, false);
      await (0,_util_util__WEBPACK_IMPORTED_MODULE_6__.withProgress)(usedBy.map(t => (0,_data__WEBPACK_IMPORTED_MODULE_4__.saveTemplate)(api, t)), onChange, 100);
      progressModal.close();
      await saveCurrent();

      function onChange(res, index, resolved, total) {
        const progress = Math.floor(resolved / total * 100);
        percent.textContent = progress + '%';
        bar.style.background = `linear-gradient(to right, #ffa000 ${progress}%, #eee 0)`;
      }
    }
  }
}

function ContentEditor({
  contentField,
  regeneratePreview,
  templates,
  categories
}) {
  return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "ses-clear"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "ses-template-group ses-template-div"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("h3", null, "\u0421\u044A\u0434\u044A\u0440\u0436\u0430\u043D\u0438\u0435"), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("button", {
    onClick: () => (0,_course_general_Description__WEBPACK_IMPORTED_MODULE_8__.createAssignDialog)(categories, templates, insertFragment, true)
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("i", {
    class: "glyphicon glyphicon-link"
  }), " \u0412\u044A\u0432\u0435\u0434\u0438 \u0444\u0440\u0430\u0433\u043C\u0435\u043D\u0442"), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("h4", null, "\u0418\u0437\u0447\u0438\u0441\u043B\u0435\u043D\u0438 \u043F\u043E\u043B\u0435\u0442\u0430"), FieldGroups(_Preview__WEBPACK_IMPORTED_MODULE_5__.fieldMeta, insertField)), contentField, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("button", {
    onClick: regeneratePreview
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("i", {
    class: "glyphicon glyphicon-refresh"
  }), " \u041F\u0440\u0435\u0433\u043B\u0435\u0434\u0430\u0439"))));

  function insertFragment(template) {
    contentField.value = `${contentField.value.slice(0, contentField.selectionStart)}[[Ref=${template.Name}]]${contentField.value.slice(contentField.selectionEnd)}`;
  }

  function insertField(field) {
    contentField.value = `${contentField.value.slice(0, contentField.selectionStart)}[[${field}]]${contentField.value.slice(contentField.selectionEnd)}`;
  }
}

function FieldGroups(meta, insertField) {
  const groups = Object.entries(meta).reduce((p, [f, c]) => {
    const arr = p[c.group] || [];
    arr.push({
      match: f,
      name: c.name
    });
    return Object.assign(p, {
      [c.group]: arr
    });
  }, {});
  const elements = Object.entries(groups).map(([name, f]) => (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "ses-templates-fieldGroup"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", null, name), f.map(FieldButton.bind(null, insertField))));
  return elements;
}

function FieldButton(insertField, field) {
  return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("button", {
    onClick: () => insertField(field.match)
  }, field.name);
}

function createChoices(usedBy) {
  let outResolve = () => {};

  return [(0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "ses-scroll"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("table", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("thead", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tr", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("th", null, "\u0418\u043C\u0435"), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("th", null, "\u0426\u044F\u043B\u043E\u0441\u0442\u0435\u043D"), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("th", null, "\u0410\u043A\u0442\u0443\u0430\u043B\u0435\u043D"))), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tbody", null, usedBy.map(t => (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tr", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, t.Name), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, t.Compound ? (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_3__.Yes, null) : (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_3__.No, null)), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, t.Active ? (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_3__.Yes, null) : (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_3__.No, null))))))), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("table", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tbody", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tr", {
    className: "ses-modal-active",
    onClick: update
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_3__.Yes, null)), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, "\u041E\u0431\u043D\u043E\u0432\u0438 \u0437\u0430\u0441\u0435\u0433\u043D\u0430\u0442\u0438\u0442\u0435 \u0448\u0430\u0431\u043B\u043E\u043D\u0438 \u0441 \u043D\u043E\u0432\u043E\u0442\u043E \u0438\u043C\u0435")), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tr", {
    className: "ses-modal-active",
    onClick: skip
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("i", {
    class: "glyphicon glyphicon-warning-sign"
  })), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, "\u0417\u0430\u043F\u0430\u0437\u0438 \u043F\u0440\u043E\u043C\u0435\u043D\u0438\u0442\u0435 \u0431\u0435\u0437 \u0434\u0430 \u043E\u0431\u043D\u043E\u0432\u044F\u0432\u0430\u0448 \u0434\u0440\u0443\u0433\u0438\u0442\u0435 \u0448\u0430\u0431\u043B\u043E\u043D\u0438")), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tr", {
    className: "ses-modal-active",
    onClick: cancel
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_3__.No, null)), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, "\u0412\u044A\u0440\u043D\u0438 \u0441\u0435 \u0432 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0430"))))), new Promise(resolve => {
    outResolve = resolve;
  })];

  function skip() {
    outResolve('skip');
  }

  function update() {
    outResolve('update');
  }

  function cancel() {
    outResolve('cancel');
  }
}

/***/ }),

/***/ "./src/templates/Preview.js":
/*!**********************************!*\
  !*** ./src/templates/Preview.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Preview),
/* harmony export */   "fieldMeta": () => (/* binding */ fieldMeta),
/* harmony export */   "fields": () => (/* binding */ fields),
/* harmony export */   "interpret": () => (/* binding */ interpret)
/* harmony export */ });
/* harmony import */ var _util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/jsx-render-mod/dom */ "./src/util/jsx-render-mod/dom.js");
/* harmony import */ var _util_parse__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/parse */ "./src/util/parse.js");


function Preview({
  content,
  templates,
  instanceData
}) {
  const holder = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("section", {
    class: "instance-overview-section"
  });
  const parsingErrors = [];
  holder.innerHTML = interpret(content, templates, instanceData, parsingErrors);
  return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "page-wrapper",
    style: {
      minHeight: '0',
      backgroundColor: 'white'
    }
  }, parsingErrors.map(e => (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "ses-templates-parseError"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("i", {
    class: "glyphicon glyphicon-alert"
  }), " ", e)), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("section", {
    className: "instance",
    style: {
      marginBottom: '0'
    }
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("section", {
    className: "redesigned-instance-container"
  }, holder)));
}
function interpret(content, templates, instanceData, outErrors = []) {
  // References containing child text
  const childMatcher = /\[\[Ref=(.+?)\]\](.+?)\[\[\/Ref\]\]/gms;
  let childMatch;

  while ((childMatch = childMatcher.exec(content)) != null) {
    const refName = childMatch[1];
    const children = childMatch[2];
    const reference = templates.find(t => t.Name == refName);
    const interpolated = reference.Content.replace('[[Content]]', children);

    if (reference) {
      content = content.substring(0, childMatch.index) + interpret(interpolated, templates, instanceData) + content.substring(childMatch.index + childMatch[0].length);
    } else {
      outErrors.push(`Не беше открит фрагмент "${refName}"`);
    }
  } // Fragments


  const refMatcher = /\[\[Ref=(.+?)\]\]/g;
  let match;

  while ((match = refMatcher.exec(content)) != null) {
    const refName = match[1];
    const reference = templates.find(t => t.Name == refName);

    if (reference) {
      content = content.substring(0, match.index) + interpret(reference.Content, templates, instanceData) + content.substring(match.index + match[0].length);
    } else {
      outErrors.push(`Не беше открит фрагмент "${refName}"`);
    }
  } // Calculated fields


  if (instanceData) {
    const fieldMatcher = /\[\[(.+?)\]\]/g;
    let match;

    while ((match = fieldMatcher.exec(content)) != null) {
      const replacer = fields[match[1]];

      if (typeof replacer == 'function') {
        const value = replacer(instanceData);

        if (value) {
          content = content.substring(0, match.index) + value + content.substring(match.index + match[0].length);
        } else {
          outErrors.push(`Недостатъчна информация за попълване на поле "${match[1]}"`);
        }
      } else {
        outErrors.push(`Грешка при изпълнение на изчислено поле "${match[1]}"`);
      }
    }
  }

  return content;
}
const fieldMeta = {
  InstanceId: {
    name: 'ID на инстанцията',
    group: 'За курса'
  },
  SignupDeadline: {
    name: 'Срок за записване',
    group: 'За курса'
  },
  StartDate: {
    name: 'Начална дата',
    group: 'За курса'
  },
  EventsWeekday: {
    name: 'Седмичен ден на занятията',
    group: 'За всички занятия'
  },
  LectureWeekday: {
    name: 'Седмичен ден на лекциите',
    group: 'За лекциите'
  },
  ExerciseWeekday: {
    name: 'Седмичен ден на упражненията',
    group: 'За упражненията'
  },
  EventStartTime: {
    name: 'Начален час на занятията',
    group: 'За всички занятия'
  },
  LectureStartTime: {
    name: 'Начален час на лекциите',
    group: 'За лекциите'
  },
  ExerciseStartTime: {
    name: 'Начален час на упражненията',
    group: 'За упражненията'
  },
  EventEndTime: {
    name: 'Краен час на занятията',
    group: 'За всички занятия'
  },
  LectureEndTime: {
    name: 'Краен час на лекциите',
    group: 'За лекциите'
  },
  ExerciseEndTime: {
    name: 'Краен час на упражненията',
    group: 'За упражненията'
  },
  PriceOnline: {
    name: 'Цена - Онлайн',
    group: 'За курса'
  },
  FirstExamDate: {
    name: 'Първа изпитна дата',
    group: 'За курса'
  },
  RefundDeadline: {
    name: 'Срок за възстановяване на такса',
    group: 'За курса'
  }
};
const fields = {
  InstanceId(instanceData) {
    return instanceData.info.Id;
  },

  SignupDeadline(instanceData) {
    return extractDate(instanceData, 'SignupDeadlineForUsers');
  },

  StartDate(instanceData) {
    return extractDate(instanceData, 'StartDate', true);
  },

  EventsWeekday(instanceData) {
    const events = instanceData.events ? instanceData.events.Events : [];
    return extractWeekday(events);
  },

  LectureWeekday(instanceData) {
    const events = instanceData.events ? instanceData.events.Events.filter(e => {
      const lecture = instanceData.lectures.find(l => l.Id == e.LectureId);
      return lecture && !lecture.IsExcludedFromCertificate;
    }) : [];
    return extractWeekday(events);
  },

  ExerciseWeekday(instanceData) {
    const events = instanceData.events ? instanceData.events.Events.filter(e => {
      const lecture = instanceData.lectures.find(l => l.Id == e.LectureId);
      return lecture && lecture.IsExcludedFromCertificate;
    }) : [];
    return extractWeekday(events);
  },

  EventStartTime(instanceData) {
    const events = instanceData.events ? instanceData.events.Events : [];
    return extractTime(events, 'StartDateTime', true);
  },

  LectureStartTime(instanceData) {
    const events = filterLectures(instanceData);
    return extractTime(events, 'StartDateTime', true);
  },

  ExerciseStartTime(instanceData) {
    const events = filterExercises(instanceData);
    return extractTime(events, 'StartDateTime', true);
  },

  EventEndTime(instanceData) {
    const events = instanceData.events ? instanceData.events.Events : [];
    return extractTime(events, 'EndDateTime', true);
  },

  LectureEndTime(instanceData) {
    const events = filterLectures(instanceData);
    return extractTime(events, 'EndDateTime', true);
  },

  ExerciseEndTime(instanceData) {
    const events = filterExercises(instanceData);
    return extractTime(events, 'EndDateTime', true);
  },

  PriceOnline(instanceData) {
    return instanceData.info.PriceOnline;
  },

  FirstExamDate(instanceData) {
    const firstExam = instanceData.exams.sort((a, b) => new Date(a.StartTime) - new Date(b.StartTime))[0];

    if (firstExam) {
      return (0,_util_parse__WEBPACK_IMPORTED_MODULE_1__.formatLocaleDate)(new Date(firstExam.StartTime));
    } else {
      return undefined;
    }
  },

  RefundDeadline(instanceData) {
    const events = instanceData.events ? instanceData.events.Events : [];
    const thirdEvent = events.slice().sort((a, b) => new Date(a.StartDateTime) - new Date(b.StartDateTime))[2];

    if (thirdEvent) {
      return (0,_util_parse__WEBPACK_IMPORTED_MODULE_1__.formatLocaleDate)(new Date(thirdEvent.StartDateTime));
    } else {
      return undefined;
    }
  }

};

function extractWeekday(events) {
  let weekdays = filterStrays(events.map(e => new Date(e.StartDateTime)).map(e => e.getDay()).reduce(toCount, {}));

  if (weekdays.length == 1) {
    const text = (0,_util_parse__WEBPACK_IMPORTED_MODULE_1__.formatLocaleWeekday)(weekdays[0], true);
    return `${text[1]} <strong>${text[0]}</strong>`;
  } else if (weekdays.length > 1) {
    const text = weekdays.map(w => (0,_util_parse__WEBPACK_IMPORTED_MODULE_1__.formatLocaleWeekday)(w));
    return `всеки <strong>${text.slice(0, -1).join('</strong>, <strong>')}</strong> и <strong>${text[text.length - 1]}</strong>`;
  }
}

function extractDate(instanceData, propName, includeYear) {
  let date = instanceData.info[propName];

  if (date) {
    date = new Date(date);

    if (includeYear) {
      return `${(0,_util_parse__WEBPACK_IMPORTED_MODULE_1__.formatLocaleDate)(date)} ${date.getFullYear()} г`;
    } else {
      return (0,_util_parse__WEBPACK_IMPORTED_MODULE_1__.formatLocaleDate)(date);
    }
  } else {
    return undefined;
  }
}

function extractTime(events, propName, singleResult) {
  let times = filterStrays(events.map(e => new Date(e[propName])).map(e => (0,_util_parse__WEBPACK_IMPORTED_MODULE_1__.formatTime)(e)).reduce(toCount, {}), singleResult);
  return times;
}

function toCount(p, c) {
  if (p[c] == undefined) {
    p[c] = 0;
  }

  p[c]++;
  return p;
}

function filterLectures(instanceData) {
  const events = instanceData.events ? instanceData.events.Events.filter(e => {
    const lecture = instanceData.lectures.find(l => l.Id == e.LectureId);
    return lecture && !lecture.IsExcludedFromCertificate;
  }) : [];
  return events;
}

function filterExercises(instanceData) {
  const events = instanceData.events ? instanceData.events.Events.filter(e => {
    const lecture = instanceData.lectures.find(l => l.Id == e.LectureId);
    return lecture && lecture.IsExcludedFromCertificate;
  }) : [];
  return events;
}

function filterStrays(data, singleResult) {
  if (singleResult) {
    const output = Object.entries(data).sort((a, b) => b[1] - a[1]).map(x => x[0]);
    return output[0];
  } else {
    return Object.entries(data).filter(x => x[1] > 1).map(x => x[0]);
  }
}

/***/ }),

/***/ "./src/templates/TemplateList.js":
/*!***************************************!*\
  !*** ./src/templates/TemplateList.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TemplateList": () => (/* binding */ TemplateList)
/* harmony export */ });
/* harmony import */ var _util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/jsx-render-mod/dom */ "./src/util/jsx-render-mod/dom.js");
/* harmony import */ var _util_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/router */ "./src/util/router.js");
/* harmony import */ var _util_template__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../util/template */ "./src/util/template.js");
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./data */ "./src/templates/data.js");
/* harmony import */ var _Preview__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Preview */ "./src/templates/Preview.js");






function TemplateList({
  config,
  templates,
  api,
  context
}) {
  context.on('ListUpdated', updateSelf);
  let tbody = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tbody", null);
  updateSelf();
  return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("p", null, "\u0418\u0437\u0431\u0435\u0440\u0435\u0442\u0435 \u0448\u0430\u0431\u043B\u043E\u043D \u043E\u0442 \u0441\u043F\u0438\u0441\u044A\u043A\u0430, \u0437\u0430 \u0434\u0430 \u043F\u0440\u0435\u0433\u043B\u0435\u0434\u0430\u0442\u0435 \u0441\u044A\u0434\u044A\u0440\u0436\u0430\u043D\u0438\u0435\u0442\u043E \u043C\u0443."), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("table", {
    className: "ses-template-table",
    style: {
      width: '100%'
    }
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("thead", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tr", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", {
    colSpan: "5"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_router__WEBPACK_IMPORTED_MODULE_1__.Link, {
    href: '?new',
    className: "ses-page-link"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("i", {
    class: "glyphicon glyphicon-plus"
  }), " \u0421\u044A\u0437\u0434\u0430\u0439 \u0448\u0430\u0431\u043B\u043E\u043D"))), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tr", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("th", null, "\u0418\u043C\u0435"), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("th", null, "\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438"), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("th", {
    style: {
      width: '100px'
    }
  }, "\u0426\u044F\u043B\u043E\u0441\u0442\u0435\u043D"), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("th", {
    style: {
      width: '100px'
    }
  }, "\u0410\u043A\u0442\u0443\u0430\u043B\u0435\u043D"), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("th", {
    style: {
      width: '100px'
    }
  }, "\u041A\u043E\u043D\u0442\u0440\u043E\u043B"))), tbody, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tfoot", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tr", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", {
    colSpan: "5"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_router__WEBPACK_IMPORTED_MODULE_1__.Link, {
    href: '?new',
    className: "ses-page-link"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("i", {
    class: "glyphicon glyphicon-plus"
  }), " \u0421\u044A\u0437\u0434\u0430\u0439 \u0448\u0430\u0431\u043B\u043E\u043D"))))));

  function updateSelf() {
    tbody = (0,_util_template__WEBPACK_IMPORTED_MODULE_2__.replaceContents)(tbody, templates.filter(t => !t.InstanceId).map(TemplateRow.bind(null, config.categories, templates, api, context)));
  }
}

function TemplateRow(categories, allTemplates, api, context, template) {
  const usesFragments = /\[\[Ref=.+?\]\]/.test(template.Content);
  const isDynamic = usesFragments == false && /\[\[.+?\]\]/.test(template.Content);
  let active = false;
  const element = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tr", {
    className: "ses-template-row",
    onClick: toggle
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, template.Name), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, template.Category.map(c => (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
    className: "ses-template-category"
  }, categories[c])), usesFragments ? (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
    className: "ses-template-category-auto"
  }, "\u0421\u044A\u0434\u044A\u0440\u0436\u0430 \u0444\u0440\u0430\u0433\u043C\u0435\u043D\u0442\u0438") : '', isDynamic ? (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
    className: "ses-template-category-auto"
  }, "\u0414\u0438\u043D\u0430\u043C\u0438\u0447\u0435\u043D") : ''), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", {
    className: "ses-center"
  }, template.Compound ? (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_2__.Yes, null) : (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_2__.No, null)), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", {
    className: "ses-center"
  }, template.Active ? (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_2__.Yes, null) : (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_2__.No, null)), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", {
    className: "ses-center"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("button", {
    onClick: () => (0,_util_router__WEBPACK_IMPORTED_MODULE_1__.redirect)(`?id=${template.Id}`)
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("i", {
    class: "glyphicon glyphicon-pencil"
  })), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("button", {
    onClick: onDelete
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("i", {
    class: "glyphicon glyphicon-trash"
  }))));
  let preview = null;
  const decoration = (0,_util_template__WEBPACK_IMPORTED_MODULE_2__.getEditorDecoration)(element);
  return element;

  function toggle(e) {
    if (e && (e.target.tagName == 'I' || e.target.tagName == 'BUTTON')) {
      return;
    }

    if (active) {
      active = false;
      preview.remove();
    } else {
      active = true;

      if (preview == null) {
        preview = generatePreview(allTemplates, template, toggle);
      }

      element.after(preview);
    }
  }

  async function onDelete() {
    const choice = confirm(`Сигурни ли сте, че искате да изтриете шаблона "${template.Name}"?`);

    if (choice) {
      decoration.working();

      try {
        await (0,_data__WEBPACK_IMPORTED_MODULE_3__.deleteTemplate)(api, template);
        allTemplates.splice(allTemplates.indexOf(template), 1);
        context.emit('ListUpdated');
      } catch (err) {
        decoration.failure();
        alert(err.message);
        console.error(err);
      }
    }
  }
}

function generatePreview(allTemplates, template, toggle) {
  return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tr", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", {
    colSpan: "5"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_Preview__WEBPACK_IMPORTED_MODULE_4__["default"], {
    content: template.Content,
    templates: allTemplates
  }), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("button", {
    style: {
      float: 'right'
    },
    onClick: () => toggle()
  }, "\u0417\u0430\u0442\u0432\u043E\u0440\u0438"))));
}

/***/ }),

/***/ "./src/templates/catalog.js":
/*!**********************************!*\
  !*** ./src/templates/catalog.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "catalogPage": () => (/* binding */ catalogPage),
/* harmony export */   "createPage": () => (/* binding */ createPage),
/* harmony export */   "editPage": () => (/* binding */ editPage)
/* harmony export */ });
/* harmony import */ var _util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/jsx-render-mod/dom */ "./src/util/jsx-render-mod/dom.js");
/* harmony import */ var _util_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/api */ "./src/util/api.js");
/* harmony import */ var _util_template__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../util/template */ "./src/util/template.js");
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./data */ "./src/templates/data.js");
/* harmony import */ var _TemplateList__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./TemplateList */ "./src/templates/TemplateList.js");
/* harmony import */ var _Editor__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Editor */ "./src/templates/Editor.js");
/// <reference path="../util/api.d.ts" />







async function page(Component, options = {}) {
  let container = document.getElementById('pageContent');
  container = (0,_util_template__WEBPACK_IMPORTED_MODULE_2__.replaceContents)(container, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_2__.Loading, {
    color: "black"
  }));
  const config = await (0,_data__WEBPACK_IMPORTED_MODULE_3__.getConfig)(_util_api__WEBPACK_IMPORTED_MODULE_1__);
  const templates = await (0,_data__WEBPACK_IMPORTED_MODULE_3__.getTemplates)(_util_api__WEBPACK_IMPORTED_MODULE_1__);
  container = (0,_util_template__WEBPACK_IMPORTED_MODULE_2__.replaceContents)(container, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(Component, Object.assign({
    config: config,
    templates: templates
  }, options)));
}

async function catalogPage(query, context) {
  page(_TemplateList__WEBPACK_IMPORTED_MODULE_4__.TemplateList, {
    api: _util_api__WEBPACK_IMPORTED_MODULE_1__,
    context
  });
}
async function createPage(query, context) {
  page(_Editor__WEBPACK_IMPORTED_MODULE_5__["default"], {
    api: _util_api__WEBPACK_IMPORTED_MODULE_1__
  });
}
async function editPage(query, context) {
  const id = query.id;
  page(_Editor__WEBPACK_IMPORTED_MODULE_5__["default"], {
    id,
    title: 'Редакция на шаблон',
    api: _util_api__WEBPACK_IMPORTED_MODULE_1__
  });
}

/***/ }),

/***/ "./src/templates/data.js":
/*!*******************************!*\
  !*** ./src/templates/data.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "createTemplateModel": () => (/* binding */ createTemplateModel),
/* harmony export */   "deleteTemplate": () => (/* binding */ deleteTemplate),
/* harmony export */   "getConfig": () => (/* binding */ getConfig),
/* harmony export */   "getTemplateByInstanceId": () => (/* binding */ getTemplateByInstanceId),
/* harmony export */   "getTemplates": () => (/* binding */ getTemplates),
/* harmony export */   "saveTemplate": () => (/* binding */ saveTemplate)
/* harmony export */ });
/* harmony import */ var _util_data_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/data-connect */ "./src/util/data-connect.js");
/// <reference path="../util/api.d.ts" />

/**
 * @param {SUAPI} api 
 */

async function getConfig(api) {
  const data = await (0,_util_data_connect__WEBPACK_IMPORTED_MODULE_0__.withCache)(api.getTemplateStoreSettings, _util_data_connect__WEBPACK_IMPORTED_MODULE_0__.stores.TEMPLATE_CONFIG)();
  return data.settings;
}
/**
 * @param {SUAPI} api 
 */

async function getTemplates(api) {
  return api.getTemplates();
}
/**
 * @param {SUAPI} api 
 */

async function getTemplateByInstanceId(api, instanceId) {
  return api.getTemplateByInstanceId(instanceId);
}
/**
 * @param {SUAPI} api 
 */

async function saveTemplate(api, template) {
  return api.saveTemplate(template);
}
/**
 * @param {SUAPI} api 
 */

async function deleteTemplate(api, template) {
  return api.deleteTemplate(template);
}
function createTemplateModel() {
  return {
    Id: 0,
    Name: '',
    Category: [],
    Active: false,
    Compound: false,
    Content: '',
    InstanceId: ''
  };
}

/***/ }),

/***/ "./src/util/api-connect.js":
/*!*********************************!*\
  !*** ./src/util/api-connect.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _parse__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parse */ "./src/util/parse.js");
/* harmony import */ var _api_api_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../api/api-index */ "./src/api/api-index.js");
/* harmony import */ var _node_modules_awesome_notifications_src_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../node_modules/awesome-notifications/src/index.js */ "./node_modules/awesome-notifications/src/index.js");
/// <reference path="./api.d.ts" />



const dispatcher = {};
let bgPort;
startSesApiPort();

function startSesApiPort() {
  bgPort = browser.runtime.connect({
    name: 'ses-api-port'
  });
  bgPort.onMessage.addListener(onMessage);
  bgPort.onDisconnect.addListener(() => {
    startSesApiPort();
  });
}

function getData(type, params) {
  return new Promise((resolve, reject) => {
    const _uuid = (0,_parse__WEBPACK_IMPORTED_MODULE_0__.uuid)();

    bgPort.postMessage({
      _uuid,
      appName: interopAppName(),
      type,
      params
    });
    dispatcher[_uuid] = {
      resolve,
      reject,
      type
    };
  });
}

function onMessage(m) {
  const uuid = m._uuid;

  if (m._rejected) {
    console.info('Operation reject:', dispatcher[uuid].type);
    const error = new Error(m._error);
    let notifier = new _node_modules_awesome_notifications_src_index_js__WEBPACK_IMPORTED_MODULE_2__["default"]();
    notifier.alert(`${m._error}`, {
      durations: {
        alert: 10000
      }
    }); //maybe update to show only in debug mode, providing more detailed error information using the _meta property

    console.dir(error);
    error._meta = m._meta;
    dispatcher[uuid].reject(error);
  } else {
    dispatcher[uuid].resolve(m.data);
  }

  delete dispatcher[uuid];
}

function interopAppName() {
  switch (window.location.host.slice(0, 7)) {
    case 'digital':
      return 'digital';

    case 'creativ':
      return 'creative';

    case 'ai.soft':
      return 'ai';

    case 'finance':
      return 'financeacademy';

    case 'dev.dig':
      return 'devdigital';

    case 'dev.sof':
      return 'devsoftuni';

    default:
      return 'programming';
  }
}
/** @type {SUAPI} */


const actions = (0,_api_api_index__WEBPACK_IMPORTED_MODULE_1__["default"])(null).map(a => ({
  name: a,
  func: (...params) => getData(a, params)
})).reduce((p, c) => {
  p[c.name] = c.func;
  return p;
}, {});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (actions);

/***/ }),

/***/ "./src/util/api.js":
/*!*************************!*\
  !*** ./src/util/api.js ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "addQuizQuestion": () => (/* binding */ addQuizQuestion),
/* harmony export */   "addQuizQuestionAnswer": () => (/* binding */ addQuizQuestionAnswer),
/* harmony export */   "createDocument": () => (/* binding */ createDocument),
/* harmony export */   "createEvent": () => (/* binding */ createEvent),
/* harmony export */   "createExam": () => (/* binding */ createExam),
/* harmony export */   "createExamGroup": () => (/* binding */ createExamGroup),
/* harmony export */   "createLecture": () => (/* binding */ createLecture),
/* harmony export */   "createQuizInstance": () => (/* binding */ createQuizInstance),
/* harmony export */   "createSkill": () => (/* binding */ createSkill),
/* harmony export */   "createStatus": () => (/* binding */ createStatus),
/* harmony export */   "createTrainingByTrainer": () => (/* binding */ createTrainingByTrainer),
/* harmony export */   "createTrainingGroup": () => (/* binding */ createTrainingGroup),
/* harmony export */   "deleteConfig": () => (/* binding */ deleteConfig),
/* harmony export */   "deleteNavetFile": () => (/* binding */ deleteNavetFile),
/* harmony export */   "deleteTemplate": () => (/* binding */ deleteTemplate),
/* harmony export */   "destroyEvent": () => (/* binding */ destroyEvent),
/* harmony export */   "destroyExamGroup": () => (/* binding */ destroyExamGroup),
/* harmony export */   "destroyGroup": () => (/* binding */ destroyGroup),
/* harmony export */   "destroyLecture": () => (/* binding */ destroyLecture),
/* harmony export */   "destroySkill": () => (/* binding */ destroySkill),
/* harmony export */   "destroyStatus": () => (/* binding */ destroyStatus),
/* harmony export */   "destroyTrainingOfTrainer": () => (/* binding */ destroyTrainingOfTrainer),
/* harmony export */   "findSurveyByTraining": () => (/* binding */ findSurveyByTraining),
/* harmony export */   "getAllQuizesByName": () => (/* binding */ getAllQuizesByName),
/* harmony export */   "getAnswersByQuestionId": () => (/* binding */ getAnswersByQuestionId),
/* harmony export */   "getAnyById": () => (/* binding */ getAnyById),
/* harmony export */   "getAppStatus": () => (/* binding */ getAppStatus),
/* harmony export */   "getAppStatusByInstanceId": () => (/* binding */ getAppStatusByInstanceId),
/* harmony export */   "getAppZip": () => (/* binding */ getAppZip),
/* harmony export */   "getApplications": () => (/* binding */ getApplications),
/* harmony export */   "getApplicationsByInstanceId": () => (/* binding */ getApplicationsByInstanceId),
/* harmony export */   "getBlogByUrl": () => (/* binding */ getBlogByUrl),
/* harmony export */   "getConfigByExamId": () => (/* binding */ getConfigByExamId),
/* harmony export */   "getConfigs": () => (/* binding */ getConfigs),
/* harmony export */   "getContestCompeteResults": () => (/* binding */ getContestCompeteResults),
/* harmony export */   "getCourseData": () => (/* binding */ getCourseData),
/* harmony export */   "getCourseEvents": () => (/* binding */ getCourseEvents),
/* harmony export */   "getCourseInstances": () => (/* binding */ getCourseInstances),
/* harmony export */   "getEnrolledByGroupId": () => (/* binding */ getEnrolledByGroupId),
/* harmony export */   "getEvents": () => (/* binding */ getEvents),
/* harmony export */   "getEventsByDate": () => (/* binding */ getEventsByDate),
/* harmony export */   "getEventsById": () => (/* binding */ getEventsById),
/* harmony export */   "getExamGroupsByExamId": () => (/* binding */ getExamGroupsByExamId),
/* harmony export */   "getExamsByCourse": () => (/* binding */ getExamsByCourse),
/* harmony export */   "getExamsByName": () => (/* binding */ getExamsByName),
/* harmony export */   "getExtraCourseInfo": () => (/* binding */ getExtraCourseInfo),
/* harmony export */   "getGraduateInfo": () => (/* binding */ getGraduateInfo),
/* harmony export */   "getGroupById": () => (/* binding */ getGroupById),
/* harmony export */   "getHalls": () => (/* binding */ getHalls),
/* harmony export */   "getHomeworkResults": () => (/* binding */ getHomeworkResults),
/* harmony export */   "getInsanceGroups": () => (/* binding */ getInsanceGroups),
/* harmony export */   "getInstanceConfig": () => (/* binding */ getInstanceConfig),
/* harmony export */   "getInstanceData": () => (/* binding */ getInstanceData),
/* harmony export */   "getInstanceFullPage": () => (/* binding */ getInstanceFullPage),
/* harmony export */   "getInstanceInModule": () => (/* binding */ getInstanceInModule),
/* harmony export */   "getInstanceLectures": () => (/* binding */ getInstanceLectures),
/* harmony export */   "getInstancePage": () => (/* binding */ getInstancePage),
/* harmony export */   "getInstancesInModule": () => (/* binding */ getInstancesInModule),
/* harmony export */   "getLectureDetails": () => (/* binding */ getLectureDetails),
/* harmony export */   "getLecturesForExamsByTrainingId": () => (/* binding */ getLecturesForExamsByTrainingId),
/* harmony export */   "getModules": () => (/* binding */ getModules),
/* harmony export */   "getModulesInProfession": () => (/* binding */ getModulesInProfession),
/* harmony export */   "getNavetArchivedCourses": () => (/* binding */ getNavetArchivedCourses),
/* harmony export */   "getNavetCertificate": () => (/* binding */ getNavetCertificate),
/* harmony export */   "getNavetClosedCourses": () => (/* binding */ getNavetClosedCourses),
/* harmony export */   "getNavetCourseInfo": () => (/* binding */ getNavetCourseInfo),
/* harmony export */   "getNavetCurrentCourses": () => (/* binding */ getNavetCurrentCourses),
/* harmony export */   "getNavetExistingFiles": () => (/* binding */ getNavetExistingFiles),
/* harmony export */   "getNavetStudentInfo": () => (/* binding */ getNavetStudentInfo),
/* harmony export */   "getNavetStudents": () => (/* binding */ getNavetStudents),
/* harmony export */   "getPackagesForProduct": () => (/* binding */ getPackagesForProduct),
/* harmony export */   "getPaymentsForPackage": () => (/* binding */ getPaymentsForPackage),
/* harmony export */   "getProductsForCourse": () => (/* binding */ getProductsForCourse),
/* harmony export */   "getProductsForModule": () => (/* binding */ getProductsForModule),
/* harmony export */   "getProtocol": () => (/* binding */ getProtocol),
/* harmony export */   "getQuestionsById": () => (/* binding */ getQuestionsById),
/* harmony export */   "getSeminarsByDate": () => (/* binding */ getSeminarsByDate),
/* harmony export */   "getSkillsByInstance": () => (/* binding */ getSkillsByInstance),
/* harmony export */   "getStoreSettings": () => (/* binding */ getStoreSettings),
/* harmony export */   "getStudents": () => (/* binding */ getStudents),
/* harmony export */   "getSurveyAnswers": () => (/* binding */ getSurveyAnswers),
/* harmony export */   "getSurveyById": () => (/* binding */ getSurveyById),
/* harmony export */   "getSurveyQuestionsByTemplateId": () => (/* binding */ getSurveyQuestionsByTemplateId),
/* harmony export */   "getSurveySectionsById": () => (/* binding */ getSurveySectionsById),
/* harmony export */   "getSurveySectionsByTemplateId": () => (/* binding */ getSurveySectionsByTemplateId),
/* harmony export */   "getSurveyTemplates": () => (/* binding */ getSurveyTemplates),
/* harmony export */   "getSurveys": () => (/* binding */ getSurveys),
/* harmony export */   "getSurveysByNameAndStartAndEndDate": () => (/* binding */ getSurveysByNameAndStartAndEndDate),
/* harmony export */   "getTemplateByInstanceId": () => (/* binding */ getTemplateByInstanceId),
/* harmony export */   "getTemplateByName": () => (/* binding */ getTemplateByName),
/* harmony export */   "getTemplateStoreSettings": () => (/* binding */ getTemplateStoreSettings),
/* harmony export */   "getTemplates": () => (/* binding */ getTemplates),
/* harmony export */   "getTrainerById": () => (/* binding */ getTrainerById),
/* harmony export */   "getTrainerNames": () => (/* binding */ getTrainerNames),
/* harmony export */   "getTrainersByTraining": () => (/* binding */ getTrainersByTraining),
/* harmony export */   "getTrainingsByTrainer": () => (/* binding */ getTrainingsByTrainer),
/* harmony export */   "openNavetCertificate": () => (/* binding */ openNavetCertificate),
/* harmony export */   "openNavetFile": () => (/* binding */ openNavetFile),
/* harmony export */   "saveConfig": () => (/* binding */ saveConfig),
/* harmony export */   "saveTemplate": () => (/* binding */ saveTemplate),
/* harmony export */   "searchByName": () => (/* binding */ searchByName),
/* harmony export */   "searchCourseInstancesByCourseNameAndInstanceId": () => (/* binding */ searchCourseInstancesByCourseNameAndInstanceId),
/* harmony export */   "searchCourses": () => (/* binding */ searchCourses),
/* harmony export */   "searchModules": () => (/* binding */ searchModules),
/* harmony export */   "searchSkills": () => (/* binding */ searchSkills),
/* harmony export */   "searchTrainingsByName": () => (/* binding */ searchTrainingsByName),
/* harmony export */   "searchUsers": () => (/* binding */ searchUsers),
/* harmony export */   "updateCourse": () => (/* binding */ updateCourse),
/* harmony export */   "updateEvent": () => (/* binding */ updateEvent),
/* harmony export */   "updateExam": () => (/* binding */ updateExam),
/* harmony export */   "updateExamGroup": () => (/* binding */ updateExamGroup),
/* harmony export */   "updateHall": () => (/* binding */ updateHall),
/* harmony export */   "updateInstance": () => (/* binding */ updateInstance),
/* harmony export */   "updateLecture": () => (/* binding */ updateLecture),
/* harmony export */   "updateNavetStudent": () => (/* binding */ updateNavetStudent),
/* harmony export */   "updateSkill": () => (/* binding */ updateSkill),
/* harmony export */   "updateStatus": () => (/* binding */ updateStatus),
/* harmony export */   "updateTrainingByTrainer": () => (/* binding */ updateTrainingByTrainer),
/* harmony export */   "uploadDiploma": () => (/* binding */ uploadDiploma),
/* harmony export */   "uploadExamResults": () => (/* binding */ uploadExamResults),
/* harmony export */   "uploadMedical": () => (/* binding */ uploadMedical),
/* harmony export */   "uploadNavetCertificate": () => (/* binding */ uploadNavetCertificate)
/* harmony export */ });
/* harmony import */ var _api_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./api-connect */ "./src/util/api-connect.js");
 // ########################################################################################################################
// ### Common Data
// ########################################################################################################################

async function getBlogByUrl(blogUrl) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getBlogByUrl(blogUrl);
}
async function getHalls() {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getHalls();
}
async function updateHall(hall) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateHall(hall);
} // ########################################################################################################################
// ### Module Data
// ########################################################################################################################

async function getModulesInProfession(professionId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getModulesInProfession(professionId);
}
async function getModules() {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getModules();
}
async function getInstancesInModule(moduleId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInstancesInModule(moduleId);
}
async function searchModules(query) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].searchModules(query);
}
async function getInstanceInModule(moduleId, moduleInstanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInstanceInModule(moduleId, moduleInstanceId);
} // ########################################################################################################################
// ### Payments Data
// ########################################################################################################################

async function getPaymentsForPackage(packageName) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getPaymentsForPackage(packageName);
}
async function getPackagesForProduct(productId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getPackagesForProduct(productId);
}
async function getProductsForModule(moduleId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getProductsForModule(moduleId);
}
async function getProductsForCourse(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getProductsForCourse(instanceId);
} // ########################################################################################################################
// ### Payments Data
// ########################################################################################################################

async function getContestCompeteResults(contestId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getContestCompeteResults(contestId);
} // ########################################################################################################################
// ### Quiz Data
// ########################################################################################################################

async function createQuizInstance(payload) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createQuizInstance(payload);
}
async function addQuizQuestion(quizId, content) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].addQuestion(quizId, content);
}
async function addQuizQuestionAnswer(questionId, answer, isCorrect) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].addAnswer(questionId, answer, isCorrect);
}
async function getAllQuizesByName(containingName, pageSize, page) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getAllQuizesByName(containingName, pageSize, page);
}
async function getQuestionsById(quizId, pageSize, page) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getQuestionsById(quizId, pageSize, page);
}
async function getAnswersByQuestionId(questionId, pageSize, page) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getAnswersByQuestionId(questionId, pageSize, page);
} // ########################################################################################################################
// ### Survey Data
// ########################################################################################################################

async function getSurveys(page, query, pageSize) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveys(page, query, pageSize);
}
async function getSurveysByNameAndStartAndEndDate(page, name, startDate, endDate, pageSize) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveysByNameAndStartAndEndDate(page, name, startDate, endDate, pageSize);
}
async function getSurveyById(surveyId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveyById(surveyId);
}
async function getSurveyAnswers(surveyId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveyAnswers(surveyId);
}
async function getSurveyTemplates() {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveyTemplates();
}
async function getSurveyQuestionsByTemplateId(templateId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveyQuestionsByTemplateId(templateId);
}
async function getSurveySectionsByTemplateId(templateId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveySectionsByTemplateId(templateId);
}
async function getSurveySectionsById(sectionId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveySectionsById(sectionId);
}
async function findSurveyByTraining(nameBg) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].findSurveyByTraining(nameBg);
} // ########################################################################################################################
// ### User Data
// ########################################################################################################################

async function getTrainingsByTrainer(userId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTrainingsByTrainer(userId);
}
async function getTrainerById(userId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTrainerById(userId);
}
async function updateTrainingByTrainer(training) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateTrainingByTrainer(training);
}
async function createTrainingByTrainer(training) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createTrainingByTrainer(training);
}
async function destroyTrainingOfTrainer(training) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].destroyTrainingOfTrainer(training);
}
async function searchUsers(query, exclude) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].searchUsers(query, exclude);
}
async function getTrainersByTraining(trainingId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTrainersByTraining(trainingId);
} // ########################################################################################################################
// ### Course Data
// ########################################################################################################################

async function searchByName(body) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].searchByName(body);
}
async function searchCourses(query) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].searchCourses(query);
}
async function getCourseData(courseId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getCourseData(courseId);
}
async function getCourseInstances(courseId, filter = undefined) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getCourseInstances(courseId, filter = undefined);
}
async function getInstanceData(instanceId, courseId, type) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInstanceData(instanceId, courseId, type);
}
async function updateCourse(course) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateCourse(course);
}
async function updateInstance(instance) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateInstance(instance);
}
async function getStudents(instanceId, type = 'main') {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getStudents(instanceId, type);
}
async function getCourseEvents(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getCourseEvents(instanceId);
}
async function getAnyById(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getAnyById(instanceId);
}
async function getInstancePage(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInstancePage(instanceId);
}
async function getInstanceFullPage(url) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInstanceFullPage(url);
}
async function getTrainerNames(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTrainerNames(instanceId);
}
async function searchCourseInstancesByCourseNameAndInstanceId(courseName, instanceId, filter = undefined) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].searchCourseInstancesByCourseNameAndInstanceId(courseName, instanceId, filter = undefined);
}
async function searchTrainingsByName(name, exact = false) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].searchTrainingsByName(name, exact);
} // ########################################################################################################################
// ### Exam Data
// ########################################################################################################################

async function getExamsByCourse(nameBg, instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getExamsByCourse(nameBg, instanceId);
}
async function getExamsByName(query) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getExamsByName(query);
}
async function getExamGroupsByExamId(examId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getExamGroupsByExamId(examId);
}
async function getEnrolledByGroupId(examGroupId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getEnrolledByGroupId(examGroupId);
}
async function createExam(exam) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createExam(exam);
}
async function updateExam(exam) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateExam(exam);
}
async function createExamGroup(group) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createExamGroup(group);
}
async function updateExamGroup(group) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateExamGroup(group);
}
async function destroyExamGroup(group) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].destroyExamGroup(group);
} // ########################################################################################################################
// ### Event Data
// ########################################################################################################################

async function getEvents(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getEvents(instanceId);
}
async function updateEvent(event) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateEvent(event);
}
async function createEvent(event) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createEvent(event);
}
async function destroyEvent(event) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].destroyEvent(event);
}
async function getEventsByDate(startDate, endDate) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getEventsByDate(startDate, endDate);
}
async function getEventsById(eventId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getEventsById(eventId);
} // ########################################################################################################################
// ### Group Data
// ########################################################################################################################

async function getInsanceGroups(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInsanceGroups(instanceId);
}
async function getGroupById(groupId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getGroupById(groupId);
}
async function createTrainingGroup(group) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createTrainingGroup(group);
}
async function destroyGroup(group) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].destroyGroup(group);
} // ########################################################################################################################
// ### Lecture Data
// ########################################################################################################################

async function getInstanceLectures(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInstanceLectures(instanceId);
}
async function updateLecture(lecture) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateLecture(lecture);
}
async function createLecture(lecture) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createLecture(lecture);
}
async function destroyLecture(lecture) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].destroyLecture(lecture);
}
async function getLectureDetails(trainingId, lectureId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getLectureDetails(trainingId, lectureId);
}
async function getLecturesForExamsByTrainingId(trainingId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getLecturesForExamsByTrainingId(trainingId);
} // ########################################################################################################################
// ### Skill Data
// ########################################################################################################################

async function getSkillsByInstance(name, instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSkillsByInstance(name, instanceId);
}
async function updateSkill(skill) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateSkill(skill);
}
async function createSkill(skill) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createSkill(skill);
}
async function destroySkill(skill) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].destroySkill(skill);
}
async function searchSkills(query, type) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].searchSkills(query, type);
} // ########################################################################################################################
// ### Stream Data
// ########################################################################################################################

async function getInstanceConfig(instanceId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInstanceConfig(instanceId);
} // ########################################################################################################################
// ### CPE Data
// ########################################################################################################################

async function getApplicationsByInstanceId(instanceId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getApplicationsByInstanceId(instanceId);
}
async function getApplications(query, page) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getApplications(query, page);
}
async function getAppZip(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getAppZip(id);
}
async function getAppStatus(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getAppStatus(id);
}
async function getAppStatusByInstanceId(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getAppStatusByInstanceId(id);
}
async function createStatus(status) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createStatus(status);
}
async function updateStatus(status) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateStatus(status);
}
async function destroyStatus(status) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].destroyStatus(status);
} // ########################################################################################################################
// ### NAVET Data
// ########################################################################################################################

async function getNavetCurrentCourses() {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetCurrentCourses();
}
async function getNavetClosedCourses() {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetClosedCourses();
}
async function getNavetArchivedCourses() {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetArchivedCourses();
}
async function getNavetCourseInfo(id, type) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetCourseInfo(id, type);
}
async function getNavetStudents(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetStudents(id);
}
async function getNavetStudentInfo(clientId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetStudentInfo(clientId);
}
async function getNavetExistingFiles(courseId, id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetExistingFiles(courseId, id);
}
async function uploadMedical(courseId, id, fileDescriptor) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].uploadMedical(courseId, id, fileDescriptor);
}
async function uploadDiploma(courseId, id, fileDescriptor, reg_no, prn_no, doc_date) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].uploadDiploma(courseId, id, fileDescriptor, reg_no, prn_no, doc_date);
}
async function openNavetFile(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].openNavetFile(id);
}
async function deleteNavetFile(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].deleteNavetFile(id);
}
async function getGraduateInfo(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getGraduateInfo(id);
}
async function getNavetCertificate(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetCertificate(id);
}
async function openNavetCertificate(id, page) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].openNavetCertificate(id, page);
}
async function uploadNavetCertificate(meta, fileDescriptors) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].uploadNavetCertificate(meta, fileDescriptors);
}
async function updateNavetStudent(id, student) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateNavetStudent(id, student);
}
async function createDocument(studentId, clientId, data) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createDocument(studentId, clientId, data);
}
async function getExtraCourseInfo(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getExtraCourseInfo(id);
} // ########################################################################################################################
// ### Generic Data Store
// ########################################################################################################################

async function getStoreSettings(storeId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getStoreSettings(storeId);
} // ########################################################################################################################
// ### Templates Data
// ########################################################################################################################

async function getTemplateStoreSettings() {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTemplateStoreSettings();
}
async function getTemplates() {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTemplates();
}
async function getTemplateByName(name) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTemplateByName(name);
}
async function getTemplateByInstanceId(instanceId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTemplateByInstanceId(instanceId);
}
async function saveTemplate(template) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].saveTemplate(template);
}
async function deleteTemplate(template) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].deleteTemplate(template);
} // ########################################################################################################################
// ### Assessment Data
// ########################################################################################################################

async function getHomeworkResults(instanceId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getHomeworkResults(instanceId);
}
async function getProtocol(instanceId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getProtocol(instanceId);
}
async function uploadExamResults(examName, examId, combo, fileDescriptor) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].uploadExamResults(examName, examId, combo, fileDescriptor);
}
async function getConfigs(examIds) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getConfigs(examIds);
}
async function getConfigByExamId(examId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getConfigByExamId(examId);
}
async function saveConfig(config) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].saveConfig(config);
}
async function deleteConfig(config) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].deleteConfig(config);
} // ########################################################################################################################
// ### Seminar Data
// ########################################################################################################################

async function getSeminarsByDate(startDate, endDate) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSeminarsByDate(startDate, endDate);
}

/***/ }),

/***/ "./src/util/contentTypes.js":
/*!**********************************!*\
  !*** ./src/util/contentTypes.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ContentType": () => (/* binding */ ContentType)
/* harmony export */ });
class ContentType {
  // Private Fields
  static #_UrlFormEncoded = 'application/x-www-form-urlencoded; charset=UTF-8';
  static #_ApplictionJson = 'application/json'; // Accessors for "get" functions only (no "set" functions)

  static get UrlFormEncoded() {
    return this.#_UrlFormEncoded;
  }

  static get ApplicationJson() {
    return this.#_ApplictionJson;
  }

}

/***/ }),

/***/ "./src/util/data-connect.js":
/*!**********************************!*\
  !*** ./src/util/data-connect.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "clearCache": () => (/* binding */ clearCache),
/* harmony export */   "getData": () => (/* binding */ getData),
/* harmony export */   "setData": () => (/* binding */ setData),
/* harmony export */   "stores": () => (/* binding */ stores),
/* harmony export */   "withCache": () => (/* binding */ withCache)
/* harmony export */ });
/* harmony import */ var _parse__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parse */ "./src/util/parse.js");

const dispatch = {};
const stores = {
  MAIN_MODULES: 'STORE_MAIN_MODULES',
  MODULES: 'STORE_MODULES',
  MODULE_INSTANCES: 'STORE_MODULE_INSTANCES',
  PAYMENTS: 'STORE_PAYMENTS',
  TRAINING_HALLS: 'TRAINING_HALLS',
  COURSE_INFO: 'COURSE_INFO',
  STREAM_CONFIG: 'STREAM_CONFIG',
  SURVEYS: 'SURVEYS',
  SURVEYS_ALL: 'SURVEYS_ALL',
  SURVEY: 'SURVEY_ID_',
  TEMPLATE_CONFIG: 'TEMPLATE_CONFIG',
  STATISTICS_CONFIG: 'STATISTICS_CONFIG'
};
const bgPort = browser.runtime.connect({
  name: 'ses-data-port'
});
bgPort.onMessage.addListener(onMessage);
/**
 * Create function with cached response
 * @param {Function} func Function call to cache
 * @param {Symbol} storeId Store identifier
 * @param {Number=} maxAge Cache age threshold, in seconds. If omitted, the cache is considered non-expiring (resets on reinstalling/updating extension)
 */

function withCache(func, storeId, maxAge) {
  return function (...params) {
    const callbacks = {};
    const promise = new Promise((resolve, reject) => {
      callbacks.resolve = resolve;
      callbacks.reject = reject;
    });
    executor();
    return promise;

    async function executor() {
      try {
        let rawCache = await getData(storeId);

        if (rawCache.data !== undefined && isFresh(rawCache.when, maxAge)) {
          promise._cacheHit = true;
          callbacks.resolve(rawCache.data);
        } else {
          const value = await func(...params);
          setData(storeId, value);
          callbacks.resolve(value);
        }
      } catch (err) {
        callbacks.reject(err);
      }
    }
  };
}

;

function isFresh(creationDate, maxAge) {
  if (maxAge === undefined) {
    return true;
  } else if ((Date.now() - creationDate) / 1000 <= maxAge) {
    return true;
  } else {
    return false;
  }
}

function clearCache(name) {
  bgPort.postMessage({
    clear: name
  });
}
/**
 * Retrieve data from the background store
 * @param {String} name Item name
 */


function getData(name) {
  return new Promise(resolve => {
    const _uuid = (0,_parse__WEBPACK_IMPORTED_MODULE_0__.uuid)();

    bgPort.postMessage({
      _uuid,
      get: name
    });
    dispatch[_uuid] = resolve;
  });
}
/**
 * Save data in the background store
 * @param {String} name Item name
 * @param {*} data Data to save in the store
 */


function setData(name, data) {
  bgPort.postMessage({
    set: name,
    data
  });
}

function onMessage(m) {
  const uuid = m._uuid;
  delete m._uuid;
  dispatch[uuid](m);
  delete dispatch[uuid];
}



/***/ }),

/***/ "./src/util/jsx-render-mod/dom.js":
/*!****************************************!*\
  !*** ./src/util/jsx-render-mod/dom.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Fragment": () => (/* binding */ Fragment),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "portalCreator": () => (/* binding */ portalCreator)
/* harmony export */ });
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils */ "./src/util/jsx-render-mod/utils.js");

/**
 * The tag name and create an html together with the attributes
 *
 * @param  {String} tagName name as string, e.g. 'div', 'span', 'svg'
 * @param  {Object} attrs html attributes e.g. data-, width, src
 * @param  {Array} children html nodes from inside de elements
 * @return {HTMLElement|SVGElement} html node with attrs
 */

function createElements(tagName, attrs, children) {
  const element = (0,_utils__WEBPACK_IMPORTED_MODULE_0__.isSVG)(tagName) ? document.createElementNS('http://www.w3.org/2000/svg', tagName) : document.createElement(tagName); // one or multiple will be evaluated to append as string or HTMLElement

  const fragment = (0,_utils__WEBPACK_IMPORTED_MODULE_0__.createFragmentFrom)(children);
  element.appendChild(fragment);
  Object.keys(attrs || {}).forEach(prop => {
    if (prop === 'style') {
      // e.g. origin: <element style={{ prop: value }} />
      Object.assign(element.style, attrs[prop]);
    } else if (prop === 'ref' && typeof attrs.ref === 'function') {
      attrs.ref(element, attrs);
    } else if (prop === 'className') {
      element.setAttribute('class', attrs[prop]);
    } else if (prop === 'xlinkHref') {
      element.setAttributeNS('http://www.w3.org/1999/xlink', 'xlink:href', attrs[prop]);
    } else if (prop === 'dangerouslySetInnerHTML') {
      // eslint-disable-next-line no-underscore-dangle
      element.innerHTML = attrs[prop].__html;
    } else if (prop in _utils__WEBPACK_IMPORTED_MODULE_0__.EVENT_LISTENERS) {
      element.addEventListener(_utils__WEBPACK_IMPORTED_MODULE_0__.EVENT_LISTENERS[prop], attrs[prop]);
    } else {
      // any other prop will be set as attribute
      element.setAttribute(prop, attrs[prop]);
    }
  });
  return element;
}
/**
 * The JSXTag will be unwrapped returning the html
 *
 * @param  {Function} JSXTag name as string, e.g. 'div', 'span', 'svg'
 * @param  {Object} elementProps custom jsx attributes e.g. fn, strings
 * @param  {Array} children html nodes from inside de elements
 *
 * @return {Function} returns de 'dom' (fn) executed, leaving the HTMLElement
 *
 * JSXTag:  function Comp(props) {
 *   return dom("span", null, props.num);
 * }
 */


function composeToFunction(JSXTag, elementProps, children) {
  const props = Object.assign({}, JSXTag.defaultProps || {}, elementProps, {
    children
  });
  const bridge = JSXTag.prototype && JSXTag.prototype.render ? new JSXTag(props).render : JSXTag;
  const result = bridge(props);

  switch (result) {
    case 'FRAGMENT':
      return (0,_utils__WEBPACK_IMPORTED_MODULE_0__.createFragmentFrom)(children);
    // Portals are useful to render modals
    // allow render on a different element than the parent of the chain
    // and leave a comment instead

    case 'PORTAL':
      bridge.target.appendChild((0,_utils__WEBPACK_IMPORTED_MODULE_0__.createFragmentFrom)(children));
      return document.createComment('Portal Used');

    default:
      return result;
  }
}

function dom(element, attrs, ...children) {
  // Custom Components will be functions
  if (typeof element === 'function') {
    if (element.hasOwnProperty('propTypes')) {
      for (let prop of element.propTypes) {
        if (attrs.hasOwnProperty(prop) === false) {
          console.error(`JSX Error: Missing property '${prop}' from '${element.name}' invocation`);
        }
      }
    } // e.g. const CustomTag = ({ w }) => <span width={w} />
    // will be used
    // e.g. <CustomTag w={1} />
    // becomes: CustomTag({ w: 1})


    return composeToFunction(element, attrs, children);
  } // regular html components will be strings to create the elements
  // this is handled by the babel plugins


  if (typeof element === 'string') {
    return createElements(element, attrs, children);
  }

  return console.error(`jsx-render does not handle ${typeof tag}`);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (dom);
const Fragment = () => 'FRAGMENT';
const portalCreator = node => {
  function Portal() {
    return 'PORTAL';
  }

  Portal.target = document.body;

  if (node && node.nodeType === Node.ELEMENT_NODE) {
    Portal.target = node;
  }

  return Portal;
};

/***/ }),

/***/ "./src/util/jsx-render-mod/utils.js":
/*!******************************************!*\
  !*** ./src/util/jsx-render-mod/utils.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EVENT_LISTENERS": () => (/* binding */ EVENT_LISTENERS),
/* harmony export */   "createFragmentFrom": () => (/* binding */ createFragmentFrom),
/* harmony export */   "isSVG": () => (/* binding */ isSVG)
/* harmony export */ });
function isSVG(element) {
  const patt = new RegExp(`^${element}$`, 'i');
  const SVGTags = ['path', 'svg', 'use', 'g'];
  return SVGTags.some(tag => patt.test(tag));
}
function createFragmentFrom(children) {
  // fragments will help later to append multiple children to the initial node
  const fragment = document.createDocumentFragment();

  function processDOMNodes(child) {
    if (child instanceof HTMLElement || child instanceof SVGElement || child instanceof Comment || child instanceof DocumentFragment) {
      fragment.appendChild(child);
    } else if (typeof child === 'string' || typeof child === 'number') {
      const textnode = document.createTextNode(child);
      fragment.appendChild(textnode);
    } else if (child instanceof Array) {
      child.forEach(processDOMNodes);
    } else if (child === false || child === null) {// expression evaluated as false e.g. {false && <Elem />}
      // expression evaluated as false e.g. {null && <Elem />}
    } else if (typeof child === 'function') {} else if (true) {
      // later other things could not be HTMLElement nor strings
      console.log(child, 'is not appendable');
    }
  }

  children.forEach(processDOMNodes);
  return fragment;
} // Map from JSX property (e.g. onClick) to event name (e.g. 'click').

const EVENT_LISTENERS = {
  // Clipboard Events
  onCopy: 'copy',
  onCut: 'cut',
  onPaste: 'paste',
  // Composition Events
  onCompositionEnd: 'compositionend',
  onCompositionStart: 'compositionstart',
  onCompositionUpdate: 'compositionupdate',
  // Focus Events
  onFocus: 'focus',
  onBlur: 'blur',
  // Form Events
  onChange: 'change',
  onBeforeInput: 'beforeinput',
  onInput: 'input',
  onReset: 'reset',
  onSubmit: 'submit',
  onInvalid: 'invalid',
  // Image Events
  onLoad: 'load',
  onError: 'error',
  // Keyboard Events
  onKeyDown: 'keydown',
  onKeyPress: 'keypress',
  onKeyUp: 'keyup',
  // Media Events
  onAbort: 'abort',
  onCanPlay: 'canplay',
  onCanPlayThrough: 'canplaythrough',
  onDurationChange: 'durationchange',
  onEmptied: 'emptied',
  onEncrypted: 'encrypted',
  onEnded: 'ended',
  onLoadedData: 'loadeddata',
  onLoadedMetadata: 'loadedmetadata',
  onLoadStart: 'loadstart',
  onPause: 'pause',
  onPlay: 'play',
  onPlaying: 'playing',
  onProgress: 'progress',
  onRateChange: 'ratechange',
  onSeeked: 'seeked',
  onSeeking: 'seeking',
  onStalled: 'stalled',
  onSuspend: 'suspend',
  onTimeUpdate: 'timeupdate',
  onVolumeChange: 'volumechange',
  onWaiting: 'waiting',
  // MouseEvents
  onClick: 'click',
  onContextMenu: 'contextmenu',
  onDoubleClick: 'doubleclick',
  onDrag: 'drag',
  onDragEnd: 'dragend',
  onDragEnter: 'dragenter',
  onDragExit: 'dragexit',
  onDragLeave: 'dragleave',
  onDragOver: 'dragover',
  onDragStart: 'dragstart',
  onDrop: 'drop',
  onMouseDown: 'mousedown',
  onMouseEnter: 'mouseenter',
  onMouseLeave: 'mouseleave',
  onMouseMove: 'mousemove',
  onMouseOut: 'mouseout',
  onMouseOver: 'mouseover',
  onMouseUp: 'mouseup',
  // Selection Events
  onSelect: 'select',
  // Touch Events
  onTouchCancel: 'touchcancel',
  onTouchEnd: 'touchend',
  onTouchMove: 'touchmove',
  onTouchStart: 'touchstart',
  // Pointer Events
  onPointerDown: 'pointerdown',
  onPointerMove: 'pointermove',
  onPointerUp: 'pointerup',
  onPointerCancel: 'pointercancel',
  onPointerEnter: 'pointerenter',
  onPointerLeave: 'pointerleave',
  onPointerOver: 'pointerover',
  onPointerOut: 'pointerout',
  // UI Events
  onScroll: 'scroll',
  // Wheel Events
  onWheel: 'wheel',
  // Animation Events
  onAnimationStart: 'animationstart',
  onAnimationEnd: 'animationend',
  onAnimationIteration: 'animationiteration',
  // Transition Events
  onTransitionEnd: 'transitionend'
};

/***/ }),

/***/ "./src/util/parse.js":
/*!***************************!*\
  !*** ./src/util/parse.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dateDiff": () => (/* binding */ dateDiff),
/* harmony export */   "dateDiffToDays": () => (/* binding */ dateDiffToDays),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "formatDate": () => (/* binding */ formatDate),
/* harmony export */   "formatLocaleDate": () => (/* binding */ formatLocaleDate),
/* harmony export */   "formatLocaleWeekday": () => (/* binding */ formatLocaleWeekday),
/* harmony export */   "formatTime": () => (/* binding */ formatTime),
/* harmony export */   "getDateIndex": () => (/* binding */ getDateIndex),
/* harmony export */   "getMonday": () => (/* binding */ getMonday),
/* harmony export */   "getOffsetByDays": () => (/* binding */ getOffsetByDays),
/* harmony export */   "getSunday": () => (/* binding */ getSunday),
/* harmony export */   "hasValue": () => (/* binding */ hasValue),
/* harmony export */   "htmlToText": () => (/* binding */ htmlToText),
/* harmony export */   "instanceMetaFromHref": () => (/* binding */ instanceMetaFromHref),
/* harmony export */   "isLastDay": () => (/* binding */ isLastDay),
/* harmony export */   "isLastWeek": () => (/* binding */ isLastWeek),
/* harmony export */   "localeMonthName": () => (/* binding */ localeMonthName),
/* harmony export */   "monthName": () => (/* binding */ monthName),
/* harmony export */   "normalizeDateTime": () => (/* binding */ normalizeDateTime),
/* harmony export */   "offsetByDays": () => (/* binding */ offsetByDays),
/* harmony export */   "paymentsToMatrix": () => (/* binding */ paymentsToMatrix),
/* harmony export */   "prettyJSON": () => (/* binding */ prettyJSON),
/* harmony export */   "queryString": () => (/* binding */ queryString),
/* harmony export */   "sumArrayMax": () => (/* binding */ sumArrayMax),
/* harmony export */   "toAssocArray": () => (/* binding */ toAssocArray),
/* harmony export */   "toCustomAssocArray": () => (/* binding */ toCustomAssocArray),
/* harmony export */   "uuid": () => (/* binding */ uuid),
/* harmony export */   "valueOrEmpty": () => (/* binding */ valueOrEmpty)
/* harmony export */ });
function queryString(query) {
  if (!query) {
    return null;
  }

  return query.split('?')[1].split('&').map(a => a.split('=')).reduce((a, c) => {
    a[c[0]] = c[1];
    return a;
  }, {});
}
/**
 * Calculate number of days passing between two dates
 * @param {Date} a Starting date
 * @param {Date} b Ending date
 * @returns {number} Number of days
 */


function dateDiff(a, b) {
  if (a.getFullYear() == b.getFullYear() && a.getMonth() == b.getMonth() && a.getDate() == b.getDate()) {
    return 0;
  } else {
    return b - a > 0 ? Math.ceil((b - a) / 86400000) : Math.floor((b - a) / 86400000);
  }
}

function dateDiffToDays(days) {
  if (days == 0) {
    return 'Today';
  } else {
    if (days <= 0) {
      return `In ${-days} day${days == -1 ? '' : 's'}`;
    } else {
      return `${days} day${days == 1 ? '' : 's'} ago`;
    }
  }
}
/**
 * Is the date in the last day of a month
 * @param {Date} date
 * @returns {boolean}
 */


function isLastDay(date) {
  const nextDay = new Date(date);
  nextDay.setDate(nextDay.getDate() + 1);
  return date.getMonth() != nextDay.getMonth();
}
/**
 * Is the date in the last week of a month
 * @param {Date} date
 * @returns {boolean}
 */


function isLastWeek(date) {
  const nextWeek = new Date(date);
  nextWeek.setDate(nextWeek.getDate() + 7);
  return date.getMonth() != nextWeek.getMonth();
}

function formatDate(date) {
  const asString = date.toLocaleDateString('en-US', {
    month: 'short',
    year: 'numeric'
  });
  return `${date.getDate()} ${asString}`;
}

function formatTime(date) {
  return date.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: 'numeric',
    // hour12: false,
    hourCycle: 'h23'
  });
}

function formatLocaleDate(date) {
  const day = date.getDate();
  const month = ['януари', 'февруари', 'март', 'април', 'май', 'юни', 'юли', 'август', 'септември', 'октомври', 'ноември', 'декември'][date.getMonth()];
  return `${day} ${month}`;
}

function formatLocaleWeekday(day, getAdj) {
  const weekday = ['неделя', 'понеделник', 'вторник', 'сряда', 'четвъртък', 'петък', 'събота'][day];

  if (getAdj) {
    return [weekday, ['всяка', 'всеки', 'всеки', 'всяка', 'всеки', 'всеки', 'всяка'][day]];
  }

  return weekday;
}
/**
 * Get a new date offset by the specified number of days
 * @param {Date} date Base date
 * @param {number} days How many days to offset
 * @returns {Date}
 */


function getOffsetByDays(date, days) {
  const result = new Date(date);
  result.setUTCDate(result.getUTCDate() + days);
  return result;
}
/**
 * Offset the given date in place by the specified number of days
 * @param {Date} date Base date
 * @param {number} days How many days to offset
 */

function offsetByDays(date, days) {
  date.setUTCDate(date.getUTCDate() + days);
}
/**
 * Create date index as string
 * @param {Date|string} date Base date
 * @returns {string}
 */

function getDateIndex(date) {
  if (typeof date == 'string') {
    date = new Date(date);
  }

  return date.toISOString().slice(0, 10);
}

function prettyJSON(obj) {
  return JSON.stringify(obj, null, 2).replace(/ /gmi, '&nbsp;').replace(/\n/gmi, '<br>');
}

function getMonday(date) {
  const monday = new Date(`${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()} 12:00:00`);
  monday.setDate(monday.getDate() - (monday.getDay() + 6) % 7);
  return monday;
}

function getSunday(date) {
  const sunday = new Date(`${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()} 23:59:59`);
  sunday.setDate(sunday.getDate() + (7 - sunday.getDay()) % 7);
  return sunday;
}

const monthName = {
  1: 'January',
  2: 'February',
  3: 'March',
  4: 'April',
  5: 'May',
  6: 'June',
  7: 'July',
  8: 'August',
  9: 'September',
  10: 'October',
  11: 'November',
  12: 'December'
};
const localeMonthName = {
  1: 'януари',
  2: 'февруари',
  3: 'март',
  4: 'април',
  5: 'май',
  6: 'юни',
  7: 'юли',
  8: 'август',
  9: 'септември',
  10: 'октомври',
  11: 'ноември',
  12: 'декември'
};

function toAssocArray(p, c, i, a) {
  p[c.Id] = c;
  return p;
}

function toCustomAssocArray(indexName, overwrite = false) {
  return (p, c, i, a) => {
    if (p[c[indexName]] !== undefined && overwrite == false) {
      if (Array.isArray(p[c[indexName]])) {
        p[c[indexName]].push(c);
      } else {
        p[c[indexName]] = [p[c[indexName]], c];
      }
    } else {
      p[c[indexName]] = c;
    }

    return p;
  };
}
/**
 * @param {Array<SUPayment>} data 
 * @returns {Array<PaymentViewModel>}
 */

function paymentsToMatrix(data) {
  const template = ['Id', 'PaymentNumber', 'ModuleNameEn', 'PaymentPackagesAsString', 'PaidForUserName', 'Price', 'EducationalForm', 'PaymentDateTime'];
  const parsed = data.map(e => {
    e.EducationalForm = e.EducationalForm == 1 ? 'online' : 'onsite';
    const entry = [];

    for (let prop of template) {
      if (prop === 'PaymentDateTime') {
        entry.push(new Date(e[prop]));
      } else {
        entry.push(e[prop]);
      }
    }

    return entry;
  });
  return [template, ...parsed];
}

function uuid() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    let r = Math.random() * 16 | 0,
        v = c == 'x' ? r : r & 0x3 | 0x8;
    return v.toString(16);
  });
}
function normalizeDateTime(datetime) {
  if (!datetime) {
    return '';
  } else if (datetime.toString().includes('Date(')) {
    const match = /Date\((.+)\)/.exec(datetime);

    if (match !== null) {
      const d = new Date(Number(match[1]));
      return `${('0000' + d.getFullYear()).slice(-4)}-${pt(d.getMonth() + 1)}-${pt(d.getDate())}T${pt(d.getHours())}:${pt(d.getMinutes())}`;
    } else {
      return datetime;
    }
  } else {
    return datetime;
  }
}

function pt(s) {
  return `0${s}`.slice(-2);
}

function htmlToText(html) {
  const div = document.createElement('div');
  div.innerHTML = html;
  return div.textContent;
}

function instanceMetaFromHref(href) {
  const instanceMeta = queryString(href);

  instanceMeta.InstanceRefType = (() => {
    switch (instanceMeta.type) {
      case 'course':
        return 'main';

      case 'fast-track':
        return 'open';

      case 'general-course-instance':
        return 'general';
    }
  })();

  return instanceMeta;
}
function hasValue(value) {
  return value !== null && value !== undefined && value !== '';
}
function valueOrEmpty(value, alt = '') {
  if (value === null || value === undefined || value === '') {
    return alt;
  } else {
    return value;
  }
}
function sumArrayMax(arr) {
  if (arr[0].length == 0 && arr[1].length == 0) {
    return null;
  }

  let result = 0;

  if (arr[0].length > 0) {
    result += Math.max(...arr[0]);
  }

  if (arr[1].length > 0) {
    result += Math.max(...arr[1]);
  }

  return result;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  queryString,
  dateDiff,
  dateDiffToDays,
  isLastDay,
  isLastWeek,
  formatDate,
  formatTime,
  formatLocaleDate,
  formatLocaleWeekday,
  prettyJSON,
  getMonday,
  getSunday,
  monthName,
  localeMonthName,
  toAssocArray,
  paymentsToMatrix,
  htmlToText
});


/***/ }),

/***/ "./src/util/router.js":
/*!****************************!*\
  !*** ./src/util/router.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Link": () => (/* binding */ Link),
/* harmony export */   "back": () => (/* binding */ back),
/* harmony export */   "checkActiveNav": () => (/* binding */ checkActiveNav),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "redirect": () => (/* binding */ redirect)
/* harmony export */ });
/* harmony import */ var _parse__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parse */ "./src/util/parse.js");

function Link({
  href,
  to,
  nav,
  partial,
  req,
  children,
  ...props
}) {
  try {
    const element = document.createElement('a');

    if (href !== undefined) {
      element.setAttribute('href', href);
      element.addEventListener('click', e => handler(e, element));
    }

    for (let prop of Object.keys(props)) {
      element[prop] = props[prop];
    }

    if (nav) {
      element.classList.add('ses-nav');
      const hrefTokens = _parse__WEBPACK_IMPORTED_MODULE_0__["default"].queryString(element.href);

      const matcher = nav => matchRoute(hrefTokens, nav);

      element.checkActiveNav = () => {
        if (window.location.search.split('?')[1] === element.href.split('?')[1]) {
          return element.classList.add('active');
        } else if (partial) {
          if (activeNav.some(matcher)) {
            if (req === undefined) {
              return element.classList.add('active');
            } else if (activeNav.some(nav => matchRoute(req, nav))) {
              return element.classList.add('active');
            }
          }
        }

        element.classList.remove('active');
      };

      element.checkActiveNav();
    }

    appendAll(children, element);
    return element;
  } catch (err) {
    console.error(err.message);
  }

  function handler(e, element) {
    e.preventDefault();
    const title = document.title;
    window.history.pushState({}, title, href);

    if (to !== undefined) {
      if (nav) {
        checkActiveNav();
      }

      to();
    } else {
      trigger();
    }
  }

  function appendAll(children, element) {
    for (let child of children) {
      if (Array.isArray(child)) {
        appendAll(child, element);
      } else if (typeof child === 'string' || typeof child === 'number') {
        element.appendChild(document.createTextNode(child));
      } else {
        element.appendChild(child);
      }
    }
  }
}
function redirect(href) {
  const title = document.title;
  window.history.pushState({}, title, href);
  trigger();
}
function back() {
  window.history.back();
}
function checkActiveNav() {
  document.querySelectorAll('.ses-nav').forEach(e => e.checkActiveNav());
}

function link(callback, title) {
  return function (element) {
    element.addEventListener('click', e => {
      e.preventDefault();
      title = title || document.title;
      window.history.pushState({}, title, e.target.href);
      callback(e);
    });
  };
}

window.onpopstate = function (e) {
  try {
    trigger();
  } catch (e) {
    console.error('Routing handler error:');
    console.error(e.message);
  }
}; // must have a static instance available - starting with top level on first call to register, replaced by active route upon load/navigation
// subsequent calls to register add the routes to the active router

/**
 * @typedef {Object} Route
 * @property {{name: string}} match - Name of query parameter and its value
 * @property {Function} handler - Callback to be executed on match. Expected to render content
 * @property {*=} context - Optional object that will be passed to handler
 * @property {Route[]=} routes - Nested routes
 */

/** @type {number} - Debug counter */

/** @type {Route[]} */


const routes = [];
/** @type {Route} */

let activeRoute = null;
let activeNav = [];
/**
 * Add nested routes to currently active route. If first call, top level routes are defined
 * @param {Route[]} options - List of routes
 * @param {*=} context - Optional object that will be passed to handlers
 */

function register(options, context) {
  let currentRoutes = routes;

  if (activeRoute !== null) {
    activeRoute.routes = activeRoute.routes || [];
    currentRoutes = activeRoute.routes;
  }

  const newRoutes = [];

  for (let route of options) {
    route = Object.assign(route, {
      context
    });
    const routeId = currentRoutes.reduce((p, c, i) => matchRoute(route.match, c.match) ? i : p, undefined);

    if (routeId !== undefined) {
      currentRoutes[routeId] = route;
    } else {
      newRoutes.push(route);
    }
  }

  newRoutes.forEach(r => currentRoutes.push(r));
  trigger(currentRoutes);
}
/**
 * Run a check against the routing list and execute matching handlers
 * @param {Route[]=} currentRoutes - Currently active routing list
 */


function trigger(currentRoutes) {
  if (currentRoutes === undefined || currentRoutes === routes) {
    currentRoutes = routes;
    activeNav = [];
  }
  /** @type {Object.<string, string>?} */


  const query = _parse__WEBPACK_IMPORTED_MODULE_0__["default"].queryString(document.location.search);

  for (let route of currentRoutes) {
    if (matchRoute(query, route.match)) {
      activeRoute = route;
      activeNav.push(activeRoute.match);
      checkActiveNav();
      return route.handler(query, route.context);
    }
  }
}
/**
 * Check if a given query object matches a given route pattern
 * @param {Object.<string, string>?} query - Query parameters
 * @param {{name: string}} match - Parameter name and value that must match
 * @returns {boolean}
 */


function matchRoute(query, match) {
  if (match === query) {
    return true;
  } else if (query) {
    if (typeof match === 'string' && query.hasOwnProperty(match)) {
      return true;
    } else {
      for (let name in match) {
        if (query[name] === match[name]) {
          return true;
        }
      }
    }
  } // No match


  return false;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  link,
  register
});

/***/ }),

/***/ "./src/util/template.js":
/*!******************************!*\
  !*** ./src/util/template.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Alert": () => (/* binding */ Alert),
/* harmony export */   "Autocomplete": () => (/* binding */ Autocomplete),
/* harmony export */   "Container": () => (/* binding */ Container),
/* harmony export */   "DownloadProgressBar": () => (/* binding */ DownloadProgressBar),
/* harmony export */   "Loading": () => (/* binding */ Loading),
/* harmony export */   "No": () => (/* binding */ No),
/* harmony export */   "Question": () => (/* binding */ Question),
/* harmony export */   "Remote": () => (/* binding */ Remote),
/* harmony export */   "Spinner": () => (/* binding */ Spinner),
/* harmony export */   "Yes": () => (/* binding */ Yes),
/* harmony export */   "applyBeginRequest": () => (/* binding */ applyBeginRequest),
/* harmony export */   "applyRequestError": () => (/* binding */ applyRequestError),
/* harmony export */   "applyRequestSuccess": () => (/* binding */ applyRequestSuccess),
/* harmony export */   "createCheckbox": () => (/* binding */ createCheckbox),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "element": () => (/* binding */ element),
/* harmony export */   "getEditorDecoration": () => (/* binding */ getEditorDecoration),
/* harmony export */   "popupTable": () => (/* binding */ popupTable),
/* harmony export */   "replaceContents": () => (/* binding */ replaceContents),
/* harmony export */   "swap": () => (/* binding */ swap),
/* harmony export */   "table": () => (/* binding */ table)
/* harmony export */ });
/* harmony import */ var _parse__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parse */ "./src/util/parse.js");
/* harmony import */ var _util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/jsx-render-mod/dom */ "./src/util/jsx-render-mod/dom.js");


/**
 * 
 * @param {*} type 
 * @param {*} content 
 * @param {*} attributes 
 * @param {{forceType: 'Text' | 'HTML'}} options 
 * @returns 
 */

function element(type, content, attributes, options = undefined) {
  const result = document.createElement(type);

  if (attributes) {
    for (let attr of Object.keys(attributes)) {
      result[attr] = attributes[attr];
    }
  }

  result.append = append.bind(result);

  result.appendTo = parent => {
    parent.append(result);
    return result;
  };

  if (content !== undefined && content !== null) {
    result.append(content, options);
  }

  return result;
}

function append(child, options = undefined) {
  if (typeof child === 'string' || typeof child === 'number') {
    if (options?.forceType != 'Text' && (options?.forceType === 'HTML' || child.toString().trim()[0] === '<')) {
      this.innerHTML = child;
    } else {
      child = document.createTextNode(child);
      this.appendChild(child);
    }
  } else if (Array.isArray(child)) {
    for (let node of child) {
      append.call(this, node);
    }
  } else {
    this.appendChild(child);
  }

  return this;
}

function replaceContents(node, newContents) {
  const cNode = node.cloneNode(false);
  append.call(cNode, newContents);

  try {
    node.parentNode.replaceChild(cNode, node);
  } catch (err) {
    console.info('Node has no parent or another problem occured');
  }

  return cNode;
}
function swap(oldNode, newNode) {
  oldNode.parentNode.replaceChild(newNode, oldNode);
  return newNode;
}
function Spinner({
  id
}) {
  const node = element('div', [element('div', null, {
    classList: 'sk-cube sk-cube1'
  }), element('div', null, {
    classList: 'sk-cube sk-cube2'
  }), element('div', null, {
    classList: 'sk-cube sk-cube3'
  }), element('div', null, {
    classList: 'sk-cube sk-cube4'
  }), element('div', null, {
    classList: 'sk-cube sk-cube5'
  }), element('div', null, {
    classList: 'sk-cube sk-cube6'
  }), element('div', null, {
    classList: 'sk-cube sk-cube7'
  }), element('div', null, {
    classList: 'sk-cube sk-cube8'
  }), element('div', null, {
    classList: 'sk-cube sk-cube9'
  })], {
    classList: 'sk-cube-grid'
  });

  if (id) {
    node.setAttribute('id', id);
  }

  return node;
}
function Loading({
  id,
  color = 'white'
}) {
  const node = element('div', [element('div', null, {
    classList: 'rect1'
  }), element('div', null, {
    classList: 'rect2'
  }), element('div', null, {
    classList: 'rect3'
  }), element('div', null, {
    classList: 'rect4'
  }), element('div', null, {
    classList: 'rect5'
  })], {
    classList: getClass()
  });

  if (id) {
    node.setAttribute('id', id);
  }

  return node;

  function getClass() {
    return `spinner ${color}`;
  }
}
function Remote({
  src,
  parse,
  component,
  color = 'white',
  onReady,
  onError
}) {
  const id = (0,_parse__WEBPACK_IMPORTED_MODULE_0__.uuid)();
  resolve();
  const loader = Loading({
    id,
    color
  });
  return loader;

  async function resolve() {
    let data = await (async () => {
      try {
        return (await (src instanceof Promise)) ? src : src();
      } catch (e) {
        if (onError) {
          onError(e, loader);
          throw e;
        }

        const retryBtn = element('button', [element('i', null, {
          className: 'glyphicon glyphicon-repeat'
        }), 'Retry'], {
          style: 'background-color: green'
        });
        retryBtn.addEventListener('click', () => {
          replaceSelf(Remote({
            src,
            parse,
            component,
            color
          }));
        });
        return element('div', [element('i', null, {
          className: 'glyphicon glyphicon-remove',
          style: 'color: red'
        }), e.message, retryBtn], {
          id: id
        });
      }
    })();

    if (parse) {
      data = parse(data);
    }

    replaceSelf(data);

    function replaceSelf(data) {
      //const loader = document.getElementById(id);
      const parent = loader.parentNode;

      if (component) {
        parent.insertBefore(component(data), loader);
      } else {
        append(data);
      } //await new Promise(resolve => setTimeout(10, resolve));
      //console.log(document.getElementById(id));


      loader.remove();

      if (onReady) {
        onReady();
      }

      function append(child) {
        if (typeof child === 'string' || typeof child === 'number') {
          if (child.toString().trim()[0] === '<') {
            const fragment = element('div', child);
            fragment.childNodes.forEach(n => parent.insertBefore(n.cloneNode(true), loader));
          } else {
            parent.insertBefore(document.createTextNode(child), loader);
          }
        } else if (Array.isArray(child)) {
          for (let node of child) {
            append(node);
          }
        } else {
          parent.insertBefore(child, loader);
        }
      }
    }
  }
}
function Yes() {
  const el = document.createElement('i');
  el.className = 'glyphicon glyphicon-ok';
  el.style.color = 'green';
  return el;
}
function No() {
  const el = document.createElement('i');
  el.className = 'glyphicon glyphicon-remove';
  el.style.color = 'red';
  return el;
}
function Question([title, answers]) {
  return element('div', [element('h2', title), element('ul', Object.entries(answers).map(([a, isCorrect]) => element('li', a, {
    classList: isCorrect ? 'correct-answer' : 'none'
  }, true)))], {
    classList: 'question-container'
  });
}
;
function Alert() {
  const el = document.createElement('i');
  el.className = 'glyphicon glyphicon-warning-sign';
  el.style.color = 'orange';
  return el;
}
function Container({
  children,
  className
}) {
  const section = element('section', children, {
    className: className ? 'event-container' : 'container'
  });
  const el = element('div', section, {
    className: className ? className : 'container administration-container ses-container'
  });
  return el;
}
function popupTable(data) {
  let html = `
        <style>
            table {
                border-collapse: collapse;
            }
            tr, td, th {
                border: 1px solid black;
                padding: 0.25em 0.5em;
            }
        </style>
        `;
  html += '<table><thead><tr>';

  for (let col of data[0]) {
    html += `<th>${col}</th>`;
  }

  html += '</tr></thead><tbody>';

  for (let row = 1; row < data.length; row++) {
    html += '<tr>';

    for (let col of data[row]) {
      html += `<td>${col}</td>`;
    }

    html += '</tr>';
  }

  html += '</tbody></table>';
  return html;
}
function getEditorDecoration(element) {
  function enable() {
    element.classList.add('enabled');
  }

  function disable() {
    element.classList.remove('enabled');
  }

  function working() {
    element.classList.remove('enabled');
    element.classList.add('working');
  }

  function updated() {
    element.classList.remove('working');
    element.classList.add('updated');
    setTimeout(() => element.classList.remove('updated'), 3000);
  }

  function failure() {
    element.classList.remove('working');
    element.classList.add('failed');
  }

  function _clear() {
    element.classList.remove('enabled');
    element.classList.remove('working');
    element.classList.remove('updated');
    element.classList.remove('failed');
  }

  return {
    enable,
    disable,
    working,
    updated,
    failure,
    _clear
  };
}
function applyBeginRequest(element) {
  element.childNodes.forEach(c => c.childNodes.forEach(n => n.disabled = true));
  element.classList.remove('enabled');
  element.classList.remove('failed');
  element.classList.add('working');
}
function applyRequestSuccess(element) {
  element.classList.remove('working');
  element.classList.add('updated');
  setTimeout(() => element.classList.remove('updated'), 3000);
}
function applyRequestError(refElement, errorContainer, fields) {
  refElement.childNodes.forEach(c => c.childNodes.forEach(n => n.disabled = false));
  refElement.classList.remove('working');
  refElement.classList.add('failed');
  console.warn(errorContainer);

  if (errorContainer.message !== undefined) {
    alert(errorContainer.message);
  } else {
    for (let error of Object.keys(errorContainer)) {
      if (error.length == 0) {
        alert(errorContainer[error].errors.join('\n'));
      } else {
        const field = fields[error];

        for (let message of errorContainer[error].errors) {
          field.appendChild(element('p', message));
        }
      }
    }
  }
}
function createCheckbox(name, data, text, onChange, defaultValue = false) {
  const id = 'ses-' + name;
  let value = readPrevInput();
  data[name] = value;
  let element = document.createElement('input');
  element.type = 'checkbox';
  element.id = id;
  element.name = name;
  let label = document.createElement('label');
  label.htmlFor = id;
  label.textContent = text;
  /*
  let element = <input type="checkbox" className="ses-check" id={id} name={name} />;
  let label = <label for={id}>{text}</label>;
  */

  element.checked = value;
  element.addEventListener('change', toggle);

  function readPrevInput() {
    let prevInput = document.getElementById(id);

    if (prevInput) {
      return prevInput.checked;
    } else {
      return defaultValue;
    }
  }

  function toggle(e) {
    value = e.target.checked;
    data[name] = value;
    redraw();
  }

  function redraw() {
    try {
      onChange();
    } catch (err) {
      console.log(err.message);
    }
  }

  const checkbox = {
    element,
    label
  };
  Object.defineProperty(checkbox, 'value', {
    get: () => value,
    set: newValue => {
      value = newValue;
      element.checked = value;
      data[name] = value;
      redraw();
    }
  });
  return checkbox;
}
function table(data, layout) {
  const thead = element('thead', element('tr', layout.map(h => element('th', h.label))));
  const tbody = element('tbody', data.map(r => element('tr', layout.map(h => element('td', r[h.name])))));
  const table = element('table', [thead, tbody]);
  table.thead = thead;
  table.tbody = tbody;
  return table;
}
function Autocomplete({
  values,
  current
}) {
  let autocomplete = element('div', [element('input', undefined, {
    className: 'ses-search-autocomplete-input'
  }), element('div', element('ul'), {
    className: 'ses-search-autocomplete-suggestions'
  })], {
    className: 'ses-search-autocomplete-container'
  });
  const suggestionsContainer = autocomplete.querySelector('.ses-search-autocomplete-suggestions');
  const input = autocomplete.querySelector('.ses-search-autocomplete-input');
  let selectedIndex = undefined;

  if (current != undefined) {
    input.value = current;
  }

  autocomplete.getValue = function () {
    return input.value;
  };

  function searchHandler(e) {
    const inputVal = e.currentTarget.value;
    let results = values;

    if (inputVal.length > 0) {
      results = values.filter(x => x.toLowerCase().indexOf(inputVal.toLowerCase()) > -1);
    }

    showSuggestions(results, inputVal);

    if (e.keyCode === 38 || e.keyCode === 40 || e.keyCode === 13) {
      scrollResults(e);
    }
  }

  function showSuggestions(results, inputVal) {
    let suggestions = suggestionsContainer.querySelector('ul');
    replaceContents(suggestions, '');
    suggestions = suggestionsContainer.querySelector('ul');
    ;

    if (results.length > 0) {
      for (let i = 0; i < results.length; i++) {
        let item = results[i];
        const match = item.match(new RegExp(inputVal, 'i'));
        item = item.replace(match[0], `<strong>${match[0]}</strong>`);
        let newLi = element('li', item, undefined, {
          forceType: "HTML"
        });
        suggestions.appendChild(newLi);
      }

      suggestions.classList.add('has-suggestions');
    } else {
      suggestions.classList.remove('has-suggestions');
    }
  }

  function useSuggestion(e) {
    input.value = e.target.textContent;
    input.focus();
    let suggestions = suggestionsContainer.querySelector('ul');
    replaceContents(suggestions, '');
    suggestions = suggestionsContainer.querySelector('ul');
    suggestions.classList.remove('has-suggestions');
  }

  function scrollResults(e) {
    let allSuggestions = [...suggestionsContainer.querySelectorAll('ul li')];
    let oldIndex = undefined;
    let indexChange = 1; // enter

    if (e.keyCode === 13) {
      input.value = allSuggestions[selectedIndex].textContent;
      selectedIndex = undefined;
      let suggestions = suggestionsContainer.querySelector('ul');
      suggestions.classList.remove('has-suggestions');
      return;
    }

    if (e.keyCode === 40) {
      // down arrow
      indexChange = 1;
    } else if (e.keyCode === 38) {
      // up arrow
      indexChange = -1;
    }

    if (selectedIndex == undefined) {
      selectedIndex = indexChange === 1 ? 0 : allSuggestions.length - 1;
    } else {
      oldIndex = selectedIndex;
      selectedIndex = (selectedIndex + indexChange + allSuggestions.length) % allSuggestions.length;
    }

    if (oldIndex !== undefined && oldIndex < allSuggestions.length) {
      allSuggestions[oldIndex].classList.remove('selected');
    }

    allSuggestions[selectedIndex].classList.add('selected');
  }

  input.addEventListener('keyup', searchHandler);
  suggestionsContainer.addEventListener('click', useSuggestion);
  return autocomplete;
}
/**
 * Creates a span element that represents a download progress bar
 * @param { {downloadFunction: (onProgress: import('./util.js').OnProgressFunction), returnFunction: function} } settings Contains the function that will download the resources, which will be called with onProgress
 * and the returnFunction which will be called with the results after the download finishes
 */

function DownloadProgressBar({
  downloadFunction,
  returnFunction
}) {
  const percent = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_1__["default"])("span", null, "0%");
  const bar = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_1__["default"])("span", {
    style: {
      padding: '0 0.5em',
      display: 'inline-block',
      width: '25%',
      background: 'linear-gradient(to right, #ffa000 0%, #eee 0)'
    }
  }, percent, " \u0421\u0432\u0430\u043B\u044F\u043D\u0435");
  downloadFunction(onProgress).then(data => {
    if (returnFunction) {
      returnFunction(data);
    }
  });
  return bar;

  function onProgress(completed, total, response, index) {
    const progress = Math.floor(completed / total * 100);
    percent.textContent = progress + '%';
    bar.style.background = `linear-gradient(to right, #ffa000 ${progress}%, #eee 0)`;
  }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  element
});

/***/ }),

/***/ "./src/util/util.js":
/*!**************************!*\
  !*** ./src/util/util.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "assertTemplate": () => (/* binding */ assertTemplate),
/* harmony export */   "createThrottledExecutor": () => (/* binding */ createThrottledExecutor),
/* harmony export */   "crossBrowserFileUpload": () => (/* binding */ crossBrowserFileUpload),
/* harmony export */   "distribute": () => (/* binding */ distribute),
/* harmony export */   "download": () => (/* binding */ download),
/* harmony export */   "escapeHTML": () => (/* binding */ escapeHTML),
/* harmony export */   "exportPaymentsToXlsx": () => (/* binding */ exportPaymentsToXlsx),
/* harmony export */   "exportToJson": () => (/* binding */ exportToJson),
/* harmony export */   "exportToXlsx": () => (/* binding */ exportToXlsx),
/* harmony export */   "getExcludedModuleInstances": () => (/* binding */ getExcludedModuleInstances),
/* harmony export */   "getExcludedModules": () => (/* binding */ getExcludedModules),
/* harmony export */   "getFundamentalLevelIds": () => (/* binding */ getFundamentalLevelIds),
/* harmony export */   "getLocale": () => (/* binding */ getLocale),
/* harmony export */   "getMime": () => (/* binding */ getMime),
/* harmony export */   "getProfessionInstanceIds": () => (/* binding */ getProfessionInstanceIds),
/* harmony export */   "getSubsite": () => (/* binding */ getSubsite),
/* harmony export */   "hasCPOAccess": () => (/* binding */ hasCPOAccess),
/* harmony export */   "iconAsset": () => (/* binding */ iconAsset),
/* harmony export */   "importFromXlsx": () => (/* binding */ importFromXlsx),
/* harmony export */   "importQuizFromXlsx": () => (/* binding */ importQuizFromXlsx),
/* harmony export */   "isAdmin": () => (/* binding */ isAdmin),
/* harmony export */   "openFile": () => (/* binding */ openFile),
/* harmony export */   "roundUpWithPrecision": () => (/* binding */ roundUpWithPrecision),
/* harmony export */   "serializeCalls": () => (/* binding */ serializeCalls),
/* harmony export */   "toLegacyXlsFile": () => (/* binding */ toLegacyXlsFile),
/* harmony export */   "toXlsxFile": () => (/* binding */ toXlsxFile),
/* harmony export */   "withProgress": () => (/* binding */ withProgress),
/* harmony export */   "zipFiles": () => (/* binding */ zipFiles)
/* harmony export */ });
/* harmony import */ var _parse__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parse */ "./src/util/parse.js");
/* globals xlsx, JSZip */

function importQuizFromXlsx(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = function (e) {
      const fileData = e.target.result;
      const wb = xlsx.read(fileData, {
        type: 'binary'
      });
      const firstSheet = wb.Sheets[wb.SheetNames[0]];
      const apiData = xlsx.utils.sheet_to_json(firstSheet, {
        header: 1
      }).slice(1) // remove first row
      .reduce((data, currentRow) => {
        if (currentRow.length !== 0) {
          const correctAnswerIndex = currentRow.pop();
          const question = currentRow[0];
          const allAnswers = currentRow.slice(1);
          const correctAnswer = currentRow[correctAnswerIndex];
          data[question] = allAnswers.reduce((answers, a) => {
            if (a != undefined && a.toString().trim() !== '') {
              answers[a] = a === correctAnswer;
            }

            return answers;
          }, {});
        }

        return data;
      }, {});
      resolve(apiData);
    };

    reader.readAsBinaryString(blob);
  });
}
function importFromXlsx(blob, useCellDates = false) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = function (e) {
      const file = e.target.result;

      try {
        const wb = xlsx.read(file, {
          type: 'binary',
          cellDates: useCellDates
        });
        const firstSheet = wb.Sheets[wb.SheetNames[0]];
        const data = xlsx.utils.sheet_to_json(firstSheet, {
          header: 1
        });
        resolve(data);
      } catch (err) {
        console.log('Error parsing XLSX file, make sure the library is loaded');
        reject(err);
      }
    };

    reader.onerror = function (e) {
      console.log('Error reading file');
      reject(e);
    };

    reader.readAsBinaryString(blob);
  });
}
function toXlsxFile(table, name = 'Output', ws_name) {
  if (ws_name === undefined) {
    ws_name = name.slice(0, 31);
  }

  const wb = xlsx.utils.book_new(),
        ws = xlsx.utils.aoa_to_sheet(table); // wb.Workbook = { Views: ['Window2'] };

  xlsx.utils.book_append_sheet(wb, ws, ws_name);
  const data = xlsx.write(wb, {
    type: 'array',
    bookType: 'xlsx'
  });
  const file = new File([data], name + '.xlsx', {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  });
  return file;
}
function toLegacyXlsFile(table, name = 'Output', ws_name) {
  if (ws_name === undefined) {
    ws_name = name.slice(0, 31);
  }

  const wb = xlsx.utils.book_new(),
        ws = xlsx.utils.aoa_to_sheet(table);
  wb.Workbook = {
    Views: ['Window2']
  };
  xlsx.utils.book_append_sheet(wb, ws, ws_name);
  const data = xlsx.write(wb, {
    type: 'array',
    bookType: 'biff8'
  });
  const file = new File([data], name + '.xls', {
    type: 'application/vnd.ms-excel'
  });
  return file;
}
function exportToXlsx(table, name = 'Output', ws_name) {
  const filename = `${name}.xlsx`;

  if (ws_name === undefined) {
    ws_name = name.slice(0, 31);
  } // Sheet name cannot contain: \ / ? * [ ]


  const sheetRegex = /[\[\]\\\/\*]/gi;

  if (sheetRegex.test(ws_name)) {
    ws_name = ws_name.replace(sheetRegex, '-');
  }

  const wb = xlsx.utils.book_new(),
        ws = xlsx.utils.aoa_to_sheet(table);
  xlsx.utils.book_append_sheet(wb, ws, ws_name);
  xlsx.writeFile(wb, filename);
}
function exportPaymentsToXlsx(data, year, month) {
  const filename = `Payments-${_parse__WEBPACK_IMPORTED_MODULE_0__["default"].monthName[month]}-${year}.xlsx`;
  const ws_name = `Payments ${_parse__WEBPACK_IMPORTED_MODULE_0__["default"].monthName[month]} ${year}`;
  const wb = xlsx.utils.book_new(),
        ws = xlsx.utils.aoa_to_sheet(data);
  xlsx.utils.book_append_sheet(wb, ws, ws_name);
  xlsx.writeFile(wb, filename);
}
function exportToJson(data, name = 'Output') {
  const blob = new Blob([data], {
    type: 'application/json'
  });

  if (window.navigator.msSaveOrOpenBlob) {
    window.navigator.msSaveBlob(blob, name + '.json');
  } else {
    var elem = window.document.createElement('a');
    elem.href = window.URL.createObjectURL(blob);
    elem.download = name + '.json';
    document.body.appendChild(elem);
    elem.click();
    document.body.removeChild(elem);
  }
}
/**
 * @param {{folder: string, files: File[]}[]} files 
 */

async function zipFiles(files) {
  const zip = new JSZip();

  for (let entry of files) {
    const current = zip.folder(entry.folder);
    current.file(entry.files.photo.name, await blobToBase64(entry.files.photo.file), {
      base64: true
    });
    current.file(entry.files.medical.name, await blobToBase64(entry.files.medical.file), {
      base64: true
    });
    current.file(entry.files.diploma.name, await blobToBase64(entry.files.diploma.file), {
      base64: true
    });
  }

  return zip.generateAsync({
    type: 'blob'
  });

  function blobToBase64(blob) {
    return new Promise(resolve => {
      const reader = new FileReader();

      reader.onload = function () {
        const dataUrl = reader.result;
        const base64 = dataUrl.split(',')[1];
        resolve(base64);
      };

      reader.readAsDataURL(blob);
    });
  }

  ;
}
const mimes = {
  'bmp': 'image/bmp',
  'gif': 'image/gif',
  'jpeg': 'image/jpeg',
  'jpg': 'image/jpeg',
  'png': 'image/png',
  'pdf': 'application/pdf',
  'tif': 'image/tiff',
  'tiff': 'image/tiff',
  'webp': 'image/webp',
  'zip': 'application/zip',
  '7z': 'application/x-7z-compressed',
  'tar': 'application/x-tar',
  'rar': 'application/vnd.rar'
};
function getMime(extension) {
  extension = extension.toLocaleLowerCase();
  return mimes[extension] || 'application/octet-stream';
}
async function openFile(file, name = 'output.txt') {
  try {
    var elem = window.document.createElement('a');
    elem.target = '_blank';
    elem.download = name;
    const href = window.URL.createObjectURL(file);
    elem.href = href;
    elem.click();
    setTimeout(() => URL.revokeObjectURL(href), 60000);
  } catch (err) {
    console.error(err);
  }
}
function download(blob, name = 'output.txt') {
  if (window.navigator.msSaveOrOpenBlob) {
    window.navigator.msSaveBlob(blob, name);
  } else {
    var elem = window.document.createElement('a');
    elem.target = '_blank';
    const href = window.URL.createObjectURL(blob);
    elem.href = href;
    elem.download = name;
    elem.click();
    setTimeout(() => URL.revokeObjectURL(href), 60000);
  }
}
async function crossBrowserFileUpload(apiCall, file) {
  if (!!window.chrome) {
    const fileUrl = URL.createObjectURL(file);
    const result = await apiCall({
      fileUrl,
      name: file.name
    });
    URL.revokeObjectURL(fileUrl);
    return result;
  } else {
    return await apiCall({
      file
    });
  }
}
function getSubsite() {
  switch (window.location.host.substr(0, 7)) {
    case 'digital':
      return 'digital';

    case 'creativ':
      return 'creative';

    case 'platfor':
      return 'platform';

    case 'ai.soft':
      return 'ai';

    case 'finance':
      return 'financeacademy';

    case 'dev.dig':
      return 'devdigital';

    case 'dev.sof':
      return 'devsoftuni';

    default:
      return 'programming';
  }
}
function hasCPOAccess() {
  return ['digital', 'creative', 'programming', 'devdigital', 'devsoftuni'].includes(getSubsite());
}
function isAdmin() {
  const e = document.querySelectorAll('a[href="/administration/navigation" i]');

  if (e.length > 0) {
    return true;
  } else {
    return false;
  }
}
function serializeCalls(fnArray, delay) {
  const callArray = [];

  if (delay !== undefined) {
    for (let i = 0; i < fnArray.length; i++) {
      const handler = (res, rej) => {
        setTimeout(async () => {
          try {
            const result = await fnArray[i]();
            res(result);
          } catch (err) {
            rej(err);
          }
        }, i * delay);
      };

      const pr = new Promise(handler);
      callArray.push(pr);
    }
  } else {
    for (let i = 0; i < fnArray.length; i++) {
      const handler = (res, rej) => {
        if (i > 0) {
          callArray[i - 1].finally(async () => {
            try {
              const result = await fnArray[i]();
              res(result);
            } catch (err) {
              rej(err);
            }
          });
        } else {
          fnArray[i]().then(res).catch(rej);
        }
      };

      const pr = new Promise(handler);
      callArray.push(pr);
    }
  }

  return callArray;
}
async function withProgress(callArray, onChange, delay = 10) {
  return new Promise((resolve, reject) => {
    // Failsave for empty callArray
    if (callArray.length == 0) {
      onChange(undefined, 0, 1, 1);
      resolve([]);
    }

    let resolved = 0;
    const response = [];
    callNext(0);

    function callNext(i) {
      if (i >= callArray.length) {
        return;
      } else {
        callArray[i].then(res => onResolve(res, i)).catch(onError);
        setTimeout(() => callNext(i + 1), delay);
      }
    }

    function onResolve(res, index) {
      resolved++;

      if (onChange) {
        onChange(res, index, resolved, callArray.length);
      }

      response[index] = res;

      if (resolved === callArray.length) {
        resolve(response);
      }
    }

    function onError(e) {
      reject(e);
    }
  });
}
/**
 * @typedef {(completed: number, total: number, response, index: number) => void} OnProgressFunction
 */

/**
 * @typedef {() => Promise} AsyncFunction
 */

/**
 * Initiate remote calls at intervals
 * @param {Array<AsyncFunction>} fnArray 
 * @param {OnProgressFunction} onProgress 
 * @param {number} [delay=10]
 * @returns 
 */

async function distribute(fnArray, onProgress, delay = 10) {
  return new Promise((resolve, reject) => {
    const total = fnArray.length;
    let completed = 0;
    let resolved = 0; // Failsave for empty fnArray

    if (total == 0) {
      if (typeof onProgress == 'function') {
        onProgress(undefined, 0, 1, 1);
      }

      resolve([]);
    }

    const calls = fnArray.map((fn, i) => {
      const call = {
        fn,
        sent: false,
        cancelled: false,
        response: undefined,
        timer: null
      };
      call.onCall = onCall.bind(call, i);
      call.cancel = onCancel.bind(call);
      call.timer = setTimeout(call.onCall, i * delay);
      return call;
    });
    calls.forEach((c, i) => c.next = calls[i + 1]);

    async function onCall(i) {
      if (this.sent == false) {
        clearTimeout(this.timer);
      }

      if (this.cancelled == false) {
        this.sent = true;

        try {
          const promise = this.fn();
          this.response = await promise;

          if (promise._cacheHit && this.next) {
            this.next.onCall();
          }

          resolved++;

          if (this.cancelled == false && resolved === total) {
            resolve(calls.map(c => c.response));
          }
        } catch (err) {
          onError(err);
        }
      }

      completed++;

      if (typeof onProgress == 'function') {
        onProgress(completed, total, this.response, i);
      }
    }

    function onCancel() {
      if (this.cancelled == false) {
        this.cancelled = true;

        if (this.sent == false) {
          clearTimeout(this.timer);
          this.onCall();
        }
      }
    }

    function onError(e) {
      calls.forEach(c => c.cancel());

      if (e instanceof Error) {
        e._responses = calls.map(c => c.response);
      }

      reject(e);
    }
  });
}
function assertTemplate(template, target, bottom = false) {
  if (template.Data !== undefined && template.Total !== undefined) {
    template = template.Data;
    target = target.Data;
  }

  if (Array.isArray(template)) {
    if (Array.isArray(target)) {
      if (bottom) {
        return;
      } else {
        assertTemplate(template[0], target[0], true);
      }
    } else {
      throw new TypeError('Target type mismatch');
    }
  } else if (typeof template === 'object') {
    if (typeof target === 'object') {
      const model = Object.keys(template);

      for (let prop of model) {
        if (target.hasOwnProperty(prop) === false) {
          throw new TypeError('Missing property on target: ' + prop);
        }
      }
    } else {
      throw new TypeError('Target type mismatch');
    }
  } else if (typeof template !== typeof target) {
    throw new TypeError('Target type mismatch');
  } else {
    return true;
  }
}
function getLocale() {
  return 'bg';
}
function createThrottledExecutor(callback, delay) {
  let timer = null;
  return function (...params) {
    clear();
    timer = setTimeout(() => {
      clear();
      callback(...params);
    }, delay);
  };

  function clear() {
    if (timer !== null) {
      clearTimeout(timer);
    }
  }
}
function iconAsset(name) {
  return browser.runtime.getURL(`icons/${name}.png`);
}
function escapeHTML(str) {
  return str.replace(/[&<>]/g, tag => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;'
  })[tag]);
}
;
function getFundamentalLevelIds(appname) {
  return {
    'programming': [19, 44, 57, 70, 106],
    'digital': [6, 7, 8, 23, 24, 25, 27, 33, 35, 40],
    'creative': [23, 24, 42, 52]
  }[appname];
}
function getProfessionInstanceIds(appname) {
  return {
    // Commented are for QA
    'programming': [1007, 1009, 1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1020, 1022, 1023, 1024, 1025, 1026, // 1028,
    1029, 1030, 1031, 1032, 1033, 1034, 1035, 1036, 1037, 1038, 1039, 1040, 1041, 1042, 1043, 1044, 1045, 1046, 1047, 1048, 1049, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1062, 1063, 1064, 1065, 1066, // 1067,
    // 1068,
    // 1069,
    1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078],
    'digital': [1, 3, 4, 5, 6, 7, 8, 9],
    'creative': [1, 3, 4, 5],
    'devdigital': [1, 3, 4, 5, 6, 7, 8, 9],
    'ai': []
  }[appname];
}
function getExcludedModules(appname) {
  return {
    'programming': [2]
  }[appname];
}
function getExcludedModuleInstances(appname) {
  return {
    'digital': [5, 50],
    'creative': [1, 14, 28, 46],
    'devdigital': [5, 50]
  }[appname];
}
/**
 * @description Rounds up a number up to specified number of decimal places using a specified number of decimal places as precision.
 * This allows correct rounding of problematic floating point numbers like "55.00000000000001" or "0.460000000000001"
 * @param {Number} number The number to round up
 * @param {Number} decimalPlacesToRoundTo The number of decimal places to round to
 * @param {Number} decimalPlacesPrecision The number of decimal places that should be considered for the rounding. Should be larger than decimalPlacesToRoundTo
 * @returns The rounded number
 */

function roundUpWithPrecision(number, decimalPlacesToRoundTo, decimalPlacesPrecision) {
  if (decimalPlacesPrecision <= decimalPlacesToRoundTo) {
    throw new RangeError('decimalPlacesPrecision should be larger than decimalPlacesToRoundTo');
  }

  let precisionValue = 10 ** decimalPlacesPrecision;
  let roundingValue = 10 ** decimalPlacesToRoundTo;
  let roundingValueBigInt = BigInt(roundingValue);
  let precisionDifferenceValue = BigInt(precisionValue / roundingValue);
  let bigInt = BigInt(Math.trunc(number * precisionValue));
  let roundedPlacesNumberPart = bigInt / precisionDifferenceValue;
  let precisionDifferenceLeftover = bigInt % precisionDifferenceValue;
  roundedPlacesNumberPart += precisionDifferenceLeftover > 0 ? 1n : 0n;
  let numberPart = roundedPlacesNumberPart / roundingValueBigInt;
  let decimalPart = roundedPlacesNumberPart % roundingValueBigInt;
  let roundedNum = Number(`${numberPart}.${decimalPart.toString().padStart(decimalPlacesToRoundTo, '0')}`);
  return roundedNum;
}

/***/ }),

/***/ "./node_modules/json5/dist/index.min.js":
/*!**********************************************!*\
  !*** ./node_modules/json5/dist/index.min.js ***!
  \**********************************************/
/***/ (function(module) {

!function(u,D){ true?module.exports=D():0}(this,function(){"use strict";function u(u,D){return u(D={exports:{}},D.exports),D.exports}var D=u(function(u){var D=u.exports="undefined"!=typeof window&&window.Math==Math?window:"undefined"!=typeof self&&self.Math==Math?self:Function("return this")();"number"==typeof __g&&(__g=D)}),e=u(function(u){var D=u.exports={version:"2.6.5"};"number"==typeof __e&&(__e=D)}),t=(e.version,function(u){return"object"==typeof u?null!==u:"function"==typeof u}),r=function(u){if(!t(u))throw TypeError(u+" is not an object!");return u},F=function(u){try{return!!u()}catch(u){return!0}},n=!F(function(){return 7!=Object.defineProperty({},"a",{get:function(){return 7}}).a}),C=D.document,A=t(C)&&t(C.createElement),i=!n&&!F(function(){return 7!=Object.defineProperty((u="div",A?C.createElement(u):{}),"a",{get:function(){return 7}}).a;var u}),E=Object.defineProperty,o={f:n?Object.defineProperty:function(u,D,e){if(r(u),D=function(u,D){if(!t(u))return u;var e,r;if(D&&"function"==typeof(e=u.toString)&&!t(r=e.call(u)))return r;if("function"==typeof(e=u.valueOf)&&!t(r=e.call(u)))return r;if(!D&&"function"==typeof(e=u.toString)&&!t(r=e.call(u)))return r;throw TypeError("Can't convert object to primitive value")}(D,!0),r(e),i)try{return E(u,D,e)}catch(u){}if("get"in e||"set"in e)throw TypeError("Accessors not supported!");return"value"in e&&(u[D]=e.value),u}},a=n?function(u,D,e){return o.f(u,D,function(u,D){return{enumerable:!(1&u),configurable:!(2&u),writable:!(4&u),value:D}}(1,e))}:function(u,D,e){return u[D]=e,u},c={}.hasOwnProperty,B=function(u,D){return c.call(u,D)},s=0,f=Math.random(),l=u(function(u){var t=D["__core-js_shared__"]||(D["__core-js_shared__"]={});(u.exports=function(u,D){return t[u]||(t[u]=void 0!==D?D:{})})("versions",[]).push({version:e.version,mode:"global",copyright:"© 2019 Denis Pushkarev (zloirock.ru)"})})("native-function-to-string",Function.toString),d=u(function(u){var t,r="Symbol(".concat(void 0===(t="src")?"":t,")_",(++s+f).toString(36)),F=(""+l).split("toString");e.inspectSource=function(u){return l.call(u)},(u.exports=function(u,e,t,n){var C="function"==typeof t;C&&(B(t,"name")||a(t,"name",e)),u[e]!==t&&(C&&(B(t,r)||a(t,r,u[e]?""+u[e]:F.join(String(e)))),u===D?u[e]=t:n?u[e]?u[e]=t:a(u,e,t):(delete u[e],a(u,e,t)))})(Function.prototype,"toString",function(){return"function"==typeof this&&this[r]||l.call(this)})}),v=function(u,D,e){if(function(u){if("function"!=typeof u)throw TypeError(u+" is not a function!")}(u),void 0===D)return u;switch(e){case 1:return function(e){return u.call(D,e)};case 2:return function(e,t){return u.call(D,e,t)};case 3:return function(e,t,r){return u.call(D,e,t,r)}}return function(){return u.apply(D,arguments)}},p=function(u,t,r){var F,n,C,A,i=u&p.F,E=u&p.G,o=u&p.S,c=u&p.P,B=u&p.B,s=E?D:o?D[t]||(D[t]={}):(D[t]||{}).prototype,f=E?e:e[t]||(e[t]={}),l=f.prototype||(f.prototype={});for(F in E&&(r=t),r)C=((n=!i&&s&&void 0!==s[F])?s:r)[F],A=B&&n?v(C,D):c&&"function"==typeof C?v(Function.call,C):C,s&&d(s,F,C,u&p.U),f[F]!=C&&a(f,F,A),c&&l[F]!=C&&(l[F]=C)};D.core=e,p.F=1,p.G=2,p.S=4,p.P=8,p.B=16,p.W=32,p.U=64,p.R=128;var h,m=p,g=Math.ceil,y=Math.floor,w=function(u){return isNaN(u=+u)?0:(u>0?y:g)(u)},S=(h=!1,function(u,D){var e,t,r=String(function(u){if(null==u)throw TypeError("Can't call method on  "+u);return u}(u)),F=w(D),n=r.length;return F<0||F>=n?h?"":void 0:(e=r.charCodeAt(F))<55296||e>56319||F+1===n||(t=r.charCodeAt(F+1))<56320||t>57343?h?r.charAt(F):e:h?r.slice(F,F+2):t-56320+(e-55296<<10)+65536});m(m.P,"String",{codePointAt:function(u){return S(this,u)}});e.String.codePointAt;var b=Math.max,x=Math.min,N=String.fromCharCode,P=String.fromCodePoint;m(m.S+m.F*(!!P&&1!=P.length),"String",{fromCodePoint:function(u){for(var D,e,t,r=arguments,F=[],n=arguments.length,C=0;n>C;){if(D=+r[C++],t=1114111,((e=w(e=D))<0?b(e+t,0):x(e,t))!==D)throw RangeError(D+" is not a valid code point");F.push(D<65536?N(D):N(55296+((D-=65536)>>10),D%1024+56320))}return F.join("")}});e.String.fromCodePoint;var _,I,O,j,V,J,M,k,L,T,z,H,$,R,G={Space_Separator:/[\u1680\u2000-\u200A\u202F\u205F\u3000]/,ID_Start:/[\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0559\u0561-\u0587\u05D0-\u05EA\u05F0-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u0860-\u086A\u08A0-\u08B4\u08B6-\u08BD\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u09FC\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C60\u0C61\u0C80\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D05-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D54-\u0D56\u0D5F-\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E87\u0E88\u0E8A\u0E8D\u0E94-\u0E97\u0E99-\u0E9F\u0EA1-\u0EA3\u0EA5\u0EA7\u0EAA\u0EAB\u0EAD-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u170C\u170E-\u1711\u1720-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1877\u1880-\u1884\u1887-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4B\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1C80-\u1C88\u1CE9-\u1CEC\u1CEE-\u1CF1\u1CF5\u1CF6\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2160-\u2188\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312E\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FEA\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6EF\uA717-\uA71F\uA722-\uA788\uA78B-\uA7AE\uA7B0-\uA7B7\uA7F7-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA8FD\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uA9E0-\uA9E4\uA9E6-\uA9EF\uA9FA-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB65\uAB70-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDD40-\uDD74\uDE80-\uDE9C\uDEA0-\uDED0\uDF00-\uDF1F\uDF2D-\uDF4A\uDF50-\uDF75\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF\uDFD1-\uDFD5]|\uD801[\uDC00-\uDC9D\uDCB0-\uDCD3\uDCD8-\uDCFB\uDD00-\uDD27\uDD30-\uDD63\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC60-\uDC76\uDC80-\uDC9E\uDCE0-\uDCF2\uDCF4\uDCF5\uDD00-\uDD15\uDD20-\uDD39\uDD80-\uDDB7\uDDBE\uDDBF\uDE00\uDE10-\uDE13\uDE15-\uDE17\uDE19-\uDE33\uDE60-\uDE7C\uDE80-\uDE9C\uDEC0-\uDEC7\uDEC9-\uDEE4\uDF00-\uDF35\uDF40-\uDF55\uDF60-\uDF72\uDF80-\uDF91]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2]|\uD804[\uDC03-\uDC37\uDC83-\uDCAF\uDCD0-\uDCE8\uDD03-\uDD26\uDD50-\uDD72\uDD76\uDD83-\uDDB2\uDDC1-\uDDC4\uDDDA\uDDDC\uDE00-\uDE11\uDE13-\uDE2B\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEDE\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3D\uDF50\uDF5D-\uDF61]|\uD805[\uDC00-\uDC34\uDC47-\uDC4A\uDC80-\uDCAF\uDCC4\uDCC5\uDCC7\uDD80-\uDDAE\uDDD8-\uDDDB\uDE00-\uDE2F\uDE44\uDE80-\uDEAA\uDF00-\uDF19]|\uD806[\uDCA0-\uDCDF\uDCFF\uDE00\uDE0B-\uDE32\uDE3A\uDE50\uDE5C-\uDE83\uDE86-\uDE89\uDEC0-\uDEF8]|\uD807[\uDC00-\uDC08\uDC0A-\uDC2E\uDC40\uDC72-\uDC8F\uDD00-\uDD06\uDD08\uDD09\uDD0B-\uDD30\uDD46]|\uD808[\uDC00-\uDF99]|\uD809[\uDC00-\uDC6E\uDC80-\uDD43]|[\uD80C\uD81C-\uD820\uD840-\uD868\uD86A-\uD86C\uD86F-\uD872\uD874-\uD879][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2E]|\uD811[\uDC00-\uDE46]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDED0-\uDEED\uDF00-\uDF2F\uDF40-\uDF43\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDF00-\uDF44\uDF50\uDF93-\uDF9F\uDFE0\uDFE1]|\uD821[\uDC00-\uDFEC]|\uD822[\uDC00-\uDEF2]|\uD82C[\uDC00-\uDD1E\uDD70-\uDEFB]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB]|\uD83A[\uDC00-\uDCC4\uDD00-\uDD43]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD869[\uDC00-\uDED6\uDF00-\uDFFF]|\uD86D[\uDC00-\uDF34\uDF40-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEA1\uDEB0-\uDFFF]|\uD87A[\uDC00-\uDFE0]|\uD87E[\uDC00-\uDE1D]/,ID_Continue:/[\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0300-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u0483-\u0487\u048A-\u052F\u0531-\u0556\u0559\u0561-\u0587\u0591-\u05BD\u05BF\u05C1\u05C2\u05C4\u05C5\u05C7\u05D0-\u05EA\u05F0-\u05F2\u0610-\u061A\u0620-\u0669\u066E-\u06D3\u06D5-\u06DC\u06DF-\u06E8\u06EA-\u06FC\u06FF\u0710-\u074A\u074D-\u07B1\u07C0-\u07F5\u07FA\u0800-\u082D\u0840-\u085B\u0860-\u086A\u08A0-\u08B4\u08B6-\u08BD\u08D4-\u08E1\u08E3-\u0963\u0966-\u096F\u0971-\u0983\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BC-\u09C4\u09C7\u09C8\u09CB-\u09CE\u09D7\u09DC\u09DD\u09DF-\u09E3\u09E6-\u09F1\u09FC\u0A01-\u0A03\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A3C\u0A3E-\u0A42\u0A47\u0A48\u0A4B-\u0A4D\u0A51\u0A59-\u0A5C\u0A5E\u0A66-\u0A75\u0A81-\u0A83\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABC-\u0AC5\u0AC7-\u0AC9\u0ACB-\u0ACD\u0AD0\u0AE0-\u0AE3\u0AE6-\u0AEF\u0AF9-\u0AFF\u0B01-\u0B03\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3C-\u0B44\u0B47\u0B48\u0B4B-\u0B4D\u0B56\u0B57\u0B5C\u0B5D\u0B5F-\u0B63\u0B66-\u0B6F\u0B71\u0B82\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BBE-\u0BC2\u0BC6-\u0BC8\u0BCA-\u0BCD\u0BD0\u0BD7\u0BE6-\u0BEF\u0C00-\u0C03\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D-\u0C44\u0C46-\u0C48\u0C4A-\u0C4D\u0C55\u0C56\u0C58-\u0C5A\u0C60-\u0C63\u0C66-\u0C6F\u0C80-\u0C83\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBC-\u0CC4\u0CC6-\u0CC8\u0CCA-\u0CCD\u0CD5\u0CD6\u0CDE\u0CE0-\u0CE3\u0CE6-\u0CEF\u0CF1\u0CF2\u0D00-\u0D03\u0D05-\u0D0C\u0D0E-\u0D10\u0D12-\u0D44\u0D46-\u0D48\u0D4A-\u0D4E\u0D54-\u0D57\u0D5F-\u0D63\u0D66-\u0D6F\u0D7A-\u0D7F\u0D82\u0D83\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0DCA\u0DCF-\u0DD4\u0DD6\u0DD8-\u0DDF\u0DE6-\u0DEF\u0DF2\u0DF3\u0E01-\u0E3A\u0E40-\u0E4E\u0E50-\u0E59\u0E81\u0E82\u0E84\u0E87\u0E88\u0E8A\u0E8D\u0E94-\u0E97\u0E99-\u0E9F\u0EA1-\u0EA3\u0EA5\u0EA7\u0EAA\u0EAB\u0EAD-\u0EB9\u0EBB-\u0EBD\u0EC0-\u0EC4\u0EC6\u0EC8-\u0ECD\u0ED0-\u0ED9\u0EDC-\u0EDF\u0F00\u0F18\u0F19\u0F20-\u0F29\u0F35\u0F37\u0F39\u0F3E-\u0F47\u0F49-\u0F6C\u0F71-\u0F84\u0F86-\u0F97\u0F99-\u0FBC\u0FC6\u1000-\u1049\u1050-\u109D\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u135D-\u135F\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u170C\u170E-\u1714\u1720-\u1734\u1740-\u1753\u1760-\u176C\u176E-\u1770\u1772\u1773\u1780-\u17D3\u17D7\u17DC\u17DD\u17E0-\u17E9\u180B-\u180D\u1810-\u1819\u1820-\u1877\u1880-\u18AA\u18B0-\u18F5\u1900-\u191E\u1920-\u192B\u1930-\u193B\u1946-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u19D0-\u19D9\u1A00-\u1A1B\u1A20-\u1A5E\u1A60-\u1A7C\u1A7F-\u1A89\u1A90-\u1A99\u1AA7\u1AB0-\u1ABD\u1B00-\u1B4B\u1B50-\u1B59\u1B6B-\u1B73\u1B80-\u1BF3\u1C00-\u1C37\u1C40-\u1C49\u1C4D-\u1C7D\u1C80-\u1C88\u1CD0-\u1CD2\u1CD4-\u1CF9\u1D00-\u1DF9\u1DFB-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u203F\u2040\u2054\u2071\u207F\u2090-\u209C\u20D0-\u20DC\u20E1\u20E5-\u20F0\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2160-\u2188\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D7F-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2DE0-\u2DFF\u2E2F\u3005-\u3007\u3021-\u302F\u3031-\u3035\u3038-\u303C\u3041-\u3096\u3099\u309A\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312E\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FEA\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA62B\uA640-\uA66F\uA674-\uA67D\uA67F-\uA6F1\uA717-\uA71F\uA722-\uA788\uA78B-\uA7AE\uA7B0-\uA7B7\uA7F7-\uA827\uA840-\uA873\uA880-\uA8C5\uA8D0-\uA8D9\uA8E0-\uA8F7\uA8FB\uA8FD\uA900-\uA92D\uA930-\uA953\uA960-\uA97C\uA980-\uA9C0\uA9CF-\uA9D9\uA9E0-\uA9FE\uAA00-\uAA36\uAA40-\uAA4D\uAA50-\uAA59\uAA60-\uAA76\uAA7A-\uAAC2\uAADB-\uAADD\uAAE0-\uAAEF\uAAF2-\uAAF6\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB65\uAB70-\uABEA\uABEC\uABED\uABF0-\uABF9\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE00-\uFE0F\uFE20-\uFE2F\uFE33\uFE34\uFE4D-\uFE4F\uFE70-\uFE74\uFE76-\uFEFC\uFF10-\uFF19\uFF21-\uFF3A\uFF3F\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDD40-\uDD74\uDDFD\uDE80-\uDE9C\uDEA0-\uDED0\uDEE0\uDF00-\uDF1F\uDF2D-\uDF4A\uDF50-\uDF7A\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF\uDFD1-\uDFD5]|\uD801[\uDC00-\uDC9D\uDCA0-\uDCA9\uDCB0-\uDCD3\uDCD8-\uDCFB\uDD00-\uDD27\uDD30-\uDD63\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC60-\uDC76\uDC80-\uDC9E\uDCE0-\uDCF2\uDCF4\uDCF5\uDD00-\uDD15\uDD20-\uDD39\uDD80-\uDDB7\uDDBE\uDDBF\uDE00-\uDE03\uDE05\uDE06\uDE0C-\uDE13\uDE15-\uDE17\uDE19-\uDE33\uDE38-\uDE3A\uDE3F\uDE60-\uDE7C\uDE80-\uDE9C\uDEC0-\uDEC7\uDEC9-\uDEE6\uDF00-\uDF35\uDF40-\uDF55\uDF60-\uDF72\uDF80-\uDF91]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2]|\uD804[\uDC00-\uDC46\uDC66-\uDC6F\uDC7F-\uDCBA\uDCD0-\uDCE8\uDCF0-\uDCF9\uDD00-\uDD34\uDD36-\uDD3F\uDD50-\uDD73\uDD76\uDD80-\uDDC4\uDDCA-\uDDCC\uDDD0-\uDDDA\uDDDC\uDE00-\uDE11\uDE13-\uDE37\uDE3E\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEEA\uDEF0-\uDEF9\uDF00-\uDF03\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3C-\uDF44\uDF47\uDF48\uDF4B-\uDF4D\uDF50\uDF57\uDF5D-\uDF63\uDF66-\uDF6C\uDF70-\uDF74]|\uD805[\uDC00-\uDC4A\uDC50-\uDC59\uDC80-\uDCC5\uDCC7\uDCD0-\uDCD9\uDD80-\uDDB5\uDDB8-\uDDC0\uDDD8-\uDDDD\uDE00-\uDE40\uDE44\uDE50-\uDE59\uDE80-\uDEB7\uDEC0-\uDEC9\uDF00-\uDF19\uDF1D-\uDF2B\uDF30-\uDF39]|\uD806[\uDCA0-\uDCE9\uDCFF\uDE00-\uDE3E\uDE47\uDE50-\uDE83\uDE86-\uDE99\uDEC0-\uDEF8]|\uD807[\uDC00-\uDC08\uDC0A-\uDC36\uDC38-\uDC40\uDC50-\uDC59\uDC72-\uDC8F\uDC92-\uDCA7\uDCA9-\uDCB6\uDD00-\uDD06\uDD08\uDD09\uDD0B-\uDD36\uDD3A\uDD3C\uDD3D\uDD3F-\uDD47\uDD50-\uDD59]|\uD808[\uDC00-\uDF99]|\uD809[\uDC00-\uDC6E\uDC80-\uDD43]|[\uD80C\uD81C-\uD820\uD840-\uD868\uD86A-\uD86C\uD86F-\uD872\uD874-\uD879][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2E]|\uD811[\uDC00-\uDE46]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDE60-\uDE69\uDED0-\uDEED\uDEF0-\uDEF4\uDF00-\uDF36\uDF40-\uDF43\uDF50-\uDF59\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDF00-\uDF44\uDF50-\uDF7E\uDF8F-\uDF9F\uDFE0\uDFE1]|\uD821[\uDC00-\uDFEC]|\uD822[\uDC00-\uDEF2]|\uD82C[\uDC00-\uDD1E\uDD70-\uDEFB]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99\uDC9D\uDC9E]|\uD834[\uDD65-\uDD69\uDD6D-\uDD72\uDD7B-\uDD82\uDD85-\uDD8B\uDDAA-\uDDAD\uDE42-\uDE44]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB\uDFCE-\uDFFF]|\uD836[\uDE00-\uDE36\uDE3B-\uDE6C\uDE75\uDE84\uDE9B-\uDE9F\uDEA1-\uDEAF]|\uD838[\uDC00-\uDC06\uDC08-\uDC18\uDC1B-\uDC21\uDC23\uDC24\uDC26-\uDC2A]|\uD83A[\uDC00-\uDCC4\uDCD0-\uDCD6\uDD00-\uDD4A\uDD50-\uDD59]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD869[\uDC00-\uDED6\uDF00-\uDFFF]|\uD86D[\uDC00-\uDF34\uDF40-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEA1\uDEB0-\uDFFF]|\uD87A[\uDC00-\uDFE0]|\uD87E[\uDC00-\uDE1D]|\uDB40[\uDD00-\uDDEF]/},U={isSpaceSeparator:function(u){return"string"==typeof u&&G.Space_Separator.test(u)},isIdStartChar:function(u){return"string"==typeof u&&(u>="a"&&u<="z"||u>="A"&&u<="Z"||"$"===u||"_"===u||G.ID_Start.test(u))},isIdContinueChar:function(u){return"string"==typeof u&&(u>="a"&&u<="z"||u>="A"&&u<="Z"||u>="0"&&u<="9"||"$"===u||"_"===u||"‌"===u||"‍"===u||G.ID_Continue.test(u))},isDigit:function(u){return"string"==typeof u&&/[0-9]/.test(u)},isHexDigit:function(u){return"string"==typeof u&&/[0-9A-Fa-f]/.test(u)}};function Z(){for(T="default",z="",H=!1,$=1;;){R=q();var u=X[T]();if(u)return u}}function q(){if(_[j])return String.fromCodePoint(_.codePointAt(j))}function W(){var u=q();return"\n"===u?(V++,J=0):u?J+=u.length:J++,u&&(j+=u.length),u}var X={default:function(){switch(R){case"\t":case"\v":case"\f":case" ":case" ":case"\ufeff":case"\n":case"\r":case"\u2028":case"\u2029":return void W();case"/":return W(),void(T="comment");case void 0:return W(),K("eof")}if(!U.isSpaceSeparator(R))return X[I]();W()},comment:function(){switch(R){case"*":return W(),void(T="multiLineComment");case"/":return W(),void(T="singleLineComment")}throw tu(W())},multiLineComment:function(){switch(R){case"*":return W(),void(T="multiLineCommentAsterisk");case void 0:throw tu(W())}W()},multiLineCommentAsterisk:function(){switch(R){case"*":return void W();case"/":return W(),void(T="default");case void 0:throw tu(W())}W(),T="multiLineComment"},singleLineComment:function(){switch(R){case"\n":case"\r":case"\u2028":case"\u2029":return W(),void(T="default");case void 0:return W(),K("eof")}W()},value:function(){switch(R){case"{":case"[":return K("punctuator",W());case"n":return W(),Q("ull"),K("null",null);case"t":return W(),Q("rue"),K("boolean",!0);case"f":return W(),Q("alse"),K("boolean",!1);case"-":case"+":return"-"===W()&&($=-1),void(T="sign");case".":return z=W(),void(T="decimalPointLeading");case"0":return z=W(),void(T="zero");case"1":case"2":case"3":case"4":case"5":case"6":case"7":case"8":case"9":return z=W(),void(T="decimalInteger");case"I":return W(),Q("nfinity"),K("numeric",1/0);case"N":return W(),Q("aN"),K("numeric",NaN);case'"':case"'":return H='"'===W(),z="",void(T="string")}throw tu(W())},identifierNameStartEscape:function(){if("u"!==R)throw tu(W());W();var u=Y();switch(u){case"$":case"_":break;default:if(!U.isIdStartChar(u))throw Fu()}z+=u,T="identifierName"},identifierName:function(){switch(R){case"$":case"_":case"‌":case"‍":return void(z+=W());case"\\":return W(),void(T="identifierNameEscape")}if(!U.isIdContinueChar(R))return K("identifier",z);z+=W()},identifierNameEscape:function(){if("u"!==R)throw tu(W());W();var u=Y();switch(u){case"$":case"_":case"‌":case"‍":break;default:if(!U.isIdContinueChar(u))throw Fu()}z+=u,T="identifierName"},sign:function(){switch(R){case".":return z=W(),void(T="decimalPointLeading");case"0":return z=W(),void(T="zero");case"1":case"2":case"3":case"4":case"5":case"6":case"7":case"8":case"9":return z=W(),void(T="decimalInteger");case"I":return W(),Q("nfinity"),K("numeric",$*(1/0));case"N":return W(),Q("aN"),K("numeric",NaN)}throw tu(W())},zero:function(){switch(R){case".":return z+=W(),void(T="decimalPoint");case"e":case"E":return z+=W(),void(T="decimalExponent");case"x":case"X":return z+=W(),void(T="hexadecimal")}return K("numeric",0*$)},decimalInteger:function(){switch(R){case".":return z+=W(),void(T="decimalPoint");case"e":case"E":return z+=W(),void(T="decimalExponent")}if(!U.isDigit(R))return K("numeric",$*Number(z));z+=W()},decimalPointLeading:function(){if(U.isDigit(R))return z+=W(),void(T="decimalFraction");throw tu(W())},decimalPoint:function(){switch(R){case"e":case"E":return z+=W(),void(T="decimalExponent")}return U.isDigit(R)?(z+=W(),void(T="decimalFraction")):K("numeric",$*Number(z))},decimalFraction:function(){switch(R){case"e":case"E":return z+=W(),void(T="decimalExponent")}if(!U.isDigit(R))return K("numeric",$*Number(z));z+=W()},decimalExponent:function(){switch(R){case"+":case"-":return z+=W(),void(T="decimalExponentSign")}if(U.isDigit(R))return z+=W(),void(T="decimalExponentInteger");throw tu(W())},decimalExponentSign:function(){if(U.isDigit(R))return z+=W(),void(T="decimalExponentInteger");throw tu(W())},decimalExponentInteger:function(){if(!U.isDigit(R))return K("numeric",$*Number(z));z+=W()},hexadecimal:function(){if(U.isHexDigit(R))return z+=W(),void(T="hexadecimalInteger");throw tu(W())},hexadecimalInteger:function(){if(!U.isHexDigit(R))return K("numeric",$*Number(z));z+=W()},string:function(){switch(R){case"\\":return W(),void(z+=function(){switch(q()){case"b":return W(),"\b";case"f":return W(),"\f";case"n":return W(),"\n";case"r":return W(),"\r";case"t":return W(),"\t";case"v":return W(),"\v";case"0":if(W(),U.isDigit(q()))throw tu(W());return"\0";case"x":return W(),function(){var u="",D=q();if(!U.isHexDigit(D))throw tu(W());if(u+=W(),D=q(),!U.isHexDigit(D))throw tu(W());return u+=W(),String.fromCodePoint(parseInt(u,16))}();case"u":return W(),Y();case"\n":case"\u2028":case"\u2029":return W(),"";case"\r":return W(),"\n"===q()&&W(),"";case"1":case"2":case"3":case"4":case"5":case"6":case"7":case"8":case"9":case void 0:throw tu(W())}return W()}());case'"':return H?(W(),K("string",z)):void(z+=W());case"'":return H?void(z+=W()):(W(),K("string",z));case"\n":case"\r":throw tu(W());case"\u2028":case"\u2029":!function(u){console.warn("JSON5: '"+nu(u)+"' in strings is not valid ECMAScript; consider escaping")}(R);break;case void 0:throw tu(W())}z+=W()},start:function(){switch(R){case"{":case"[":return K("punctuator",W())}T="value"},beforePropertyName:function(){switch(R){case"$":case"_":return z=W(),void(T="identifierName");case"\\":return W(),void(T="identifierNameStartEscape");case"}":return K("punctuator",W());case'"':case"'":return H='"'===W(),void(T="string")}if(U.isIdStartChar(R))return z+=W(),void(T="identifierName");throw tu(W())},afterPropertyName:function(){if(":"===R)return K("punctuator",W());throw tu(W())},beforePropertyValue:function(){T="value"},afterPropertyValue:function(){switch(R){case",":case"}":return K("punctuator",W())}throw tu(W())},beforeArrayValue:function(){if("]"===R)return K("punctuator",W());T="value"},afterArrayValue:function(){switch(R){case",":case"]":return K("punctuator",W())}throw tu(W())},end:function(){throw tu(W())}};function K(u,D){return{type:u,value:D,line:V,column:J}}function Q(u){for(var D=0,e=u;D<e.length;D+=1){var t=e[D];if(q()!==t)throw tu(W());W()}}function Y(){for(var u="",D=4;D-- >0;){var e=q();if(!U.isHexDigit(e))throw tu(W());u+=W()}return String.fromCodePoint(parseInt(u,16))}var uu={start:function(){if("eof"===M.type)throw ru();Du()},beforePropertyName:function(){switch(M.type){case"identifier":case"string":return k=M.value,void(I="afterPropertyName");case"punctuator":return void eu();case"eof":throw ru()}},afterPropertyName:function(){if("eof"===M.type)throw ru();I="beforePropertyValue"},beforePropertyValue:function(){if("eof"===M.type)throw ru();Du()},beforeArrayValue:function(){if("eof"===M.type)throw ru();"punctuator"!==M.type||"]"!==M.value?Du():eu()},afterPropertyValue:function(){if("eof"===M.type)throw ru();switch(M.value){case",":return void(I="beforePropertyName");case"}":eu()}},afterArrayValue:function(){if("eof"===M.type)throw ru();switch(M.value){case",":return void(I="beforeArrayValue");case"]":eu()}},end:function(){}};function Du(){var u;switch(M.type){case"punctuator":switch(M.value){case"{":u={};break;case"[":u=[]}break;case"null":case"boolean":case"numeric":case"string":u=M.value}if(void 0===L)L=u;else{var D=O[O.length-1];Array.isArray(D)?D.push(u):D[k]=u}if(null!==u&&"object"==typeof u)O.push(u),I=Array.isArray(u)?"beforeArrayValue":"beforePropertyName";else{var e=O[O.length-1];I=null==e?"end":Array.isArray(e)?"afterArrayValue":"afterPropertyValue"}}function eu(){O.pop();var u=O[O.length-1];I=null==u?"end":Array.isArray(u)?"afterArrayValue":"afterPropertyValue"}function tu(u){return Cu(void 0===u?"JSON5: invalid end of input at "+V+":"+J:"JSON5: invalid character '"+nu(u)+"' at "+V+":"+J)}function ru(){return Cu("JSON5: invalid end of input at "+V+":"+J)}function Fu(){return Cu("JSON5: invalid identifier character at "+V+":"+(J-=5))}function nu(u){var D={"'":"\\'",'"':'\\"',"\\":"\\\\","\b":"\\b","\f":"\\f","\n":"\\n","\r":"\\r","\t":"\\t","\v":"\\v","\0":"\\0","\u2028":"\\u2028","\u2029":"\\u2029"};if(D[u])return D[u];if(u<" "){var e=u.charCodeAt(0).toString(16);return"\\x"+("00"+e).substring(e.length)}return u}function Cu(u){var D=new SyntaxError(u);return D.lineNumber=V,D.columnNumber=J,D}return{parse:function(u,D){_=String(u),I="start",O=[],j=0,V=1,J=0,M=void 0,k=void 0,L=void 0;do{M=Z(),uu[I]()}while("eof"!==M.type);return"function"==typeof D?function u(D,e,t){var r=D[e];if(null!=r&&"object"==typeof r)for(var F in r){var n=u(r,F,t);void 0===n?delete r[F]:r[F]=n}return t.call(D,e,r)}({"":L},"",D):L},stringify:function(u,D,e){var t,r,F,n=[],C="",A="";if(null==D||"object"!=typeof D||Array.isArray(D)||(e=D.space,F=D.quote,D=D.replacer),"function"==typeof D)r=D;else if(Array.isArray(D)){t=[];for(var i=0,E=D;i<E.length;i+=1){var o=E[i],a=void 0;"string"==typeof o?a=o:("number"==typeof o||o instanceof String||o instanceof Number)&&(a=String(o)),void 0!==a&&t.indexOf(a)<0&&t.push(a)}}return e instanceof Number?e=Number(e):e instanceof String&&(e=String(e)),"number"==typeof e?e>0&&(e=Math.min(10,Math.floor(e)),A="          ".substr(0,e)):"string"==typeof e&&(A=e.substr(0,10)),c("",{"":u});function c(u,D){var e=D[u];switch(null!=e&&("function"==typeof e.toJSON5?e=e.toJSON5(u):"function"==typeof e.toJSON&&(e=e.toJSON(u))),r&&(e=r.call(D,u,e)),e instanceof Number?e=Number(e):e instanceof String?e=String(e):e instanceof Boolean&&(e=e.valueOf()),e){case null:return"null";case!0:return"true";case!1:return"false"}return"string"==typeof e?B(e):"number"==typeof e?String(e):"object"==typeof e?Array.isArray(e)?function(u){if(n.indexOf(u)>=0)throw TypeError("Converting circular structure to JSON5");n.push(u);var D=C;C+=A;for(var e,t=[],r=0;r<u.length;r++){var F=c(String(r),u);t.push(void 0!==F?F:"null")}if(0===t.length)e="[]";else if(""===A){var i=t.join(",");e="["+i+"]"}else{var E=",\n"+C,o=t.join(E);e="[\n"+C+o+",\n"+D+"]"}return n.pop(),C=D,e}(e):function(u){if(n.indexOf(u)>=0)throw TypeError("Converting circular structure to JSON5");n.push(u);var D=C;C+=A;for(var e,r,F=t||Object.keys(u),i=[],E=0,o=F;E<o.length;E+=1){var a=o[E],B=c(a,u);if(void 0!==B){var f=s(a)+":";""!==A&&(f+=" "),f+=B,i.push(f)}}if(0===i.length)e="{}";else if(""===A)r=i.join(","),e="{"+r+"}";else{var l=",\n"+C;r=i.join(l),e="{\n"+C+r+",\n"+D+"}"}return n.pop(),C=D,e}(e):void 0}function B(u){for(var D={"'":.1,'"':.2},e={"'":"\\'",'"':'\\"',"\\":"\\\\","\b":"\\b","\f":"\\f","\n":"\\n","\r":"\\r","\t":"\\t","\v":"\\v","\0":"\\0","\u2028":"\\u2028","\u2029":"\\u2029"},t="",r=0;r<u.length;r++){var n=u[r];switch(n){case"'":case'"':D[n]++,t+=n;continue;case"\0":if(U.isDigit(u[r+1])){t+="\\x00";continue}}if(e[n])t+=e[n];else if(n<" "){var C=n.charCodeAt(0).toString(16);t+="\\x"+("00"+C).substring(C.length)}else t+=n}var A=F||Object.keys(D).reduce(function(u,e){return D[u]<D[e]?u:e});return A+(t=t.replace(new RegExp(A,"g"),e[A]))+A}function s(u){if(0===u.length)return B(u);var D=String.fromCodePoint(u.codePointAt(0));if(!U.isIdStartChar(D))return B(u);for(var e=D.length;e<u.length;e++)if(!U.isIdContinueChar(String.fromCodePoint(u.codePointAt(e))))return B(u);return u}}}});


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
/*!************************************!*\
  !*** ./src/templates/templates.js ***!
  \************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/jsx-render-mod/dom */ "./src/util/jsx-render-mod/dom.js");
/* harmony import */ var _util_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/router */ "./src/util/router.js");
/* harmony import */ var _util_template__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../util/template */ "./src/util/template.js");
/* harmony import */ var _common_Emitter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../common/Emitter */ "./src/common/Emitter.js");
/* harmony import */ var _catalog__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./catalog */ "./src/templates/catalog.js");





document.title = 'Template Editor';
const container = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_2__.Container, null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("h1", {
  id: "titleHeading"
}, "\u0428\u0430\u0431\u043B\u043E\u043D\u0438 \u0437\u0430 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043D\u0430 \u0438\u043D\u0441\u0442\u0430\u043D\u0446\u0438\u044F"), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("section", {
  className: "bottom-buffer"
}, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  id: "pageContent"
})));
document.querySelectorAll('.content')[0].innerHTML = '';
document.querySelectorAll('.content')[0].appendChild(container);
_util_router__WEBPACK_IMPORTED_MODULE_1__["default"].register([{
  match: null,
  handler: _catalog__WEBPACK_IMPORTED_MODULE_4__.catalogPage
}, {
  match: 'new',
  handler: _catalog__WEBPACK_IMPORTED_MODULE_4__.createPage
}, {
  match: 'id',
  handler: _catalog__WEBPACK_IMPORTED_MODULE_4__.editPage
}], new _common_Emitter__WEBPACK_IMPORTED_MODULE_3__["default"]());
})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9kZXYvL2NvbnRlbnQtc2NyaXB0cy90ZW1wbGF0ZXMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7OztBQzlDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6R0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoSUE7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7OztBQ3BGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hCQTtBQUNBO0FBQ0E7QUFJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1REE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFQQTtBQVVBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWZBOztBQWtCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBZEE7QUFnQkE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFkQTtBQWdCQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQWRBO0FBaUJBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFKQTtBQU1BO0FBQ0E7QUFFQTtBQVVBO0FBTUE7O0FBT0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMQTtBQU9BOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBTEE7O0FBUUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFEQTs7QUFJQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTs7Ozs7Ozs7Ozs7Ozs7O0FDelJBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFEQTtBQUlBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQURBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQURBO0FBSUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBekJBO0FBNEJBO0FBRUE7O0FBRUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUdBO0FBQ0E7QUFFQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBO0FBT0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUMzR0E7QUFHQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFNQTtBQUNBOztBQUVBO0FBQ0E7QUFFQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSkE7QUFPQTtBQUNBOztBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOzs7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMQTtBQVFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBckJBOztBQXdCQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQUtBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7O0FBR0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBVEE7QUFXQTs7QUFFQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDM01BO0FBRUE7QUFDQTs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBTEE7QUFPQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBREE7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQURBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFUQTs7QUFXQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBRUE7QUFDQTtBQUNBO0FBREE7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFJQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQURBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7QUFHQTs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSkE7QUFPQTtBQUVBO0FBRUE7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBREE7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQURBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUVBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFJQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBSUE7QUFDQTtBQUdBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQURBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWxCQTtBQW9CQTs7Ozs7Ozs7Ozs7Ozs7OztBQ3BjQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBTUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQU1BO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRkE7QUFJQTs7Ozs7Ozs7Ozs7Ozs7O0FDM0NBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQURBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQURBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFEQTtBQUlBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFNQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBO0FBT0E7Ozs7Ozs7Ozs7Ozs7OztBQ2xGQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUZBO0FBT0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUpBO0FBTUE7Ozs7Ozs7Ozs7Ozs7OztBQzdGQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBUEE7QUFVQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFkQTtBQWlCQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFSQTtBQVdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBO0FBUUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTEE7QUFRQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMQTtBQVFBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFOQTtBQVFBOzs7Ozs7Ozs7Ozs7Ozs7O0FDdEdBO0FBR0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBOztBQVFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFyQkE7QUF1QkE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFLQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFBQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKQTtBQU1BOzs7Ozs7Ozs7Ozs7Ozs7QUNoRkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMQTs7QUFRQTtBQUNBO0FBQ0E7QUFDQTtBQURBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQURBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU5BO0FBUUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBREE7O0FBR0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFIQTtBQXZCQTtBQThCQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBSEE7QUF2QkE7QUErQkE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQUtBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU5BO0FBUUE7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqT0E7QUFHQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUpBO0FBT0E7QUFDQTtBQUNBO0FBRkE7QUFJQTs7Ozs7Ozs7Ozs7Ozs7OztBQ2xCQTtBQUdBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSkE7O0FBT0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU5BO0FBUUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXJCQTtBQXVCQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWZBO0FBaUJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFQQTtBQVNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDaklBO0FBR0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBOztBQVFBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBckJBO0FBdUJBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBUEE7QUFTQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFHQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFOQTtBQVFBOzs7Ozs7Ozs7Ozs7Ozs7QUNyR0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQURBO0FBR0E7Ozs7Ozs7Ozs7Ozs7OztBQ2pCQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7O0FBS0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQU1BO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQURBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBREE7QUFJQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBREE7QUFJQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFJQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFUQTtBQVdBOzs7Ozs7Ozs7Ozs7Ozs7O0FDdklBO0FBR0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBO0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBTUE7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWRBO0FBZ0JBO0FBQ0E7QUFuQkE7QUFzQkE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFNQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBRUE7QUFFQTtBQUVBO0FBQ0E7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFLQTs7Ozs7Ozs7Ozs7Ozs7O0FDMUlBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBO0FBUUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFsQkE7QUFvQkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBbEJBO0FBb0JBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBS0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTEE7QUFRQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBO0FBUUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU5BO0FBUUE7Ozs7Ozs7Ozs7Ozs7OztBQ3ZIQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7QUFFQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQU1BOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBO0FBUUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQURBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWJBO0FBZUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFHQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBYkE7QUFlQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTtBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBakJBO0FBbUJBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFqQkE7QUFtQkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFLQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFYQTtBQWFBOzs7Ozs7Ozs7Ozs7Ozs7QUN6UEE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBbEJBO0FBb0JBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBS0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUpBO0FBTUE7Ozs7Ozs7Ozs7Ozs7OztBQ3RFQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBTUE7QUFDQTs7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBNUJBO0FBOEJBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUE1QkE7QUE4QkE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQUtBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTkE7QUFRQTs7Ozs7Ozs7Ozs7Ozs7O0FDL0lBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTEE7QUFRQTtBQUNBOztBQUVBO0FBQ0E7QUFEQTtBQUdBOzs7Ozs7Ozs7Ozs7Ozs7QUNsQkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFFQTtBQUlBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBVEE7O0FBV0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVRBOztBQVdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQUtBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBTUE7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTEE7QUFPQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pIQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFFQTtBQUNBO0FBRUE7QUFLQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKQTtBQU1BOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUpBO0FBTUE7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSkE7QUFNQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQU5BO0FBU0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBTUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFNQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFJQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKQTtBQU9BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQUtBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKQTtBQU9BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQUtBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKQTtBQU9BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQUtBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBREE7QUFJQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQVlBO0FBRUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFOQTtBQVFBOztBQUNBO0FBQ0E7QUFEQTtBQUdBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFwQkE7QUFzQkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQVJBO0FBVUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUpBO0FBT0E7QUFDQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBTkE7QUFRQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFNQTtBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBR0E7QUFDQTs7QUFNQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFMQTtBQVdBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQU1BO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBS0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBVEE7QUFXQTtBQUNBO0FBZEE7QUFnQkE7O0FBRUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXZCQTtBQXlCQTs7Ozs7Ozs7Ozs7Ozs7O0FDamdCQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWkE7QUFjQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFaQTtBQWNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFJQTtBQUNBO0FBQ0E7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBRUE7O0FBR0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFNQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBRUE7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFNQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFQQTtBQVNBOzs7Ozs7Ozs7Ozs7Ozs7QUNoTEE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7OztBQ1pBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQWpDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQ0E7QUFJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU5BO0FBU0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQUE7QUFBQTtBQUlBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBRUE7QUFBQTtBQVFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBT0E7QUFFQTtBQUNBO0FBRUE7QUFBQTtBQUFBO0FBQ0E7QUFLQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUlBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFJQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSkE7QUFPQTtBQUFBO0FBQUE7QUFBQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDN05BO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25DQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUVBOztBQUVBO0FBQ0E7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFBQTtBQUFBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUFBO0FBQUE7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBU0E7QUFBQTtBQUFBO0FBTUE7QUFBQTtBQUFBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBR0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBRUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBR0E7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUVBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFJQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZJQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUtBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUVBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFJQTtBQUNBO0FBRUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBRUE7QUFDQTtBQUVBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFOQTtBQVNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFNQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBVEE7QUFXQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVRBO0FBV0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeExBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFFQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBTkE7QUFTQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFBQTtBQUFBO0FBSUE7QUFBQTtBQUNBO0FBQUE7QUFFQTtBQUFBO0FBQ0E7QUFBQTtBQUdBO0FBQUE7QUFJQTtBQUFBO0FBS0E7QUFBQTtBQUVBO0FBQUE7QUFPQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTUE7QUFFQTtBQUtBO0FBQUE7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7O0FBT0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7O0FBRUE7QUFDQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFHQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVBBO0FBVUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUVBO0FBRUE7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFHQTtBQUFBO0FBQUE7QUFBQTtBQVNBO0FBQUE7QUFBQTtBQUFBOztBQUtBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUlBO0FBQUE7QUFBQTtBQUNBO0FBRUE7QUFFQTtBQUFBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBQUE7QUFBQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUFBO0FBcUJBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFJQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDN1JBO0FBQ0E7QUFHQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBRUE7QUFFQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUtBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTtBQUVBOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUlBO0FBQ0E7QUFDQTtBQUZBO0FBSUE7QUFDQTtBQUNBO0FBRkE7QUFJQTtBQUNBO0FBQ0E7QUFGQTtBQUlBO0FBQ0E7QUFDQTtBQUZBO0FBSUE7QUFDQTtBQUNBO0FBRkE7QUFJQTtBQUNBO0FBQ0E7QUFGQTtBQUlBO0FBQ0E7QUFDQTtBQUZBO0FBSUE7QUFDQTtBQUNBO0FBRkE7QUFJQTtBQUNBO0FBQ0E7QUFGQTtBQUlBO0FBQ0E7QUFDQTtBQUZBO0FBSUE7QUFDQTtBQUNBO0FBRkE7QUFJQTtBQUNBO0FBQ0E7QUFGQTtBQUlBO0FBQ0E7QUFDQTtBQUZBO0FBSUE7QUFDQTtBQUNBO0FBRkE7QUF6REE7QUErREE7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUF2RUE7O0FBMEVBO0FBQ0E7O0FBS0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzNSQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUdBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUtBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQU9BO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQU1BO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFHQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFFQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBR0E7QUFFQTtBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBRUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBRUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUlBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3BIQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFHQTtBQUNBO0FBRUE7QUFBQTtBQUFBO0FBRUE7QUFDQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7O0FBR0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBRUE7QUFDQTtBQUFBO0FBQUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pDQTtBQUNBO0FBR0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVBBO0FBU0E7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xEQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKQTtBQU9BO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUVBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBZEE7QUFnQkE7QUFFQTs7O0FBQ0E7QUFFQTtBQUNBO0FBRkE7QUFLQTtBQUNBO0FBQ0E7QUFFQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqRkE7QUFJQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFJQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7QUMxakJBO0FBQ0E7QUFDQTtBQUNBOztBQUdBO0FBQUE7QUFBQTs7QUFDQTtBQUFBO0FBQUE7O0FBUEE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUE7QUFFQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWkE7QUFlQTtBQUNBO0FBREE7QUFJQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQURBO0FBR0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUlBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoSEE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBS0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFYQTtBQWFBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOzs7QUFDQTtBQUNBO0FBR0E7OztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwSEE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUdBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBTUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFFQTtBQUNBOztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBM0dBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFJQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUpBO0FBTUE7O0FBRUE7QUFDQTtBQUNBO0FBY0E7QUFDQTs7QUFFQTtBQUNBOztBQVNBO0FBQ0E7QUFTQTs7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVpBO0FBZ0JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWkE7O0FBZUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBVUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUdBO0FBQ0E7QUFDQTtBQUFBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUFBOztBQUNBO0FBQUE7O0FBQ0E7QUFBQTtBQUhBO0FBS0E7O0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBakJBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM3VUE7QUFHQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7OztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRkE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsTUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTs7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7O0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUVBOztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQUE7QUFFQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSkE7QUFNQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBR0E7QUFBQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7OztBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFOQTtBQVFBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBUEE7QUFVQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQURBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdGdCQTtBQUVBO0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBREE7QUFHQTtBQUNBO0FBQ0E7QUFBQTtBQURBO0FBSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBSUE7QUFDQTtBQUFBO0FBQUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFBQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFBQTtBQUFBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFBQTtBQUFBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTs7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQUE7QUFBQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUNBOztBQUNBO0FBQUE7QUFBQTs7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFiQTtBQWdCQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBaEJBO0FBa0JBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFDQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFHQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTEE7QUFPQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUhBO0FBS0E7QUFBQTtBQUdBO0FBQ0E7QUFDQTtBQU9BO0FBWUE7QUFwQkE7QUEyQkE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQW1CQTtBQXVDQTtBQUNBO0FBQ0E7QUFVQTtBQVVBO0FBTUE7QUFVQTtBQWxHQTtBQW9HQTtBQUVBO0FBQ0E7QUFDQTtBQURBO0FBS0E7QUFFQTtBQUNBO0FBQ0E7QUFJQTtBQU1BO0FBWEE7QUFnQkE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBOzs7Ozs7Ozs7O0FDdHJCQTs7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7OztBQ3ZCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7OztBQ1BBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7O0FDUEE7Ozs7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdBO0FBRUE7QUFFQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFPQTtBQUNBO0FBRUE7QUFFQTtBQUNBO0FBRkE7QUFLQTtBQUNBO0FBRkE7QUFLQTtBQUNBO0FBRkEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vbm9kZV9tb2R1bGVzL2F3ZXNvbWUtbm90aWZpY2F0aW9ucy9zcmMvY29uc3RhbnRzLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9ub2RlX21vZHVsZXMvYXdlc29tZS1ub3RpZmljYXRpb25zL3NyYy9lbGVtLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9ub2RlX21vZHVsZXMvYXdlc29tZS1ub3RpZmljYXRpb25zL3NyYy9pbmRleC5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vbm9kZV9tb2R1bGVzL2F3ZXNvbWUtbm90aWZpY2F0aW9ucy9zcmMvb3B0aW9ucy5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vbm9kZV9tb2R1bGVzL2F3ZXNvbWUtbm90aWZpY2F0aW9ucy9zcmMvcG9wdXAuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL25vZGVfbW9kdWxlcy9hd2Vzb21lLW5vdGlmaWNhdGlvbnMvc3JjL3RpbWVyLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9ub2RlX21vZHVsZXMvYXdlc29tZS1ub3RpZmljYXRpb25zL3NyYy90b2FzdC5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL2FwaS9hcGktaW5kZXguanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvY29tbW9uLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvYXBpL2NwZS9jcGUuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvY3BlL25hdmV0LmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvYXBpL2p1ZGdlL2FscGhhSnVkZ2UuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvbW9kdWxlLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvYXBpL3BheW1lbnRzLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvYXBpL3F1aXouanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvc3RvcmFnZS9hc3Nlc3NtZW50Q29uZmlnLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvYXBpL3N0b3JhZ2UvZ2VuZXJpYy5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL2FwaS9zdG9yYWdlL21vZHVsZXNEYXRhLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvYXBpL3N0b3JhZ2UvcGF5bWVudFN0YXRzLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvYXBpL3N0b3JhZ2UvdGVtcGxhdGVzLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvYXBpL3N0cmVhbS9zdHJlYW0uanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvc3VydmV5LmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvYXBpL3RyYWluaW5ncy9hc3Nlc3NtZW50LmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvYXBpL3RyYWluaW5ncy9ldmVudHMuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvdHJhaW5pbmdzL2V4YW1zLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvYXBpL3RyYWluaW5ncy9ncm91cHMuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvdHJhaW5pbmdzL2xlY3R1cmVzLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvYXBpL3RyYWluaW5ncy9zZW1pbmFycy5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL2FwaS90cmFpbmluZ3Mvc2tpbGxzLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvYXBpL3RyYWluaW5ncy90cmFpbmluZ3MuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvdXNlcnMuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvdXRpbC5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL2NvbW1vbi9FbWl0dGVyLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvY29tbW9uL01vZGFsLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvY29tbW9uL1Byb2dyZXNzQmFyLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvY291cnNlL2dlbmVyYWwvRGVzY3JpcHRpb24uanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9jb3Vyc2Uvc3RyaW5ncy5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL3RlbXBsYXRlcy9FZGl0b3IuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy90ZW1wbGF0ZXMvUHJldmlldy5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL3RlbXBsYXRlcy9UZW1wbGF0ZUxpc3QuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy90ZW1wbGF0ZXMvY2F0YWxvZy5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL3RlbXBsYXRlcy9kYXRhLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvdXRpbC9hcGktY29ubmVjdC5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL3V0aWwvYXBpLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvdXRpbC9jb250ZW50VHlwZXMuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy91dGlsL2RhdGEtY29ubmVjdC5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL3V0aWwvanN4LXJlbmRlci1tb2QvZG9tLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvdXRpbC9qc3gtcmVuZGVyLW1vZC91dGlscy5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL3V0aWwvcGFyc2UuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy91dGlsL3JvdXRlci5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL3V0aWwvdGVtcGxhdGUuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy91dGlsL3V0aWwuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL25vZGVfbW9kdWxlcy9qc29uNS9kaXN0L2luZGV4Lm1pbi5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvd2VicGFjay9ydW50aW1lL2NvbXBhdCBnZXQgZGVmYXVsdCBleHBvcnQiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS93ZWJwYWNrL3J1bnRpbWUvZGVmaW5lIHByb3BlcnR5IGdldHRlcnMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS93ZWJwYWNrL3J1bnRpbWUvaGFzT3duUHJvcGVydHkgc2hvcnRoYW5kIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvd2VicGFjay9ydW50aW1lL21ha2UgbmFtZXNwYWNlIG9iamVjdCIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL3RlbXBsYXRlcy90ZW1wbGF0ZXMuanMiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgbGliTmFtZSA9IFwiYXduXCJcbmNvbnN0IHByZWZpeCA9IHtcbiAgcG9wdXA6IGAke2xpYk5hbWV9LXBvcHVwYCxcbiAgdG9hc3Q6IGAke2xpYk5hbWV9LXRvYXN0YCxcbiAgYnRuOiBgJHtsaWJOYW1lfS1idG5gLFxuICBjb25maXJtOiBgJHtsaWJOYW1lfS1jb25maXJtYFxufVxuXG4vLyBDb25zdGFudHMgZm9yIHRvYXN0c1xuZXhwb3J0IGNvbnN0IHRDb25zdHMgPSB7XG4gIHByZWZpeDogcHJlZml4LnRvYXN0LFxuICBrbGFzczoge1xuICAgIGxhYmVsOiBgJHtwcmVmaXgudG9hc3R9LWxhYmVsYCxcbiAgICBjb250ZW50OiBgJHtwcmVmaXgudG9hc3R9LWNvbnRlbnRgLFxuICAgIGljb246IGAke3ByZWZpeC50b2FzdH0taWNvbmAsXG4gICAgcHJvZ3Jlc3NCYXI6IGAke3ByZWZpeC50b2FzdH0tcHJvZ3Jlc3MtYmFyYCxcbiAgICBwcm9ncmVzc0JhclBhdXNlOiBgJHtwcmVmaXgudG9hc3R9LXByb2dyZXNzLWJhci1wYXVzZWRgXG4gIH0sXG4gIGlkczoge1xuICAgIGNvbnRhaW5lcjogYCR7cHJlZml4LnRvYXN0fS1jb250YWluZXJgXG4gIH1cbn1cblxuLy8gQ29uc3RhbnRzIGZvciBwb3B1cHNcbmV4cG9ydCBjb25zdCBtQ29uc3RzID0ge1xuICBwcmVmaXg6IHByZWZpeC5wb3B1cCxcbiAga2xhc3M6IHtcbiAgICBidXR0b25zOiBgJHtsaWJOYW1lfS1idXR0b25zYCxcbiAgICBidXR0b246IHByZWZpeC5idG4sXG4gICAgc3VjY2Vzc0J0bjogYCR7cHJlZml4LmJ0bn0tc3VjY2Vzc2AsXG4gICAgY2FuY2VsQnRuOiBgJHtwcmVmaXguYnRufS1jYW5jZWxgLFxuICAgIHRpdGxlOiBgJHtwcmVmaXgucG9wdXB9LXRpdGxlYCxcbiAgICBib2R5OiBgJHtwcmVmaXgucG9wdXB9LWJvZHlgLFxuICAgIGNvbnRlbnQ6IGAke3ByZWZpeC5wb3B1cH0tY29udGVudGAsXG4gICAgZG90QW5pbWF0aW9uOiBgJHtwcmVmaXgucG9wdXB9LWxvYWRpbmctZG90c2BcbiAgfSxcbiAgaWRzOiB7XG4gICAgd3JhcHBlcjogYCR7cHJlZml4LnBvcHVwfS13cmFwcGVyYCxcbiAgICBjb25maXJtT2s6IGAke3ByZWZpeC5jb25maXJtfS1va2AsXG4gICAgY29uZmlybUNhbmNlbDogYCR7cHJlZml4LmNvbmZpcm19LWNhbmNlbGBcbiAgfVxufVxuXG5leHBvcnQgY29uc3QgZUNvbnN0cyA9IHtcbiAga2xhc3M6IHtcbiAgICBoaWRpbmc6IGAke2xpYk5hbWV9LWhpZGluZ2BcbiAgfSxcbiAgbGliOiBsaWJOYW1lXG59XG4iLCJpbXBvcnQge1xuICAgIGVDb25zdHNcbn0gZnJvbSBcIi4vY29uc3RhbnRzXCJcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3Mge1xuICAgIGNvbnN0cnVjdG9yKHBhcmVudCwgaWQsIGtsYXNzLCBzdHlsZSwgb3B0aW9ucykge1xuICAgICAgICB0aGlzLm5ld05vZGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuICAgICAgICBpZiAoaWQpIHRoaXMubmV3Tm9kZS5pZCA9IGlkXG4gICAgICAgIGlmIChrbGFzcykgdGhpcy5uZXdOb2RlLmNsYXNzTmFtZSA9IGtsYXNzXG4gICAgICAgIGlmIChzdHlsZSkgdGhpcy5uZXdOb2RlLnN0eWxlLmNzc1RleHQgPSBzdHlsZVxuICAgICAgICB0aGlzLnBhcmVudCA9IHBhcmVudFxuICAgICAgICB0aGlzLm9wdGlvbnMgPSBvcHRpb25zXG4gICAgfVxuICAgIGJlZm9yZUluc2VydCgpIHt9XG4gICAgYWZ0ZXJJbnNlcnQoKSB7fVxuICAgIGluc2VydCgpIHtcbiAgICAgICAgdGhpcy5iZWZvcmVJbnNlcnQoKVxuICAgICAgICB0aGlzLmVsID0gdGhpcy5wYXJlbnQuYXBwZW5kQ2hpbGQodGhpcy5uZXdOb2RlKVxuICAgICAgICB0aGlzLmFmdGVySW5zZXJ0KClcbiAgICAgICAgcmV0dXJuIHRoaXNcbiAgICB9XG5cbiAgICByZXBsYWNlKGVsKSB7XG4gICAgICAgIGlmICghdGhpcy5nZXRFbGVtZW50KCkpIHJldHVyblxuICAgICAgICByZXR1cm4gdGhpcy5iZWZvcmVEZWxldGUoKS50aGVuKCgpID0+IHtcbiAgICAgICAgICAgIHRoaXMudXBkYXRlVHlwZShlbC50eXBlKVxuICAgICAgICAgICAgdGhpcy5wYXJlbnQucmVwbGFjZUNoaWxkKGVsLm5ld05vZGUsIHRoaXMuZWwpXG4gICAgICAgICAgICB0aGlzLmVsID0gdGhpcy5nZXRFbGVtZW50KGVsLm5ld05vZGUpXG4gICAgICAgICAgICB0aGlzLmFmdGVySW5zZXJ0KClcbiAgICAgICAgICAgIHJldHVybiB0aGlzXG4gICAgICAgIH0pXG4gICAgfVxuXG4gICAgYmVmb3JlRGVsZXRlKGVsID0gdGhpcy5lbCkge1xuICAgICAgICBsZXQgdGltZUxlZnQgPSAwXG4gICAgICAgIGlmICh0aGlzLnN0YXJ0KSB7XG4gICAgICAgICAgICB0aW1lTGVmdCA9IHRoaXMub3B0aW9ucy5taW5EdXJhdGlvbnNbdGhpcy50eXBlXSArIHRoaXMuc3RhcnQgLSBEYXRlLm5vdygpXG4gICAgICAgICAgICBpZiAodGltZUxlZnQgPCAwKSB0aW1lTGVmdCA9IDBcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShyZXNvbHZlID0+IHtcbiAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgIGVsLmNsYXNzTGlzdC5hZGQoZUNvbnN0cy5rbGFzcy5oaWRpbmcpXG4gICAgICAgICAgICAgICAgc2V0VGltZW91dChyZXNvbHZlLCB0aGlzLm9wdGlvbnMuYW5pbWF0aW9uRHVyYXRpb24pXG4gICAgICAgICAgICB9LCB0aW1lTGVmdClcbiAgICAgICAgfSlcbiAgICB9XG5cbiAgICBkZWxldGUoZWwgPSB0aGlzLmVsKSB7XG4gICAgICAgIGlmICghdGhpcy5nZXRFbGVtZW50KGVsKSkgcmV0dXJuIG51bGxcbiAgICAgICAgcmV0dXJuIHRoaXMuYmVmb3JlRGVsZXRlKGVsKS50aGVuKCgpID0+IHtcbiAgICAgICAgICAgIGVsLnJlbW92ZSgpXG4gICAgICAgICAgICB0aGlzLmFmdGVyRGVsZXRlKClcbiAgICAgICAgfSlcbiAgICB9XG4gICAgYWZ0ZXJEZWxldGUoKSB7fVxuXG4gICAgZ2V0RWxlbWVudChlbCA9IHRoaXMuZWwpIHtcbiAgICAgICAgaWYgKCFlbCkgcmV0dXJuIG51bGxcbiAgICAgICAgcmV0dXJuIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGVsLmlkKVxuICAgIH1cblxuICAgIGFkZEV2ZW50KG5hbWUsIGZ1bmMpIHtcbiAgICAgICAgdGhpcy5lbC5hZGRFdmVudExpc3RlbmVyKG5hbWUsIGZ1bmMpXG4gICAgfVxuXG4gICAgdG9nZ2xlQ2xhc3Moa2xhc3MpIHtcbiAgICAgICAgdGhpcy5lbC5jbGFzc0xpc3QudG9nZ2xlKGtsYXNzKVxuICAgIH1cbiAgICB1cGRhdGVUeXBlKHR5cGUpIHtcbiAgICAgICAgdGhpcy50eXBlID0gdHlwZVxuICAgICAgICB0aGlzLmR1cmF0aW9uID0gdGhpcy5vcHRpb25zLmR1cmF0aW9uKHRoaXMudHlwZSlcbiAgICB9XG59IiwiaW1wb3J0IE9wdGlvbnMgZnJvbSBcIi4vb3B0aW9uc1wiXG5pbXBvcnQgVG9hc3QgZnJvbSBcIi4vdG9hc3RcIlxuaW1wb3J0IFBvcHVwIGZyb20gXCIuL3BvcHVwXCJcbmltcG9ydCBFbGVtIGZyb20gXCIuL2VsZW1cIlxuXG5pbXBvcnQge1xuICB0Q29uc3RzXG59IGZyb20gXCIuL2NvbnN0YW50c1wiXG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE5vdGlmaWVyIHtcbiAgY29uc3RydWN0b3Iob3B0aW9ucyA9IHt9KSB7XG4gICAgdGhpcy5vcHRpb25zID0gbmV3IE9wdGlvbnMob3B0aW9ucylcbiAgfVxuXG4gIHRpcChtc2csIG9wdGlvbnMpIHtcbiAgICByZXR1cm4gdGhpcy5fYWRkVG9hc3QobXNnLCBcInRpcFwiLCBvcHRpb25zKS5lbFxuICB9XG5cbiAgaW5mbyhtc2csIG9wdGlvbnMpIHtcbiAgICByZXR1cm4gdGhpcy5fYWRkVG9hc3QobXNnLCBcImluZm9cIiwgb3B0aW9ucykuZWxcbiAgfVxuXG4gIHN1Y2Nlc3MobXNnLCBvcHRpb25zKSB7XG4gICAgcmV0dXJuIHRoaXMuX2FkZFRvYXN0KG1zZywgXCJzdWNjZXNzXCIsIG9wdGlvbnMpLmVsXG4gIH1cblxuICB3YXJuaW5nKG1zZywgb3B0aW9ucykge1xuICAgIHJldHVybiB0aGlzLl9hZGRUb2FzdChtc2csIFwid2FybmluZ1wiLCBvcHRpb25zKS5lbFxuICB9XG5cbiAgYWxlcnQobXNnLCBvcHRpb25zKSB7XG4gICAgcmV0dXJuIHRoaXMuX2FkZFRvYXN0KG1zZywgXCJhbGVydFwiLCBvcHRpb25zKS5lbFxuICB9XG5cbiAgYXN5bmMgKHByb21pc2UsIG9uUmVzb2x2ZSwgb25SZWplY3QsIG1zZywgb3B0aW9ucykge1xuICAgIGxldCBhc3luY1RvYXN0ID0gdGhpcy5fYWRkVG9hc3QobXNnLCBcImFzeW5jXCIsIG9wdGlvbnMpXG4gICAgcmV0dXJuIHRoaXMuX2FmdGVyQXN5bmMocHJvbWlzZSwgb25SZXNvbHZlLCBvblJlamVjdCwgb3B0aW9ucywgYXN5bmNUb2FzdClcbiAgfVxuXG4gIGNvbmZpcm0obXNnLCBvbk9rLCBvbkNhbmNlbCwgb3B0aW9ucykge1xuICAgIHJldHVybiB0aGlzLl9hZGRQb3B1cChtc2csIFwiY29uZmlybVwiLCBvcHRpb25zLCBvbk9rLCBvbkNhbmNlbClcbiAgfVxuXG4gIGFzeW5jQmxvY2socHJvbWlzZSwgb25SZXNvbHZlLCBvblJlamVjdCwgbXNnLCBvcHRpb25zKSB7XG4gICAgbGV0IGFzeW5jQmxvY2sgPSB0aGlzLl9hZGRQb3B1cChtc2csIFwiYXN5bmMtYmxvY2tcIiwgb3B0aW9ucylcbiAgICByZXR1cm4gdGhpcy5fYWZ0ZXJBc3luYyhwcm9taXNlLCBvblJlc29sdmUsIG9uUmVqZWN0LCBvcHRpb25zLCBhc3luY0Jsb2NrKVxuICB9XG5cbiAgbW9kYWwobXNnLCBjbGFzc05hbWUsIG9wdGlvbnMpIHtcbiAgICByZXR1cm4gdGhpcy5fYWRkUG9wdXAobXNnLCBjbGFzc05hbWUsIG9wdGlvbnMpXG4gIH1cblxuICBjbG9zZVRvYXN0cygpIHtcbiAgICBsZXQgYyA9IHRoaXMuY29udGFpbmVyXG4gICAgd2hpbGUgKGMuZmlyc3RDaGlsZCkge1xuICAgICAgYy5yZW1vdmVDaGlsZChjLmZpcnN0Q2hpbGQpXG4gICAgfVxuICB9XG5cbiAgLy8gVG9vbHNcbiAgX2FkZFBvcHVwKG1zZywgY2xhc3NOYW1lLCBvcHRpb25zLCBvbk9rLCBvbkNhbmNlbCkge1xuICAgIHJldHVybiBuZXcgUG9wdXAobXNnLCBjbGFzc05hbWUsIHRoaXMub3B0aW9ucy5vdmVycmlkZShvcHRpb25zKSwgb25Paywgb25DYW5jZWwpXG4gIH1cblxuICBfYWRkVG9hc3QobXNnLCB0eXBlLCBvcHRpb25zLCBvbGQpIHtcbiAgICBvcHRpb25zID0gdGhpcy5vcHRpb25zLm92ZXJyaWRlKG9wdGlvbnMpXG4gICAgbGV0IG5ld1RvYXN0ID0gbmV3IFRvYXN0KG1zZywgdHlwZSwgb3B0aW9ucywgdGhpcy5jb250YWluZXIpXG4gICAgaWYgKG9sZCkge1xuICAgICAgaWYgKG9sZCBpbnN0YW5jZW9mIFBvcHVwKSByZXR1cm4gb2xkLmRlbGV0ZSgpLnRoZW4oKCkgPT4gbmV3VG9hc3QuaW5zZXJ0KCkpXG4gICAgICBsZXQgaSA9IG9sZC5yZXBsYWNlKG5ld1RvYXN0KVxuICAgICAgcmV0dXJuIGlcbiAgICB9XG4gICAgcmV0dXJuIG5ld1RvYXN0Lmluc2VydCgpXG4gIH1cblxuICBfYWZ0ZXJBc3luYyhwcm9taXNlLCBvblJlc29sdmUsIG9uUmVqZWN0LCBvcHRpb25zLCBvbGRFbGVtZW50KSB7XG4gICAgcmV0dXJuIHByb21pc2UudGhlbihcbiAgICAgIHRoaXMuX3Jlc3BvbnNlSGFuZGxlcihvblJlc29sdmUsIFwic3VjY2Vzc1wiLCBvcHRpb25zLCBvbGRFbGVtZW50KSxcbiAgICAgIHRoaXMuX3Jlc3BvbnNlSGFuZGxlcihvblJlamVjdCwgXCJhbGVydFwiLCBvcHRpb25zLCBvbGRFbGVtZW50KVxuICAgIClcbiAgfVxuXG4gIF9yZXNwb25zZUhhbmRsZXIocGF5bG9hZCwgdG9hc3ROYW1lLCBvcHRpb25zLCBvbGRFbGVtZW50KSB7XG4gICAgcmV0dXJuIHJlc3VsdCA9PiB7XG4gICAgICBzd2l0Y2ggKHR5cGVvZiBwYXlsb2FkKSB7XG4gICAgICAgIGNhc2UgJ3VuZGVmaW5lZCc6XG4gICAgICAgIGNhc2UgJ3N0cmluZyc6XG4gICAgICAgICAgbGV0IG1zZyA9IHRvYXN0TmFtZSA9PT0gJ2FsZXJ0JyA/IHBheWxvYWQgfHwgcmVzdWx0IDogcGF5bG9hZFxuICAgICAgICAgIHRoaXMuX2FkZFRvYXN0KG1zZywgdG9hc3ROYW1lLCBvcHRpb25zLCBvbGRFbGVtZW50KVxuICAgICAgICAgIGJyZWFrXG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgb2xkRWxlbWVudC5kZWxldGUoKS50aGVuKCgpID0+IHtcbiAgICAgICAgICAgIGlmIChwYXlsb2FkKSBwYXlsb2FkKHJlc3VsdClcbiAgICAgICAgICB9KVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIF9jcmVhdGVDb250YWluZXIoKSB7XG4gICAgcmV0dXJuIG5ldyBFbGVtKGRvY3VtZW50LmJvZHksIHRDb25zdHMuaWRzLmNvbnRhaW5lciwgYGF3bi0ke3RoaXMub3B0aW9ucy5wb3NpdGlvbn1gKS5pbnNlcnQoKS5lbFxuICB9XG5cbiAgZ2V0IGNvbnRhaW5lcigpIHtcbiAgICByZXR1cm4gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQodENvbnN0cy5pZHMuY29udGFpbmVyKSB8fCB0aGlzLl9jcmVhdGVDb250YWluZXIoKVxuICB9XG59XG4iLCJjb25zdCBkZWZhdWx0cyA9IHtcbiAgbWF4Tm90aWZpY2F0aW9uczogMTAsXG4gIGFuaW1hdGlvbkR1cmF0aW9uOiAzMDAsXG4gIHBvc2l0aW9uOiBcImJvdHRvbS1yaWdodFwiLFxuICBsYWJlbHM6IHtcbiAgICB0aXA6IFwiVGlwXCIsXG4gICAgaW5mbzogXCJJbmZvXCIsXG4gICAgc3VjY2VzczogXCJTdWNjZXNzXCIsXG4gICAgd2FybmluZzogXCJBdHRlbnRpb25cIixcbiAgICBhbGVydDogXCJFcnJvclwiLFxuICAgIGFzeW5jOiBcIkxvYWRpbmdcIixcbiAgICBjb25maXJtOiBcIkNvbmZpcm1hdGlvbiByZXF1aXJlZFwiLFxuICAgIGNvbmZpcm1PazogXCJPS1wiLFxuICAgIGNvbmZpcm1DYW5jZWw6IFwiQ2FuY2VsXCJcbiAgfSxcbiAgaWNvbnM6IHtcbiAgICB0aXA6IFwicXVlc3Rpb24tY2lyY2xlXCIsXG4gICAgaW5mbzogXCJpbmZvLWNpcmNsZVwiLFxuICAgIHN1Y2Nlc3M6IFwiY2hlY2stY2lyY2xlXCIsXG4gICAgd2FybmluZzogXCJleGNsYW1hdGlvbi1jaXJjbGVcIixcbiAgICBhbGVydDogXCJleGNsYW1hdGlvbi10cmlhbmdsZVwiLFxuICAgIGFzeW5jOiBcImNvZyBmYS1zcGluXCIsXG4gICAgY29uZmlybTogXCJleGNsYW1hdGlvbi10cmlhbmdsZVwiLFxuICAgIHByZWZpeDogXCI8aSBjbGFzcz0nZmEgZmFzIGZhLWZ3IGZhLVwiLFxuICAgIHN1ZmZpeDogXCInPjwvaT5cIixcbiAgICBlbmFibGVkOiB0cnVlXG4gIH0sXG4gIHJlcGxhY2VtZW50czoge1xuICAgIHRpcDogbnVsbCxcbiAgICBpbmZvOiBudWxsLFxuICAgIHN1Y2Nlc3M6IG51bGwsXG4gICAgd2FybmluZzogbnVsbCxcbiAgICBhbGVydDogbnVsbCxcbiAgICBhc3luYzogbnVsbCxcbiAgICBcImFzeW5jLWJsb2NrXCI6IG51bGwsXG4gICAgbW9kYWw6IG51bGwsXG4gICAgY29uZmlybTogbnVsbCxcbiAgICBnZW5lcmFsOiB7XG4gICAgICBcIjxzY3JpcHQ+XCI6IFwiXCIsXG4gICAgICBcIjwvc2NyaXB0PlwiOiBcIlwiXG4gICAgfVxuICB9LFxuICBtZXNzYWdlczoge1xuICAgIHRpcDogXCJcIixcbiAgICBpbmZvOiBcIlwiLFxuICAgIHN1Y2Nlc3M6IFwiQWN0aW9uIGhhcyBiZWVuIHN1Y2NlZWRlZFwiLFxuICAgIHdhcm5pbmc6IFwiXCIsXG4gICAgYWxlcnQ6IFwiQWN0aW9uIGhhcyBiZWVuIGZhaWxlZFwiLFxuICAgIGNvbmZpcm06IFwiVGhpcyBhY3Rpb24gY2FuJ3QgYmUgdW5kb25lLiBDb250aW51ZT9cIixcbiAgICBhc3luYzogXCJQbGVhc2UsIHdhaXQuLi5cIixcbiAgICBcImFzeW5jLWJsb2NrXCI6IFwiTG9hZGluZ1wiXG4gIH0sXG4gIGZvcm1hdEVycm9yKGVycikge1xuICAgIGlmIChlcnIucmVzcG9uc2UpIHtcbiAgICAgIGlmICghZXJyLnJlc3BvbnNlLmRhdGEpIHJldHVybiAnNTAwIEFQSSBTZXJ2ZXIgRXJyb3InXG4gICAgICBpZiAoZXJyLnJlc3BvbnNlLmRhdGEuZXJyb3JzKSB7XG4gICAgICAgIHJldHVybiBlcnIucmVzcG9uc2UuZGF0YS5lcnJvcnMubWFwKG8gPT4gby5kZXRhaWwpLmpvaW4oJzxicj4nKVxuICAgICAgfVxuICAgICAgaWYgKGVyci5yZXNwb25zZS5zdGF0dXNUZXh0KSB7XG4gICAgICAgIHJldHVybiBgJHtlcnIucmVzcG9uc2Uuc3RhdHVzfSAke2Vyci5yZXNwb25zZS5zdGF0dXNUZXh0fTogJHtlcnIucmVzcG9uc2UuZGF0YX1gXG4gICAgICB9XG4gICAgfVxuICAgIGlmIChlcnIubWVzc2FnZSkgcmV0dXJuIGVyci5tZXNzYWdlXG4gICAgcmV0dXJuIGVyclxuICB9LFxuICBkdXJhdGlvbnM6IHtcbiAgICBnbG9iYWw6IDUwMDAsXG4gICAgc3VjY2VzczogbnVsbCxcbiAgICBpbmZvOiBudWxsLFxuICAgIHRpcDogbnVsbCxcbiAgICB3YXJuaW5nOiBudWxsLFxuICAgIGFsZXJ0OiBudWxsXG4gIH0sXG4gIG1pbkR1cmF0aW9uczoge1xuICAgIGFzeW5jOiAxMDAwLFxuICAgIFwiYXN5bmMtYmxvY2tcIjogMTAwMFxuICB9LFxufVxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgT3B0aW9ucyB7XG4gIGNvbnN0cnVjdG9yKG9wdGlvbnMgPSB7fSwgZ2xvYmFsID0gZGVmYXVsdHMpIHtcbiAgICBPYmplY3QuYXNzaWduKHRoaXMsIHRoaXMuZGVmYXVsdHNEZWVwKGdsb2JhbCwgb3B0aW9ucykpXG4gIH1cblxuICBpY29uKHR5cGUpIHtcbiAgICBpZiAodGhpcy5pY29ucy5lbmFibGVkKSByZXR1cm4gYCR7dGhpcy5pY29ucy5wcmVmaXh9JHt0aGlzLmljb25zW3R5cGVdfSR7dGhpcy5pY29ucy5zdWZmaXh9YFxuICAgIHJldHVybiAnJ1xuICB9XG5cbiAgbGFiZWwodHlwZSkge1xuICAgIHJldHVybiB0aGlzLmxhYmVsc1t0eXBlXVxuICB9XG5cbiAgZHVyYXRpb24odHlwZSkge1xuICAgIGxldCBkdXJhdGlvbiA9IHRoaXMuZHVyYXRpb25zW3R5cGVdXG4gICAgcmV0dXJuIGR1cmF0aW9uID09PSBudWxsID8gdGhpcy5kdXJhdGlvbnMuZ2xvYmFsIDogZHVyYXRpb25cbiAgfVxuXG4gIHRvU2Vjcyh2YWx1ZSkge1xuICAgIHJldHVybiBgJHt2YWx1ZSAvIDEwMDB9c2BcbiAgfVxuXG4gIGFwcGx5UmVwbGFjZW1lbnRzKHN0ciwgdHlwZSkge1xuICAgIGlmICghc3RyKSByZXR1cm4gdGhpcy5tZXNzYWdlc1t0eXBlXSB8fCBcIlwiXG4gICAgZm9yIChjb25zdCBuIG9mIFsnZ2VuZXJhbCcsIHR5cGVdKSB7XG4gICAgICBpZiAoIXRoaXMucmVwbGFjZW1lbnRzW25dKSBjb250aW51ZVxuICAgICAgZm9yIChjb25zdCBrIGluIHRoaXMucmVwbGFjZW1lbnRzW25dKSB7XG4gICAgICAgIHN0ciA9IHN0ci5yZXBsYWNlKGssIHRoaXMucmVwbGFjZW1lbnRzW25dW2tdKVxuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gc3RyXG4gIH1cblxuICBvdmVycmlkZShvcHRpb25zKSB7XG4gICAgaWYgKG9wdGlvbnMpIHJldHVybiBuZXcgT3B0aW9ucyhvcHRpb25zLCB0aGlzKVxuICAgIHJldHVybiB0aGlzXG4gIH1cblxuICBkZWZhdWx0c0RlZXAoZGVmYXVsdHMsIG92ZXJyaWRlcykge1xuICAgIGxldCByZXN1bHQgPSB7fVxuICAgIGZvciAoY29uc3QgayBpbiBkZWZhdWx0cykge1xuICAgICAgaWYgKG92ZXJyaWRlcy5oYXNPd25Qcm9wZXJ0eShrKSkge1xuICAgICAgICByZXN1bHRba10gPSB0eXBlb2YgZGVmYXVsdHNba10gPT09IFwib2JqZWN0XCIgJiYgZGVmYXVsdHNba10gIT09IG51bGwgPyB0aGlzLmRlZmF1bHRzRGVlcChkZWZhdWx0c1trXSwgb3ZlcnJpZGVzW2tdKSA6IG92ZXJyaWRlc1trXVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmVzdWx0W2tdID0gZGVmYXVsdHNba11cbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdFxuICB9XG59XG4iLCJpbXBvcnQgRWxlbSBmcm9tIFwiLi9lbGVtXCJcbmltcG9ydCB7XG4gIG1Db25zdHNcbn0gZnJvbSBcIi4vY29uc3RhbnRzXCJcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgZXh0ZW5kcyBFbGVtIHtcbiAgY29uc3RydWN0b3IobXNnLCB0eXBlID0gJ21vZGFsJywgb3B0aW9ucywgb25Paywgb25DYW5jZWwpIHtcbiAgICBsZXQgYW5pbWF0aW9uRHVyYXRpb24gPSBgYW5pbWF0aW9uLWR1cmF0aW9uOiAke29wdGlvbnMudG9TZWNzKG9wdGlvbnMuYW5pbWF0aW9uRHVyYXRpb24pfTtgXG4gICAgc3VwZXIoZG9jdW1lbnQuYm9keSwgbUNvbnN0cy5pZHMud3JhcHBlciwgbnVsbCwgYW5pbWF0aW9uRHVyYXRpb24sIG9wdGlvbnMpXG4gICAgdGhpc1ttQ29uc3RzLmlkcy5jb25maXJtT2tdID0gb25Pa1xuICAgIHRoaXNbbUNvbnN0cy5pZHMuY29uZmlybUNhbmNlbF0gPSBvbkNhbmNlbFxuICAgIHRoaXMuY2xhc3NOYW1lID0gYCR7bUNvbnN0cy5wcmVmaXh9LSR7dHlwZX1gXG4gICAgaWYgKCFbJ2NvbmZpcm0nLCAnYXN5bmMtYmxvY2snLCAnbW9kYWwnXS5pbmNsdWRlcyh0eXBlKSkgdHlwZSA9ICdtb2RhbCdcbiAgICB0aGlzLnVwZGF0ZVR5cGUodHlwZSlcbiAgICB0aGlzLnNldElubmVySHRtbChtc2cpXG4gICAgdGhpcy5pbnNlcnQoKVxuICB9XG5cbiAgc2V0SW5uZXJIdG1sKGh0bWwpIHtcbiAgICBsZXQgaW5uZXJIVE1MID0gdGhpcy5vcHRpb25zLmFwcGx5UmVwbGFjZW1lbnRzKGh0bWwsIHRoaXMudHlwZSlcbiAgICBzd2l0Y2ggKHRoaXMudHlwZSkge1xuICAgICAgY2FzZSBcImNvbmZpcm1cIjpcbiAgICAgICAgbGV0IGJ1dHRvbnMgPSBbYDxidXR0b24gY2xhc3M9JyR7bUNvbnN0cy5rbGFzcy5idXR0b259ICR7bUNvbnN0cy5rbGFzcy5zdWNjZXNzQnRufSdpZD0nJHttQ29uc3RzLmlkcy5jb25maXJtT2t9Jz4ke3RoaXMub3B0aW9ucy5sYWJlbHMuY29uZmlybU9rfTwvYnV0dG9uPmBdXG4gICAgICAgIGlmICh0aGlzW21Db25zdHMuaWRzLmNvbmZpcm1DYW5jZWxdICE9PSBmYWxzZSkge1xuICAgICAgICAgIGJ1dHRvbnMucHVzaChgPGJ1dHRvbiBjbGFzcz0nJHttQ29uc3RzLmtsYXNzLmJ1dHRvbn0gJHttQ29uc3RzLmtsYXNzLmNhbmNlbEJ0bn0naWQ9JyR7bUNvbnN0cy5pZHMuY29uZmlybUNhbmNlbH0nPiR7dGhpcy5vcHRpb25zLmxhYmVscy5jb25maXJtQ2FuY2VsfTwvYnV0dG9uPmApXG4gICAgICAgIH1cbiAgICAgICAgaW5uZXJIVE1MID0gYCR7dGhpcy5vcHRpb25zLmljb24odGhpcy50eXBlKX08ZGl2IGNsYXNzPScke21Db25zdHMua2xhc3MudGl0bGV9Jz4ke3RoaXMub3B0aW9ucy5sYWJlbCh0aGlzLnR5cGUpfTwvZGl2PjxkaXYgY2xhc3M9XCIke21Db25zdHMua2xhc3MuY29udGVudH1cIj4ke2lubmVySFRNTH08L2Rpdj48ZGl2IGNsYXNzPScke21Db25zdHMua2xhc3MuYnV0dG9uc30gJHttQ29uc3RzLmtsYXNzLmJ1dHRvbnN9LSR7YnV0dG9ucy5sZW5ndGh9Jz4ke2J1dHRvbnMuam9pbignJyl9PC9kaXY+YFxuICAgICAgICBicmVha1xuICAgICAgY2FzZSBcImFzeW5jLWJsb2NrXCI6XG4gICAgICAgIGlubmVySFRNTCA9IGAke2lubmVySFRNTH08ZGl2IGNsYXNzPVwiJHttQ29uc3RzLmtsYXNzLmRvdEFuaW1hdGlvbn1cIj48L2Rpdj5gXG4gICAgfVxuICAgIHRoaXMubmV3Tm9kZS5pbm5lckhUTUwgPSBgPGRpdiBjbGFzcz1cIiR7bUNvbnN0cy5rbGFzcy5ib2R5fSAke3RoaXMuY2xhc3NOYW1lfVwiPiR7aW5uZXJIVE1MfTwvZGl2PmBcbiAgfVxuXG4gIGtleXVwTGlzdGVuZXIoZSkge1xuICAgIGlmICh0aGlzLnR5cGUgPT09ICdhc3luYy1ibG9jaycpIHJldHVybiBlLnByZXZlbnREZWZhdWx0KClcbiAgICBzd2l0Y2ggKGUuY29kZSkge1xuICAgICAgY2FzZSAnRXNjYXBlJzpcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgICAgIHRoaXMuZGVsZXRlKClcbiAgICAgIGNhc2UgJ1RhYic6XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgICBpZiAodGhpcy50eXBlICE9PSAnY29uZmlybScgfHwgdGhpc1ttQ29uc3RzLmlkcy5jb25maXJtQ2FuY2VsXSA9PT0gZmFsc2UpIHJldHVybiB0cnVlXG4gICAgICAgIGxldCBuZXh0ID0gdGhpcy5va0J0blxuICAgICAgICBpZiAoZS5zaGlmdEtleSkge1xuICAgICAgICAgIGlmIChkb2N1bWVudC5hY3RpdmVFbGVtZW50LmlkID09IG1Db25zdHMuaWRzLmNvbmZpcm1PaykgbmV4dCA9IHRoaXMuY2FuY2VsQnRuXG4gICAgICAgIH0gZWxzZSBpZiAoZG9jdW1lbnQuYWN0aXZlRWxlbWVudC5pZCAhPT0gbUNvbnN0cy5pZHMuY29uZmlybUNhbmNlbCkgbmV4dCA9IHRoaXMuY2FuY2VsQnRuXG4gICAgICAgIG5leHQuZm9jdXMoKVxuICAgIH1cbiAgfVxuICBhZnRlckluc2VydCgpIHtcbiAgICB0aGlzLmxpc3RlbmVyID0gZSA9PiB0aGlzLmtleXVwTGlzdGVuZXIoZSlcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwgdGhpcy5saXN0ZW5lcilcbiAgICBzd2l0Y2ggKHRoaXMudHlwZSkge1xuICAgICAgY2FzZSAnYXN5bmMtYmxvY2snOlxuICAgICAgICB0aGlzLnN0YXJ0ID0gRGF0ZS5ub3coKVxuICAgICAgICBicmVha1xuICAgICAgY2FzZSAnY29uZmlybSc6XG4gICAgICAgIHRoaXMub2tCdG4uZm9jdXMoKVxuICAgICAgICB0aGlzLmFkZEV2ZW50KFwiY2xpY2tcIiwgZSA9PiB7XG4gICAgICAgICAgaWYgKGUudGFyZ2V0Lm5vZGVOYW1lICE9PSBcIkJVVFRPTlwiKSByZXR1cm4gZmFsc2VcbiAgICAgICAgICB0aGlzLmRlbGV0ZSgpXG4gICAgICAgICAgaWYgKHRoaXNbZS50YXJnZXQuaWRdKSB0aGlzW2UudGFyZ2V0LmlkXSgpXG4gICAgICAgIH0pXG4gICAgICAgIGJyZWFrXG4gICAgICBkZWZhdWx0OlxuICAgICAgICBkb2N1bWVudC5hY3RpdmVFbGVtZW50LmJsdXIoKVxuICAgICAgICB0aGlzLmFkZEV2ZW50KFwiY2xpY2tcIiwgZSA9PiB7XG4gICAgICAgICAgaWYgKGUudGFyZ2V0LmlkID09PSB0aGlzLm5ld05vZGUuaWQpIHRoaXMuZGVsZXRlKClcbiAgICAgICAgfSlcbiAgICB9XG4gIH1cblxuICBhZnRlckRlbGV0ZSgpIHtcbiAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwgdGhpcy5saXN0ZW5lcilcbiAgfVxuXG4gIGdldCBva0J0bigpIHtcbiAgICByZXR1cm4gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQobUNvbnN0cy5pZHMuY29uZmlybU9rKVxuICB9XG5cbiAgZ2V0IGNhbmNlbEJ0bigpIHtcbiAgICByZXR1cm4gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQobUNvbnN0cy5pZHMuY29uZmlybUNhbmNlbClcbiAgfVxufVxuIiwiZXhwb3J0IGRlZmF1bHQgY2xhc3Mge1xuICBjb25zdHJ1Y3RvcihjYWxsYmFjaywgZGVsYXkpIHtcbiAgICB0aGlzLmNhbGxiYWNrID0gY2FsbGJhY2tcbiAgICB0aGlzLnJlbWFpbmluZyA9IGRlbGF5XG4gICAgdGhpcy5yZXN1bWUoKVxuICB9XG4gIHBhdXNlKCkge1xuICAgIHRoaXMucGF1c2VkID0gdHJ1ZVxuICAgIHdpbmRvdy5jbGVhclRpbWVvdXQodGhpcy50aW1lcklkKVxuICAgIHRoaXMucmVtYWluaW5nIC09IG5ldyBEYXRlKCkgLSB0aGlzLnN0YXJ0XG4gIH1cbiAgcmVzdW1lKCkge1xuICAgIHRoaXMucGF1c2VkID0gZmFsc2VcbiAgICB0aGlzLnN0YXJ0ID0gbmV3IERhdGUoKVxuICAgIHdpbmRvdy5jbGVhclRpbWVvdXQodGhpcy50aW1lcklkKVxuICAgIHRoaXMudGltZXJJZCA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHdpbmRvdy5jbGVhclRpbWVvdXQodGhpcy50aW1lcklkKVxuICAgICAgdGhpcy5jYWxsYmFjaygpXG4gICAgfSwgdGhpcy5yZW1haW5pbmcpXG4gIH1cbiAgdG9nZ2xlKCkge1xuICAgIGlmICh0aGlzLnBhdXNlZCkgdGhpcy5yZXN1bWUoKVxuICAgIGVsc2UgdGhpcy5wYXVzZSgpXG4gIH1cbn1cbiIsImltcG9ydCBFbGVtIGZyb20gXCIuL2VsZW1cIlxuaW1wb3J0IFRpbWVyIGZyb20gXCIuL3RpbWVyXCJcblxuaW1wb3J0IHtcbiAgdENvbnN0cyxcbiAgZUNvbnN0c1xufSBmcm9tIFwiLi9jb25zdGFudHNcIlxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBleHRlbmRzIEVsZW0ge1xuICBjb25zdHJ1Y3Rvcihtc2csIHR5cGUsIG9wdGlvbnMsIHBhcmVudCkge1xuICAgIHN1cGVyKFxuICAgICAgcGFyZW50LFxuICAgICAgYCR7dENvbnN0cy5wcmVmaXh9LSR7TWF0aC5mbG9vcihEYXRlLm5vdygpIC0gTWF0aC5yYW5kb20oKSAqIDEwMCl9YCxcbiAgICAgIGAke3RDb25zdHMucHJlZml4fSAke3RDb25zdHMucHJlZml4fS0ke3R5cGV9YCxcbiAgICAgIGBhbmltYXRpb24tZHVyYXRpb246ICR7b3B0aW9ucy50b1NlY3Mob3B0aW9ucy5hbmltYXRpb25EdXJhdGlvbil9O2AsXG4gICAgICBvcHRpb25zXG4gICAgKVxuICAgIHRoaXMudXBkYXRlVHlwZSh0eXBlKVxuICAgIHRoaXMuc2V0SW5uZXJIdG1sKG1zZylcbiAgfVxuXG4gIHNldElubmVySHRtbChodG1sKSB7XG4gICAgaWYgKHRoaXMudHlwZSA9PT0gJ2FsZXJ0JyAmJiBodG1sKSBodG1sID0gdGhpcy5vcHRpb25zLmZvcm1hdEVycm9yKGh0bWwpXG4gICAgaHRtbCA9IHRoaXMub3B0aW9ucy5hcHBseVJlcGxhY2VtZW50cyhodG1sLCB0aGlzLnR5cGUpXG4gICAgdGhpcy5uZXdOb2RlLmlubmVySFRNTCA9IGA8ZGl2IGNsYXNzPVwiYXduLXRvYXN0LXdyYXBwZXJcIj4ke3RoaXMucHJvZ3Jlc3NCYXJ9JHt0aGlzLmxhYmVsfTxkaXYgY2xhc3M9XCIke3RDb25zdHMua2xhc3MuY29udGVudH1cIj4ke2h0bWx9PC9kaXY+PHNwYW4gY2xhc3M9XCIke3RDb25zdHMua2xhc3MuaWNvbn1cIj4ke3RoaXMub3B0aW9ucy5pY29uKHRoaXMudHlwZSl9PC9zcGFuPjwvZGl2PmBcbiAgfVxuXG4gIGJlZm9yZUluc2VydCgpIHtcbiAgICBpZiAodGhpcy5wYXJlbnQuY2hpbGRFbGVtZW50Q291bnQgPj0gdGhpcy5vcHRpb25zLm1heE5vdGlmaWNhdGlvbnMpIHtcbiAgICAgIGxldCBlbGVtZW50cyA9IEFycmF5LmZyb20odGhpcy5wYXJlbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZSh0Q29uc3RzLnByZWZpeCkpXG4gICAgICB0aGlzLmRlbGV0ZShlbGVtZW50cy5maW5kKGUgPT4gIXRoaXMuaXNEZWxldGVkKGUpKSlcbiAgICB9XG4gIH1cbiAgYWZ0ZXJJbnNlcnQoKSB7XG4gICAgaWYgKHRoaXMudHlwZSA9PSBcImFzeW5jXCIpIHJldHVybiB0aGlzLnN0YXJ0ID0gRGF0ZS5ub3coKVxuXG4gICAgdGhpcy5hZGRFdmVudChcImNsaWNrXCIsICgpID0+IHRoaXMuZGVsZXRlKCkpXG5cbiAgICBpZiAodGhpcy5kdXJhdGlvbiA8PSAwKSByZXR1cm5cbiAgICB0aGlzLnRpbWVyID0gbmV3IFRpbWVyKCgpID0+IHRoaXMuZGVsZXRlKCksIHRoaXMuZHVyYXRpb24pXG4gICAgZm9yIChjb25zdCBlIG9mIFtcIm1vdXNlZW50ZXJcIiwgXCJtb3VzZWxlYXZlXCJdKSB7XG4gICAgICB0aGlzLmFkZEV2ZW50KGUsICgpID0+IHtcbiAgICAgICAgaWYgKHRoaXMuaXNEZWxldGVkKCkpIHJldHVyblxuICAgICAgICB0aGlzLnRvZ2dsZUNsYXNzKHRDb25zdHMua2xhc3MucHJvZ3Jlc3NCYXJQYXVzZSlcbiAgICAgICAgdGhpcy50aW1lci50b2dnbGUoKVxuICAgICAgfSlcbiAgICB9XG4gIH1cblxuICBpc0RlbGV0ZWQoZWwgPSB0aGlzLmVsKSB7XG4gICAgcmV0dXJuIGVsLmNsYXNzTGlzdC5jb250YWlucyhlQ29uc3RzLmtsYXNzLmhpZGluZylcbiAgfVxuICBnZXQgcHJvZ3Jlc3NCYXIoKSB7XG4gICAgaWYgKHRoaXMuZHVyYXRpb24gPD0gMCB8fCB0aGlzLnR5cGUgPT09ICdhc3luYycpIHJldHVybiBcIlwiXG4gICAgcmV0dXJuIGA8ZGl2IGNsYXNzPScke3RDb25zdHMua2xhc3MucHJvZ3Jlc3NCYXJ9JyBzdHlsZT1cImFuaW1hdGlvbi1kdXJhdGlvbjoke3RoaXMub3B0aW9ucy50b1NlY3ModGhpcy5kdXJhdGlvbil9O1wiPjwvZGl2PmBcbiAgfVxuICBnZXQgbGFiZWwoKSB7XG4gICAgcmV0dXJuIGA8YiBjbGFzcz1cIiR7dENvbnN0cy5rbGFzcy5sYWJlbH1cIj4ke3RoaXMub3B0aW9ucy5sYWJlbCh0aGlzLnR5cGUpfTwvYj5gXG4gIH1cblxufVxuIiwiaW1wb3J0IGNvdXJzZUFwaSBmcm9tICcuL3RyYWluaW5ncy90cmFpbmluZ3MnO1xyXG5pbXBvcnQgbW9kdWxlQXBpIGZyb20gJy4vbW9kdWxlJztcclxuaW1wb3J0IHBheW1lbnRzQXBpIGZyb20gJy4vcGF5bWVudHMnO1xyXG5pbXBvcnQgc3VydmV5QXBpIGZyb20gJy4vc3VydmV5JztcclxuaW1wb3J0IGNvbW1vbkFwaSBmcm9tICcuL2NvbW1vbic7XHJcbmltcG9ydCBxdWl6QXBpIGZyb20gJy4vcXVpeic7XHJcbmltcG9ydCB1c2Vyc0FwaSBmcm9tICcuL3VzZXJzJztcclxuaW1wb3J0IHN0cmVhbUFwaSBmcm9tICcuL3N0cmVhbS9zdHJlYW0nO1xyXG5pbXBvcnQgY3BlQXBpIGZyb20gJy4vY3BlL2NwZSc7XHJcbmltcG9ydCBnZW5lcmljQXBpIGZyb20gJy4vc3RvcmFnZS9nZW5lcmljJztcclxuaW1wb3J0IHRlbXBsYXRlc0FwaSBmcm9tICcuL3N0b3JhZ2UvdGVtcGxhdGVzJztcclxuaW1wb3J0IGFzc2Vzc21lbnRBcGkgZnJvbSAnLi9zdG9yYWdlL2Fzc2Vzc21lbnRDb25maWcnO1xyXG5pbXBvcnQgc3RhdHNBcGkgZnJvbSAnLi9zdG9yYWdlL3BheW1lbnRTdGF0cyc7XHJcbmltcG9ydCBtb2R1bGVzRGF0YUFwaSBmcm9tICcuL3N0b3JhZ2UvbW9kdWxlc0RhdGEuanMnO1xyXG5pbXBvcnQgYWxwaGFKdWRnZUFwaSBmcm9tICcuL2p1ZGdlL2FscGhhSnVkZ2UuanMnO1xyXG5pbXBvcnQgeyBDb250ZW50VHlwZSB9IGZyb20gJy4uL3V0aWwvY29udGVudFR5cGVzLmpzJztcclxuXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBiaW5kU2l0ZUFwaShhcHBOYW1lKSB7XHJcbiAgICBjb25zdCBlbnYgPSB7XHJcbiAgICAgICAgaW50ZXJvcEhvc3QsXHJcbiAgICAgICAgaW50ZXJvcEFwcElkLFxyXG4gICAgICAgIHBhcmFtcyxcclxuICAgICAgICBwb3N0LFxyXG4gICAgICAgIGdldCxcclxuICAgICAgICBpbnRlcm9wUGxhdGZvcm1Ib3N0LFxyXG4gICAgICAgIGludGVyb3BBZG1pbkFscGhhSnVkZ2VIb3N0XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGFjdGlvbnMgPSB7XHJcbiAgICAgICAgLi4uY291cnNlQXBpKGVudiksXHJcbiAgICAgICAgLi4ubW9kdWxlQXBpKGVudiksXHJcbiAgICAgICAgLi4ucGF5bWVudHNBcGkoZW52KSxcclxuICAgICAgICAuLi5zdXJ2ZXlBcGkoZW52KSxcclxuICAgICAgICAuLi5jb21tb25BcGkoZW52KSxcclxuICAgICAgICAuLi5xdWl6QXBpKGVudiksXHJcbiAgICAgICAgLi4udXNlcnNBcGkoZW52KSxcclxuICAgICAgICAuLi5zdHJlYW1BcGkoZW52KSxcclxuICAgICAgICAuLi5jcGVBcGkoZW52KSxcclxuICAgICAgICAuLi5nZW5lcmljQXBpKGVudiksXHJcbiAgICAgICAgLi4udGVtcGxhdGVzQXBpKGVudiksXHJcbiAgICAgICAgLi4uYXNzZXNzbWVudEFwaShlbnYpLFxyXG4gICAgICAgIC4uLnN0YXRzQXBpKGVudiksXHJcbiAgICAgICAgLi4ubW9kdWxlc0RhdGFBcGkoZW52KSxcclxuICAgICAgICAuLi5hbHBoYUp1ZGdlQXBpKGVudilcclxuICAgIH07XHJcblxyXG4gICAgaWYgKGFwcE5hbWUgPT09IG51bGwpIHtcclxuICAgICAgICByZXR1cm4gT2JqZWN0LmtleXMoYWN0aW9ucyk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJldHVybiBhY3Rpb25zO1xyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIGludGVyb3BIb3N0KGVuZHBvaW50KSB7XHJcbiAgICAgICAgc3dpdGNoIChhcHBOYW1lKSB7XHJcbiAgICAgICAgICAgIGNhc2UgJ2RpZ2l0YWwnOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdodHRwczovL2RpZ2l0YWwuc29mdHVuaS5iZy8nICsgZW5kcG9pbnQ7XHJcbiAgICAgICAgICAgIGNhc2UgJ2NyZWF0aXZlJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiAnaHR0cHM6Ly9jcmVhdGl2ZS5zb2Z0dW5pLmJnLycgKyBlbmRwb2ludDtcclxuICAgICAgICAgICAgY2FzZSAnYWknOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdodHRwczovL2FpLnNvZnR1bmkuYmcvJyArIGVuZHBvaW50O1xyXG4gICAgICAgICAgICBjYXNlICdmaW5hbmNlYWNhZGVteSc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJ2h0dHBzOi8vZmluYW5jZWFjYWRlbXkuYmcvJyArIGVuZHBvaW50O1xyXG4gICAgICAgICAgICBjYXNlICdkZXZkaWdpdGFsJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiAnaHR0cHM6Ly9kZXYuZGlnaXRhbC5zb2Z0dW5pLmJnLycgKyBlbmRwb2ludDtcclxuICAgICAgICAgICAgY2FzZSAnZGV2c29mdHVuaSc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJ2h0dHBzOi8vZGV2LnNvZnR1bmkuYmcvJyArIGVuZHBvaW50O1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdodHRwczovL3NvZnR1bmkuYmcvJyArIGVuZHBvaW50O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBpbnRlcm9wQXBwSWQoKSB7XHJcbiAgICAgICAgc3dpdGNoIChhcHBOYW1lKSB7XHJcbiAgICAgICAgICAgIGNhc2UgJ2RpZ2l0YWwnOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdkaWdpdGFsLnNvZnR1bmkuYmcnO1xyXG4gICAgICAgICAgICBjYXNlICdjcmVhdGl2ZSc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJ2NyZWF0aXZlLnNvZnR1bmkuYmcnO1xyXG4gICAgICAgICAgICBjYXNlICdhaSc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJ2FpLnNvZnR1bmkuYmcnO1xyXG4gICAgICAgICAgICBjYXNlICdmaW5hbmNlYWNhZGVteSc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJ2ZpbmFuY2VhY2FkZW15LmJnJztcclxuICAgICAgICAgICAgY2FzZSAnZGV2ZGlnaXRhbCc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJ2RpZ2l0YWwuc29mdHVuaS5iZyc7XHJcbiAgICAgICAgICAgIGNhc2UgJ2RldnNvZnR1bmknOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdzb2Z0dW5pLmJnJztcclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIHJldHVybiAnc29mdHVuaS5iZyc7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIGludGVyb3BQbGF0Zm9ybUhvc3QoKSB7XHJcbiAgICAgICAgc3dpdGNoIChhcHBOYW1lKSB7XHJcbiAgICAgICAgICAgIGNhc2UgJ2RpZ2l0YWwnOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdodHRwczovL3BsYXRmb3JtLnNvZnR1bmkuYmcnO1xyXG4gICAgICAgICAgICBjYXNlICdjcmVhdGl2ZSc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJ2h0dHBzOi8vcGxhdGZvcm0uc29mdHVuaS5iZyc7XHJcbiAgICAgICAgICAgIGNhc2UgJ2FpJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiAnaHR0cHM6Ly9wbGF0Zm9ybS5zb2Z0dW5pLmJnJztcclxuICAgICAgICAgICAgY2FzZSAnZmluYW5jZWFjYWRlbXknOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdodHRwczovL3BsYXRmb3JtLmZpbmFuY2VhY2FkZW15LmJnJztcclxuICAgICAgICAgICAgY2FzZSAnZGV2ZGlnaXRhbCc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJ2h0dHBzOi8vZGV2LnBsYXRmb3JtLnNvZnR1bmkuYmcnO1xyXG4gICAgICAgICAgICBjYXNlICdkZXZzb2Z0dW5pJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiAnaHR0cHM6Ly9kZXYucGxhdGZvcm0uc29mdHVuaS5iZyc7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJ2h0dHBzOi8vcGxhdGZvcm0uc29mdHVuaS5iZyc7XHJcblxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBpbnRlcm9wQWRtaW5BbHBoYUp1ZGdlSG9zdCgpIHtcclxuICAgICAgICBzd2l0Y2ggKGFwcE5hbWUpIHtcclxuICAgICAgICAgICAgY2FzZSAnZGV2c29mdHVuaSc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gXCJodHRwczovL2FkbWluLmRldi5hbHBoYS5qdWRnZS5zb2Z0dW5pLm9yZ1wiXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gXCJodHRwczovL2FkbWluLmFscGhhLmp1ZGdlLnNvZnR1bmkub3JnXCI7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5sZXQgaG9zdHMgPSBbXHJcbiAgICAnaHR0cHM6Ly9kaWdpdGFsLnNvZnR1bmkuYmcvJyxcclxuICAgICdodHRwczovL2NyZWF0aXZlLnNvZnR1bmkuYmcvJyxcclxuICAgICdodHRwczovL2FpLnNvZnR1bmkuYmcvJyxcclxuICAgICdodHRwczovL2ZpbmFuY2VhY2FkZW15LmJnLycsXHJcbiAgICAnaHR0cHM6Ly9kZXYuZGlnaXRhbC5zb2Z0dW5pLmJnLycsXHJcbiAgICAnaHR0cHM6Ly9kZXYuc29mdHVuaS5iZy8nLFxyXG4gICAgJ2h0dHBzOi8vc29mdHVuaS5iZy8nXHJcbl1cclxuXHJcbmxldCBwbGF0Zm9ybUhvc3RzID0gW1xyXG4gICAgJ2h0dHBzOi8vcGxhdGZvcm0uZmluYW5jZWFjYWRlbXkuYmcnLFxyXG4gICAgJ2h0dHBzOi8vZGV2LnBsYXRmb3JtLnNvZnR1bmkuYmcnLFxyXG4gICAgJ2h0dHBzOi8vcGxhdGZvcm0uc29mdHVuaS5iZydcclxuXVxyXG5cclxubGV0IGp1ZGdlSG9zdHMgPSBbXHJcbiAgICBcImh0dHBzOi8vYWRtaW4uYWxwaGEuanVkZ2Uuc29mdHVuaS5vcmdcIixcclxuICAgIFwiaHR0cHM6Ly9kZXYuYWRtaW4uYWxwaGEuanVkZ2Uuc29mdHVuaS5vcmdcIixcclxuICAgIFwiaHR0cHM6Ly9hbHBoYS5qdWRnZS5zb2Z0dW5pLm9yZ1wiLFxyXG4gICAgXCJodHRwczovL2Rldi5hbHBoYS5qdWRnZS5zb2Z0dW5pLm9yZ1wiLFxyXG5dXHJcblxyXG5mdW5jdGlvbiBwYXJhbXMocGFyYW1zID0ge30pIHtcclxuICAgIHJldHVybiBPYmplY3QuYXNzaWduKHtcclxuICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICBwYWdlOiAxLFxyXG4gICAgICAgIHBhZ2VTaXplOiAxMCxcclxuICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgZmlsdGVyOiAnJ1xyXG4gICAgfSwgcGFyYW1zKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gcG9zdCh1cmwsIHBhcmFtcywgY29udGVudFR5cGUgPSBDb250ZW50VHlwZS5VcmxGb3JtRW5jb2RlZCwgYXNCbG9iID0gZmFsc2UpIHtcclxuICAgIGxldCBib2R5ID0gbmV3IFVSTFNlYXJjaFBhcmFtcygpO1xyXG4gICAgaWYoY29udGVudFR5cGUgPT09IENvbnRlbnRUeXBlLkFwcGxpY2F0aW9uSnNvbikge1xyXG4gICAgICAgIGJvZHkgPSBKU09OLnN0cmluZ2lmeShwYXJhbXMpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICBmb3IgKGxldCBrZXkgb2YgT2JqZWN0LmtleXMocGFyYW1zKSkge1xyXG4gICAgICAgICAgICBib2R5LmFwcGVuZChrZXksIHBhcmFtc1trZXldKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgcmVxID0ge1xyXG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6IGNvbnRlbnRUeXBlXHJcbiAgICAgICAgfSxcclxuICAgICAgICBib2R5XHJcbiAgICB9O1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaCh1cmwsIHJlcSk7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyAhPT0gMjAwKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUud2FybignVW5zdWNjZXNzZnVsIHJlcXVlc3QnKTtcclxuICAgICAgICAgICAgY29uc29sZS53YXJuKHBhcmFtcyk7XHJcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIGxldCBlcnJvciA9IG5ldyBFcnJvcihgJHtyZXNwb25zZS5zdGF0dXN9OiAke3Jlc3BvbnNlLnN0YXR1c1RleHR9IGF0ICR7cmVzcG9uc2UudXJsfWApO1xyXG4gICAgICAgICAgICBlcnJvci5fc3RhdHVzID0gcmVzcG9uc2Uuc3RhdHVzO1xyXG4gICAgICAgICAgICB0aHJvdyBlcnJvcjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLnJlZGlyZWN0ZWQgfHwgcmVzcG9uc2Uuc3RhdHVzID09IDMwMikge1xyXG4gICAgICAgICAgICBsZXQgdXJsRG9tYWluID0gaG9zdHMuZmluZCh4ID0+IHVybC5zdGFydHNXaXRoKHgpKTtcclxuICAgICAgICAgICAgbGV0IHBsYXRmb3JtRG9tYWluID0gcGxhdGZvcm1Ib3N0cy5maW5kKHggPT4gdXJsLnN0YXJ0c1dpdGgoeCkpO1xyXG4gICAgICAgICAgICBsZXQganVkZ2VEb21haW4gPSBqdWRnZUhvc3RzLmZpbmQoeCA9PiB1cmwuc3RhcnRzV2l0aCh4KSk7XHJcblxyXG4gICAgICAgICAgICBpZighdXJsRG9tYWluKSB7XHJcbiAgICAgICAgICAgICAgICB1cmxEb21haW4gPSBwbGF0Zm9ybURvbWFpbjtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYoIXVybERvbWFpbikge1xyXG4gICAgICAgICAgICAgICAgdXJsRG9tYWluID0ganVkZ2VEb21haW47XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYFJlcXVlc3QgZXJyb3IgZmV0Y2hpbmcgZnJvbSAke3VybH0sIHlvdSdyZSBwcm9iYWJseSBub3QgbG9nZ2VkIGluICcke3VybERvbWFpbn0nLmApO1xyXG4gICAgICAgICAgICBjb25zdCBlcnJvciA9IG5ldyBFcnJvcihgUmVxdWVzdCBlcnJvciwgeW91J3JlIHByb2JhYmx5IG5vdCBsb2dnZWQgaW4gPGEgaHJlZj1cIiR7dXJsRG9tYWlufVwiIHRhcmdldD1cIl9ibGFua1wiPiR7dXJsRG9tYWlufTwvYT4uIFBsZWFzZSBsb2dpbiB0byA8YSBocmVmPVwiJHt1cmxEb21haW59XCIgdGFyZ2V0PVwiX2JsYW5rXCI+JHt1cmxEb21haW59PC9hPiBhbmQgdHJ5IGFnYWluLmApO1xyXG4gICAgICAgICAgICBlcnJvci5fdXJsID0gdXJsO1xyXG4gICAgICAgICAgICB0aHJvdyBlcnJvcjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmKGFzQmxvYikge1xyXG4gICAgICAgICAgICBsZXQgZmlsZW5hbWUgPSByZXNwb25zZS5oZWFkZXJzLmdldCgnQ29udGVudC1EaXNwb3NpdGlvbicpLnNwbGl0KCdmaWxlbmFtZT0nKVsxXS5zcGxpdCgnOycpWzBdLnJlcGxhY2VBbGwoJ1xcXCInLCAnJyk7XHJcbiAgICAgICAgICAgIGxldCBibG9iID0gYXdhaXQgcmVzcG9uc2UuYmxvYigpO1xyXG4gICAgICAgICAgICBibG9iLmZpbGVuYW1lID0gZmlsZW5hbWU7XHJcbiAgICAgICAgICAgIHJldHVybiBibG9iO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgbGV0IHJlc3VsdCA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcclxuICAgICAgICAgICAgaWYocmVzdWx0LkVycm9ycykge1xyXG4gICAgICAgICAgICAgICAgbGV0IGVycm9yc1BhcnNlZCA9IEpTT04uc3RyaW5naWZ5KHJlc3VsdC5FcnJvcnMsIHVuZGVmaW5lZCwgMik7XHJcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoZXJyb3JzUGFyc2VkKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICBpZiAoZSBpbnN0YW5jZW9mIFN5bnRheEVycm9yKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aHJvdyBlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgY2F0Y2ggKGUpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKGUpO1xyXG4gICAgICAgIHRocm93IGU7XHJcbiAgICB9XHJcblxyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBnZXQodXJsLCBhc0Jsb2IpIHtcclxuICAgIGNvbnN0IHJlcSA9IHtcclxuICAgICAgICBtZXRob2Q6ICdHRVQnXHJcbiAgICB9O1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgICAgbGV0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2godXJsLCByZXEpO1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgIT09IDIwMCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ1Vuc3VjY2Vzc2Z1bCByZXF1ZXN0Jyk7XHJcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihwYXJhbXMpO1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7cmVzcG9uc2Uuc3RhdHVzVGV4dH0gYXQgJHtyZXNwb25zZS51cmx9YCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChyZXNwb25zZS5yZWRpcmVjdGVkKSB7XHJcbiAgICAgICAgICAgIGlmICh1cmwuaW5jbHVkZXMoJ3BsYXRmb3JtJykpIHtcclxuICAgICAgICAgICAgICAgIGxldCBwbGF0Zm9ybURvbWFpbiA9IHBsYXRmb3JtSG9zdHMuZmluZCh4ID0+IHVybC5zdGFydHNXaXRoKHgpKTtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYFJlcXVlc3QgZXJyb3IgZmV0Y2hpbmcgZnJvbSAke3VybH0sIHlvdSdyZSBwcm9iYWJseSBub3QgbG9nZ2VkIGluIHRvIHRoZSBwbGF0Zm9ybS5gKTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGVycm9yID0gbmV3IEVycm9yKGBSZXF1ZXN0IGVycm9yLCB5b3UncmUgcHJvYmFibHkgbm90IGxvZ2dlZCBpbiA8YSBocmVmPVwiJHtwbGF0Zm9ybURvbWFpbn1cIiB0YXJnZXQ9XCJfYmxhbmtcIj4ke3BsYXRmb3JtRG9tYWlufTwvYT4uIFBsZWFzZSBsb2dpbiB0byA8YSBocmVmPVwiJHtwbGF0Zm9ybURvbWFpbn1cIiB0YXJnZXQ9XCJfYmxhbmtcIj4ke3BsYXRmb3JtRG9tYWlufTwvYT4gYW5kIHRyeSBhZ2Fpbi5gKTtcclxuICAgICAgICAgICAgICAgIGVycm9yLl91cmwgPSB1cmw7XHJcbiAgICAgICAgICAgICAgICB0aHJvdyBlcnJvcjtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gYXdhaXQgZmV0Y2gocmVzcG9uc2UudXJsLCByZXEpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoYXNCbG9iKSB7XHJcbiAgICAgICAgICAgIHJldHVybiByZXNwb25zZS5ibG9iKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCByZWFkZXIgPSByZXNwb25zZS5ib2R5LmdldFJlYWRlcigpO1xyXG4gICAgICAgIGNvbnN0IHV0ZjhEZWNvZGVyID0gbmV3IFRleHREZWNvZGVyKCd1dGYtOCcpO1xyXG4gICAgICAgIGxldCByZXN1bHQgPSAnJztcclxuICAgICAgICB3aGlsZSAodHJ1ZSkge1xyXG4gICAgICAgICAgICBjb25zdCB7IGRvbmUsIHZhbHVlIH0gPSBhd2FpdCByZWFkZXIucmVhZCgpO1xyXG4gICAgICAgICAgICBpZiAoZG9uZSkge1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmVzdWx0ICs9IHV0ZjhEZWNvZGVyLmRlY29kZSh2YWx1ZSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICByZXR1cm4gSlNPTi5wYXJzZShyZXN1bHQpO1xyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBjYXRjaCAoZSkge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XHJcbiAgICAgICAgdGhyb3cgZTtcclxuICAgIH1cclxuXHJcbn0iLCJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KSB7XHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRCbG9nQnlVcmwoYmxvZ1VybCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl9jbXMvbmV3cy9yZWFkJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIGZpbHRlcjogYFVybH5lcX4nJHtibG9nVXJsfSdgXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmksIGJvZHkpKS5EYXRhWzBdO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEhhbGxzKCkge1xyXG4gICAgICAgIGNvbnN0IGRpciA9IGludGVyb3BBcHBJZCgpID09ICdzb2Z0dW5pLmJnJyA/ICdhZG1pbmlzdHJhdGlvbl91bml2ZXJzaXR5JyA6ICdBZG1pbmlzdHJhdGlvbic7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoZGlyICsgJy90cmFpbmluZ2xhYnMvcmVhZCcpO1xyXG5cclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDBcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRTb2Z0d2FyZVVuaXZlcnNpdHlIYWxscygpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSAnaHR0cHM6Ly9zb2Z0dW5pLmJnL2FkbWluaXN0cmF0aW9uX3VuaXZlcnNpdHkvdHJhaW5pbmdsYWJzL3JlYWQnO1xyXG5cclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDBcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBnZXRIYWxsQm9keShoYWxsKSB7XHJcbiAgICAgICAgbGV0IGN1cnJlbnREYXRlID0gbmV3IERhdGUoKTtcclxuICAgICAgICAvLyBzaW1wbGVzdCB3YXkgdG8gY29udmVydCBkYXRlIHRvIElTTyBmb3JtYXQgaW4gbG9jYWwgVGltZXpvbmUgYXMgU1VMUyByZXF1aXJlc1xyXG4gICAgICAgIGN1cnJlbnREYXRlLnNldE1pbnV0ZXMoY3VycmVudERhdGUuZ2V0TWludXRlcygpIC0gY3VycmVudERhdGUuZ2V0VGltZXpvbmVPZmZzZXQoKSlcclxuICAgICAgICBsZXQgbW9kaWZpZWRPbkRhdGUgPSBjdXJyZW50RGF0ZS50b0lTT1N0cmluZygpLnNsaWNlKDAsIC0xKTtcclxuXHJcbiAgICAgICAgY29uc3QgYm9keSA9IHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgSWQ6IGhhbGwuSWQsXHJcbiAgICAgICAgICAgIE5hbWVCZzogaGFsbC5OYW1lQmcsXHJcbiAgICAgICAgICAgIE5hbWVFbjogaGFsbC5OYW1lRW4sXHJcbiAgICAgICAgICAgIEFkZHJlc3M6IGhhbGwuQWRkcmVzcyxcclxuICAgICAgICAgICAgQ2FwYWNpdHk6IGhhbGwuQ2FwYWNpdHksXHJcbiAgICAgICAgICAgIERlc2NyaXB0aW9uOiBoYWxsLkRlc2NyaXB0aW9uLFxyXG4gICAgICAgICAgICBEaXNhYmxlU2VjdXJlTGluazogaGFsbC5EaXNhYmxlU2VjdXJlTGluayxcclxuICAgICAgICAgICAgRmxvb3I6IGhhbGwuRmxvb3IsXHJcbiAgICAgICAgICAgIEdvb2dsZUNhbGVuZGFySWQ6IGhhbGwuR29vZ2xlQ2FsZW5kYXJJZCxcclxuICAgICAgICAgICAgSXNBY3RpdmU6IGhhbGwuSXNBY3RpdmUsXHJcbiAgICAgICAgICAgIElzRmVhdHVyZWQ6IGhhbGwuSXNGZWF0dXJlZCxcclxuICAgICAgICAgICAgSXNQaHlzaWNhbDogaGFsbC5Jc1BoeXNpY2FsLFxyXG4gICAgICAgICAgICBTaG93T25TY2hlZHVsZTogaGFsbC5TaG93T25TY2hlZHVsZSxcclxuICAgICAgICAgICAgQnJhbmNoSWQ6IGhhbGwuQnJhbmNoSWQsXHJcbiAgICAgICAgICAgIFNlYXRzQ29uZmlndXJhdGlvbjogaGFsbC5TZWF0c0NvbmZpZ3VyYXRpb24sXHJcbiAgICAgICAgICAgIFN0cmVhbWluZ1R5cGU6IGhhbGwuU3RyZWFtaW5nVHlwZSxcclxuICAgICAgICAgICAgWW91VHViZUNvZGU6IGhhbGwuWW91VHViZUNvZGUsXHJcbiAgICAgICAgICAgIFNvZnRVbmlTdHJlYW1Db2RlOiBoYWxsLlNvZnRVbmlTdHJlYW1Db2RlLFxyXG4gICAgICAgICAgICBTdHJlYW1pbmdTZXJ2ZXJCYXNlSWQ6IGhhbGwuU3RyZWFtaW5nU2VydmVyQmFzZUlkLFxyXG4gICAgICAgICAgICBVY2RuU3RyZWFtaW5nQ29kZTogaGFsbC5VY2RuU3RyZWFtaW5nQ29kZSxcclxuICAgICAgICAgICAgQ3JlYXRlZE9uOiBoYWxsLkNyZWF0ZWRPbixcclxuICAgICAgICAgICAgTW9kaWZpZWRPbjogaGFsbC5Nb2RpZmllZE9uIHx8IG1vZGlmaWVkT25EYXRlXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgcmV0dXJuIGJvZHk7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUhhbGwoaGFsbCkge1xyXG4gICAgICAgIGxldCB1cmk7XHJcbiAgICAgICAgaWYgKGludGVyb3BBcHBJZCgpID09PSAnc29mdHVuaS5iZycpIHtcclxuICAgICAgICAgICAgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3VuaXZlcnNpdHkvdHJhaW5pbmdsYWJzL3VwZGF0ZScpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHVyaSA9IGludGVyb3BIb3N0KCdBZG1pbmlzdHJhdGlvbi9UcmFpbmluZ0xhYnMvVXBkYXRlJyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCBib2R5ID0gZ2V0SGFsbEJvZHkoaGFsbCk7XHJcblxyXG4gICAgICAgIGlmIChpbnRlcm9wQXBwSWQoKSAhPT0gJ3NvZnR1bmkuYmcnKSB7XHJcbiAgICAgICAgICAgIGRlbGV0ZSBib2R5LkJyYW5jaElkO1xyXG4gICAgICAgICAgICBkZWxldGUgYm9keS5TZWF0c0NvbmZpZ3VyYXRpb247XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCkgeyBib2R5W2tdID0gJyc7IH0gfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVNvZnR3YXJlVW5pdmVyc2l0eUhhbGwoaGFsbCkge1xyXG4gICAgICAgIGxldCB1cmkgPSAnaHR0cHM6Ly9zb2Z0dW5pLmJnL2FkbWluaXN0cmF0aW9uX3VuaXZlcnNpdHkvdHJhaW5pbmdsYWJzL3VwZGF0ZSc7XHJcblxyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBnZXRIYWxsQm9keShoYWxsKTtcclxuXHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgZ2V0QmxvZ0J5VXJsLFxyXG4gICAgICAgIGdldEhhbGxzLFxyXG4gICAgICAgIHVwZGF0ZUhhbGwsXHJcbiAgICAgICAgZ2V0U29mdHdhcmVVbml2ZXJzaXR5SGFsbHMsXHJcbiAgICAgICAgdXBkYXRlU29mdHdhcmVVbml2ZXJzaXR5SGFsbFxyXG4gICAgfTtcclxufSIsImltcG9ydCBuYXZldEFwaUZhY3RvcnkgZnJvbSAnLi9uYXZldCc7XHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQsIGludGVyb3BQbGF0Zm9ybUhvc3QgfSkge1xyXG4gICAgY29uc3QgbmF2ZXRBcGkgPSBuYXZldEFwaUZhY3RvcnkoKTtcclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRBcHBsaWNhdGlvbnNCeUluc3RhbmNlSWQoaW5zdGFuY2VJZCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGAke2ludGVyb3BQbGF0Zm9ybUhvc3QoKX0vYWRtaW5pc3RyYXRpb24vY3BlY2VydGlmaWNhdGVhcHBsaWNhdGlvbnMvcmVhZD9hcHBJZD0ke2ludGVyb3BBcHBJZCgpfWA7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICdDcmVhdGVkT24tZGVzYy1hc2MnLFxyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMCxcclxuICAgICAgICAgICAgZmlsdGVyOiBgVHJhaW5pbmdJZH5lcX4ke2luc3RhbmNlSWR9YFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRBcHBsaWNhdGlvbnMocXVlcnksIHBhZ2UpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBgJHtpbnRlcm9wUGxhdGZvcm1Ib3N0KCl9L2FkbWluaXN0cmF0aW9uL2NwZWNlcnRpZmljYXRlYXBwbGljYXRpb25zL3JlYWQ/YXBwSWQ9JHtpbnRlcm9wQXBwSWQoKX1gO1xyXG5cclxuICAgICAgICBjb25zdCBmaWx0ZXJUb2tlbnMgPSBbXTtcclxuICAgICAgICBpZiAocXVlcnkuaW5zdGFuY2VJZCkge1xyXG4gICAgICAgICAgICBmaWx0ZXJUb2tlbnMucHVzaChgKFRyYWluaW5nSWR+ZXF+JHtxdWVyeS5pbnN0YW5jZUlkfSlgKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHF1ZXJ5Lmluc3RhbmNlTmFtZSkge1xyXG4gICAgICAgICAgICBmaWx0ZXJUb2tlbnMucHVzaChgKFRyYWluaW5nTmFtZX5jb250YWluc34nJHt0b2tlbml6ZShxdWVyeS5pbnN0YW5jZU5hbWUpLmpvaW4oJ1xcJ35hbmR+VHJhaW5pbmdOYW1lfmNvbnRhaW5zflxcJycpfScpYCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChxdWVyeS5uYW1lcykge1xyXG4gICAgICAgICAgICBjb25zdCBuYW1lVG9rZW5zID0gdG9rZW5pemUocXVlcnkubmFtZXMpO1xyXG4gICAgICAgICAgICBsZXQgbmFtZUZpbHRlciA9ICcnO1xyXG4gICAgICAgICAgICBpZiAobmFtZVRva2Vucy5sZW5ndGggPT0gMSkge1xyXG4gICAgICAgICAgICAgICAgbmFtZUZpbHRlciA9IGAoRmlyc3ROYW1lfmNvbnRhaW5zficke25hbWVUb2tlbnNbMF19J35vcn5NaWRkbGVOYW1lfmNvbnRhaW5zficke25hbWVUb2tlbnNbMF19J35vcn5MYXN0TmFtZX5jb250YWluc34nJHtuYW1lVG9rZW5zWzBdfScpYDtcclxuICAgICAgICAgICAgfSBlbHNlIGlmIChuYW1lVG9rZW5zLmxlbmd0aCA9PSAyKSB7XHJcbiAgICAgICAgICAgICAgICBuYW1lRmlsdGVyID0gYChGaXJzdE5hbWV+Y29udGFpbnN+JyR7bmFtZVRva2Vuc1swXX0nfmFuZH4oTWlkZGxlTmFtZX5jb250YWluc34nJHtuYW1lVG9rZW5zWzFdfSd+b3J+TGFzdE5hbWV+Y29udGFpbnN+JyR7bmFtZVRva2Vuc1sxXX0nKSlgO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKG5hbWVUb2tlbnMubGVuZ3RoID09IDMpIHtcclxuICAgICAgICAgICAgICAgIG5hbWVGaWx0ZXIgPSBgKEZpcnN0TmFtZX5jb250YWluc34nJHtuYW1lVG9rZW5zWzBdfSd+YW5kfk1pZGRsZU5hbWV+Y29udGFpbnN+JyR7bmFtZVRva2Vuc1sxXX0nfmFuZH5MYXN0TmFtZX5jb250YWluc34nJHtuYW1lVG9rZW5zWzJdfScpYDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgZmlsdGVyVG9rZW5zLnB1c2gobmFtZUZpbHRlcik7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChxdWVyeS5TU04pIHtcclxuICAgICAgICAgICAgZmlsdGVyVG9rZW5zLnB1c2goYFNTTn5jb250YWluc34nJHtxdWVyeS5TU059J2ApO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICdDcmVhdGVkT24tZGVzYycsXHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiBwYWdlID8gMjUgOiAyMDAwLFxyXG4gICAgICAgICAgICBwYWdlOiBwYWdlID8gcGFnZSA6IDEsXHJcbiAgICAgICAgICAgIGZpbHRlcjogZmlsdGVyVG9rZW5zLmpvaW4oJ35hbmR+JylcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRBcHBaaXAoaWQpIHtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChgJHtpbnRlcm9wUGxhdGZvcm1Ib3N0KCl9L2FkbWluaXN0cmF0aW9uL2NwZWNlcnRpZmljYXRlYXBwbGljYXRpb25zL2dldGZpbGVzemlwP2lkPSR7aWR9YCk7XHJcblxyXG4gICAgICAgIGNvbnN0IGJsb2IgPSBhd2FpdCByZXMuYmxvYigpO1xyXG4gICAgICAgIGNvbnN0IHNlcmlhbGl6ZWRCbG9iID0gbmV3IFVpbnQ4QXJyYXkoYXdhaXQgYmxvYi5hcnJheUJ1ZmZlcigpKTtcclxuICBcclxuICAgICAgICBjb25zdCBibG9iRGF0YSA9IHtcclxuICAgICAgICAgICAgdHlwZTogYmxvYi50eXBlLFxyXG4gICAgICAgICAgICBidWZmZXI6IEFycmF5LmZyb20oc2VyaWFsaXplZEJsb2IpXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgcmV0dXJuIGJsb2JEYXRhO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvLyAjIyMgRXh0ZXJuYWwgc3RvcmFnZSBvZiBhcHBsaWNhdGlvbiBkYXRhICh1c2VzIGxlY3R1cmVzIGluc2lkZSBhIGZpeGVkIGNvdXJzZSBpbnN0YW5jZSlcclxuXHJcbiAgICBjb25zdCBzdG9yZUlkID0ge1xyXG4gICAgICAgICdzb2Z0dW5pLmJnJzogMzEyNCxcclxuICAgICAgICAnZGlnaXRhbC5zb2Z0dW5pLmJnJzogMjMzNixcclxuICAgICAgICAnY3JlYXRpdmUuc29mdHVuaS5iZyc6IDExOTMsXHJcbiAgICAgICAgJ2FpLnNvZnR1bmkuYmcnOiA4LFxyXG4gICAgICAgICdmaW5hbmNlYWNhZGVteS5iZyc6IDIyOFxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBzdGF0dXNNb2RlbCA9IHtcclxuICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICBJZDogJycsXHJcbiAgICAgICAgVHJhaW5pbmdJZDogJycsXHJcbiAgICAgICAgTmFtZUJnOiAnJyxcclxuICAgICAgICBOYW1lRW46ICcnLFxyXG4gICAgICAgIEhhc01hbnVhbE51bWJlck9mU3R1ZHlIb3VyczogJycsXHJcbiAgICAgICAgTnVtYmVyT2ZTdHVkeUhvdXJzOiAnJyxcclxuICAgICAgICBJc0V4Y2x1ZGVkRnJvbUNlcnRpZmljYXRlOiAnJyxcclxuICAgICAgICBIYXNIb21ld29yazogJycsXHJcbiAgICAgICAgUmVzb3VyY2VNYWlsc1N0YXRlOiAnJyxcclxuICAgICAgICBIb21ld29ya01haWxzU3RhdGU6ICcnLFxyXG4gICAgICAgIEp1ZGdlQ29udGVzdElkOiAnJyxcclxuICAgICAgICBPcmRlckJ5OiAnJyxcclxuICAgICAgICBEZXNjcmlwdGlvbkJnOiAnJyxcclxuICAgICAgICBEZXNjcmlwdGlvbkVuOiAnJyxcclxuICAgICAgICBFeGNsdWRlRnJvbUNhbGVuZGFyOiAnJyxcclxuICAgICAgICBIYXNMaXZlU3RyZWFtOiAnJyxcclxuICAgICAgICBDcmVhdGVkT246ICcnLFxyXG4gICAgICAgIE1vZGlmaWVkT246ICcnXHJcbiAgICB9O1xyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEFwcFN0YXR1cyhpZCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvbGVjdHVyZXMvcmVhZD9mb3JlaWduS2V5SWQ9JHtzdG9yZUlkW2ludGVyb3BBcHBJZCgpXX1gKTtcclxuICAgICAgICBsZXQgZmlsdGVyID0gJyc7XHJcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoaWQpKSB7XHJcbiAgICAgICAgICAgIGZpbHRlciA9IGBOYW1lRW5+ZXF+JyR7aWQuam9pbignXFwnfm9yfk5hbWVFbn5lcX5cXCcnKX0nYDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBmaWx0ZXIgPSBgTmFtZUVufmVxficke2lkfSdgO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAsXHJcbiAgICAgICAgICAgIGZpbHRlclxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRBcHBTdGF0dXNCeUluc3RhbmNlSWQoaWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2xlY3R1cmVzL3JlYWQ/Zm9yZWlnbktleUlkPSR7c3RvcmVJZFtpbnRlcm9wQXBwSWQoKV19YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGBOYW1lQmd+ZXF+JyR7aWR9J2BcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gY3JlYXRlU3RhdHVzKHN0YXR1cykge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvbGVjdHVyZXMvY3JlYXRlP2ZvcmVpZ25LZXlJZD0ke3N0b3JlSWRbaW50ZXJvcEFwcElkKCldfWApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBPYmplY3QuYXNzaWduKHBhcmFtcyh7fSksIHN0YXR1c01vZGVsKTtcclxuICAgICAgICBmb3IgKGxldCBmaWVsZCBpbiBib2R5KSB7XHJcbiAgICAgICAgICAgIGJvZHlbZmllbGRdID0gc3RhdHVzW2ZpZWxkXSA9PT0gdW5kZWZpbmVkID8gYm9keVtmaWVsZF0gOiBzdGF0dXNbZmllbGRdO1xyXG4gICAgICAgIH1cclxuICAgICAgICBib2R5LlRyYWluaW5nSWQgPSBzdG9yZUlkW2ludGVyb3BBcHBJZCgpXTtcclxuXHJcbiAgICAgICAgbGV0IHN0YXJ0RGF0ZSA9IG5ldyBEYXRlKCk7XHJcbiAgICAgICAgbGV0IGVuZERhdGUgPSBuZXcgRGF0ZShzdGFydERhdGUpO1xyXG4gICAgICAgIGVuZERhdGUuc2V0VVRDRGF0ZShlbmREYXRlLmdldFVUQ0RhdGUoKSAgKyAxKTtcclxuICAgICAgICBib2R5W2BEYXRlc0luZm9bMF0uU3RhcnRgXSA9IHN0YXJ0RGF0ZS50b0lTT1N0cmluZygpO1xyXG4gICAgICAgIGJvZHlbYERhdGVzSW5mb1swXS5FbmRgXSA9IGVuZERhdGUudG9JU09TdHJpbmcoKTtcclxuICAgICAgICBib2R5W2BEYXRlc0luZm9bMF0uRXh0cmFJbmZvcm1hdGlvbmBdID0gJyc7XHJcblxyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gdXBkYXRlU3RhdHVzKHN0YXR1cykge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvbGVjdHVyZXMvdXBkYXRlP2ZvcmVpZ25LZXlJZD0ke3N0b3JlSWRbaW50ZXJvcEFwcElkKCldfWApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBPYmplY3QuYXNzaWduKHBhcmFtcyh7fSksIHN0YXR1c01vZGVsKTtcclxuICAgICAgICBmb3IgKGxldCBmaWVsZCBpbiBib2R5KSB7XHJcbiAgICAgICAgICAgIGJvZHlbZmllbGRdID0gc3RhdHVzW2ZpZWxkXSA9PT0gdW5kZWZpbmVkID8gYm9keVtmaWVsZF0gOiBzdGF0dXNbZmllbGRdO1xyXG4gICAgICAgIH1cclxuICAgICAgICBib2R5LlRyYWluaW5nSWQgPSBzdG9yZUlkW2ludGVyb3BBcHBJZCgpXTtcclxuXHJcbiAgICAgICAgbGV0IHN0YXJ0RGF0ZSA9IG5ldyBEYXRlKCk7XHJcbiAgICAgICAgbGV0IGVuZERhdGUgPSBuZXcgRGF0ZShzdGFydERhdGUpO1xyXG4gICAgICAgIGVuZERhdGUuc2V0VVRDRGF0ZShlbmREYXRlLmdldFVUQ0RhdGUoKSAgKyAxKTtcclxuICAgICAgICBib2R5W2BEYXRlc0luZm9bMF0uU3RhcnRgXSA9IHN0YXJ0RGF0ZS50b0lTT1N0cmluZygpO1xyXG4gICAgICAgIGJvZHlbYERhdGVzSW5mb1swXS5FbmRgXSA9IGVuZERhdGUudG9JU09TdHJpbmcoKTtcclxuICAgICAgICBib2R5W2BEYXRlc0luZm9bMF0uRXh0cmFJbmZvcm1hdGlvbmBdID0gJyc7XHJcblxyXG4gICAgICAgIGJvZHkuQ3JlYXRlZE9uID0gJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JztcclxuICAgICAgICBib2R5Lk1vZGlmaWVkT24gPSAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZGVzdHJveVN0YXR1cyhzdGF0dXMpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2xlY3R1cmVzL2Rlc3Ryb3k/Zm9yZWlnbktleUlkPSR7c3RvcmVJZFtpbnRlcm9wQXBwSWQoKV19YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJydcclxuICAgICAgICB9KTtcclxuICAgICAgICBPYmplY3QuYXNzaWduKGJvZHksIHN0YXR1cyk7XHJcbiAgICAgICAgYm9keS5UcmFpbmluZ0lkID0gc3RvcmVJZFtpbnRlcm9wQXBwSWQoKV07XHJcbiAgICAgICAgYm9keS5DcmVhdGVkT24gPSAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnO1xyXG4gICAgICAgIGJvZHkuTW9kaWZpZWRPbiA9ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNyc7XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLm5hdmV0QXBpLFxyXG4gICAgICAgIGdldEFwcGxpY2F0aW9uc0J5SW5zdGFuY2VJZCxcclxuICAgICAgICBnZXRBcHBsaWNhdGlvbnMsXHJcbiAgICAgICAgZ2V0QXBwWmlwLFxyXG4gICAgICAgIGdldEFwcFN0YXR1cyxcclxuICAgICAgICBnZXRBcHBTdGF0dXNCeUluc3RhbmNlSWQsXHJcbiAgICAgICAgY3JlYXRlU3RhdHVzLFxyXG4gICAgICAgIHVwZGF0ZVN0YXR1cyxcclxuICAgICAgICBkZXN0cm95U3RhdHVzXHJcbiAgICB9O1xyXG59XHJcblxyXG5mdW5jdGlvbiB0b2tlbml6ZShhc1N0cmluZykge1xyXG4gICAgcmV0dXJuIGFzU3RyaW5nLnNwbGl0KCcgJykubWFwKHQgPT4gdC50cmltKCkpLmZpbHRlcih0ID0+IHQubGVuZ3RoID4gMCk7XHJcbn0iLCJpbXBvcnQgSlNPTjUgZnJvbSAnLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2pzb241L2Rpc3QvaW5kZXgubWluJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICgpIHtcclxuICAgIGNvbnN0IGhvc3QgPSAnaHR0cHM6Ly9pcy5uYXZldC5nb3Zlcm5tZW50LmJnL2Z1cmlhL1Byb2plY3RzL25hcG9vL2luZGV4Lm5ldy5waHAnO1xyXG5cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXQodXJsKSB7XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2godXJsKTtcclxuICAgICAgICBjb25zdCB0ZXh0ID0gYXdhaXQgcmVzLnRleHQoKTtcclxuICAgICAgICByZXR1cm4gdGV4dDtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBwb3N0Rm9ybSh1cmwsIGJvZHkpIHtcclxuICAgICAgICBPYmplY3QuYXNzaWduKGJvZHksIHsgYXBwbGljYXRpb246ICdBSkFYRGF0YVByb3ZpZGVyJywgbm9DYWNoZTogRGF0ZS5ub3coKSB9KTtcclxuICAgICAgICBjb25zdCBxdWVyeSA9IFtdO1xyXG4gICAgICAgIGZvciAobGV0IHBhcmFtIGluIGJvZHkpIHtcclxuICAgICAgICAgICAgcXVlcnkucHVzaChgJHtwYXJhbX09JHtlbmNvZGVVUklDb21wb25lbnQoYm9keVtwYXJhbV0pfWApO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCh1cmwsIHtcclxuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICdDb250ZW50LXR5cGUnOiAnYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkOyBjaGFyc2V0PXV0Zi04J1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBib2R5OiBxdWVyeS5qb2luKCcmJylcclxuICAgICAgICB9KTtcclxuICAgICAgICByZXR1cm4gcmVzLnRleHQoKTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBwYXJzZVJlc3BvbnNlKGRhdGEpIHtcclxuICAgICAgICBsZXQganNvbjtcclxuICAgICAgICBqc29uID0gSlNPTjUucGFyc2UoZGF0YSk7XHJcblxyXG4gICAgICAgIGlmIChqc29uLmhhc093blByb3BlcnR5KCdvYmonKSkge1xyXG4gICAgICAgICAgICByZXR1cm4gcGFyc2VPYmplY3QoanNvbi5vYmopO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoanNvbi5oYXNPd25Qcm9wZXJ0eSgnb2JqcycpKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBqc29uLm9ianMubWFwKHBhcnNlT2JqZWN0KTtcclxuICAgICAgICB9IGVsc2UgaWYgKGpzb24uaGFzT3duUHJvcGVydHkoJ2RhdGEnKSB8fCBqc29uLnN0YXR1cyAhPSAwKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBqc29uO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoanNvbik7XHJcbiAgICAgICAgICAgIGlmIChqc29uLnN0YXR1cyA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdZb3VyIHNlc3Npb24gaGFzIGV4cGlyZWQuIFBsZWFzZSBlbnRlciB5b3VyIGNyZWRlbnRpYWxzIGFnYWluLicpO1xyXG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdZb3VyIHNlc3Npb24gaGFzIGV4cGlyZWQuIFBsZWFzZSBlbnRlciB5b3VyIGNyZWRlbnRpYWxzIGFnYWluLicpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignVW5hYmxlIHRvIHBhcnNlIGRhdGE6IG5vIGtleXMgW29ial0gb3IgW29ianNdIGZvdW5kLiBTZWUgY29uc29sZSBmb3IgZGV0YWlscy4nKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZnVuY3Rpb24gcGFyc2VPYmplY3Qob2JqKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHBhcnNlZCA9IHt9O1xyXG4gICAgICAgICAgICBmb3IgKGxldCBwcm9wIGluIG9iaikge1xyXG4gICAgICAgICAgICAgICAgcGFyc2VkW3Byb3BdID0gb2JqW3Byb3BdLnZhbHVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiBwYXJzZWQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEV4dHJhQ291cnNlSW5mbyhpZCkge1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSB7XHJcbiAgICAgICAgICAgIGludm9rZTogYFRiQ291cnNlR3JvdXBzTWFuYWdlci5nZXRCeUNvdXJzZUdyb3VwSWQoJHtpZH0pYCxcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKGF3YWl0IHBvc3RGb3JtKGhvc3QsIGJvZHkpKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXROYXZldEN1cnJlbnRDb3Vyc2VzKCkge1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSB7XHJcbiAgICAgICAgICAgIGludm9rZTogJ1ZpZXdDb3Vyc2VHcm91cExpc3RNYW5hZ2VyLmN1c3RvbUdldEJ5UHJvdmlkZXJJZEFuZENvdXJzZVN0YXR1c0lkKDI5MjksMiknLFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UoYXdhaXQgcG9zdEZvcm0oaG9zdCwgYm9keSkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldE5hdmV0Q2xvc2VkQ291cnNlcygpIHtcclxuICAgICAgICBjb25zdCBib2R5ID0ge1xyXG4gICAgICAgICAgICBpbnZva2U6ICdWaWV3RmluaXNoZWRDb3Vyc2VHcm91cExpc3RNYW5hZ2VyLmN1c3RvbUdldEJ5UHJvdmlkZXJJZEFuZENvdXJzZVN0YXR1c0lkTm90QXJjaGl2ZWQoMjkyOSknLFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UoYXdhaXQgcG9zdEZvcm0oaG9zdCwgYm9keSkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldE5hdmV0QXJjaGl2ZWRDb3Vyc2VzKCkge1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSB7XHJcbiAgICAgICAgICAgIGludm9rZTogJ1ZpZXdGaW5pc2hlZENvdXJzZUdyb3VwTGlzdE1hbmFnZXIuY3VzdG9tR2V0QnlQcm92aWRlcklkQW5kQ291cnNlU3RhdHVzSWRBcmNoaXZlZCgyOTI5KScsXHJcbiAgICAgICAgfTtcclxuICAgICAgICByZXR1cm4gcGFyc2VSZXNwb25zZShhd2FpdCBwb3N0Rm9ybShob3N0LCBib2R5KSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRDb3Vyc2VJbmZvKGlkLCB0eXBlID0gJ2N1cnJlbnQnKSB7XHJcbiAgICAgICAgbGV0IGV4dHJhSW5mbyA9IGdldEV4dHJhQ291cnNlSW5mbyhpZCk7XHJcbiAgICAgICAgbGV0IGNvdXJzZUxpc3QgPSBbXTtcclxuICAgICAgICBzd2l0Y2ggKHR5cGUpIHtcclxuICAgICAgICAgICAgY2FzZSAnY3VycmVudCc6XHJcbiAgICAgICAgICAgICAgICBjb3Vyc2VMaXN0ID0gZ2V0TmF2ZXRDdXJyZW50Q291cnNlcygpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgJ2NvbmNsdWRlZCc6XHJcbiAgICAgICAgICAgICAgICBjb3Vyc2VMaXN0ID0gZ2V0TmF2ZXRDbG9zZWRDb3Vyc2VzKCk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSAnYXJjaGl2ZSc6XHJcbiAgICAgICAgICAgICAgICBjb3Vyc2VMaXN0ID0gZ2V0TmF2ZXRBcmNoaXZlZENvdXJzZXMoKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgICAgICBbZXh0cmFJbmZvLCBjb3Vyc2VMaXN0XSA9IGF3YWl0IFByb21pc2UuYWxsKFtleHRyYUluZm8sIGNvdXJzZUxpc3RdKTtcclxuICAgICAgICBjb25zdCBzZWxlY3RlZCA9IGNvdXJzZUxpc3QuZmluZChjID0+IGMuaWQgPT0gaWQpO1xyXG4gICAgICAgIHNlbGVjdGVkLl9leHRyYSA9IGV4dHJhSW5mb1swXTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHNlbGVjdGVkO1xyXG4gICAgfVxyXG5cclxuICAgIC8qIFJlcGxhY2VkLCBiZWNhdXNlIGl0IGRvZXNuJ3QgcHJvdmlkZSB0aGUgbmVjZXNzYXJ5IGluZm9ybWF0aW9uICovXHJcbiAgICAvKlxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRDb3Vyc2VJbmZvKGlkKSB7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHtcclxuICAgICAgICAgICAgaW52b2tlOiBgVmlld0NvdXJzZUluZm9NYW5hZ2VyLmdldEJ5SWQoJHtpZH0pYFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UoYXdhaXQgcG9zdEZvcm0oaG9zdCwgYm9keSkpO1xyXG4gICAgfVxyXG4gICAgKi9cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXROYXZldFN0dWRlbnRzKGlkKSB7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHtcclxuICAgICAgICAgICAgaW52b2tlOiBgVmlld0NsaWVudENvdXJzZXNNYW5hZ2VyLmdldEJ5Q291cnNlR3JvdXBJZCgke2lkfSlgXHJcbiAgICAgICAgfTtcclxuICAgICAgICByZXR1cm4gcGFyc2VSZXNwb25zZShhd2FpdCBwb3N0Rm9ybShob3N0LCBib2R5KSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRTdHVkZW50SW5mbyhjbGllbnRJZCkge1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSB7XHJcbiAgICAgICAgICAgIGludm9rZTogYFRiQ2xpZW50c01hbmFnZXIuZ2V0QnlJZCgke2NsaWVudElkfSlgLFxyXG4gICAgICAgICAgICBpZDogY2xpZW50SWRcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKGF3YWl0IHBvc3RGb3JtKGhvc3QsIGJvZHkpKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXROYXZldEV4aXN0aW5nRmlsZXMoY291cnNlSWQsIGlkKSB7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHtcclxuICAgICAgICAgICAgaW52b2tlOiBgVGJDbGllbnRzUmVxdWlyZWREb2N1bWVudHNNYW5hZ2VyLmN1c3RvbUdldFZhbGlkQnlDb3Vyc2VHcm91cEFuZENsaWVudCgke2NvdXJzZUlkfSwke2lkfSlgLFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UoYXdhaXQgcG9zdEZvcm0oaG9zdCwgYm9keSkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHVwbG9hZEZpbGUoZm9ybURhdGEpIHtcclxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBmZXRjaChob3N0LCB7XHJcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgICAgICBib2R5OiBmb3JtRGF0YVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjb25zdCBvdXRwdXQgPSBhd2FpdCByZXN1bHQudGV4dCgpO1xyXG4gICAgICAgIGlmIChvdXRwdXQuc2VhcmNoKC9zdGF0dXM6XFxzMC8pICE9IC0xKSB7XHJcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignWW91ciBzZXNzaW9uIGhhcyBleHBpcmVkLiBQbGVhc2UgZW50ZXIgeW91ciBjcmVkZW50aWFscyBhZ2Fpbi4nKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gb3V0cHV0O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB1cGxvYWRNZWRpY2FsKGNvdXJzZUlkLCBpZCwgZmlsZURlc2NyaXB0b3IpIHtcclxuICAgICAgICBsZXQgYmxvYjtcclxuICAgICAgICBsZXQgZmlsZW5hbWU7XHJcbiAgICAgICAgaWYgKGZpbGVEZXNjcmlwdG9yLmZpbGVVcmwgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICBibG9iID0gYXdhaXQgKGF3YWl0IGZldGNoKGZpbGVEZXNjcmlwdG9yLmZpbGVVcmwpKS5ibG9iKCk7XHJcbiAgICAgICAgICAgIGZpbGVuYW1lID0gZmlsZURlc2NyaXB0b3IubmFtZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBibG9iID0gZmlsZURlc2NyaXB0b3IuZmlsZTtcclxuICAgICAgICAgICAgZmlsZW5hbWUgPSBmaWxlRGVzY3JpcHRvci5maWxlLm5hbWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IGZvcm1EYXRhID0gbmV3IEZvcm1EYXRhKCk7XHJcblxyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaWQnLCBudWxsKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludF9jb3Vyc2VfZ3JvdXBfaWQnLCBjb3Vyc2VJZCk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpc192YWxpZCcsIHRydWUpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnb2lkX2ZpbGVfYWN0aW9uJywgJ3VwbG9hZCcpO1xyXG5cclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ29pZF9maWxlJywgYmxvYiwgZmlsZW5hbWUpO1xyXG5cclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludm9rZScsICdUYkNsaWVudHNSZXF1aXJlZERvY3VtZW50c01hbmFnZXIuY3JlYXRlT2JqZWN0KCknKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2FwcGxpY2F0aW9uJywgJ0FKQVhEYXRhUHJvdmlkZXInKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3Byb3RvY29sJywgJ2RhdGFJRnJhbWUnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ251bGwnLCAnJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnRfY29kZV9jb3Vyc2VfZ3JvdXBfcmVxdWlyZWRfZG9jdW1lbnRzX3R5cGVfaWQnLCAxKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludF9jbGllbnRfaWQnLCBpZCk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCd2Y19kZXNjaXB0aW9uJywgJ9C80LXQtNC40YbQuNC90YHQutC+IChhdXRvKScpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnZHRfZG9jdW1lbnRfZGF0ZScsICcnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX2RvY3VtZW50X3JlZ19ubycsICcnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX2RvY3VtZW50X3Bybl9ubycsICcnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2R0X2RvY3VtZW50X29mZmljaWFsX2RhdGUnLCAnJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdib29sX2JlZm9yZV9kYXRlJywgZmFsc2UpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaW50X2NvZGVfZXh0X3JlZ2lzdGVyX2lkJywgbnVsbCk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCd0aXRsZScsICc8ZGl2IGNsYXNzPVxcJ25hcG9vLXRpdGxlLWRhcmtcXCc+0JzQtdC00LjRhtC40L3RgdC60L4g0YHQstC40LTQtdGC0LXQu9GB0YLQstC+OjwvZGl2PicpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnYXN5bmNfaWZyYW1lX2lkJywgJ2FzeW5jX2lmcmFtZV8zMTUyJyk7XHJcblxyXG4gICAgICAgIHJldHVybiB1cGxvYWRGaWxlKGZvcm1EYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB1cGxvYWREaXBsb21hKGNvdXJzZUlkLCBpZCwgZmlsZURlc2NyaXB0b3IsIHJlZ19ubywgcHJuX25vLCBkb2NfZGF0ZSkge1xyXG4gICAgICAgIGxldCBibG9iO1xyXG4gICAgICAgIGxldCBmaWxlbmFtZTtcclxuICAgICAgICBpZiAoZmlsZURlc2NyaXB0b3IuZmlsZVVybCAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIGJsb2IgPSBhd2FpdCAoYXdhaXQgZmV0Y2goZmlsZURlc2NyaXB0b3IuZmlsZVVybCkpLmJsb2IoKTtcclxuICAgICAgICAgICAgZmlsZW5hbWUgPSBmaWxlRGVzY3JpcHRvci5uYW1lO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGJsb2IgPSBmaWxlRGVzY3JpcHRvci5maWxlO1xyXG4gICAgICAgICAgICBmaWxlbmFtZSA9IGZpbGVEZXNjcmlwdG9yLmZpbGUubmFtZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgZm9ybURhdGEgPSBuZXcgRm9ybURhdGEoKTtcclxuXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpZCcsIG51bGwpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaW50X2NvdXJzZV9ncm91cF9pZCcsIGNvdXJzZUlkKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2lzX3ZhbGlkJywgdHJ1ZSk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnRfY29kZV9lZHVjYXRpb25faWQnLCAzMSk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCczNDEtdGV4dCcsICfQt9Cw0LLRitGA0YjQtdC90L4g0YHRgNC10LTQvdC+INC+0LHRgNCw0LfQvtCy0LDQvdC40LUgKNC40LvQuCDQv9C+LdCy0LjRgdC+0LrQviknKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX2RvY3VtZW50X3JlZ19ubycsIHJlZ19ubyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCd2Y19kb2N1bWVudF9wcm5fbm8nLCBwcm5fbm8pO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnb2lkX2ZpbGVfYWN0aW9uJywgJ3VwbG9hZCcpO1xyXG5cclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ29pZF9maWxlJywgYmxvYiwgZmlsZW5hbWUpO1xyXG5cclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludm9rZScsICdUYkNsaWVudHNSZXF1aXJlZERvY3VtZW50c01hbmFnZXIuY3JlYXRlT2JqZWN0KCknKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2FwcGxpY2F0aW9uJywgJ0FKQVhEYXRhUHJvdmlkZXInKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3Byb3RvY29sJywgJ2RhdGFJRnJhbWUnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ251bGwnLCAnJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnRfY2xpZW50X2lkJywgaWQpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndmNfZGVzY2lwdGlvbicsICfQtNC40L/Qu9C+0LzQsCAoYXV0byknKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2R0X2RvY3VtZW50X2RhdGUnLCAnJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdkdF9kb2N1bWVudF9vZmZpY2lhbF9kYXRlJywgZG9jX2RhdGUpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnYm9vbF9iZWZvcmVfZGF0ZScsIGZhbHNlKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludF9jb2RlX2V4dF9yZWdpc3Rlcl9pZCcsIG51bGwpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndGl0bGUnLCAnPGRpdiBjbGFzcz1cXCduYXBvby10aXRsZS1kYXJrXFwnPtCS0YXQvtC00Y/RidC+INC80LjQvdC40LzQsNC70L3QviDQvtCx0YDQsNC30L7QstCw0YLQtdC70L3QviDRgNCw0LLQvdC40YnQtTo8L2Rpdj4nKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3Jlc3BJbmZvJywgJycpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnZXh0cmFJbmZvJywgJycpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnY2hlY2staW4tZWR1LWJ1dHRvbicsICfQn9GA0L7QstC10YDQuCDQsiDRgNC10LPQuNGB0YLRgNC40YLQtScpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnYXN5bmNfaWZyYW1lX2lkJywgJ2FzeW5jX2lmcmFtZV8zNzQnKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHVwbG9hZEZpbGUoZm9ybURhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIG9wZW5OYXZldEZpbGUoaWQpIHtcclxuICAgICAgICBjb25zdCB1cmwgPSBgJHtob3N0fT9hcHBsaWNhdGlvbj1BSkFYRGF0YVByb3ZpZGVyJmludm9rZT1UYkNsaWVudHNSZXF1aXJlZERvY3VtZW50c01hbmFnZXIuY3VzdG9tRG93bmxvYWRGaWxlKCR7aWR9LFwib2lkX2ZpbGVcIilgO1xyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKHVybCk7XHJcblxyXG4gICAgICAgIGNvbnN0IGJsb2IgPSBhd2FpdCByZXMuYmxvYigpO1xyXG4gICAgICAgIGNvbnN0IHNlcmlhbGl6ZWRCbG9iID0gbmV3IFVpbnQ4QXJyYXkoYXdhaXQgYmxvYi5hcnJheUJ1ZmZlcigpKTtcclxuICBcclxuICAgICAgICBsZXQgYmxvYkRhdGEgPSB7XHJcbiAgICAgICAgICAgIHR5cGU6IGJsb2IudHlwZSxcclxuICAgICAgICAgICAgYnVmZmVyOiBBcnJheS5mcm9tKHNlcmlhbGl6ZWRCbG9iKVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHJldHVybiBibG9iRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBkZWxldGVOYXZldEZpbGUoaWQpIHtcclxuICAgICAgICBjb25zdCBib2R5ID0ge1xyXG4gICAgICAgICAgICBpbnZva2U6IGBUYkNsaWVudHNSZXF1aXJlZERvY3VtZW50c01hbmFnZXIuY3VzdG9tU2V0VG9GYWxzZSgke2lkfSlgLFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UoYXdhaXQgcG9zdEZvcm0oaG9zdCwgYm9keSkpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKiBFeHBlcmltZW50YWwgKi9cclxuICAgIGFzeW5jIGZ1bmN0aW9uIG5hdmV0TG9naW4odXNlcm5hbWUsIHBhc3N3b3JkKSB7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHtcclxuICAgICAgICAgICAgcmVzcG9uc2U6ICdjbGllbnQnLFxyXG4gICAgICAgICAgICByZXF1ZXN0OiAnbG9naW4nLFxyXG4gICAgICAgICAgICB1c2VybmFtZSxcclxuICAgICAgICAgICAgcGFzc3dvcmRcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBjb25zdCBoZWFkZXIgPSBlbmNvZGVVUklDb21wb25lbnQoSlNPTi5zdHJpbmdpZnkoYm9keSkpO1xyXG5cclxuICAgICAgICBjb25zdCB1cmwgPSAnL3Jlc3BvbnNlJztcclxuXHJcbiAgICAgICAgbGV0IHJlcXVlc3QgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcclxuICAgICAgICByZXF1ZXN0Lm9ucmVhZHlzdGF0ZWNoYW5nZSA9ICgpID0+IHtcclxuICAgICAgICAgICAgaWYgKHJlcXVlc3QucmVhZHlTdGF0ZSA9PSA0ICYmIChyZXF1ZXN0LnN0YXR1cyA9PSAyMDAgfHwgd2luZG93LmxvY2F0aW9uLmhyZWYuaW5kZXhPZignaHR0cCcpID09IC0xKSkge1xyXG4gICAgICAgICAgICAgICAgbGV0IHVkYXQgPSBKU09OLnBhcnNlKHJlcXVlc3QucmVzcG9uc2VUZXh0KTtcclxuICAgICAgICAgICAgICAgIGlmICh1ZGF0LnN0YXR1cyA9PSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSAnLyc7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignRXJyb3I6ICcgKyB1ZGF0LmVycm9yX2NvZGUpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgcmVxdWVzdCA9IG51bGw7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBjb25zdCBjYWNoZSA9ICc/JyArIG5ldyBEYXRlKCkuZ2V0VGltZSgpO1xyXG4gICAgICAgIHJlcXVlc3Qub3BlbignR0VUJywgdXJsICsgY2FjaGUsIHRydWUpO1xyXG4gICAgICAgIHJlcXVlc3Quc2V0UmVxdWVzdEhlYWRlcignQUNDU1NDVFJMJywgaGVhZGVyKTtcclxuICAgICAgICByZXF1ZXN0LnNlbmQobnVsbCk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0R3JhZHVhdGVJbmZvKGlkKSB7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHtcclxuICAgICAgICAgICAgaW52b2tlOiBgUmVmQ2xpZW50c0NvdXJzZXNNYW5hZ2VyLmdldEJ5SWQoJHtpZH0pYCxcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKGF3YWl0IHBvc3RGb3JtKGhvc3QsIGJvZHkpKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXROYXZldENlcnRpZmljYXRlKGlkKSB7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHtcclxuICAgICAgICAgICAgaW52b2tlOiBgVmlld0NsaWVudHNDb3Vyc2VzRG9jdW1lbnRzTWFuYWdlci5nZXRCeUNsaWVudENvdXJzZXNJZCgke2lkfSlgLFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UoYXdhaXQgcG9zdEZvcm0oaG9zdCwgYm9keSkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIG9wZW5OYXZldENlcnRpZmljYXRlKGlkLCBwYWdlKSB7XHJcbiAgICAgICAgY29uc3QgdXJsID0gYCR7aG9zdH0/YXBwbGljYXRpb249QUpBWERhdGFQcm92aWRlciZpbnZva2U9VGJDbGllbnRzQ291cnNlc0RvY3VtZW50c01hbmFnZXIuY3VzdG9tRG93bmxvYWRGaWxlKCR7aWR9LCBcImRvY3VtZW50XyR7cGFnZX1fZmlsZVwiKWA7XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2godXJsKTtcclxuICAgICAgICBjb25zdCBibG9iID0gYXdhaXQgcmVzLmJsb2IoKTtcclxuICAgICAgICBpZiAoYmxvYi50eXBlID09ICd0ZXh0L2phdmFzY3JpcHQnKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1lvdXIgc2Vzc2lvbiBoYXMgZXhwaXJlZC4gUGxlYXNlIGVudGVyIHlvdXIgY3JlZGVudGlhbHMgYWdhaW4uJyk7XHJcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignWW91ciBzZXNzaW9uIGhhcyBleHBpcmVkLiBQbGVhc2UgZW50ZXIgeW91ciBjcmVkZW50aWFscyBhZ2Fpbi4nKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IHNlcmlhbGl6ZWRCbG9iID0gbmV3IFVpbnQ4QXJyYXkoYXdhaXQgYmxvYi5hcnJheUJ1ZmZlcigpKTtcclxuICBcclxuICAgICAgICBsZXQgYmxvYkRhdGEgPSB7XHJcbiAgICAgICAgICAgIHR5cGU6IGJsb2IudHlwZSxcclxuICAgICAgICAgICAgYnVmZmVyOiBBcnJheS5mcm9tKHNlcmlhbGl6ZWRCbG9iKVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHJldHVybiBibG9iRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB1cGxvYWROYXZldENlcnRpZmljYXRlKG1ldGEsIGZpbGVEZXNjcmlwdG9ycykge1xyXG4gICAgICAgIGNvbnN0IGZpbGVzID0gYXdhaXQgUHJvbWlzZS5hbGwoZmlsZURlc2NyaXB0b3JzLm1hcChhc3luYyBkZXNjcmlwdG9yID0+IHtcclxuICAgICAgICAgICAgaWYgKGRlc2NyaXB0b3IgPT09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKGRlc2NyaXB0b3IuZmlsZVVybCAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGJsb2I6IGF3YWl0IChhd2FpdCBmZXRjaChkZXNjcmlwdG9yLmZpbGVVcmwpKS5ibG9iKCksXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsZW5hbWU6IGRlc2NyaXB0b3IubmFtZVxyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAgICAgYmxvYjogZGVzY3JpcHRvci5maWxlLFxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGVuYW1lOiBkZXNjcmlwdG9yLmZpbGUubmFtZVxyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKTtcclxuXHJcblxyXG4gICAgICAgIGNvbnN0IGZvcm1EYXRhID0gbmV3IEZvcm1EYXRhKCk7XHJcblxyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaWQnLCBtZXRhLmlkKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludF9jbGllbnRzX2NvdXJzZXNfaWQnLCBtZXRhLmludF9jbGllbnRzX2NvdXJzZXNfaWQpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaW50X2RvY3VtZW50X3R5cGVfaWQnLCBtZXRhLmludF9kb2N1bWVudF90eXBlX2lkKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJzYwOC10ZXh0JywgJ9Cj0LTQvtGB0YLQvtCy0LXRgNC10L3QuNC1INC30LAg0L/RgNC+0YTQtdGB0LjQvtC90LDQu9C90L4g0L7QsdGD0YfQtdC90LjQtScpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaW50X2NvdXJzZV9maW5pc2hlZF95ZWFyJywgbWV0YS5pbnRfY291cnNlX2ZpbmlzaGVkX3llYXIpOyAvLyBuZWVkIHRoaXMgYWRkZWRcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX2RvY3VtZW50X3Bybl9ubycsICcnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJzYxMi10ZXh0JywgJycpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndmNfb3JpZ2luYWxfcHJuX25vJywgbWV0YS52Y19kb2N1bWVudF9wcm5fbm8pO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndmNfZG9jdW1lbnRfcmVnX25vJywgbWV0YS52Y19kb2N1bWVudF9yZWdfbm8pOyAvLyBuZWVkIHRoaXMgYWRkZWRcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX2RvY3VtZW50X3Byb3QnLCBtZXRhLnZjX2RvY3VtZW50X3Byb3QpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnbnVtX3RoZW9yeV9yZXN1bHQnLCBtZXRhLm51bV90aGVvcnlfcmVzdWx0KTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ251bV9wcmFjdGljZV9yZXN1bHQnLCBtZXRhLm51bV9wcmFjdGljZV9yZXN1bHQpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndmNfcXVhbGlmaWNhdGlvbl9uYW1lJywgbWV0YS52Y19xdWFsaWZpY2F0aW9uX25hbWUpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndmNfcXVhbGlmaWNhdGlval9sZXZlbCcsIG1ldGEudmNfcXVhbGlmaWNhdGlval9sZXZlbCk7XHJcblxyXG4gICAgICAgIGlmIChmaWxlc1swXSAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2RvY3VtZW50XzFfZmlsZV9hY3Rpb24nLCAndXBsb2FkJyk7XHJcbiAgICAgICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnZG9jdW1lbnRfMV9maWxlJywgZmlsZXNbMF0uYmxvYiwgZmlsZXNbMF0uZmlsZW5hbWUpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnZG9jdW1lbnRfMV9maWxlX2FjdGlvbicsICcnKTtcclxuICAgICAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdkb2N1bWVudF8xX2ZpbGUnLCBuZXcgQmxvYihbJyddKSwgJycpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGZpbGVzWzFdICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnZG9jdW1lbnRfMl9maWxlX2FjdGlvbicsICd1cGxvYWQnKTtcclxuICAgICAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdkb2N1bWVudF8yX2ZpbGUnLCBmaWxlc1sxXS5ibG9iLCBmaWxlc1sxXS5maWxlbmFtZSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdkb2N1bWVudF8yX2ZpbGVfYWN0aW9uJywgJycpO1xyXG4gICAgICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2RvY3VtZW50XzJfZmlsZScsIG5ldyBCbG9iKFsnJ10pLCAnJyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludm9rZScsIGBUYkNsaWVudHNDb3Vyc2VzRG9jdW1lbnRzTWFuYWdlci51cGRhdGVPYmplY3QoJHttZXRhLmlkfSlgKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2FwcGxpY2F0aW9uJywgJ0FKQVhEYXRhUHJvdmlkZXInKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3Byb3RvY29sJywgJ2RhdGFJRnJhbWUnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2R0X2RvY3VtZW50X2RhdGUnLCBtZXRhLmR0X2RvY3VtZW50X2RhdGUpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndmNfZG9jdW1lbnRfdHlwZV9uYW1lJywgbWV0YS52Y19kb2N1bWVudF90eXBlX25hbWUpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaW50X2RvY3VtZW50X3N0YXR1cycsIG1ldGEuaW50X2RvY3VtZW50X3N0YXR1cyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdib29sX3dpdGhfbm90ZScsIG1ldGEuYm9vbF93aXRoX25vdGUpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnYXN5bmNfaWZyYW1lX2lkJywgJ2FzeW5jX2lmcmFtZV82MzknKTtcclxuXHJcblxyXG4gICAgICAgIHJldHVybiB1cGxvYWRGaWxlKGZvcm1EYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB1cGRhdGVOYXZldFN0dWRlbnQoaWQsIHN0dWRlbnQpIHtcclxuICAgICAgICBjb25zdCBib2R5ID0gT2JqZWN0LmFzc2lnbih7fSwgc3R1ZGVudCwge1xyXG4gICAgICAgICAgICBpbnZva2U6IGBSZWZDbGllbnRzQ291cnNlc01hbmFnZXIudXBkYXRlT2JqZWN0KCR7aWR9KWAsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UoYXdhaXQgcG9zdEZvcm0oaG9zdCwgYm9keSkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZURvY3VtZW50KHN0dWRlbnRJZCwgY2xpZW50SWQsIGRhdGEpIHtcclxuICAgICAgICBjb25zdCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaWQnLCBudWxsKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludF9jbGllbnRzX2NvdXJzZXNfaWQnLCBudWxsKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludF9kb2N1bWVudF90eXBlX2lkJywgJycpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnMzA0LXRleHQnLCAn0KPQtNC+0YHRgtC+0LLQtdGA0LXQvdC40LUg0LfQsCDQv9GA0L7RhNC10YHQuNC+0L3QsNC70L3QviDQvtCx0YPRh9C10L3QuNC1Jyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnRfY291cnNlX2ZpbmlzaGVkX3llYXInLCBkYXRhLmludF9jb3Vyc2VfZmluaXNoZWRfeWVhcik7IC8vIG5lZWQgdGhpcyBhZGRlZFxyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndmNfZG9jdW1lbnRfcHJuX25vJywgJycpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnMzA4LXRleHQnLCAnJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCd2Y19kb2N1bWVudF9yZWdfbm8nLCBkYXRhLnZjX2RvY3VtZW50X3JlZ19ubyk7IC8vIG5lZWQgdGhpcyBhZGRlZFxyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndmNfZG9jdW1lbnRfcHJvdCcsICcnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ251bV90aGVvcnlfcmVzdWx0JywgMCk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdudW1fcHJhY3RpY2VfcmVzdWx0JywgMCk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCd2Y19xdWFsaWZpY2F0aW9uX25hbWUnLCAnJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCd2Y19xdWFsaWZpY2F0aW9qX2xldmVsJywgJycpO1xyXG5cclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2RvY3VtZW50XzFfZmlsZV9hY3Rpb24nLCAnJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdkb2N1bWVudF8xX2ZpbGUnLCBuZXcgQmxvYihbJyddKSwgJycpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnZG9jdW1lbnRfMl9maWxlX2FjdGlvbicsICcnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2RvY3VtZW50XzJfZmlsZScsIG5ldyBCbG9iKFsnJ10pLCAnJyk7XHJcblxyXG4gICAgICAgIFxyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaW52b2tlJywgJ0N1c3RvbUV2ZW50c01hbmFnZXIuY3VzdG9tVGJDbGllbnRzQ291cnNlc0RvY3VtZW50cygxKScpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnYXBwbGljYXRpb24nLCAnQUpBWERhdGFQcm92aWRlcicpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgncHJvdG9jb2wnLCAnZGF0YUlGcmFtZScpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaW50X3Byb3ZpZGVyX2lkJywgMjkyOSk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdyZWZfY2xpZW50c19jb3Vyc2VzX2lkX3QnLCBzdHVkZW50SWQpOyAvL2RhdGEuaWRcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3RiX2NsaWVudHNfaWRfdCcsIGNsaWVudElkKTsgLy9kYXRhLmludF9jbGllbnRfaWRcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2R0X2RvY3VtZW50X2RhdGVfdCcsICcnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludF9jbGllbnRfY291cnNlX2lkX3QnLCBzdHVkZW50SWQpOyAvL2RhdGEuaWRcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludF9kb2N1bWVudF90eXBlX2lkX3QnLCAyKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX2RvY3VtZW50X3Bybl9ub190JywgJycpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndmNfZG9jdW1lbnRfcmVnX25vX3QnLCBkYXRhLnZjX2RvY3VtZW50X3JlZ19ubyk7IC8vIG5lZWQgdGhpcyBhZGRlZCwgc2FtZSBhcyBhYm92ZVxyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaW50X2RvY3VtZW50X3N0YXR1cycsIDApO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnYXN5bmNfaWZyYW1lX2lkJywgJ2FzeW5jX2lmcmFtZV8zMjknKTtcclxuXHJcblxyXG4gICAgICAgIHJldHVybiB1cGxvYWRGaWxlKGZvcm1EYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldE5hdmV0Q3VycmVudENvdXJzZXMsXHJcbiAgICAgICAgZ2V0TmF2ZXRDbG9zZWRDb3Vyc2VzLFxyXG4gICAgICAgIGdldE5hdmV0QXJjaGl2ZWRDb3Vyc2VzLFxyXG4gICAgICAgIGdldE5hdmV0Q291cnNlSW5mbyxcclxuICAgICAgICBnZXROYXZldFN0dWRlbnRzLFxyXG4gICAgICAgIGdldE5hdmV0U3R1ZGVudEluZm8sXHJcbiAgICAgICAgZ2V0TmF2ZXRFeGlzdGluZ0ZpbGVzLFxyXG4gICAgICAgIHVwbG9hZE1lZGljYWwsXHJcbiAgICAgICAgdXBsb2FkRGlwbG9tYSxcclxuICAgICAgICBvcGVuTmF2ZXRGaWxlLFxyXG4gICAgICAgIGRlbGV0ZU5hdmV0RmlsZSxcclxuICAgICAgICBnZXRHcmFkdWF0ZUluZm8sXHJcbiAgICAgICAgZ2V0TmF2ZXRDZXJ0aWZpY2F0ZSxcclxuICAgICAgICBvcGVuTmF2ZXRDZXJ0aWZpY2F0ZSxcclxuICAgICAgICB1cGxvYWROYXZldENlcnRpZmljYXRlLFxyXG4gICAgICAgIHVwZGF0ZU5hdmV0U3R1ZGVudCxcclxuICAgICAgICBjcmVhdGVEb2N1bWVudCxcclxuICAgICAgICBnZXRFeHRyYUNvdXJzZUluZm9cclxuICAgIH07XHJcbn0iLCJpbXBvcnQgeyBDb250ZW50VHlwZSB9IGZyb20gXCIuLi8uLi91dGlsL2NvbnRlbnRUeXBlcy5qc1wiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQsIGludGVyb3BQbGF0Zm9ybUhvc3QsIGludGVyb3BBZG1pbkFscGhhSnVkZ2VIb3N0IH0pIHtcclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldENvbnRlc3RDb21wZXRlUmVzdWx0cyhjb250ZXN0SWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBgJHtpbnRlcm9wQWRtaW5BbHBoYUp1ZGdlSG9zdCgpfS9hcGkvY29udGVzdHMvRXhwb3J0UmVzdWx0c2A7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHtcclxuICAgICAgICAgICAgaWQ6IGNvbnRlc3RJZCxcclxuICAgICAgICAgICAgdHlwZTogMCAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgbGV0IGJsb2IgPSBhd2FpdCBwb3N0KHVyaSwgYm9keSwgQ29udGVudFR5cGUuQXBwbGljYXRpb25Kc29uLCB0cnVlKTtcclxuICAgICAgICBjb25zdCBzZXJpYWxpemVkQmxvYiA9IG5ldyBVaW50OEFycmF5KGF3YWl0IGJsb2IuYXJyYXlCdWZmZXIoKSk7XHJcbiAgICAgICAgY29uc3QgYmxvYkRhdGEgPSB7XHJcbiAgICAgICAgICAgIHR5cGU6IGJsb2IudHlwZSxcclxuICAgICAgICAgICAgZmlsZW5hbWU6IGJsb2IuZmlsZW5hbWUsXHJcbiAgICAgICAgICAgIGJ1ZmZlcjogQXJyYXkuZnJvbShzZXJpYWxpemVkQmxvYilcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICByZXR1cm4gYmxvYkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0Q29udGVzdFByYWN0aWNlUmVzdWx0cyhjb250ZXN0SWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBgJHtpbnRlcm9wQWRtaW5BbHBoYUp1ZGdlSG9zdCgpfS9hcGkvY29udGVzdHMvRXhwb3J0UmVzdWx0c2A7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHtcclxuICAgICAgICAgICAgaWQ6IGNvbnRlc3RJZCxcclxuICAgICAgICAgICAgdHlwZTogMSAgICAgICAgICAgICAgICBcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBsZXQgYmxvYiA9IGF3YWl0IHBvc3QodXJpLCBib2R5LCBDb250ZW50VHlwZS5BcHBsaWNhdGlvbkpzb24sIHRydWUpO1xyXG4gICAgICAgIGNvbnN0IHNlcmlhbGl6ZWRCbG9iID0gbmV3IFVpbnQ4QXJyYXkoYXdhaXQgYmxvYi5hcnJheUJ1ZmZlcigpKTtcclxuICAgICAgICBjb25zdCBibG9iRGF0YSA9IHtcclxuICAgICAgICAgICAgdHlwZTogYmxvYi50eXBlLFxyXG4gICAgICAgICAgICBmaWxlbmFtZTogYmxvYi5maWxlbmFtZSxcclxuICAgICAgICAgICAgYnVmZmVyOiBBcnJheS5mcm9tKHNlcmlhbGl6ZWRCbG9iKVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHJldHVybiBibG9iRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldENvbnRlc3RDb21wZXRlUmVzdWx0cyxcclxuICAgICAgICBnZXRDb250ZXN0UHJhY3RpY2VSZXN1bHRzXHJcbiAgICB9O1xyXG59IiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0IH0pIHtcclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldE1vZHVsZXNJblByb2Zlc3Npb24ocHJvZmVzc2lvbklkKSB7XHJcbiAgICAgICAgY29uc3QgdXJsID0gKCgpID0+IHtcclxuICAgICAgICAgICAgaWYgKGludGVyb3BBcHBJZCgpID09PSAnc29mdHVuaS5iZycpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fcHJvZmVzc2lvbnMvbGV2ZWxncm91cHNpbnByb2Zlc3Npb25pbnN0YW5jZXMvcmVhZD9mb3JlaWduS2V5SWQ9JHtwcm9mZXNzaW9uSWR9YCk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gaW50ZXJvcEhvc3QoYEFkbWluaXN0cmF0aW9uX1Byb2Zlc3Npb25zL0NvdXJzZUdyb3Vwc0luUHJvZmVzc2lvbkluc3RhbmNlcy9SZWFkP2ZvcmVpZ25LZXlJZD0ke3Byb2Zlc3Npb25JZH1gKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDBcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJsLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRNb2R1bGVzKCkge1xyXG4gICAgICAgIGNvbnN0IHVybCA9ICBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fTGV2ZWxzL2xldmVscy9yZWFkJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmwsIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEluc3RhbmNlc0luTW9kdWxlKG1vZHVsZUlkKSB7XHJcbiAgICAgICAgY29uc3QgdXJsID0gKCgpID0+IHtcclxuICAgICAgICAgICAgaWYgKGludGVyb3BBcHBJZCgpID09PSAnc29mdHVuaS5iZycpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fbGV2ZWxzL2xldmVsaW5zdGFuY2VzL3JlYWQ/aW1wb3J0TGV2ZWxJZD0ke21vZHVsZUlkfSZsZXZlbElkPSR7bW9kdWxlSWR9YCk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gaW50ZXJvcEhvc3QoYEFkbWluaXN0cmF0aW9uX0xldmVscy9MZXZlbEluc3RhbmNlcy9SZWFkP2ltcG9ydExldmVsSWQ9JHttb2R1bGVJZH0mbGV2ZWxJZD0ke21vZHVsZUlkfSZmb3JlaWduS2V5SWQ9JHttb2R1bGVJZH1gKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVybCwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0SW5zdGFuY2VJbk1vZHVsZShtb2R1bGVJZCwgbW9kdWxlSW5zdGFuY2VJZCkge1xyXG4gICAgICAgIGNvbnN0IHVybCA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChpbnRlcm9wQXBwSWQoKSA9PT0gJ3NvZnR1bmkuYmcnKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX2xldmVscy9sZXZlbGluc3RhbmNlcy9yZWFkP2ltcG9ydExldmVsSWQ9JHttb2R1bGVJZH0mbGV2ZWxJZD0ke21vZHVsZUlkfWApO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGludGVyb3BIb3N0KGBBZG1pbmlzdHJhdGlvbl9MZXZlbHMvTGV2ZWxJbnN0YW5jZXMvUmVhZD9pbXBvcnRMZXZlbElkPSR7bW9kdWxlSWR9JmxldmVsSWQ9JHttb2R1bGVJZH0mZm9yZWlnbktleUlkPSR7bW9kdWxlSWR9YCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KSgpO1xyXG5cclxuICAgICAgICBsZXQgZmlsdGVyID0gYElkfmVxfiR7bW9kdWxlSW5zdGFuY2VJZH1gO1xyXG5cclxuICAgICAgICBpZihBcnJheS5pc0FycmF5KG1vZHVsZUluc3RhbmNlSWQpKSB7XHJcbiAgICAgICAgICAgIGZpbHRlciA9IGBJZH5lcX4ke21vZHVsZUluc3RhbmNlSWQuam9pbignfm9yfklkfmVxficpfWA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMCxcclxuICAgICAgICAgICAgZmlsdGVyOiBmaWx0ZXJcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJsLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBzZWFyY2hNb2R1bGVzKHF1ZXJ5KSB7XHJcbiAgICAgICAgY29uc3QgdXJsID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX2xldmVscy9sZXZlbHMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9IGBOYW1lQmd+Y29udGFpbnN+JyR7cXVlcnkuc3BsaXQoJyAnKS5maWx0ZXIocyA9PiBzLmxlbmd0aCA+IDApLmpvaW4oJ1xcJ35hbmR+TmFtZUJnfmNvbnRhaW5zflxcJycpfSdgO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwLFxyXG4gICAgICAgICAgICBmaWx0ZXIsXHJcbiAgICAgICAgICAgIHNvcnQ6ICdDcmVhdGVkT24tZGVzYydcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVybCwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBnZXRNb2R1bGVzSW5Qcm9mZXNzaW9uLFxyXG4gICAgICAgIGdldE1vZHVsZXMsXHJcbiAgICAgICAgZ2V0SW5zdGFuY2VzSW5Nb2R1bGUsXHJcbiAgICAgICAgc2VhcmNoTW9kdWxlcyxcclxuICAgICAgICBnZXRJbnN0YW5jZUluTW9kdWxlXHJcbiAgICB9O1xyXG59IiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQsIGludGVyb3BQbGF0Zm9ybUhvc3QgfSkge1xyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0UGF5bWVudHNGb3JQYWNrYWdlKHBhY2thZ2VOYW1lKSB7XHJcbiAgICAgICAgLy8gVGhpcyBmaWVsZCBkb2VzIG5vdCB3b3JrIHdpdGggbXVsdGlwbGUgdmFsdWVzXHJcbiAgICAgICAgLypcclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSAoKCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShwYWNrYWdlSWQpKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gYFBheW1lbnRQYWNrYWdlc0FzU3RyaW5nfmVxficke3BhY2thZ2VJZC5qb2luKCdcXCd+b3J+UGF5bWVudFBhY2thZ2VzQXNTdHJpbmd+ZXF+XFwnJyl9J2A7XHJcbiAgICAgICAgICAgICAgICAvL3JldHVybiBgUGF5bWVudFN0YXR1c35lcX40fmFuZH4oUGF5bWVudFBhY2thZ2VzQXNTdHJpbmd+ZXF+JyR7cGFja2FnZUlkLmpvaW4oJ1xcJ35vcn5QYXltZW50UGFja2FnZXNBc1N0cmluZ35lcX5cXCcnKX0nKWA7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gYFBheW1lbnRQYWNrYWdlc0FzU3RyaW5nfmVxficke3BhY2thZ2VJZH0nYDtcclxuICAgICAgICAgICAgICAgIC8vcmV0dXJuIGBQYXltZW50U3RhdHVzfmVxfjR+YW5kflBheW1lbnRQYWNrYWdlc0FzU3RyaW5nfmVxfiR7cGFja2FnZUlkfWA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KSgpO1xyXG4gICAgICAgICovXHJcblxyXG4gICAgICAgIGNvbnN0IHVybCA9IGAke2ludGVyb3BQbGF0Zm9ybUhvc3QoKX0vYWRtaW5pc3RyYXRpb24vcGF5bWVudHMvcmVhZD9hcHBJZD0ke2ludGVyb3BBcHBJZCgpfWA7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwMCxcclxuICAgICAgICAgICAgZmlsdGVyOiBgUGF5bWVudFN0YXR1c35lcX40fmFuZH5QYXltZW50UGFja2FnZXNBc1N0cmluZ35lcX4nJHtwYWNrYWdlTmFtZX0nYFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmwsIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFBhY2thZ2VzRm9yUHJvZHVjdChwcm9kdWN0SWQpIHtcclxuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShwcm9kdWN0SWQpICYmIHByb2R1Y3RJZC5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuIHsgRGF0YTogW10gfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgZmlsdGVyID0gKCgpID0+IHtcclxuICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkocHJvZHVjdElkKSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGBOYW1lfmRvZXNub3Rjb250YWlufidJSSd+YW5kfihQcm9kdWN0LklkfmVxfiR7cHJvZHVjdElkLmpvaW4oJ35vcn5Qcm9kdWN0LklkfmVxficpfSlgO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGBOYW1lfmRvZXNub3Rjb250YWlufidJSSd+YW5kflByb2R1Y3QuSWR+ZXF+JHtwcm9kdWN0SWR9YDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKCk7XHJcbiAgICAgICAgY29uc3QgdXJsID0gYCR7aW50ZXJvcFBsYXRmb3JtSG9zdCgpfS9hZG1pbmlzdHJhdGlvbi9wYXltZW50cGFja2FnZXMvcmVhZD9hcHBJZD0ke2ludGVyb3BBcHBJZCgpfWA7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwLFxyXG4gICAgICAgICAgICBmaWx0ZXJcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJsLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRQcm9kdWN0c0Zvck1vZHVsZShtb2R1bGVJZCkge1xyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KG1vZHVsZUlkKSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGBOYW1lfmRvZXNub3Rjb250YWlufidJSSd+YW5kfihMZXZlbEluc3RhbmNlSWR+ZXF+JHttb2R1bGVJZC5qb2luKCd+b3J+TGV2ZWxJbnN0YW5jZUlkfmVxficpfSlgO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGBOYW1lfmRvZXNub3Rjb250YWlufidJSSd+YW5kfkxldmVsSW5zdGFuY2VJZH5lcX4ke21vZHVsZUlkfWA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KSgpO1xyXG4gICAgICAgIGNvbnN0IHVybCA9IGAke2ludGVyb3BQbGF0Zm9ybUhvc3QoKX0vYWRtaW5pc3RyYXRpb24vbGV2ZWxpbnN0YW5jZXByb2R1Y3RzL3JlYWQ/YXBwSWQ9JHtpbnRlcm9wQXBwSWQoKX1gO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMCxcclxuICAgICAgICAgICAgZmlsdGVyXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVybCwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0UHJvZHVjdHNGb3JDb3Vyc2UoaW5zdGFuY2VJZCwgdHlwZSA9ICdvcGVuJykge1xyXG4gICAgICAgIGNvbnN0IGVwU3RyaW5ncyA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAodHlwZSkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAnb3Blbic6XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogJ2Zhc3R0cmFja2luc3RhbmNlcHJvZHVjdHMnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXJhbTogJ0Zhc3RUcmFja0luc3RhbmNlSWQnXHJcbiAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKCk7XHJcbiAgICAgICAgY29uc3QgZmlsdGVyID0gKCgpID0+IHtcclxuICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoaW5zdGFuY2VJZCkpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBgKCR7ZXBTdHJpbmdzLnBhcmFtfX5lcX4ke2luc3RhbmNlSWQuam9pbihgfm9yfiR7ZXBTdHJpbmdzLnBhcmFtfX5lcX5gKX0pYDtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBgJHtlcFN0cmluZ3MucGFyYW19fmVxfiR7aW5zdGFuY2VJZH1gO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSkoKTtcclxuICAgICAgICBjb25zdCB1cmwgPSBgJHtpbnRlcm9wUGxhdGZvcm1Ib3N0KCl9L2FkbWluaXN0cmF0aW9uLyR7ZXBTdHJpbmdzLnBhdGh9L3JlYWQ/YXBwSWQ9JHtpbnRlcm9wQXBwSWQoKX1gO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMCxcclxuICAgICAgICAgICAgZmlsdGVyXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVybCwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBnZXRQYXltZW50c0ZvclBhY2thZ2UsXHJcbiAgICAgICAgZ2V0UGFja2FnZXNGb3JQcm9kdWN0LFxyXG4gICAgICAgIGdldFByb2R1Y3RzRm9yTW9kdWxlLFxyXG4gICAgICAgIGdldFByb2R1Y3RzRm9yQ291cnNlXHJcbiAgICB9O1xyXG59IiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSkge1xyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVF1aXpJbnN0YW5jZShwYXlsb2FkKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3Rlc3RzeXN0ZW0vdGVzdHMvY3JlYXRlJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiAwLFxyXG4gICAgICAgICAgICBOYW1lOiBwYXlsb2FkLm5hbWUsXHJcbiAgICAgICAgICAgIERlc2NyaXB0aW9uOiBwYXlsb2FkLmRlc2NyaXB0aW9uLFxyXG4gICAgICAgICAgICBRdWVzdGlvbnNDb3VudDogMFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gYXdhaXQgcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGFkZFF1ZXN0aW9uKHF1aXpJZCwgcXVlc3Rpb24pIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdGVzdHN5c3RlbS90ZXN0cXVlc3Rpb25zL2NyZWF0ZT9mb3JlaWduS2V5SWQ9JHtxdWl6SWR9YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiAwLFxyXG4gICAgICAgICAgICBUeXBlOiAxLFxyXG4gICAgICAgICAgICBDb250ZW50OiBxdWVzdGlvbixcclxuICAgICAgICAgICAgQ29ycmVjdEFuc3dlclBvaW50czogMSxcclxuICAgICAgICAgICAgV3JvbmdBbnN3ZXJQb2ludHM6IDAsXHJcbiAgICAgICAgICAgIEtlZXBBbnN3ZXJzT3JkZXI6IGZhbHNlLFxyXG4gICAgICAgICAgICBTaG93Q29ycmVjdEFuc3dlcnNDb3VudDogZmFsc2UsXHJcbiAgICAgICAgICAgIENvcnJlY3RDb3VudDogMCxcclxuICAgICAgICAgICAgV3JvbmdDb3VudDogMCxcclxuICAgICAgICAgICAgQWxsQ291bnQ6IDAsXHJcbiAgICAgICAgICAgIFBlcmNlbnRDb3JyZWN0OiAwXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBhd2FpdCBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gYWRkQW5zd2VyKHF1ZXN0aW9uSWQsIGFuc3dlciwgaXNDb3JyZWN0KSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3Rlc3RzeXN0ZW0vdGVzdHF1ZXN0aW9uYW5zd2Vycy9jcmVhdGU/Zm9yZWlnbktleUlkPSR7cXVlc3Rpb25JZH1gKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgSWQ6IDAsXHJcbiAgICAgICAgICAgIFF1ZXN0aW9uSWQ6IDAsXHJcbiAgICAgICAgICAgIENvbnRlbnQ6IGFuc3dlcixcclxuICAgICAgICAgICAgSXNDb3JyZWN0OiBpc0NvcnJlY3QsXHJcbiAgICAgICAgICAgIFNlbGVjdGVkQ291bnQ6IDBcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIGF3YWl0IHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRBbGxRdWl6ZXNCeU5hbWUoY29udGFpbmluZ05hbWUsIHBhZ2VTaXplLCBwYWdlKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3Rlc3RzeXN0ZW0vdGVzdHMvcmVhZGApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGBOYW1lfmNvbnRhaW5zficke2NvbnRhaW5pbmdOYW1lfSdgLFxyXG4gICAgICAgICAgICBwYWdlU2l6ZSxcclxuICAgICAgICAgICAgcGFnZVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gYXdhaXQgcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFF1ZXN0aW9uc0J5SWQocXVpeklkLCBwYWdlU2l6ZSwgcGFnZSkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90ZXN0c3lzdGVtL3Rlc3RxdWVzdGlvbnMvcmVhZD9mb3JlaWduS2V5SWQ9JHtxdWl6SWR9YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIHBhZ2VTaXplLFxyXG4gICAgICAgICAgICBwYWdlXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBhd2FpdCBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0QW5zd2Vyc0J5UXVlc3Rpb25JZChxdWVzdGlvbklkLCBwYWdlU2l6ZSwgcGFnZSkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90ZXN0c3lzdGVtL3Rlc3RxdWVzdGlvbmFuc3dlcnMvcmVhZD9mb3JlaWduS2V5SWQ9JHtxdWVzdGlvbklkfWApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnLFxyXG4gICAgICAgICAgICBwYWdlU2l6ZSxcclxuICAgICAgICAgICAgcGFnZVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gYXdhaXQgcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgY3JlYXRlUXVpekluc3RhbmNlLFxyXG4gICAgICAgIGFkZFF1ZXN0aW9uLFxyXG4gICAgICAgIGFkZEFuc3dlcixcclxuICAgICAgICBnZXRBbGxRdWl6ZXNCeU5hbWUsXHJcbiAgICAgICAgZ2V0UXVlc3Rpb25zQnlJZCxcclxuICAgICAgICBnZXRBbnN3ZXJzQnlRdWVzdGlvbklkXHJcbiAgICB9O1xyXG59IiwiaW1wb3J0IGdlbmVyaWNBcGlGYWN0b3J5IGZyb20gJy4vZ2VuZXJpYyc7XHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSkge1xyXG4gICAgY29uc3QgZ2VuZXJpY0FwaSA9IGdlbmVyaWNBcGlGYWN0b3J5KHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSk7XHJcblxyXG5cclxuICAgIGNvbnN0IHN0b3JlSWQgPSB7XHJcbiAgICAgICAgJ3NvZnR1bmkuYmcnOiAzNzk3LFxyXG4gICAgICAgICdkaWdpdGFsLnNvZnR1bmkuYmcnOiAzNTU2LFxyXG4gICAgICAgICdjcmVhdGl2ZS5zb2Z0dW5pLmJnJzogMTQxMSxcclxuICAgICAgICAnYWkuc29mdHVuaS5iZyc6IDYsXHJcbiAgICAgICAgJ2ZpbmFuY2VhY2FkZW15LmJnJzogNzNcclxuICAgIH07XHJcblxyXG4gICAgZnVuY3Rpb24gc2VyaWFsaXplKGRhdGEpIHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnLFxyXG4gICAgICAgICAgICBJZDogZGF0YS5JZCB8fCAwLFxyXG4gICAgICAgICAgICBUcmFpbmluZ0lkOiBzdG9yZUlkW2ludGVyb3BBcHBJZCgpXSxcclxuICAgICAgICAgICAgTmFtZUJnOiAnMDAwMDAwMDAwMCcgKyBkYXRhLkV4YW1JZCxcclxuICAgICAgICAgICAgTmFtZUVuOiAnMDAwMDAwMDAwMCcsXHJcbiAgICAgICAgICAgIEhhc01hbnVhbE51bWJlck9mU3R1ZHlIb3VyczogdHJ1ZSxcclxuICAgICAgICAgICAgTnVtYmVyT2ZTdHVkeUhvdXJzOiAwLFxyXG4gICAgICAgICAgICBJc0V4Y2x1ZGVkRnJvbUNlcnRpZmljYXRlOiBmYWxzZSxcclxuICAgICAgICAgICAgSGFzSG9tZXdvcms6IGZhbHNlLFxyXG4gICAgICAgICAgICBSZXNvdXJjZU1haWxzU3RhdGU6IDAsXHJcbiAgICAgICAgICAgIEhvbWV3b3JrTWFpbHNTdGF0ZTogMCxcclxuICAgICAgICAgICAgSnVkZ2VDb250ZXN0SWQ6ICcnLFxyXG4gICAgICAgICAgICBPcmRlckJ5OiAwLFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkJnOiAnMDAwMDAwMDAwMCcgKyBKU09OLnN0cmluZ2lmeShkYXRhLkNvbmZpZyksXHJcbiAgICAgICAgICAgIERlc2NyaXB0aW9uRW46ICcwMDAwMDAwMDAwJyxcclxuICAgICAgICAgICAgRXhjbHVkZUZyb21DYWxlbmRhcjogZmFsc2UsXHJcbiAgICAgICAgICAgIEhhc0xpdmVTdHJlYW06IGZhbHNlLFxyXG4gICAgICAgICAgICBDcmVhdGVkT246ICcnLFxyXG4gICAgICAgICAgICBNb2RpZmllZE9uOiAnJ1xyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gcGFyc2UoZW50cnkpIHtcclxuICAgICAgICBpZiAoZW50cnkpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIElkOiBlbnRyeS5JZCxcclxuICAgICAgICAgICAgICAgIEV4YW1JZDogTnVtYmVyKChlbnRyeS5OYW1lQmcgfHwgJycpLnNsaWNlKDEwKSksXHJcbiAgICAgICAgICAgICAgICBDb25maWc6IEpTT04ucGFyc2UoKGVudHJ5LkRlc2NyaXB0aW9uQmcgfHwgJycpLnNsaWNlKDEwKSksXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0Q29uZmlncyhleGFtSWRzKSB7XHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGdlbmVyaWNBcGkuZ2V0RW50cmllcyhzdG9yZUlkW2ludGVyb3BBcHBJZCgpXSwgYE5hbWVCZ35lcX4nJHtleGFtSWRzLm1hcChpZCA9PiAnMDAwMDAwMDAwMCcgKyBpZCkuam9pbignXFwnfm9yfk5hbWVCZ35lcX5cXCcnKX0nYCk7XHJcbiAgICAgICAgcmV0dXJuIGRhdGEubWFwKHBhcnNlKTs7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0Q29uZmlnQnlFeGFtSWQoZXhhbUlkKSB7XHJcbiAgICAgICAgY29uc3QgY29uZmlnID0gYXdhaXQgZ2VuZXJpY0FwaS5nZXRFbnRyaWVzKHN0b3JlSWRbaW50ZXJvcEFwcElkKCldLCBgTmFtZUJnfmVxficwMDAwMDAwMDAwJHtleGFtSWR9J2ApO1xyXG4gICAgICAgIHJldHVybiBwYXJzZShjb25maWcuRGF0YVswXSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gc2F2ZUNvbmZpZyhjb25maWcpIHtcclxuICAgICAgICBjb25zdCBvcGVyYXRpb24gPSBjb25maWcuSWQgPyBnZW5lcmljQXBpLnVwZGF0ZUVudHJ5IDogZ2VuZXJpY0FwaS5jcmVhdGVFbnRyeTtcclxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBvcGVyYXRpb24oc2VyaWFsaXplKGNvbmZpZykpO1xyXG5cclxuICAgICAgICByZXR1cm4gcGFyc2UocmVzdWx0LkRhdGFbMF0pO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGRlbGV0ZUNvbmZpZyhjb25maWcpIHtcclxuICAgICAgICByZXR1cm4gZ2VuZXJpY0FwaS5kZXN0cm95RW50cnkoc2VyaWFsaXplKGNvbmZpZykpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgZ2V0Q29uZmlncyxcclxuICAgICAgICBnZXRDb25maWdCeUV4YW1JZCxcclxuICAgICAgICBzYXZlQ29uZmlnLFxyXG4gICAgICAgIGRlbGV0ZUNvbmZpZ1xyXG4gICAgfTtcclxufSIsImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCwgZ2V0IH0pIHtcclxuXHJcbiAgICAvKiBFbnRyeSBtb2RlbDpcclxuXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnLFxyXG4gICAgICAgICAgICBJZDogZGF0YS5JZCxcclxuICAgICAgICAgICAgVHJhaW5pbmdJZDogc3RvcmVJZFtpbnRlcm9wQXBwSWQoKV0sXHJcbiAgICAgICAgICAgIE5hbWVCZzogJycsICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTdHJpbmcgKDMtMjAwKVxyXG4gICAgICAgICAgICBOYW1lRW46ICcnLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU3RyaW5nICgzLTIwMClcclxuICAgICAgICAgICAgTnVtYmVyT2ZTdHVkeUhvdXJzOiAwLCAgICAgICAgICAgICAgICAgIEludGVnZXJcclxuICAgICAgICAgICAgSXNFeGNsdWRlZEZyb21DZXJ0aWZpY2F0ZTogZmFsc2UsICAgICAgIEJvb2xlYW5cclxuICAgICAgICAgICAgSGFzSG9tZXdvcms6IGZhbHNlLCAgICAgICAgICAgICAgICAgICAgIEJvb2xlYW5cclxuICAgICAgICAgICAgUmVzb3VyY2VNYWlsc1N0YXRlOiAwLFxyXG4gICAgICAgICAgICBIb21ld29ya01haWxzU3RhdGU6IDAsXHJcbiAgICAgICAgICAgIEp1ZGdlQ29udGVzdElkOiAnJywgICAgICAgICAgICAgICAgICAgICBJbnRlZ2VyIChjYW5ub3QgYmUgZW1wdHkpXHJcbiAgICAgICAgICAgIE9yZGVyQnk6IDAsICAgICAgICAgICAgICAgICAgICAgICAgICAgICBJbnRlZ2VyXHJcbiAgICAgICAgICAgIERlc2NyaXB0aW9uQmc6ICcnLCAgICAgICAgICAgICAgICAgICAgICBTdHJpbmcgKDEwLTYwMDApXHJcbiAgICAgICAgICAgIERlc2NyaXB0aW9uRW46ICcnLCAgICAgICAgICAgICAgICAgICAgICBTdHJpbmcgKDEwLTYwMDApXHJcbiAgICAgICAgICAgIEV4Y2x1ZGVGcm9tQ2FsZW5kYXI6IGZhbHNlLCAgICAgICAgICAgICBCb29sZWFuXHJcbiAgICAgICAgICAgIEhhc0xpdmVTdHJlYW06IGZhbHNlLCAgICAgICAgICAgICAgICAgICBCb29sZWFuXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogJycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcnXHJcbiAgICAgICAgfTtcclxuICAgICovXHJcblxyXG4gICAgY29uc3Qgc2V0dGluZ3NTdG9yZUlkID0ge1xyXG4gICAgICAgICdzb2Z0dW5pLmJnJzogNTI5LFxyXG4gICAgICAgICdkaWdpdGFsLnNvZnR1bmkuYmcnOiAxMDY0LFxyXG4gICAgICAgICdjcmVhdGl2ZS5zb2Z0dW5pLmJnJzogMTAxLFxyXG4gICAgICAgICdhaS5zb2Z0dW5pLmJnJzogNSxcclxuICAgICAgICAnZmluYW5jZWFjYWRlbXkuYmcnOiAyNFxyXG4gICAgfTtcclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRTdG9yZVNldHRpbmdzKHN0b3JlSWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2Zhc3R0cmFja2luc3RhbmNlcy9yZWFkP2ZvcmVpZ25LZXlJZD0ke3NldHRpbmdzU3RvcmVJZFtpbnRlcm9wQXBwSWQoKV19YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIGZpbHRlcjogYElkfmVxfiR7c3RvcmVJZH1gXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGNvbnN0IHN0b3JlID0gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YVswXTtcclxuICAgICAgICBjb25zdCBhc0pzb24gPSAoc3RvcmUuRGVzY3JpcHRpb25CZyB8fCAnJykuc2xpY2UoMTApICsgKHN0b3JlLkRlc2NyaXB0aW9uRW4gfHwgJycpLnNsaWNlKDEwKTtcclxuXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIHNldHRpbmdzOiBKU09OLnBhcnNlKGFzSnNvbiksXHJcbiAgICAgICAgICAgICAgICBfTW9kaWZpZWRPbjogc3RvcmUuTW9kaWZpZWRPbiB8fCBzdG9yZS5DcmVhdGVkT25cclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4gICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBzYXZlU3RvcmVTZXR0aW5ncyhzdG9yZUlkLCBzZXR0aW5ncykge1xyXG4gICAgICAgIGNvbnN0IGN1cnJlbnRVcmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2Zhc3R0cmFja2luc3RhbmNlcy9yZWFkP2ZvcmVpZ25LZXlJZD0ke3NldHRpbmdzU3RvcmVJZFtpbnRlcm9wQXBwSWQoKV19YCk7XHJcbiAgICAgICAgY29uc3QgY3VycmVudEJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBmaWx0ZXI6IGBJZH5lcX4ke3N0b3JlSWR9YFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjb25zdCBjdXJyZW50ID0gKGF3YWl0IHBvc3QoY3VycmVudFVyaSwgY3VycmVudEJvZHkpKS5EYXRhWzBdO1xyXG4gICAgICAgIGRlbGV0ZSBjdXJyZW50LlNoYXJlc0xpdmVTdHJlYW1XaXRoVHJhaW5pbmdzO1xyXG5cclxuICAgICAgICBpZiAoc2V0dGluZ3MuaGFzT3duUHJvcGVydHkoJ19Nb2RpZmllZE9uJykgJiYgc2V0dGluZ3MuaGFzT3duUHJvcGVydHkoJ3NldHRpbmdzJykpIHtcclxuICAgICAgICAgICAgc2V0dGluZ3MgPSBzZXR0aW5ncy5zZXR0aW5ncztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IGFzSnNvbiA9IEpTT04uc3RyaW5naWZ5KHNldHRpbmdzKTtcclxuICAgICAgICBjdXJyZW50LkRlc2NyaXB0aW9uQmcgPSAnMDAwMDAwMDAwMCcgKyBhc0pzb24uc2xpY2UoMCwgMTAwMDApO1xyXG4gICAgICAgIGN1cnJlbnQuRGVzY3JpcHRpb25FbiA9ICcwMDAwMDAwMDAwJyArIGFzSnNvbi5zbGljZSgxMDAwMCk7XHJcbiAgICAgICAgLy9DZXJ0aWZpY2F0ZSB0eXBlIGlzIG5vdyByZXF1aXJlZCAoOCA9IE5vbmUpXHJcbiAgICAgICAgY3VycmVudC5DZXJ0aWZpY2F0ZVR5cGUgPSA4O1xyXG5cclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2Zhc3R0cmFja2luc3RhbmNlcy91cGRhdGU/Zm9yZWlnbktleUlkPSR7c2V0dGluZ3NTdG9yZUlkW2ludGVyb3BBcHBJZCgpXX1gKTtcclxuICAgICAgICBjb25zdCBib2R5ID0ge1xyXG4gICAgICAgICAgICAnc29ydCc6ICcnLFxyXG4gICAgICAgICAgICAnZ3JvdXAnOiAnJyxcclxuICAgICAgICAgICAgJ2ZpbHRlcic6ICcnLFxyXG4gICAgICAgICAgICAuLi5jdXJyZW50LFxyXG4gICAgICAgICAgICBDcmVhdGVkT246ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNydcclxuICAgICAgICB9O1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YVswXTtcclxuICAgICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UoKHJlc3VsdC5EZXNjcmlwdGlvbkJnIHx8ICcnKS5zbGljZSgxMCkpO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbiAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEVudHJpZXMoc3RvcmVJZCwgZmlsdGVyKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9sZWN0dXJlcy9yZWFkP2ZvcmVpZ25LZXlJZD0ke3N0b3JlSWR9YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGlmIChmaWx0ZXIpIHtcclxuICAgICAgICAgICAgYm9keS5maWx0ZXIgPSBmaWx0ZXI7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB1cGRhdGVFbnRyeShlbnRyeSkge1xyXG4gICAgICAgIGxldCBzdGFydERhdGUgPSBuZXcgRGF0ZSgpO1xyXG4gICAgICAgIGxldCBlbmREYXRlID0gbmV3IERhdGUoc3RhcnREYXRlKTtcclxuICAgICAgICBlbmREYXRlLnNldFVUQ0RhdGUoZW5kRGF0ZS5nZXRVVENEYXRlKCkgICsgMSk7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9sZWN0dXJlcy91cGRhdGU/Zm9yZWlnbktleUlkPSR7ZW50cnkuVHJhaW5pbmdJZH1gKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgSWQ6IGVudHJ5LklkLFxyXG4gICAgICAgICAgICBUcmFpbmluZ0lkOiBlbnRyeS5UcmFpbmluZ0lkLFxyXG4gICAgICAgICAgICBOYW1lQmc6IGVudHJ5Lk5hbWVCZyxcclxuICAgICAgICAgICAgTmFtZUVuOiBlbnRyeS5OYW1lRW4sXHJcbiAgICAgICAgICAgIEhhc01hbnVhbE51bWJlck9mU3R1ZHlIb3VyczogdHJ1ZSxcclxuICAgICAgICAgICAgTnVtYmVyT2ZTdHVkeUhvdXJzOiBlbnRyeS5OdW1iZXJPZlN0dWR5SG91cnMsXHJcbiAgICAgICAgICAgIElzRXhjbHVkZWRGcm9tQ2VydGlmaWNhdGU6IGVudHJ5LklzRXhjbHVkZWRGcm9tQ2VydGlmaWNhdGUsXHJcbiAgICAgICAgICAgIEhhc0hvbWV3b3JrOiBlbnRyeS5IYXNIb21ld29yayxcclxuICAgICAgICAgICAgUmVzb3VyY2VNYWlsc1N0YXRlOiBlbnRyeS5SZXNvdXJjZU1haWxzU3RhdGUsXHJcbiAgICAgICAgICAgIEhvbWV3b3JrTWFpbHNTdGF0ZTogZW50cnkuSG9tZXdvcmtNYWlsc1N0YXRlLFxyXG4gICAgICAgICAgICBKdWRnZUNvbnRlc3RJZDogZW50cnkuSnVkZ2VDb250ZXN0SWQsXHJcbiAgICAgICAgICAgIE9yZGVyQnk6IGVudHJ5Lk9yZGVyQnksXHJcbiAgICAgICAgICAgIERlc2NyaXB0aW9uQmc6IGVudHJ5LkRlc2NyaXB0aW9uQmcsXHJcbiAgICAgICAgICAgIERlc2NyaXB0aW9uRW46IGVudHJ5LkRlc2NyaXB0aW9uRW4sXHJcbiAgICAgICAgICAgIEV4Y2x1ZGVGcm9tQ2FsZW5kYXI6IGVudHJ5LkV4Y2x1ZGVGcm9tQ2FsZW5kYXIsXHJcbiAgICAgICAgICAgIEhhc0xpdmVTdHJlYW06IGVudHJ5Lkhhc0xpdmVTdHJlYW0sXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JyxcclxuICAgICAgICAgICAgTW9kaWZpZWRPbjogJzIwMTktMDctMzFUMTc6Mzk6MDIuMzE3JyxcclxuICAgICAgICAgICAgRGF0ZXNJbmZvOiBbXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgU3RhcnQ6IHN0YXJ0RGF0ZS50b0lTT1N0cmluZygpLFxyXG4gICAgICAgICAgICAgICAgICAgIEVuZDogZW5kRGF0ZS50b0lTT1N0cmluZygpLFxyXG4gICAgICAgICAgICAgICAgICAgIEV4dHJhSW5mb3JtYXRpb246ICcnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIF0gXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgc2VyaWFsaXplRGF0ZXNJbmZvKGJvZHkpO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBjcmVhdGVFbnRyeShlbnRyeSkge1xyXG4gICAgICAgIGxldCBzdGFydERhdGUgPSBuZXcgRGF0ZSgpO1xyXG4gICAgICAgIGxldCBlbmREYXRlID0gbmV3IERhdGUoc3RhcnREYXRlKTtcclxuICAgICAgICBlbmREYXRlLnNldFVUQ0RhdGUoZW5kRGF0ZS5nZXRVVENEYXRlKCkgICsgMSk7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9sZWN0dXJlcy9jcmVhdGU/Zm9yZWlnbktleUlkPSR7ZW50cnkuVHJhaW5pbmdJZH1gKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgSWQ6IGVudHJ5LklkLFxyXG4gICAgICAgICAgICBUcmFpbmluZ0lkOiBlbnRyeS5UcmFpbmluZ0lkLFxyXG4gICAgICAgICAgICBOYW1lQmc6IGVudHJ5Lk5hbWVCZyxcclxuICAgICAgICAgICAgTmFtZUVuOiBlbnRyeS5OYW1lRW4sXHJcbiAgICAgICAgICAgIEhhc01hbnVhbE51bWJlck9mU3R1ZHlIb3VyczogdHJ1ZSxcclxuICAgICAgICAgICAgTnVtYmVyT2ZTdHVkeUhvdXJzOiBlbnRyeS5OdW1iZXJPZlN0dWR5SG91cnMsXHJcbiAgICAgICAgICAgIElzRXhjbHVkZWRGcm9tQ2VydGlmaWNhdGU6IGVudHJ5LklzRXhjbHVkZWRGcm9tQ2VydGlmaWNhdGUsXHJcbiAgICAgICAgICAgIEhhc0hvbWV3b3JrOiBlbnRyeS5IYXNIb21ld29yayxcclxuICAgICAgICAgICAgUmVzb3VyY2VNYWlsc1N0YXRlOiBlbnRyeS5SZXNvdXJjZU1haWxzU3RhdGUsXHJcbiAgICAgICAgICAgIEhvbWV3b3JrTWFpbHNTdGF0ZTogZW50cnkuSG9tZXdvcmtNYWlsc1N0YXRlLFxyXG4gICAgICAgICAgICBKdWRnZUNvbnRlc3RJZDogZW50cnkuSnVkZ2VDb250ZXN0SWQsXHJcbiAgICAgICAgICAgIE9yZGVyQnk6IGVudHJ5Lk9yZGVyQnksXHJcbiAgICAgICAgICAgIERlc2NyaXB0aW9uQmc6IGVudHJ5LkRlc2NyaXB0aW9uQmcsXHJcbiAgICAgICAgICAgIERlc2NyaXB0aW9uRW46IGVudHJ5LkRlc2NyaXB0aW9uRW4sXHJcbiAgICAgICAgICAgIEV4Y2x1ZGVGcm9tQ2FsZW5kYXI6IGVudHJ5LkV4Y2x1ZGVGcm9tQ2FsZW5kYXIsXHJcbiAgICAgICAgICAgIEhhc0xpdmVTdHJlYW06IGVudHJ5Lkhhc0xpdmVTdHJlYW0sXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogJycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcnLFxyXG4gICAgICAgICAgICBEYXRlc0luZm86IFtcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBTdGFydDogc3RhcnREYXRlLnRvSVNPU3RyaW5nKCksXHJcbiAgICAgICAgICAgICAgICAgICAgRW5kOiBlbmREYXRlLnRvSVNPU3RyaW5nKCksXHJcbiAgICAgICAgICAgICAgICAgICAgRXh0cmFJbmZvcm1hdGlvbjogJydcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXSBcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgc2VyaWFsaXplRGF0ZXNJbmZvKGJvZHkpO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBkZXN0cm95RW50cnkoZW50cnkpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2xlY3R1cmVzL2Rlc3Ryb3k/Zm9yZWlnbktleUlkPSR7ZW50cnkuVHJhaW5pbmdJZH1gKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJ1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIE9iamVjdC5hc3NpZ24oYm9keSwgZW50cnkpO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuICAgICAgICBib2R5LkNyZWF0ZWRPbiA9ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNyc7XHJcbiAgICAgICAgYm9keS5Nb2RpZmllZE9uID0gJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JztcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBzZXJpYWxpemVEYXRlc0luZm8oYm9keSkge1xyXG4gICAgICAgIGNvbnN0IGRhdGVzSW5mbyA9IGJvZHkuRGF0ZXNJbmZvO1xyXG4gICAgICAgIGRlbGV0ZSBib2R5LkRhdGVzSW5mbztcclxuICAgICAgICBcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGVzSW5mby5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBjb25zdCBkYXRlID0gZGF0ZXNJbmZvW2ldO1xyXG4gICAgICAgICAgICBib2R5W2BEYXRlc0luZm9bJHtpfV0uU3RhcnRgXSA9IGRhdGUuU3RhcnQ7XHJcbiAgICAgICAgICAgIGJvZHlbYERhdGVzSW5mb1ske2l9XS5FbmRgXSA9IGRhdGUuRW5kO1xyXG4gICAgICAgICAgICBib2R5W2BEYXRlc0luZm9bJHtpfV0uRXh0cmFJbmZvcm1hdGlvbmBdID0gZGF0ZS5FeHRyYUluZm9ybWF0aW9uO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldFN0b3JlU2V0dGluZ3MsXHJcbiAgICAgICAgc2F2ZVN0b3JlU2V0dGluZ3MsXHJcbiAgICAgICAgZ2V0RW50cmllcyxcclxuICAgICAgICB1cGRhdGVFbnRyeSxcclxuICAgICAgICBjcmVhdGVFbnRyeSxcclxuICAgICAgICBkZXN0cm95RW50cnlcclxuICAgIH07XHJcbn0iLCJpbXBvcnQgZ2VuZXJpY0FwaUZhY3RvcnkgZnJvbSAnLi9nZW5lcmljJztcclxuXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KSB7XHJcbiAgICBjb25zdCBnZW5lcmljQXBpID0gZ2VuZXJpY0FwaUZhY3RvcnkoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KTtcclxuXHJcblxyXG4gICAgY29uc3Qgc3RvcmVJZCA9IHtcclxuICAgICAgICAnc29mdHVuaS5iZyc6IDQ0OTIsXHJcbiAgICAgICAgJ2RpZ2l0YWwuc29mdHVuaS5iZyc6IDM4MTUsXHJcbiAgICAgICAgJ2NyZWF0aXZlLnNvZnR1bmkuYmcnOiAxNjEyLFxyXG4gICAgICAgICdhaS5zb2Z0dW5pLmJnJzogOVxyXG4gICAgfTtcclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldE1vZHVsZURhdGFTZXR0aW5nczogKCkgPT4gZ2VuZXJpY0FwaS5nZXRTdG9yZVNldHRpbmdzKHN0b3JlSWRbaW50ZXJvcEFwcElkKCldKSxcclxuICAgICAgICBzYXZlTW9kdWxlRGF0YVNldHRpbmdzOiAoc2V0dGluZ3MpID0+IGdlbmVyaWNBcGkuc2F2ZVN0b3JlU2V0dGluZ3Moc3RvcmVJZFtpbnRlcm9wQXBwSWQoKV0sIHNldHRpbmdzKSxcclxuICAgIH07XHJcbn0iLCJpbXBvcnQgZ2VuZXJpY0FwaUZhY3RvcnkgZnJvbSAnLi9nZW5lcmljJztcclxuXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KSB7XHJcbiAgICBjb25zdCBnZW5lcmljQXBpID0gZ2VuZXJpY0FwaUZhY3RvcnkoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KTtcclxuXHJcblxyXG4gICAgY29uc3Qgc3RvcmVJZCA9IHtcclxuICAgICAgICAnc29mdHVuaS5iZyc6IDM4MzMsXHJcbiAgICAgICAgJ2RpZ2l0YWwuc29mdHVuaS5iZyc6IDM1ODIsXHJcbiAgICAgICAgJ2NyZWF0aXZlLnNvZnR1bmkuYmcnOiAxNDI4LFxyXG4gICAgICAgICdhaS5zb2Z0dW5pLmJnJzogMTBcclxuICAgIH07XHJcblxyXG4gICAgZnVuY3Rpb24gc2VyaWFsaXplKGRhdGEpIHtcclxuICAgICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICAgICAgICBQYXltZW50c0J5RGF0ZTogZGF0YS5QYXltZW50c0J5RGF0ZSxcclxuICAgICAgICAgICAgUmV0ZW50aW9uQnlEYXRlOiBkYXRhLlJldGVudGlvbkJ5RGF0ZSxcclxuICAgICAgICAgICAgT25saW5lUGF5bWVudHM6IGRhdGEuT25saW5lUGF5bWVudHMgfHwgMCxcclxuICAgICAgICAgICAgT25saW5lUmV0ZW50aW9uOiBkYXRhLk9ubGluZVJldGVudGlvbiB8fCAwLFxyXG4gICAgICAgICAgICBTaXRlUGF5bWVudHM6IGRhdGEuU2l0ZVBheW1lbnRzIHx8IDAsXHJcbiAgICAgICAgICAgIFNpdGVSZXRlbnRpb246IGRhdGEuU2l0ZVJldGVudGlvbiB8fCAwXHJcbiAgICAgICAgfTtcclxuICAgICAgICBjb25zdCBhc0pzb24gPSBKU09OLnN0cmluZ2lmeShwYXlsb2FkKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgSWQ6IGRhdGEuSWQgfHwgMCxcclxuICAgICAgICAgICAgVHJhaW5pbmdJZDogc3RvcmVJZFtpbnRlcm9wQXBwSWQoKV0sXHJcbiAgICAgICAgICAgIE5hbWVCZzogJzAwMDAwMDAwMDAnICsgKGRhdGEuTmFtZUJnICsgJzo6JyArIGRhdGEuTmFtZUVuICsgJzo6JyArIGRhdGEuTGV2ZWxJZCksXHJcbiAgICAgICAgICAgIE5hbWVFbjogJzAwMDAwMDAwMDAnICsgSlNPTi5zdHJpbmdpZnkoZGF0YS5EYXRlQ29uZmlnKSxcclxuICAgICAgICAgICAgSGFzTWFudWFsTnVtYmVyT2ZTdHVkeUhvdXJzOiB0cnVlLFxyXG4gICAgICAgICAgICBOdW1iZXJPZlN0dWR5SG91cnM6IGRhdGEuU3RhcnRJbmRleCB8fCAwLFxyXG4gICAgICAgICAgICBJc0V4Y2x1ZGVkRnJvbUNlcnRpZmljYXRlOiBmYWxzZSxcclxuICAgICAgICAgICAgSnVkZ2VDb250ZXN0SWQ6IGRhdGEuTGV2ZWxJZCxcclxuICAgICAgICAgICAgSGFzSG9tZXdvcms6IGZhbHNlLFxyXG4gICAgICAgICAgICBSZXNvdXJjZU1haWxzU3RhdGU6IDAsXHJcbiAgICAgICAgICAgIEhvbWV3b3JrTWFpbHNTdGF0ZTogMCxcclxuICAgICAgICAgICAgT3JkZXJCeTogZGF0YS5JbnN0YW5jZUlkLFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkJnOiAnMDAwMDAwMDAwMCcgKyBhc0pzb24uc2xpY2UoMCwgNTk4MCksXHJcbiAgICAgICAgICAgIERlc2NyaXB0aW9uRW46ICcwMDAwMDAwMDAwJyArIGFzSnNvbi5zbGljZSg1OTgwKSxcclxuICAgICAgICAgICAgRXhjbHVkZUZyb21DYWxlbmRhcjogIWRhdGEuSXNNYWluUHJvZ3JhbSxcclxuICAgICAgICAgICAgSGFzTGl2ZVN0cmVhbTogZmFsc2UsXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogJycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcnXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBwYXJzZShlbnRyeSkge1xyXG4gICAgICAgIGlmIChlbnRyeSkge1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcGF5bG9hZEpzb24gPSAoZW50cnkuRGVzY3JpcHRpb25CZyB8fCAnJykuc2xpY2UoMTApICsgKGVudHJ5LkRlc2NyaXB0aW9uRW4gfHwgJycpLnNsaWNlKDEwKTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHBheWxvYWQgPSBKU09OLnBhcnNlKHBheWxvYWRKc29uKTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IG5hbWVzQW5kTGV2ZWwgPSBlbnRyeS5OYW1lQmcuc2xpY2UoMTApLnNwbGl0KCc6OicpO1xyXG5cclxuICAgICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAgICAgSWQ6IGVudHJ5LklkLFxyXG4gICAgICAgICAgICAgICAgICAgIEluc3RhbmNlSWQ6IE51bWJlcihlbnRyeS5PcmRlckJ5KSB8fCBudWxsLFxyXG4gICAgICAgICAgICAgICAgICAgIExldmVsSWQ6IE51bWJlcihuYW1lc0FuZExldmVsWzJdKSB8fCBlbnRyeS5KdWRnZUNvbnRlc3RJZCxcclxuICAgICAgICAgICAgICAgICAgICBOYW1lQmc6IG5hbWVzQW5kTGV2ZWxbMF0sXHJcbiAgICAgICAgICAgICAgICAgICAgTmFtZUVuOiBuYW1lc0FuZExldmVsWzFdLFxyXG4gICAgICAgICAgICAgICAgICAgIERhdGVDb25maWc6IEpTT04ucGFyc2UoKGVudHJ5Lk5hbWVFbiB8fCAnJykuc2xpY2UoMTApKSxcclxuICAgICAgICAgICAgICAgICAgICBTdGFydEluZGV4OiBlbnRyeS5OdW1iZXJPZlN0dWR5SG91cnMsXHJcbiAgICAgICAgICAgICAgICAgICAgUGF5bWVudHNCeURhdGU6IHBheWxvYWQuUGF5bWVudHNCeURhdGUsXHJcbiAgICAgICAgICAgICAgICAgICAgUmV0ZW50aW9uQnlEYXRlOiBwYXlsb2FkLlJldGVudGlvbkJ5RGF0ZSxcclxuICAgICAgICAgICAgICAgICAgICBPbmxpbmVQYXltZW50czogcGF5bG9hZC5PbmxpbmVQYXltZW50cyB8fCAwLFxyXG4gICAgICAgICAgICAgICAgICAgIE9ubGluZVJldGVudGlvbjogcGF5bG9hZC5PbmxpbmVSZXRlbnRpb24gfHwgMCxcclxuICAgICAgICAgICAgICAgICAgICBTaXRlUGF5bWVudHM6IHBheWxvYWQuU2l0ZVBheW1lbnRzIHx8IDAsXHJcbiAgICAgICAgICAgICAgICAgICAgU2l0ZVJldGVudGlvbjogcGF5bG9hZC5TaXRlUmV0ZW50aW9uIHx8IDAsXHJcbiAgICAgICAgICAgICAgICAgICAgSXNNYWluUHJvZ3JhbTogIWVudHJ5LkV4Y2x1ZGVGcm9tQ2FsZW5kYXIsXHJcbiAgICAgICAgICAgICAgICAgICAgTW9kaWZpZWRPbjogZW50cnkuTW9kaWZpZWRPbiB8fCBlbnRyeS5DcmVhdGVkT25cclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignRGVzdHJveWluZyBpbmNvbXBhdGlibGUgZW50cnknKTtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVudHJ5KTtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgICAgICAgICAgICAgIGdlbmVyaWNBcGkuZGVzdHJveUVudHJ5KGVudHJ5KTtcclxuXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0U3RhdHMoaW5zdGFuY2VJZHMpIHtcclxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgZ2VuZXJpY0FwaS5nZXRFbnRyaWVzKHN0b3JlSWRbaW50ZXJvcEFwcElkKCldLCBgT3JkZXJCeX5lcX4ke2luc3RhbmNlSWRzLmpvaW4oJ35vcn5PcmRlckJ5fmVxficpfWApO1xyXG4gICAgICAgIHJldHVybiBkYXRhLm1hcChwYXJzZSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0U3RhdHNCeUluc3RhbmNlSWQoaW5zdGFuY2VJZCkge1xyXG4gICAgICAgIGNvbnN0IGNvbmZpZyA9IGF3YWl0IGdlbmVyaWNBcGkuZ2V0RW50cmllcyhzdG9yZUlkW2ludGVyb3BBcHBJZCgpXSwgYE9yZGVyQnl+ZXF+JHtpbnN0YW5jZUlkfWApO1xyXG4gICAgICAgIHJldHVybiBwYXJzZShjb25maWdbMF0pO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFN0YXRzQnlTdGFydEluZGV4KHN0YXJ0LCBlbmQpIHtcclxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgZ2VuZXJpY0FwaS5nZXRFbnRyaWVzKHN0b3JlSWRbaW50ZXJvcEFwcElkKCldLCBgTnVtYmVyT2ZTdHVkeUhvdXJzfmd0ZX4ke3N0YXJ0fX5hbmR+TnVtYmVyT2ZTdHVkeUhvdXJzfmx0ZX4ke2VuZH1gKTtcclxuICAgICAgICByZXR1cm4gZGF0YS5tYXAocGFyc2UpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHNhdmVTdGF0cyhzdGF0cykge1xyXG4gICAgICAgIGNvbnN0IG9wZXJhdGlvbiA9IHN0YXRzLklkID8gZ2VuZXJpY0FwaS51cGRhdGVFbnRyeSA6IGdlbmVyaWNBcGkuY3JlYXRlRW50cnk7XHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgb3BlcmF0aW9uKHNlcmlhbGl6ZShzdGF0cykpO1xyXG5cclxuICAgICAgICBpZihyZXN1bHQuRXJyb3JzKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGVycm9yID0gbmV3IEVycm9yKCdSZXF1ZXN0IHJldHVybmVkIEVycm9ycycpO1xyXG4gICAgICAgICAgICBlcnJvci5fZXJyb3JPYmplY3QgPSByZXN1bHQuRXJyb3JzO1xyXG4gICAgICAgICAgICB0aHJvdyBlcnJvcjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KHJlc3VsdCkpO1xyXG4gICAgICAgIHJldHVybiBwYXJzZShyZXN1bHQuRGF0YVswXSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZGVsZXRlU3RhdHMoc3RhdHMpIHtcclxuICAgICAgICByZXR1cm4gZ2VuZXJpY0FwaS5kZXN0cm95RW50cnkoc2VyaWFsaXplKHN0YXRzKSk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBnZXRTdGF0c1NldHRpbmdzOiAoKSA9PiBnZW5lcmljQXBpLmdldFN0b3JlU2V0dGluZ3Moc3RvcmVJZFtpbnRlcm9wQXBwSWQoKV0pLFxyXG4gICAgICAgIHNhdmVTdGF0c1NldHRpbmdzOiAoc2V0dGluZ3MpID0+IGdlbmVyaWNBcGkuc2F2ZVN0b3JlU2V0dGluZ3Moc3RvcmVJZFtpbnRlcm9wQXBwSWQoKV0sIHNldHRpbmdzKSxcclxuICAgICAgICBnZXRTdGF0cyxcclxuICAgICAgICBnZXRTdGF0c0J5SW5zdGFuY2VJZCxcclxuICAgICAgICBnZXRTdGF0c0J5U3RhcnRJbmRleCxcclxuICAgICAgICBzYXZlU3RhdHMsXHJcbiAgICAgICAgZGVsZXRlU3RhdHNcclxuICAgIH07XHJcbn0iLCJpbXBvcnQgZ2VuZXJpY0FwaUZhY3RvcnkgZnJvbSAnLi9nZW5lcmljJztcclxuXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KSB7XHJcbiAgICBjb25zdCBnZW5lcmljQXBpID0gZ2VuZXJpY0FwaUZhY3RvcnkoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KTtcclxuXHJcblxyXG4gICAgY29uc3QgdGVtcGxhdGVTdG9yZUlkID0ge1xyXG4gICAgICAgICdzb2Z0dW5pLmJnJzogMzUxOSxcclxuICAgICAgICAnZGlnaXRhbC5zb2Z0dW5pLmJnJzogMzQ0MCxcclxuICAgICAgICAnY3JlYXRpdmUuc29mdHVuaS5iZyc6IDEzMDAsXHJcbiAgICAgICAgJ2FpLnNvZnR1bmkuYmcnOiA3LFxyXG4gICAgICAgICdmaW5hbmNlYWNhZGVteS5iZyc6IDc0XHJcbiAgICB9O1xyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFRlbXBsYXRlU3RvcmVTZXR0aW5ncygpIHtcclxuICAgICAgICByZXR1cm4gZ2VuZXJpY0FwaS5nZXRTdG9yZVNldHRpbmdzKHRlbXBsYXRlU3RvcmVJZFtpbnRlcm9wQXBwSWQoKV0pO1xyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIHRlbXBsYXRlVG9FbnRyeShkYXRhKSB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgSWQ6IGRhdGEuSWQgfHwgMCxcclxuICAgICAgICAgICAgVHJhaW5pbmdJZDogdGVtcGxhdGVTdG9yZUlkW2ludGVyb3BBcHBJZCgpXSxcclxuICAgICAgICAgICAgTmFtZUJnOiAnMDAwMDAwMDAwMCcgKyBkYXRhLk5hbWUsXHJcbiAgICAgICAgICAgIE5hbWVFbjogJzAwMDAwMDAwMDAnICsgSlNPTi5zdHJpbmdpZnkoZGF0YS5DYXRlZ29yeSksXHJcbiAgICAgICAgICAgIEhhc01hbnVhbE51bWJlck9mU3R1ZHlIb3VyczogdHJ1ZSxcclxuICAgICAgICAgICAgTnVtYmVyT2ZTdHVkeUhvdXJzOiAwLFxyXG4gICAgICAgICAgICBJc0V4Y2x1ZGVkRnJvbUNlcnRpZmljYXRlOiBkYXRhLkFjdGl2ZSxcclxuICAgICAgICAgICAgSGFzSG9tZXdvcms6IGZhbHNlLFxyXG4gICAgICAgICAgICBSZXNvdXJjZU1haWxzU3RhdGU6IDAsXHJcbiAgICAgICAgICAgIEhvbWV3b3JrTWFpbHNTdGF0ZTogMCxcclxuICAgICAgICAgICAgSnVkZ2VDb250ZXN0SWQ6ICcnLFxyXG4gICAgICAgICAgICBPcmRlckJ5OiAwLFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkJnOiAnMDAwMDAwMDAwMCcgKyBkYXRhLkNvbnRlbnQsXHJcbiAgICAgICAgICAgIERlc2NyaXB0aW9uRW46ICgnMDAwMDAwMDAwMCcgKyAoZGF0YS5JbnN0YW5jZUlkIHx8ICcnKSkuc2xpY2UoLTEwKSxcclxuICAgICAgICAgICAgRXhjbHVkZUZyb21DYWxlbmRhcjogZGF0YS5Db21wb3VuZCxcclxuICAgICAgICAgICAgSGFzTGl2ZVN0cmVhbTogZmFsc2UsXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogJycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcnXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBlbnRyeVRvVGVtcGxhdGUoZW50cnkpIHtcclxuICAgICAgICBpZiAoZW50cnkpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIElkOiBlbnRyeS5JZCxcclxuICAgICAgICAgICAgICAgIE5hbWU6IGVudHJ5Lk5hbWVCZy5zbGljZSgxMCksXHJcbiAgICAgICAgICAgICAgICBDYXRlZ29yeTogSlNPTi5wYXJzZShlbnRyeS5OYW1lRW4uc2xpY2UoMTApKSB8fCBbXSxcclxuICAgICAgICAgICAgICAgIEFjdGl2ZTogZW50cnkuSXNFeGNsdWRlZEZyb21DZXJ0aWZpY2F0ZSxcclxuICAgICAgICAgICAgICAgIENvbXBvdW5kOiBlbnRyeS5FeGNsdWRlRnJvbUNhbGVuZGFyLFxyXG4gICAgICAgICAgICAgICAgQ29udGVudDogKGVudHJ5LkRlc2NyaXB0aW9uQmcgfHwgJycpLnNsaWNlKDEwKSxcclxuICAgICAgICAgICAgICAgIEluc3RhbmNlSWQ6IE51bWJlcihlbnRyeS5EZXNjcmlwdGlvbkVuKSB8fCBudWxsXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0VGVtcGxhdGVzKCkge1xyXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBnZW5lcmljQXBpLmdldEVudHJpZXModGVtcGxhdGVTdG9yZUlkW2ludGVyb3BBcHBJZCgpXSk7XHJcbiAgICAgICAgcmV0dXJuIGRhdGFcclxuICAgICAgICAgICAgLm1hcChlbnRyeVRvVGVtcGxhdGUpXHJcbiAgICAgICAgICAgIC5zb3J0KChhLCBiKSA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gKChiLkFjdGl2ZSA/IDEgOiAwKSAtIChhLkFjdGl2ZSA/IDEgOiAwKSlcclxuICAgICAgICAgICAgICAgICAgICB8fCAoKGIuQ29tcG91bmQgPyAxIDogMCkgLSAoYS5Db21wb3VuZCA/IDEgOiAwKSlcclxuICAgICAgICAgICAgICAgICAgICB8fCBhLk5hbWUubG9jYWxlQ29tcGFyZShiLk5hbWUpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRUZW1wbGF0ZUJ5TmFtZShuYW1lKSB7XHJcbiAgICAgICAgY29uc3QgdGVtcGxhdGUgPSBhd2FpdCBnZW5lcmljQXBpLmdldEVudHJpZXModGVtcGxhdGVTdG9yZUlkW2ludGVyb3BBcHBJZCgpXSwgYE5hbWVCZ35lcX4nJHtuYW1lfSdgKTtcclxuICAgICAgICByZXR1cm4gZW50cnlUb1RlbXBsYXRlKHRlbXBsYXRlWzBdKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRUZW1wbGF0ZUJ5SW5zdGFuY2VJZChpbnN0YW5jZUlkKSB7XHJcbiAgICAgICAgY29uc3QgdGVtcGxhdGUgPSBhd2FpdCBnZW5lcmljQXBpLmdldEVudHJpZXModGVtcGxhdGVTdG9yZUlkW2ludGVyb3BBcHBJZCgpXSwgYERlc2NyaXB0aW9uRW5+ZXF+JyR7aW5zdGFuY2VJZH0nYCk7XHJcbiAgICAgICAgcmV0dXJuIGVudHJ5VG9UZW1wbGF0ZSh0ZW1wbGF0ZVswXSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gc2F2ZVRlbXBsYXRlKHRlbXBsYXRlKSB7XHJcbiAgICAgICAgY29uc3Qgb3BlcmF0aW9uID0gdGVtcGxhdGUuSWQgPyBnZW5lcmljQXBpLnVwZGF0ZUVudHJ5IDogZ2VuZXJpY0FwaS5jcmVhdGVFbnRyeTtcclxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBvcGVyYXRpb24odGVtcGxhdGVUb0VudHJ5KHRlbXBsYXRlKSk7XHJcblxyXG4gICAgICAgIHJldHVybiBlbnRyeVRvVGVtcGxhdGUocmVzdWx0LkRhdGFbMF0pO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGRlbGV0ZVRlbXBsYXRlKHRlbXBsYXRlKSB7XHJcbiAgICAgICAgcmV0dXJuIGdlbmVyaWNBcGkuZGVzdHJveUVudHJ5KHRlbXBsYXRlVG9FbnRyeSh0ZW1wbGF0ZSkpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgZ2V0VGVtcGxhdGVTdG9yZVNldHRpbmdzLFxyXG4gICAgICAgIGdldFRlbXBsYXRlcyxcclxuICAgICAgICBnZXRUZW1wbGF0ZUJ5TmFtZSxcclxuICAgICAgICBnZXRUZW1wbGF0ZUJ5SW5zdGFuY2VJZCxcclxuICAgICAgICBzYXZlVGVtcGxhdGUsXHJcbiAgICAgICAgZGVsZXRlVGVtcGxhdGVcclxuICAgIH07XHJcbn0iLCJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KSB7XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0SW5zdGFuY2VDb25maWcoaW5zdGFuY2VJZCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGBodHRwczovL3Nlcy13ZWJleHQuZ2l0aHViLmlvL3N0cmVhbS8ke2luc3RhbmNlSWR9Lmpzb25gO1xyXG5cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBnZXQodXJpKTtcclxuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyKTtcclxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgZ2V0SW5zdGFuY2VDb25maWdcclxuICAgIH07XHJcbn0iLCJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QgfSkge1xyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0U3VydmV5cyhwYWdlLCBxdWVyeSwgZmlsdGVyLCBwYWdlU2l6ZSA9IDMwKSB7XHJcbiAgICAgICAgaWYgKHBhZ2VTaXplID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICBwYWdlU2l6ZSA9IDMwO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgdXJsID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3N1cnZleXMvc3VydmV5cy9yZWFkJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICdBY3RpdmVUby1kZXNjJyxcclxuICAgICAgICAgICAgcGFnZVNpemU6IHBhZ2VTaXplLFxyXG4gICAgICAgICAgICBwYWdlXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgaWYgKHF1ZXJ5KSB7XHJcbiAgICAgICAgICAgIGJvZHkuZmlsdGVyID0gYE5hbWV+Y29udGFpbnN+JyR7cXVlcnl9J2A7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoZmlsdGVyKSB7XHJcbiAgICAgICAgICAgIGJvZHkuZmlsdGVyICs9IGB+YW5kfigke2ZpbHRlcn0pYFxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJsLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRTdXJ2ZXlzQnlOYW1lQW5kU3RhcnRBbmRFbmREYXRlKHBhZ2UsIG5hbWUsIHN0YXJ0RGF0ZSwgZW5kRGF0ZSwgcGFnZVNpemUgPSAzMCkge1xyXG4gICAgICAgIGlmIChwYWdlU2l6ZSA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgcGFnZVNpemUgPSAzMDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IHVybCA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl9zdXJ2ZXlzL3N1cnZleXMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnQWN0aXZlVG8tZGVzYycsXHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiBwYWdlU2l6ZSxcclxuICAgICAgICAgICAgcGFnZVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBib2R5LmZpbHRlciA9IGBOYW1lfmNvbnRhaW5zficke25hbWV9J35hbmR+QWN0aXZlRnJvbX5ndGV+ZGF0ZXRpbWUnJHtzdGFydERhdGV9J35hbmR+QWN0aXZlRnJvbX5sdH5kYXRldGltZScke2VuZERhdGV9J2A7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVybCwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0U3VydmV5QnlJZChzdXJ2ZXlJZCkge1xyXG4gICAgICAgIGNvbnN0IHVybCA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl9zdXJ2ZXlzL3N1cnZleXMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBmaWx0ZXI6ICdJZH5lcX4nICsgc3VydmV5SWQsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVybCwgYm9keSkpLkRhdGFbMF07XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0U3VydmV5QW5zd2VycyhzdXJ2ZXlJZCkge1xyXG4gICAgICAgIGNvbnN0IHVybCA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl9zdXJ2ZXlzL3VzZXJwb2xsYW5zd2Vycy9yZWFkJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwMCxcclxuICAgICAgICAgICAgZmlsdGVyOiAnU3VydmV5SWR+ZXF+JyArIHN1cnZleUlkXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVybCwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0U3VydmV5VGVtcGxhdGVzKCkge1xyXG4gICAgICAgIGNvbnN0IHVybCA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl9zdXJ2ZXlzL3N1cnZleXNlY3Rpb250ZW1wbGF0ZXMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDAsXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVybCwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0U3VydmV5UXVlc3Rpb25zQnlUZW1wbGF0ZUlkKHRlbXBsYXRlSWQpIHtcclxuICAgICAgICBjb25zdCB1cmwgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fc3VydmV5cy9wb2xscXVlc3Rpb25zL3JlYWRwb2xscXVlc3Rpb25zP3N1cnZleVNlY3Rpb25UZW1wbGF0ZUlkPSR7dGVtcGxhdGVJZH1gKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAwLFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmwsIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFN1cnZleVNlY3Rpb25zQnlUZW1wbGF0ZUlkKHRlbXBsYXRlSWQpIHtcclxuICAgICAgICBjb25zdCB1cmwgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fc3VydmV5cy9zdXJ2ZXlzZWN0aW9ucy9yZWFkJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwMCxcclxuICAgICAgICAgICAgZmlsdGVyOiBgU3VydmV5U2VjdGlvblRlbXBsYXRlSWR+ZXF+JHt0ZW1wbGF0ZUlkfWBcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJsLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRTdXJ2ZXlTZWN0aW9uc0J5SWQoc2VjdGlvbklkKSB7XHJcbiAgICAgICAgY29uc3QgdXJsID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3N1cnZleXMvc3VydmV5c2VjdGlvbnMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogYElkfmVxfiR7QXJyYXkuaXNBcnJheShzZWN0aW9uSWQpID8gc2VjdGlvbklkLmpvaW4oJ35vcn5JZH5lcX4nKSA6IHNlY3Rpb25JZH1gXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVybCwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZmluZFNlY3Rpb25zQnlUcmFpbmluZyhuYW1lQmcpIHtcclxuICAgICAgICBjb25zdCB1cmwgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fc3VydmV5cy9zdXJ2ZXlzZWN0aW9ucy9yZWFkJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogYFRyYWluaW5nfmVxficke25hbWVCZ30nfmFuZH5OYW1lfmRvZXNub3Rjb250YWlufifQvtCx0YHQu9GD0LbQstCw0L3QtSd+YW5kfk5hbWV+ZG9lc25vdGNvbnRhaW5+J9C40L3RhNC+0YDQvNCw0YbQuNGPJ35hbmR+TmFtZX5kb2Vzbm90Y29udGFpbn4n0YHQstGK0YDQt9Cw0L3QuCDRgSDQutGD0YDRgdCwJ2BcclxuICAgICAgICB9KTtcclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJsLCBib2R5KSkuRGF0YS5tYXAocyA9PiBzLk5hbWUpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGZpbmRBbnN3ZXJzQnlTZWN0aW9uKHNlY3Rpb25OYW1lcykge1xyXG4gICAgICAgIGNvbnN0IHVybCA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl9zdXJ2ZXlzL3VzZXJwb2xsYW5zd2Vycy9yZWFkJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwMCxcclxuICAgICAgICAgICAgZmlsdGVyOiAnU2VjdGlvbn5lcX5cXCcnICsgc2VjdGlvbk5hbWVzLmpvaW4oJ1xcJ35vcn5TZWN0aW9ufmVxflxcJycpICsgJ1xcJydcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVybCwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZmluZFN1cnZleUJ5VHJhaW5pbmcobmFtZUJnKSB7XHJcbiAgICAgICAgY29uc3Qgc2VjdGlvbnMgPSBhd2FpdCBmaW5kU2VjdGlvbnNCeVRyYWluaW5nKG5hbWVCZyk7XHJcbiAgICAgICAgY29uc29sZS5sb2coc2VjdGlvbnMpO1xyXG4gICAgICAgIGNvbnN0IGFuc3dlcnMgPSBhd2FpdCBmaW5kQW5zd2Vyc0J5U2VjdGlvbihzZWN0aW9ucyk7XHJcbiAgICAgICAgY29uc3Qgc3VydmV5cyA9IFsuLi5hbnN3ZXJzLnJlZHVjZSgocCwgYykgPT4geyBwLmFkZChjLlN1cnZleUlkKTsgcmV0dXJuIHA7IH0sIG5ldyBTZXQoKSldO1xyXG5cclxuICAgICAgICByZXR1cm4gUHJvbWlzZS5hbGwoc3VydmV5cy5tYXAoZ2V0U3VydmV5QnlJZCkpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgZ2V0U3VydmV5cyxcclxuICAgICAgICBnZXRTdXJ2ZXlzQnlOYW1lQW5kU3RhcnRBbmRFbmREYXRlLFxyXG4gICAgICAgIGdldFN1cnZleUJ5SWQsXHJcbiAgICAgICAgZ2V0U3VydmV5QW5zd2VycyxcclxuICAgICAgICBnZXRTdXJ2ZXlUZW1wbGF0ZXMsXHJcbiAgICAgICAgZ2V0U3VydmV5UXVlc3Rpb25zQnlUZW1wbGF0ZUlkLFxyXG4gICAgICAgIGdldFN1cnZleVNlY3Rpb25zQnlUZW1wbGF0ZUlkLFxyXG4gICAgICAgIGdldFN1cnZleVNlY3Rpb25zQnlJZCxcclxuICAgICAgICBmaW5kU3VydmV5QnlUcmFpbmluZ1xyXG4gICAgfTtcclxufSIsImltcG9ydCB7IHBhcnNlQ3Jvc3NCcm93c2VyRmlsZSB9IGZyb20gJy4uL3V0aWwnO1xyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCwgZ2V0IH0pIHtcclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRIb21ld29ya1Jlc3VsdHMoaW5zdGFuY2VJZCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl9jcm0vaW50ZXJuYWxjb3Vyc2Vjcm1wcm9maWxlcy9yZWFkaW50ZXJuYWxjb3Vyc2Vjcm1wcm9maWxlcy8ke2luc3RhbmNlSWR9YCk7XHJcblxyXG4gICAgICAgIHJldHVybiBhd2FpdCBmZXRjaE5leHQoKTtcclxuXHJcbiAgICAgICAgYXN5bmMgZnVuY3Rpb24gZmV0Y2hOZXh0KHBhZ2UgPSAxKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICAgICAgc29ydDogJ0NyZWF0ZWRPbi1kZXNjJyxcclxuICAgICAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwLFxyXG4gICAgICAgICAgICAgICAgcGFnZVxyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgcG9zdCh1cmksIGJvZHkpO1xyXG5cclxuICAgICAgICAgICAgbGV0IHJlc3VsdCA9IHJlc3BvbnNlLkRhdGE7XHJcblxyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuVG90YWwgPiBwYWdlICogMTAwMCkge1xyXG4gICAgICAgICAgICAgICAgcmVzdWx0ID0gcmVzdWx0LmNvbmNhdChhd2FpdCBmZXRjaE5leHQocGFnZSArIDEpKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0UHJvdG9jb2woaW5zdGFuY2VJZCkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy91c2Vyc2luY291cnNlcy9leHBvcnR0cmFpbmluZ3Byb3RvY29sLyR7aW5zdGFuY2VJZH1gKSwge1xyXG4gICAgICAgICAgICAnY3JlZGVudGlhbHMnOiAnaW5jbHVkZScsXHJcbiAgICAgICAgICAgICdoZWFkZXJzJzoge1xyXG4gICAgICAgICAgICAgICAgJ0hvc3QnOiAnc29mdHVuaS5iZycsXHJcbiAgICAgICAgICAgICAgICAnVXNlci1BZ2VudCc6ICdNb3ppbGxhLzUuMCAoV2luZG93cyBOVCAxMC4wOyBXaW42NDsgeDY0OyBydjo5Ny4wKSBHZWNrby8yMDEwMDEwMSBGaXJlZm94Lzk3LjAnLFxyXG4gICAgICAgICAgICAgICAgJ0FjY2VwdCc6ICd0ZXh0L2h0bWwsYXBwbGljYXRpb24veGh0bWwreG1sLGFwcGxpY2F0aW9uL3htbDtxPTAuOSxpbWFnZS9hdmlmLGltYWdlL3dlYnAsKi8qO3E9MC44JyxcclxuICAgICAgICAgICAgICAgICdBY2NlcHQtTGFuZ3VhZ2UnOiAnZW4tVVMsZW47cT0wLjUnLFxyXG4gICAgICAgICAgICAgICAgJ0FjY2VwdC1FbmNvZGluZyc6ICdnemlwLCBkZWZsYXRlLCBicicsXHJcbiAgICAgICAgICAgICAgICAnQ29ubmVjdGlvbic6ICdrZWVwLWFsaXZlJyxcclxuICAgICAgICAgICAgICAgICdSZWZlcmVyJzogaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy91c2Vyc2ludHJhaW5pbmdzbWFuYWdlbWVudCcpLFxyXG4gICAgICAgICAgICAgICAgJ1VwZ3JhZGUtSW5zZWN1cmUtUmVxdWVzdHMnOiAxLFxyXG4gICAgICAgICAgICAgICAgJ1NlYy1GZXRjaC1EZXN0JzogJ2RvY3VtZW50JyxcclxuICAgICAgICAgICAgICAgICdTZWMtRmV0Y2gtTW9kZSc6ICduYXZpZ2F0ZScsXHJcbiAgICAgICAgICAgICAgICAnU2VjLUZldGNoLVNpdGUnOiAnc2FtZS1vcmlnaW4nLFxyXG4gICAgICAgICAgICAgICAgJ1NlYy1GZXRjaC1Vc2VyJzogJz8xJyxcclxuICAgICAgICAgICAgICAgICdQcmFnbWEnOiAnbm8tY2FjaGUnLFxyXG4gICAgICAgICAgICAgICAgJ0NhY2hlLUNvbnRyb2wnOiAnbm8tY2FjaGUnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICdtZXRob2QnOiAnR0VUJyxcclxuICAgICAgICAgICAgJ21vZGUnOiAnY29ycydcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgYmxvYiA9IGF3YWl0IHJlc3BvbnNlLmJsb2IoKTtcclxuICAgICAgICBjb25zdCBzZXJpYWxpemVkQmxvYiA9IG5ldyBVaW50OEFycmF5KGF3YWl0IGJsb2IuYXJyYXlCdWZmZXIoKSk7XHJcbiAgXHJcbiAgICAgICAgY29uc3QgYmxvYkRhdGEgPSB7XHJcbiAgICAgICAgICAgIHR5cGU6IGJsb2IudHlwZSxcclxuICAgICAgICAgICAgYnVmZmVyOiBBcnJheS5mcm9tKHNlcmlhbGl6ZWRCbG9iKVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgXHJcbiAgICAgICAgcmV0dXJuIGJsb2JEYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHVwbG9hZEZpbGUodXJsLCBmb3JtRGF0YSkge1xyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGZldGNoKHVybCwge1xyXG4gICAgICAgICAgICBjcmVkZW50aWFsczogJ2luY2x1ZGUnLFxyXG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICAgICAgYm9keTogZm9ybURhdGEsXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gdXBsb2FkRXhhbVJlc3VsdHMoZXhhbU5hbWUsIGV4YW1JZCwgY29tYm8sIGZpbGVEZXNjcmlwdG9yKSB7XHJcbiAgICAgICAgY29uc3QgdXJsID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9leGFtcy9pbXBvcnRleGFtcmVzdWx0cycpO1xyXG4gICAgICAgIGNvbnN0IHsgYmxvYiwgZmlsZW5hbWUgfSA9IGF3YWl0IHBhcnNlQ3Jvc3NCcm93c2VyRmlsZShmaWxlRGVzY3JpcHRvcik7XHJcblxyXG4gICAgICAgIGNvbnN0IGZvcm1EYXRhID0gbmV3IEZvcm1EYXRhKCk7XHJcblxyXG4gICAgICAgIGNvbnN0IHJ2dCA9IGF3YWl0IG9idGFpblJWVCgpO1xyXG5cclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ19fUmVxdWVzdFZlcmlmaWNhdGlvblRva2VuJywgcnZ0KTtcclxuXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdFeGFtSWRfaW5wdXQnLCBleGFtTmFtZSk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdFeGFtSWQnLCBleGFtSWQpO1xyXG5cclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ1Jlc3VsdHNGaWxlJywgYmxvYiwgZmlsZW5hbWUpO1xyXG5cclxuICAgICAgICBpZiAoY29tYm8uaW1wb3J0UHJhY3RpY2UpIHtcclxuICAgICAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdJbXBvcnRQcmVmZXJlbmNlcycsIDEpOyAgICAvLyBQcmFjdGljZVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoY29tYm8uaW1wb3J0UXVpeikge1xyXG4gICAgICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ0ltcG9ydFByZWZlcmVuY2VzJywgMik7ICAgIC8vIFF1aXpcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnVXNlcm5hbWVDb2x1bW4nLCAxKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ1Jlc3VsdENvbHVtbicsIDIpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnQ29tbWVudENvbHVtbicsIDMpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnVGhlb3J5UmVzdWx0Q29sdW1uJywgNCk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdUaGVvcnlDb21tZW50Q29sdW1uJywgNSk7XHJcblxyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHVwbG9hZEZpbGUodXJsLCBmb3JtRGF0YSk7XHJcbiAgICAgICAgcmV0dXJuIHByb2Nlc3NFeGFtUmVzdWx0T3V0Y29tZShyZXN1bHQpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHByb2Nlc3NFeGFtUmVzdWx0T3V0Y29tZShyZXN1bHQpIHtcclxuICAgICAgICBjb25zdCBwYWdlID0gYXdhaXQgcmVzdWx0LnRleHQoKTtcclxuXHJcbiAgICAgICAgY29uc3Qgc3VjY2Vzc1BhdHRlcm4gPSAvPGgzPtCj0YHQv9C10YjQvdC4INC30LDQv9C40YHQuDooLis/KTxcXC9oMz4vdXM7XHJcbiAgICAgICAgY29uc3QgZmFpbHVyZVBhdHRlcm4gPSAvPGgzPtCd0LXRg9GB0L/QtdGI0L3QuCDQt9Cw0L/QuNGB0Lg6KC4rPyk8XFwvaDM+L3VzO1xyXG4gICAgICAgIGNvbnN0IHVzZXJsaXN0UGF0dGVybiA9IC88cD4uKj/Qo9GB0L/QtdGI0L3QviDQsdGP0YXQsCDQstC80YrQutC90LDRgtC4INGA0LXQt9GD0LvRgtCw0YLQuNGC0LUg0L3QsCDRgdC70LXQtNC90LjRgtC1INC/0L7RgtGA0LXQsdC40YLQtdC70Lg6KC4rPyk8XFwvcD4vdXM7XHJcblxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHN1Y2Nlc3NmdWwgPSBOdW1iZXIoc3VjY2Vzc1BhdHRlcm4uZXhlYyhwYWdlKVsxXS50cmltKCkpO1xyXG4gICAgICAgICAgICBjb25zdCBmYWlsZWQgPSBOdW1iZXIoZmFpbHVyZVBhdHRlcm4uZXhlYyhwYWdlKVsxXS50cmltKCkpO1xyXG4gICAgICAgICAgICBjb25zdCBsaXN0ID0gdXNlcmxpc3RQYXR0ZXJuLmV4ZWMocGFnZSlbMV0udHJpbSgpLnNwbGl0KCcsJykubWFwKHUgPT4gdS50cmltKCkpO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuIHsgc3VjY2Vzc2Z1bCwgZmFpbGVkLCBsaXN0IH07XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdFcnJvciBwcm9jZXNzaW5nIGZpbGUnKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gb2J0YWluUlZUKCkge1xyXG4gICAgICAgIGNvbnN0IHVybCA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvZXhhbXMvaW1wb3J0ZXhhbXJlc3VsdHMnKTtcclxuICAgICAgICBjb25zdCBwYWdlRGF0YSA9IGF3YWl0IGdldCh1cmwpO1xyXG4gICAgICAgIGNvbnN0IHBhdHRlcm4gPSAvPGlucHV0Lio/bmFtZT1cIl9fUmVxdWVzdFZlcmlmaWNhdGlvblRva2VuXCIuKj92YWx1ZT1cIiguKz8pXCIuKj8+L2k7XHJcbiAgICAgICAgY29uc3QgcnZ0ID0gcGF0dGVybi5leGVjKHBhZ2VEYXRhKVsxXTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHJ2dDtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldEhvbWV3b3JrUmVzdWx0cyxcclxuICAgICAgICBnZXRQcm90b2NvbCxcclxuICAgICAgICB1cGxvYWRFeGFtUmVzdWx0c1xyXG4gICAgfTtcclxufVxyXG4iLCJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KSB7XHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRFdmVudHMoaW5zdGFuY2VJZCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdHJhaW5pbmdncm91cGxlY3R1cmVzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJ1N0YXJ0RGF0ZVRpbWUtYXNjJyxcclxuICAgICAgICAgICAgcGFnZTogMSxcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMCxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGBUcmFpbmluZ0lkfmVxfiR7aW5zdGFuY2VJZH1gXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmksIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUV2ZW50KGV2ZW50KSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy90cmFpbmluZ2dyb3VwbGVjdHVyZXMvdXBkYXRlJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiBldmVudC5JZCxcclxuICAgICAgICAgICAgVHJhaW5pbmdHcm91cElkOiBldmVudC5UcmFpbmluZ0dyb3VwSWQsXHJcbiAgICAgICAgICAgIFRyYWluaW5nR3JvdXBOYW1lOiBldmVudC5UcmFpbmluZ0dyb3VwTmFtZSxcclxuICAgICAgICAgICAgTGVjdHVyZUlkOiBldmVudC5MZWN0dXJlSWQsXHJcbiAgICAgICAgICAgIExlY3R1cmVOYW1lOiBldmVudC5MZWN0dXJlTmFtZSxcclxuICAgICAgICAgICAgVHJhaW5pbmdJZDogZXZlbnQuVHJhaW5pbmdJZCxcclxuICAgICAgICAgICAgU3RhcnREYXRlVGltZTogZXZlbnQuU3RhcnREYXRlVGltZSxcclxuICAgICAgICAgICAgRW5kRGF0ZVRpbWU6IGV2ZW50LkVuZERhdGVUaW1lLFxyXG4gICAgICAgICAgICBIYXNMaXZlU3RyZWFtOiBldmVudC5IYXNMaXZlU3RyZWFtLFxyXG4gICAgICAgICAgICBUcmFpbmluZ0xhYklkOiBldmVudC5UcmFpbmluZ0xhYklkLFxyXG4gICAgICAgICAgICBUcmFpbmluZ0xhYk5hbWU6IGV2ZW50LlRyYWluaW5nTGFiTmFtZSxcclxuICAgICAgICAgICAgTGFzdEVkaXRlZFVzZXJuYW1lOiAnJyxcclxuICAgICAgICAgICAgQ3JlYXRlZE9uOiAnJyxcclxuICAgICAgICAgICAgTW9kaWZpZWRPbjogJycsXHJcbiAgICAgICAgICAgIFRyYWluaW5nR3JvdXBJZF9pbnB1dDogJycsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZUV2ZW50KGV2ZW50KSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy90cmFpbmluZ2dyb3VwbGVjdHVyZXMvY3JlYXRlJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiBldmVudC5JZCxcclxuICAgICAgICAgICAgVHJhaW5pbmdHcm91cElkOiBldmVudC5UcmFpbmluZ0dyb3VwSWQsXHJcbiAgICAgICAgICAgIFRyYWluaW5nR3JvdXBOYW1lOiBldmVudC5UcmFpbmluZ0dyb3VwTmFtZSxcclxuICAgICAgICAgICAgTGVjdHVyZUlkOiBldmVudC5MZWN0dXJlSWQsXHJcbiAgICAgICAgICAgIExlY3R1cmVOYW1lOiBldmVudC5MZWN0dXJlTmFtZSxcclxuICAgICAgICAgICAgVHJhaW5pbmdJZDogZXZlbnQuVHJhaW5pbmdJZCxcclxuICAgICAgICAgICAgU3RhcnREYXRlVGltZTogZXZlbnQuU3RhcnREYXRlVGltZSxcclxuICAgICAgICAgICAgRW5kRGF0ZVRpbWU6IGV2ZW50LkVuZERhdGVUaW1lLFxyXG4gICAgICAgICAgICBIYXNMaXZlU3RyZWFtOiBldmVudC5IYXNMaXZlU3RyZWFtLFxyXG4gICAgICAgICAgICBUcmFpbmluZ0xhYklkOiBldmVudC5UcmFpbmluZ0xhYklkLFxyXG4gICAgICAgICAgICBUcmFpbmluZ0xhYk5hbWU6IGV2ZW50LlRyYWluaW5nTGFiTmFtZSxcclxuICAgICAgICAgICAgTGFzdEVkaXRlZFVzZXJuYW1lOiAnJyxcclxuICAgICAgICAgICAgQ3JlYXRlZE9uOiAnJyxcclxuICAgICAgICAgICAgTW9kaWZpZWRPbjogJycsXHJcbiAgICAgICAgICAgIFRyYWluaW5nR3JvdXBJZF9pbnB1dDogJycsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGRlc3Ryb3lFdmVudChldmVudCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdHJhaW5pbmdncm91cGxlY3R1cmVzL2Rlc3Ryb3knKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJ1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIE9iamVjdC5hc3NpZ24oYm9keSwgZXZlbnQpO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuICAgICAgICBib2R5LkNyZWF0ZWRPbiA9ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNyc7XHJcbiAgICAgICAgYm9keS5Nb2RpZmllZE9uID0gJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JztcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRFdmVudHNCeURhdGUoc3RhcnREYXRlLCBlbmREYXRlKSB7XHJcbiAgICAgICAgLy8gRGF0ZSBmb3JtYXQgeXl5eS1tbS1kZCBleGFtcGxlOiAyMDIwLTAzLTI1XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy90cmFpbmluZ2dyb3VwbGVjdHVyZXMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnU3RhcnREYXRlVGltZS1hc2MnLFxyXG4gICAgICAgICAgICBwYWdlOiAxLFxyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDAsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiBgU3RhcnREYXRlVGltZX5ndGV+ZGF0ZXRpbWUnJHtzdGFydERhdGV9VDAwLTAwLTAwJ35hbmR+RW5kRGF0ZVRpbWV+bHRlfmRhdGV0aW1lJyR7ZW5kRGF0ZX1UMjMtNTktNTknYFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRFdmVudHNCeUlkKGV2ZW50SWQpIHtcclxuICAgICAgICAvLyBEYXRlIGZvcm1hdCB5eXl5LW1tLWRkIGV4YW1wbGU6IDIwMjAtMDMtMjVcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3RyYWluaW5nZ3JvdXBsZWN0dXJlcy9yZWFkJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICdTdGFydERhdGVUaW1lLWFzYycsXHJcbiAgICAgICAgICAgIHBhZ2U6IDEsXHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogYElkfmVxfiR7ZXZlbnRJZH1gXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmksIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgZ2V0RXZlbnRzLFxyXG4gICAgICAgIHVwZGF0ZUV2ZW50LFxyXG4gICAgICAgIGNyZWF0ZUV2ZW50LFxyXG4gICAgICAgIGRlc3Ryb3lFdmVudCxcclxuICAgICAgICBnZXRFdmVudHNCeURhdGUsXHJcbiAgICAgICAgZ2V0RXZlbnRzQnlJZFxyXG4gICAgfTtcclxufSIsImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCwgZ2V0IH0pIHtcclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRFeGFtc0J5SWQoaWRzKSB7XHJcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoaWRzKSA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICBpZHMgPSBbaWRzXTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGlkcy5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgICAgICByZXR1cm4gW107XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvZXhhbXMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogYElkfmVxfiR7aWRzLmpvaW4oJ35vcn5JZH5lcX4nKX1gXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmksIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEV4YW1zQnlDb3Vyc2UobmFtZUJnLCBpbnN0YW5jZUlkKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9leGFtcy9yZWFkJyk7XHJcbiAgICAgICAgY29uc3QgZmlsdGVyID0gKCgpID0+IHtcclxuICAgICAgICAgICAgaWYgKGludGVyb3BBcHBJZCgpID09PSAnc29mdHVuaS5iZycpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBgVHJhaW5pbmdOYW1lc1N0cmluZ35jb250YWluc34nJHtuYW1lQmd9J2A7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJyc7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KSgpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDAsXHJcbiAgICAgICAgICAgIGZpbHRlclxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgICAgIHJldHVybiBkYXRhLkRhdGEuZmlsdGVyKGUgPT4gZS5QcmltYXJ5VHJhaW5pbmdzLmZpbHRlcih0ID0+IHQuSWQgPT0gaW5zdGFuY2VJZCkubGVuZ3RoID4gMCB8fCBlLlJldGFrZW5UcmFpbmluZ3MuZmlsdGVyKHQgPT4gdC5JZCA9PSBpbnN0YW5jZUlkKS5sZW5ndGggPiAwKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRFeGFtc0J5TmFtZShxdWVyeSkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvZXhhbXMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KHF1ZXJ5KSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGAoTmFtZUJnfmNvbnRhaW5zficke3F1ZXJ5LmpvaW4oJ1xcJ35vcn5OYW1lQmd+Y29udGFpbnN+XFwnJyl9Jyl+b3J+KE5hbWVFbn5jb250YWluc34nJHtxdWVyeS5qb2luKCdcXCd+b3J+TmFtZUVufmNvbnRhaW5zflxcJycpfScpYDtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBgTmFtZUJnfmNvbnRhaW5zficke3F1ZXJ5fSd+b3J+TmFtZUVufmNvbnRhaW5zficke3F1ZXJ5fSdgO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSkoKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJ0NyZWF0ZWRPbi1kZXNjJyxcclxuICAgICAgICAgICAgcGFnZVNpemU6IDIwLFxyXG4gICAgICAgICAgICBmaWx0ZXJcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvc3QodXJpLCBib2R5KTtcclxuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShxdWVyeSkpIHtcclxuICAgICAgICAgICAgY29uc3QgZnVsbE1hdGNoID0gYXdhaXQgZ2V0RXhhbXNCeU5hbWUocXVlcnkuam9pbignICcpKTtcclxuICAgICAgICAgICAgY29uc3QgZmlsdGVyZWQgPSBkYXRhLkRhdGEuZmlsdGVyKHIgPT4gZnVsbE1hdGNoLnNvbWUoeCA9PiB4LklkID09IHIuSWQpID09IGZhbHNlKTtcclxuICAgICAgICAgICAgcmV0dXJuIGZ1bGxNYXRjaC5jb25jYXQoZmlsdGVyZWQuc2xpY2UoMCwgMjAgLSBmdWxsTWF0Y2gubGVuZ3RoKSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIGRhdGEuRGF0YTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0RXhhbUdyb3Vwc0J5RXhhbUlkKGV4YW1JZCkge1xyXG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KGV4YW1JZCkgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgZXhhbUlkID0gW2V4YW1JZF07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChleGFtSWQubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuIFtdO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2V4YW1ncm91cHMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogYEV4YW1JZH5lcX4ke2V4YW1JZC5qb2luKCd+b3J+RXhhbUlkfmVxficpfWBcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0RXhhbUdyb3Vwc0J5RGF0ZShzdGFydERhdGUsIGVuZERhdGUpIHtcclxuICAgICAgICAvLyBEYXRlIGZvcm1hdCB5eXl5LW1tLWRkIGV4YW1wbGU6IDIwMjAtMDMtMjVcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2V4YW1ncm91cHMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnU3RhcnRUaW1lLWFzYycsXHJcbiAgICAgICAgICAgIHBhZ2U6IDEsXHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwMCxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGBTdGFydFRpbWV+Z3RlfmRhdGV0aW1lJyR7c3RhcnREYXRlfVQwMC0wMC0wMCd+YW5kfkVuZFRpbWV+bHRlfmRhdGV0aW1lJyR7ZW5kRGF0ZX1UMjMtNTktNTknYFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRFbnJvbGxlZEJ5R3JvdXBJZChleGFtR3JvdXBJZCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvZXhhbWdyb3VwcGFydGljaXBhbnRzL3JlYWQ/Zm9yZWlnbktleUlkPSR7ZXhhbUdyb3VwSWR9YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwMFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBjcmVhdGVFeGFtKGV4YW0pIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2V4YW1zL2NyZWF0ZScpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnLFxyXG4gICAgICAgICAgICBJZDogZXhhbS5JZCxcclxuICAgICAgICAgICAgTmFtZUJnOiBleGFtLk5hbWVCZyxcclxuICAgICAgICAgICAgTmFtZUVuOiBleGFtLk5hbWVFbixcclxuICAgICAgICAgICAgVHlwZTogZXhhbS5UeXBlLFxyXG4gICAgICAgICAgICBBbGxvd0Nob29zaW5nU2VhdHNXaXRoQ29tcHV0ZXI6IGV4YW0uQWxsb3dDaG9vc2luZ1NlYXRzV2l0aENvbXB1dGVyLFxyXG4gICAgICAgICAgICBBbGxvd0FsbFVzZXJzSW5UcmFpbmluZ3NUb1NpdEV4YW06IGV4YW0uQWxsb3dBbGxVc2Vyc0luVHJhaW5pbmdzVG9TaXRFeGFtLFxyXG4gICAgICAgICAgICBFeGFtR3JvdXBFbnJvbGxtZW50RGVhZGxpbmU6IGV4YW0uRXhhbUdyb3VwRW5yb2xsbWVudERlYWRsaW5lLFxyXG4gICAgICAgICAgICBUcmFpbmluZ05hbWVzU3RyaW5nOiAnJyxcclxuICAgICAgICAgICAgQ3JlYXRlZE9uOiAnJyxcclxuICAgICAgICAgICAgTW9kaWZpZWRPbjogJydcclxuICAgICAgICB9KTtcclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCkgeyBib2R5W2tdID0gJyc7IH0gfSk7XHJcblxyXG4gICAgICAgIC8vIFR3by1zdGVwIHByb2Nlc3MgaXMgbmVjZXNzYXJ5IGJlY2F1c2Ugb2YgYSBzZXJ2ZXIgYnVnIHdoZW4gdGhlIGV4YW0gaGFzIGFzc29jaWF0ZWQgdHJhaW5pbmcgaW5zdGFuY2VzXHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgICAgIGlmIChyZXN1bHQuRXJyb3JzICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgY29uc3QgaXRlbSA9IHJlc3VsdC5EYXRhWzBdO1xyXG4gICAgICAgICAgICBpdGVtLlByaW1hcnlUcmFpbmluZ3MgPSBleGFtLlByaW1hcnlUcmFpbmluZ3M7XHJcbiAgICAgICAgICAgIGl0ZW0uUmV0YWtlblRyYWluaW5ncyA9IGV4YW0uUmV0YWtlblRyYWluaW5ncztcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IGRlYWRsaW5lID0gbmV3IERhdGUoTnVtYmVyKGl0ZW0uRXhhbUdyb3VwRW5yb2xsbWVudERlYWRsaW5lLm1hdGNoKC9cXGQrLylbMF0pKTtcclxuICAgICAgICAgICAgaXRlbS5FeGFtR3JvdXBFbnJvbGxtZW50RGVhZGxpbmUgPSBOdW1iZXIuaXNOYU4oZGVhZGxpbmUpID8gJycgOiBkZWFkbGluZS50b0lTT1N0cmluZygpO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuIHVwZGF0ZUV4YW0oaXRlbSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUV4YW0oZXhhbSkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvZXhhbXMvdXBkYXRlJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiBleGFtLklkLFxyXG4gICAgICAgICAgICBOYW1lQmc6IGV4YW0uTmFtZUJnLFxyXG4gICAgICAgICAgICBOYW1lRW46IGV4YW0uTmFtZUVuLFxyXG4gICAgICAgICAgICBUeXBlOiBleGFtLlR5cGUsXHJcbiAgICAgICAgICAgIEFsbG93Q2hvb3NpbmdTZWF0c1dpdGhDb21wdXRlcjogZXhhbS5BbGxvd0Nob29zaW5nU2VhdHNXaXRoQ29tcHV0ZXIsXHJcbiAgICAgICAgICAgIEFsbG93QWxsVXNlcnNJblRyYWluaW5nc1RvU2l0RXhhbTogZXhhbS5BbGxvd0FsbFVzZXJzSW5UcmFpbmluZ3NUb1NpdEV4YW0sXHJcbiAgICAgICAgICAgIEV4YW1Hcm91cEVucm9sbG1lbnREZWFkbGluZTogZXhhbS5FeGFtR3JvdXBFbnJvbGxtZW50RGVhZGxpbmUsXHJcbiAgICAgICAgICAgIFRyYWluaW5nTmFtZXNTdHJpbmc6ICcnLFxyXG4gICAgICAgICAgICBDcmVhdGVkT246ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNydcclxuICAgICAgICB9KTtcclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCkgeyBib2R5W2tdID0gJyc7IH0gfSk7XHJcblxyXG4gICAgICAgIGV4YW0uUHJpbWFyeVRyYWluaW5ncy5mb3JFYWNoKHRyYWluaW5nc1RvQm9keSgnUHJpbWFyeVRyYWluaW5ncycpKTtcclxuICAgICAgICBleGFtLlJldGFrZW5UcmFpbmluZ3MuZm9yRWFjaCh0cmFpbmluZ3NUb0JvZHkoJ1JldGFrZW5UcmFpbmluZ3MnKSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIHRyYWluaW5nc1RvQm9keShwcm9wTmFtZSkge1xyXG4gICAgICAgICAgICByZXR1cm4gZnVuY3Rpb24gKHRyYWluaW5nLCBpbmRleCkge1xyXG4gICAgICAgICAgICAgICAgYm9keVtgJHtwcm9wTmFtZX1bJHtpbmRleH1dLklkYF0gPSB0cmFpbmluZy5JZDtcclxuICAgICAgICAgICAgICAgIGJvZHlbYCR7cHJvcE5hbWV9WyR7aW5kZXh9XS5OYW1lYF0gPSB0cmFpbmluZy5OYW1lQmc7XHJcbiAgICAgICAgICAgICAgICBib2R5W2Ake3Byb3BOYW1lfVske2luZGV4fV0uTmFtZUJnYF0gPSB0cmFpbmluZy5OYW1lQmc7XHJcbiAgICAgICAgICAgICAgICBib2R5W2Ake3Byb3BOYW1lfVske2luZGV4fV0uTmFtZUVuYF0gPSB0cmFpbmluZy5OYW1lRW47XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZUV4YW1Hcm91cChncm91cCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvZXhhbWdyb3Vwcy9jcmVhdGUnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgSWQ6ICcwJyxcclxuICAgICAgICAgICAgRXhhbUlkOiBncm91cC5FeGFtSWQsXHJcbiAgICAgICAgICAgIEV4YW1OYW1lOiAnJyxcclxuICAgICAgICAgICAgU3RhcnRUaW1lOiBncm91cC5TdGFydFRpbWUsXHJcbiAgICAgICAgICAgIEVuZFRpbWU6IGdyb3VwLkVuZFRpbWUsXHJcbiAgICAgICAgICAgIFRyYWluaW5nTGFiSWQ6IGdyb3VwLlRyYWluaW5nTGFiSWQsXHJcbiAgICAgICAgICAgIEp1ZGdlU3lzdGVtQ29udGVzdElkOiBncm91cC5KdWRnZVN5c3RlbUNvbnRlc3RJZCxcclxuICAgICAgICAgICAgVGVzdFN5c3RlbVRlc3RJZDogZ3JvdXAuVGVzdFN5c3RlbVRlc3RJZCxcclxuICAgICAgICAgICAgRXhhbUdyb3VwUGFydGljaXBhbnRzQ291bnQ6IGdyb3VwLkV4YW1Hcm91cFBhcnRpY2lwYW50c0NvdW50LFxyXG4gICAgICAgICAgICBMaW1pdDogZ3JvdXAuTGltaXQsXHJcbiAgICAgICAgICAgIElzQWRkZWRUb0dvb2dsZUNhbGVuZGFyOiBncm91cC5Jc0FkZGVkVG9Hb29nbGVDYWxlbmRhcixcclxuICAgICAgICAgICAgQ3VzdG9tRW5yb2xsbWVudFN1Y2Nlc3NNZXNzYWdlOiBncm91cC5DdXN0b21FbnJvbGxtZW50U3VjY2Vzc01lc3NhZ2UsXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogJycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcnXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUV4YW1Hcm91cChncm91cCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvZXhhbWdyb3Vwcy91cGRhdGUnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgSWQ6IGdyb3VwLklkLFxyXG4gICAgICAgICAgICBFeGFtSWQ6IGdyb3VwLkV4YW1JZCxcclxuICAgICAgICAgICAgRXhhbU5hbWU6IGdyb3VwLkV4YW1OYW1lLFxyXG4gICAgICAgICAgICBTdGFydFRpbWU6IGdyb3VwLlN0YXJ0VGltZSxcclxuICAgICAgICAgICAgRW5kVGltZTogZ3JvdXAuRW5kVGltZSxcclxuICAgICAgICAgICAgVHJhaW5pbmdMYWJJZDogZ3JvdXAuVHJhaW5pbmdMYWJJZCxcclxuICAgICAgICAgICAgSnVkZ2VTeXN0ZW1Db250ZXN0SWQ6IGdyb3VwLkp1ZGdlU3lzdGVtQ29udGVzdElkLFxyXG4gICAgICAgICAgICBUZXN0U3lzdGVtVGVzdElkOiBncm91cC5UZXN0U3lzdGVtVGVzdElkLFxyXG4gICAgICAgICAgICBFeGFtR3JvdXBQYXJ0aWNpcGFudHNDb3VudDogZ3JvdXAuRXhhbUdyb3VwUGFydGljaXBhbnRzQ291bnQsXHJcbiAgICAgICAgICAgIExpbWl0OiBncm91cC5MaW1pdCxcclxuICAgICAgICAgICAgSXNBZGRlZFRvR29vZ2xlQ2FsZW5kYXI6IGdyb3VwLklzQWRkZWRUb0dvb2dsZUNhbGVuZGFyLFxyXG4gICAgICAgICAgICBDdXN0b21FbnJvbGxtZW50U3VjY2Vzc01lc3NhZ2U6IGdyb3VwLkN1c3RvbUVucm9sbG1lbnRTdWNjZXNzTWVzc2FnZSxcclxuICAgICAgICAgICAgQ3JlYXRlZE9uOiAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnLFxyXG4gICAgICAgICAgICBNb2RpZmllZE9uOiAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGRlc3Ryb3lFeGFtR3JvdXAoZ3JvdXApIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2V4YW1ncm91cHMvZGVzdHJveScpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgT2JqZWN0LmFzc2lnbihib2R5LCBncm91cCk7XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG4gICAgICAgIGJvZHkuQ3JlYXRlZE9uID0gJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JztcclxuICAgICAgICBib2R5Lk1vZGlmaWVkT24gPSAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgZ2V0RXhhbXNCeUlkLFxyXG4gICAgICAgIGdldEV4YW1zQnlDb3Vyc2UsXHJcbiAgICAgICAgZ2V0RXhhbXNCeU5hbWUsXHJcbiAgICAgICAgZ2V0RXhhbUdyb3Vwc0J5RXhhbUlkLFxyXG4gICAgICAgIGdldEVucm9sbGVkQnlHcm91cElkLFxyXG4gICAgICAgIGdldEV4YW1Hcm91cHNCeURhdGUsXHJcbiAgICAgICAgY3JlYXRlRXhhbSxcclxuICAgICAgICB1cGRhdGVFeGFtLFxyXG4gICAgICAgIGNyZWF0ZUV4YW1Hcm91cCxcclxuICAgICAgICB1cGRhdGVFeGFtR3JvdXAsXHJcbiAgICAgICAgZGVzdHJveUV4YW1Hcm91cFxyXG4gICAgfTtcclxufVxyXG4iLCJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KSB7XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0SW5zYW5jZUdyb3VwcyhpbnN0YW5jZUlkKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy90cmFpbmluZ2dyb3Vwcy9yZWFkJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogYFRyYWluaW5nSWR+ZXF+JHtpbnN0YW5jZUlkfWBcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0R3JvdXBCeUlkKGdyb3VwSWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3RyYWluaW5nZ3JvdXBzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMCxcclxuICAgICAgICAgICAgZmlsdGVyOiBgSWR+ZXF+JHtncm91cElkfWBcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGFbMF07XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gY3JlYXRlVHJhaW5pbmdHcm91cChncm91cCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdHJhaW5pbmdncm91cHMvY3JlYXRlJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiBncm91cC5JZCxcclxuICAgICAgICAgICAgVHJhaW5pbmdJZDogZ3JvdXAuVHJhaW5pbmdJZCxcclxuICAgICAgICAgICAgVHJhaW5pbmdOYW1lOiBncm91cC5UcmFpbmluZ05hbWUsXHJcbiAgICAgICAgICAgIFRyYWluaW5nTGFiSWQ6IGdyb3VwLlRyYWluaW5nTGFiSWQsXHJcbiAgICAgICAgICAgIE5hbWU6IGdyb3VwLk5hbWUsXHJcbiAgICAgICAgICAgIERheU9mV2VlazogZ3JvdXAuRGF5T2ZXZWVrLFxyXG4gICAgICAgICAgICBTdGFydFRpbWU6IGdyb3VwLlN0YXJ0VGltZSxcclxuICAgICAgICAgICAgRW5kVGltZTogZ3JvdXAuRW5kVGltZSxcclxuICAgICAgICAgICAgU2tpcFdlZWtzQ291bnQ6IGdyb3VwLlNraXBXZWVrc0NvdW50LFxyXG4gICAgICAgICAgICBXZWVrTGVjdHVyZU51bWJlcjogZ3JvdXAuV2Vla0xlY3R1cmVOdW1iZXIsXHJcbiAgICAgICAgICAgIFBlb3BsZUxpbWl0OiBncm91cC5QZW9wbGVMaW1pdCxcclxuICAgICAgICAgICAgVGFrZW5QbGFjZXM6IGdyb3VwLlRha2VuUGxhY2VzLFxyXG4gICAgICAgICAgICBJc0FkZGVkVG9Hb29nbGVDYWxlbmRhcjogZ3JvdXAuSXNBZGRlZFRvR29vZ2xlQ2FsZW5kYXIsXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogJycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcnXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGRlc3Ryb3lHcm91cChncm91cCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdHJhaW5pbmdncm91cHMvZGVzdHJveScpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgT2JqZWN0LmFzc2lnbihib2R5LCBncm91cCk7XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG4gICAgICAgIGJvZHkuQ3JlYXRlZE9uID0gJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JztcclxuICAgICAgICBib2R5Lk1vZGlmaWVkT24gPSAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgZ2V0SW5zYW5jZUdyb3VwcyxcclxuICAgICAgICBnZXRHcm91cEJ5SWQsXHJcbiAgICAgICAgY3JlYXRlVHJhaW5pbmdHcm91cCxcclxuICAgICAgICBkZXN0cm95R3JvdXBcclxuICAgIH07XHJcbn0iLCJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KSB7XHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRJbnN0YW5jZUxlY3R1cmVzKGluc3RhbmNlSWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2xlY3R1cmVzL3JlYWQ/Zm9yZWlnbktleUlkPSR7aW5zdGFuY2VJZH1gKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJ09yZGVyQnktYXNjJyxcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMCxcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0TGVjdHVyZXNGb3JFeGFtc0J5VHJhaW5pbmdJZCh0cmFpbmluZ0lkKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9sZWN0dXJlcy9yZWFkP2ZvcmVpZ25LZXlJZD0ke3RyYWluaW5nSWR9YCk7XHJcbiAgICAgICAgY29uc3QgZXhhbUtleXdvcmRzID0gWydleGFtJywgJ2RlZmVuY2UnLCAnZGVmZW5zZScsICfQuNC30L/QuNGCJywgJ9C30LDRidC40YLQsCddO1xyXG4gICAgICAgIGNvbnN0IGV4YW1FeGNsdWRlS2V5d29yZHMgPSBbJ3ByZXBhcmF0aW9uJywgJ9C/0L7QtNCz0L7RgtC+0LLQutCwJ107XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICdPcmRlckJ5LWFzYycsXHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogYChOYW1lQmd+Y29udGFpbnN+JyR7ZXhhbUtleXdvcmRzLmpvaW4oJ1xcJ35vcn5OYW1lQmd+Y29udGFpbnN+XFwnJyl9Jyl+YW5kfihOYW1lQmd+ZG9lc25vdGNvbnRhaW5+JyR7ZXhhbUV4Y2x1ZGVLZXl3b3Jkcy5qb2luKCdcXCd+YW5kfk5hbWVCZ35kb2Vzbm90Y29udGFpbn5cXCcnKX0nKWBcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gdXBkYXRlTGVjdHVyZShsZWN0dXJlKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2cobGVjdHVyZSk7XHJcblxyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvbGVjdHVyZXMvdXBkYXRlP2ZvcmVpZ25LZXlJZD0ke2xlY3R1cmUuVHJhaW5pbmdJZH1gKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgSWQ6IGxlY3R1cmUuSWQsXHJcbiAgICAgICAgICAgIFRyYWluaW5nSWQ6IGxlY3R1cmUuVHJhaW5pbmdJZCxcclxuICAgICAgICAgICAgTmFtZUJnOiBsZWN0dXJlLk5hbWVCZyxcclxuICAgICAgICAgICAgTmFtZUVuOiBsZWN0dXJlLk5hbWVFbixcclxuICAgICAgICAgICAgSGFzTWFudWFsTnVtYmVyT2ZTdHVkeUhvdXJzOiBsZWN0dXJlLkhhc01hbnVhbE51bWJlck9mU3R1ZHlIb3VycyxcclxuICAgICAgICAgICAgTnVtYmVyT2ZTdHVkeUhvdXJzOiBsZWN0dXJlLk51bWJlck9mU3R1ZHlIb3VycyxcclxuICAgICAgICAgICAgSXNFeGNsdWRlZEZyb21DZXJ0aWZpY2F0ZTogbGVjdHVyZS5Jc0V4Y2x1ZGVkRnJvbUNlcnRpZmljYXRlLFxyXG4gICAgICAgICAgICBIYXNIb21ld29yazogbGVjdHVyZS5IYXNIb21ld29yayxcclxuICAgICAgICAgICAgUmVzb3VyY2VNYWlsc1N0YXRlOiBsZWN0dXJlLlJlc291cmNlTWFpbHNTdGF0ZSxcclxuICAgICAgICAgICAgSG9tZXdvcmtNYWlsc1N0YXRlOiBsZWN0dXJlLkhvbWV3b3JrTWFpbHNTdGF0ZSxcclxuICAgICAgICAgICAgSnVkZ2VDb250ZXN0SWQ6IGxlY3R1cmUuSnVkZ2VDb250ZXN0SWQsXHJcbiAgICAgICAgICAgIEFscGhhSnVkZ2VDb250ZXN0SWQ6IGxlY3R1cmUuQWxwaGFKdWRnZUNvbnRlc3RJZCxcclxuICAgICAgICAgICAgT3JkZXJCeTogbGVjdHVyZS5PcmRlckJ5LFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkJnOiBsZWN0dXJlLkRlc2NyaXB0aW9uQmcsXHJcbiAgICAgICAgICAgIERlc2NyaXB0aW9uRW46IGxlY3R1cmUuRGVzY3JpcHRpb25FbixcclxuICAgICAgICAgICAgRGF0ZXNJbmZvOiBsZWN0dXJlLkRhdGVzSW5mbyB8fCBbXSxcclxuICAgICAgICAgICAgTGVjdHVyZXI6IGxlY3R1cmUuTGVjdHVyZXIsXHJcbiAgICAgICAgICAgIExlY3R1cmVUeXBlOiBsZWN0dXJlLkxlY3R1cmVUeXBlLFxyXG4gICAgICAgICAgICBFeGNsdWRlRnJvbUNhbGVuZGFyOiBsZWN0dXJlLkV4Y2x1ZGVGcm9tQ2FsZW5kYXIsXHJcbiAgICAgICAgICAgIEhhc0xpdmVTdHJlYW06IGxlY3R1cmUuSGFzTGl2ZVN0cmVhbSxcclxuICAgICAgICAgICAgRXhhbVBhc3N3b3JkOiBsZWN0dXJlLkV4YW1QYXNzd29yZCxcclxuICAgICAgICAgICAgRGlzY29yZENoYW5uZWw6IGxlY3R1cmUuRGlzY29yZENoYW5uZWwsXHJcbiAgICAgICAgICAgIFNsaWRvQ29kZTogbGVjdHVyZS5TbGlkb0NvZGUsXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JyxcclxuICAgICAgICAgICAgTW9kaWZpZWRPbjogJzIwMTktMDctMzFUMTc6Mzk6MDIuMzE3J1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNlcmlhbGl6ZURhdGVzSW5mbyhib2R5KTtcclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCkgeyBib2R5W2tdID0gJyc7IH0gfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gY3JlYXRlTGVjdHVyZShsZWN0dXJlKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9sZWN0dXJlcy9jcmVhdGU/Zm9yZWlnbktleUlkPSR7bGVjdHVyZS5UcmFpbmluZ0lkfWApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnLFxyXG4gICAgICAgICAgICBJZDogbGVjdHVyZS5JZCxcclxuICAgICAgICAgICAgVHJhaW5pbmdJZDogbGVjdHVyZS5UcmFpbmluZ0lkLFxyXG4gICAgICAgICAgICBOYW1lQmc6IGxlY3R1cmUuTmFtZUJnLFxyXG4gICAgICAgICAgICBOYW1lRW46IGxlY3R1cmUuTmFtZUVuLFxyXG4gICAgICAgICAgICBIYXNNYW51YWxOdW1iZXJPZlN0dWR5SG91cnM6IGxlY3R1cmUuSGFzTWFudWFsTnVtYmVyT2ZTdHVkeUhvdXJzLFxyXG4gICAgICAgICAgICBOdW1iZXJPZlN0dWR5SG91cnM6IGxlY3R1cmUuTnVtYmVyT2ZTdHVkeUhvdXJzLFxyXG4gICAgICAgICAgICBJc0V4Y2x1ZGVkRnJvbUNlcnRpZmljYXRlOiBsZWN0dXJlLklzRXhjbHVkZWRGcm9tQ2VydGlmaWNhdGUsXHJcbiAgICAgICAgICAgIEhhc0hvbWV3b3JrOiBsZWN0dXJlLkhhc0hvbWV3b3JrLFxyXG4gICAgICAgICAgICBSZXNvdXJjZU1haWxzU3RhdGU6IGxlY3R1cmUuUmVzb3VyY2VNYWlsc1N0YXRlLFxyXG4gICAgICAgICAgICBIb21ld29ya01haWxzU3RhdGU6IGxlY3R1cmUuSG9tZXdvcmtNYWlsc1N0YXRlLFxyXG4gICAgICAgICAgICBKdWRnZUNvbnRlc3RJZDogbGVjdHVyZS5KdWRnZUNvbnRlc3RJZCxcclxuICAgICAgICAgICAgQWxwaGFKdWRnZUNvbnRlc3RJZDogbGVjdHVyZS5BbHBoYUp1ZGdlQ29udGVzdElkLFxyXG4gICAgICAgICAgICBPcmRlckJ5OiBsZWN0dXJlLk9yZGVyQnksXHJcbiAgICAgICAgICAgIERlc2NyaXB0aW9uQmc6IGxlY3R1cmUuRGVzY3JpcHRpb25CZyxcclxuICAgICAgICAgICAgRGVzY3JpcHRpb25FbjogbGVjdHVyZS5EZXNjcmlwdGlvbkVuLFxyXG4gICAgICAgICAgICBEYXRlc0luZm86IGxlY3R1cmUuRGF0ZXNJbmZvIHx8IFtdLFxyXG4gICAgICAgICAgICBMZWN0dXJlcjogbGVjdHVyZS5MZWN0dXJlcixcclxuICAgICAgICAgICAgTGVjdHVyZVR5cGU6IGxlY3R1cmUuTGVjdHVyZVR5cGUsXHJcbiAgICAgICAgICAgIEV4Y2x1ZGVGcm9tQ2FsZW5kYXI6IGxlY3R1cmUuRXhjbHVkZUZyb21DYWxlbmRhcixcclxuICAgICAgICAgICAgSGFzTGl2ZVN0cmVhbTogbGVjdHVyZS5IYXNMaXZlU3RyZWFtLFxyXG4gICAgICAgICAgICBFeGFtUGFzc3dvcmQ6IGxlY3R1cmUuRXhhbVBhc3N3b3JkLFxyXG4gICAgICAgICAgICBEaXNjb3JkQ2hhbm5lbDogbGVjdHVyZS5EaXNjb3JkQ2hhbm5lbCxcclxuICAgICAgICAgICAgU2xpZG9Db2RlOiBsZWN0dXJlLlNsaWRvQ29kZSxcclxuICAgICAgICAgICAgQ3JlYXRlZE9uOiAnJyxcclxuICAgICAgICAgICAgTW9kaWZpZWRPbjogJydcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXJpYWxpemVEYXRlc0luZm8oYm9keSk7XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGRlc3Ryb3lMZWN0dXJlKGxlY3R1cmUpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2xlY3R1cmVzL2Rlc3Ryb3k/Zm9yZWlnbktleUlkPSR7bGVjdHVyZS5UcmFpbmluZ0lkfWApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgT2JqZWN0LmFzc2lnbihib2R5LCBsZWN0dXJlKTtcclxuICAgICAgICBzZXJpYWxpemVEYXRlc0luZm8oYm9keSk7XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG4gICAgICAgIGJvZHkuQ3JlYXRlZE9uID0gJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JztcclxuICAgICAgICBib2R5Lk1vZGlmaWVkT24gPSAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldExlY3R1cmVEZXRhaWxzKHRyYWluaW5nSWQsIGxlY3R1cmVJZCkge1xyXG4gICAgICAgIGNvbnN0IHVybCA9IGludGVyb3BIb3N0KGB0cmFpbmluZ3MvdHJhaW5pbmdzL2dldGxlY3R1cmVkZXRhaWxzP3RyYWluaW5nSWQ9JHt0cmFpbmluZ0lkfSZsZWN0dXJlSWQ9JHtsZWN0dXJlSWR9YCk7XHJcbiAgICAgICAgcmV0dXJuIGdldCh1cmwpO1xyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIHNlcmlhbGl6ZURhdGVzSW5mbyhib2R5KSB7XHJcbiAgICAgICAgY29uc3QgZGF0ZXNJbmZvID0gYm9keS5EYXRlc0luZm87XHJcbiAgICAgICAgZGVsZXRlIGJvZHkuRGF0ZXNJbmZvO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGF0ZXNJbmZvLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGRhdGUgPSBkYXRlc0luZm9baV07XHJcbiAgICAgICAgICAgIGJvZHlbYERhdGVzSW5mb1ske2l9XS5TdGFydGBdID0gZGF0ZS5TdGFydDtcclxuICAgICAgICAgICAgYm9keVtgRGF0ZXNJbmZvWyR7aX1dLkVuZGBdID0gZGF0ZS5FbmQ7XHJcbiAgICAgICAgICAgIGJvZHlbYERhdGVzSW5mb1ske2l9XS5FeHRyYUluZm9ybWF0aW9uYF0gPSBkYXRlLkV4dHJhSW5mb3JtYXRpb247XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgZ2V0SW5zdGFuY2VMZWN0dXJlcyxcclxuICAgICAgICB1cGRhdGVMZWN0dXJlLFxyXG4gICAgICAgIGNyZWF0ZUxlY3R1cmUsXHJcbiAgICAgICAgZGVzdHJveUxlY3R1cmUsXHJcbiAgICAgICAgZ2V0TGVjdHVyZURldGFpbHMsXHJcbiAgICAgICAgZ2V0TGVjdHVyZXNGb3JFeGFtc0J5VHJhaW5pbmdJZFxyXG4gICAgfTtcclxufSIsImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCwgZ2V0IH0pIHtcclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFNlbWluYXJzQnlEYXRlKHN0YXJ0RGF0ZSwgZW5kRGF0ZSkge1xyXG4gICAgICAgIC8vIERhdGUgZm9ybWF0IHl5eXktbW0tZGQgZXhhbXBsZTogMjAyMC0wMy0yNVxyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3Mvc2VtaW5hcnMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnU3RhcnREYXRlLWFzYycsXHJcbiAgICAgICAgICAgIHBhZ2U6IDEsXHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwMCxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGBTdGFydERhdGV+Z3RlfmRhdGV0aW1lJyR7c3RhcnREYXRlfVQwMC0wMC0wMCd+YW5kfkVuZERhdGV+bHRlfmRhdGV0aW1lJyR7ZW5kRGF0ZX1UMjMtNTktNTknYFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldFNlbWluYXJzQnlEYXRlXHJcbiAgICB9O1xyXG59IiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSkge1xyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0U2tpbGxzQnlJbnN0YW5jZShuYW1lLCBpbnN0YW5jZUlkKSB7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwMCxcclxuICAgICAgICAgICAgc29ydDogJ09yZGVyQnktYXNjJ1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBib2R5LmZpbHRlciA9IGBNZXJnZWRUcmFpbmluZ3N+Y29udGFpbnN+JyR7bmFtZX0nYDtcclxuXHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgICAgICAgcG9zdChpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2Zhc3R0cmFja2luc3RhbmNlc2tpbGxzL3JlYWQnKSwgYm9keSksXHJcbiAgICAgICAgICAgIHBvc3QoaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9jb3Vyc2VpbnN0YW5jZXNraWxscy9yZWFkJyksIGJvZHkpLFxyXG4gICAgICAgIF0pO1xyXG4gICAgICAgIGxldCByZXNwb25zZSA9IFtdO1xyXG4gICAgICAgIHJlc3BvbnNlID0gcmVzcG9uc2UuY29uY2F0KGRhdGFbMF0uRGF0YS5maWx0ZXIoaSA9PiBpLlRyYWluaW5ncy5maWx0ZXIodCA9PiB0LklkID09IGluc3RhbmNlSWQpLmxlbmd0aCA+IDApLm1hcChzID0+IHsgcy5UeXBlID0gJ29wZW4nOyByZXR1cm4gczsgfSkpO1xyXG4gICAgICAgIHJlc3BvbnNlID0gcmVzcG9uc2UuY29uY2F0KGRhdGFbMV0uRGF0YS5maWx0ZXIoaSA9PiBpLlRyYWluaW5ncy5maWx0ZXIodCA9PiB0LklkID09IGluc3RhbmNlSWQpLmxlbmd0aCA+IDApLm1hcChzID0+IHsgcy5UeXBlID0gJ21haW4nOyByZXR1cm4gczsgfSkpO1xyXG5cclxuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gdXBkYXRlU2tpbGwoc2tpbGwpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzLyR7c2tpbGwuVHlwZSA9PT0gJ21haW4nID8gJ2NvdXJzZWluc3RhbmNlc2tpbGxzJyA6ICdmYXN0dHJhY2tpbnN0YW5jZXNraWxscyd9L3VwZGF0ZWApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnLFxyXG4gICAgICAgICAgICBJZDogc2tpbGwuSWQsXHJcbiAgICAgICAgICAgIFRleHRCZzogc2tpbGwuVGV4dEJnLFxyXG4gICAgICAgICAgICBPcmRlckJ5OiBza2lsbC5PcmRlckJ5LFxyXG4gICAgICAgICAgICBNZXJnZWRUcmFpbmluZ3M6IHNraWxsLk1lcmdlZFRyYWluaW5ncyxcclxuICAgICAgICAgICAgQ3JlYXRlZE9uOiAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnLFxyXG4gICAgICAgICAgICBNb2RpZmllZE9uOiAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBza2lsbC5UcmFpbmluZ3MubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgY29uc3QgdHJhaW5pbmcgPSBza2lsbC5UcmFpbmluZ3NbaV07XHJcbiAgICAgICAgICAgIGJvZHlbYFRyYWluaW5nc1ske2l9XS5JZGBdID0gdHJhaW5pbmcuSWQ7XHJcbiAgICAgICAgICAgIGJvZHlbYFRyYWluaW5nc1ske2l9XS5OYW1lYF0gPSB0cmFpbmluZy5OYW1lO1xyXG4gICAgICAgICAgICBib2R5W2BUcmFpbmluZ3NbJHtpfV0uTmFtZUJnYF0gPSB0cmFpbmluZy5OYW1lQmc7XHJcbiAgICAgICAgICAgIGJvZHlbYFRyYWluaW5nc1ske2l9XS5OYW1lRW5gXSA9IHRyYWluaW5nLk5hbWVFbjtcclxuICAgICAgICB9XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICAgICAgcmVzdWx0LkRhdGFbMF0uVHlwZSA9IHNraWxsLlR5cGU7XHJcblxyXG4gICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gY3JlYXRlU2tpbGwoc2tpbGwpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzLyR7c2tpbGwuVHlwZSA9PT0gJ21haW4nID8gJ2NvdXJzZWluc3RhbmNlc2tpbGxzJyA6ICdmYXN0dHJhY2tpbnN0YW5jZXNraWxscyd9L2NyZWF0ZWApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnLFxyXG4gICAgICAgICAgICBJZDogc2tpbGwuSWQsXHJcbiAgICAgICAgICAgIFRleHRCZzogc2tpbGwuVGV4dEJnLFxyXG4gICAgICAgICAgICBPcmRlckJ5OiBza2lsbC5PcmRlckJ5LFxyXG4gICAgICAgICAgICBNZXJnZWRUcmFpbmluZ3M6IHNraWxsLk1lcmdlZFRyYWluaW5ncyxcclxuICAgICAgICAgICAgQ3JlYXRlZE9uOiAnJyxcclxuICAgICAgICAgICAgTW9kaWZpZWRPbjogJydcclxuICAgICAgICB9KTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNraWxsLlRyYWluaW5ncy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBjb25zdCB0cmFpbmluZyA9IHNraWxsLlRyYWluaW5nc1tpXTtcclxuICAgICAgICAgICAgYm9keVtgVHJhaW5pbmdzWyR7aX1dLklkYF0gPSB0cmFpbmluZy5JZDtcclxuICAgICAgICAgICAgYm9keVtgVHJhaW5pbmdzWyR7aX1dLk5hbWVgXSA9IHRyYWluaW5nLk5hbWU7XHJcbiAgICAgICAgICAgIGJvZHlbYFRyYWluaW5nc1ske2l9XS5OYW1lQmdgXSA9IHRyYWluaW5nLk5hbWVCZztcclxuICAgICAgICAgICAgYm9keVtgVHJhaW5pbmdzWyR7aX1dLk5hbWVFbmBdID0gdHJhaW5pbmcuTmFtZUVuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCkgeyBib2R5W2tdID0gJyc7IH0gfSk7XHJcblxyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHBvc3QodXJpLCBib2R5KTtcclxuICAgICAgICByZXN1bHQuRGF0YVswXS5UeXBlID0gc2tpbGwuVHlwZTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBkZXN0cm95U2tpbGwoc2tpbGwpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzLyR7c2tpbGwuVHlwZSA9PT0gJ21haW4nID8gJ2NvdXJzZWluc3RhbmNlc2tpbGxzJyA6ICdmYXN0dHJhY2tpbnN0YW5jZXNraWxscyd9L2Rlc3Ryb3lgKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJ1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIE9iamVjdC5hc3NpZ24oYm9keSwgc2tpbGwpO1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc2tpbGwuVHJhaW5pbmdzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHRyYWluaW5nID0gc2tpbGwuVHJhaW5pbmdzW2ldO1xyXG4gICAgICAgICAgICBib2R5W2BUcmFpbmluZ3NbJHtpfV0uSWRgXSA9IHRyYWluaW5nLklkO1xyXG4gICAgICAgICAgICBib2R5W2BUcmFpbmluZ3NbJHtpfV0uTmFtZWBdID0gdHJhaW5pbmcuTmFtZTtcclxuICAgICAgICAgICAgYm9keVtgVHJhaW5pbmdzWyR7aX1dLk5hbWVCZ2BdID0gdHJhaW5pbmcuTmFtZUJnO1xyXG4gICAgICAgICAgICBib2R5W2BUcmFpbmluZ3NbJHtpfV0uTmFtZUVuYF0gPSB0cmFpbmluZy5OYW1lRW47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGRlbGV0ZSBib2R5LlRyYWluaW5ncztcclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCkgeyBib2R5W2tdID0gJyc7IH0gfSk7XHJcbiAgICAgICAgYm9keS5DcmVhdGVkT24gPSAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnO1xyXG4gICAgICAgIGJvZHkuTW9kaWZpZWRPbiA9ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNyc7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gc2VhcmNoU2tpbGxzKHF1ZXJ5LCB0eXBlKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy8ke3R5cGUgPT09ICdtYWluJyA/ICdjb3Vyc2VpbnN0YW5jZXNraWxscycgOiAnZmFzdHRyYWNraW5zdGFuY2Vza2lsbHMnfS9yZWFkYCk7XHJcblxyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTUsXHJcbiAgICAgICAgICAgIHNvcnQ6ICdPcmRlckJ5LWFzYycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogYFRleHRCZ35jb250YWluc34nJHtxdWVyeX0nYFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgICAgIGRhdGEuRGF0YS5mb3JFYWNoKHMgPT4gcy5UeXBlID0gdHlwZSk7XHJcblxyXG4gICAgICAgIHJldHVybiBkYXRhLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBnZXRTa2lsbHNCeUluc3RhbmNlLFxyXG4gICAgICAgIHVwZGF0ZVNraWxsLFxyXG4gICAgICAgIGNyZWF0ZVNraWxsLFxyXG4gICAgICAgIGRlc3Ryb3lTa2lsbCxcclxuICAgICAgICBzZWFyY2hTa2lsbHNcclxuICAgIH07XHJcbn0iLCJpbXBvcnQgZXZlbnRzQXBpRmFjdG9yeSBmcm9tICcuL2V2ZW50cyc7XHJcbmltcG9ydCBsZWN0dXJlc0FwaUZhY3RvcnkgZnJvbSAnLi9sZWN0dXJlcyc7XHJcbmltcG9ydCBza2lsbHNBcGlGYWN0b3J5IGZyb20gJy4vc2tpbGxzJztcclxuaW1wb3J0IGdyb3Vwc0FwaUZhY3RvcnkgZnJvbSAnLi9ncm91cHMnO1xyXG5pbXBvcnQgZXhhbUFwaUZhY3RvcnkgZnJvbSAnLi9leGFtcyc7XHJcbmltcG9ydCBhc3Nlc3NtZW50QXBpRmFjdG9yeSBmcm9tICcuL2Fzc2Vzc21lbnQnO1xyXG5pbXBvcnQgc2VtaW5hcnNBcGlGYWN0b3J5IGZyb20gJy4vc2VtaW5hcnMnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQsIGludGVyb3BQbGF0Zm9ybUhvc3QgfSkge1xyXG4gICAgY29uc3QgZXZlbnRzQXBpID0gZXZlbnRzQXBpRmFjdG9yeSh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCwgZ2V0IH0pO1xyXG4gICAgY29uc3QgbGVjdHVyZXNBcGkgPSBsZWN0dXJlc0FwaUZhY3RvcnkoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KTtcclxuICAgIGNvbnN0IHNraWxsc0FwaSA9IHNraWxsc0FwaUZhY3RvcnkoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KTtcclxuICAgIGNvbnN0IGdyb3Vwc0FwaSA9IGdyb3Vwc0FwaUZhY3RvcnkoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KTtcclxuICAgIGNvbnN0IGV4YW1zQXBpID0gZXhhbUFwaUZhY3RvcnkoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KTtcclxuICAgIGNvbnN0IGFzc2Vzc21lbnRBcGkgPSBhc3Nlc3NtZW50QXBpRmFjdG9yeSh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCwgZ2V0IH0pO1xyXG4gICAgY29uc3Qgc2VtaW5hcnNBcGkgPSBzZW1pbmFyc0FwaUZhY3RvcnkoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KTtcclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBzZWFyY2hCeU5hbWUoYm9keSkge1xyXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0gYm9keS5xdWVyeS5maWx0ZXIoZiA9PiBmLmxlbmd0aCA+IDApO1xyXG5cclxuICAgICAgICBjb25zdCBjb3Vyc2VzID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgICAgICBib2R5Lm1haW4gJiYgZ2V0TWFpbkluc3RhbmNlcyhib2R5LnBhZ2UsIHF1ZXJ5KSxcclxuICAgICAgICAgICAgYm9keS5vcGVuICYmIGdldE9wZW5JbnN0YW5jZXMoYm9keS5wYWdlLCBxdWVyeSksXHJcbiAgICAgICAgICAgIGJvZHkuZ2VuZXJhbCAmJiBnZXRHZW5lcmFsSW5zdGFuY2VzKGJvZHkucGFnZSwgcXVlcnkpXHJcbiAgICAgICAgXSk7XHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gW107XHJcbiAgICAgICAgZm9yIChsZXQgY291cnNlIG9mIChjb3Vyc2VzWzBdIHx8IFtdKSkge1xyXG4gICAgICAgICAgICByZXN1bHQucHVzaCh7XHJcbiAgICAgICAgICAgICAgICBJZDogY291cnNlLklkLFxyXG4gICAgICAgICAgICAgICAgTmFtZUJnOiBjb3Vyc2UuTmFtZUJnLFxyXG4gICAgICAgICAgICAgICAgVHlwZTogJ21haW4nLFxyXG4gICAgICAgICAgICAgICAgQ291cnNlSWQ6IGNvdXJzZS5Db3Vyc2VJZFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZm9yIChsZXQgY291cnNlIG9mIChjb3Vyc2VzWzFdIHx8IFtdKSkge1xyXG4gICAgICAgICAgICByZXN1bHQucHVzaCh7XHJcbiAgICAgICAgICAgICAgICBJZDogY291cnNlLklkLFxyXG4gICAgICAgICAgICAgICAgTmFtZUJnOiBjb3Vyc2UuTmFtZUJnLFxyXG4gICAgICAgICAgICAgICAgVHlwZTogJ29wZW4nLFxyXG4gICAgICAgICAgICAgICAgQ291cnNlSWQ6IGNvdXJzZS5Db3Vyc2VJZFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZm9yIChsZXQgY291cnNlIG9mIChjb3Vyc2VzWzJdIHx8IFtdKSkge1xyXG4gICAgICAgICAgICByZXN1bHQucHVzaCh7XHJcbiAgICAgICAgICAgICAgICBJZDogY291cnNlLklkLFxyXG4gICAgICAgICAgICAgICAgTmFtZUJnOiBjb3Vyc2UuTmFtZUJnLFxyXG4gICAgICAgICAgICAgICAgVHlwZTogJ2dlbmVyYWwnLFxyXG4gICAgICAgICAgICAgICAgQ291cnNlSWQ6IGNvdXJzZS5Db3Vyc2VJZFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBzZWFyY2hUcmFpbmluZ3NCeU5hbWUobmFtZSwgZXhhY3QgPSBmYWxzZSkge1xyXG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KG5hbWUpID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIG5hbWUgPSBbbmFtZV07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdHJhaW5pbmdzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDUwLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGV4YWN0XHJcbiAgICAgICAgICAgICAgICA/IGBOYW1lQmd+ZXF+JyR7bmFtZS5maWx0ZXIocyA9PiBzLmxlbmd0aCA+IDApLmpvaW4oJ1xcJ35vcn5OYW1lQmd+ZXF+XFwnJyl9J2BcclxuICAgICAgICAgICAgICAgIDogYE5hbWVCZ35jb250YWluc34nJHtuYW1lLmZpbHRlcihzID0+IHMubGVuZ3RoID4gMCkuam9pbignXFwnfm9yfk5hbWVCZ35jb250YWluc35cXCcnKX0nYCxcclxuICAgICAgICAgICAgc29ydDogJ1N0YXJ0RGF0ZS1kZXNjJyxcclxuICAgICAgICAgICAgcGFnZTogMVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBzZWFyY2hDb3Vyc2VzKHF1ZXJ5KSB7XHJcbiAgICAgICAgY29uc3QgdXJsID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9jb3Vyc2VzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSBgTmFtZX5jb250YWluc34nJHtxdWVyeS5zcGxpdCgnICcpLmZpbHRlcihzID0+IHMubGVuZ3RoID4gMCkuam9pbignXFwnfmFuZH5OYW1lfmNvbnRhaW5zflxcJycpfSdgO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwLFxyXG4gICAgICAgICAgICBmaWx0ZXIsXHJcbiAgICAgICAgICAgIHNvcnQ6ICdDcmVhdGVkT24tZGVzYydcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gKGF3YWl0IHBvc3QodXJsLCBib2R5KSkuRGF0YTtcclxuICAgICAgICByZXN1bHQuZm9yRWFjaChyID0+IHtcclxuICAgICAgICAgICAgci5OYW1lQmcgPSByLk5hbWU7XHJcbiAgICAgICAgICAgIHIuTmFtZUVuID0gci5OYW1lO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHNlYXJjaENvdXJzZUluc3RhbmNlc0J5Q291cnNlTmFtZUFuZEluc3RhbmNlSWQoY291cnNlTmFtZXMsIGluc3RhbmNlSWRzLCBmaWx0ZXIgPSB1bmRlZmluZWQpIHtcclxuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShjb3Vyc2VOYW1lcykgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgY291cnNlTmFtZXMgPSBbY291cnNlTmFtZXNdO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgdXJsID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9jb3Vyc2VzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBjb3Vyc2VzRmlsdGVyID0gYE5hbWV+Y29udGFpbnN+JyR7Y291cnNlTmFtZXMuZmlsdGVyKHMgPT4gcy5sZW5ndGggPiAwKS5qb2luKCdcXCd+YW5kfk5hbWV+Y29udGFpbnN+XFwnJyl9J2A7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogY291cnNlc0ZpbHRlcixcclxuICAgICAgICAgICAgc29ydDogJ0NyZWF0ZWRPbi1kZXNjJ1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjb25zdCByZXN1bHQgPSAoYXdhaXQgcG9zdCh1cmwsIGJvZHkpKS5EYXRhO1xyXG4gICAgICAgIHJlc3VsdC5mb3JFYWNoKHIgPT4ge1xyXG4gICAgICAgICAgICByLk5hbWVCZyA9IHIuTmFtZTtcclxuICAgICAgICAgICAgci5OYW1lRW4gPSByLk5hbWU7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGxldCBjb3Vyc2VJbnN0YW5jZXNQcm9taXNlcyA9IFtdO1xyXG4gICAgICAgIHJlc3VsdC5mb3JFYWNoKGMgPT4ge1xyXG4gICAgICAgICAgICBjb3Vyc2VJbnN0YW5jZXNQcm9taXNlcy5wdXNoKGdldENvdXJzZUluc3RhbmNlcyhjLklkLCBmaWx0ZXIpKTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoaW5zdGFuY2VJZHMpID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIGluc3RhbmNlSWRzID0gW2luc3RhbmNlSWRzXTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBhbGxDb3Vyc2VJbnN0YW5jZXMgPSAoYXdhaXQgUHJvbWlzZS5hbGwoY291cnNlSW5zdGFuY2VzUHJvbWlzZXMpKS5yZWR1Y2UoKGEsIGMpID0+IGEuY29uY2F0KGMpLCBbXSk7XHJcbiAgICAgICAgbGV0IGZpbHRlcmVkQ291cnNlSW5zdGFuY2VzID0gaW5zdGFuY2VJZHMubGVuZ3RoID09IDBcclxuICAgICAgICAgICAgPyBhbGxDb3Vyc2VJbnN0YW5jZXNcclxuICAgICAgICAgICAgOiBhbGxDb3Vyc2VJbnN0YW5jZXMuZmlsdGVyKGNpID0+IGluc3RhbmNlSWRzLmluY2x1ZGVzKGNpLklkKSk7XHJcblxyXG4gICAgICAgIHJldHVybiBmaWx0ZXJlZENvdXJzZUluc3RhbmNlcztcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRNYWluSW5zdGFuY2VzKHBhZ2UsIHF1ZXJ5KSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy91c2Vyc2luY291cnNlcy9yZWFkY291cnNlaW5zdGFuY2VzJyk7XHJcbiAgICAgICAgY29uc3QgZmlsdGVyID0gcXVlcnkubWFwKGUgPT4gYE5hbWVCZ35jb250YWluc34nJHtlfSdgKS5qb2luKCd+YW5kficpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnSXNBY3RpdmUtZGVzY35DcmVhdGVkT24tZGVzYycsXHJcbiAgICAgICAgICAgIHBhZ2UsXHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAyNSxcclxuICAgICAgICAgICAgZmlsdGVyXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICAgICAgcmV0dXJuIGRhdGEuRGF0YS5tYXAoZSA9PiAoe1xyXG4gICAgICAgICAgICBJZDogZS5JZCxcclxuICAgICAgICAgICAgTmFtZUJnOiBlLk5hbWVCZyxcclxuICAgICAgICAgICAgQ291cnNlSWQ6IGUuQ291cnNlSWRcclxuICAgICAgICB9KSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0T3Blbkluc3RhbmNlcyhwYWdlLCBxdWVyeSkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCcvYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3VzZXJzaW5mYXN0dHJhY2tzL3JlYWRmYXN0dHJhY2tpbnN0YW5jZXMnKTtcclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSBxdWVyeS5tYXAoZSA9PiBgTmFtZUJnfmNvbnRhaW5zficke2V9J2ApLmpvaW4oJ35hbmR+Jyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICdJc0FjdGl2ZS1kZXNjfkNyZWF0ZWRPbi1kZXNjJyxcclxuICAgICAgICAgICAgcGFnZSxcclxuICAgICAgICAgICAgcGFnZVNpemU6IDI1LFxyXG4gICAgICAgICAgICBmaWx0ZXJcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvc3QodXJpLCBib2R5KTtcclxuICAgICAgICByZXR1cm4gZGF0YS5EYXRhLm1hcChlID0+ICh7XHJcbiAgICAgICAgICAgIElkOiBlLklkLFxyXG4gICAgICAgICAgICBOYW1lQmc6IGUuTmFtZUJnLFxyXG4gICAgICAgICAgICBDb3Vyc2VJZDogZS5Db3Vyc2VJZFxyXG4gICAgICAgIH0pKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRHZW5lcmFsSW5zdGFuY2VzKHBhZ2UsIHF1ZXJ5KSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy91c2Vyc2luZ2VuZXJhbGNvdXJzZWluc3RhbmNlcy9yZWFkZ2VuZXJhbGNvdXJzZWluc3RhbmNlcycpO1xyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9IHF1ZXJ5Lm1hcChlID0+IGBOYW1lQmd+Y29udGFpbnN+JyR7ZX0nYCkuam9pbignfmFuZH4nKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJ0lzQWN0aXZlLWRlc2N+Q3JlYXRlZE9uLWRlc2MnLFxyXG4gICAgICAgICAgICBwYWdlLFxyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMjUsXHJcbiAgICAgICAgICAgIGZpbHRlclxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgICAgIHJldHVybiBkYXRhLkRhdGEubWFwKGUgPT4gKHtcclxuICAgICAgICAgICAgSWQ6IGUuSWQsXHJcbiAgICAgICAgICAgIE5hbWVCZzogZS5OYW1lQmcsXHJcbiAgICAgICAgICAgIENvdXJzZUlkOiBlLkNvdXJzZUlkXHJcbiAgICAgICAgfSkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldENvdXJzZURhdGEoY291cnNlSWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2NvdXJzZXMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBmaWx0ZXI6IGBJZH5lcX4nJHtjb3Vyc2VJZH0nYFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YVswXTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRDb3Vyc2VJbnN0YW5jZXMoY291cnNlSWQsIGZpbHRlciA9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnU3RhcnREYXRlLWRlc2MnLFxyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICAgICAgICAgIChmaWx0ZXIgPT0gdW5kZWZpbmVkIHx8IGZpbHRlci5tYWluID09PSB0cnVlKVxyXG4gICAgICAgICAgICAgICAgPyBwb3N0KGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvY291cnNlaW5zdGFuY2VzL3JlYWQ/Zm9yZWlnbktleUlkPSR7Y291cnNlSWR9YCksIGJvZHkpXHJcbiAgICAgICAgICAgICAgICA6IFByb21pc2UucmVzb2x2ZSh0cnVlKSxcclxuICAgICAgICAgICAgKGZpbHRlciA9PSB1bmRlZmluZWQgfHwgZmlsdGVyLm1haW4gPT09IHRydWUpXHJcbiAgICAgICAgICAgICAgICA/IHBvc3QoaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9mYXN0dHJhY2tpbnN0YW5jZXMvcmVhZD9mb3JlaWduS2V5SWQ9JHtjb3Vyc2VJZH1gKSwgYm9keSlcclxuICAgICAgICAgICAgICAgIDogUHJvbWlzZS5yZXNvbHZlKHRydWUpLFxyXG4gICAgICAgICAgICAoZmlsdGVyID09IHVuZGVmaW5lZCB8fCBmaWx0ZXIuZ2VuZXJhbCA9PT0gdHJ1ZSlcclxuICAgICAgICAgICAgICAgID8gcG9zdChpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2dlbmVyYWxjb3Vyc2VpbnN0YW5jZXMvcmVhZD9mb3JlaWduS2V5SWQ9JHtjb3Vyc2VJZH1gKSwgYm9keSlcclxuICAgICAgICAgICAgICAgIDogUHJvbWlzZS5yZXNvbHZlKHRydWUpXHJcbiAgICAgICAgXSk7XHJcblxyXG4gICAgICAgIGxldCByZXNwb25zZSA9IFtdO1xyXG5cclxuICAgICAgICByZXNwb25zZSA9IHJlc3BvbnNlLmNvbmNhdChkYXRhWzBdLkRhdGEgIT0gdW5kZWZpbmVkID8gZGF0YVswXS5EYXRhLm1hcChjID0+IHsgYy5JbnN0YW5jZVJlZlR5cGUgPSAnbWFpbic7IHJldHVybiBjOyB9KSA6IFtdKTtcclxuICAgICAgICByZXNwb25zZSA9IHJlc3BvbnNlLmNvbmNhdChkYXRhWzFdLkRhdGEgIT0gdW5kZWZpbmVkID8gZGF0YVsxXS5EYXRhLm1hcChjID0+IHsgYy5JbnN0YW5jZVJlZlR5cGUgPSAnb3Blbic7IHJldHVybiBjOyB9KSA6IFtdKTtcclxuICAgICAgICByZXNwb25zZSA9IHJlc3BvbnNlLmNvbmNhdChkYXRhWzJdLkRhdGEgIT0gdW5kZWZpbmVkID8gZGF0YVsyXS5EYXRhLm1hcChjID0+IHsgYy5JbnN0YW5jZVJlZlR5cGUgPSAnZ2VuZXJhbCc7IHJldHVybiBjOyB9KSA6IFtdKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEluc3RhbmNlRGF0YShpbnN0YW5jZUlkLCBjb3Vyc2VJZCwgdHlwZSkge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZ2V0SW5zdGFuY2VEYXRhQnlUeXBlKGluc3RhbmNlSWQsIGNvdXJzZUlkLCB0eXBlKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHF1ZXJ5UmVzdWx0cyA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgICAgICAgICAgICAgICBnZXRJbnN0YW5jZURhdGFCeVR5cGUoaW5zdGFuY2VJZCwgY291cnNlSWQsICdtYWluJyksXHJcbiAgICAgICAgICAgICAgICAgICAgZ2V0SW5zdGFuY2VEYXRhQnlUeXBlKGluc3RhbmNlSWQsIGNvdXJzZUlkLCAnb3BlbicpLFxyXG4gICAgICAgICAgICAgICAgICAgIGdldEluc3RhbmNlRGF0YUJ5VHlwZShpbnN0YW5jZUlkLCBjb3Vyc2VJZCwgJ2dlbmVyYWwnKVxyXG4gICAgICAgICAgICAgICAgXSk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcXVlcnlSZXN1bHRzLmZpbHRlcihlID0+IGUgIT09IHVuZGVmaW5lZClbMF07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRJbnN0YW5jZURhdGFCeVR5cGUoaW5zdGFuY2VJZCwgY291cnNlSWQsIHR5cGUpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSAoKCkgPT4ge1xyXG4gICAgICAgICAgICBzd2l0Y2ggKHR5cGUpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgJ21haW4nOlxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2NvdXJzZWluc3RhbmNlcy9yZWFkP2ZvcmVpZ25LZXlJZD0ke2NvdXJzZUlkfWApO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAnb3Blbic6XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvZmFzdHRyYWNraW5zdGFuY2VzL3JlYWQ/Zm9yZWlnbktleUlkPSR7Y291cnNlSWR9YCk7XHJcbiAgICAgICAgICAgICAgICBjYXNlICdnZW5lcmFsJzpcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9nZW5lcmFsY291cnNlaW5zdGFuY2VzL3JlYWQ/Zm9yZWlnbktleUlkPSR7Y291cnNlSWR9YCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KSgpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBmaWx0ZXI6IGBJZH5lcX4ke2luc3RhbmNlSWR9YFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGNvbnN0IGluc3RhbmNlID0gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YVswXTtcclxuICAgICAgICBpZiAoaW5zdGFuY2UgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICBpbnN0YW5jZS5JbnN0YW5jZVJlZlR5cGUgPSB0eXBlO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gaW5zdGFuY2U7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0SW5zdGFuY2VPdmVydmlldyhpbnN0YW5jZUlkcykge1xyXG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KGluc3RhbmNlSWRzKSA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICBpbnN0YW5jZUlkcyA9IFtpbnN0YW5jZUlkc107XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdHJhaW5pbmdzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogYFRyYWluaW5nSWR+ZXF+JHtpbnN0YW5jZUlkcy5qb2luKCd+b3J+VHJhaW5pbmdJZH5lcX4nKX1gXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmksIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIHVwZGF0ZUNvdXJzZShjb3Vyc2UpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2NvdXJzZXMvdXBkYXRlJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiBjb3Vyc2UuSWQsXHJcbiAgICAgICAgICAgIE5hbWU6IGNvdXJzZS5OYW1lLFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkJnOiBjb3Vyc2UuRGVzY3JpcHRpb25CZyxcclxuICAgICAgICAgICAgRGVzY3JpcHRpb25FbjogY291cnNlLkRlc2NyaXB0aW9uRW4sXHJcbiAgICAgICAgICAgIFVybE5hbWU6IGNvdXJzZS5VcmxOYW1lLFxyXG4gICAgICAgICAgICBJY29uVXJsOiBjb3Vyc2UuSWNvblVybCxcclxuICAgICAgICAgICAgQ3JlZGl0czogY291cnNlLkNyZWRpdHMsXHJcbiAgICAgICAgICAgIElzQWN0aXZlOiBjb3Vyc2UuSXNBY3RpdmUsXHJcbiAgICAgICAgICAgIElzSGlkZGVuOiBjb3Vyc2UuSXNIaWRkZW4sXHJcbiAgICAgICAgICAgIE9yZGVyQnk6IGNvdXJzZS5PcmRlckJ5LFxyXG4gICAgICAgICAgICBNZXJnZWRUYWdzOiBjb3Vyc2UuTWVyZ2VkVGFncyxcclxuICAgICAgICAgICAgQ291cnNlQ2F0ZWdvcnlJZDogY291cnNlLkNvdXJzZUNhdGVnb3J5SWQsXHJcbiAgICAgICAgICAgIENvdXJzZURpZmZpY3VsdHlMZXZlbDogY291cnNlLkNvdXJzZURpZmZpY3VsdHlMZXZlbCxcclxuICAgICAgICAgICAgQ291cnNlRGlmZmljdWx0eUxldmVsRGVzY3JpcHRpb25CZzogY291cnNlLkNvdXJzZURpZmZpY3VsdHlMZXZlbERlc2NyaXB0aW9uQmcsXHJcbiAgICAgICAgICAgIENvdXJzZURpZmZpY3VsdHlMZXZlbERlc2NyaXB0aW9uRW46IGNvdXJzZS5Db3Vyc2VEaWZmaWN1bHR5TGV2ZWxEZXNjcmlwdGlvbkVuLFxyXG4gICAgICAgICAgICBDcmVhdGVkT246IGNvdXJzZS5DcmVhdGVkT24sXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246IGNvdXJzZS5Nb2RpZmllZE9uIHx8IGNvdXJzZS5DcmVhdGVkT24sXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUluc3RhbmNlKGluc3RhbmNlKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gKCgpID0+IHtcclxuICAgICAgICAgICAgc3dpdGNoIChpbnN0YW5jZS5JbnN0YW5jZVJlZlR5cGUpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgJ21haW4nOlxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2NvdXJzZWluc3RhbmNlcy91cGRhdGU/Zm9yZWlnbktleUlkPSR7aW5zdGFuY2UuQ291cnNlSWR9YCk7XHJcbiAgICAgICAgICAgICAgICBjYXNlICdvcGVuJzpcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9mYXN0dHJhY2tpbnN0YW5jZXMvdXBkYXRlP2ZvcmVpZ25LZXlJZD0ke2luc3RhbmNlLkNvdXJzZUlkfWApO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAnZ2VuZXJhbCc6XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvZ2VuZXJhbGNvdXJzZWluc3RhbmNlcy91cGRhdGU/Zm9yZWlnbktleUlkPSR7aW5zdGFuY2UuQ291cnNlSWR9YCk7XHJcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2Zhc3R0cmFja2luc3RhbmNlcy91cGRhdGU/Zm9yZWlnbktleUlkPSR7aW5zdGFuY2UuQ291cnNlSWR9YCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KSgpO1xyXG5cclxuICAgICAgICBjb25zdCBib2R5ID0gT2JqZWN0LmFzc2lnbih7fSwgaW5zdGFuY2UsIHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgTW9kaWZpZWRPbjogaW5zdGFuY2UuTW9kaWZpZWRPbiB8fCBpbnN0YW5jZS5DcmVhdGVkT25cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgZGVsZXRlIGJvZHkuSW5zdGFuY2VSZWZUeXBlO1xyXG4gICAgICAgIGRlbGV0ZSBib2R5LlNoYXJlc0xpdmVTdHJlYW1XaXRoVHJhaW5pbmdzO1xyXG5cclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCkgeyBib2R5W2tdID0gJyc7IH0gfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0U3R1ZGVudHMoaW5zdGFuY2VJZCwgdHlwZSA9ICdtYWluJykge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAodHlwZSkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAnbWFpbic6XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdXNlcnNpbmNvdXJzZXMvcmVhZD9mb3JlaWduS2V5SWQ9JHtpbnN0YW5jZUlkfWApO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAnb3Blbic6XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdXNlcnNpbmZhc3R0cmFja3MvcmVhZD9mb3JlaWduS2V5SWQ9JHtpbnN0YW5jZUlkfWApO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAnZ2VuZXJhbCc6XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdXNlcnNpbmdlbmVyYWxjb3Vyc2VpbnN0YW5jZXMvcmVhZD9mb3JlaWduS2V5SWQ9JHtpbnN0YW5jZUlkfWApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSkoKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIGF3YWl0IGZldGNoTmV4dCgpO1xyXG5cclxuICAgICAgICBhc3luYyBmdW5jdGlvbiBmZXRjaE5leHQocGFnZSA9IDEpIHtcclxuICAgICAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgICAgICBzb3J0OiAnQ3JlYXRlZE9uLWRlc2MnLFxyXG4gICAgICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAsXHJcbiAgICAgICAgICAgICAgICBwYWdlXHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBwb3N0KHVyaSwgYm9keSk7XHJcblxyXG4gICAgICAgICAgICBsZXQgcmVzdWx0ID0gcmVzcG9uc2UuRGF0YTtcclxuXHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5Ub3RhbCA+IHBhZ2UgKiAxMDAwKSB7XHJcbiAgICAgICAgICAgICAgICByZXN1bHQgPSByZXN1bHQuY29uY2F0KGF3YWl0IGZldGNoTmV4dChwYWdlICsgMSkpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0Q291cnNlRXZlbnRzKGluc3RhbmNlSWQpIHtcclxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgICAgICBnZXRNYWluQnlJZChpbnN0YW5jZUlkKSxcclxuICAgICAgICAgICAgZ2V0T3BlbkJ5SWQoaW5zdGFuY2VJZCksXHJcbiAgICAgICAgICAgIGdldEdlbmVyYWxCeUlkKGluc3RhbmNlSWQpLFxyXG4gICAgICAgICAgICBldmVudHNBcGkuZ2V0RXZlbnRzKGluc3RhbmNlSWQpXHJcbiAgICAgICAgXSk7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCAzOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKGRhdGFbaV0uVG90YWwgPiAwKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IHtcclxuICAgICAgICAgICAgICAgICAgICBJZDogZGF0YVtpXS5EYXRhWzBdLklkLFxyXG4gICAgICAgICAgICAgICAgICAgIENvdXJzZUlkOiBkYXRhW2ldLkRhdGFbMF0uQ291cnNlSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgTmFtZUJnOiBkYXRhW2ldLkRhdGFbMF0uTmFtZUJnLFxyXG4gICAgICAgICAgICAgICAgICAgIEV2ZW50czogZGF0YVszXSxcclxuICAgICAgICAgICAgICAgICAgICBJbnN0YW5jZVJlZlR5cGU6ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDA6ICdtYWluJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgMTogJ29wZW4nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAyOiAnZ2VuZXJhbCdcclxuICAgICAgICAgICAgICAgICAgICB9KVtpXVxyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgIHJldHVybiByZXNwb25zZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Vycm9yIGZldGNoaW5nIGluc3RhbmNlIGRhdGE6IEFsbCBzZWFyY2hlcyByZXR1cm5lZCAwIG1hdGNoZXMnKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRBbnlCeUlkKGluc3RhbmNlSWQpIHtcclxuICAgICAgICBpZihBcnJheS5pc0FycmF5KGluc3RhbmNlSWQpICYmIGluc3RhbmNlSWQubGVuZ3RoID09PSAwKXtcclxuICAgICAgICAgICAgcmV0dXJuIFtdO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgICAgICBnZXRNYWluQnlJZChpbnN0YW5jZUlkKSxcclxuICAgICAgICAgICAgZ2V0T3BlbkJ5SWQoaW5zdGFuY2VJZCksXHJcbiAgICAgICAgICAgIGdldEdlbmVyYWxCeUlkKGluc3RhbmNlSWQpXHJcbiAgICAgICAgXSk7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcmVzdWx0Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGluc3RhbmNlID0gcmVzdWx0W2ldO1xyXG4gICAgICAgICAgICBpZiAoaW5zdGFuY2UuVG90YWwgPiAwKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCB0eXBlID0gKHtcclxuICAgICAgICAgICAgICAgICAgICAwOiAnbWFpbicsXHJcbiAgICAgICAgICAgICAgICAgICAgMTogJ29wZW4nLFxyXG4gICAgICAgICAgICAgICAgICAgIDI6ICdnZW5lcmFsJ1xyXG4gICAgICAgICAgICAgICAgfSlbaV07XHJcbiAgICAgICAgICAgICAgICBpbnN0YW5jZS5EYXRhLmZvckVhY2goaSA9PiBpLkluc3RhbmNlUmVmVHlwZSA9IHR5cGUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzdWx0LnJlZHVjZSgocCwgYykgPT4gcC5jb25jYXQoYy5EYXRhKSwgW10pO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldE1haW5CeUlkKGluc3RhbmNlSWQpIHtcclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSAoKCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShpbnN0YW5jZUlkKSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGBJZH5lcX4ke2luc3RhbmNlSWQuam9pbignfm9yfklkfmVxficpfWA7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gYElkfmVxfiR7aW5zdGFuY2VJZH1gO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSkoKTtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3VzZXJzaW5jb3Vyc2VzL3JlYWRjb3Vyc2VpbnN0YW5jZXMnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAwLFxyXG4gICAgICAgICAgICBmaWx0ZXJcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRPcGVuQnlJZChpbnN0YW5jZUlkKSB7XHJcbiAgICAgICAgY29uc3QgZmlsdGVyID0gKCgpID0+IHtcclxuICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoaW5zdGFuY2VJZCkpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBgSWR+ZXF+JHtpbnN0YW5jZUlkLmpvaW4oJ35vcn5JZH5lcX4nKX1gO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGBJZH5lcX4ke2luc3RhbmNlSWR9YDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKCk7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy91c2Vyc2luZmFzdHRyYWNrcy9yZWFkZmFzdHRyYWNraW5zdGFuY2VzJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwMCxcclxuICAgICAgICAgICAgZmlsdGVyXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0R2VuZXJhbEJ5SWQoaW5zdGFuY2VJZCkge1xyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KGluc3RhbmNlSWQpKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gYElkfmVxfiR7aW5zdGFuY2VJZC5qb2luKCd+b3J+SWR+ZXF+Jyl9YDtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBgSWR+ZXF+JHtpbnN0YW5jZUlkfWA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KSgpO1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdXNlcnNpbmdlbmVyYWxjb3Vyc2VpbnN0YW5jZXMvcmVhZGdlbmVyYWxjb3Vyc2VpbnN0YW5jZXMnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAwLFxyXG4gICAgICAgICAgICBmaWx0ZXJcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRJbnN0YW5jZVBhZ2UoaW5zdGFuY2VJZCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGB0cmFpbmluZ3MvdHJhaW5pbmdzL2dldGNvdXJzZWRldGFpbHM/aWQ9JHtpbnN0YW5jZUlkfWApO1xyXG4gICAgICAgIHJldHVybiBnZXQodXJpKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRJbnN0YW5jZUZ1bGxQYWdlKHVybCkge1xyXG4gICAgICAgIHJldHVybiBnZXQodXJsKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRUcmFpbmVyTmFtZXMoaW5zdGFuY2VJZCkge1xyXG4gICAgICAgIHJldHVybiAoYXdhaXQgZmV0Y2goaW50ZXJvcEhvc3QoYGtlbmRvcmVtb3RlZGF0YS9nZXR0cmFpbmVyc2J5dHJhaW5pbmc/dHJhaW5pbmdJZD0ke2luc3RhbmNlSWR9YCksIHtcclxuICAgICAgICAgICAgJ2NyZWRlbnRpYWxzJzogJ2luY2x1ZGUnLFxyXG4gICAgICAgICAgICAnaGVhZGVycyc6IHtcclxuICAgICAgICAgICAgICAgICdVc2VyLUFnZW50JzogJ01vemlsbGEvNS4wIChXaW5kb3dzIE5UIDEwLjA7IFdpbjY0OyB4NjQ7IHJ2Ojk2LjApIEdlY2tvLzIwMTAwMTAxIEZpcmVmb3gvOTYuMCcsXHJcbiAgICAgICAgICAgICAgICAnQWNjZXB0JzogJyovKicsXHJcbiAgICAgICAgICAgICAgICAnQWNjZXB0LUxhbmd1YWdlJzogJ2VuLVVTLGVuO3E9MC41JyxcclxuICAgICAgICAgICAgICAgICdYLVJlcXVlc3RlZC1XaXRoJzogJ1hNTEh0dHBSZXF1ZXN0JyxcclxuICAgICAgICAgICAgICAgICdQcmFnbWEnOiAnbm8tY2FjaGUnLFxyXG4gICAgICAgICAgICAgICAgJ0NhY2hlLUNvbnRyb2wnOiAnbm8tY2FjaGUnLFxyXG4gICAgICAgICAgICAgICAgJ1NlYy1GZXRjaC1EZXN0JzogJ2VtcHR5JyxcclxuICAgICAgICAgICAgICAgICdTZWMtRmV0Y2gtTW9kZSc6ICduby1jb3JzJyxcclxuICAgICAgICAgICAgICAgICdTZWMtRmV0Y2gtU2l0ZSc6ICdzYW1lLW9yaWdpbidcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgJ21ldGhvZCc6ICdHRVQnLFxyXG4gICAgICAgICAgICAnbW9kZSc6ICdjb3JzJ1xyXG4gICAgICAgIH0pKS5qc29uKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICAuLi5ldmVudHNBcGksXHJcbiAgICAgICAgLi4ubGVjdHVyZXNBcGksXHJcbiAgICAgICAgLi4uc2tpbGxzQXBpLFxyXG4gICAgICAgIC4uLmdyb3Vwc0FwaSxcclxuICAgICAgICAuLi5leGFtc0FwaSxcclxuICAgICAgICAuLi5hc3Nlc3NtZW50QXBpLFxyXG4gICAgICAgIC4uLnNlbWluYXJzQXBpLFxyXG4gICAgICAgIHNlYXJjaEJ5TmFtZSxcclxuICAgICAgICBzZWFyY2hDb3Vyc2VzLFxyXG4gICAgICAgIGdldENvdXJzZURhdGEsXHJcbiAgICAgICAgZ2V0Q291cnNlSW5zdGFuY2VzLFxyXG4gICAgICAgIGdldEluc3RhbmNlRGF0YSxcclxuICAgICAgICBnZXRJbnN0YW5jZU92ZXJ2aWV3LFxyXG4gICAgICAgIHVwZGF0ZUNvdXJzZSxcclxuICAgICAgICB1cGRhdGVJbnN0YW5jZSxcclxuICAgICAgICBnZXRTdHVkZW50cyxcclxuICAgICAgICBnZXRDb3Vyc2VFdmVudHMsXHJcbiAgICAgICAgZ2V0QW55QnlJZCxcclxuICAgICAgICBnZXRJbnN0YW5jZVBhZ2UsXHJcbiAgICAgICAgZ2V0SW5zdGFuY2VGdWxsUGFnZSxcclxuICAgICAgICBnZXRUcmFpbmVyTmFtZXMsXHJcbiAgICAgICAgc2VhcmNoQ291cnNlSW5zdGFuY2VzQnlDb3Vyc2VOYW1lQW5kSW5zdGFuY2VJZCxcclxuICAgICAgICBzZWFyY2hUcmFpbmluZ3NCeU5hbWVcclxuICAgIH07XHJcbn0iLCJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KSB7XHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRUcmFpbmluZ3NCeVRyYWluZXIodXNlcklkKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gKCgpID0+IHtcclxuICAgICAgICAgICAgaWYgKGludGVyb3BBcHBJZCgpID09PSAnc29mdHVuaS5iZycpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdXNlcnMvdHJhaW5lcnNpbnRyYWluaW5ncy9yZWFkdHJhaW5pbmdzb2Z0cmFpbmVyP3RyYWluZXJJZD0ke3VzZXJJZH1gKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdChgQWRtaW5pc3RyYXRpb25fVXNlcnMvVHJhaW5lcnNJblRyYWluaW5ncy9SZWFkP2ZvcmVpZ25LZXk9JHt1c2VySWR9JmZvcmVpZ25LZXlJZD0ke3VzZXJJZH1gKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAsXHJcbiAgICAgICAgICAgIHNvcnQ6ICdNb2RpZmllZE9uLWRlc2MnXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHBvc3QodXJpLCBib2R5KTtcclxuICAgICAgICByZXN1bHQuRGF0YS5mb3JFYWNoKHQgPT4ge1xyXG4gICAgICAgICAgICB0LkRlc2NyaXB0aW9uQmcgPSB0LkRlc2NyaXB0aW9uQmcgfHwgJyc7XHJcbiAgICAgICAgICAgIHQuRGVzY3JpcHRpb25FbiA9IHQuRGVzY3JpcHRpb25FbiB8fCAnJztcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRUcmFpbmVyQnlJZCh1c2VySWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSAoKCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoaW50ZXJvcEFwcElkKCkgPT09ICdzb2Z0dW5pLmJnJykge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl91c2Vycy90cmFpbmVyc2ludHJhaW5pbmdzL3JlYWQnKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdCgnQWRtaW5pc3RyYXRpb25fVXNlcnMvVHJhaW5lcnMvUmVhZCcpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSkoKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMCxcclxuICAgICAgICAgICAgZmlsdGVyOiBgVXNlcklkfmVxficke3VzZXJJZH0nYFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVRyYWluaW5nQnlUcmFpbmVyKHRyYWluaW5nKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gKCgpID0+IHtcclxuICAgICAgICAgICAgaWYgKGludGVyb3BBcHBJZCgpID09PSAnc29mdHVuaS5iZycpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdXNlcnMvdHJhaW5lcnNpbnRyYWluaW5ncy9VcGRhdGVUcmFpbmVySW5UcmFpbmluZycpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGludGVyb3BIb3N0KCdBZG1pbmlzdHJhdGlvbl9Vc2Vycy9UcmFpbmVyc0luVHJhaW5pbmdzL1VwZGF0ZScpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSkoKTtcclxuXHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIFRyYWluaW5nSWQ6IHRyYWluaW5nLlRyYWluaW5nSWQsXHJcbiAgICAgICAgICAgIFRyYWluaW5nTmFtZTogdHJhaW5pbmcuVHJhaW5pbmdOYW1lLFxyXG4gICAgICAgICAgICBUcmFpbmVyRmlyc3ROYW1lOiB0cmFpbmluZy5UcmFpbmVyRmlyc3ROYW1lLFxyXG4gICAgICAgICAgICBUcmFpbmVyTGFzdE5hbWU6IHRyYWluaW5nLlRyYWluZXJMYXN0TmFtZSxcclxuICAgICAgICAgICAgVHJhaW5lcklkOiB0cmFpbmluZy5UcmFpbmVySWQsXHJcbiAgICAgICAgICAgIFRyYWluZXJPcmRlckJ5OiB0cmFpbmluZy5UcmFpbmVyT3JkZXJCeSxcclxuICAgICAgICAgICAgSXNQdWJsaWNUcmFpbmVyOiB0cmFpbmluZy5Jc1B1YmxpY1RyYWluZXIsXHJcbiAgICAgICAgICAgIERlc2NyaXB0aW9uQmc6IHRyYWluaW5nLkRlc2NyaXB0aW9uQmcsXHJcbiAgICAgICAgICAgIERlc2NyaXB0aW9uRW46IHRyYWluaW5nLkRlc2NyaXB0aW9uRW4sXHJcbiAgICAgICAgICAgIFRyYWluZXJQaG90b1BhdGg6IHRyYWluaW5nLlRyYWluZXJQaG90b1BhdGgsXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JyxcclxuICAgICAgICAgICAgTW9kaWZpZWRPbjogJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3J1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsIHx8IGJvZHlba10gPT09IHVuZGVmaW5lZCkgeyBib2R5W2tdID0gJyc7IH0gfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gY3JlYXRlVHJhaW5pbmdCeVRyYWluZXIodHJhaW5pbmcpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wQXBwSWQoKSA9PT0gJ3NvZnR1bmkuYmcnID9cclxuICAgICAgICAgICAgaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3VzZXJzL3RyYWluZXJzaW50cmFpbmluZ3MvQWRkVHJhaW5lclRvVHJhaW5pbmc/dXNlcklkPSR7dHJhaW5pbmcuVHJhaW5lcklkfWApIDpcclxuICAgICAgICAgICAgaW50ZXJvcEhvc3QoYEFkbWluaXN0cmF0aW9uX1VzZXJzL1RyYWluZXJzSW5UcmFpbmluZ3MvQ3JlYXRlP2ZvcmVpZ25LZXk9JHt0cmFpbmluZy5UcmFpbmVySWR9YCk7XHJcblxyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBUcmFpbmluZ0lkOiB0cmFpbmluZy5UcmFpbmluZ0lkLFxyXG4gICAgICAgICAgICBUcmFpbmluZ05hbWU6IHRyYWluaW5nLlRyYWluaW5nTmFtZSxcclxuICAgICAgICAgICAgVHJhaW5lckZpcnN0TmFtZTogdHJhaW5pbmcuVHJhaW5lckZpcnN0TmFtZSxcclxuICAgICAgICAgICAgVHJhaW5lckxhc3ROYW1lOiB0cmFpbmluZy5UcmFpbmVyTGFzdE5hbWUsXHJcbiAgICAgICAgICAgIFRyYWluZXJJZDogdHJhaW5pbmcuVHJhaW5lcklkLFxyXG4gICAgICAgICAgICBUcmFpbmVyT3JkZXJCeTogdHJhaW5pbmcuVHJhaW5lck9yZGVyQnksXHJcbiAgICAgICAgICAgIElzUHVibGljVHJhaW5lcjogdHJhaW5pbmcuSXNQdWJsaWNUcmFpbmVyLFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkJnOiB0cmFpbmluZy5EZXNjcmlwdGlvbkJnLFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkVuOiB0cmFpbmluZy5EZXNjcmlwdGlvbkVuLFxyXG4gICAgICAgICAgICBUcmFpbmVyUGhvdG9QYXRoOiB0cmFpbmluZy5UcmFpbmVyUGhvdG9QYXRoLFxyXG4gICAgICAgICAgICBDcmVhdGVkT246ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNydcclxuICAgICAgICB9KTtcclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCB8fCBib2R5W2tdID09PSB1bmRlZmluZWQpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHNlYXJjaFVzZXJzKHF1ZXJ5LCBleGNsdWRlKSB7XHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgICAgICBzZWFyY2hVc2Vyc0J5TmFtZShxdWVyeSwgZXhjbHVkZSksXHJcbiAgICAgICAgICAgIHNlYXJjaFVzZXJzQnlVc2VyTmFtZShxdWVyeSwgZXhjbHVkZSlcclxuICAgICAgICBdKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc3VsdFswXS5jb25jYXQocmVzdWx0WzFdKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBkZXN0cm95VHJhaW5pbmdPZlRyYWluZXIodHJhaW5pbmcpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wQXBwSWQoKSA9PT0gJ3NvZnR1bmkuYmcnID9cclxuICAgICAgICAgICAgaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3VzZXJzL3RyYWluZXJzaW50cmFpbmluZ3MvRGVsZXRlVHJhaW5lckZyb21UcmFpbmluZycpIDpcclxuICAgICAgICAgICAgaW50ZXJvcEhvc3QoJ0FkbWluaXN0cmF0aW9uX1VzZXJzL1RyYWluZXJzSW5UcmFpbmluZ3MvRGVzdHJveScpO1xyXG5cclxuICAgICAgICBjb25zdCBib2R5ID0gT2JqZWN0LmFzc2lnbihwYXJhbXMoKSwgdHJhaW5pbmcpO1xyXG4gICAgICAgIGJvZHkuQ3JlYXRlZE9uID0gJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JztcclxuICAgICAgICBib2R5Lk1vZGlmaWVkT24gPSAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnO1xyXG5cclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCB8fCBib2R5W2tdID09PSB1bmRlZmluZWQpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHNlYXJjaFVzZXJzQnlOYW1lKG5hbWUsIGV4Y2x1ZGUpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdXNlcnMvdXNlcnMvcmVhZCcpO1xyXG5cclxuICAgICAgICBsZXQgZmlsdGVyID0gbmFtZS5pbmNsdWRlcygnICcpID9cclxuICAgICAgICAgICAgYChGaXJzdE5hbWVFbn5lcX4nJHtuYW1lLnNwbGl0KCcgJylbMF19J35hbmR+TGFzdE5hbWVFbn5zdGFydHN3aXRoficke25hbWUuc3BsaXQoJyAnKVsxXX0nKX5vcn4oRmlyc3ROYW1lQmd+ZXF+JyR7bmFtZS5zcGxpdCgnICcpWzBdfSd+YW5kfkxhc3ROYW1lQmd+c3RhcnRzd2l0aH4nJHtuYW1lLnNwbGl0KCcgJylbMV19JylgIDpcclxuICAgICAgICAgICAgYEZpcnN0TmFtZUVufmNvbnRhaW5zficke25hbWV9J35vcn5MYXN0TmFtZUVufmNvbnRhaW5zficke25hbWV9J35vcn5GaXJzdE5hbWVCZ35jb250YWluc34nJHtuYW1lfSd+b3J+TGFzdE5hbWVCZ35jb250YWluc34nJHtuYW1lfSdgO1xyXG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KGV4Y2x1ZGUpKSB7XHJcbiAgICAgICAgICAgIGZpbHRlciA9IGAoJHtmaWx0ZXJ9KX5hbmR+KElkfm5lcX4nJHtleGNsdWRlLmpvaW4oJ1xcJ35hbmR+SWR+bmVxflxcJycpfScpYDtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICdVc2VyTmFtZS1hc2MnLFxyXG4gICAgICAgICAgICBwYWdlU2l6ZTogNSxcclxuICAgICAgICAgICAgZmlsdGVyXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmksIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHNlYXJjaFVzZXJzQnlVc2VyTmFtZShuYW1lLCBleGNsdWRlKSB7XHJcbiAgICAgICAgaWYgKG5hbWUuaW5jbHVkZXMoJyAnKSkge1xyXG4gICAgICAgICAgICByZXR1cm4gW107XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl91c2Vycy91c2Vycy9yZWFkJyk7XHJcblxyXG4gICAgICAgIGxldCBmaWx0ZXIgPSBgVXNlck5hbWV+Y29udGFpbnN+JyR7bmFtZX0nYDtcclxuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShleGNsdWRlKSkge1xyXG4gICAgICAgICAgICBmaWx0ZXIgPSBgKCR7ZmlsdGVyfSl+YW5kfihJZH5uZXF+JyR7ZXhjbHVkZS5qb2luKCdcXCd+YW5kfklkfm5lcX5cXCcnKX0nKWA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnVXNlck5hbWUtYXNjJyxcclxuICAgICAgICAgICAgcGFnZVNpemU6IDUsXHJcbiAgICAgICAgICAgIGZpbHRlclxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRUcmFpbmVyc0J5VHJhaW5pbmcodHJhaW5pbmdJZCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBBZG1pbmlzdHJhdGlvbl9UcmFpbmluZ3MvVHJhaW5pbmdzV2l0aFRyYWluZXJzL1JlYWQ/Zm9yZWlnbktleT0ke3RyYWluaW5nSWR9JmZvcmVpZ25LZXlJZD0ke3RyYWluaW5nSWR9YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMCxcclxuICAgICAgICAgICAgc29ydDogJ09yZGVyQnktYXNjJ1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICAgICAgcmVzdWx0LkRhdGEuZm9yRWFjaCh0ID0+IHtcclxuICAgICAgICAgICAgdC5EZXNjcmlwdGlvbkJnID0gdC5EZXNjcmlwdGlvbkJnIHx8ICcnO1xyXG4gICAgICAgICAgICB0LkRlc2NyaXB0aW9uRW4gPSB0LkRlc2NyaXB0aW9uRW4gfHwgJyc7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiByZXN1bHQuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldFRyYWluaW5nc0J5VHJhaW5lcixcclxuICAgICAgICBnZXRUcmFpbmVyQnlJZCxcclxuICAgICAgICB1cGRhdGVUcmFpbmluZ0J5VHJhaW5lcixcclxuICAgICAgICBjcmVhdGVUcmFpbmluZ0J5VHJhaW5lcixcclxuICAgICAgICBkZXN0cm95VHJhaW5pbmdPZlRyYWluZXIsXHJcbiAgICAgICAgc2VhcmNoVXNlcnMsXHJcbiAgICAgICAgZ2V0VHJhaW5lcnNCeVRyYWluaW5nXHJcbiAgICB9O1xyXG59IiwiZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHBhcnNlQ3Jvc3NCcm93c2VyRmlsZShmaWxlRGVzY3JpcHRvcikge1xyXG4gICAgbGV0IGJsb2I7XHJcbiAgICBsZXQgZmlsZW5hbWU7XHJcbiAgICBpZiAoZmlsZURlc2NyaXB0b3IuZmlsZVVybCAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgYmxvYiA9IGF3YWl0IChhd2FpdCBmZXRjaChmaWxlRGVzY3JpcHRvci5maWxlVXJsKSkuYmxvYigpO1xyXG4gICAgICAgIGZpbGVuYW1lID0gZmlsZURlc2NyaXB0b3IubmFtZTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgYmxvYiA9IGZpbGVEZXNjcmlwdG9yLmZpbGU7XHJcbiAgICAgICAgZmlsZW5hbWUgPSBmaWxlRGVzY3JpcHRvci5maWxlLm5hbWU7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHsgYmxvYiwgZmlsZW5hbWUgfTtcclxufSIsImV4cG9ydCBkZWZhdWx0IGNsYXNzIEVtaXR0ZXIge1xyXG4gICAgY29uc3RydWN0b3IoKSB7XHJcbiAgICAgICAgdGhpcy5zdWJzY3JpYmVycyA9IG5ldyBNYXAoKTtcclxuICAgIH1cclxuXHJcbiAgICBvbihldnROYW1lLCBoYW5kbGVyKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuc3Vic2NyaWJlcnMuaGFzKGV2dE5hbWUpID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc3Vic2NyaWJlcnMuc2V0KGV2dE5hbWUsIFtdKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5zdWJzY3JpYmVycy5nZXQoZXZ0TmFtZSkucHVzaChoYW5kbGVyKTtcclxuICAgIH1cclxuXHJcbiAgICBvZmYoZXZ0TmFtZSwgaGFuZGxlcikge1xyXG4gICAgICAgIGNvbnN0IHN1YnNjcmliZXJzID0gdGhpcy5zdWJzY3JpYmVycy5nZXQoZXZ0TmFtZSk7XHJcbiAgICAgICAgaWYgKHN1YnNjcmliZXJzKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGluZGV4ID0gc3Vic2NyaWJlcnMuaW5kZXhPZihoYW5kbGVyKTtcclxuICAgICAgICAgICAgaWYgKGluZGV4ID4gLTEpIHtcclxuICAgICAgICAgICAgICAgIHN1YnNjcmliZXJzLnNwbGljZShpbmRleCwgMSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgZW1pdChldnROYW1lLCAuLi5kYXRhKSB7XHJcbiAgICAgICAgY29uc3Qgc3Vic2NyaWJlcnMgPSB0aGlzLnN1YnNjcmliZXJzLmdldChldnROYW1lKTtcclxuICAgICAgICBpZiAoc3Vic2NyaWJlcnMpIHtcclxuICAgICAgICAgICAgc3Vic2NyaWJlcnMuZm9yRWFjaChmbiA9PiB0aGlzLmludm9rZShmbiwgLi4uZGF0YSkpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBpbnZva2UoZm4sIC4uLmRhdGEpIHtcclxuICAgICAgICBpZiAodHlwZW9mIGZuID09ICdmdW5jdGlvbicpIHtcclxuICAgICAgICAgICAgZm4oLi4uZGF0YSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59IiwiaW1wb3J0IGRvbSwgeyBGcmFnbWVudCB9IGZyb20gJy4uL3V0aWwvanN4LXJlbmRlci1tb2QvZG9tJztcclxuaW1wb3J0IFByb2dyZXNzQmFyIGZyb20gJy4uL2NvbW1vbi9Qcm9ncmVzc0Jhcic7XHJcblxyXG5cclxuXHJcbmNvbnN0IGljb25zID0ge1xyXG4gICAgcXVlc3Rpb246ICdnbHlwaGljb24tcXVlc3Rpb24tc2lnbicsXHJcbiAgICB3YWl0OiAnZ2x5cGhpY29uLWhvdXJnbGFzcycsXHJcbiAgICB3cmVuY2g6ICdnbHlwaGljb24td3JlbmNoJyxcclxuICAgIGltcG9ydDogJ2dseXBoaWNvbi1pbXBvcnQnLFxyXG4gICAgZG93bmxvYWQ6ICdnbHlwaGljb24tZG93bmxvYWQtYWx0JyxcclxuICAgIGNoYXJ0OiAnZ2x5cGhpY29uLXNpZ25hbCdcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1vZGFsKHsgbWVzc2FnZSwgY2hpbGRyZW4sIG9uQ2xvc2UsIGljb24gPSAncXVlc3Rpb24nIH0pIHtcclxuICAgIGlmIChBcnJheS5pc0FycmF5KG1lc3NhZ2UpID09IGZhbHNlKSB7XHJcbiAgICAgICAgbWVzc2FnZSA9IFttZXNzYWdlXTtcclxuICAgIH1cclxuICAgIGNvbnN0IGNvbnRlbnQgPSAoPGRpdiBjbGFzc05hbWU9XCJzZXMtbW9kYWwtY29udGVudFwiPlxyXG4gICAgICAgIHtjaGlsZHJlbn1cclxuICAgIDwvZGl2Pik7XHJcblxyXG4gICAgY29uc3QgbW9kYWwgPSAoXHJcbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic2VzLW1vZGFsXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VzLW1vZGFsLXdpbmRvd1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXMtbW9kYWwtbWVzc2FnZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtpY29uICYmIDxpIGNsYXNzTmFtZT17YGdseXBoaWNvbiAke2ljb25zW2ljb25dfSBzZXMtbW9kYWwtaWNvbmB9PjwvaT59XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge21lc3NhZ2UubWFwKG0gPT4gPHA+e219PC9wPil9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIHtjb250ZW50fVxyXG4gICAgICAgICAgICAgICAge29uQ2xvc2UgIT09IHVuZGVmaW5lZCA/XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXMtbW9kYWwtY2xvc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cImphdmFzY3JpcHQ6dm9pZCgwKTtcIiBvbkNsaWNrPXtvbkNsb3NlfT48aSBjbGFzcz1cImdseXBoaWNvbiBnbHlwaGljb24tcmVtb3ZlXCIgc3R5bGU9e3sgY29sb3I6ICdyZWQnIH19PjwvaT48L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+IDpcclxuICAgICAgICAgICAgICAgICAgICBudWxsfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICApO1xyXG5cclxuICAgIG1vZGFsLl9jb250ZW50ID0gY29udGVudDtcclxuXHJcbiAgICByZXR1cm4gbW9kYWw7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBNb2RhbENvbnRyb2xzKHsgY2hpbGRyZW4gfSkge1xyXG4gICAgcmV0dXJuICg8dGFibGU+XHJcbiAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICB7Y2hpbGRyZW59XHJcbiAgICAgICAgPC90Ym9keT5cclxuICAgIDwvdGFibGU+KTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIE1vZGFsT3B0aW9uKHsgaWNvbiA9IG51bGwsIG9uQ2xpY2ssIGNoaWxkcmVuIH0pIHtcclxuICAgIHJldHVybiAoPHRyIGNsYXNzTmFtZT1cInNlcy1tb2RhbC1hY3RpdmVcIiBvbkNsaWNrPXtvbkNsaWNrfT5cclxuICAgICAgICA8dGQ+e2ljb259PC90ZD5cclxuICAgICAgICA8dGQ+e2NoaWxkcmVufTwvdGQ+XHJcbiAgICA8L3RyPik7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBcclxuICogQHBhcmFtIHtzdHJpbmd9IG1lc3NhZ2UgXHJcbiAqIEBwYXJhbSB7SFRNTEVsZW1lbnQgfCBBcnJheTxIVE1MRWxlbWVudD59IGNoaWxkcmVuIFxyXG4gKiBAcGFyYW0ge0Jvb2xlYW59IGNhbkNsb3NlIFxyXG4gKiBAcmV0dXJucyB7SW50ZXJhY3RpdmVNb2RhbH1cclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVNb2RhbChtZXNzYWdlLCBjaGlsZHJlbiwgY2FuQ2xvc2UgPSB0cnVlLCBpY29uID0gJ3F1ZXN0aW9uJykge1xyXG4gICAgLyoqIEB0eXBlIHtJbnRlcmFjdGl2ZU1vZGFsfSAqL1xyXG4gICAgY29uc3QgbW9kYWwgPSAoPE1vZGFsIG1lc3NhZ2U9e21lc3NhZ2V9IG9uQ2xvc2U9e2NhbkNsb3NlID8gY2xvc2UgOiB1bmRlZmluZWR9IGljb249e2ljb259PntjaGlsZHJlbn08L01vZGFsPik7XHJcblxyXG4gICAgaWYgKGNhbkNsb3NlKSB7XHJcbiAgICAgICAgbW9kYWwuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBvbkNsaWNrKTtcclxuICAgIH1cclxuICAgIG1vZGFsLmNsb3NlID0gY2xvc2U7XHJcbiAgICBtb2RhbC5vbkNsb3NlID0gbnVsbDtcclxuXHJcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKG1vZGFsKTtcclxuICAgIGNvbnN0IGRpdiA9IG1vZGFsLmNoaWxkcmVuWzBdO1xyXG4gICAgYWRqdXN0UG9zaXRpb24oKTtcclxuICAgIGNvbnN0IHJlc2l6ZU9ic2VydmVyID0gbmV3IFJlc2l6ZU9ic2VydmVyKGFkanVzdFBvc2l0aW9uKTtcclxuICAgIHJlc2l6ZU9ic2VydmVyLm9ic2VydmUobW9kYWwuX2NvbnRlbnQpO1xyXG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIGFkanVzdFBvc2l0aW9uKTtcclxuXHJcbiAgICByZXR1cm4gbW9kYWw7XHJcblxyXG4gICAgZnVuY3Rpb24gb25DbGljayhlKSB7XHJcbiAgICAgICAgaWYgKGUudGFyZ2V0ID09PSBtb2RhbCkge1xyXG4gICAgICAgICAgICBjbG9zZSgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBjbG9zZShwcm9wYWdhdGUgPSB0cnVlKSB7XHJcbiAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIGFkanVzdFBvc2l0aW9uKTtcclxuICAgICAgICByZXNpemVPYnNlcnZlci5kaXNjb25uZWN0KCk7XHJcbiAgICAgICAgbW9kYWwucmVtb3ZlKCk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBtb2RhbC5vbkNsb3NlID09ICdmdW5jdGlvbicgJiYgcHJvcGFnYXRlKSB7XHJcbiAgICAgICAgICAgIG1vZGFsLm9uQ2xvc2UoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gYWRqdXN0UG9zaXRpb24oKSB7XHJcbiAgICAgICAgY29uc3QgbmV3VG9wID0gKG1vZGFsLm9mZnNldEhlaWdodCAtIGRpdi5vZmZzZXRIZWlnaHQpIC8gMztcclxuICAgICAgICBkaXYuc3R5bGVbJ21hcmdpbi10b3AnXSA9IG5ld1RvcCArICdweCc7XHJcbiAgICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBAcGFyYW0ge3N0cmluZ30gbWVzc2FnZSBcclxuICogQHBhcmFtIHtIVE1MRWxlbWVudCB8IEFycmF5PEhUTUxFbGVtZW50Pn0gY29udGVudCBcclxuICogQHBhcmFtIHtBcnJheTxPcHRpb25EZXNjcmlwdG9yPn0gb3B0aW9ucyBcclxuICogQHBhcmFtIHtCb29sZWFufSBjYW5DbG9zZSBcclxuICogQHJldHVybnMge1Byb21pc2U8Ym9vbGVhbj59XHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlRGlhbG9nKG1lc3NhZ2UsIGNvbnRlbnQsIG9wdGlvbnMsIGNhbkNsb3NlID0gdHJ1ZSwgaWNvbiA9ICdxdWVzdGlvbicpIHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgY29uc3QgY29udHJvbHMgPSA8TW9kYWxDb250cm9scz5cclxuICAgICAgICAgICAge29wdGlvbnMubWFwKGNyZWF0ZU9wdGlvbi5iaW5kKG51bGwsIG9uQ29uZmlybSwgb25DYW5jZWwpKX1cclxuICAgICAgICA8L01vZGFsQ29udHJvbHM+O1xyXG5cclxuICAgICAgICBjb25zdCBtb2RhbCA9IGNyZWF0ZU1vZGFsKG1lc3NhZ2UsIFtjb250ZW50LCBjb250cm9sc10uZmxhdCgxKSwgY2FuQ2xvc2UsIGljb24pO1xyXG5cclxuICAgICAgICBtb2RhbC5vbkNsb3NlID0gKCkgPT4gcmVzb2x2ZShmYWxzZSk7XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIG9uQ29uZmlybSgpIHtcclxuICAgICAgICAgICAgbW9kYWwuY2xvc2UoZmFsc2UpO1xyXG4gICAgICAgICAgICByZXNvbHZlKHRydWUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZnVuY3Rpb24gb25DYW5jZWwoKSB7XHJcbiAgICAgICAgICAgIG1vZGFsLmNsb3NlKGZhbHNlKTtcclxuICAgICAgICAgICAgcmVzb2x2ZShmYWxzZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBvbkNvbmZpcm0gXHJcbiAqIEBwYXJhbSB7RnVuY3Rpb259IG9uQ2FuY2VsIFxyXG4gKiBAcGFyYW0ge09wdGlvbkRlc2NyaXB0b3IgfCBPcHRpb25FbnRyeX0gb3B0aW9uIFxyXG4gKiBAcmV0dXJucyB7TW9kYWxPcHRpb259XHJcbiAqL1xyXG5mdW5jdGlvbiBjcmVhdGVPcHRpb24ob25Db25maXJtLCBvbkNhbmNlbCwgb3B0aW9uLCBvcHRpb25JbmRleCkge1xyXG4gICAgY29uc3QgeyBpY29uID0gbnVsbCwgbGFiZWwsIHJvbGUsIG9uQ2xpY2ssIGNvbmZpcm1DaGVjayB9ID0gQXJyYXkuaXNBcnJheShvcHRpb24pID8ge1xyXG4gICAgICAgIGljb246IG9wdGlvblswXSxcclxuICAgICAgICBsYWJlbDogb3B0aW9uWzFdLFxyXG4gICAgICAgIHJvbGU6IG9wdGlvblsyXSxcclxuICAgICAgICBvbkNsaWNrOiBvcHRpb25bMl1cclxuICAgIH0gOiBvcHRpb247XHJcblxyXG4gICAgcmV0dXJuIDxNb2RhbE9wdGlvbiBpY29uPXtpY29ufSBvbkNsaWNrPXtjYWxsYmFja30+e2xhYmVsfTwvTW9kYWxPcHRpb24+O1xyXG5cclxuICAgIGZ1bmN0aW9uIGNhbGxiYWNrKGV2ZW50KSB7XHJcbiAgICAgICAgaWYgKHJvbGUgPT0gJ29rJykge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGNvbmZpcm1DaGVjayA9PSAnZnVuY3Rpb24nICYmIGNvbmZpcm1DaGVjaygpICE9IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBvbkNvbmZpcm0oKTtcclxuICAgICAgICB9IGVsc2UgaWYgKHJvbGUgPT0gJ2NhbmNlbCcpIHtcclxuICAgICAgICAgICAgb25DYW5jZWwoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2Ygb25DbGljayA9PSAnZnVuY3Rpb24nKSB7XHJcbiAgICAgICAgICAgIG9uQ2xpY2soZXZlbnQsIG9wdGlvbkluZGV4KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBAcGFyYW0ge0FycmF5PHN0cmluZz4gfCBzdHJpbmd9IG1lc3NhZ2VzIFxyXG4gKiBAcmV0dXJucyB7e25leHRCYXI6IEZ1bmN0aW9ufSAmIEludGVyYWN0aXZlTW9kYWx9XHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlTG9hZGluZ01vZGFsKG1lc3NhZ2VzKSB7XHJcbiAgICBpZiAoQXJyYXkuaXNBcnJheShtZXNzYWdlcykgPT0gZmFsc2UpIHtcclxuICAgICAgICBtZXNzYWdlcyA9IFttZXNzYWdlc107XHJcbiAgICB9XHJcbiAgICBjb25zdCBiYXJzID0gbWVzc2FnZXMubWFwKG0gPT4gUHJvZ3Jlc3NCYXIoNDAwLCBtLCBvbkZpbmlzaCkpO1xyXG4gICAgbGV0IGZpbmlzaGVkID0gMDtcclxuICAgIGxldCBjdXJyZW50ID0gMDtcclxuXHJcbiAgICBjb25zdCBtb2RhbCA9IGNyZWF0ZU1vZGFsKGJhcnMsIG51bGwsIGZhbHNlLCAnd2FpdCcpO1xyXG4gICAgbW9kYWwubmV4dEJhciA9IG5leHRCYXI7XHJcblxyXG4gICAgcmV0dXJuIG1vZGFsO1xyXG5cclxuICAgIGZ1bmN0aW9uIG5leHRCYXIoKSB7XHJcbiAgICAgICAgaWYgKGN1cnJlbnQgPCBiYXJzLmxlbmd0aCkge1xyXG4gICAgICAgICAgICByZXR1cm4gYmFyc1tjdXJyZW50KytdLm9uUHJvZ3Jlc3M7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIG9uRmluaXNoKCkge1xyXG4gICAgICAgIGZpbmlzaGVkKys7XHJcbiAgICAgICAgaWYgKGZpbmlzaGVkID09IGJhcnMubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgIG1vZGFsLmNsb3NlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5cclxuLyoqXHJcbiAqIEB0eXBlZGVmIHtPYmplY3R9IE9wdGlvbkRlc2NyaXB0b3JcclxuICogQHByb3BlcnR5IHtIVE1MRWxlbWVudH0gW2ljb249bnVsbF1cclxuICogQHByb3BlcnR5IHtzdHJpbmd9IGxhYmVsXHJcbiAqIEBwcm9wZXJ0eSB7XCJva1wiIHwgXCJjYW5jZWxcIn0gW3JvbGU9XVxyXG4gKiBAcHJvcGVydHkge0Z1bmN0aW9ufSBbb25DbGljaz1dXHJcbiAqL1xyXG5cclxuLyoqXHJcbiAqIEB0eXBlZGVmIHtbSFRNTEVsZW1lbnQgfCBudWxsLCBzdHJpbmcsIFwib2tcIiB8IFwiY2FuY2VsXCIgfCB1bmRlZmluZWQgfCBGdW5jdGlvbl19IE9wdGlvbkVudHJ5XHJcbiAqL1xyXG5cclxuLyoqXHJcbiAqIEB0eXBlZGVmIHtPYmplY3R9IEludGVyYWN0aXZlTW9kYWxcclxuICogQHByb3BlcnR5IHtGdW5jdGlvbn0gY2xvc2VcclxuICogQHByb3BlcnR5IHsoZXZlbnQ6IEV2ZW50LCBvcHRpb25JbmRleDogbnVtYmVyKSA9PiB7fX0gW29uQ2xvc2U9bnVsbF1cclxuICovIiwiaW1wb3J0IGRvbSBmcm9tICcuLi91dGlsL2pzeC1yZW5kZXItbW9kL2RvbSc7XHJcblxyXG5cclxuLyoqXHJcbiAqIEBwYXJhbSB7bnVtYmVyfSB3aWR0aCBcclxuICogQHBhcmFtIHtzdHJpbmd9IGxhYmVsIFxyXG4gKiBAcmV0dXJucyB7UHJvZ3Jlc3NCYXJFbGVtZW50fVxyXG4gKi9cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUHJvZ3Jlc3NCYXIod2lkdGgsIGxhYmVsLCBvbkZpbmlzaCkge1xyXG4gICAgY29uc3QgcGVyY2VudCA9IDxzcGFuPjAlPC9zcGFuPjtcclxuICAgIC8qKiBAdHlwZSB7UHJvZ3Jlc3NCYXJFbGVtZW50fSAqL1xyXG4gICAgY29uc3QgYmFyID0gPHNwYW4gc3R5bGU9e3sgcGFkZGluZzogJzAgMC41ZW0nLCBkaXNwbGF5OiAnaW5saW5lLWJsb2NrJywgd2lkdGg6IHdpZHRoICsgJ3B4JywgYmFja2dyb3VuZDogJ2xpbmVhci1ncmFkaWVudCh0byByaWdodCwgI2ZmYTAwMCAwJSwgI2VlZSAwKScgfX0+e3BlcmNlbnR9e2xhYmVsID8gYCAke2xhYmVsfWAgOiBudWxsfTwvc3Bhbj47XHJcbiAgICBiYXIub25Qcm9ncmVzcyA9IG9uUHJvZ3Jlc3M7XHJcblxyXG4gICAgcmV0dXJuIGJhcjtcclxuXHJcbiAgICBmdW5jdGlvbiBvblByb2dyZXNzKGNvbXBsZXRlZCwgdG90YWwpIHtcclxuICAgICAgICBjb25zdCBwcm9ncmVzcyA9IHRvdGFsID09IDAgPyAxMDAgOiBNYXRoLmZsb29yKGNvbXBsZXRlZCAvIHRvdGFsICogMTAwKTtcclxuICAgICAgICBwZXJjZW50LnRleHRDb250ZW50ID0gcHJvZ3Jlc3MgKyAnJSc7XHJcbiAgICAgICAgYmFyLnN0eWxlLmJhY2tncm91bmQgPSBgbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZmZhMDAwICR7cHJvZ3Jlc3N9JSwgI2VlZSAwKWA7XHJcblxyXG4gICAgICAgIGlmICgodG90YWwgPT0gMCB8fCBjb21wbGV0ZWQgPT0gdG90YWwpICYmIHR5cGVvZiBvbkZpbmlzaCA9PSAnZnVuY3Rpb24nKSAge1xyXG4gICAgICAgICAgICBvbkZpbmlzaCgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIEB0eXBlZGVmIHtQcm9ncmVzc0JhclNwYW4gJiBIVE1MU3BhbkVsZW1lbnR9IFByb2dyZXNzQmFyRWxlbWVudFxyXG4gKiBAcHJvcGVydHkge0Z1bmN0aW9ufSBvblByb2dyZXNzXHJcbiAqL1xyXG5cclxuLyoqXHJcbiAqIEB0eXBlZGVmIHtPYmplY3R9IFByb2dyZXNzQmFyU3BhblxyXG4gKiBAcHJvcGVydHkge0Z1bmN0aW9ufSBvblByb2dyZXNzXHJcbiAqLyIsImltcG9ydCB7IGNyZWF0ZU1vZGFsIH0gZnJvbSAnLi4vLi4vY29tbW9uL01vZGFsJztcclxuaW1wb3J0IHsgY3JlYXRlVGVtcGxhdGVNb2RlbCwgZGVsZXRlVGVtcGxhdGUgfSBmcm9tICcuLi8uLi90ZW1wbGF0ZXMvZGF0YSc7XHJcbmltcG9ydCBQcmV2aWV3IGZyb20gJy4uLy4uL3RlbXBsYXRlcy9QcmV2aWV3JztcclxuaW1wb3J0IGRvbSwgeyBGcmFnbWVudCB9IGZyb20gJy4uLy4uL3V0aWwvanN4LXJlbmRlci1tb2QvZG9tJztcclxuaW1wb3J0IHsgcmVkaXJlY3QgfSBmcm9tICcuLi8uLi91dGlsL3JvdXRlcic7XHJcbmltcG9ydCB7IExvYWRpbmcsIE5vLCByZXBsYWNlQ29udGVudHMsIFllcyB9IGZyb20gJy4uLy4uL3V0aWwvdGVtcGxhdGUnO1xyXG5pbXBvcnQgeyBBU1NJR05fQlVUVE9OLCBERUxFVEVfQlVUVE9OLCBERUxFVEVfVEVNUExBVEVfQ09ORklSTSwgRURJVF9CVVRUT04sIEVSUk9SX09DQ1VSRUQsIE5PX1RFTVBMQVRFLCBURU1QTEFURV9SRUFEWSB9IGZyb20gJy4uL3N0cmluZ3MnO1xyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIERlc2NyaXB0aW9uKHsgdGVtcGxhdGUsIGluc3RhbmNlRGF0YSwgYWxsVGVtcGxhdGVzLCBhcGksIGNhdGVnb3JpZXMsIGNvbnRleHQgfSkge1xyXG4gICAgbGV0IGVsZW1lbnQgPSB0ZW1wbGF0ZSA/IDxIYXNUZW1wbGF0ZSAvPiA6IDxOb1RlbXBsYXRlIC8+O1xyXG5cclxuICAgIHJldHVybiBlbGVtZW50O1xyXG5cclxuICAgIGZ1bmN0aW9uIEhhc1RlbXBsYXRlKCkge1xyXG4gICAgICAgIHJldHVybiAoPGRpdj5cclxuICAgICAgICAgICAge1RFTVBMQVRFX1JFQURZfSA8WWVzIC8+XHJcbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gcmVkaXJlY3QoYD9jb3Vyc2VJZD0ke2luc3RhbmNlRGF0YS5pbmZvLkNvdXJzZUlkfSZpbnN0YW5jZUlkPSR7aW5zdGFuY2VEYXRhLmluZm8uSWR9JnRhYj1kZXNjcmlwdGlvbmApfT48aSBjbGFzcz1cImdseXBoaWNvbiBnbHlwaGljb24tcGVuY2lsXCI+PC9pPiB7RURJVF9CVVRUT059PC9idXR0b24+XHJcbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17b25EZWxldGV9PjxpIGNsYXNzPVwiZ2x5cGhpY29uIGdseXBoaWNvbi10cmFzaFwiPjwvaT4ge0RFTEVURV9CVVRUT059PC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+KTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBOb1RlbXBsYXRlKCkge1xyXG4gICAgICAgIHJldHVybiAoPGRpdj5cclxuICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFN0eWxlOiAnaXRhbGljJyB9fT57Tk9fVEVNUExBVEV9PC9zcGFuPlxyXG4gICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGNyZWF0ZUFzc2lnbkRpYWxvZyhjYXRlZ29yaWVzLCBhbGxUZW1wbGF0ZXMsIG9uU2VsZWN0KX0+PGkgY2xhc3M9XCJnbHlwaGljb24gZ2x5cGhpY29uLWxpbmtcIj48L2k+IHtBU1NJR05fQlVUVE9OfTwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2Pik7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gb25TZWxlY3Qoc2VsZWN0ZWRUZW1wbGF0ZSkge1xyXG4gICAgICAgIGNvbnN0IGFzc2lnbmVkID0gY3JlYXRlVGVtcGxhdGVNb2RlbCgpO1xyXG4gICAgICAgIGFzc2lnbmVkLk5hbWUgPSBpbnN0YW5jZURhdGEuaW5mby5OYW1lQmc7XHJcbiAgICAgICAgYXNzaWduZWQuQ29udGVudCA9IHNlbGVjdGVkVGVtcGxhdGUuQ29udGVudDtcclxuICAgICAgICBhc3NpZ25lZC5JbnN0YW5jZUlkID0gaW5zdGFuY2VEYXRhLmluZm8uSWQ7XHJcblxyXG4gICAgICAgIGVsZW1lbnQgPSByZXBsYWNlQ29udGVudHMoZWxlbWVudCwgPExvYWRpbmcgY29sb3I9XCJibGFja1wiIC8+KTtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb250ZXh0LmVtaXQoJ1RlbXBsYXRlU2VsZWN0ZWQnLCBhc3NpZ25lZCk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgIGVsZW1lbnQgPSByZXBsYWNlQ29udGVudHMoZWxlbWVudCwgPGRpdj57RVJST1JfT0NDVVJFRH08L2Rpdj4pO1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIG9uRGVsZXRlKCkge1xyXG4gICAgICAgIGNvbnN0IGNob2ljZSA9IGNvbmZpcm0oREVMRVRFX1RFTVBMQVRFX0NPTkZJUk0odGVtcGxhdGUuTmFtZSkpO1xyXG4gICAgICAgIGlmIChjaG9pY2UpIHtcclxuICAgICAgICAgICAgZWxlbWVudCA9IHJlcGxhY2VDb250ZW50cyhlbGVtZW50LCA8TG9hZGluZyBjb2xvcj1cImJsYWNrXCIgLz4pO1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgYXdhaXQgZGVsZXRlVGVtcGxhdGUoYXBpLCB0ZW1wbGF0ZSk7XHJcbiAgICAgICAgICAgICAgICBhbGxUZW1wbGF0ZXMuc3BsaWNlKGFsbFRlbXBsYXRlcy5pbmRleE9mKHRlbXBsYXRlKSwgMSk7XHJcbiAgICAgICAgICAgICAgICBlbGVtZW50ID0gcmVwbGFjZUNvbnRlbnRzKGVsZW1lbnQsIDxOb1RlbXBsYXRlIC8+KTtcclxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgICAgICBlbGVtZW50ID0gcmVwbGFjZUNvbnRlbnRzKGVsZW1lbnQsIDxkaXY+e0VSUk9SX09DQ1VSRUR9PC9kaXY+KTtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUFzc2lnbkRpYWxvZyhjYXRlZ29yaWVzLCB0ZW1wbGF0ZXMsIG9uU2VsZWN0LCBmcmFnbWVudE1vZGUpIHtcclxuICAgIGNvbnN0IHRlbXBsYXRlTGlzdCA9ICg8RnJhZ21lbnQ+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXMtc2Nyb2xsXCI+XHJcbiAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJzZXMtdGVtcGxhdGUtdGFibGVcIiBzdHlsZT17eyB3aWR0aDogJzEwMCUnLCBib3JkZXJDb2xsYXBzZTogJ2NvbGxhcHNlJyB9fT5cclxuICAgICAgICAgICAgICAgIDx0aGVhZD5cclxuICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aD7QmNC80LU8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGg+0JrQsNGC0LXQs9C+0YDQuNC4PC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoPtCa0L7QvdGC0YDQvtC7PC90aD5cclxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICB7dGVtcGxhdGVzLmZpbHRlcih0ID0+ICF0Lkluc3RhbmNlSWQgJiYgKGZyYWdtZW50TW9kZSA/IHQuQ29tcG91bmQgIT0gdHJ1ZSA6IHQuQ29tcG91bmQpKS5tYXAoVGVtcGxhdGVSb3cuYmluZChudWxsLCBjYXRlZ29yaWVzLCB0ZW1wbGF0ZXMsIHQgPT4geyBkaWFsb2cuY2xvc2UoKTsgb25TZWxlY3QodCk7IH0pKX1cclxuICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPHRhYmxlPlxyXG4gICAgICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwic2VzLW1vZGFsLWFjdGl2ZVwiIG9uQ2xpY2s9eygpID0+IGRpYWxvZy5jbG9zZSgpfT48dGQ+PE5vIC8+PC90ZD48dGQ+0J7QsdGA0LDRgtC90L4g0LIg0YDQtdC00LDQutGC0L7RgNCwPC90ZD48L3RyPlxyXG4gICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgIDwvdGFibGU+XHJcbiAgICA8L0ZyYWdtZW50Pik7XHJcblxyXG4gICAgY29uc3QgZGlhbG9nID0gY3JlYXRlTW9kYWwoJ1NlbGVjdCB0ZW1wbGF0ZScsIHRlbXBsYXRlTGlzdCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIFRlbXBsYXRlUm93KGNhdGVnb3JpZXMsIGFsbFRlbXBsYXRlcywgb25TZWxlY3QsIHRlbXBsYXRlKSB7XHJcbiAgICBjb25zdCB1c2VzRnJhZ21lbnRzID0gL1xcW1xcW1JlZj0uKz9cXF1cXF0vLnRlc3QodGVtcGxhdGUuQ29udGVudCk7XHJcbiAgICBjb25zdCBpc0R5bmFtaWMgPSB1c2VzRnJhZ21lbnRzID09IGZhbHNlICYmIC9cXFtcXFsuKz9cXF1cXF0vLnRlc3QodGVtcGxhdGUuQ29udGVudCk7XHJcblxyXG4gICAgbGV0IGFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgY29uc3QgZWxlbWVudCA9ICg8dHIgY2xhc3NOYW1lPVwic2VzLXRlbXBsYXRlLXJvd1wiIG9uQ2xpY2s9e3RvZ2dsZX0+XHJcbiAgICAgICAgPHRkPnt0ZW1wbGF0ZS5OYW1lfTwvdGQ+XHJcbiAgICAgICAgPHRkPlxyXG4gICAgICAgICAgICB7dGVtcGxhdGUuQ2F0ZWdvcnkubWFwKGMgPT4gPHNwYW4gY2xhc3NOYW1lPVwic2VzLXRlbXBsYXRlLWNhdGVnb3J5XCI+e2NhdGVnb3JpZXNbY119PC9zcGFuPil9XHJcbiAgICAgICAgICAgIHt1c2VzRnJhZ21lbnRzID8gPHNwYW4gY2xhc3NOYW1lPVwic2VzLXRlbXBsYXRlLWNhdGVnb3J5LWF1dG9cIj7QodGK0LTRitGA0LbQsCDRhNGA0LDQs9C80LXQvdGC0Lg8L3NwYW4+IDogJyd9XHJcbiAgICAgICAgICAgIHtpc0R5bmFtaWMgPyA8c3BhbiBjbGFzc05hbWU9XCJzZXMtdGVtcGxhdGUtY2F0ZWdvcnktYXV0b1wiPtCU0LjQvdCw0LzQuNGH0LXQvTwvc3Bhbj4gOiAnJ31cclxuICAgICAgICA8L3RkPlxyXG4gICAgICAgIDx0ZCBjbGFzc05hbWU9XCJzZXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gb25TZWxlY3QodGVtcGxhdGUpfT48aSBjbGFzcz1cImdseXBoaWNvbiBnbHlwaGljb24tbGlua1wiPjwvaT4g0JjQt9Cx0LXRgNC4PC9idXR0b24+XHJcbiAgICAgICAgPC90ZD5cclxuICAgIDwvdHI+KTtcclxuICAgIGxldCBwcmV2aWV3ID0gbnVsbDtcclxuXHJcbiAgICByZXR1cm4gZWxlbWVudDtcclxuXHJcbiAgICBmdW5jdGlvbiB0b2dnbGUoZSkge1xyXG4gICAgICAgIGlmIChlICYmIChlLnRhcmdldC50YWdOYW1lID09ICdJJyB8fCBlLnRhcmdldC50YWdOYW1lID09ICdCVVRUT04nKSkge1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoYWN0aXZlKSB7XHJcbiAgICAgICAgICAgIGFjdGl2ZSA9IGZhbHNlO1xyXG5cclxuICAgICAgICAgICAgcHJldmlldy5yZW1vdmUoKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBhY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICBpZiAocHJldmlldyA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICBwcmV2aWV3ID0gZ2VuZXJhdGVQcmV2aWV3KGFsbFRlbXBsYXRlcywgdGVtcGxhdGUsIHRvZ2dsZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxlbWVudC5hZnRlcihwcmV2aWV3KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGdlbmVyYXRlUHJldmlldyhhbGxUZW1wbGF0ZXMsIHRlbXBsYXRlLCB0b2dnbGUpIHtcclxuXHJcbiAgICByZXR1cm4gKDx0cj5cclxuICAgICAgICA8dGQgY29sU3Bhbj1cIjNcIj5cclxuICAgICAgICAgICAgPFByZXZpZXcgY29udGVudD17dGVtcGxhdGUuQ29udGVudH0gdGVtcGxhdGVzPXthbGxUZW1wbGF0ZXN9IC8+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIHN0eWxlPXt7IGZsb2F0OiAncmlnaHQnIH19IG9uQ2xpY2s9eygpID0+IHRvZ2dsZSgpfT7Ql9Cw0YLQstC+0YDQuDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L3RkPlxyXG4gICAgPC90cj4pO1xyXG59IiwiLy8gTWFpbiBwYWdlXHJcblxyXG5leHBvcnQgY29uc3QgQ09VUlNFX0RBU0hCT0FSRF9USVRMRSA9ICfQlNCw0YjQsdC+0YDQtCc7XHJcbmV4cG9ydCBjb25zdCBMT0FESU5HX0NPVVJTRV9ERVRBSUxTID0gJ9CX0LDRgNC10LbQtNCw0L3QtSDQvdCwINC60YPRgNGB0L7QstCw0YLQsCDQuNC90YTQvtGA0LzQsNGG0LjRjyZoZWxsaXA7JztcclxuZXhwb3J0IGNvbnN0IExPQ0FMSVpFRF9OQU1FU19MQUJFTCA9ICfQm9C+0LrQsNC70LjQt9Cw0YbQuNGPINC90LAg0LjQvNC10L3QsCDQuCDQvtC/0LjRgdCw0L3QuNGPIEJHL0VOJztcclxuZXhwb3J0IGNvbnN0IFNIT1dfREVTQ1JJUFRJT05fTEFCRUwgPSAn0J/QvtC60LDQttC4INGG0LXQu9C40YLQtSDQvtC/0LjRgdCw0L3QuNGPJztcclxuZXhwb3J0IGNvbnN0IEFMTE9XX01VTFRJUExFX0VWRU5UU19MQUJFTCA9ICfQn9C+0LfQstC+0LvQuCDQvdGP0LrQvtC70LrQviDRgdGK0LHQuNGC0Y8g0LfQsCDQtdC00L3QsCDQu9C10LrRhtC40Y8nO1xyXG5leHBvcnQgY29uc3QgSU5DTFVERV9BTExfSEFMTFNfTEFCRUwgPSAn0JLQutC70Y7Rh9C4INCy0YHQuNGH0LrQuCDQsNC60YLQuNCy0L3QuCDQt9Cw0LvQuCc7XHJcbmV4cG9ydCBjb25zdCBTSE9XX1RSQUlORVJfUEVSX0xFQ1RVUkVfTEFCRUwgPSAn0J/QvtC60LDQttC4INGC0YDQtdC50L3RitGAINC30LAg0LLRgdGP0LrQsCDQu9C10LrRhtC40Y8nO1xyXG5leHBvcnQgY29uc3QgQVVUT01BVElDQUxMWV9TRUxFQ1RfVFJBSU5FUl9MQUJFTCA9ICfQkNCy0YLQvtC80LDRgtC40YfQvdC+INC40LfQsdC40YDQsNC90LUg0L/RgNC4INC10LTQuNC90YHRgtCy0LXQvSDQu9C10LrRgtC+0YAnO1xyXG5cclxuZXhwb3J0IGNvbnN0IElOU1RBTkNFX1BBR0VfTElOSyA9ICfQodGC0YDQsNC90LjRhtCwINC90LAg0LjQvdGB0YLQsNC90YbQuNGP0YLQsCc7XHJcbmV4cG9ydCBjb25zdCBTVUxTX0FETUlOX0xJTksgPSAnU1VMUyDQkNC00LzQuNC90LjRgdGC0YDQsNGG0LjRjyc7XHJcbmV4cG9ydCBjb25zdCBMT0dfREFUQV9MSU5LID0gJ9CU0LXQsdGK0LMg0LjQvdGE0L7RgNC80LDRhtC40Y8nO1xyXG5leHBvcnQgY29uc3QgVEVNUExBVEVfRURJVE9SX0xJTksgPSAn0KDQtdC00LDQutGC0L7RgCDQvdCwINGI0LDQsdC70L7QvdC4JztcclxuXHJcbmV4cG9ydCBjb25zdCBDQUNIRV9ESVNDTEFJTUVSID0gJ9Cd0Y/QutC+0Lgg0L/RgNC+0LzQtdC90Lgg0LzQvtC20LUg0LTQsCDQt9Cw0LLQuNGB0Y/RgiDQvtGCINGB0YrRgNCy0YrRgNC90LjRjyDQutC10YgsINC30LAg0LTQsCDRgdGC0LDQvdCw0YIg0L/Rg9Cx0LvQuNGH0L3QviDQstC40LTQuNC80LguJztcclxuXHJcbmV4cG9ydCBjb25zdCBHRU5FUkFMX1RBQl9MSU5LID0gJ9CY0L3RhNC+0YDQvNCw0YbQuNGPJztcclxuZXhwb3J0IGNvbnN0IExFQ1RVUkVTX1RBQl9MSU5LID0gJ9Cb0LXQutGG0LjQuCc7XHJcbmV4cG9ydCBjb25zdCBFVkVOVFNfVEFCX0xJTksgPSAn0KHRitCx0LjRgtC40Y8nO1xyXG5leHBvcnQgY29uc3QgRVhBTVNfVEFCX0xJTksgPSAn0JjQt9C/0LjRgtC4JztcclxuZXhwb3J0IGNvbnN0IFVTRVJTX1RBQl9MSU5LID0gJ9Cf0L7RgtGA0LXQsdC40YLQtdC70LgnO1xyXG5leHBvcnQgY29uc3QgQVNTRVNTTUVOVF9UQUJfTElOSyA9ICfQntGG0LXQvdGP0LLQsNC90LUnO1xyXG5cclxuXHJcbi8vIEdlbmVyYWwgdGFiXHJcblxyXG5leHBvcnQgY29uc3QgU0tJTExTX0hFQURJTkcgPSAn0KPQvNC10L3QuNGPJztcclxuZXhwb3J0IGNvbnN0IFBVQkxJQ19OQU1FX0hFQURJTkcgPSAn0J/Rg9Cx0LvQuNGH0L3QviDQuNC80LUnO1xyXG5leHBvcnQgY29uc3QgUFVCTElDX1BIT1RPX0hFQURJTkcgPSAn0KHQvdC40LzQutCwJztcclxuZXhwb3J0IGNvbnN0IEFTX1BST0ZJTEVfTEFCRUwgPSAn0LrQsNGC0L4g0LIg0L/RgNC+0YTQuNC70LAnO1xyXG5leHBvcnQgY29uc3QgREVTQ1JJUFRJT05fSEVBRElORyA9ICfQntC/0LjRgdCw0L3QuNC1JztcclxuZXhwb3J0IGNvbnN0IFRSQUlORVJTX0hFQURJTkcgPSAn0J/Rg9Cx0LvQuNGH0L3QuCDRgtGA0LXQudC90YrRgNC4JztcclxuXHJcbmV4cG9ydCBjb25zdCBPUkRFUl9IRUFESU5HID0gJ9Cf0L7QtNGA0LXQtNCx0LAnO1xyXG5leHBvcnQgY29uc3QgQ09OVEVOVF9IRUFESU5HID0gJ9Ch0YrQtNGK0YDQttCw0L3QuNC1JztcclxuZXhwb3J0IGNvbnN0IFJFTEFURURfSEVBRElORyA9ICfQodCy0YrRgNC30LDQvdC4JztcclxuZXhwb3J0IGNvbnN0IENPTlRST0xTX0hFQURJTkcgPSAn0JrQvtC90YLRgNC+0LsnO1xyXG5leHBvcnQgY29uc3QgQUREX1NLSUxMX0JVVFRPTiA9ICfQlNC+0LHQsNCy0Lgg0L3QvtCy0L4g0YPQvNC10L3QuNC1JztcclxuZXhwb3J0IGNvbnN0IExJTktfU0tJTExfQlVUVE9OID0gJ9Ch0YrRidC10YHRgtCy0YPQstCw0YnQviDRg9C80LXQvdC40LUnO1xyXG5cclxuZXhwb3J0IGNvbnN0IE5BTUVfSEVBRElORyA9ICfQmNC80LUnO1xyXG5leHBvcnQgY29uc3QgVVNFUk5BTUVfSEVBRElORyA9ICfQn9C+0YLRgNC10LHQuNGC0LXQu9GB0LrQviDQuNC80LUnO1xyXG5leHBvcnQgY29uc3QgSElTVE9SWV9IRUFESU5HID0gJ9CY0YHRgtC+0YDQuNGPJztcclxuZXhwb3J0IGNvbnN0IEFERF9UUkFJTkVSX0JVVFRPTiA9ICfQlNC+0LHQsNCy0Lgg0YLRgNC10LnQvdGK0YAnO1xyXG5cclxuZXhwb3J0IGNvbnN0IFVOTElOS19TS0lMTF9DT05GSVJNID0gKGxhYmVsKSA9PiBg0J/QvtGC0LLRitGA0LTQtdGC0LUg0YDQsNC30LrQsNGH0LLQsNC90LXRgtC+INC90LAgJHtsYWJlbH0/XFxuXFxuKNC+0YHRgtCw0L3QsNC70LjRgtC1INGB0LLRitGA0LfQsNC90Lgg0L7QsdGD0YfQtdC90LjRjyDQndCv0JzQkCDQtNCwINCx0YrQtNCw0YIg0LfQsNGB0LXQs9C90LDRgtC4KWA7XHJcbmV4cG9ydCBjb25zdCBERUxFVEVfU0tJTExfQ09ORklSTSA9IChsYWJlbCkgPT4gYNCf0L7RgtCy0YrRgNC00LXRgtC1INC40LfRgtGA0LjQstCw0L3QtdGC0L4g0L3QsCAke2xhYmVsfT9gO1xyXG5leHBvcnQgY29uc3QgRURJVF9TS0lMTF9DT05GSVJNID0gKHNraWxscykgPT4gYNCi0L7QstCwINGD0LzQtdC90LjQtSDRgdC1INC40LfQv9C+0LvQt9Cy0LAg0LIg0YHQu9C10LTQvdC40YLQtSDQvtCx0YPRh9C10L3QuNGPOlxcblxcbiR7c2tpbGxzfVxcblxcbtCh0LjQs9GD0YDQvdC4INC70Lgg0YHRgtC1LCDRh9C1INC40YHQutCw0YLQtSDQtNCwINGA0LXQtNCw0LrRgtC40YDQsNGC0LUg0JLQodCY0KfQmtCYINCe0JHQo9Cn0JXQndCY0K8/YDtcclxuZXhwb3J0IGNvbnN0IENSRUFURV9GUk9NX0VESVRfU0tJTExfQ09ORklSTSA9IChvbGRMYWJlbCwgbmV3TGFiZWwsIGV4aXN0aW5nVHJhaW5pbmdzQ291bnQpID0+IGDQotC+0LLQsCDRidC1ICR7ZXhpc3RpbmdUcmFpbmluZ3NDb3VudCA+IDEgPyAn0YDQsNC30LrQsNGH0LgnIDogJ9C40LfRgtGA0LjQtSd9IFwiJHtvbGRMYWJlbH1cIiDQuCDRidC1INGB0YrQt9C00LDQtNC1INC4INC30LDQutCw0YfQuCBcIiR7bmV3TGFiZWx9XCIsINCy0YHQuNGH0LrQuCDQvtGB0YLQsNC90LDQu9C4INC+0LHRg9GH0LXQvdC40Y8g0LrQvtC40YLQviDQuNC30L/QvtC70LfQstCw0YIgXCIke29sZExhYmVsfVwiINGJ0LUg0L7RgdGC0LDQvdCw0YIg0L3QtdC/0YDQvtC80LXQvdC10L3QuC4g0JzQvtC70Y8g0L/QvtGC0LLRitGA0LTQtdGC0LU/YDtcclxuXHJcbmV4cG9ydCBjb25zdCBWSUVXX0xJTksgPSAn0J/RgNC10LPQu9C10LTQsNC5JztcclxuXHJcbmV4cG9ydCBjb25zdCBURU1QTEFURV9SRUFEWSA9ICfQqNCw0LHQu9C+0L3QsCDQtSDQvdCwINGA0LDQt9C/0L7Qu9C+0LbQtdC90LjQtSc7XHJcbmV4cG9ydCBjb25zdCBFRElUX0JVVFRPTiA9ICfQoNC10LTQsNC60YLQuNGA0LDQuSc7XHJcbmV4cG9ydCBjb25zdCBERUxFVEVfQlVUVE9OID0gJ9CY0LfRgtGA0LjQuSc7XHJcbmV4cG9ydCBjb25zdCBOT19URU1QTEFURSA9ICfQndC1INC1INC90LDRgdGC0YDQvtC10L0g0YjQsNCx0LvQvtC9JztcclxuZXhwb3J0IGNvbnN0IEFTU0lHTl9CVVRUT04gPSAn0J/RgNC40LvQvtC20LgnO1xyXG5leHBvcnQgY29uc3QgRVJST1JfT0NDVVJFRCA9ICfQktGK0LfQvdC40LrQvdCwINCz0YDQtdGI0LrQsCwg0LLQuNC20YLQtSDQsiDQutC+0L3Qt9C+0LvQsNGC0LAg0LfQsCDQtNC10YLQsNC50LvQuC4nO1xyXG5leHBvcnQgY29uc3QgREVMRVRFX1RFTVBMQVRFX0NPTkZJUk0gPSAobmFtZSkgPT4gYNCh0LjQs9GD0YDQvdC4INC70Lgg0YHRgtC1LCDRh9C1INC40YHQutCw0YLQtSDQtNCwINC40LfRgtGA0LjQtdGC0LUg0YjQsNCx0LvQvtC90LAgXCIke25hbWV9XCI/XFxuKNC+0L/QuNGB0LDQvdC40LXRgtC+INC90LAg0LjQvdGB0YLQsNC90YbQuNGP0YLQsCDQvdGP0LzQsCDQtNCwINCx0YrQtNC1INC30LDRgdC10LPQvdCw0YLQvilgO1xyXG5cclxuZXhwb3J0IGNvbnN0IERFTEVURV9UUkFJTkVSX0NPTkZJUk0gPSAoZmlyc3ROYW1lLCBsYXN0TmFtZSkgPT4gYNCf0L7RgtCy0YrRgNC00LXRgtC1INC/0YDQtdC80LDRhdCy0LDQvdC10YLQviDQvdCwINGC0YDQtdC50L3RitGAICR7Zmlyc3ROYW1lfSAke2xhc3ROYW1lfT9gO1xyXG5leHBvcnQgY29uc3QgTUlTU0lOR19ST0xFID0gJ9CY0LfQsdGA0LDQvdC40Y8g0L/QvtGC0YDQtdCx0LjRgtC10Lsg0L3Rj9C80LAg0YDQvtC70Y8gXCLQm9C10LrRgtC+0YBcIi4g0JTQvtCx0LDQstC10YLQtSDRjyDQv9GA0LXQtyDQsNC00LzQuNC90LjRgdGC0YDQsNGG0LjRj9GC0LAg0Lgg0L7Qv9C40YLQsNC50YLQtSDQvtGC0L3QvtCy0L4uJztcclxuXHJcbmV4cG9ydCBjb25zdCBMSVZFX0hFQURJTkcgPSAn0J3QsCDQttC40LLQvic7XHJcbmV4cG9ydCBjb25zdCBDRVJUSUZJQ0FURV9IRUFESU5HID0gJ9Ch0LXRgNGC0LjRhNC40LrQsNGCJztcclxuZXhwb3J0IGNvbnN0IEhPTUVXT1JLX0hFQURJTkcgPSAn0JTQvtC80LDRiNC90L4nO1xyXG5leHBvcnQgY29uc3QgQUREX0xFQ1RVUkVfQlVUVE9OID0gJ9CU0L7QsdCw0LLQuCDQu9C10LrRhtC40Y8nO1xyXG5leHBvcnQgY29uc3QgREVMRVRFX0xFQ1RVUkVfQ09ORklSTSA9IChsYWJlbCkgPT4gYNCf0L7RgtCy0YrRgNC00LXRgtC1INC40LfRgtGA0LjQstCw0L3QtdGC0L4g0L3QsCAke2xhYmVsfT9gO1xyXG5leHBvcnQgY29uc3QgVFJBSU5FUl9OT1RfQVNTSUdORURfTEFCRUwgPSAn0J3QtSDQtSDQt9Cw0LTQsNC00LXQvSDRgtGA0LXQudC90YrRgCc7XHJcbmV4cG9ydCBjb25zdCBUUkFJTkVSX0hFQURJTkcgPSAn0JvQtdC60YLQvtGAJztcclxuZXhwb3J0IGNvbnN0IEJVTEtfRURJVF9IRUFESU5HID0gJ9CT0YDRg9C/0L7QstC+INGA0LXQtNCw0LrRgtC40YDQsNC90LUnO1xyXG5cclxuZXhwb3J0IGNvbnN0IEFERF9FVkVOVF9CVVRUT04gPSAn0JTQvtCx0LDQstC4INGB0YrQsdC40YLQuNC1JztcclxuXHJcbmV4cG9ydCBjb25zdCBNVUxUSVBMRV9FVkVOVFNfTEFCRUwgPSBbJ9Ce0YLQutGA0LjRgtC4INGB0LAg0L3Rj9C60L7Qu9C60L4g0YHRitCx0LjRgtC40Y8sICcsICfQutC70LjQutC90LXRgtC1INC30LAg0L/QvtC30LLQvtC70LjRgtC1INGA0LXQtNCw0LrRhtC40Y8nXTtcclxuXHJcbmV4cG9ydCBjb25zdCBHUk9VUF9IRUFESU5HID0gJ9CT0YDRg9C/0LAnO1xyXG5leHBvcnQgY29uc3QgREFURV9IRUFESU5HID0gJ9CU0LDRgtCwJztcclxuZXhwb3J0IGNvbnN0IFNUQVJUX0hFQURJTkcgPSAn0J3QsNGH0LDQu9C+JztcclxuZXhwb3J0IGNvbnN0IEVORF9IRUFESU5HID0gJ9Ca0YDQsNC5JztcclxuZXhwb3J0IGNvbnN0IEhBTExfSEVBRElORyA9ICfQl9Cw0LvQsCc7XHJcblxyXG4vLyBFeGFtcyBUYWJcclxuXHJcbmV4cG9ydCBjb25zdCBSRUdVTEFSX0VYQU1TX0hFQURJTkcgPSAn0KDQtdC00L7QstC90Lgg0LjQt9C/0LjRgtC4JztcclxuZXhwb3J0IGNvbnN0IFJFVEFLRV9FWEFNU19IRUFESU5HID0gJ9Cf0L7Qv9GA0LDQstC40YLQtdC70L3QuCDQuNC30L/QuNGC0LgnO1xyXG5cclxuZXhwb3J0IGNvbnN0IE1JU1NJTkdfR1JPVVBfTEFCRUwgPSAn0J3Rj9C80LAg0LrQvtC90YTQuNCz0YPRgNC40YDQsNC90Lgg0LPRgNGD0L/QuCDQt9CwINC40LfQv9C40YLQsCc7XHJcblxyXG5leHBvcnQgY29uc3QgQUREX0VYQU1fUkVHVUxBUl9CVVRUT04gPSAn0KHRitC30LTQsNC5INGA0LXQtNC+0LLQtdC9INC40LfQv9C40YInO1xyXG5leHBvcnQgY29uc3QgQUREX0VYQU1fUkVUQUtFX0JVVFRPTiA9ICfQodGK0LfQtNCw0Lkg0L/QvtC/0YDQsNCy0LjRgtC10LvQtdC9INC40LfQv9C40YInO1xyXG5leHBvcnQgY29uc3QgTElOS19FWEFNX0JVVFRPTiA9ICfQodCy0YrRgNC20Lgg0YHRitGJ0LXRgdGC0LLRg9Cy0LDRiSDQuNC30L/QuNGCJztcclxuZXhwb3J0IGNvbnN0IEFERF9FWEFNX0dST1VQX0JVVFRPTiA9ICfQlNC+0LHQsNCy0Lgg0LPRgNGD0L/QsCc7XHJcbmV4cG9ydCBjb25zdCBWSUVXX0VOUk9MTEVEX0JVVFRPTiA9ICfQodC/0LjRgdGK0LonO1xyXG5cclxuZXhwb3J0IGNvbnN0IEdST1VQX1NFQVRTX0hFQURJTkcgPSAn0JzQtdGB0YLQsCc7XHJcblxyXG5leHBvcnQgY29uc3QgRVhBTV9UWVBFX0xBQkVMID0gJ9Ci0LjQvyDQvdCwINC40LfQv9C40YLQsCc7XHJcbmV4cG9ydCBjb25zdCBFWEFNX0RFU0tUT1BTX0xBQkVMID0gJ9Cd0LDRgdGC0L7Qu9C90Lgg0LrQvtC80L/RjtGC0YDQuCc7XHJcbmV4cG9ydCBjb25zdCBFWEFNX0FMTE9XX0FMTF9MQUJFTCA9ICfQl9CwINCy0YHQuNGH0LrQuCDQsiDQvtCx0YPRh9C10L3QuNC10YLQvic7XHJcbmV4cG9ydCBjb25zdCBFWEFNX0RFQURMSU5FX0xBQkVMID0gJ9Ch0YDQvtC6INC30LAg0LfQsNC/0LjRgdCy0LDQvdC1JztcclxuXHJcbmV4cG9ydCBjb25zdCBSRUxBVEVEX0lOU1RBTkNFU19MQUJFTCA9ICfQodCy0YrRgNC30LDQvdC4INC+0LHRg9GH0LXQvdC40Y8nO1xyXG5cclxuZXhwb3J0IGNvbnN0IFlFU19MQUJFTCA9ICfQlNCwJztcclxuZXhwb3J0IGNvbnN0IE5PX0xBQkVMID0gJ9Cd0LUnO1xyXG5cclxuZXhwb3J0IGNvbnN0IEVYQU1fTUlTU0lOR19ERUFETElORV9MQUJFTCA9ICfQndC1INC1INC90LDRgdGC0YDQvtC10L0nO1xyXG5cclxuZXhwb3J0IGNvbnN0IEVYQU1fVFlQRVMgPSB7XHJcbiAgICAnMCc6ICdOL0EnLFxyXG4gICAgJzEnOiAn0J/RgNCw0LrRgtC40YfQtdGB0LrQuCDQuNC30L/QuNGCJyxcclxuICAgICcyJzogJ9Cf0YDQvtC10LrRgicsXHJcbiAgICAnMyc6ICfQotC10YHRgtC+0LLQuCDQuNC30L/QuNGCJyxcclxuICAgICc0JzogJ9CQ0LLRgtC+0LzQsNGC0LjQt9C40YDQsNC90LAg0YHQuNGB0YLQtdC80LAnLFxyXG4gICAgJzUnOiAn0KPRgdGC0LXQvSDQuNC30L/QuNGCJ1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IExFQ1RVUkVfVFlQRVMgPSB7XHJcbiAgICAnMCc6ICdOL0EnLFxyXG4gICAgJzEnOiAn0KDQtdC00L7QstC10L0g0LjQt9C/0LjRgicsXHJcbiAgICAnMic6ICfQn9C+0L/RgNCw0LLQuNGC0LXQu9C10L0g0LjQt9C/0LjRgidcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IEVSUk9SX0RFRkFVTFRfTUVTU0FHRSA9ICfQk9GA0LXRiNC60LAg0L/RgNC4INC40LfQv9GK0LvQvdC10L3QuNC1LCDQstC40LbRgtC1INCyINC60L7QvdC30L7Qu9Cw0YLQsCDQt9CwINC/0L7QtNGA0L7QsdC90L7RgdGC0LgnO1xyXG5cclxuZXhwb3J0IGNvbnN0IFNBVkVfQlVUVE9OID0gJ9CX0LDQv9Cw0LfQuCc7XHJcbmV4cG9ydCBjb25zdCBDQU5DRUxfQlVUVE9OID0gJ9Ce0YLQutCw0LcnO1xyXG5leHBvcnQgY29uc3QgVU5MSU5LX0JVVFRPTiA9ICfQoNCw0LfQutCw0YfQuCDQuNC30L/QuNGC0LAnO1xyXG5leHBvcnQgY29uc3QgU0VBUkNIX0JVVFRPTiA9ICfQotGK0YDRgdC4JztcclxuXHJcbmV4cG9ydCBjb25zdCBFWEFNX05BTUVfVEVNUExBVEUgPSAoaW5zdGFuY2VOYW1lLCBkYXRlLCB0eXBlKSA9PiB7XHJcbiAgICBjb25zdCB0eXBlU3RyaW5nID0gdHlwZSA9PSAncmVndWxhcicgPyAn0YDQtdC00L7QstC10L0g0LjQt9C/0LjRgicgOiAn0L/QvtC/0YDQsNCy0LjRgtC10LvQtdC9L9C/0L7QstC40YjQuNGC0LXQu9C10L0g0LjQt9C/0LjRgic7XHJcbiAgICByZXR1cm4gYEV4YW06ICR7aW5zdGFuY2VOYW1lfSAtICR7dHlwZVN0cmluZ30gLSAke2RhdGV9YDtcclxufTtcclxuXHJcbi8vIFVzZXJzIFRhYlxyXG5cclxuZXhwb3J0IGNvbnN0IFBBUlRJQ0lQQVRJT05fVFlQRV9IRUFESU5HID0gJ9Ck0L7RgNC80LAnO1xyXG5leHBvcnQgY29uc3QgR1JBREVfSEVBRElORyA9ICfQntGG0LXQvdC60LAnO1xyXG5leHBvcnQgY29uc3QgUEFSVElDSVBBVElPTl9UWVBFUyA9IHtcclxuICAgICcwJzogJ9Cd0LDQsdC70Y7QtNCw0YLQtdC7JyxcclxuICAgICcxJzogJ9Ce0L3Qu9Cw0LnQvScsXHJcbiAgICAnMic6ICfQn9GA0LjRgdGK0YHRgtCy0LXQvdC+JyxcclxuICAgICczJzogJ9Cf0YDQuNGB0YrRgdGC0LLQtdC90L4g0YEg0LPQsNGA0LDQvdGC0LjRgNCw0L3QviDQvNGP0YHRgtC+JyxcclxuICAgICc0JzogJ9Cf0YDQuNGB0YrRgdGC0LLQtdC90L4g0YEg0L3QtdCz0LDRgNCw0L3RgtC40YDQsNC90L4g0LzRj9GB0YLQvicsXHJcbiAgICAnNSc6ICfQmNC30YfQsNC60LLQsNGJJyxcclxuICAgICc2JzogJ9Cb0LXQutGC0L7RgCcsXHJcbiAgICAnNyc6ICfQn9C+0LLQuNGI0LjRgtC10LvQtdC9INC40LfQv9C40YInLFxyXG4gICAgJzgnOiAn0J/QvtCy0LjRiNC40YLQtdC70LXQvSDQuNC30L/QuNGCIC0g0J3QlSDQptCf0J4nLFxyXG59O1xyXG5leHBvcnQgY29uc3QgUEFSVElDSVBBVElPTl9UWVBFU19DUEUgPSB7XHJcbiAgICAnMCc6ICfQntC90LvQsNC50L0nLFxyXG4gICAgJzEnOiAn0J7QvdC70LDQudC9JyxcclxuICAgICcyJzogJ9Cf0YDQuNGB0YrRgdGC0LLQtdC90L4nLFxyXG4gICAgJzMnOiAn0J/RgNC40YHRitGB0YLQstC10L3QvicsXHJcbiAgICAnNCc6ICfQn9GA0LjRgdGK0YHRgtCy0LXQvdC+JyxcclxuICAgICc1JzogJ9Ce0L3Qu9Cw0LnQvScsXHJcbiAgICAnNic6ICfQm9C10LrRgtC+0YAnLFxyXG4gICAgJzcnOiAn0J/QvtCy0LjRiNC40YLQtdC70LXQvSDQuNC30L/QuNGCJyxcclxuICAgICc4JzogJ9Cf0L7QstC40YjQuNGC0LXQu9C10L0g0LjQt9C/0LjRgiAtINCd0JUg0KbQn9CeJyxcclxufTtcclxuZXhwb3J0IGNvbnN0IEFMTF9GSUxURVJfSEVBRElORyA9ICfQktGB0LjRh9C60LgnO1xyXG5leHBvcnQgY29uc3QgUFJPRklMRV9CVVRUT04gPSAn0JLQuNC2INC/0YDQvtGE0LjQuyc7XHJcbmV4cG9ydCBjb25zdCBVU0VSTkFNRV9GSUxURVJfUExBQ0VIT0xERVIgPSAn0KTQuNC70YLRgNC40YDQsNC5INC/0L4g0L/QvtGC0YDQtdCx0LjRgtC10LvRgdC60L4g0LjQvNC1JztcclxuZXhwb3J0IGNvbnN0IE5BTUVfRklMVEVSX1BMQUNFSE9MREVSID0gJ9Ck0LjQu9GC0YDQuNGA0LDQuSDQv9C+INC40LzQtdC90LAnO1xyXG5leHBvcnQgY29uc3QgVFlQRV9GSUxURVJfVEVYVCA9ICfQl9Cw0LTRgNGK0LYgU0hJRlQg0LfQsCDQutC+0LzQsdC40L3QsNGG0LjRjyc7XHJcblxyXG5leHBvcnQgY29uc3QgU1RBVFNfVVNFUlNfTEFCRUwgPSAn0KDQtdC00L7QstC90Lgg0YHRgtGD0LTQtdC90YLQuCAo0L7QvdC70LDQudC9INC4INC/0YDQuNGB0YrRgdGC0LLQtdC90L4pOic7XHJcbmV4cG9ydCBjb25zdCBTVEFUU19BVkdfR1JBREVfTEFCRUwgPSAn0KHRgNC10LTQtdC9INGD0YHQv9C10YU6JztcclxuZXhwb3J0IGNvbnN0IFNUQVRTX0NFUlRJRklFRF9MQUJFTCA9ICfQodC10YDRgtC40YTQuNGG0LjRgNCw0L3QuDonO1xyXG5leHBvcnQgY29uc3QgU1RBVFNfRkFJTEVEX0xBQkVMID0gJ9Ch0LrRitGB0LDQvdC4Oic7XHJcbmV4cG9ydCBjb25zdCBTVEFUU19NSVNTSU5HX0xBQkVMID0gJ9Cg0LXQtNC+0LLQvdC4INGB0YLRg9C00LXQvdGC0Lgg0LHQtdC3INC+0YbQtdC90LrQsDonO1xyXG5cclxuZXhwb3J0IGNvbnN0IFNUQVRTX0hFQURJTkcgPSAn0KHRgtCw0YLQuNGB0YLQuNC60LAnO1xyXG5leHBvcnQgY29uc3QgTElTVF9IRUFESU5HID0gJ9Ch0L/QuNGB0YrQuic7XHJcblxyXG5leHBvcnQgY29uc3QgTElWRVNUUkVBTV9NSVNDT05GSUdfTEFCRUwgPSAn0KDQsNC30LzQuNC90LDQstCw0L3QtSDQsiDQutC+0L3RhNC40LPRg9GA0LDRhtC40Y/RgtCwINC90LAg0LrQsNC70LXQvdC00LDRgCDQuCDQu9Cw0LnQstGB0YLRgNC40LnQvCc7XHJcbmV4cG9ydCBjb25zdCBFWFBPUlRfVVNFUlNfQlVUVE9OID0gJ9Ch0LLQsNC70Lgg0YHQv9C40YHRitC60LAnO1xyXG5leHBvcnQgY29uc3QgRklMVEVSX1VTRVJTX0JVVFRPTiA9ICfQpNC40LvRgtGA0LjRgNCw0Lkg0L/QviDRgdC/0LjRgdGK0LonO1xyXG5leHBvcnQgY29uc3QgRklMVEVSX1VTRVJTX1RFWFQgPSAn0JjQt9Cx0LXRgNC10YLQtSBYTFNYINGE0LDQudC7LCDRgdGK0LTRitGA0LbQsNGJINGB0L/QuNGB0YrQuiDRgSDQv9C+0YLRgNC10LHQuNGC0LXQu9GB0LrQuCDQuNC80LXQvdCwJztcclxuXHJcbmV4cG9ydCBjb25zdCB0eXBlTGFiZWxzID0ge1xyXG4gICAgJzEnOiAnb25saW5lJyxcclxuICAgICcyJzogJ3NpdGUnLFxyXG4gICAgJzMnOiAnc2l0ZScsXHJcbiAgICAnNCc6ICdzaXRlJyxcclxuICAgICc2JzogJ3RlYW0nLFxyXG59OyIsImltcG9ydCBkb20sIHsgRnJhZ21lbnQgfSBmcm9tICcuLi91dGlsL2pzeC1yZW5kZXItbW9kL2RvbSc7XHJcbmltcG9ydCB7IGNyZWF0ZU1vZGFsIH0gZnJvbSAnLi4vY29tbW9uL01vZGFsJztcclxuaW1wb3J0IHsgcmVkaXJlY3QgfSBmcm9tICcuLi91dGlsL3JvdXRlcic7XHJcbmltcG9ydCB7IFllcywgTm8sIHN3YXAsIGdldEVkaXRvckRlY29yYXRpb24gfSBmcm9tICcuLi91dGlsL3RlbXBsYXRlJztcclxuaW1wb3J0IHsgY3JlYXRlVGVtcGxhdGVNb2RlbCwgc2F2ZVRlbXBsYXRlIH0gZnJvbSAnLi9kYXRhJztcclxuaW1wb3J0IFByZXZpZXcsIHsgZmllbGRzLCBmaWVsZE1ldGEsIGludGVycHJldCB9IGZyb20gJy4vUHJldmlldyc7XHJcbmltcG9ydCB7IHdpdGhQcm9ncmVzcyB9IGZyb20gJy4uL3V0aWwvdXRpbCc7XHJcbmltcG9ydCB7IHF1ZXJ5U3RyaW5nIH0gZnJvbSAnLi4vdXRpbC9wYXJzZSc7XHJcbmltcG9ydCB7IGNyZWF0ZUFzc2lnbkRpYWxvZyB9IGZyb20gJy4uL2NvdXJzZS9nZW5lcmFsL0Rlc2NyaXB0aW9uJztcclxuXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBFZGl0b3IoeyB0aXRsZSwgY29uZmlnLCB0ZW1wbGF0ZXMsIGlkLCBhcGksIGluVGVtcGxhdGUsIGluc3RhbmNlRGF0YSwgY29udGV4dCB9KSB7XHJcbiAgICBjb25zdCB0ZW1wbGF0ZSA9IGluVGVtcGxhdGUgfHwgKGlkID8gdGVtcGxhdGVzLmZpbmQodCA9PiB0LklkID09IGlkKSA6IGNyZWF0ZVRlbXBsYXRlTW9kZWwoKSk7XHJcblxyXG4gICAgY29uc3QgaW5wdXQgPSB7XHJcbiAgICAgICAgbmFtZTogPGlucHV0IHR5cGU9XCJ0ZXh0XCIgY2xhc3NOYW1lPVwic2VzLXdpZGUtaW5wdXRcIiB2YWx1ZT17dGVtcGxhdGUuTmFtZX0gLz4sXHJcbiAgICAgICAgY29tcG91bmQ6IDxpbnB1dCBjbGFzc05hbWU9XCJzZXMtY2hlY2tcIiB0eXBlPVwiY2hlY2tib3hcIiAvPixcclxuICAgICAgICBhY3RpdmU6IDxpbnB1dCBjbGFzc05hbWU9XCJzZXMtY2hlY2tcIiB0eXBlPVwiY2hlY2tib3hcIiAvPixcclxuICAgICAgICBjYXRlZ29yaWVzOiBPYmplY3QuZW50cmllcyhjb25maWcuY2F0ZWdvcmllcylcclxuICAgICAgICAgICAgLm1hcCgoW2ssIHZdKSA9PiBbaywgW3YsIDxpbnB1dCBjbGFzc05hbWU9XCJzZXMtY2hlY2tcIiB0eXBlPVwiY2hlY2tib3hcIiB2YWx1ZT17a30gLz5dXSksXHJcbiAgICAgICAgY29udGVudDogPHRleHRhcmVhPnt0ZW1wbGF0ZS5Db250ZW50fTwvdGV4dGFyZWE+XHJcbiAgICB9O1xyXG5cclxuICAgIGxldCBwcmV2aWV3ID0gPFByZXZpZXcgY29udGVudD17dGVtcGxhdGUuQ29udGVudH0gdGVtcGxhdGVzPXt0ZW1wbGF0ZXN9IGluc3RhbmNlRGF0YT17aW5zdGFuY2VEYXRhfSAvPjtcclxuXHJcbiAgICBpbnB1dC5jb21wb3VuZC5jaGVja2VkID0gdGVtcGxhdGUuQ29tcG91bmQ7XHJcbiAgICBpbnB1dC5hY3RpdmUuY2hlY2tlZCA9IHRlbXBsYXRlLkFjdGl2ZTtcclxuICAgIGlucHV0LmNhdGVnb3JpZXMuZm9yRWFjaCgoW2ssIFtsYWJlbCwgZmllbGRdXSkgPT4gZmllbGQuY2hlY2tlZCA9IHRlbXBsYXRlLkNhdGVnb3J5LmluY2x1ZGVzKGspKTtcclxuXHJcbiAgICBjb25zdCBlZGl0b3IgPSAoPGRpdiBjbGFzc05hbWU9XCJzZXMtdGFibGUtZWRpdG9yXCI+XHJcblxyXG4gICAgICAgIHtjcmVhdGVDb250cm9scygpfVxyXG5cclxuICAgICAgICB7aW5UZW1wbGF0ZSA9PSB1bmRlZmluZWQgJiYgKDxkaXYgY2xhc3NOYW1lPVwic2VzLWNsZWFyXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VzLXRlbXBsYXRlLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICA8aDM+0J7QsdGJ0LAg0LjQvdGE0L7RgNC80LDRhtC40Y88L2gzPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInNlcy10ZW1wbGF0ZS1sYWJlbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNlcy1sYWJlbFwiPtCY0LzQtTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICB7aW5wdXQubmFtZX1cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwic2VzLXRlbXBsYXRlLWxhYmVsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2lucHV0LmNvbXBvdW5kfVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPtCm0Y/Qu9C+0YHRgtC10L0g0YjQsNCx0LvQvtC9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJzZXMtdGVtcGxhdGUtbGFiZWxcIj5cclxuICAgICAgICAgICAgICAgICAgICB7aW5wdXQuYWN0aXZlfVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPtCQ0LrRgtGD0LDQu9C10L08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXMtdGVtcGxhdGUtZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgIDxoMz7QmtCw0YLQtdCz0L7RgNC40Y88L2gzPlxyXG4gICAgICAgICAgICAgICAge2lucHV0LmNhdGVnb3JpZXMubWFwKChbaywgW2xhYmVsLCBmaWVsZF1dKSA9PiAoPGxhYmVsIGNsYXNzTmFtZT1cInNlcy10ZW1wbGF0ZS1sYWJlbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmaWVsZH1cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj57bGFiZWx9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD4pKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+KX1cclxuXHJcbiAgICAgICAgezxDb250ZW50RWRpdG9yIGNvbnRlbnRGaWVsZD17aW5wdXQuY29udGVudH0gcmVnZW5lcmF0ZVByZXZpZXc9e3JlZ2VuZXJhdGVQcmV2aWV3fSB0ZW1wbGF0ZXM9e3RlbXBsYXRlc30gY2F0ZWdvcmllcz17Y29uZmlnLmNhdGVnb3JpZXN9IC8+fVxyXG5cclxuICAgICAgICB7Y3JlYXRlQ29udHJvbHMoKX1cclxuXHJcbiAgICA8L2Rpdj4pO1xyXG5cclxuICAgIGNvbnN0IGRlY29yYXRpb24gPSBnZXRFZGl0b3JEZWNvcmF0aW9uKGVkaXRvcik7XHJcblxyXG4gICAgcmV0dXJuICg8RnJhZ21lbnQ+XHJcbiAgICAgICAgPGgyPnt0aXRsZSB8fCAn0KHRitC30LTQsNCy0LDQvdC1INC90LAg0L3QvtCyINGI0LDQsdC70L7QvSd9PC9oMj5cclxuXHJcbiAgICAgICAge2VkaXRvcn1cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXMtY2xlYXJcIj5cclxuICAgICAgICAgICAgPGgzPtCf0YDQtdCz0LvQtdC0PC9oMz5cclxuICAgICAgICAgICAgPHAgc3R5bGU9e3sgZm9udFN0eWxlOiAnaXRhbGljJyB9fT7Ql9Cw0LHQtdC70LXQttC60LA6INCy0YrQt9C80L7QttC90L4g0LUg0LTQsCDQuNC80LAg0YHRgtC40LvQuNGB0YLQuNGH0L3QuCDRgNCw0LfQu9C40LrQuCDQvNC10LbQtNGDINGC0L7Qt9C4INC40LfQs9C70LXQtCDQuCDRgdGC0YDQsNC90LjRhtCw0YLQsCDQvdCwINC60YPRgNGB0LAuPC9wPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlcy10ZW1wbGF0ZS1wcmV2aWV3XCI+XHJcbiAgICAgICAgICAgICAgICB7cHJldmlld31cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgPC9GcmFnbWVudCA+KTtcclxuXHJcbiAgICBmdW5jdGlvbiByZWdlbmVyYXRlUHJldmlldygpIHtcclxuICAgICAgICBwcmV2aWV3ID0gc3dhcChwcmV2aWV3LCA8UHJldmlldyBjb250ZW50PXtpbnB1dC5jb250ZW50LnZhbHVlfSB0ZW1wbGF0ZXM9e3RlbXBsYXRlc30gaW5zdGFuY2VEYXRhPXtpbnN0YW5jZURhdGF9IC8+KTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBjcmVhdGVDb250cm9scygpIHtcclxuICAgICAgICByZXR1cm4gKDxkaXYgY2xhc3NOYW1lPVwic2VzLWNsZWFyXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VzLXRlbXBsYXRlLWdyb3VwIHNlcy10ZW1wbGF0ZS1kaXZcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17b25TYXZlfT48WWVzIC8+INCX0LDQv9Cw0LfQuDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtnb0JhY2t9PjxObyAvPiDQntGC0LrQsNC3PC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2Pik7XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gZ29CYWNrKCkge1xyXG4gICAgICAgIGlmIChpblRlbXBsYXRlKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGNvdXJzZUlkID0gcXVlcnlTdHJpbmcoZG9jdW1lbnQubG9jYXRpb24uc2VhcmNoKS5jb3Vyc2VJZDtcclxuICAgICAgICAgICAgcmVkaXJlY3QoYD9jb3Vyc2VJZD0ke2NvdXJzZUlkfSZpbnN0YW5jZUlkPSR7dGVtcGxhdGUuSW5zdGFuY2VJZH0mdGFiPWdlbmVyYWxgKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZWRpcmVjdCgnPycpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBvblNhdmUoKSB7XHJcbiAgICAgICAgY29uc3QgZXhpc3RpbmdOYW1lID0gdGVtcGxhdGVzLmZpbHRlcih0ID0+IHQuTmFtZSA9PSBpbnB1dC5uYW1lLnZhbHVlKTtcclxuXHJcbiAgICAgICAgaWYgKGV4aXN0aW5nTmFtZS5sZW5ndGggPiAwICYmIGV4aXN0aW5nTmFtZVswXS5JZCAhPSB0ZW1wbGF0ZS5JZCkge1xyXG4gICAgICAgICAgICByZXR1cm4gYWxlcnQoJ9CS0LXRh9C1INGB0YrRidC10YHRgtCy0YPQstCwINGI0LDQsdC70L7QvSDRgSDRgtC+0LLQsCDQuNC80LUnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IHVzZWRCeSA9IHRlbXBsYXRlcy5maWx0ZXIodCA9PiB0LkNvbnRlbnQuaW5jbHVkZXMoYFtbUmVmPSR7dGVtcGxhdGUuTmFtZX1dXWApKTtcclxuICAgICAgICBjb25zdCBuYW1lQ2hhbmdlZCA9IHRlbXBsYXRlLk5hbWUgIT0gaW5wdXQubmFtZS52YWx1ZTtcclxuICAgICAgICBpZiAobmFtZUNoYW5nZWQgJiYgdXNlZEJ5Lmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgY29uc3QgW2Nob2ljZXMsIGNob2ljZVByb21pc2VdID0gY3JlYXRlQ2hvaWNlcyh1c2VkQnkpO1xyXG4gICAgICAgICAgICBjb25zdCBtb2RhbCA9IGNyZWF0ZU1vZGFsKCfQntC/0LjRgtCy0LDRgtC1INGB0LUg0LTQsCDQv9GA0L7QvNC10L3QuNGC0LUg0LjQvNC10YLQviDQvdCwINGI0LDQsdC70L7QvSwg0LrQvtC50YLQviDRgdC1INC40LfQv9C+0LvQt9Cy0LAg0LIg0YHQu9C10LTQvdC40YLQtSDQtNGA0YPQs9C4INGI0LDQsdC70L7QvdC4OicsIGNob2ljZXMpO1xyXG5cclxuICAgICAgICAgICAgY29uc3QgY2hvaWNlID0gYXdhaXQgY2hvaWNlUHJvbWlzZTtcclxuICAgICAgICAgICAgbW9kYWwuY2xvc2UoKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChjaG9pY2UgPT0gJ3NraXAnKSB7XHJcbiAgICAgICAgICAgICAgICBzYXZlQ3VycmVudCgpO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKGNob2ljZSA9PSAndXBkYXRlJykge1xyXG4gICAgICAgICAgICAgICAgc2F2ZUFsbCgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgc2F2ZUN1cnJlbnQoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGFzeW5jIGZ1bmN0aW9uIHNhdmVDdXJyZW50KCkge1xyXG4gICAgICAgICAgICBjb25zdCBkYXRhID0ge1xyXG4gICAgICAgICAgICAgICAgSWQ6IHRlbXBsYXRlLklkLFxyXG4gICAgICAgICAgICAgICAgTmFtZTogaW5wdXQubmFtZS52YWx1ZSxcclxuICAgICAgICAgICAgICAgIENhdGVnb3J5OiBpbnB1dC5jYXRlZ29yaWVzLmZpbHRlcihjID0+IGNbMV1bMV0uY2hlY2tlZCkubWFwKGMgPT4gY1swXSksXHJcbiAgICAgICAgICAgICAgICBBY3RpdmU6IGlucHV0LmFjdGl2ZS5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgQ29tcG91bmQ6IGlucHV0LmNvbXBvdW5kLmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICBDb250ZW50OiBpbnB1dC5jb250ZW50LnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgSW5zdGFuY2VJZDogdGVtcGxhdGUuSW5zdGFuY2VJZFxyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgY29uc3QgY3VycmVudElucHV0cyA9IFsuLi5lZGl0b3IucXVlcnlTZWxlY3RvckFsbCgnaW5wdXQsIGJ1dHRvbiwgdGV4dGFyZWEnKV0uZmlsdGVyKG4gPT4gbi5kaXNhYmxlZCAhPSB0cnVlKTtcclxuICAgICAgICAgICAgY3VycmVudElucHV0cy5mb3JFYWNoKG4gPT4gbi5kaXNhYmxlZCA9IHRydWUpO1xyXG4gICAgICAgICAgICBkZWNvcmF0aW9uLndvcmtpbmcoKTtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHNhdmVUZW1wbGF0ZShhcGksIGRhdGEpO1xyXG4gICAgICAgICAgICAgICAgZGVjb3JhdGlvbi51cGRhdGVkKCk7XHJcbiAgICAgICAgICAgICAgICBpZiAoY29udGV4dCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRleHQub24oJ0Rlc2NyaXB0aW9uVXBkYXRlZCcsIGdvQmFjayk7XHJcbiAgICAgICAgICAgICAgICAgICAgY29udGV4dC5lbWl0KCdUZW1wbGF0ZVVwZGF0ZWQnLCBpbnRlcnByZXQoZGF0YS5Db250ZW50LCB0ZW1wbGF0ZXMsIGluc3RhbmNlRGF0YSkpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBnb0JhY2soKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgICAgICBkZWNvcmF0aW9uLmZhaWx1cmUoKTtcclxuICAgICAgICAgICAgICAgIGFsZXJ0KGVyci5tZXNzYWdlKTtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgICAgICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICAgICAgICAgIGN1cnJlbnRJbnB1dHMuZm9yRWFjaChuID0+IG4uZGlzYWJsZWQgPSBmYWxzZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGFzeW5jIGZ1bmN0aW9uIHNhdmVBbGwoKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IFtvbGROYW1lLCBuZXdOYW1lXSA9IFt0ZW1wbGF0ZS5OYW1lLCBpbnB1dC5uYW1lLnZhbHVlXTtcclxuICAgICAgICAgICAgY29uc3QgbWF0Y2hlciA9IG5ldyBSZWdFeHAoYFxcXFxbXFxcXFtSZWY9JHtvbGROYW1lfVxcXFxdXFxcXF1gLCAnZycpO1xyXG4gICAgICAgICAgICB1c2VkQnkuZm9yRWFjaCh0ID0+IHQuQ29udGVudCA9IHQuQ29udGVudC5yZXBsYWNlKG1hdGNoZXIsIGBbW1JlZj0ke25ld05hbWV9XV1gKSk7XHJcblxyXG4gICAgICAgICAgICBjb25zdCB3aWR0aCA9IDUwMDtcclxuICAgICAgICAgICAgY29uc3QgcGVyY2VudCA9IDxzcGFuPjAlPC9zcGFuPjtcclxuICAgICAgICAgICAgY29uc3QgYmFyID0gPHNwYW4gc3R5bGU9e3sgcGFkZGluZzogJzAgMC41ZW0nLCBkaXNwbGF5OiAnaW5saW5lLWJsb2NrJywgd2lkdGg6IHdpZHRoICsgJ3B4JywgYmFja2dyb3VuZDogJ2xpbmVhci1ncmFkaWVudCh0byByaWdodCwgI2ZmYTAwMCAwJSwgI2VlZSAwKScgfX0+e3BlcmNlbnR9Jm5ic3A7V29ya2luZyZoZWxsaXA7PC9zcGFuPjtcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IHByb2dyZXNzTW9kYWwgPSBjcmVhdGVNb2RhbCgn0J7QsdC90L7QstGP0LLQsNC90LUg0L3QsCDRiNCw0LHQu9C+0L3QuCwg0L3QtSDQt9Cw0YLQstCw0YDRj9C50YLQtSDRgdGC0YDQsNC90LjRhtCw0YLQsCcsIGJhciwgZmFsc2UpO1xyXG5cclxuICAgICAgICAgICAgYXdhaXQgd2l0aFByb2dyZXNzKHVzZWRCeS5tYXAodCA9PiBzYXZlVGVtcGxhdGUoYXBpLCB0KSksIG9uQ2hhbmdlLCAxMDApO1xyXG5cclxuICAgICAgICAgICAgcHJvZ3Jlc3NNb2RhbC5jbG9zZSgpO1xyXG5cclxuICAgICAgICAgICAgYXdhaXQgc2F2ZUN1cnJlbnQoKTtcclxuXHJcbiAgICAgICAgICAgIGZ1bmN0aW9uIG9uQ2hhbmdlKHJlcywgaW5kZXgsIHJlc29sdmVkLCB0b3RhbCkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcHJvZ3Jlc3MgPSBNYXRoLmZsb29yKHJlc29sdmVkIC8gdG90YWwgKiAxMDApO1xyXG4gICAgICAgICAgICAgICAgcGVyY2VudC50ZXh0Q29udGVudCA9IHByb2dyZXNzICsgJyUnO1xyXG4gICAgICAgICAgICAgICAgYmFyLnN0eWxlLmJhY2tncm91bmQgPSBgbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZmZhMDAwICR7cHJvZ3Jlc3N9JSwgI2VlZSAwKWA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIENvbnRlbnRFZGl0b3IoeyBjb250ZW50RmllbGQsIHJlZ2VuZXJhdGVQcmV2aWV3LCB0ZW1wbGF0ZXMsIGNhdGVnb3JpZXMgfSkge1xyXG4gICAgcmV0dXJuICg8ZGl2IGNsYXNzTmFtZT1cInNlcy1jbGVhclwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VzLXRlbXBsYXRlLWdyb3VwIHNlcy10ZW1wbGF0ZS1kaXZcIj5cclxuICAgICAgICAgICAgPGgzPtCh0YrQtNGK0YDQttCw0L3QuNC1PC9oMz5cclxuXHJcbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gY3JlYXRlQXNzaWduRGlhbG9nKGNhdGVnb3JpZXMsIHRlbXBsYXRlcywgaW5zZXJ0RnJhZ21lbnQsIHRydWUpfT48aSBjbGFzcz1cImdseXBoaWNvbiBnbHlwaGljb24tbGlua1wiPjwvaT4g0JLRitCy0LXQtNC4INGE0YDQsNCz0LzQtdC90YI8L2J1dHRvbj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxoND7QmNC30YfQuNGB0LvQtdC90Lgg0L/QvtC70LXRgtCwPC9oND5cclxuICAgICAgICAgICAgICAgIHtGaWVsZEdyb3VwcyhmaWVsZE1ldGEsIGluc2VydEZpZWxkKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7Y29udGVudEZpZWxkfVxyXG5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17cmVnZW5lcmF0ZVByZXZpZXd9PjxpIGNsYXNzPVwiZ2x5cGhpY29uIGdseXBoaWNvbi1yZWZyZXNoXCI+PC9pPiDQn9GA0LXQs9C70LXQtNCw0Lk8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj4pO1xyXG5cclxuICAgIGZ1bmN0aW9uIGluc2VydEZyYWdtZW50KHRlbXBsYXRlKSB7XHJcbiAgICAgICAgY29udGVudEZpZWxkLnZhbHVlID0gYCR7Y29udGVudEZpZWxkLnZhbHVlLnNsaWNlKDAsIGNvbnRlbnRGaWVsZC5zZWxlY3Rpb25TdGFydCl9W1tSZWY9JHt0ZW1wbGF0ZS5OYW1lfV1dJHtjb250ZW50RmllbGQudmFsdWUuc2xpY2UoY29udGVudEZpZWxkLnNlbGVjdGlvbkVuZCl9YDtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBpbnNlcnRGaWVsZChmaWVsZCkge1xyXG4gICAgICAgIGNvbnRlbnRGaWVsZC52YWx1ZSA9IGAke2NvbnRlbnRGaWVsZC52YWx1ZS5zbGljZSgwLCBjb250ZW50RmllbGQuc2VsZWN0aW9uU3RhcnQpfVtbJHtmaWVsZH1dXSR7Y29udGVudEZpZWxkLnZhbHVlLnNsaWNlKGNvbnRlbnRGaWVsZC5zZWxlY3Rpb25FbmQpfWA7XHJcbiAgICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIEZpZWxkR3JvdXBzKG1ldGEsIGluc2VydEZpZWxkKSB7XHJcbiAgICBjb25zdCBncm91cHMgPSBPYmplY3RcclxuICAgICAgICAuZW50cmllcyhtZXRhKVxyXG4gICAgICAgIC5yZWR1Y2UoKHAsIFtmLCBjXSkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBhcnIgPSBwW2MuZ3JvdXBdIHx8IFtdO1xyXG4gICAgICAgICAgICBhcnIucHVzaCh7XHJcbiAgICAgICAgICAgICAgICBtYXRjaDogZixcclxuICAgICAgICAgICAgICAgIG5hbWU6IGMubmFtZVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgcmV0dXJuIE9iamVjdC5hc3NpZ24ocCwgeyBbYy5ncm91cF06IGFyciB9KTtcclxuICAgICAgICB9LCB7fSk7XHJcblxyXG4gICAgY29uc3QgZWxlbWVudHMgPSBPYmplY3RcclxuICAgICAgICAuZW50cmllcyhncm91cHMpXHJcbiAgICAgICAgLm1hcCgoW25hbWUsIGZdKSA9PiAoPGRpdiBjbGFzc05hbWU9XCJzZXMtdGVtcGxhdGVzLWZpZWxkR3JvdXBcIj5cclxuICAgICAgICAgICAgPHNwYW4+e25hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICB7Zi5tYXAoRmllbGRCdXR0b24uYmluZChudWxsLCBpbnNlcnRGaWVsZCkpfVxyXG4gICAgICAgIDwvZGl2PikpO1xyXG5cclxuICAgIHJldHVybiBlbGVtZW50cztcclxufVxyXG5cclxuZnVuY3Rpb24gRmllbGRCdXR0b24oaW5zZXJ0RmllbGQsIGZpZWxkKSB7XHJcbiAgICByZXR1cm4gPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBpbnNlcnRGaWVsZChmaWVsZC5tYXRjaCl9PntmaWVsZC5uYW1lfTwvYnV0dG9uPjtcclxufVxyXG5cclxuZnVuY3Rpb24gY3JlYXRlQ2hvaWNlcyh1c2VkQnkpIHtcclxuICAgIGxldCBvdXRSZXNvbHZlID0gKCkgPT4geyB9O1xyXG5cclxuICAgIHJldHVybiBbKDxGcmFnbWVudD5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlcy1zY3JvbGxcIj5cclxuICAgICAgICAgICAgPHRhYmxlPlxyXG4gICAgICAgICAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoPtCY0LzQtTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aD7QptGP0LvQvtGB0YLQtdC9PC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoPtCQ0LrRgtGD0LDQu9C10L08L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgIHt1c2VkQnkubWFwKHQgPT4gKDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkPnt0Lk5hbWV9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkPnt0LkNvbXBvdW5kID8gPFllcyAvPiA6IDxObyAvPn08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQ+e3QuQWN0aXZlID8gPFllcyAvPiA6IDxObyAvPn08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdHI+KSl9XHJcbiAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8dGFibGU+XHJcbiAgICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJzZXMtbW9kYWwtYWN0aXZlXCIgb25DbGljaz17dXBkYXRlfT48dGQ+PFllcyAvPjwvdGQ+PHRkPtCe0LHQvdC+0LLQuCDQt9Cw0YHQtdCz0L3QsNGC0LjRgtC1INGI0LDQsdC70L7QvdC4INGBINC90L7QstC+0YLQviDQuNC80LU8L3RkPjwvdHI+XHJcbiAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwic2VzLW1vZGFsLWFjdGl2ZVwiIG9uQ2xpY2s9e3NraXB9Pjx0ZD48aSBjbGFzcz1cImdseXBoaWNvbiBnbHlwaGljb24td2FybmluZy1zaWduXCI+PC9pPjwvdGQ+PHRkPtCX0LDQv9Cw0LfQuCDQv9GA0L7QvNC10L3QuNGC0LUg0LHQtdC3INC00LAg0L7QsdC90L7QstGP0LLQsNGIINC00YDRg9Cz0LjRgtC1INGI0LDQsdC70L7QvdC4PC90ZD48L3RyPlxyXG4gICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cInNlcy1tb2RhbC1hY3RpdmVcIiBvbkNsaWNrPXtjYW5jZWx9Pjx0ZD48Tm8gLz48L3RkPjx0ZD7QktGK0YDQvdC4INGB0LUg0LIg0YDQtdC00LDQutGC0L7RgNCwPC90ZD48L3RyPlxyXG4gICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgIDwvdGFibGU+XHJcbiAgICA8L0ZyYWdtZW50PiksIG5ldyBQcm9taXNlKHJlc29sdmUgPT4ge1xyXG4gICAgICAgIG91dFJlc29sdmUgPSByZXNvbHZlO1xyXG4gICAgfSldO1xyXG5cclxuICAgIGZ1bmN0aW9uIHNraXAoKSB7XHJcbiAgICAgICAgb3V0UmVzb2x2ZSgnc2tpcCcpO1xyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIHVwZGF0ZSgpIHtcclxuICAgICAgICBvdXRSZXNvbHZlKCd1cGRhdGUnKTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBjYW5jZWwoKSB7XHJcbiAgICAgICAgb3V0UmVzb2x2ZSgnY2FuY2VsJyk7XHJcbiAgICB9XHJcbn0iLCJpbXBvcnQgZG9tIGZyb20gJy4uL3V0aWwvanN4LXJlbmRlci1tb2QvZG9tJztcclxuaW1wb3J0IHsgZm9ybWF0RGF0ZSwgZm9ybWF0TG9jYWxlRGF0ZSwgZm9ybWF0TG9jYWxlV2Vla2RheSwgZm9ybWF0VGltZSB9IGZyb20gJy4uL3V0aWwvcGFyc2UnO1xyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFByZXZpZXcoeyBjb250ZW50LCB0ZW1wbGF0ZXMsIGluc3RhbmNlRGF0YSB9KSB7XHJcbiAgICBjb25zdCBob2xkZXIgPSA8c2VjdGlvbiBjbGFzcz1cImluc3RhbmNlLW92ZXJ2aWV3LXNlY3Rpb25cIj48L3NlY3Rpb24+O1xyXG5cclxuICAgIGNvbnN0IHBhcnNpbmdFcnJvcnMgPSBbXTtcclxuXHJcbiAgICBob2xkZXIuaW5uZXJIVE1MID0gaW50ZXJwcmV0KGNvbnRlbnQsIHRlbXBsYXRlcywgaW5zdGFuY2VEYXRhLCBwYXJzaW5nRXJyb3JzKTtcclxuXHJcbiAgICByZXR1cm4gKDxkaXYgY2xhc3NOYW1lPVwicGFnZS13cmFwcGVyXCIgc3R5bGU9e3sgbWluSGVpZ2h0OiAnMCcsIGJhY2tncm91bmRDb2xvcjogJ3doaXRlJyB9fT5cclxuICAgICAgICB7cGFyc2luZ0Vycm9ycy5tYXAoZSA9PiA8ZGl2IGNsYXNzTmFtZT1cInNlcy10ZW1wbGF0ZXMtcGFyc2VFcnJvclwiPjxpIGNsYXNzPVwiZ2x5cGhpY29uIGdseXBoaWNvbi1hbGVydFwiPjwvaT4ge2V9PC9kaXY+KX1cclxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJpbnN0YW5jZVwiIHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogJzAnIH19PlxyXG4gICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJyZWRlc2lnbmVkLWluc3RhbmNlLWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgICAgICAge2hvbGRlcn1cclxuICAgICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgIDwvZGl2Pik7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBpbnRlcnByZXQoY29udGVudCwgdGVtcGxhdGVzLCBpbnN0YW5jZURhdGEsIG91dEVycm9ycyA9IFtdKSB7XHJcbiAgICAvLyBSZWZlcmVuY2VzIGNvbnRhaW5pbmcgY2hpbGQgdGV4dFxyXG4gICAgY29uc3QgY2hpbGRNYXRjaGVyID0gL1xcW1xcW1JlZj0oLis/KVxcXVxcXSguKz8pXFxbXFxbXFwvUmVmXFxdXFxdL2dtcztcclxuICAgIGxldCBjaGlsZE1hdGNoO1xyXG5cclxuICAgIHdoaWxlICgoY2hpbGRNYXRjaCA9IGNoaWxkTWF0Y2hlci5leGVjKGNvbnRlbnQpKSAhPSBudWxsKSB7XHJcbiAgICAgICAgY29uc3QgcmVmTmFtZSA9IGNoaWxkTWF0Y2hbMV07XHJcbiAgICAgICAgY29uc3QgY2hpbGRyZW4gPSBjaGlsZE1hdGNoWzJdO1xyXG4gICAgICAgIGNvbnN0IHJlZmVyZW5jZSA9IHRlbXBsYXRlcy5maW5kKHQgPT4gdC5OYW1lID09IHJlZk5hbWUpO1xyXG4gICAgICAgIGNvbnN0IGludGVycG9sYXRlZCA9IHJlZmVyZW5jZS5Db250ZW50LnJlcGxhY2UoJ1tbQ29udGVudF1dJywgY2hpbGRyZW4pO1xyXG4gICAgICAgIGlmIChyZWZlcmVuY2UpIHtcclxuICAgICAgICAgICAgY29udGVudCA9IGNvbnRlbnQuc3Vic3RyaW5nKDAsIGNoaWxkTWF0Y2guaW5kZXgpICsgaW50ZXJwcmV0KGludGVycG9sYXRlZCwgdGVtcGxhdGVzLCBpbnN0YW5jZURhdGEpICsgY29udGVudC5zdWJzdHJpbmcoY2hpbGRNYXRjaC5pbmRleCArIGNoaWxkTWF0Y2hbMF0ubGVuZ3RoKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBvdXRFcnJvcnMucHVzaChg0J3QtSDQsdC10YjQtSDQvtGC0LrRgNC40YIg0YTRgNCw0LPQvNC10L3RgiBcIiR7cmVmTmFtZX1cImApO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyBGcmFnbWVudHNcclxuICAgIGNvbnN0IHJlZk1hdGNoZXIgPSAvXFxbXFxbUmVmPSguKz8pXFxdXFxdL2c7XHJcbiAgICBsZXQgbWF0Y2g7XHJcblxyXG4gICAgd2hpbGUgKChtYXRjaCA9IHJlZk1hdGNoZXIuZXhlYyhjb250ZW50KSkgIT0gbnVsbCkge1xyXG4gICAgICAgIGNvbnN0IHJlZk5hbWUgPSBtYXRjaFsxXTtcclxuICAgICAgICBjb25zdCByZWZlcmVuY2UgPSB0ZW1wbGF0ZXMuZmluZCh0ID0+IHQuTmFtZSA9PSByZWZOYW1lKTtcclxuICAgICAgICBpZiAocmVmZXJlbmNlKSB7XHJcbiAgICAgICAgICAgIGNvbnRlbnQgPSBjb250ZW50LnN1YnN0cmluZygwLCBtYXRjaC5pbmRleCkgKyBpbnRlcnByZXQocmVmZXJlbmNlLkNvbnRlbnQsIHRlbXBsYXRlcywgaW5zdGFuY2VEYXRhKSArIGNvbnRlbnQuc3Vic3RyaW5nKG1hdGNoLmluZGV4ICsgbWF0Y2hbMF0ubGVuZ3RoKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBvdXRFcnJvcnMucHVzaChg0J3QtSDQsdC10YjQtSDQvtGC0LrRgNC40YIg0YTRgNCw0LPQvNC10L3RgiBcIiR7cmVmTmFtZX1cImApO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyBDYWxjdWxhdGVkIGZpZWxkc1xyXG4gICAgaWYgKGluc3RhbmNlRGF0YSkge1xyXG4gICAgICAgIGNvbnN0IGZpZWxkTWF0Y2hlciA9IC9cXFtcXFsoLis/KVxcXVxcXS9nO1xyXG5cclxuICAgICAgICBsZXQgbWF0Y2g7XHJcblxyXG4gICAgICAgIHdoaWxlICgobWF0Y2ggPSBmaWVsZE1hdGNoZXIuZXhlYyhjb250ZW50KSkgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICBjb25zdCByZXBsYWNlciA9IGZpZWxkc1ttYXRjaFsxXV07XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgcmVwbGFjZXIgPT0gJ2Z1bmN0aW9uJykge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgdmFsdWUgPSByZXBsYWNlcihpbnN0YW5jZURhdGEpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHZhbHVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29udGVudCA9IGNvbnRlbnQuc3Vic3RyaW5nKDAsIG1hdGNoLmluZGV4KSArIHZhbHVlICsgY29udGVudC5zdWJzdHJpbmcobWF0Y2guaW5kZXggKyBtYXRjaFswXS5sZW5ndGgpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBvdXRFcnJvcnMucHVzaChg0J3QtdC00L7RgdGC0LDRgtGK0YfQvdCwINC40L3RhNC+0YDQvNCw0YbQuNGPINC30LAg0L/QvtC/0YrQu9Cy0LDQvdC1INC90LAg0L/QvtC70LUgXCIke21hdGNoWzFdfVwiYCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBvdXRFcnJvcnMucHVzaChg0JPRgNC10YjQutCwINC/0YDQuCDQuNC30L/RitC70L3QtdC90LjQtSDQvdCwINC40LfRh9C40YHQu9C10L3QviDQv9C+0LvQtSBcIiR7bWF0Y2hbMV19XCJgKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gY29udGVudDtcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IGZpZWxkTWV0YSA9IHtcclxuICAgIEluc3RhbmNlSWQ6IHtcclxuICAgICAgICBuYW1lOiAnSUQg0L3QsCDQuNC90YHRgtCw0L3RhtC40Y/RgtCwJyxcclxuICAgICAgICBncm91cDogJ9CX0LAg0LrRg9GA0YHQsCdcclxuICAgIH0sXHJcbiAgICBTaWdudXBEZWFkbGluZToge1xyXG4gICAgICAgIG5hbWU6ICfQodGA0L7QuiDQt9CwINC30LDQv9C40YHQstCw0L3QtScsXHJcbiAgICAgICAgZ3JvdXA6ICfQl9CwINC60YPRgNGB0LAnXHJcbiAgICB9LFxyXG4gICAgU3RhcnREYXRlOiB7XHJcbiAgICAgICAgbmFtZTogJ9Cd0LDRh9Cw0LvQvdCwINC00LDRgtCwJyxcclxuICAgICAgICBncm91cDogJ9CX0LAg0LrRg9GA0YHQsCdcclxuICAgIH0sXHJcbiAgICBFdmVudHNXZWVrZGF5OiB7XHJcbiAgICAgICAgbmFtZTogJ9Ch0LXQtNC80LjRh9C10L0g0LTQtdC9INC90LAg0LfQsNC90Y/RgtC40Y/RgtCwJyxcclxuICAgICAgICBncm91cDogJ9CX0LAg0LLRgdC40YfQutC4INC30LDQvdGP0YLQuNGPJ1xyXG4gICAgfSxcclxuICAgIExlY3R1cmVXZWVrZGF5OiB7XHJcbiAgICAgICAgbmFtZTogJ9Ch0LXQtNC80LjRh9C10L0g0LTQtdC9INC90LAg0LvQtdC60YbQuNC40YLQtScsXHJcbiAgICAgICAgZ3JvdXA6ICfQl9CwINC70LXQutGG0LjQuNGC0LUnXHJcbiAgICB9LFxyXG4gICAgRXhlcmNpc2VXZWVrZGF5OiB7XHJcbiAgICAgICAgbmFtZTogJ9Ch0LXQtNC80LjRh9C10L0g0LTQtdC9INC90LAg0YPQv9GA0LDQttC90LXQvdC40Y/RgtCwJyxcclxuICAgICAgICBncm91cDogJ9CX0LAg0YPQv9GA0LDQttC90LXQvdC40Y/RgtCwJ1xyXG4gICAgfSxcclxuICAgIEV2ZW50U3RhcnRUaW1lOiB7XHJcbiAgICAgICAgbmFtZTogJ9Cd0LDRh9Cw0LvQtdC9INGH0LDRgSDQvdCwINC30LDQvdGP0YLQuNGP0YLQsCcsXHJcbiAgICAgICAgZ3JvdXA6ICfQl9CwINCy0YHQuNGH0LrQuCDQt9Cw0L3Rj9GC0LjRjydcclxuICAgIH0sXHJcbiAgICBMZWN0dXJlU3RhcnRUaW1lOiB7XHJcbiAgICAgICAgbmFtZTogJ9Cd0LDRh9Cw0LvQtdC9INGH0LDRgSDQvdCwINC70LXQutGG0LjQuNGC0LUnLFxyXG4gICAgICAgIGdyb3VwOiAn0JfQsCDQu9C10LrRhtC40LjRgtC1J1xyXG4gICAgfSxcclxuICAgIEV4ZXJjaXNlU3RhcnRUaW1lOiB7XHJcbiAgICAgICAgbmFtZTogJ9Cd0LDRh9Cw0LvQtdC9INGH0LDRgSDQvdCwINGD0L/RgNCw0LbQvdC10L3QuNGP0YLQsCcsXHJcbiAgICAgICAgZ3JvdXA6ICfQl9CwINGD0L/RgNCw0LbQvdC10L3QuNGP0YLQsCdcclxuICAgIH0sXHJcbiAgICBFdmVudEVuZFRpbWU6IHtcclxuICAgICAgICBuYW1lOiAn0JrRgNCw0LXQvSDRh9Cw0YEg0L3QsCDQt9Cw0L3Rj9GC0LjRj9GC0LAnLFxyXG4gICAgICAgIGdyb3VwOiAn0JfQsCDQstGB0LjRh9C60Lgg0LfQsNC90Y/RgtC40Y8nXHJcbiAgICB9LFxyXG4gICAgTGVjdHVyZUVuZFRpbWU6IHtcclxuICAgICAgICBuYW1lOiAn0JrRgNCw0LXQvSDRh9Cw0YEg0L3QsCDQu9C10LrRhtC40LjRgtC1JyxcclxuICAgICAgICBncm91cDogJ9CX0LAg0LvQtdC60YbQuNC40YLQtSdcclxuICAgIH0sXHJcbiAgICBFeGVyY2lzZUVuZFRpbWU6IHtcclxuICAgICAgICBuYW1lOiAn0JrRgNCw0LXQvSDRh9Cw0YEg0L3QsCDRg9C/0YDQsNC20L3QtdC90LjRj9GC0LAnLFxyXG4gICAgICAgIGdyb3VwOiAn0JfQsCDRg9C/0YDQsNC20L3QtdC90LjRj9GC0LAnXHJcbiAgICB9LFxyXG4gICAgUHJpY2VPbmxpbmU6IHtcclxuICAgICAgICBuYW1lOiAn0KbQtdC90LAgLSDQntC90LvQsNC50L0nLFxyXG4gICAgICAgIGdyb3VwOiAn0JfQsCDQutGD0YDRgdCwJ1xyXG4gICAgfSxcclxuICAgIEZpcnN0RXhhbURhdGU6IHtcclxuICAgICAgICBuYW1lOiAn0J/RitGA0LLQsCDQuNC30L/QuNGC0L3QsCDQtNCw0YLQsCcsXHJcbiAgICAgICAgZ3JvdXA6ICfQl9CwINC60YPRgNGB0LAnXHJcbiAgICB9LFxyXG4gICAgUmVmdW5kRGVhZGxpbmU6IHtcclxuICAgICAgICBuYW1lOiAn0KHRgNC+0Log0LfQsCDQstGK0LfRgdGC0LDQvdC+0LLRj9Cy0LDQvdC1INC90LAg0YLQsNC60YHQsCcsXHJcbiAgICAgICAgZ3JvdXA6ICfQl9CwINC60YPRgNGB0LAnXHJcbiAgICB9LFxyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IGZpZWxkcyA9IHtcclxuICAgIEluc3RhbmNlSWQoaW5zdGFuY2VEYXRhKSB7XHJcbiAgICAgICAgcmV0dXJuIGluc3RhbmNlRGF0YS5pbmZvLklkO1xyXG4gICAgfSxcclxuICAgIFNpZ251cERlYWRsaW5lKGluc3RhbmNlRGF0YSkge1xyXG4gICAgICAgIHJldHVybiBleHRyYWN0RGF0ZShpbnN0YW5jZURhdGEsICdTaWdudXBEZWFkbGluZUZvclVzZXJzJyk7XHJcbiAgICB9LFxyXG4gICAgU3RhcnREYXRlKGluc3RhbmNlRGF0YSkge1xyXG4gICAgICAgIHJldHVybiBleHRyYWN0RGF0ZShpbnN0YW5jZURhdGEsICdTdGFydERhdGUnLCB0cnVlKTtcclxuICAgIH0sXHJcbiAgICBFdmVudHNXZWVrZGF5KGluc3RhbmNlRGF0YSkge1xyXG4gICAgICAgIGNvbnN0IGV2ZW50cyA9IGluc3RhbmNlRGF0YS5ldmVudHMgPyBpbnN0YW5jZURhdGEuZXZlbnRzLkV2ZW50cyA6IFtdO1xyXG4gICAgICAgIHJldHVybiBleHRyYWN0V2Vla2RheShldmVudHMpO1xyXG4gICAgfSxcclxuICAgIExlY3R1cmVXZWVrZGF5KGluc3RhbmNlRGF0YSkge1xyXG4gICAgICAgIGNvbnN0IGV2ZW50cyA9IGluc3RhbmNlRGF0YS5ldmVudHMgPyBpbnN0YW5jZURhdGEuZXZlbnRzLkV2ZW50cy5maWx0ZXIoZSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IGxlY3R1cmUgPSBpbnN0YW5jZURhdGEubGVjdHVyZXMuZmluZChsID0+IGwuSWQgPT0gZS5MZWN0dXJlSWQpO1xyXG4gICAgICAgICAgICByZXR1cm4gbGVjdHVyZSAmJiAhbGVjdHVyZS5Jc0V4Y2x1ZGVkRnJvbUNlcnRpZmljYXRlO1xyXG4gICAgICAgIH0pIDogW107XHJcbiAgICAgICAgcmV0dXJuIGV4dHJhY3RXZWVrZGF5KGV2ZW50cyk7XHJcbiAgICB9LFxyXG4gICAgRXhlcmNpc2VXZWVrZGF5KGluc3RhbmNlRGF0YSkge1xyXG4gICAgICAgIGNvbnN0IGV2ZW50cyA9IGluc3RhbmNlRGF0YS5ldmVudHMgPyBpbnN0YW5jZURhdGEuZXZlbnRzLkV2ZW50cy5maWx0ZXIoZSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IGxlY3R1cmUgPSBpbnN0YW5jZURhdGEubGVjdHVyZXMuZmluZChsID0+IGwuSWQgPT0gZS5MZWN0dXJlSWQpO1xyXG4gICAgICAgICAgICByZXR1cm4gbGVjdHVyZSAmJiBsZWN0dXJlLklzRXhjbHVkZWRGcm9tQ2VydGlmaWNhdGU7XHJcbiAgICAgICAgfSkgOiBbXTtcclxuICAgICAgICByZXR1cm4gZXh0cmFjdFdlZWtkYXkoZXZlbnRzKTtcclxuICAgIH0sXHJcbiAgICBFdmVudFN0YXJ0VGltZShpbnN0YW5jZURhdGEpIHtcclxuICAgICAgICBjb25zdCBldmVudHMgPSBpbnN0YW5jZURhdGEuZXZlbnRzID8gaW5zdGFuY2VEYXRhLmV2ZW50cy5FdmVudHMgOiBbXTtcclxuICAgICAgICByZXR1cm4gZXh0cmFjdFRpbWUoZXZlbnRzLCAnU3RhcnREYXRlVGltZScsIHRydWUpO1xyXG4gICAgfSxcclxuICAgIExlY3R1cmVTdGFydFRpbWUoaW5zdGFuY2VEYXRhKSB7XHJcbiAgICAgICAgY29uc3QgZXZlbnRzID0gZmlsdGVyTGVjdHVyZXMoaW5zdGFuY2VEYXRhKTtcclxuICAgICAgICByZXR1cm4gZXh0cmFjdFRpbWUoZXZlbnRzLCAnU3RhcnREYXRlVGltZScsIHRydWUpO1xyXG4gICAgfSxcclxuICAgIEV4ZXJjaXNlU3RhcnRUaW1lKGluc3RhbmNlRGF0YSkge1xyXG4gICAgICAgIGNvbnN0IGV2ZW50cyA9IGZpbHRlckV4ZXJjaXNlcyhpbnN0YW5jZURhdGEpO1xyXG4gICAgICAgIHJldHVybiBleHRyYWN0VGltZShldmVudHMsICdTdGFydERhdGVUaW1lJywgdHJ1ZSk7XHJcbiAgICB9LFxyXG4gICAgRXZlbnRFbmRUaW1lKGluc3RhbmNlRGF0YSkge1xyXG4gICAgICAgIGNvbnN0IGV2ZW50cyA9IGluc3RhbmNlRGF0YS5ldmVudHMgPyBpbnN0YW5jZURhdGEuZXZlbnRzLkV2ZW50cyA6IFtdO1xyXG4gICAgICAgIHJldHVybiBleHRyYWN0VGltZShldmVudHMsICdFbmREYXRlVGltZScsIHRydWUpO1xyXG4gICAgfSxcclxuICAgIExlY3R1cmVFbmRUaW1lKGluc3RhbmNlRGF0YSkge1xyXG4gICAgICAgIGNvbnN0IGV2ZW50cyA9IGZpbHRlckxlY3R1cmVzKGluc3RhbmNlRGF0YSk7XHJcbiAgICAgICAgcmV0dXJuIGV4dHJhY3RUaW1lKGV2ZW50cywgJ0VuZERhdGVUaW1lJywgdHJ1ZSk7XHJcbiAgICB9LFxyXG4gICAgRXhlcmNpc2VFbmRUaW1lKGluc3RhbmNlRGF0YSkge1xyXG4gICAgICAgIGNvbnN0IGV2ZW50cyA9IGZpbHRlckV4ZXJjaXNlcyhpbnN0YW5jZURhdGEpO1xyXG4gICAgICAgIHJldHVybiBleHRyYWN0VGltZShldmVudHMsICdFbmREYXRlVGltZScsIHRydWUpO1xyXG4gICAgfSxcclxuICAgIFByaWNlT25saW5lKGluc3RhbmNlRGF0YSkge1xyXG4gICAgICAgIHJldHVybiBpbnN0YW5jZURhdGEuaW5mby5QcmljZU9ubGluZTtcclxuICAgIH0sXHJcbiAgICBGaXJzdEV4YW1EYXRlKGluc3RhbmNlRGF0YSkge1xyXG4gICAgICAgIGNvbnN0IGZpcnN0RXhhbSA9IGluc3RhbmNlRGF0YS5leGFtcy5zb3J0KChhLCBiKSA9PiAobmV3IERhdGUoYS5TdGFydFRpbWUpKSAtIChuZXcgRGF0ZShiLlN0YXJ0VGltZSkpKVswXTtcclxuICAgICAgICBpZiAoZmlyc3RFeGFtKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBmb3JtYXRMb2NhbGVEYXRlKG5ldyBEYXRlKGZpcnN0RXhhbS5TdGFydFRpbWUpKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBSZWZ1bmREZWFkbGluZShpbnN0YW5jZURhdGEpIHtcclxuICAgICAgICBjb25zdCBldmVudHMgPSBpbnN0YW5jZURhdGEuZXZlbnRzID8gaW5zdGFuY2VEYXRhLmV2ZW50cy5FdmVudHMgOiBbXTtcclxuICAgICAgICBjb25zdCB0aGlyZEV2ZW50ID0gZXZlbnRzLnNsaWNlKCkuc29ydCgoYSwgYikgPT4gKG5ldyBEYXRlKGEuU3RhcnREYXRlVGltZSkpIC0gKG5ldyBEYXRlKGIuU3RhcnREYXRlVGltZSkpKVsyXTtcclxuICAgICAgICBpZiAodGhpcmRFdmVudCkge1xyXG4gICAgICAgICAgICByZXR1cm4gZm9ybWF0TG9jYWxlRGF0ZShuZXcgRGF0ZSh0aGlyZEV2ZW50LlN0YXJ0RGF0ZVRpbWUpKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufTtcclxuXHJcbmZ1bmN0aW9uIGV4dHJhY3RXZWVrZGF5KGV2ZW50cykge1xyXG4gICAgbGV0IHdlZWtkYXlzID0gZmlsdGVyU3RyYXlzKGV2ZW50c1xyXG4gICAgICAgIC5tYXAoZSA9PiBuZXcgRGF0ZShlLlN0YXJ0RGF0ZVRpbWUpKVxyXG4gICAgICAgIC5tYXAoZSA9PiBlLmdldERheSgpKVxyXG4gICAgICAgIC5yZWR1Y2UodG9Db3VudCwge30pKTtcclxuXHJcbiAgICBpZiAod2Vla2RheXMubGVuZ3RoID09IDEpIHtcclxuICAgICAgICBjb25zdCB0ZXh0ID0gZm9ybWF0TG9jYWxlV2Vla2RheSh3ZWVrZGF5c1swXSwgdHJ1ZSk7XHJcbiAgICAgICAgcmV0dXJuIGAke3RleHRbMV19IDxzdHJvbmc+JHt0ZXh0WzBdfTwvc3Ryb25nPmA7XHJcbiAgICB9IGVsc2UgaWYgKHdlZWtkYXlzLmxlbmd0aCA+IDEpIHtcclxuICAgICAgICBjb25zdCB0ZXh0ID0gd2Vla2RheXMubWFwKHcgPT4gZm9ybWF0TG9jYWxlV2Vla2RheSh3KSk7XHJcbiAgICAgICAgcmV0dXJuIGDQstGB0LXQutC4IDxzdHJvbmc+JHt0ZXh0LnNsaWNlKDAsIC0xKS5qb2luKCc8L3N0cm9uZz4sIDxzdHJvbmc+Jyl9PC9zdHJvbmc+INC4IDxzdHJvbmc+JHt0ZXh0W3RleHQubGVuZ3RoIC0gMV19PC9zdHJvbmc+YDtcclxuICAgIH1cclxufVxyXG5cclxuZnVuY3Rpb24gZXh0cmFjdERhdGUoaW5zdGFuY2VEYXRhLCBwcm9wTmFtZSwgaW5jbHVkZVllYXIpIHtcclxuICAgIGxldCBkYXRlID0gaW5zdGFuY2VEYXRhLmluZm9bcHJvcE5hbWVdO1xyXG4gICAgaWYgKGRhdGUpIHtcclxuICAgICAgICBkYXRlID0gbmV3IERhdGUoZGF0ZSk7XHJcbiAgICAgICAgaWYgKGluY2x1ZGVZZWFyKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBgJHtmb3JtYXRMb2NhbGVEYXRlKGRhdGUpfSAke2RhdGUuZ2V0RnVsbFllYXIoKX0g0LNgO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiBmb3JtYXRMb2NhbGVEYXRlKGRhdGUpO1xyXG4gICAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcclxuICAgIH1cclxufVxyXG5cclxuZnVuY3Rpb24gZXh0cmFjdFRpbWUoZXZlbnRzLCBwcm9wTmFtZSwgc2luZ2xlUmVzdWx0KSB7XHJcbiAgICBsZXQgdGltZXMgPSBmaWx0ZXJTdHJheXMoZXZlbnRzXHJcbiAgICAgICAgLm1hcChlID0+IG5ldyBEYXRlKGVbcHJvcE5hbWVdKSlcclxuICAgICAgICAubWFwKGUgPT4gZm9ybWF0VGltZShlKSlcclxuICAgICAgICAucmVkdWNlKHRvQ291bnQsIHt9KSwgc2luZ2xlUmVzdWx0KTtcclxuXHJcbiAgICByZXR1cm4gdGltZXM7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHRvQ291bnQocCwgYykge1xyXG4gICAgaWYgKHBbY10gPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgcFtjXSA9IDA7XHJcbiAgICB9XHJcbiAgICBwW2NdKys7XHJcbiAgICByZXR1cm4gcDtcclxufVxyXG5cclxuZnVuY3Rpb24gZmlsdGVyTGVjdHVyZXMoaW5zdGFuY2VEYXRhKSB7XHJcbiAgICBjb25zdCBldmVudHMgPSBpbnN0YW5jZURhdGEuZXZlbnRzID8gaW5zdGFuY2VEYXRhLmV2ZW50cy5FdmVudHMuZmlsdGVyKGUgPT4ge1xyXG4gICAgICAgIGNvbnN0IGxlY3R1cmUgPSBpbnN0YW5jZURhdGEubGVjdHVyZXMuZmluZChsID0+IGwuSWQgPT0gZS5MZWN0dXJlSWQpO1xyXG4gICAgICAgIHJldHVybiBsZWN0dXJlICYmICFsZWN0dXJlLklzRXhjbHVkZWRGcm9tQ2VydGlmaWNhdGU7XHJcbiAgICB9KSA6IFtdO1xyXG4gICAgcmV0dXJuIGV2ZW50cztcclxufVxyXG5cclxuXHJcbmZ1bmN0aW9uIGZpbHRlckV4ZXJjaXNlcyhpbnN0YW5jZURhdGEpIHtcclxuICAgIGNvbnN0IGV2ZW50cyA9IGluc3RhbmNlRGF0YS5ldmVudHMgPyBpbnN0YW5jZURhdGEuZXZlbnRzLkV2ZW50cy5maWx0ZXIoZSA9PiB7XHJcbiAgICAgICAgY29uc3QgbGVjdHVyZSA9IGluc3RhbmNlRGF0YS5sZWN0dXJlcy5maW5kKGwgPT4gbC5JZCA9PSBlLkxlY3R1cmVJZCk7XHJcbiAgICAgICAgcmV0dXJuIGxlY3R1cmUgJiYgbGVjdHVyZS5Jc0V4Y2x1ZGVkRnJvbUNlcnRpZmljYXRlO1xyXG4gICAgfSkgOiBbXTtcclxuICAgIHJldHVybiBldmVudHM7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZpbHRlclN0cmF5cyhkYXRhLCBzaW5nbGVSZXN1bHQpIHtcclxuICAgIGlmIChzaW5nbGVSZXN1bHQpIHtcclxuICAgICAgICBjb25zdCBvdXRwdXQgPSBPYmplY3QuZW50cmllcyhkYXRhKS5zb3J0KChhLCBiKSA9PiBiWzFdIC0gYVsxXSkubWFwKHggPT4geFswXSk7XHJcbiAgICAgICAgcmV0dXJuIG91dHB1dFswXTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKGRhdGEpLmZpbHRlcih4ID0+IHhbMV0gPiAxKS5tYXAoeCA9PiB4WzBdKTtcclxuICAgIH1cclxufSIsImltcG9ydCBkb20sIHsgRnJhZ21lbnQgfSBmcm9tICcuLi91dGlsL2pzeC1yZW5kZXItbW9kL2RvbSc7XHJcbmltcG9ydCB7IHJlZGlyZWN0IH0gZnJvbSAnLi4vdXRpbC9yb3V0ZXInO1xyXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSAnLi4vdXRpbC9yb3V0ZXInO1xyXG5pbXBvcnQgeyBZZXMsIE5vLCBnZXRFZGl0b3JEZWNvcmF0aW9uLCByZXBsYWNlQ29udGVudHMgfSBmcm9tICcuLi91dGlsL3RlbXBsYXRlJztcclxuaW1wb3J0IHsgZGVsZXRlVGVtcGxhdGUgfSBmcm9tICcuL2RhdGEnO1xyXG5pbXBvcnQgUHJldmlldyBmcm9tICcuL1ByZXZpZXcnO1xyXG5cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBUZW1wbGF0ZUxpc3QoeyBjb25maWcsIHRlbXBsYXRlcywgYXBpLCBjb250ZXh0IH0pIHtcclxuICAgIGNvbnRleHQub24oJ0xpc3RVcGRhdGVkJywgdXBkYXRlU2VsZik7XHJcblxyXG4gICAgbGV0IHRib2R5ID0gKDx0Ym9keT48L3Rib2R5Pik7XHJcbiAgICB1cGRhdGVTZWxmKCk7XHJcblxyXG4gICAgcmV0dXJuICg8RnJhZ21lbnQ+XHJcbiAgICAgICAgPHA+0JjQt9Cx0LXRgNC10YLQtSDRiNCw0LHQu9C+0L0g0L7RgiDRgdC/0LjRgdGK0LrQsCwg0LfQsCDQtNCwINC/0YDQtdCz0LvQtdC00LDRgtC1INGB0YrQtNGK0YDQttCw0L3QuNC10YLQviDQvNGDLjwvcD5cclxuXHJcbiAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInNlcy10ZW1wbGF0ZS10YWJsZVwiIHN0eWxlPXt7IHdpZHRoOiAnMTAwJScgfX0+XHJcbiAgICAgICAgICAgIDx0aGVhZD5cclxuICAgICAgICAgICAgICAgIDx0cj48dGQgY29sU3Bhbj1cIjVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPXsnP25ldyd9IGNsYXNzTmFtZT1cInNlcy1wYWdlLWxpbmtcIj48aSBjbGFzcz1cImdseXBoaWNvbiBnbHlwaGljb24tcGx1c1wiPjwvaT4g0KHRitC30LTQsNC5INGI0LDQsdC70L7QvTwvTGluaz5cclxuICAgICAgICAgICAgICAgIDwvdGQ+PC90cj5cclxuICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICA8dGg+0JjQvNC1PC90aD5cclxuICAgICAgICAgICAgICAgICAgICA8dGg+0JrQsNGC0LXQs9C+0YDQuNC4PC90aD5cclxuICAgICAgICAgICAgICAgICAgICA8dGggc3R5bGU9e3sgd2lkdGg6ICcxMDBweCcgfX0+0KbRj9C70L7RgdGC0LXQvTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRoIHN0eWxlPXt7IHdpZHRoOiAnMTAwcHgnIH19PtCQ0LrRgtGD0LDQu9C10L08L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0aCBzdHlsZT17eyB3aWR0aDogJzEwMHB4JyB9fT7QmtC+0L3RgtGA0L7QuzwvdGg+XHJcbiAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICA8L3RoZWFkPlxyXG5cclxuICAgICAgICAgICAge3Rib2R5fVxyXG5cclxuICAgICAgICAgICAgPHRmb290PlxyXG4gICAgICAgICAgICAgICAgPHRyPjx0ZCBjb2xTcGFuPVwiNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9eyc/bmV3J30gY2xhc3NOYW1lPVwic2VzLXBhZ2UtbGlua1wiPjxpIGNsYXNzPVwiZ2x5cGhpY29uIGdseXBoaWNvbi1wbHVzXCI+PC9pPiDQodGK0LfQtNCw0Lkg0YjQsNCx0LvQvtC9PC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgPC90ZD48L3RyPlxyXG4gICAgICAgICAgICA8L3Rmb290PlxyXG4gICAgICAgIDwvdGFibGU+XHJcbiAgICA8L0ZyYWdtZW50Pik7XHJcblxyXG4gICAgZnVuY3Rpb24gdXBkYXRlU2VsZigpIHtcclxuICAgICAgICB0Ym9keSA9IHJlcGxhY2VDb250ZW50cyh0Ym9keSwgdGVtcGxhdGVzLmZpbHRlcih0ID0+ICF0Lkluc3RhbmNlSWQpLm1hcChUZW1wbGF0ZVJvdy5iaW5kKG51bGwsIGNvbmZpZy5jYXRlZ29yaWVzLCB0ZW1wbGF0ZXMsIGFwaSwgY29udGV4dCkpKTtcclxuICAgIH1cclxufVxyXG5cclxuZnVuY3Rpb24gVGVtcGxhdGVSb3coY2F0ZWdvcmllcywgYWxsVGVtcGxhdGVzLCBhcGksIGNvbnRleHQsIHRlbXBsYXRlKSB7XHJcbiAgICBjb25zdCB1c2VzRnJhZ21lbnRzID0gL1xcW1xcW1JlZj0uKz9cXF1cXF0vLnRlc3QodGVtcGxhdGUuQ29udGVudCk7XHJcbiAgICBjb25zdCBpc0R5bmFtaWMgPSB1c2VzRnJhZ21lbnRzID09IGZhbHNlICYmIC9cXFtcXFsuKz9cXF1cXF0vLnRlc3QodGVtcGxhdGUuQ29udGVudCk7XHJcblxyXG4gICAgbGV0IGFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgY29uc3QgZWxlbWVudCA9ICg8dHIgY2xhc3NOYW1lPVwic2VzLXRlbXBsYXRlLXJvd1wiIG9uQ2xpY2s9e3RvZ2dsZX0+XHJcbiAgICAgICAgPHRkPnt0ZW1wbGF0ZS5OYW1lfTwvdGQ+XHJcbiAgICAgICAgPHRkPlxyXG4gICAgICAgICAgICB7dGVtcGxhdGUuQ2F0ZWdvcnkubWFwKGMgPT4gPHNwYW4gY2xhc3NOYW1lPVwic2VzLXRlbXBsYXRlLWNhdGVnb3J5XCI+e2NhdGVnb3JpZXNbY119PC9zcGFuPil9XHJcbiAgICAgICAgICAgIHt1c2VzRnJhZ21lbnRzID8gPHNwYW4gY2xhc3NOYW1lPVwic2VzLXRlbXBsYXRlLWNhdGVnb3J5LWF1dG9cIj7QodGK0LTRitGA0LbQsCDRhNGA0LDQs9C80LXQvdGC0Lg8L3NwYW4+IDogJyd9XHJcbiAgICAgICAgICAgIHtpc0R5bmFtaWMgPyA8c3BhbiBjbGFzc05hbWU9XCJzZXMtdGVtcGxhdGUtY2F0ZWdvcnktYXV0b1wiPtCU0LjQvdCw0LzQuNGH0LXQvTwvc3Bhbj4gOiAnJ31cclxuICAgICAgICA8L3RkPlxyXG4gICAgICAgIDx0ZCBjbGFzc05hbWU9XCJzZXMtY2VudGVyXCI+e3RlbXBsYXRlLkNvbXBvdW5kID8gPFllcyAvPiA6IDxObyAvPn08L3RkPlxyXG4gICAgICAgIDx0ZCBjbGFzc05hbWU9XCJzZXMtY2VudGVyXCI+e3RlbXBsYXRlLkFjdGl2ZSA/IDxZZXMgLz4gOiA8Tm8gLz59PC90ZD5cclxuICAgICAgICA8dGQgY2xhc3NOYW1lPVwic2VzLWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHJlZGlyZWN0KGA/aWQ9JHt0ZW1wbGF0ZS5JZH1gKX0+PGkgY2xhc3M9XCJnbHlwaGljb24gZ2x5cGhpY29uLXBlbmNpbFwiPjwvaT48L2J1dHRvbj5cclxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvbkRlbGV0ZX0+PGkgY2xhc3M9XCJnbHlwaGljb24gZ2x5cGhpY29uLXRyYXNoXCI+PC9pPjwvYnV0dG9uPlxyXG4gICAgICAgIDwvdGQ+XHJcbiAgICA8L3RyPik7XHJcbiAgICBsZXQgcHJldmlldyA9IG51bGw7XHJcblxyXG4gICAgY29uc3QgZGVjb3JhdGlvbiA9IGdldEVkaXRvckRlY29yYXRpb24oZWxlbWVudCk7XHJcblxyXG4gICAgcmV0dXJuIGVsZW1lbnQ7XHJcblxyXG4gICAgZnVuY3Rpb24gdG9nZ2xlKGUpIHtcclxuICAgICAgICBpZiAoZSAmJiAoZS50YXJnZXQudGFnTmFtZSA9PSAnSScgfHwgZS50YXJnZXQudGFnTmFtZSA9PSAnQlVUVE9OJykpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGFjdGl2ZSkge1xyXG4gICAgICAgICAgICBhY3RpdmUgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgICAgIHByZXZpZXcucmVtb3ZlKCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgaWYgKHByZXZpZXcgPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgcHJldmlldyA9IGdlbmVyYXRlUHJldmlldyhhbGxUZW1wbGF0ZXMsIHRlbXBsYXRlLCB0b2dnbGUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsZW1lbnQuYWZ0ZXIocHJldmlldyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIG9uRGVsZXRlKCkge1xyXG4gICAgICAgIGNvbnN0IGNob2ljZSA9IGNvbmZpcm0oYNCh0LjQs9GD0YDQvdC4INC70Lgg0YHRgtC1LCDRh9C1INC40YHQutCw0YLQtSDQtNCwINC40LfRgtGA0LjQtdGC0LUg0YjQsNCx0LvQvtC90LAgXCIke3RlbXBsYXRlLk5hbWV9XCI/YCk7XHJcbiAgICAgICAgaWYgKGNob2ljZSkge1xyXG4gICAgICAgICAgICBkZWNvcmF0aW9uLndvcmtpbmcoKTtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGF3YWl0IGRlbGV0ZVRlbXBsYXRlKGFwaSwgdGVtcGxhdGUpO1xyXG4gICAgICAgICAgICAgICAgYWxsVGVtcGxhdGVzLnNwbGljZShhbGxUZW1wbGF0ZXMuaW5kZXhPZih0ZW1wbGF0ZSksIDEpO1xyXG4gICAgICAgICAgICAgICAgY29udGV4dC5lbWl0KCdMaXN0VXBkYXRlZCcpO1xyXG4gICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgICAgIGRlY29yYXRpb24uZmFpbHVyZSgpO1xyXG4gICAgICAgICAgICAgICAgYWxlcnQoZXJyLm1lc3NhZ2UpO1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBnZW5lcmF0ZVByZXZpZXcoYWxsVGVtcGxhdGVzLCB0ZW1wbGF0ZSwgdG9nZ2xlKSB7XHJcblxyXG4gICAgcmV0dXJuICg8dHI+XHJcbiAgICAgICAgPHRkIGNvbFNwYW49XCI1XCI+XHJcbiAgICAgICAgICAgIDxQcmV2aWV3IGNvbnRlbnQ9e3RlbXBsYXRlLkNvbnRlbnR9IHRlbXBsYXRlcz17YWxsVGVtcGxhdGVzfSAvPlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBzdHlsZT17eyBmbG9hdDogJ3JpZ2h0JyB9fSBvbkNsaWNrPXsoKSA9PiB0b2dnbGUoKX0+0JfQsNGC0LLQvtGA0Lg8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC90ZD5cclxuICAgIDwvdHI+KTtcclxufSIsIi8vLyA8cmVmZXJlbmNlIHBhdGg9XCIuLi91dGlsL2FwaS5kLnRzXCIgLz5cclxuXHJcbmltcG9ydCBkb20sIHsgRnJhZ21lbnQgfSBmcm9tICcuLi91dGlsL2pzeC1yZW5kZXItbW9kL2RvbSc7XHJcbmltcG9ydCAqIGFzIFNlc0FwaSBmcm9tICcuLi91dGlsL2FwaSc7XHJcbmltcG9ydCB7IHJlcGxhY2VDb250ZW50cywgTG9hZGluZyB9IGZyb20gJy4uL3V0aWwvdGVtcGxhdGUnO1xyXG5pbXBvcnQgeyBnZXRDb25maWcsIGdldFRlbXBsYXRlcyB9IGZyb20gJy4vZGF0YSc7XHJcbmltcG9ydCB7IFRlbXBsYXRlTGlzdCB9IGZyb20gJy4vVGVtcGxhdGVMaXN0JztcclxuaW1wb3J0IEVkaXRvciBmcm9tICcuL0VkaXRvcic7XHJcblxyXG5cclxuYXN5bmMgZnVuY3Rpb24gcGFnZShDb21wb25lbnQsIG9wdGlvbnMgPSB7fSkge1xyXG4gICAgbGV0IGNvbnRhaW5lciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdwYWdlQ29udGVudCcpO1xyXG5cclxuICAgIGNvbnRhaW5lciA9IHJlcGxhY2VDb250ZW50cyhjb250YWluZXIsIDxMb2FkaW5nIGNvbG9yPVwiYmxhY2tcIiAvPik7XHJcblxyXG4gICAgY29uc3QgY29uZmlnID0gYXdhaXQgZ2V0Q29uZmlnKFNlc0FwaSk7XHJcbiAgICBjb25zdCB0ZW1wbGF0ZXMgPSBhd2FpdCBnZXRUZW1wbGF0ZXMoU2VzQXBpKTtcclxuXHJcbiAgICBjb250YWluZXIgPSByZXBsYWNlQ29udGVudHMoY29udGFpbmVyLCA8Q29tcG9uZW50IGNvbmZpZz17Y29uZmlnfSB0ZW1wbGF0ZXM9e3RlbXBsYXRlc30gey4uLm9wdGlvbnN9IC8+KTtcclxufVxyXG5cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjYXRhbG9nUGFnZShxdWVyeSwgY29udGV4dCkge1xyXG4gICAgcGFnZShUZW1wbGF0ZUxpc3QsIHsgYXBpOiBTZXNBcGksIGNvbnRleHQgfSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVQYWdlKHF1ZXJ5LCBjb250ZXh0KSB7XHJcbiAgICBwYWdlKEVkaXRvciwgeyBhcGk6IFNlc0FwaSB9KTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVkaXRQYWdlKHF1ZXJ5LCBjb250ZXh0KSB7XHJcbiAgICBjb25zdCBpZCA9IHF1ZXJ5LmlkO1xyXG4gICAgcGFnZShFZGl0b3IsIHsgaWQsIHRpdGxlOiAn0KDQtdC00LDQutGG0LjRjyDQvdCwINGI0LDQsdC70L7QvScsIGFwaTogU2VzQXBpIH0pO1xyXG59IiwiLy8vIDxyZWZlcmVuY2UgcGF0aD1cIi4uL3V0aWwvYXBpLmQudHNcIiAvPlxyXG5pbXBvcnQgeyBzdG9yZXMsIHdpdGhDYWNoZSB9IGZyb20gJy4uL3V0aWwvZGF0YS1jb25uZWN0JztcclxuXHJcblxyXG4vKipcclxuICogQHBhcmFtIHtTVUFQSX0gYXBpIFxyXG4gKi9cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbmZpZyhhcGkpIHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCB3aXRoQ2FjaGUoYXBpLmdldFRlbXBsYXRlU3RvcmVTZXR0aW5ncywgc3RvcmVzLlRFTVBMQVRFX0NPTkZJRykoKTtcclxuICAgIHJldHVybiBkYXRhLnNldHRpbmdzO1xyXG59XHJcblxyXG4vKipcclxuICogQHBhcmFtIHtTVUFQSX0gYXBpIFxyXG4gKi9cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRlbXBsYXRlcyhhcGkpIHtcclxuICAgIHJldHVybiBhcGkuZ2V0VGVtcGxhdGVzKCk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBAcGFyYW0ge1NVQVBJfSBhcGkgXHJcbiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VGVtcGxhdGVCeUluc3RhbmNlSWQoYXBpLCBpbnN0YW5jZUlkKSB7XHJcbiAgICByZXR1cm4gYXBpLmdldFRlbXBsYXRlQnlJbnN0YW5jZUlkKGluc3RhbmNlSWQpO1xyXG59XHJcblxyXG4vKipcclxuICogQHBhcmFtIHtTVUFQSX0gYXBpIFxyXG4gKi9cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNhdmVUZW1wbGF0ZShhcGksIHRlbXBsYXRlKSB7XHJcbiAgICByZXR1cm4gYXBpLnNhdmVUZW1wbGF0ZSh0ZW1wbGF0ZSk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBAcGFyYW0ge1NVQVBJfSBhcGkgXHJcbiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVsZXRlVGVtcGxhdGUoYXBpLCB0ZW1wbGF0ZSkge1xyXG4gICAgcmV0dXJuIGFwaS5kZWxldGVUZW1wbGF0ZSh0ZW1wbGF0ZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVUZW1wbGF0ZU1vZGVsKCkge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBJZDogMCxcclxuICAgICAgICBOYW1lOiAnJyxcclxuICAgICAgICBDYXRlZ29yeTogW10sXHJcbiAgICAgICAgQWN0aXZlOiBmYWxzZSxcclxuICAgICAgICBDb21wb3VuZDogZmFsc2UsXHJcbiAgICAgICAgQ29udGVudDogJycsXHJcbiAgICAgICAgSW5zdGFuY2VJZDogJydcclxuICAgIH07XHJcbn0iLCIvLy8gPHJlZmVyZW5jZSBwYXRoPVwiLi9hcGkuZC50c1wiIC8+XHJcblxyXG5pbXBvcnQgeyB1dWlkIH0gZnJvbSAnLi9wYXJzZSc7XHJcbmltcG9ydCBiaW5kU2l0ZUFwaSBmcm9tICcuLi9hcGkvYXBpLWluZGV4JztcclxuaW1wb3J0IEFXTiBmcm9tICcuLi8uLi9ub2RlX21vZHVsZXMvYXdlc29tZS1ub3RpZmljYXRpb25zL3NyYy9pbmRleC5qcyc7XHJcblxyXG5jb25zdCBkaXNwYXRjaGVyID0ge307XHJcblxyXG5sZXQgYmdQb3J0O1xyXG5zdGFydFNlc0FwaVBvcnQoKTtcclxuXHJcbmZ1bmN0aW9uIHN0YXJ0U2VzQXBpUG9ydCgpIHtcclxuICAgIGJnUG9ydCA9IGJyb3dzZXIucnVudGltZS5jb25uZWN0KHsgbmFtZTogJ3Nlcy1hcGktcG9ydCcgfSk7XHJcbiAgICBiZ1BvcnQub25NZXNzYWdlLmFkZExpc3RlbmVyKG9uTWVzc2FnZSk7XHJcbiAgICBiZ1BvcnQub25EaXNjb25uZWN0LmFkZExpc3RlbmVyKCgpID0+IHtcclxuICAgICAgICBzdGFydFNlc0FwaVBvcnQoKTtcclxuICAgIH0pO1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXREYXRhKHR5cGUsIHBhcmFtcykge1xyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICBjb25zdCBfdXVpZCA9IHV1aWQoKTtcclxuICAgICAgICBiZ1BvcnQucG9zdE1lc3NhZ2Uoe1xyXG4gICAgICAgICAgICBfdXVpZCxcclxuICAgICAgICAgICAgYXBwTmFtZTogaW50ZXJvcEFwcE5hbWUoKSxcclxuICAgICAgICAgICAgdHlwZSxcclxuICAgICAgICAgICAgcGFyYW1zXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGRpc3BhdGNoZXJbX3V1aWRdID0geyByZXNvbHZlLCByZWplY3QsIHR5cGUgfTtcclxuICAgIH0pO1xyXG59XHJcblxyXG5mdW5jdGlvbiBvbk1lc3NhZ2UobSkge1xyXG4gICAgY29uc3QgdXVpZCA9IG0uX3V1aWQ7XHJcbiAgICBpZiAobS5fcmVqZWN0ZWQpIHtcclxuICAgICAgICBjb25zb2xlLmluZm8oJ09wZXJhdGlvbiByZWplY3Q6JywgZGlzcGF0Y2hlclt1dWlkXS50eXBlKTtcclxuICAgICAgICBjb25zdCBlcnJvciA9IG5ldyBFcnJvcihtLl9lcnJvcik7XHJcbiAgICAgICAgbGV0IG5vdGlmaWVyID0gbmV3IEFXTigpO1xyXG4gICAgICAgIG5vdGlmaWVyLmFsZXJ0KGAke20uX2Vycm9yfWAsIHtkdXJhdGlvbnM6IHthbGVydDogMTAwMDB9fSk7XHJcbiAgICAgICAgLy9tYXliZSB1cGRhdGUgdG8gc2hvdyBvbmx5IGluIGRlYnVnIG1vZGUsIHByb3ZpZGluZyBtb3JlIGRldGFpbGVkIGVycm9yIGluZm9ybWF0aW9uIHVzaW5nIHRoZSBfbWV0YSBwcm9wZXJ0eVxyXG4gICAgICAgIGNvbnNvbGUuZGlyKGVycm9yKTtcclxuXHJcbiAgICAgICAgZXJyb3IuX21ldGEgPSBtLl9tZXRhO1xyXG4gICAgICAgIGRpc3BhdGNoZXJbdXVpZF0ucmVqZWN0KGVycm9yKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgZGlzcGF0Y2hlclt1dWlkXS5yZXNvbHZlKG0uZGF0YSk7XHJcbiAgICB9XHJcbiAgICBkZWxldGUgZGlzcGF0Y2hlclt1dWlkXTtcclxufVxyXG5cclxuZnVuY3Rpb24gaW50ZXJvcEFwcE5hbWUoKSB7XHJcbiAgICBzd2l0Y2ggKHdpbmRvdy5sb2NhdGlvbi5ob3N0LnNsaWNlKDAsIDcpKSB7XHJcbiAgICAgICAgY2FzZSAnZGlnaXRhbCc6XHJcbiAgICAgICAgICAgIHJldHVybiAnZGlnaXRhbCc7XHJcbiAgICAgICAgY2FzZSAnY3JlYXRpdic6XHJcbiAgICAgICAgICAgIHJldHVybiAnY3JlYXRpdmUnO1xyXG4gICAgICAgIGNhc2UgJ2FpLnNvZnQnOlxyXG4gICAgICAgICAgICByZXR1cm4gJ2FpJztcclxuICAgICAgICBjYXNlICdmaW5hbmNlJzpcclxuICAgICAgICAgICAgcmV0dXJuICdmaW5hbmNlYWNhZGVteSc7XHJcbiAgICAgICAgY2FzZSAnZGV2LmRpZyc6XHJcbiAgICAgICAgICAgIHJldHVybiAnZGV2ZGlnaXRhbCc7XHJcbiAgICAgICAgY2FzZSAnZGV2LnNvZic6XHJcbiAgICAgICAgICAgIHJldHVybiAnZGV2c29mdHVuaSc7XHJcbiAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgcmV0dXJuICdwcm9ncmFtbWluZyc7XHJcbiAgICB9XHJcbn1cclxuXHJcbi8qKiBAdHlwZSB7U1VBUEl9ICovXHJcbmNvbnN0IGFjdGlvbnMgPSBiaW5kU2l0ZUFwaShudWxsKVxyXG4gICAgLm1hcChhID0+ICh7XHJcbiAgICAgICAgbmFtZTogYSxcclxuICAgICAgICBmdW5jOiAoLi4ucGFyYW1zKSA9PiBnZXREYXRhKGEsIHBhcmFtcylcclxuICAgIH0pKVxyXG4gICAgLnJlZHVjZSgocCwgYykgPT4ge1xyXG4gICAgICAgIHBbYy5uYW1lXSA9IGMuZnVuYztcclxuICAgICAgICByZXR1cm4gcDtcclxuICAgIH0sIHt9KTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGFjdGlvbnM7XHJcbiIsImltcG9ydCBhcGlDb25uZWN0IGZyb20gJy4vYXBpLWNvbm5lY3QnO1xyXG5cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgQ29tbW9uIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QmxvZ0J5VXJsKGJsb2dVcmwpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEJsb2dCeVVybChibG9nVXJsKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEhhbGxzKCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0SGFsbHMoKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUhhbGwoaGFsbCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QudXBkYXRlSGFsbChoYWxsKTtcclxufVxyXG5cclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcbi8vICMjIyBNb2R1bGUgRGF0YVxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNb2R1bGVzSW5Qcm9mZXNzaW9uKHByb2Zlc3Npb25JZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0TW9kdWxlc0luUHJvZmVzc2lvbihwcm9mZXNzaW9uSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TW9kdWxlcygpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldE1vZHVsZXMoKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEluc3RhbmNlc0luTW9kdWxlKG1vZHVsZUlkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRJbnN0YW5jZXNJbk1vZHVsZShtb2R1bGVJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZWFyY2hNb2R1bGVzKHF1ZXJ5KSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5zZWFyY2hNb2R1bGVzKHF1ZXJ5KTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEluc3RhbmNlSW5Nb2R1bGUobW9kdWxlSWQsIG1vZHVsZUluc3RhbmNlSWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEluc3RhbmNlSW5Nb2R1bGUobW9kdWxlSWQsIG1vZHVsZUluc3RhbmNlSWQpO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIFBheW1lbnRzIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UGF5bWVudHNGb3JQYWNrYWdlKHBhY2thZ2VOYW1lKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRQYXltZW50c0ZvclBhY2thZ2UocGFja2FnZU5hbWUpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UGFja2FnZXNGb3JQcm9kdWN0KHByb2R1Y3RJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0UGFja2FnZXNGb3JQcm9kdWN0KHByb2R1Y3RJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRQcm9kdWN0c0Zvck1vZHVsZShtb2R1bGVJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0UHJvZHVjdHNGb3JNb2R1bGUobW9kdWxlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UHJvZHVjdHNGb3JDb3Vyc2UoaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0UHJvZHVjdHNGb3JDb3Vyc2UoaW5zdGFuY2VJZCk7XHJcbn1cclxuXHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIFBheW1lbnRzIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q29udGVzdENvbXBldGVSZXN1bHRzKGNvbnRlc3RJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0Q29udGVzdENvbXBldGVSZXN1bHRzKGNvbnRlc3RJZCk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgUXVpeiBEYXRhXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVF1aXpJbnN0YW5jZShwYXlsb2FkKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5jcmVhdGVRdWl6SW5zdGFuY2UocGF5bG9hZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhZGRRdWl6UXVlc3Rpb24ocXVpeklkLCBjb250ZW50KSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5hZGRRdWVzdGlvbihxdWl6SWQsIGNvbnRlbnQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYWRkUXVpelF1ZXN0aW9uQW5zd2VyKHF1ZXN0aW9uSWQsIGFuc3dlciwgaXNDb3JyZWN0KSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5hZGRBbnN3ZXIocXVlc3Rpb25JZCwgYW5zd2VyLCBpc0NvcnJlY3QpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWxsUXVpemVzQnlOYW1lKGNvbnRhaW5pbmdOYW1lLCBwYWdlU2l6ZSwgcGFnZSkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0QWxsUXVpemVzQnlOYW1lKGNvbnRhaW5pbmdOYW1lLCBwYWdlU2l6ZSwgcGFnZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRRdWVzdGlvbnNCeUlkKHF1aXpJZCwgcGFnZVNpemUsIHBhZ2UpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldFF1ZXN0aW9uc0J5SWQocXVpeklkLCBwYWdlU2l6ZSwgcGFnZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBbnN3ZXJzQnlRdWVzdGlvbklkKHF1ZXN0aW9uSWQsIHBhZ2VTaXplLCBwYWdlKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXRBbnN3ZXJzQnlRdWVzdGlvbklkKHF1ZXN0aW9uSWQsIHBhZ2VTaXplLCBwYWdlKTtcclxufVxyXG5cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgU3VydmV5IERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U3VydmV5cyhwYWdlLCBxdWVyeSwgcGFnZVNpemUpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldFN1cnZleXMocGFnZSwgcXVlcnksIHBhZ2VTaXplKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFN1cnZleXNCeU5hbWVBbmRTdGFydEFuZEVuZERhdGUocGFnZSwgbmFtZSwgc3RhcnREYXRlLCBlbmREYXRlLCBwYWdlU2l6ZSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0U3VydmV5c0J5TmFtZUFuZFN0YXJ0QW5kRW5kRGF0ZShwYWdlLCBuYW1lLCBzdGFydERhdGUsIGVuZERhdGUsIHBhZ2VTaXplKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFN1cnZleUJ5SWQoc3VydmV5SWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldFN1cnZleUJ5SWQoc3VydmV5SWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U3VydmV5QW5zd2VycyhzdXJ2ZXlJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0U3VydmV5QW5zd2VycyhzdXJ2ZXlJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTdXJ2ZXlUZW1wbGF0ZXMoKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRTdXJ2ZXlUZW1wbGF0ZXMoKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFN1cnZleVF1ZXN0aW9uc0J5VGVtcGxhdGVJZCh0ZW1wbGF0ZUlkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRTdXJ2ZXlRdWVzdGlvbnNCeVRlbXBsYXRlSWQodGVtcGxhdGVJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTdXJ2ZXlTZWN0aW9uc0J5VGVtcGxhdGVJZCh0ZW1wbGF0ZUlkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRTdXJ2ZXlTZWN0aW9uc0J5VGVtcGxhdGVJZCh0ZW1wbGF0ZUlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFN1cnZleVNlY3Rpb25zQnlJZChzZWN0aW9uSWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldFN1cnZleVNlY3Rpb25zQnlJZChzZWN0aW9uSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmluZFN1cnZleUJ5VHJhaW5pbmcobmFtZUJnKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5maW5kU3VydmV5QnlUcmFpbmluZyhuYW1lQmcpO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIFVzZXIgRGF0YVxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRUcmFpbmluZ3NCeVRyYWluZXIodXNlcklkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRUcmFpbmluZ3NCeVRyYWluZXIodXNlcklkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRyYWluZXJCeUlkKHVzZXJJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0VHJhaW5lckJ5SWQodXNlcklkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVRyYWluaW5nQnlUcmFpbmVyKHRyYWluaW5nKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC51cGRhdGVUcmFpbmluZ0J5VHJhaW5lcih0cmFpbmluZyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVUcmFpbmluZ0J5VHJhaW5lcih0cmFpbmluZykge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuY3JlYXRlVHJhaW5pbmdCeVRyYWluZXIodHJhaW5pbmcpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVzdHJveVRyYWluaW5nT2ZUcmFpbmVyKHRyYWluaW5nKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5kZXN0cm95VHJhaW5pbmdPZlRyYWluZXIodHJhaW5pbmcpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2VhcmNoVXNlcnMocXVlcnksIGV4Y2x1ZGUpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LnNlYXJjaFVzZXJzKHF1ZXJ5LCBleGNsdWRlKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRyYWluZXJzQnlUcmFpbmluZyh0cmFpbmluZ0lkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRUcmFpbmVyc0J5VHJhaW5pbmcodHJhaW5pbmdJZCk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgQ291cnNlIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2VhcmNoQnlOYW1lKGJvZHkpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LnNlYXJjaEJ5TmFtZShib2R5KTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNlYXJjaENvdXJzZXMocXVlcnkpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LnNlYXJjaENvdXJzZXMocXVlcnkpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q291cnNlRGF0YShjb3Vyc2VJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0Q291cnNlRGF0YShjb3Vyc2VJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb3Vyc2VJbnN0YW5jZXMoY291cnNlSWQsIGZpbHRlciA9IHVuZGVmaW5lZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0Q291cnNlSW5zdGFuY2VzKGNvdXJzZUlkLCBmaWx0ZXIgPSB1bmRlZmluZWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SW5zdGFuY2VEYXRhKGluc3RhbmNlSWQsIGNvdXJzZUlkLCB0eXBlKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRJbnN0YW5jZURhdGEoaW5zdGFuY2VJZCwgY291cnNlSWQsIHR5cGUpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlQ291cnNlKGNvdXJzZSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QudXBkYXRlQ291cnNlKGNvdXJzZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGRhdGVJbnN0YW5jZShpbnN0YW5jZSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QudXBkYXRlSW5zdGFuY2UoaW5zdGFuY2UpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U3R1ZGVudHMoaW5zdGFuY2VJZCwgdHlwZSA9ICdtYWluJykge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0U3R1ZGVudHMoaW5zdGFuY2VJZCwgdHlwZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb3Vyc2VFdmVudHMoaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0Q291cnNlRXZlbnRzKGluc3RhbmNlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QW55QnlJZChpbnN0YW5jZUlkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRBbnlCeUlkKGluc3RhbmNlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SW5zdGFuY2VQYWdlKGluc3RhbmNlSWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEluc3RhbmNlUGFnZShpbnN0YW5jZUlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEluc3RhbmNlRnVsbFBhZ2UodXJsKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRJbnN0YW5jZUZ1bGxQYWdlKHVybCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRUcmFpbmVyTmFtZXMoaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0VHJhaW5lck5hbWVzKGluc3RhbmNlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2VhcmNoQ291cnNlSW5zdGFuY2VzQnlDb3Vyc2VOYW1lQW5kSW5zdGFuY2VJZChjb3Vyc2VOYW1lLCBpbnN0YW5jZUlkLCBmaWx0ZXIgPSB1bmRlZmluZWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LnNlYXJjaENvdXJzZUluc3RhbmNlc0J5Q291cnNlTmFtZUFuZEluc3RhbmNlSWQoY291cnNlTmFtZSwgaW5zdGFuY2VJZCwgZmlsdGVyID0gdW5kZWZpbmVkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNlYXJjaFRyYWluaW5nc0J5TmFtZShuYW1lLCBleGFjdCA9IGZhbHNlKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5zZWFyY2hUcmFpbmluZ3NCeU5hbWUobmFtZSwgZXhhY3QpO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIEV4YW0gRGF0YVxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRFeGFtc0J5Q291cnNlKG5hbWVCZywgaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0RXhhbXNCeUNvdXJzZShuYW1lQmcsIGluc3RhbmNlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RXhhbXNCeU5hbWUocXVlcnkpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEV4YW1zQnlOYW1lKHF1ZXJ5KTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEV4YW1Hcm91cHNCeUV4YW1JZChleGFtSWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEV4YW1Hcm91cHNCeUV4YW1JZChleGFtSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RW5yb2xsZWRCeUdyb3VwSWQoZXhhbUdyb3VwSWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEVucm9sbGVkQnlHcm91cElkKGV4YW1Hcm91cElkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZUV4YW0oZXhhbSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuY3JlYXRlRXhhbShleGFtKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUV4YW0oZXhhbSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QudXBkYXRlRXhhbShleGFtKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZUV4YW1Hcm91cChncm91cCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuY3JlYXRlRXhhbUdyb3VwKGdyb3VwKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUV4YW1Hcm91cChncm91cCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QudXBkYXRlRXhhbUdyb3VwKGdyb3VwKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlc3Ryb3lFeGFtR3JvdXAoZ3JvdXApIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmRlc3Ryb3lFeGFtR3JvdXAoZ3JvdXApO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIEV2ZW50IERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RXZlbnRzKGluc3RhbmNlSWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEV2ZW50cyhpbnN0YW5jZUlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUV2ZW50KGV2ZW50KSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC51cGRhdGVFdmVudChldmVudCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVFdmVudChldmVudCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuY3JlYXRlRXZlbnQoZXZlbnQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVzdHJveUV2ZW50KGV2ZW50KSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5kZXN0cm95RXZlbnQoZXZlbnQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RXZlbnRzQnlEYXRlKHN0YXJ0RGF0ZSwgZW5kRGF0ZSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0RXZlbnRzQnlEYXRlKHN0YXJ0RGF0ZSwgZW5kRGF0ZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRFdmVudHNCeUlkKGV2ZW50SWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEV2ZW50c0J5SWQoZXZlbnRJZCk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgR3JvdXAgRGF0YVxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRJbnNhbmNlR3JvdXBzKGluc3RhbmNlSWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEluc2FuY2VHcm91cHMoaW5zdGFuY2VJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRHcm91cEJ5SWQoZ3JvdXBJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0R3JvdXBCeUlkKGdyb3VwSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlVHJhaW5pbmdHcm91cChncm91cCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuY3JlYXRlVHJhaW5pbmdHcm91cChncm91cCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXN0cm95R3JvdXAoZ3JvdXApIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmRlc3Ryb3lHcm91cChncm91cCk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgTGVjdHVyZSBEYXRhXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEluc3RhbmNlTGVjdHVyZXMoaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0SW5zdGFuY2VMZWN0dXJlcyhpbnN0YW5jZUlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUxlY3R1cmUobGVjdHVyZSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QudXBkYXRlTGVjdHVyZShsZWN0dXJlKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZUxlY3R1cmUobGVjdHVyZSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuY3JlYXRlTGVjdHVyZShsZWN0dXJlKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlc3Ryb3lMZWN0dXJlKGxlY3R1cmUpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmRlc3Ryb3lMZWN0dXJlKGxlY3R1cmUpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TGVjdHVyZURldGFpbHModHJhaW5pbmdJZCwgbGVjdHVyZUlkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRMZWN0dXJlRGV0YWlscyh0cmFpbmluZ0lkLCBsZWN0dXJlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TGVjdHVyZXNGb3JFeGFtc0J5VHJhaW5pbmdJZCh0cmFpbmluZ0lkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRMZWN0dXJlc0ZvckV4YW1zQnlUcmFpbmluZ0lkKHRyYWluaW5nSWQpO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIFNraWxsIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2tpbGxzQnlJbnN0YW5jZShuYW1lLCBpbnN0YW5jZUlkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRTa2lsbHNCeUluc3RhbmNlKG5hbWUsIGluc3RhbmNlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlU2tpbGwoc2tpbGwpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LnVwZGF0ZVNraWxsKHNraWxsKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVNraWxsKHNraWxsKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5jcmVhdGVTa2lsbChza2lsbCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXN0cm95U2tpbGwoc2tpbGwpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmRlc3Ryb3lTa2lsbChza2lsbCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZWFyY2hTa2lsbHMocXVlcnksIHR5cGUpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LnNlYXJjaFNraWxscyhxdWVyeSwgdHlwZSk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgU3RyZWFtIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SW5zdGFuY2VDb25maWcoaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0SW5zdGFuY2VDb25maWcoaW5zdGFuY2VJZCk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgQ1BFIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QXBwbGljYXRpb25zQnlJbnN0YW5jZUlkKGluc3RhbmNlSWQpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldEFwcGxpY2F0aW9uc0J5SW5zdGFuY2VJZChpbnN0YW5jZUlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFwcGxpY2F0aW9ucyhxdWVyeSwgcGFnZSkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0QXBwbGljYXRpb25zKHF1ZXJ5LCBwYWdlKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFwcFppcChpZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0QXBwWmlwKGlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFwcFN0YXR1cyhpZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0QXBwU3RhdHVzKGlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFwcFN0YXR1c0J5SW5zdGFuY2VJZChpZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0QXBwU3RhdHVzQnlJbnN0YW5jZUlkKGlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVN0YXR1cyhzdGF0dXMpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmNyZWF0ZVN0YXR1cyhzdGF0dXMpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlU3RhdHVzKHN0YXR1cykge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QudXBkYXRlU3RhdHVzKHN0YXR1cyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXN0cm95U3RhdHVzKHN0YXR1cykge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZGVzdHJveVN0YXR1cyhzdGF0dXMpO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIE5BVkVUIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRDdXJyZW50Q291cnNlcygpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldE5hdmV0Q3VycmVudENvdXJzZXMoKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE5hdmV0Q2xvc2VkQ291cnNlcygpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldE5hdmV0Q2xvc2VkQ291cnNlcygpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRBcmNoaXZlZENvdXJzZXMoKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXROYXZldEFyY2hpdmVkQ291cnNlcygpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRDb3Vyc2VJbmZvKGlkLCB0eXBlKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXROYXZldENvdXJzZUluZm8oaWQsIHR5cGUpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRTdHVkZW50cyhpZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0TmF2ZXRTdHVkZW50cyhpZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXROYXZldFN0dWRlbnRJbmZvKGNsaWVudElkKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXROYXZldFN0dWRlbnRJbmZvKGNsaWVudElkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE5hdmV0RXhpc3RpbmdGaWxlcyhjb3Vyc2VJZCwgaWQpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldE5hdmV0RXhpc3RpbmdGaWxlcyhjb3Vyc2VJZCwgaWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBsb2FkTWVkaWNhbChjb3Vyc2VJZCwgaWQsIGZpbGVEZXNjcmlwdG9yKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC51cGxvYWRNZWRpY2FsKGNvdXJzZUlkLCBpZCwgZmlsZURlc2NyaXB0b3IpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBsb2FkRGlwbG9tYShjb3Vyc2VJZCwgaWQsIGZpbGVEZXNjcmlwdG9yLCByZWdfbm8sIHBybl9ubywgZG9jX2RhdGUpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LnVwbG9hZERpcGxvbWEoY291cnNlSWQsIGlkLCBmaWxlRGVzY3JpcHRvciwgcmVnX25vLCBwcm5fbm8sIGRvY19kYXRlKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG9wZW5OYXZldEZpbGUoaWQpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0Lm9wZW5OYXZldEZpbGUoaWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVsZXRlTmF2ZXRGaWxlKGlkKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5kZWxldGVOYXZldEZpbGUoaWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0R3JhZHVhdGVJbmZvKGlkKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXRHcmFkdWF0ZUluZm8oaWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRDZXJ0aWZpY2F0ZShpZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0TmF2ZXRDZXJ0aWZpY2F0ZShpZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBvcGVuTmF2ZXRDZXJ0aWZpY2F0ZShpZCwgcGFnZSkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3Qub3Blbk5hdmV0Q2VydGlmaWNhdGUoaWQsIHBhZ2UpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBsb2FkTmF2ZXRDZXJ0aWZpY2F0ZShtZXRhLCBmaWxlRGVzY3JpcHRvcnMpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LnVwbG9hZE5hdmV0Q2VydGlmaWNhdGUobWV0YSwgZmlsZURlc2NyaXB0b3JzKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZU5hdmV0U3R1ZGVudChpZCwgc3R1ZGVudCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QudXBkYXRlTmF2ZXRTdHVkZW50KGlkLCBzdHVkZW50KTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZURvY3VtZW50KHN0dWRlbnRJZCwgY2xpZW50SWQsIGRhdGEpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmNyZWF0ZURvY3VtZW50KHN0dWRlbnRJZCwgY2xpZW50SWQsIGRhdGEpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RXh0cmFDb3Vyc2VJbmZvKGlkKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXRFeHRyYUNvdXJzZUluZm8oaWQpO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIEdlbmVyaWMgRGF0YSBTdG9yZVxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTdG9yZVNldHRpbmdzKHN0b3JlSWQpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldFN0b3JlU2V0dGluZ3Moc3RvcmVJZCk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgVGVtcGxhdGVzIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VGVtcGxhdGVTdG9yZVNldHRpbmdzKCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0VGVtcGxhdGVTdG9yZVNldHRpbmdzKCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRUZW1wbGF0ZXMoKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXRUZW1wbGF0ZXMoKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRlbXBsYXRlQnlOYW1lKG5hbWUpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldFRlbXBsYXRlQnlOYW1lKG5hbWUpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VGVtcGxhdGVCeUluc3RhbmNlSWQoaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0VGVtcGxhdGVCeUluc3RhbmNlSWQoaW5zdGFuY2VJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzYXZlVGVtcGxhdGUodGVtcGxhdGUpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LnNhdmVUZW1wbGF0ZSh0ZW1wbGF0ZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWxldGVUZW1wbGF0ZSh0ZW1wbGF0ZSkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZGVsZXRlVGVtcGxhdGUodGVtcGxhdGUpO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIEFzc2Vzc21lbnQgRGF0YVxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRIb21ld29ya1Jlc3VsdHMoaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0SG9tZXdvcmtSZXN1bHRzKGluc3RhbmNlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UHJvdG9jb2woaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0UHJvdG9jb2woaW5zdGFuY2VJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGxvYWRFeGFtUmVzdWx0cyhleGFtTmFtZSwgZXhhbUlkLCBjb21ibywgZmlsZURlc2NyaXB0b3IpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LnVwbG9hZEV4YW1SZXN1bHRzKGV4YW1OYW1lLCBleGFtSWQsIGNvbWJvLCBmaWxlRGVzY3JpcHRvcik7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb25maWdzKGV4YW1JZHMpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldENvbmZpZ3MoZXhhbUlkcyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb25maWdCeUV4YW1JZChleGFtSWQpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldENvbmZpZ0J5RXhhbUlkKGV4YW1JZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzYXZlQ29uZmlnKGNvbmZpZykge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3Quc2F2ZUNvbmZpZyhjb25maWcpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVsZXRlQ29uZmlnKGNvbmZpZykge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZGVsZXRlQ29uZmlnKGNvbmZpZyk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgU2VtaW5hciBEYXRhXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2VtaW5hcnNCeURhdGUoc3RhcnREYXRlLCBlbmREYXRlKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXRTZW1pbmFyc0J5RGF0ZShzdGFydERhdGUsIGVuZERhdGUpO1xyXG59IiwiZXhwb3J0IGNsYXNzIENvbnRlbnRUeXBlIHtcclxuICAgIC8vIFByaXZhdGUgRmllbGRzXHJcbiAgICBzdGF0aWMgI19VcmxGb3JtRW5jb2RlZCA9ICdhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWQ7IGNoYXJzZXQ9VVRGLTgnO1xyXG4gICAgc3RhdGljICNfQXBwbGljdGlvbkpzb24gPSAnYXBwbGljYXRpb24vanNvbic7XHJcblxyXG4gICAgLy8gQWNjZXNzb3JzIGZvciBcImdldFwiIGZ1bmN0aW9ucyBvbmx5IChubyBcInNldFwiIGZ1bmN0aW9ucylcclxuICAgIHN0YXRpYyBnZXQgVXJsRm9ybUVuY29kZWQoKSB7IHJldHVybiB0aGlzLiNfVXJsRm9ybUVuY29kZWQ7IH1cclxuICAgIHN0YXRpYyBnZXQgQXBwbGljYXRpb25Kc29uKCkgeyByZXR1cm4gdGhpcy4jX0FwcGxpY3Rpb25Kc29uOyB9XHJcbn0iLCJpbXBvcnQgeyB1dWlkIH0gZnJvbSAnLi9wYXJzZSc7XHJcblxyXG5jb25zdCBkaXNwYXRjaCA9IHt9O1xyXG5cclxuY29uc3Qgc3RvcmVzID0ge1xyXG4gICAgTUFJTl9NT0RVTEVTOiAnU1RPUkVfTUFJTl9NT0RVTEVTJyxcclxuICAgIE1PRFVMRVM6ICdTVE9SRV9NT0RVTEVTJyxcclxuICAgIE1PRFVMRV9JTlNUQU5DRVM6ICdTVE9SRV9NT0RVTEVfSU5TVEFOQ0VTJyxcclxuICAgIFBBWU1FTlRTOiAnU1RPUkVfUEFZTUVOVFMnLFxyXG4gICAgVFJBSU5JTkdfSEFMTFM6ICdUUkFJTklOR19IQUxMUycsXHJcbiAgICBDT1VSU0VfSU5GTzogJ0NPVVJTRV9JTkZPJyxcclxuICAgIFNUUkVBTV9DT05GSUc6ICdTVFJFQU1fQ09ORklHJyxcclxuICAgIFNVUlZFWVM6ICdTVVJWRVlTJyxcclxuICAgIFNVUlZFWVNfQUxMOiAnU1VSVkVZU19BTEwnLFxyXG4gICAgU1VSVkVZOiAnU1VSVkVZX0lEXycsXHJcbiAgICBURU1QTEFURV9DT05GSUc6ICdURU1QTEFURV9DT05GSUcnLFxyXG4gICAgU1RBVElTVElDU19DT05GSUc6ICdTVEFUSVNUSUNTX0NPTkZJRydcclxufTtcclxuXHJcbmNvbnN0IGJnUG9ydCA9IGJyb3dzZXIucnVudGltZS5jb25uZWN0KHtcclxuICAgIG5hbWU6ICdzZXMtZGF0YS1wb3J0J1xyXG59KTtcclxuXHJcbmJnUG9ydC5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIob25NZXNzYWdlKTtcclxuXHJcbi8qKlxyXG4gKiBDcmVhdGUgZnVuY3Rpb24gd2l0aCBjYWNoZWQgcmVzcG9uc2VcclxuICogQHBhcmFtIHtGdW5jdGlvbn0gZnVuYyBGdW5jdGlvbiBjYWxsIHRvIGNhY2hlXHJcbiAqIEBwYXJhbSB7U3ltYm9sfSBzdG9yZUlkIFN0b3JlIGlkZW50aWZpZXJcclxuICogQHBhcmFtIHtOdW1iZXI9fSBtYXhBZ2UgQ2FjaGUgYWdlIHRocmVzaG9sZCwgaW4gc2Vjb25kcy4gSWYgb21pdHRlZCwgdGhlIGNhY2hlIGlzIGNvbnNpZGVyZWQgbm9uLWV4cGlyaW5nIChyZXNldHMgb24gcmVpbnN0YWxsaW5nL3VwZGF0aW5nIGV4dGVuc2lvbilcclxuICovXHJcbmZ1bmN0aW9uIHdpdGhDYWNoZShmdW5jLCBzdG9yZUlkLCBtYXhBZ2UpIHtcclxuXHJcbiAgICByZXR1cm4gZnVuY3Rpb24gKC4uLnBhcmFtcykge1xyXG4gICAgICAgIGNvbnN0IGNhbGxiYWNrcyA9IHt9O1xyXG5cclxuICAgICAgICBjb25zdCBwcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgICAgICBjYWxsYmFja3MucmVzb2x2ZSA9IHJlc29sdmU7XHJcbiAgICAgICAgICAgIGNhbGxiYWNrcy5yZWplY3QgPSByZWplY3Q7XHJcblxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBleGVjdXRvcigpO1xyXG4gICAgICAgIHJldHVybiBwcm9taXNlO1xyXG5cclxuICAgICAgICBhc3luYyBmdW5jdGlvbiBleGVjdXRvcigpIHtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGxldCByYXdDYWNoZSA9IGF3YWl0IGdldERhdGEoc3RvcmVJZCk7XHJcbiAgICAgICAgICAgICAgICBpZiAocmF3Q2FjaGUuZGF0YSAhPT0gdW5kZWZpbmVkICYmIGlzRnJlc2gocmF3Q2FjaGUud2hlbiwgbWF4QWdlKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHByb21pc2UuX2NhY2hlSGl0ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICBjYWxsYmFja3MucmVzb2x2ZShyYXdDYWNoZS5kYXRhKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBhd2FpdCBmdW5jKC4uLnBhcmFtcyk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0RGF0YShzdG9yZUlkLCB2YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2tzLnJlc29sdmUodmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgICAgIGNhbGxiYWNrcy5yZWplY3QoZXJyKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH07XHJcbn07XHJcblxyXG5mdW5jdGlvbiBpc0ZyZXNoKGNyZWF0aW9uRGF0ZSwgbWF4QWdlKSB7XHJcbiAgICBpZiAobWF4QWdlID09PSB1bmRlZmluZWQpIHtcclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH0gZWxzZSBpZiAoKERhdGUubm93KCkgLSBjcmVhdGlvbkRhdGUpIC8gMTAwMCA8PSBtYXhBZ2UpIHtcclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBjbGVhckNhY2hlKG5hbWUpIHtcclxuICAgIGJnUG9ydC5wb3N0TWVzc2FnZSh7XHJcbiAgICAgICAgY2xlYXI6IG5hbWVcclxuICAgIH0pO1xyXG59XHJcblxyXG4vKipcclxuICogUmV0cmlldmUgZGF0YSBmcm9tIHRoZSBiYWNrZ3JvdW5kIHN0b3JlXHJcbiAqIEBwYXJhbSB7U3RyaW5nfSBuYW1lIEl0ZW0gbmFtZVxyXG4gKi9cclxuZnVuY3Rpb24gZ2V0RGF0YShuYW1lKSB7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UocmVzb2x2ZSA9PiB7XHJcbiAgICAgICAgY29uc3QgX3V1aWQgPSB1dWlkKCk7XHJcbiAgICAgICAgYmdQb3J0LnBvc3RNZXNzYWdlKHtcclxuICAgICAgICAgICAgX3V1aWQsXHJcbiAgICAgICAgICAgIGdldDogbmFtZVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBkaXNwYXRjaFtfdXVpZF0gPSByZXNvbHZlO1xyXG4gICAgfSk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBTYXZlIGRhdGEgaW4gdGhlIGJhY2tncm91bmQgc3RvcmVcclxuICogQHBhcmFtIHtTdHJpbmd9IG5hbWUgSXRlbSBuYW1lXHJcbiAqIEBwYXJhbSB7Kn0gZGF0YSBEYXRhIHRvIHNhdmUgaW4gdGhlIHN0b3JlXHJcbiAqL1xyXG5mdW5jdGlvbiBzZXREYXRhKG5hbWUsIGRhdGEpIHtcclxuICAgIGJnUG9ydC5wb3N0TWVzc2FnZSh7XHJcbiAgICAgICAgc2V0OiBuYW1lLFxyXG4gICAgICAgIGRhdGFcclxuICAgIH0pO1xyXG59XHJcblxyXG5mdW5jdGlvbiBvbk1lc3NhZ2UobSkge1xyXG4gICAgY29uc3QgdXVpZCA9IG0uX3V1aWQ7XHJcbiAgICBkZWxldGUgbS5fdXVpZDtcclxuICAgIGRpc3BhdGNoW3V1aWRdKG0pO1xyXG4gICAgZGVsZXRlIGRpc3BhdGNoW3V1aWRdO1xyXG59XHJcblxyXG5cclxuZXhwb3J0IHtcclxuICAgIHN0b3JlcyxcclxuICAgIHdpdGhDYWNoZSxcclxuICAgIGNsZWFyQ2FjaGUsXHJcbiAgICBnZXREYXRhLFxyXG4gICAgc2V0RGF0YVxyXG59OyIsImltcG9ydCB7IGlzU1ZHLCBjcmVhdGVGcmFnbWVudEZyb20sIEVWRU5UX0xJU1RFTkVSUyB9IGZyb20gJy4vdXRpbHMnO1xyXG5cclxuLyoqXHJcbiAqIFRoZSB0YWcgbmFtZSBhbmQgY3JlYXRlIGFuIGh0bWwgdG9nZXRoZXIgd2l0aCB0aGUgYXR0cmlidXRlc1xyXG4gKlxyXG4gKiBAcGFyYW0gIHtTdHJpbmd9IHRhZ05hbWUgbmFtZSBhcyBzdHJpbmcsIGUuZy4gJ2RpdicsICdzcGFuJywgJ3N2ZydcclxuICogQHBhcmFtICB7T2JqZWN0fSBhdHRycyBodG1sIGF0dHJpYnV0ZXMgZS5nLiBkYXRhLSwgd2lkdGgsIHNyY1xyXG4gKiBAcGFyYW0gIHtBcnJheX0gY2hpbGRyZW4gaHRtbCBub2RlcyBmcm9tIGluc2lkZSBkZSBlbGVtZW50c1xyXG4gKiBAcmV0dXJuIHtIVE1MRWxlbWVudHxTVkdFbGVtZW50fSBodG1sIG5vZGUgd2l0aCBhdHRyc1xyXG4gKi9cclxuZnVuY3Rpb24gY3JlYXRlRWxlbWVudHModGFnTmFtZSwgYXR0cnMsIGNoaWxkcmVuKSB7XHJcbiAgICBjb25zdCBlbGVtZW50ID0gaXNTVkcodGFnTmFtZSlcclxuICAgICAgICA/IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnROUygnaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnLCB0YWdOYW1lKVxyXG4gICAgICAgIDogZG9jdW1lbnQuY3JlYXRlRWxlbWVudCh0YWdOYW1lKTtcclxuXHJcbiAgICAvLyBvbmUgb3IgbXVsdGlwbGUgd2lsbCBiZSBldmFsdWF0ZWQgdG8gYXBwZW5kIGFzIHN0cmluZyBvciBIVE1MRWxlbWVudFxyXG4gICAgY29uc3QgZnJhZ21lbnQgPSBjcmVhdGVGcmFnbWVudEZyb20oY2hpbGRyZW4pO1xyXG4gICAgZWxlbWVudC5hcHBlbmRDaGlsZChmcmFnbWVudCk7XHJcblxyXG4gICAgT2JqZWN0LmtleXMoYXR0cnMgfHwge30pLmZvckVhY2gocHJvcCA9PiB7XHJcbiAgICAgICAgaWYgKHByb3AgPT09ICdzdHlsZScpIHtcclxuICAgICAgICAgICAgLy8gZS5nLiBvcmlnaW46IDxlbGVtZW50IHN0eWxlPXt7IHByb3A6IHZhbHVlIH19IC8+XHJcbiAgICAgICAgICAgIE9iamVjdC5hc3NpZ24oZWxlbWVudC5zdHlsZSwgYXR0cnNbcHJvcF0pO1xyXG4gICAgICAgIH0gZWxzZSBpZiAocHJvcCA9PT0gJ3JlZicgJiYgdHlwZW9mIGF0dHJzLnJlZiA9PT0gJ2Z1bmN0aW9uJykge1xyXG4gICAgICAgICAgICBhdHRycy5yZWYoZWxlbWVudCwgYXR0cnMpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAocHJvcCA9PT0gJ2NsYXNzTmFtZScpIHtcclxuICAgICAgICAgICAgZWxlbWVudC5zZXRBdHRyaWJ1dGUoJ2NsYXNzJywgYXR0cnNbcHJvcF0pO1xyXG4gICAgICAgIH0gZWxzZSBpZiAocHJvcCA9PT0gJ3hsaW5rSHJlZicpIHtcclxuICAgICAgICAgICAgZWxlbWVudC5zZXRBdHRyaWJ1dGVOUygnaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluaycsICd4bGluazpocmVmJywgYXR0cnNbcHJvcF0pO1xyXG4gICAgICAgIH0gZWxzZSBpZiAocHJvcCA9PT0gJ2Rhbmdlcm91c2x5U2V0SW5uZXJIVE1MJykge1xyXG4gICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tdW5kZXJzY29yZS1kYW5nbGVcclxuICAgICAgICAgICAgZWxlbWVudC5pbm5lckhUTUwgPSBhdHRyc1twcm9wXS5fX2h0bWw7XHJcbiAgICAgICAgfSBlbHNlIGlmIChwcm9wIGluIEVWRU5UX0xJU1RFTkVSUykge1xyXG4gICAgICAgICAgICBlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoRVZFTlRfTElTVEVORVJTW3Byb3BdLCBhdHRyc1twcm9wXSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgLy8gYW55IG90aGVyIHByb3Agd2lsbCBiZSBzZXQgYXMgYXR0cmlidXRlXHJcbiAgICAgICAgICAgIGVsZW1lbnQuc2V0QXR0cmlidXRlKHByb3AsIGF0dHJzW3Byb3BdKTtcclxuICAgICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gZWxlbWVudDtcclxufVxyXG5cclxuLyoqXHJcbiAqIFRoZSBKU1hUYWcgd2lsbCBiZSB1bndyYXBwZWQgcmV0dXJuaW5nIHRoZSBodG1sXHJcbiAqXHJcbiAqIEBwYXJhbSAge0Z1bmN0aW9ufSBKU1hUYWcgbmFtZSBhcyBzdHJpbmcsIGUuZy4gJ2RpdicsICdzcGFuJywgJ3N2ZydcclxuICogQHBhcmFtICB7T2JqZWN0fSBlbGVtZW50UHJvcHMgY3VzdG9tIGpzeCBhdHRyaWJ1dGVzIGUuZy4gZm4sIHN0cmluZ3NcclxuICogQHBhcmFtICB7QXJyYXl9IGNoaWxkcmVuIGh0bWwgbm9kZXMgZnJvbSBpbnNpZGUgZGUgZWxlbWVudHNcclxuICpcclxuICogQHJldHVybiB7RnVuY3Rpb259IHJldHVybnMgZGUgJ2RvbScgKGZuKSBleGVjdXRlZCwgbGVhdmluZyB0aGUgSFRNTEVsZW1lbnRcclxuICpcclxuICogSlNYVGFnOiAgZnVuY3Rpb24gQ29tcChwcm9wcykge1xyXG4gKiAgIHJldHVybiBkb20oXCJzcGFuXCIsIG51bGwsIHByb3BzLm51bSk7XHJcbiAqIH1cclxuICovXHJcbmZ1bmN0aW9uIGNvbXBvc2VUb0Z1bmN0aW9uKEpTWFRhZywgZWxlbWVudFByb3BzLCBjaGlsZHJlbikge1xyXG4gICAgY29uc3QgcHJvcHMgPSBPYmplY3QuYXNzaWduKHt9LCBKU1hUYWcuZGVmYXVsdFByb3BzIHx8IHt9LCBlbGVtZW50UHJvcHMsIHsgY2hpbGRyZW4gfSk7XHJcbiAgICBjb25zdCBicmlkZ2UgPSAoSlNYVGFnLnByb3RvdHlwZSAmJiBKU1hUYWcucHJvdG90eXBlLnJlbmRlcikgPyBuZXcgSlNYVGFnKHByb3BzKS5yZW5kZXIgOiBKU1hUYWc7XHJcbiAgICBjb25zdCByZXN1bHQgPSBicmlkZ2UocHJvcHMpO1xyXG5cclxuICAgIHN3aXRjaCAocmVzdWx0KSB7XHJcbiAgICAgICAgY2FzZSAnRlJBR01FTlQnOlxyXG4gICAgICAgICAgICByZXR1cm4gY3JlYXRlRnJhZ21lbnRGcm9tKGNoaWxkcmVuKTtcclxuXHJcbiAgICAgICAgLy8gUG9ydGFscyBhcmUgdXNlZnVsIHRvIHJlbmRlciBtb2RhbHNcclxuICAgICAgICAvLyBhbGxvdyByZW5kZXIgb24gYSBkaWZmZXJlbnQgZWxlbWVudCB0aGFuIHRoZSBwYXJlbnQgb2YgdGhlIGNoYWluXHJcbiAgICAgICAgLy8gYW5kIGxlYXZlIGEgY29tbWVudCBpbnN0ZWFkXHJcbiAgICAgICAgY2FzZSAnUE9SVEFMJzpcclxuICAgICAgICAgICAgYnJpZGdlLnRhcmdldC5hcHBlbmRDaGlsZChjcmVhdGVGcmFnbWVudEZyb20oY2hpbGRyZW4pKTtcclxuICAgICAgICAgICAgcmV0dXJuIGRvY3VtZW50LmNyZWF0ZUNvbW1lbnQoJ1BvcnRhbCBVc2VkJyk7XHJcbiAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgIH1cclxufVxyXG5cclxuZnVuY3Rpb24gZG9tKGVsZW1lbnQsIGF0dHJzLCAuLi5jaGlsZHJlbikge1xyXG4gICAgLy8gQ3VzdG9tIENvbXBvbmVudHMgd2lsbCBiZSBmdW5jdGlvbnNcclxuICAgIGlmICh0eXBlb2YgZWxlbWVudCA9PT0gJ2Z1bmN0aW9uJykge1xyXG4gICAgICAgIGlmIChlbGVtZW50Lmhhc093blByb3BlcnR5KCdwcm9wVHlwZXMnKSkge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBwcm9wIG9mIGVsZW1lbnQucHJvcFR5cGVzKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoYXR0cnMuaGFzT3duUHJvcGVydHkocHJvcCkgPT09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihgSlNYIEVycm9yOiBNaXNzaW5nIHByb3BlcnR5ICcke3Byb3B9JyBmcm9tICcke2VsZW1lbnQubmFtZX0nIGludm9jYXRpb25gKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAvLyBlLmcuIGNvbnN0IEN1c3RvbVRhZyA9ICh7IHcgfSkgPT4gPHNwYW4gd2lkdGg9e3d9IC8+XHJcbiAgICAgICAgLy8gd2lsbCBiZSB1c2VkXHJcbiAgICAgICAgLy8gZS5nLiA8Q3VzdG9tVGFnIHc9ezF9IC8+XHJcbiAgICAgICAgLy8gYmVjb21lczogQ3VzdG9tVGFnKHsgdzogMX0pXHJcbiAgICAgICAgcmV0dXJuIGNvbXBvc2VUb0Z1bmN0aW9uKGVsZW1lbnQsIGF0dHJzLCBjaGlsZHJlbik7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gcmVndWxhciBodG1sIGNvbXBvbmVudHMgd2lsbCBiZSBzdHJpbmdzIHRvIGNyZWF0ZSB0aGUgZWxlbWVudHNcclxuICAgIC8vIHRoaXMgaXMgaGFuZGxlZCBieSB0aGUgYmFiZWwgcGx1Z2luc1xyXG4gICAgaWYgKHR5cGVvZiBlbGVtZW50ID09PSAnc3RyaW5nJykge1xyXG4gICAgICAgIHJldHVybiBjcmVhdGVFbGVtZW50cyhlbGVtZW50LCBhdHRycywgY2hpbGRyZW4pO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBjb25zb2xlLmVycm9yKGBqc3gtcmVuZGVyIGRvZXMgbm90IGhhbmRsZSAke3R5cGVvZiB0YWd9YCk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGRvbTtcclxuZXhwb3J0IGNvbnN0IEZyYWdtZW50ID0gKCkgPT4gJ0ZSQUdNRU5UJztcclxuZXhwb3J0IGNvbnN0IHBvcnRhbENyZWF0b3IgPSBub2RlID0+IHtcclxuICAgIGZ1bmN0aW9uIFBvcnRhbCgpIHtcclxuICAgICAgICByZXR1cm4gJ1BPUlRBTCc7XHJcbiAgICB9XHJcblxyXG4gICAgUG9ydGFsLnRhcmdldCA9IGRvY3VtZW50LmJvZHk7XHJcblxyXG4gICAgaWYgKG5vZGUgJiYgbm9kZS5ub2RlVHlwZSA9PT0gTm9kZS5FTEVNRU5UX05PREUpIHtcclxuICAgICAgICBQb3J0YWwudGFyZ2V0ID0gbm9kZTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gUG9ydGFsO1xyXG59O1xyXG4iLCJleHBvcnQgZnVuY3Rpb24gaXNTVkcoZWxlbWVudCkge1xyXG4gICAgY29uc3QgcGF0dCA9IG5ldyBSZWdFeHAoYF4ke2VsZW1lbnR9JGAsICdpJyk7XHJcbiAgICBjb25zdCBTVkdUYWdzID0gWydwYXRoJywgJ3N2ZycsICd1c2UnLCAnZyddO1xyXG5cclxuICAgIHJldHVybiBTVkdUYWdzLnNvbWUodGFnID0+IHBhdHQudGVzdCh0YWcpKTtcclxufVxyXG5cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVGcmFnbWVudEZyb20oY2hpbGRyZW4pIHtcclxuICAgIC8vIGZyYWdtZW50cyB3aWxsIGhlbHAgbGF0ZXIgdG8gYXBwZW5kIG11bHRpcGxlIGNoaWxkcmVuIHRvIHRoZSBpbml0aWFsIG5vZGVcclxuICAgIGNvbnN0IGZyYWdtZW50ID0gZG9jdW1lbnQuY3JlYXRlRG9jdW1lbnRGcmFnbWVudCgpO1xyXG5cclxuICAgIGZ1bmN0aW9uIHByb2Nlc3NET01Ob2RlcyhjaGlsZCkge1xyXG4gICAgICAgIGlmIChcclxuICAgICAgICAgICAgY2hpbGQgaW5zdGFuY2VvZiBIVE1MRWxlbWVudCB8fFxyXG4gICAgICAgICAgICBjaGlsZCBpbnN0YW5jZW9mIFNWR0VsZW1lbnQgfHxcclxuICAgICAgICAgICAgY2hpbGQgaW5zdGFuY2VvZiBDb21tZW50IHx8XHJcbiAgICAgICAgICAgIGNoaWxkIGluc3RhbmNlb2YgRG9jdW1lbnRGcmFnbWVudFxyXG4gICAgICAgICkge1xyXG4gICAgICAgICAgICBmcmFnbWVudC5hcHBlbmRDaGlsZChjaGlsZCk7XHJcbiAgICAgICAgfSBlbHNlIGlmICh0eXBlb2YgY2hpbGQgPT09ICdzdHJpbmcnIHx8IHR5cGVvZiBjaGlsZCA9PT0gJ251bWJlcicpIHtcclxuICAgICAgICAgICAgY29uc3QgdGV4dG5vZGUgPSBkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZShjaGlsZCk7XHJcbiAgICAgICAgICAgIGZyYWdtZW50LmFwcGVuZENoaWxkKHRleHRub2RlKTtcclxuICAgICAgICB9IGVsc2UgaWYgKGNoaWxkIGluc3RhbmNlb2YgQXJyYXkpIHtcclxuICAgICAgICAgICAgY2hpbGQuZm9yRWFjaChwcm9jZXNzRE9NTm9kZXMpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoY2hpbGQgPT09IGZhbHNlIHx8IGNoaWxkID09PSBudWxsKSB7XHJcbiAgICAgICAgICAgIC8vIGV4cHJlc3Npb24gZXZhbHVhdGVkIGFzIGZhbHNlIGUuZy4ge2ZhbHNlICYmIDxFbGVtIC8+fVxyXG4gICAgICAgICAgICAvLyBleHByZXNzaW9uIGV2YWx1YXRlZCBhcyBmYWxzZSBlLmcuIHtudWxsICYmIDxFbGVtIC8+fVxyXG4gICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIGNoaWxkID09PSAnZnVuY3Rpb24nKSB7XHJcblxyXG4gICAgICAgIH0gZWxzZSBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdkZXZlbG9wbWVudCcpIHtcclxuICAgICAgICAgICAgLy8gbGF0ZXIgb3RoZXIgdGhpbmdzIGNvdWxkIG5vdCBiZSBIVE1MRWxlbWVudCBub3Igc3RyaW5nc1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhjaGlsZCwgJ2lzIG5vdCBhcHBlbmRhYmxlJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGNoaWxkcmVuLmZvckVhY2gocHJvY2Vzc0RPTU5vZGVzKTtcclxuXHJcbiAgICByZXR1cm4gZnJhZ21lbnQ7XHJcbn1cclxuXHJcbi8vIE1hcCBmcm9tIEpTWCBwcm9wZXJ0eSAoZS5nLiBvbkNsaWNrKSB0byBldmVudCBuYW1lIChlLmcuICdjbGljaycpLlxyXG5leHBvcnQgY29uc3QgRVZFTlRfTElTVEVORVJTID0ge1xyXG4gICAgLy8gQ2xpcGJvYXJkIEV2ZW50c1xyXG4gICAgb25Db3B5OiAnY29weScsXHJcbiAgICBvbkN1dDogJ2N1dCcsXHJcbiAgICBvblBhc3RlOiAncGFzdGUnLFxyXG5cclxuICAgIC8vIENvbXBvc2l0aW9uIEV2ZW50c1xyXG4gICAgb25Db21wb3NpdGlvbkVuZDogJ2NvbXBvc2l0aW9uZW5kJyxcclxuICAgIG9uQ29tcG9zaXRpb25TdGFydDogJ2NvbXBvc2l0aW9uc3RhcnQnLFxyXG4gICAgb25Db21wb3NpdGlvblVwZGF0ZTogJ2NvbXBvc2l0aW9udXBkYXRlJyxcclxuXHJcbiAgICAvLyBGb2N1cyBFdmVudHNcclxuICAgIG9uRm9jdXM6ICdmb2N1cycsXHJcbiAgICBvbkJsdXI6ICdibHVyJyxcclxuXHJcbiAgICAvLyBGb3JtIEV2ZW50c1xyXG4gICAgb25DaGFuZ2U6ICdjaGFuZ2UnLFxyXG4gICAgb25CZWZvcmVJbnB1dDogJ2JlZm9yZWlucHV0JyxcclxuICAgIG9uSW5wdXQ6ICdpbnB1dCcsXHJcbiAgICBvblJlc2V0OiAncmVzZXQnLFxyXG4gICAgb25TdWJtaXQ6ICdzdWJtaXQnLFxyXG4gICAgb25JbnZhbGlkOiAnaW52YWxpZCcsXHJcblxyXG4gICAgLy8gSW1hZ2UgRXZlbnRzXHJcbiAgICBvbkxvYWQ6ICdsb2FkJyxcclxuICAgIG9uRXJyb3I6ICdlcnJvcicsXHJcblxyXG4gICAgLy8gS2V5Ym9hcmQgRXZlbnRzXHJcbiAgICBvbktleURvd246ICdrZXlkb3duJyxcclxuICAgIG9uS2V5UHJlc3M6ICdrZXlwcmVzcycsXHJcbiAgICBvbktleVVwOiAna2V5dXAnLFxyXG5cclxuICAgIC8vIE1lZGlhIEV2ZW50c1xyXG4gICAgb25BYm9ydDogJ2Fib3J0JyxcclxuICAgIG9uQ2FuUGxheTogJ2NhbnBsYXknLFxyXG4gICAgb25DYW5QbGF5VGhyb3VnaDogJ2NhbnBsYXl0aHJvdWdoJyxcclxuICAgIG9uRHVyYXRpb25DaGFuZ2U6ICdkdXJhdGlvbmNoYW5nZScsXHJcbiAgICBvbkVtcHRpZWQ6ICdlbXB0aWVkJyxcclxuICAgIG9uRW5jcnlwdGVkOiAnZW5jcnlwdGVkJyxcclxuICAgIG9uRW5kZWQ6ICdlbmRlZCcsXHJcbiAgICBvbkxvYWRlZERhdGE6ICdsb2FkZWRkYXRhJyxcclxuICAgIG9uTG9hZGVkTWV0YWRhdGE6ICdsb2FkZWRtZXRhZGF0YScsXHJcbiAgICBvbkxvYWRTdGFydDogJ2xvYWRzdGFydCcsXHJcbiAgICBvblBhdXNlOiAncGF1c2UnLFxyXG4gICAgb25QbGF5OiAncGxheScsXHJcbiAgICBvblBsYXlpbmc6ICdwbGF5aW5nJyxcclxuICAgIG9uUHJvZ3Jlc3M6ICdwcm9ncmVzcycsXHJcbiAgICBvblJhdGVDaGFuZ2U6ICdyYXRlY2hhbmdlJyxcclxuICAgIG9uU2Vla2VkOiAnc2Vla2VkJyxcclxuICAgIG9uU2Vla2luZzogJ3NlZWtpbmcnLFxyXG4gICAgb25TdGFsbGVkOiAnc3RhbGxlZCcsXHJcbiAgICBvblN1c3BlbmQ6ICdzdXNwZW5kJyxcclxuICAgIG9uVGltZVVwZGF0ZTogJ3RpbWV1cGRhdGUnLFxyXG4gICAgb25Wb2x1bWVDaGFuZ2U6ICd2b2x1bWVjaGFuZ2UnLFxyXG4gICAgb25XYWl0aW5nOiAnd2FpdGluZycsXHJcblxyXG4gICAgLy8gTW91c2VFdmVudHNcclxuICAgIG9uQ2xpY2s6ICdjbGljaycsXHJcbiAgICBvbkNvbnRleHRNZW51OiAnY29udGV4dG1lbnUnLFxyXG4gICAgb25Eb3VibGVDbGljazogJ2RvdWJsZWNsaWNrJyxcclxuICAgIG9uRHJhZzogJ2RyYWcnLFxyXG4gICAgb25EcmFnRW5kOiAnZHJhZ2VuZCcsXHJcbiAgICBvbkRyYWdFbnRlcjogJ2RyYWdlbnRlcicsXHJcbiAgICBvbkRyYWdFeGl0OiAnZHJhZ2V4aXQnLFxyXG4gICAgb25EcmFnTGVhdmU6ICdkcmFnbGVhdmUnLFxyXG4gICAgb25EcmFnT3ZlcjogJ2RyYWdvdmVyJyxcclxuICAgIG9uRHJhZ1N0YXJ0OiAnZHJhZ3N0YXJ0JyxcclxuICAgIG9uRHJvcDogJ2Ryb3AnLFxyXG4gICAgb25Nb3VzZURvd246ICdtb3VzZWRvd24nLFxyXG4gICAgb25Nb3VzZUVudGVyOiAnbW91c2VlbnRlcicsXHJcbiAgICBvbk1vdXNlTGVhdmU6ICdtb3VzZWxlYXZlJyxcclxuICAgIG9uTW91c2VNb3ZlOiAnbW91c2Vtb3ZlJyxcclxuICAgIG9uTW91c2VPdXQ6ICdtb3VzZW91dCcsXHJcbiAgICBvbk1vdXNlT3ZlcjogJ21vdXNlb3ZlcicsXHJcbiAgICBvbk1vdXNlVXA6ICdtb3VzZXVwJyxcclxuXHJcbiAgICAvLyBTZWxlY3Rpb24gRXZlbnRzXHJcbiAgICBvblNlbGVjdDogJ3NlbGVjdCcsXHJcblxyXG4gICAgLy8gVG91Y2ggRXZlbnRzXHJcbiAgICBvblRvdWNoQ2FuY2VsOiAndG91Y2hjYW5jZWwnLFxyXG4gICAgb25Ub3VjaEVuZDogJ3RvdWNoZW5kJyxcclxuICAgIG9uVG91Y2hNb3ZlOiAndG91Y2htb3ZlJyxcclxuICAgIG9uVG91Y2hTdGFydDogJ3RvdWNoc3RhcnQnLFxyXG5cclxuICAgIC8vIFBvaW50ZXIgRXZlbnRzXHJcbiAgICBvblBvaW50ZXJEb3duOiAncG9pbnRlcmRvd24nLFxyXG4gICAgb25Qb2ludGVyTW92ZTogJ3BvaW50ZXJtb3ZlJyxcclxuICAgIG9uUG9pbnRlclVwOiAncG9pbnRlcnVwJyxcclxuICAgIG9uUG9pbnRlckNhbmNlbDogJ3BvaW50ZXJjYW5jZWwnLFxyXG4gICAgb25Qb2ludGVyRW50ZXI6ICdwb2ludGVyZW50ZXInLFxyXG4gICAgb25Qb2ludGVyTGVhdmU6ICdwb2ludGVybGVhdmUnLFxyXG4gICAgb25Qb2ludGVyT3ZlcjogJ3BvaW50ZXJvdmVyJyxcclxuICAgIG9uUG9pbnRlck91dDogJ3BvaW50ZXJvdXQnLFxyXG5cclxuICAgIC8vIFVJIEV2ZW50c1xyXG4gICAgb25TY3JvbGw6ICdzY3JvbGwnLFxyXG5cclxuICAgIC8vIFdoZWVsIEV2ZW50c1xyXG4gICAgb25XaGVlbDogJ3doZWVsJyxcclxuXHJcbiAgICAvLyBBbmltYXRpb24gRXZlbnRzXHJcbiAgICBvbkFuaW1hdGlvblN0YXJ0OiAnYW5pbWF0aW9uc3RhcnQnLFxyXG4gICAgb25BbmltYXRpb25FbmQ6ICdhbmltYXRpb25lbmQnLFxyXG4gICAgb25BbmltYXRpb25JdGVyYXRpb246ICdhbmltYXRpb25pdGVyYXRpb24nLFxyXG5cclxuICAgIC8vIFRyYW5zaXRpb24gRXZlbnRzXHJcbiAgICBvblRyYW5zaXRpb25FbmQ6ICd0cmFuc2l0aW9uZW5kJyxcclxufTsiLCJmdW5jdGlvbiBxdWVyeVN0cmluZyhxdWVyeSkge1xyXG4gICAgaWYgKCFxdWVyeSkge1xyXG4gICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHF1ZXJ5XHJcbiAgICAgICAgLnNwbGl0KCc/JylbMV1cclxuICAgICAgICAuc3BsaXQoJyYnKVxyXG4gICAgICAgIC5tYXAoYSA9PiBhLnNwbGl0KCc9JykpXHJcbiAgICAgICAgLnJlZHVjZSgoYSwgYykgPT4ge1xyXG4gICAgICAgICAgICBhW2NbMF1dID0gY1sxXTtcclxuICAgICAgICAgICAgcmV0dXJuIGE7XHJcbiAgICAgICAgfSwge30pO1xyXG59XHJcblxyXG4vKipcclxuICogQ2FsY3VsYXRlIG51bWJlciBvZiBkYXlzIHBhc3NpbmcgYmV0d2VlbiB0d28gZGF0ZXNcclxuICogQHBhcmFtIHtEYXRlfSBhIFN0YXJ0aW5nIGRhdGVcclxuICogQHBhcmFtIHtEYXRlfSBiIEVuZGluZyBkYXRlXHJcbiAqIEByZXR1cm5zIHtudW1iZXJ9IE51bWJlciBvZiBkYXlzXHJcbiAqL1xyXG5mdW5jdGlvbiBkYXRlRGlmZihhLCBiKSB7XHJcbiAgICBpZiAoYS5nZXRGdWxsWWVhcigpID09IGIuZ2V0RnVsbFllYXIoKSAmJlxyXG4gICAgICAgIGEuZ2V0TW9udGgoKSA9PSBiLmdldE1vbnRoKCkgJiZcclxuICAgICAgICBhLmdldERhdGUoKSA9PSBiLmdldERhdGUoKSkge1xyXG4gICAgICAgIHJldHVybiAwO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gKGIgLSBhKSA+IDAgPyBNYXRoLmNlaWwoKGIgLSBhKSAvIDg2NDAwMDAwKSA6IE1hdGguZmxvb3IoKGIgLSBhKSAvIDg2NDAwMDAwKTtcclxuICAgIH1cclxufVxyXG5cclxuZnVuY3Rpb24gZGF0ZURpZmZUb0RheXMoZGF5cykge1xyXG4gICAgaWYgKGRheXMgPT0gMCkge1xyXG4gICAgICAgIHJldHVybiAnVG9kYXknO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICBpZiAoZGF5cyA8PSAwKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBgSW4gJHstZGF5c30gZGF5JHtkYXlzID09IC0xID8gJycgOiAncyd9YDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gYCR7ZGF5c30gZGF5JHtkYXlzID09IDEgPyAnJyA6ICdzJ30gYWdvYDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBJcyB0aGUgZGF0ZSBpbiB0aGUgbGFzdCBkYXkgb2YgYSBtb250aFxyXG4gKiBAcGFyYW0ge0RhdGV9IGRhdGVcclxuICogQHJldHVybnMge2Jvb2xlYW59XHJcbiAqL1xyXG5mdW5jdGlvbiBpc0xhc3REYXkoZGF0ZSkge1xyXG4gICAgY29uc3QgbmV4dERheSA9IG5ldyBEYXRlKGRhdGUpO1xyXG4gICAgbmV4dERheS5zZXREYXRlKG5leHREYXkuZ2V0RGF0ZSgpICsgMSk7XHJcbiAgICByZXR1cm4gKGRhdGUuZ2V0TW9udGgoKSAhPSBuZXh0RGF5LmdldE1vbnRoKCkpO1xyXG59XHJcblxyXG4vKipcclxuICogSXMgdGhlIGRhdGUgaW4gdGhlIGxhc3Qgd2VlayBvZiBhIG1vbnRoXHJcbiAqIEBwYXJhbSB7RGF0ZX0gZGF0ZVxyXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cclxuICovXHJcbmZ1bmN0aW9uIGlzTGFzdFdlZWsoZGF0ZSkge1xyXG4gICAgY29uc3QgbmV4dFdlZWsgPSBuZXcgRGF0ZShkYXRlKTtcclxuICAgIG5leHRXZWVrLnNldERhdGUobmV4dFdlZWsuZ2V0RGF0ZSgpICsgNyk7XHJcbiAgICByZXR1cm4gKGRhdGUuZ2V0TW9udGgoKSAhPSBuZXh0V2Vlay5nZXRNb250aCgpKTtcclxufVxyXG5cclxuZnVuY3Rpb24gZm9ybWF0RGF0ZShkYXRlKSB7XHJcbiAgICBjb25zdCBhc1N0cmluZyA9IGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKCdlbi1VUycsIHtcclxuICAgICAgICBtb250aDogJ3Nob3J0JyxcclxuICAgICAgICB5ZWFyOiAnbnVtZXJpYydcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIGAke2RhdGUuZ2V0RGF0ZSgpfSAke2FzU3RyaW5nfWA7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZvcm1hdFRpbWUoZGF0ZSkge1xyXG4gICAgcmV0dXJuIGRhdGUudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1VUycsIHtcclxuICAgICAgICBob3VyOiAnbnVtZXJpYycsXHJcbiAgICAgICAgbWludXRlOiAnbnVtZXJpYycsXHJcbiAgICAgICAgLy8gaG91cjEyOiBmYWxzZSxcclxuICAgICAgICBob3VyQ3ljbGU6ICdoMjMnXHJcbiAgICB9KTtcclxufVxyXG5cclxuZnVuY3Rpb24gZm9ybWF0TG9jYWxlRGF0ZShkYXRlKSB7XHJcbiAgICBjb25zdCBkYXkgPSBkYXRlLmdldERhdGUoKTtcclxuICAgIGNvbnN0IG1vbnRoID0gW1xyXG4gICAgICAgICfRj9C90YPQsNGA0LgnLFxyXG4gICAgICAgICfRhNC10LLRgNGD0LDRgNC4JyxcclxuICAgICAgICAn0LzQsNGA0YInLFxyXG4gICAgICAgICfQsNC/0YDQuNC7JyxcclxuICAgICAgICAn0LzQsNC5JyxcclxuICAgICAgICAn0Y7QvdC4JyxcclxuICAgICAgICAn0Y7Qu9C4JyxcclxuICAgICAgICAn0LDQstCz0YPRgdGCJyxcclxuICAgICAgICAn0YHQtdC/0YLQtdC80LLRgNC4JyxcclxuICAgICAgICAn0L7QutGC0L7QvNCy0YDQuCcsXHJcbiAgICAgICAgJ9C90L7QtdC80LLRgNC4JyxcclxuICAgICAgICAn0LTQtdC60LXQvNCy0YDQuCdcclxuICAgIF1bZGF0ZS5nZXRNb250aCgpXTtcclxuICAgIHJldHVybiBgJHtkYXl9ICR7bW9udGh9YDtcclxufVxyXG5cclxuZnVuY3Rpb24gZm9ybWF0TG9jYWxlV2Vla2RheShkYXksIGdldEFkaikge1xyXG4gICAgY29uc3Qgd2Vla2RheSA9IFtcclxuICAgICAgICAn0L3QtdC00LXQu9GPJyxcclxuICAgICAgICAn0L/QvtC90LXQtNC10LvQvdC40LonLFxyXG4gICAgICAgICfQstGC0L7RgNC90LjQuicsXHJcbiAgICAgICAgJ9GB0YDRj9C00LAnLFxyXG4gICAgICAgICfRh9C10YLQstGK0YDRgtGK0LonLFxyXG4gICAgICAgICfQv9C10YLRitC6JyxcclxuICAgICAgICAn0YHRitCx0L7RgtCwJyxcclxuICAgIF1bZGF5XTtcclxuICAgIGlmIChnZXRBZGopIHtcclxuICAgICAgICByZXR1cm4gW3dlZWtkYXksIFtcclxuICAgICAgICAgICAgJ9Cy0YHRj9C60LAnLFxyXG4gICAgICAgICAgICAn0LLRgdC10LrQuCcsXHJcbiAgICAgICAgICAgICfQstGB0LXQutC4JyxcclxuICAgICAgICAgICAgJ9Cy0YHRj9C60LAnLFxyXG4gICAgICAgICAgICAn0LLRgdC10LrQuCcsXHJcbiAgICAgICAgICAgICfQstGB0LXQutC4JyxcclxuICAgICAgICAgICAgJ9Cy0YHRj9C60LAnLFxyXG4gICAgICAgIF1bZGF5XV07XHJcbiAgICB9XHJcbiAgICByZXR1cm4gd2Vla2RheTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEdldCBhIG5ldyBkYXRlIG9mZnNldCBieSB0aGUgc3BlY2lmaWVkIG51bWJlciBvZiBkYXlzXHJcbiAqIEBwYXJhbSB7RGF0ZX0gZGF0ZSBCYXNlIGRhdGVcclxuICogQHBhcmFtIHtudW1iZXJ9IGRheXMgSG93IG1hbnkgZGF5cyB0byBvZmZzZXRcclxuICogQHJldHVybnMge0RhdGV9XHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gZ2V0T2Zmc2V0QnlEYXlzKGRhdGUsIGRheXMpIHtcclxuICAgIGNvbnN0IHJlc3VsdCA9IG5ldyBEYXRlKGRhdGUpO1xyXG4gICAgcmVzdWx0LnNldFVUQ0RhdGUocmVzdWx0LmdldFVUQ0RhdGUoKSArIGRheXMpO1xyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxufVxyXG5cclxuLyoqXHJcbiAqIE9mZnNldCB0aGUgZ2l2ZW4gZGF0ZSBpbiBwbGFjZSBieSB0aGUgc3BlY2lmaWVkIG51bWJlciBvZiBkYXlzXHJcbiAqIEBwYXJhbSB7RGF0ZX0gZGF0ZSBCYXNlIGRhdGVcclxuICogQHBhcmFtIHtudW1iZXJ9IGRheXMgSG93IG1hbnkgZGF5cyB0byBvZmZzZXRcclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBvZmZzZXRCeURheXMoZGF0ZSwgZGF5cykge1xyXG4gICAgZGF0ZS5zZXRVVENEYXRlKGRhdGUuZ2V0VVRDRGF0ZSgpICsgZGF5cyk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBDcmVhdGUgZGF0ZSBpbmRleCBhcyBzdHJpbmdcclxuICogQHBhcmFtIHtEYXRlfHN0cmluZ30gZGF0ZSBCYXNlIGRhdGVcclxuICogQHJldHVybnMge3N0cmluZ31cclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXREYXRlSW5kZXgoZGF0ZSkge1xyXG4gICAgaWYgKHR5cGVvZiBkYXRlID09ICdzdHJpbmcnKSB7XHJcbiAgICAgICAgZGF0ZSA9IG5ldyBEYXRlKGRhdGUpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGRhdGUudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHByZXR0eUpTT04ob2JqKSB7XHJcbiAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkob2JqLCBudWxsLCAyKS5yZXBsYWNlKC8gL2dtaSwgJyZuYnNwOycpLnJlcGxhY2UoL1xcbi9nbWksICc8YnI+Jyk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGdldE1vbmRheShkYXRlKSB7XHJcbiAgICBjb25zdCBtb25kYXkgPSBuZXcgRGF0ZShgJHtkYXRlLmdldEZ1bGxZZWFyKCl9LSR7ZGF0ZS5nZXRNb250aCgpICsgMX0tJHtkYXRlLmdldERhdGUoKX0gMTI6MDA6MDBgKTtcclxuICAgIG1vbmRheS5zZXREYXRlKG1vbmRheS5nZXREYXRlKCkgLSAoKG1vbmRheS5nZXREYXkoKSArIDYpICUgNykpO1xyXG4gICAgcmV0dXJuIG1vbmRheTtcclxufVxyXG5cclxuZnVuY3Rpb24gZ2V0U3VuZGF5KGRhdGUpIHtcclxuICAgIGNvbnN0IHN1bmRheSA9IG5ldyBEYXRlKGAke2RhdGUuZ2V0RnVsbFllYXIoKX0tJHtkYXRlLmdldE1vbnRoKCkgKyAxfS0ke2RhdGUuZ2V0RGF0ZSgpfSAyMzo1OTo1OWApO1xyXG4gICAgc3VuZGF5LnNldERhdGUoc3VuZGF5LmdldERhdGUoKSArICgoNyAtIHN1bmRheS5nZXREYXkoKSkgJSA3KSk7XHJcbiAgICByZXR1cm4gc3VuZGF5O1xyXG59XHJcblxyXG5jb25zdCBtb250aE5hbWUgPSB7XHJcbiAgICAxOiAnSmFudWFyeScsXHJcbiAgICAyOiAnRmVicnVhcnknLFxyXG4gICAgMzogJ01hcmNoJyxcclxuICAgIDQ6ICdBcHJpbCcsXHJcbiAgICA1OiAnTWF5JyxcclxuICAgIDY6ICdKdW5lJyxcclxuICAgIDc6ICdKdWx5JyxcclxuICAgIDg6ICdBdWd1c3QnLFxyXG4gICAgOTogJ1NlcHRlbWJlcicsXHJcbiAgICAxMDogJ09jdG9iZXInLFxyXG4gICAgMTE6ICdOb3ZlbWJlcicsXHJcbiAgICAxMjogJ0RlY2VtYmVyJyxcclxufTtcclxuXHJcblxyXG5jb25zdCBsb2NhbGVNb250aE5hbWUgPSB7XHJcbiAgICAxOiAn0Y/QvdGD0LDRgNC4JyxcclxuICAgIDI6ICfRhNC10LLRgNGD0LDRgNC4JyxcclxuICAgIDM6ICfQvNCw0YDRgicsXHJcbiAgICA0OiAn0LDQv9GA0LjQuycsXHJcbiAgICA1OiAn0LzQsNC5JyxcclxuICAgIDY6ICfRjtC90LgnLFxyXG4gICAgNzogJ9GO0LvQuCcsXHJcbiAgICA4OiAn0LDQstCz0YPRgdGCJyxcclxuICAgIDk6ICfRgdC10L/RgtC10LzQstGA0LgnLFxyXG4gICAgMTA6ICfQvtC60YLQvtC80LLRgNC4JyxcclxuICAgIDExOiAn0L3QvtC10LzQstGA0LgnLFxyXG4gICAgMTI6ICfQtNC10LrQtdC80LLRgNC4JyxcclxufTtcclxuXHJcbmZ1bmN0aW9uIHRvQXNzb2NBcnJheShwLCBjLCBpLCBhKSB7XHJcbiAgICBwW2MuSWRdID0gYztcclxuICAgIHJldHVybiBwO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdG9DdXN0b21Bc3NvY0FycmF5KGluZGV4TmFtZSwgb3ZlcndyaXRlID0gZmFsc2UpIHtcclxuICAgIHJldHVybiAocCwgYywgaSwgYSkgPT4ge1xyXG4gICAgICAgIGlmIChwW2NbaW5kZXhOYW1lXV0gIT09IHVuZGVmaW5lZCAmJiBvdmVyd3JpdGUgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkocFtjW2luZGV4TmFtZV1dKSkge1xyXG4gICAgICAgICAgICAgICAgcFtjW2luZGV4TmFtZV1dLnB1c2goYyk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBwW2NbaW5kZXhOYW1lXV0gPSBbcFtjW2luZGV4TmFtZV1dLCBjXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHBbY1tpbmRleE5hbWVdXSA9IGM7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBwO1xyXG4gICAgfTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEBwYXJhbSB7QXJyYXk8U1VQYXltZW50Pn0gZGF0YSBcclxuICogQHJldHVybnMge0FycmF5PFBheW1lbnRWaWV3TW9kZWw+fVxyXG4gKi9cclxuZnVuY3Rpb24gcGF5bWVudHNUb01hdHJpeChkYXRhKSB7XHJcbiAgICBjb25zdCB0ZW1wbGF0ZSA9IFtcclxuICAgICAgICAnSWQnLFxyXG4gICAgICAgICdQYXltZW50TnVtYmVyJyxcclxuICAgICAgICAnTW9kdWxlTmFtZUVuJyxcclxuICAgICAgICAnUGF5bWVudFBhY2thZ2VzQXNTdHJpbmcnLFxyXG4gICAgICAgICdQYWlkRm9yVXNlck5hbWUnLFxyXG4gICAgICAgICdQcmljZScsXHJcbiAgICAgICAgJ0VkdWNhdGlvbmFsRm9ybScsXHJcbiAgICAgICAgJ1BheW1lbnREYXRlVGltZSdcclxuICAgIF07XHJcbiAgICBjb25zdCBwYXJzZWQgPSBkYXRhLm1hcChlID0+IHtcclxuICAgICAgICBlLkVkdWNhdGlvbmFsRm9ybSA9IGUuRWR1Y2F0aW9uYWxGb3JtID09IDEgPyAnb25saW5lJyA6ICdvbnNpdGUnO1xyXG4gICAgICAgIGNvbnN0IGVudHJ5ID0gW107XHJcbiAgICAgICAgZm9yIChsZXQgcHJvcCBvZiB0ZW1wbGF0ZSkge1xyXG4gICAgICAgICAgICBpZiAocHJvcCA9PT0gJ1BheW1lbnREYXRlVGltZScpIHtcclxuICAgICAgICAgICAgICAgIGVudHJ5LnB1c2gobmV3IERhdGUoZVtwcm9wXSkpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgZW50cnkucHVzaChlW3Byb3BdKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gZW50cnk7XHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gW3RlbXBsYXRlLCAuLi5wYXJzZWRdO1xyXG59XHJcblxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHV1aWQoKSB7XHJcbiAgICByZXR1cm4gJ3h4eHh4eHh4LXh4eHgtNHh4eC15eHh4LXh4eHh4eHh4eHh4eCcucmVwbGFjZSgvW3h5XS9nLCBmdW5jdGlvbiAoYykge1xyXG4gICAgICAgIGxldCByID0gTWF0aC5yYW5kb20oKSAqIDE2IHwgMCxcclxuICAgICAgICAgICAgdiA9IGMgPT0gJ3gnID8gciA6IChyICYgMHgzIHwgMHg4KTtcclxuICAgICAgICByZXR1cm4gdi50b1N0cmluZygxNik7XHJcbiAgICB9KTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZURhdGVUaW1lKGRhdGV0aW1lKSB7XHJcbiAgICBpZiAoIWRhdGV0aW1lKSB7XHJcbiAgICAgICAgcmV0dXJuICcnO1xyXG4gICAgfSBlbHNlIGlmIChkYXRldGltZS50b1N0cmluZygpLmluY2x1ZGVzKCdEYXRlKCcpKSB7XHJcbiAgICAgICAgY29uc3QgbWF0Y2ggPSAvRGF0ZVxcKCguKylcXCkvLmV4ZWMoZGF0ZXRpbWUpO1xyXG4gICAgICAgIGlmIChtYXRjaCAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICBjb25zdCBkID0gbmV3IERhdGUoTnVtYmVyKG1hdGNoWzFdKSk7XHJcbiAgICAgICAgICAgIHJldHVybiBgJHsoJzAwMDAnICsgZC5nZXRGdWxsWWVhcigpKS5zbGljZSgtNCl9LSR7cHQoZC5nZXRNb250aCgpICsgMSl9LSR7cHQoZC5nZXREYXRlKCkpfVQke3B0KGQuZ2V0SG91cnMoKSl9OiR7cHQoZC5nZXRNaW51dGVzKCkpfWA7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIGRhdGV0aW1lO1xyXG4gICAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIGRhdGV0aW1lO1xyXG4gICAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBwdChzKSB7XHJcbiAgICByZXR1cm4gYDAke3N9YC5zbGljZSgtMik7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGh0bWxUb1RleHQoaHRtbCkge1xyXG4gICAgY29uc3QgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgICBkaXYuaW5uZXJIVE1MID0gaHRtbDtcclxuXHJcbiAgICByZXR1cm4gZGl2LnRleHRDb250ZW50O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaW5zdGFuY2VNZXRhRnJvbUhyZWYoaHJlZikge1xyXG4gICAgY29uc3QgaW5zdGFuY2VNZXRhID0gcXVlcnlTdHJpbmcoaHJlZik7XHJcbiAgICBpbnN0YW5jZU1ldGEuSW5zdGFuY2VSZWZUeXBlID0gKCgpID0+IHtcclxuICAgICAgICBzd2l0Y2ggKGluc3RhbmNlTWV0YS50eXBlKSB7XHJcbiAgICAgICAgICAgIGNhc2UgJ2NvdXJzZSc6IHJldHVybiAnbWFpbic7XHJcbiAgICAgICAgICAgIGNhc2UgJ2Zhc3QtdHJhY2snOiByZXR1cm4gJ29wZW4nO1xyXG4gICAgICAgICAgICBjYXNlICdnZW5lcmFsLWNvdXJzZS1pbnN0YW5jZSc6IHJldHVybiAnZ2VuZXJhbCc7XHJcbiAgICAgICAgfVxyXG4gICAgfSkoKTtcclxuXHJcbiAgICByZXR1cm4gaW5zdGFuY2VNZXRhO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaGFzVmFsdWUodmFsdWUpIHtcclxuICAgIHJldHVybiAodmFsdWUgIT09IG51bGwgJiYgdmFsdWUgIT09IHVuZGVmaW5lZCAmJiB2YWx1ZSAhPT0gJycpO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdmFsdWVPckVtcHR5KHZhbHVlLCBhbHQgPSAnJykge1xyXG4gICAgaWYgKHZhbHVlID09PSBudWxsIHx8IHZhbHVlID09PSB1bmRlZmluZWQgfHwgdmFsdWUgPT09ICcnKSB7XHJcbiAgICAgICAgcmV0dXJuIGFsdDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gc3VtQXJyYXlNYXgoYXJyKSB7XHJcbiAgICBpZiAoYXJyWzBdLmxlbmd0aCA9PSAwICYmIGFyclsxXS5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG5cclxuICAgIGxldCByZXN1bHQgPSAwO1xyXG5cclxuICAgIGlmIChhcnJbMF0ubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIHJlc3VsdCArPSBNYXRoLm1heCguLi5hcnJbMF0pO1xyXG4gICAgfVxyXG4gICAgaWYgKGFyclsxXS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgcmVzdWx0ICs9IE1hdGgubWF4KC4uLmFyclsxXSk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQge1xyXG4gICAgcXVlcnlTdHJpbmcsXHJcbiAgICBkYXRlRGlmZixcclxuICAgIGRhdGVEaWZmVG9EYXlzLFxyXG4gICAgaXNMYXN0RGF5LFxyXG4gICAgaXNMYXN0V2VlayxcclxuICAgIGZvcm1hdERhdGUsXHJcbiAgICBmb3JtYXRUaW1lLFxyXG4gICAgZm9ybWF0TG9jYWxlRGF0ZSxcclxuICAgIGZvcm1hdExvY2FsZVdlZWtkYXksXHJcbiAgICBwcmV0dHlKU09OLFxyXG4gICAgZ2V0TW9uZGF5LFxyXG4gICAgZ2V0U3VuZGF5LFxyXG4gICAgbW9udGhOYW1lLFxyXG4gICAgbG9jYWxlTW9udGhOYW1lLFxyXG4gICAgdG9Bc3NvY0FycmF5LFxyXG4gICAgcGF5bWVudHNUb01hdHJpeCxcclxuICAgIGh0bWxUb1RleHRcclxufTtcclxuXHJcblxyXG5leHBvcnQge1xyXG4gICAgcXVlcnlTdHJpbmcsXHJcbiAgICBkYXRlRGlmZixcclxuICAgIGRhdGVEaWZmVG9EYXlzLFxyXG4gICAgaXNMYXN0RGF5LFxyXG4gICAgaXNMYXN0V2VlayxcclxuICAgIGZvcm1hdERhdGUsXHJcbiAgICBmb3JtYXRUaW1lLFxyXG4gICAgZm9ybWF0TG9jYWxlRGF0ZSxcclxuICAgIGZvcm1hdExvY2FsZVdlZWtkYXksXHJcbiAgICBwcmV0dHlKU09OLFxyXG4gICAgZ2V0TW9uZGF5LFxyXG4gICAgZ2V0U3VuZGF5LFxyXG4gICAgbW9udGhOYW1lLFxyXG4gICAgbG9jYWxlTW9udGhOYW1lLFxyXG4gICAgdG9Bc3NvY0FycmF5LFxyXG4gICAgcGF5bWVudHNUb01hdHJpeCxcclxuICAgIGh0bWxUb1RleHRcclxufTsiLCJpbXBvcnQgcGFyc2UgZnJvbSAnLi9wYXJzZSc7XHJcblxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIExpbmsoeyBocmVmLCB0bywgbmF2LCBwYXJ0aWFsLCByZXEsIGNoaWxkcmVuLCAuLi5wcm9wcyB9KSB7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IGVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XHJcbiAgICAgICAgaWYgKGhyZWYgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICBlbGVtZW50LnNldEF0dHJpYnV0ZSgnaHJlZicsIGhyZWYpO1xyXG4gICAgICAgICAgICBlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGUpID0+IGhhbmRsZXIoZSwgZWxlbWVudCkpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBmb3IgKGxldCBwcm9wIG9mIE9iamVjdC5rZXlzKHByb3BzKSkge1xyXG4gICAgICAgICAgICBlbGVtZW50W3Byb3BdID0gcHJvcHNbcHJvcF07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChuYXYpIHtcclxuICAgICAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QuYWRkKCdzZXMtbmF2Jyk7XHJcbiAgICAgICAgICAgIGNvbnN0IGhyZWZUb2tlbnMgPSBwYXJzZS5xdWVyeVN0cmluZyhlbGVtZW50LmhyZWYpO1xyXG4gICAgICAgICAgICBjb25zdCBtYXRjaGVyID0gKG5hdikgPT4gbWF0Y2hSb3V0ZShocmVmVG9rZW5zLCBuYXYpO1xyXG4gICAgICAgICAgICBlbGVtZW50LmNoZWNrQWN0aXZlTmF2ID0gKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHdpbmRvdy5sb2NhdGlvbi5zZWFyY2guc3BsaXQoJz8nKVsxXSA9PT0gZWxlbWVudC5ocmVmLnNwbGl0KCc/JylbMV0pIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZWxlbWVudC5jbGFzc0xpc3QuYWRkKCdhY3RpdmUnKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAocGFydGlhbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChhY3RpdmVOYXYuc29tZShtYXRjaGVyKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVxID09PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBlbGVtZW50LmNsYXNzTGlzdC5hZGQoJ2FjdGl2ZScpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGFjdGl2ZU5hdi5zb21lKG5hdiA9PiBtYXRjaFJvdXRlKHJlcSwgbmF2KSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBlbGVtZW50LmNsYXNzTGlzdC5hZGQoJ2FjdGl2ZScpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdhY3RpdmUnKTtcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgZWxlbWVudC5jaGVja0FjdGl2ZU5hdigpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBhcHBlbmRBbGwoY2hpbGRyZW4sIGVsZW1lbnQpO1xyXG5cclxuICAgICAgICByZXR1cm4gZWxlbWVudDtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyLm1lc3NhZ2UpO1xyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIGhhbmRsZXIoZSwgZWxlbWVudCkge1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICBjb25zdCB0aXRsZSA9IGRvY3VtZW50LnRpdGxlO1xyXG4gICAgICAgIHdpbmRvdy5oaXN0b3J5LnB1c2hTdGF0ZSh7fSwgdGl0bGUsIGhyZWYpO1xyXG5cclxuICAgICAgICBpZiAodG8gIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICBpZiAobmF2KSB7XHJcbiAgICAgICAgICAgICAgICBjaGVja0FjdGl2ZU5hdigpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRvKCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdHJpZ2dlcigpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBhcHBlbmRBbGwoY2hpbGRyZW4sIGVsZW1lbnQpIHtcclxuICAgICAgICBmb3IgKGxldCBjaGlsZCBvZiBjaGlsZHJlbikge1xyXG4gICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShjaGlsZCkpIHtcclxuICAgICAgICAgICAgICAgIGFwcGVuZEFsbChjaGlsZCwgZWxlbWVudCk7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIGNoaWxkID09PSAnc3RyaW5nJyB8fCB0eXBlb2YgY2hpbGQgPT09ICdudW1iZXInKSB7XHJcbiAgICAgICAgICAgICAgICBlbGVtZW50LmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKGNoaWxkKSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBlbGVtZW50LmFwcGVuZENoaWxkKGNoaWxkKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHJlZGlyZWN0KGhyZWYpIHtcclxuICAgIGNvbnN0IHRpdGxlID0gZG9jdW1lbnQudGl0bGU7XHJcbiAgICB3aW5kb3cuaGlzdG9yeS5wdXNoU3RhdGUoe30sIHRpdGxlLCBocmVmKTtcclxuICAgIHRyaWdnZXIoKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGJhY2soKSB7XHJcbiAgICB3aW5kb3cuaGlzdG9yeS5iYWNrKCk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBjaGVja0FjdGl2ZU5hdigpIHtcclxuICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJy5zZXMtbmF2JykuZm9yRWFjaChlID0+IGUuY2hlY2tBY3RpdmVOYXYoKSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGxpbmsoY2FsbGJhY2ssIHRpdGxlKSB7XHJcbiAgICByZXR1cm4gZnVuY3Rpb24gKGVsZW1lbnQpIHtcclxuICAgICAgICBlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgZSA9PiB7XHJcbiAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgdGl0bGUgPSB0aXRsZSB8fCBkb2N1bWVudC50aXRsZTtcclxuICAgICAgICAgICAgd2luZG93Lmhpc3RvcnkucHVzaFN0YXRlKHt9LCB0aXRsZSwgZS50YXJnZXQuaHJlZik7XHJcblxyXG4gICAgICAgICAgICBjYWxsYmFjayhlKTtcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcbn1cclxuXHJcblxyXG53aW5kb3cub25wb3BzdGF0ZSA9IGZ1bmN0aW9uIChlKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIHRyaWdnZXIoKTtcclxuICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKCdSb3V0aW5nIGhhbmRsZXIgZXJyb3I6Jyk7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihlLm1lc3NhZ2UpO1xyXG4gICAgfVxyXG59O1xyXG5cclxuLy8gbXVzdCBoYXZlIGEgc3RhdGljIGluc3RhbmNlIGF2YWlsYWJsZSAtIHN0YXJ0aW5nIHdpdGggdG9wIGxldmVsIG9uIGZpcnN0IGNhbGwgdG8gcmVnaXN0ZXIsIHJlcGxhY2VkIGJ5IGFjdGl2ZSByb3V0ZSB1cG9uIGxvYWQvbmF2aWdhdGlvblxyXG4vLyBzdWJzZXF1ZW50IGNhbGxzIHRvIHJlZ2lzdGVyIGFkZCB0aGUgcm91dGVzIHRvIHRoZSBhY3RpdmUgcm91dGVyXHJcbi8qKlxyXG4gKiBAdHlwZWRlZiB7T2JqZWN0fSBSb3V0ZVxyXG4gKiBAcHJvcGVydHkge3tuYW1lOiBzdHJpbmd9fSBtYXRjaCAtIE5hbWUgb2YgcXVlcnkgcGFyYW1ldGVyIGFuZCBpdHMgdmFsdWVcclxuICogQHByb3BlcnR5IHtGdW5jdGlvbn0gaGFuZGxlciAtIENhbGxiYWNrIHRvIGJlIGV4ZWN1dGVkIG9uIG1hdGNoLiBFeHBlY3RlZCB0byByZW5kZXIgY29udGVudFxyXG4gKiBAcHJvcGVydHkgeyo9fSBjb250ZXh0IC0gT3B0aW9uYWwgb2JqZWN0IHRoYXQgd2lsbCBiZSBwYXNzZWQgdG8gaGFuZGxlclxyXG4gKiBAcHJvcGVydHkge1JvdXRlW109fSByb3V0ZXMgLSBOZXN0ZWQgcm91dGVzXHJcbiAqL1xyXG5cclxuLyoqIEB0eXBlIHtudW1iZXJ9IC0gRGVidWcgY291bnRlciAqL1xyXG5cclxuLyoqIEB0eXBlIHtSb3V0ZVtdfSAqL1xyXG5jb25zdCByb3V0ZXMgPSBbXTtcclxuLyoqIEB0eXBlIHtSb3V0ZX0gKi9cclxubGV0IGFjdGl2ZVJvdXRlID0gbnVsbDtcclxubGV0IGFjdGl2ZU5hdiA9IFtdO1xyXG5cclxuLyoqXHJcbiAqIEFkZCBuZXN0ZWQgcm91dGVzIHRvIGN1cnJlbnRseSBhY3RpdmUgcm91dGUuIElmIGZpcnN0IGNhbGwsIHRvcCBsZXZlbCByb3V0ZXMgYXJlIGRlZmluZWRcclxuICogQHBhcmFtIHtSb3V0ZVtdfSBvcHRpb25zIC0gTGlzdCBvZiByb3V0ZXNcclxuICogQHBhcmFtIHsqPX0gY29udGV4dCAtIE9wdGlvbmFsIG9iamVjdCB0aGF0IHdpbGwgYmUgcGFzc2VkIHRvIGhhbmRsZXJzXHJcbiAqL1xyXG5mdW5jdGlvbiByZWdpc3RlcihvcHRpb25zLCBjb250ZXh0KSB7XHJcbiAgICBsZXQgY3VycmVudFJvdXRlcyA9IHJvdXRlcztcclxuICAgIGlmIChhY3RpdmVSb3V0ZSAhPT0gbnVsbCkge1xyXG4gICAgICAgIGFjdGl2ZVJvdXRlLnJvdXRlcyA9IGFjdGl2ZVJvdXRlLnJvdXRlcyB8fCBbXTtcclxuICAgICAgICBjdXJyZW50Um91dGVzID0gYWN0aXZlUm91dGUucm91dGVzO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IG5ld1JvdXRlcyA9IFtdO1xyXG4gICAgZm9yIChsZXQgcm91dGUgb2Ygb3B0aW9ucykge1xyXG4gICAgICAgIHJvdXRlID0gT2JqZWN0LmFzc2lnbihyb3V0ZSwgeyBjb250ZXh0IH0pO1xyXG4gICAgICAgIGNvbnN0IHJvdXRlSWQgPSBjdXJyZW50Um91dGVzLnJlZHVjZSgocCwgYywgaSkgPT4gbWF0Y2hSb3V0ZShyb3V0ZS5tYXRjaCwgYy5tYXRjaCkgPyBpIDogcCwgdW5kZWZpbmVkKTtcclxuICAgICAgICBpZiAocm91dGVJZCAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIGN1cnJlbnRSb3V0ZXNbcm91dGVJZF0gPSByb3V0ZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBuZXdSb3V0ZXMucHVzaChyb3V0ZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgbmV3Um91dGVzLmZvckVhY2gociA9PiBjdXJyZW50Um91dGVzLnB1c2gocikpO1xyXG5cclxuICAgIHRyaWdnZXIoY3VycmVudFJvdXRlcyk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBSdW4gYSBjaGVjayBhZ2FpbnN0IHRoZSByb3V0aW5nIGxpc3QgYW5kIGV4ZWN1dGUgbWF0Y2hpbmcgaGFuZGxlcnNcclxuICogQHBhcmFtIHtSb3V0ZVtdPX0gY3VycmVudFJvdXRlcyAtIEN1cnJlbnRseSBhY3RpdmUgcm91dGluZyBsaXN0XHJcbiAqL1xyXG5mdW5jdGlvbiB0cmlnZ2VyKGN1cnJlbnRSb3V0ZXMpIHtcclxuICAgIGlmIChjdXJyZW50Um91dGVzID09PSB1bmRlZmluZWQgfHwgY3VycmVudFJvdXRlcyA9PT0gcm91dGVzKSB7XHJcbiAgICAgICAgY3VycmVudFJvdXRlcyA9IHJvdXRlcztcclxuICAgICAgICBhY3RpdmVOYXYgPSBbXTtcclxuICAgIH1cclxuICAgIC8qKiBAdHlwZSB7T2JqZWN0LjxzdHJpbmcsIHN0cmluZz4/fSAqL1xyXG4gICAgY29uc3QgcXVlcnkgPSBwYXJzZS5xdWVyeVN0cmluZyhkb2N1bWVudC5sb2NhdGlvbi5zZWFyY2gpO1xyXG5cclxuICAgIGZvciAobGV0IHJvdXRlIG9mIGN1cnJlbnRSb3V0ZXMpIHtcclxuICAgICAgICBpZiAobWF0Y2hSb3V0ZShxdWVyeSwgcm91dGUubWF0Y2gpKSB7XHJcbiAgICAgICAgICAgIGFjdGl2ZVJvdXRlID0gcm91dGU7XHJcbiAgICAgICAgICAgIGFjdGl2ZU5hdi5wdXNoKGFjdGl2ZVJvdXRlLm1hdGNoKTtcclxuICAgICAgICAgICAgY2hlY2tBY3RpdmVOYXYoKTtcclxuICAgICAgICAgICAgcmV0dXJuIHJvdXRlLmhhbmRsZXIocXVlcnksIHJvdXRlLmNvbnRleHQpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIENoZWNrIGlmIGEgZ2l2ZW4gcXVlcnkgb2JqZWN0IG1hdGNoZXMgYSBnaXZlbiByb3V0ZSBwYXR0ZXJuXHJcbiAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsIHN0cmluZz4/fSBxdWVyeSAtIFF1ZXJ5IHBhcmFtZXRlcnNcclxuICogQHBhcmFtIHt7bmFtZTogc3RyaW5nfX0gbWF0Y2ggLSBQYXJhbWV0ZXIgbmFtZSBhbmQgdmFsdWUgdGhhdCBtdXN0IG1hdGNoXHJcbiAqIEByZXR1cm5zIHtib29sZWFufVxyXG4gKi9cclxuZnVuY3Rpb24gbWF0Y2hSb3V0ZShxdWVyeSwgbWF0Y2gpIHtcclxuICAgIGlmIChtYXRjaCA9PT0gcXVlcnkpIHtcclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH0gZWxzZSBpZiAocXVlcnkpIHtcclxuICAgICAgICBpZiAodHlwZW9mIG1hdGNoID09PSAnc3RyaW5nJyAmJiBxdWVyeS5oYXNPd25Qcm9wZXJ0eShtYXRjaCkpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgbmFtZSBpbiBtYXRjaCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHF1ZXJ5W25hbWVdID09PSBtYXRjaFtuYW1lXSkgeyByZXR1cm4gdHJ1ZTsgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIE5vIG1hdGNoXHJcbiAgICByZXR1cm4gZmFsc2U7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IHtcclxuICAgIGxpbmssXHJcbiAgICByZWdpc3RlclxyXG59OyIsImltcG9ydCB7IHV1aWQgfSBmcm9tICcuL3BhcnNlJztcclxuaW1wb3J0IGRvbSwgeyBGcmFnbWVudCB9IGZyb20gJy4uL3V0aWwvanN4LXJlbmRlci1tb2QvZG9tJztcclxuXHJcbi8qKlxyXG4gKiBcclxuICogQHBhcmFtIHsqfSB0eXBlIFxyXG4gKiBAcGFyYW0geyp9IGNvbnRlbnQgXHJcbiAqIEBwYXJhbSB7Kn0gYXR0cmlidXRlcyBcclxuICogQHBhcmFtIHt7Zm9yY2VUeXBlOiAnVGV4dCcgfCAnSFRNTCd9fSBvcHRpb25zIFxyXG4gKiBAcmV0dXJucyBcclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBlbGVtZW50KHR5cGUsIGNvbnRlbnQsIGF0dHJpYnV0ZXMsIG9wdGlvbnMgPSB1bmRlZmluZWQpIHtcclxuICAgIGNvbnN0IHJlc3VsdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQodHlwZSk7XHJcblxyXG4gICAgaWYgKGF0dHJpYnV0ZXMpIHtcclxuICAgICAgICBmb3IgKGxldCBhdHRyIG9mIE9iamVjdC5rZXlzKGF0dHJpYnV0ZXMpKSB7XHJcbiAgICAgICAgICAgIHJlc3VsdFthdHRyXSA9IGF0dHJpYnV0ZXNbYXR0cl07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHJlc3VsdC5hcHBlbmQgPSBhcHBlbmQuYmluZChyZXN1bHQpO1xyXG5cclxuICAgIHJlc3VsdC5hcHBlbmRUbyA9IChwYXJlbnQpID0+IHtcclxuICAgICAgICBwYXJlbnQuYXBwZW5kKHJlc3VsdCk7XHJcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgIH07XHJcblxyXG4gICAgaWYgKGNvbnRlbnQgIT09IHVuZGVmaW5lZCAmJiBjb250ZW50ICE9PSBudWxsKSB7XHJcbiAgICAgICAgcmVzdWx0LmFwcGVuZChjb250ZW50LCBvcHRpb25zKTtcclxuICAgIH1cclxuICAgIHJldHVybiByZXN1bHQ7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGFwcGVuZChjaGlsZCwgb3B0aW9ucyA9IHVuZGVmaW5lZCkge1xyXG4gICAgaWYgKHR5cGVvZiAoY2hpbGQpID09PSAnc3RyaW5nJyB8fCB0eXBlb2YgKGNoaWxkKSA9PT0gJ251bWJlcicpIHtcclxuICAgICAgICBpZiAob3B0aW9ucz8uZm9yY2VUeXBlICE9ICdUZXh0JyAmJiAob3B0aW9ucz8uZm9yY2VUeXBlID09PSAnSFRNTCcgfHwgY2hpbGQudG9TdHJpbmcoKS50cmltKClbMF0gPT09ICc8JykpIHtcclxuICAgICAgICAgICAgdGhpcy5pbm5lckhUTUwgPSBjaGlsZDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBjaGlsZCA9IGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKGNoaWxkKTtcclxuICAgICAgICAgICAgdGhpcy5hcHBlbmRDaGlsZChjaGlsZCk7XHJcbiAgICAgICAgfVxyXG4gICAgfSBlbHNlIGlmIChBcnJheS5pc0FycmF5KGNoaWxkKSkge1xyXG4gICAgICAgIGZvciAobGV0IG5vZGUgb2YgY2hpbGQpIHtcclxuICAgICAgICAgICAgYXBwZW5kLmNhbGwodGhpcywgbm9kZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICB0aGlzLmFwcGVuZENoaWxkKGNoaWxkKTtcclxuICAgIH1cclxuICAgIHJldHVybiB0aGlzO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gcmVwbGFjZUNvbnRlbnRzKG5vZGUsIG5ld0NvbnRlbnRzKSB7XHJcbiAgICBjb25zdCBjTm9kZSA9IG5vZGUuY2xvbmVOb2RlKGZhbHNlKTtcclxuICAgIGFwcGVuZC5jYWxsKGNOb2RlLCBuZXdDb250ZW50cyk7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIG5vZGUucGFyZW50Tm9kZS5yZXBsYWNlQ2hpbGQoY05vZGUsIG5vZGUpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgY29uc29sZS5pbmZvKCdOb2RlIGhhcyBubyBwYXJlbnQgb3IgYW5vdGhlciBwcm9ibGVtIG9jY3VyZWQnKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gY05vZGU7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBzd2FwKG9sZE5vZGUsIG5ld05vZGUpIHtcclxuICAgIG9sZE5vZGUucGFyZW50Tm9kZS5yZXBsYWNlQ2hpbGQobmV3Tm9kZSwgb2xkTm9kZSk7XHJcbiAgICByZXR1cm4gbmV3Tm9kZTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFNwaW5uZXIoeyBpZCB9KSB7XHJcbiAgICBjb25zdCBub2RlID0gZWxlbWVudCgnZGl2JywgW1xyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAnc2stY3ViZSBzay1jdWJlMScgfSksXHJcbiAgICAgICAgZWxlbWVudCgnZGl2JywgbnVsbCwgeyBjbGFzc0xpc3Q6ICdzay1jdWJlIHNrLWN1YmUyJyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3NrLWN1YmUgc2stY3ViZTMnIH0pLFxyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAnc2stY3ViZSBzay1jdWJlNCcgfSksXHJcbiAgICAgICAgZWxlbWVudCgnZGl2JywgbnVsbCwgeyBjbGFzc0xpc3Q6ICdzay1jdWJlIHNrLWN1YmU1JyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3NrLWN1YmUgc2stY3ViZTYnIH0pLFxyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAnc2stY3ViZSBzay1jdWJlNycgfSksXHJcbiAgICAgICAgZWxlbWVudCgnZGl2JywgbnVsbCwgeyBjbGFzc0xpc3Q6ICdzay1jdWJlIHNrLWN1YmU4JyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3NrLWN1YmUgc2stY3ViZTknIH0pLFxyXG4gICAgXSwgeyBjbGFzc0xpc3Q6ICdzay1jdWJlLWdyaWQnIH0pO1xyXG4gICAgaWYgKGlkKSB7XHJcbiAgICAgICAgbm9kZS5zZXRBdHRyaWJ1dGUoJ2lkJywgaWQpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBub2RlO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gTG9hZGluZyh7IGlkLCBjb2xvciA9ICd3aGl0ZScgfSkge1xyXG4gICAgY29uc3Qgbm9kZSA9IGVsZW1lbnQoJ2RpdicsIFtcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3JlY3QxJyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3JlY3QyJyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3JlY3QzJyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3JlY3Q0JyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3JlY3Q1JyB9KSxcclxuICAgIF0sIHsgY2xhc3NMaXN0OiBnZXRDbGFzcygpIH0pO1xyXG4gICAgaWYgKGlkKSB7XHJcbiAgICAgICAgbm9kZS5zZXRBdHRyaWJ1dGUoJ2lkJywgaWQpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBub2RlO1xyXG5cclxuXHJcbiAgICBmdW5jdGlvbiBnZXRDbGFzcygpIHtcclxuICAgICAgICByZXR1cm4gYHNwaW5uZXIgJHtjb2xvcn1gO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gUmVtb3RlKHsgc3JjLCBwYXJzZSwgY29tcG9uZW50LCBjb2xvciA9ICd3aGl0ZScsIG9uUmVhZHksIG9uRXJyb3IgfSkge1xyXG4gICAgY29uc3QgaWQgPSB1dWlkKCk7XHJcbiAgICByZXNvbHZlKCk7XHJcblxyXG4gICAgY29uc3QgbG9hZGVyID0gTG9hZGluZyh7IGlkLCBjb2xvciB9KTtcclxuXHJcbiAgICByZXR1cm4gbG9hZGVyO1xyXG5cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiByZXNvbHZlKCkge1xyXG4gICAgICAgIGxldCBkYXRhID0gYXdhaXQgKGFzeW5jICgpID0+IHtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBhd2FpdCAoc3JjIGluc3RhbmNlb2YgUHJvbWlzZSkgPyBzcmMgOiBzcmMoKTtcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKG9uRXJyb3IpIHtcclxuICAgICAgICAgICAgICAgICAgICBvbkVycm9yKGUsIGxvYWRlcik7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNvbnN0IHJldHJ5QnRuID0gZWxlbWVudCgnYnV0dG9uJywgW1xyXG4gICAgICAgICAgICAgICAgICAgIGVsZW1lbnQoJ2knLCBudWxsLCB7IGNsYXNzTmFtZTogJ2dseXBoaWNvbiBnbHlwaGljb24tcmVwZWF0JyB9KSxcclxuICAgICAgICAgICAgICAgICAgICAnUmV0cnknXHJcbiAgICAgICAgICAgICAgICBdLCB7IHN0eWxlOiAnYmFja2dyb3VuZC1jb2xvcjogZ3JlZW4nIH0pO1xyXG4gICAgICAgICAgICAgICAgcmV0cnlCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVwbGFjZVNlbGYoUmVtb3RlKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3JjLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXJzZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29tcG9uZW50LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvclxyXG4gICAgICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGVsZW1lbnQoJ2RpdicsIFtcclxuICAgICAgICAgICAgICAgICAgICBlbGVtZW50KCdpJywgbnVsbCwgeyBjbGFzc05hbWU6ICdnbHlwaGljb24gZ2x5cGhpY29uLXJlbW92ZScsIHN0eWxlOiAnY29sb3I6IHJlZCcgfSksXHJcbiAgICAgICAgICAgICAgICAgICAgZS5tZXNzYWdlLFxyXG4gICAgICAgICAgICAgICAgICAgIHJldHJ5QnRuXHJcbiAgICAgICAgICAgICAgICBdLCB7IGlkOiBpZCB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKCk7XHJcblxyXG4gICAgICAgIGlmIChwYXJzZSkge1xyXG4gICAgICAgICAgICBkYXRhID0gcGFyc2UoZGF0YSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXBsYWNlU2VsZihkYXRhKTtcclxuXHJcbiAgICAgICAgZnVuY3Rpb24gcmVwbGFjZVNlbGYoZGF0YSkge1xyXG4gICAgICAgICAgICAvL2NvbnN0IGxvYWRlciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKTtcclxuICAgICAgICAgICAgY29uc3QgcGFyZW50ID0gbG9hZGVyLnBhcmVudE5vZGU7XHJcblxyXG4gICAgICAgICAgICBpZiAoY29tcG9uZW50KSB7XHJcbiAgICAgICAgICAgICAgICBwYXJlbnQuaW5zZXJ0QmVmb3JlKGNvbXBvbmVudChkYXRhKSwgbG9hZGVyKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGFwcGVuZChkYXRhKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvL2F3YWl0IG5ldyBQcm9taXNlKHJlc29sdmUgPT4gc2V0VGltZW91dCgxMCwgcmVzb2x2ZSkpO1xyXG4gICAgICAgICAgICAvL2NvbnNvbGUubG9nKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKSk7XHJcbiAgICAgICAgICAgIGxvYWRlci5yZW1vdmUoKTtcclxuICAgICAgICAgICAgaWYgKG9uUmVhZHkpIHtcclxuICAgICAgICAgICAgICAgIG9uUmVhZHkoKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgZnVuY3Rpb24gYXBwZW5kKGNoaWxkKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIChjaGlsZCkgPT09ICdzdHJpbmcnIHx8IHR5cGVvZiAoY2hpbGQpID09PSAnbnVtYmVyJykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChjaGlsZC50b1N0cmluZygpLnRyaW0oKVswXSA9PT0gJzwnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGZyYWdtZW50ID0gZWxlbWVudCgnZGl2JywgY2hpbGQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmcmFnbWVudC5jaGlsZE5vZGVzLmZvckVhY2gobiA9PiBwYXJlbnQuaW5zZXJ0QmVmb3JlKG4uY2xvbmVOb2RlKHRydWUpLCBsb2FkZXIpKTtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXJlbnQuaW5zZXJ0QmVmb3JlKGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKGNoaWxkKSwgbG9hZGVyKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkoY2hpbGQpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgbm9kZSBvZiBjaGlsZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBhcHBlbmQobm9kZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBwYXJlbnQuaW5zZXJ0QmVmb3JlKGNoaWxkLCBsb2FkZXIpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gWWVzKCkge1xyXG4gICAgY29uc3QgZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdpJyk7XHJcbiAgICBlbC5jbGFzc05hbWUgPSAnZ2x5cGhpY29uIGdseXBoaWNvbi1vayc7XHJcbiAgICBlbC5zdHlsZS5jb2xvciA9ICdncmVlbic7XHJcbiAgICByZXR1cm4gZWw7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBObygpIHtcclxuICAgIGNvbnN0IGVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaScpO1xyXG4gICAgZWwuY2xhc3NOYW1lID0gJ2dseXBoaWNvbiBnbHlwaGljb24tcmVtb3ZlJztcclxuICAgIGVsLnN0eWxlLmNvbG9yID0gJ3JlZCc7XHJcbiAgICByZXR1cm4gZWw7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBRdWVzdGlvbihbdGl0bGUsIGFuc3dlcnNdKSB7XHJcbiAgICByZXR1cm4gZWxlbWVudCgnZGl2JywgW1xyXG4gICAgICAgIGVsZW1lbnQoJ2gyJywgdGl0bGUpLFxyXG4gICAgICAgIGVsZW1lbnQoJ3VsJywgT2JqZWN0LmVudHJpZXMoYW5zd2VycykubWFwKChbYSwgaXNDb3JyZWN0XSkgPT4gZWxlbWVudCgnbGknLCBhLCB7IGNsYXNzTGlzdDogaXNDb3JyZWN0ID8gJ2NvcnJlY3QtYW5zd2VyJyA6ICdub25lJyB9LCB0cnVlKSkpXHJcbiAgICBdLCB7IGNsYXNzTGlzdDogJ3F1ZXN0aW9uLWNvbnRhaW5lcicgfSk7XHJcbn07XHJcblxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIEFsZXJ0KCkge1xyXG4gICAgY29uc3QgZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdpJyk7XHJcbiAgICBlbC5jbGFzc05hbWUgPSAnZ2x5cGhpY29uIGdseXBoaWNvbi13YXJuaW5nLXNpZ24nO1xyXG4gICAgZWwuc3R5bGUuY29sb3IgPSAnb3JhbmdlJztcclxuICAgIHJldHVybiBlbDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIENvbnRhaW5lcih7IGNoaWxkcmVuLCBjbGFzc05hbWUgfSkge1xyXG4gICAgY29uc3Qgc2VjdGlvbiA9IGVsZW1lbnQoJ3NlY3Rpb24nLCBjaGlsZHJlbiwge1xyXG4gICAgICAgIGNsYXNzTmFtZTogY2xhc3NOYW1lID8gJ2V2ZW50LWNvbnRhaW5lcicgOiAnY29udGFpbmVyJ1xyXG4gICAgfSk7XHJcbiAgICBjb25zdCBlbCA9IGVsZW1lbnQoJ2RpdicsIHNlY3Rpb24sIHtcclxuICAgICAgICBjbGFzc05hbWU6IGNsYXNzTmFtZSA/IGNsYXNzTmFtZSA6ICdjb250YWluZXIgYWRtaW5pc3RyYXRpb24tY29udGFpbmVyIHNlcy1jb250YWluZXInXHJcbiAgICB9KTtcclxuICAgIHJldHVybiBlbDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHBvcHVwVGFibGUoZGF0YSkge1xyXG4gICAgbGV0IGh0bWwgPSBgXHJcbiAgICAgICAgPHN0eWxlPlxyXG4gICAgICAgICAgICB0YWJsZSB7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRyLCB0ZCwgdGgge1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgYmxhY2s7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAwLjI1ZW0gMC41ZW07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICA8L3N0eWxlPlxyXG4gICAgICAgIGA7XHJcbiAgICBodG1sICs9ICc8dGFibGU+PHRoZWFkPjx0cj4nO1xyXG4gICAgZm9yIChsZXQgY29sIG9mIGRhdGFbMF0pIHtcclxuICAgICAgICBodG1sICs9IGA8dGg+JHtjb2x9PC90aD5gO1xyXG4gICAgfVxyXG4gICAgaHRtbCArPSAnPC90cj48L3RoZWFkPjx0Ym9keT4nO1xyXG4gICAgZm9yIChsZXQgcm93ID0gMTsgcm93IDwgZGF0YS5sZW5ndGg7IHJvdysrKSB7XHJcbiAgICAgICAgaHRtbCArPSAnPHRyPic7XHJcbiAgICAgICAgZm9yIChsZXQgY29sIG9mIGRhdGFbcm93XSkge1xyXG4gICAgICAgICAgICBodG1sICs9IGA8dGQ+JHtjb2x9PC90ZD5gO1xyXG4gICAgICAgIH1cclxuICAgICAgICBodG1sICs9ICc8L3RyPic7XHJcbiAgICB9XHJcbiAgICBodG1sICs9ICc8L3Rib2R5PjwvdGFibGU+JztcclxuICAgIHJldHVybiBodG1sO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0RWRpdG9yRGVjb3JhdGlvbihlbGVtZW50KSB7XHJcbiAgICBmdW5jdGlvbiBlbmFibGUoKSB7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QuYWRkKCdlbmFibGVkJyk7XHJcbiAgICB9XHJcbiAgICBmdW5jdGlvbiBkaXNhYmxlKCkge1xyXG4gICAgICAgIGVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnZW5hYmxlZCcpO1xyXG4gICAgfVxyXG4gICAgZnVuY3Rpb24gd29ya2luZygpIHtcclxuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ2VuYWJsZWQnKTtcclxuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5hZGQoJ3dvcmtpbmcnKTtcclxuICAgIH1cclxuICAgIGZ1bmN0aW9uIHVwZGF0ZWQoKSB7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCd3b3JraW5nJyk7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QuYWRkKCd1cGRhdGVkJyk7XHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ3VwZGF0ZWQnKSwgMzAwMCk7XHJcbiAgICB9XHJcbiAgICBmdW5jdGlvbiBmYWlsdXJlKCkge1xyXG4gICAgICAgIGVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnd29ya2luZycpO1xyXG4gICAgICAgIGVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnZmFpbGVkJyk7XHJcbiAgICB9XHJcbiAgICBmdW5jdGlvbiBfY2xlYXIoKSB7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdlbmFibGVkJyk7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCd3b3JraW5nJyk7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCd1cGRhdGVkJyk7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdmYWlsZWQnKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGVuYWJsZSxcclxuICAgICAgICBkaXNhYmxlLFxyXG4gICAgICAgIHdvcmtpbmcsXHJcbiAgICAgICAgdXBkYXRlZCxcclxuICAgICAgICBmYWlsdXJlLFxyXG4gICAgICAgIF9jbGVhclxyXG4gICAgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGFwcGx5QmVnaW5SZXF1ZXN0KGVsZW1lbnQpIHtcclxuICAgIGVsZW1lbnQuY2hpbGROb2Rlcy5mb3JFYWNoKGMgPT4gYy5jaGlsZE5vZGVzLmZvckVhY2gobiA9PiBuLmRpc2FibGVkID0gdHJ1ZSkpO1xyXG4gICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdlbmFibGVkJyk7XHJcbiAgICBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ2ZhaWxlZCcpO1xyXG4gICAgZWxlbWVudC5jbGFzc0xpc3QuYWRkKCd3b3JraW5nJyk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBhcHBseVJlcXVlc3RTdWNjZXNzKGVsZW1lbnQpIHtcclxuICAgIGVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnd29ya2luZycpO1xyXG4gICAgZWxlbWVudC5jbGFzc0xpc3QuYWRkKCd1cGRhdGVkJyk7XHJcbiAgICBzZXRUaW1lb3V0KCgpID0+IGVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgndXBkYXRlZCcpLCAzMDAwKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGFwcGx5UmVxdWVzdEVycm9yKHJlZkVsZW1lbnQsIGVycm9yQ29udGFpbmVyLCBmaWVsZHMpIHtcclxuICAgIHJlZkVsZW1lbnQuY2hpbGROb2Rlcy5mb3JFYWNoKGMgPT4gYy5jaGlsZE5vZGVzLmZvckVhY2gobiA9PiBuLmRpc2FibGVkID0gZmFsc2UpKTtcclxuICAgIHJlZkVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnd29ya2luZycpO1xyXG4gICAgcmVmRWxlbWVudC5jbGFzc0xpc3QuYWRkKCdmYWlsZWQnKTtcclxuICAgIGNvbnNvbGUud2FybihlcnJvckNvbnRhaW5lcik7XHJcbiAgICBpZiAoZXJyb3JDb250YWluZXIubWVzc2FnZSAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgYWxlcnQoZXJyb3JDb250YWluZXIubWVzc2FnZSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIGZvciAobGV0IGVycm9yIG9mIE9iamVjdC5rZXlzKGVycm9yQ29udGFpbmVyKSkge1xyXG4gICAgICAgICAgICBpZiAoZXJyb3IubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgIGFsZXJ0KGVycm9yQ29udGFpbmVyW2Vycm9yXS5lcnJvcnMuam9pbignXFxuJykpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgZmllbGQgPSBmaWVsZHNbZXJyb3JdO1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgbWVzc2FnZSBvZiBlcnJvckNvbnRhaW5lcltlcnJvcl0uZXJyb3JzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZmllbGQuYXBwZW5kQ2hpbGQoZWxlbWVudCgncCcsIG1lc3NhZ2UpKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUNoZWNrYm94KG5hbWUsIGRhdGEsIHRleHQsIG9uQ2hhbmdlLCBkZWZhdWx0VmFsdWUgPSBmYWxzZSkge1xyXG4gICAgY29uc3QgaWQgPSAnc2VzLScgKyBuYW1lO1xyXG4gICAgbGV0IHZhbHVlID0gcmVhZFByZXZJbnB1dCgpO1xyXG4gICAgZGF0YVtuYW1lXSA9IHZhbHVlO1xyXG4gICAgbGV0IGVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdpbnB1dCcpO1xyXG4gICAgZWxlbWVudC50eXBlID0gJ2NoZWNrYm94JztcclxuICAgIGVsZW1lbnQuaWQgPSBpZDtcclxuICAgIGVsZW1lbnQubmFtZSA9IG5hbWU7XHJcbiAgICBsZXQgbGFiZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsYWJlbCcpO1xyXG4gICAgbGFiZWwuaHRtbEZvciA9IGlkO1xyXG4gICAgbGFiZWwudGV4dENvbnRlbnQgPSB0ZXh0O1xyXG5cclxuICAgIC8qXHJcbiAgICBsZXQgZWxlbWVudCA9IDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBjbGFzc05hbWU9XCJzZXMtY2hlY2tcIiBpZD17aWR9IG5hbWU9e25hbWV9IC8+O1xyXG4gICAgbGV0IGxhYmVsID0gPGxhYmVsIGZvcj17aWR9Pnt0ZXh0fTwvbGFiZWw+O1xyXG4gICAgKi9cclxuICAgIGVsZW1lbnQuY2hlY2tlZCA9IHZhbHVlO1xyXG4gICAgZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCB0b2dnbGUpO1xyXG5cclxuICAgIGZ1bmN0aW9uIHJlYWRQcmV2SW5wdXQoKSB7XHJcbiAgICAgICAgbGV0IHByZXZJbnB1dCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKTtcclxuICAgICAgICBpZiAocHJldklucHV0KSB7XHJcbiAgICAgICAgICAgIHJldHVybiBwcmV2SW5wdXQuY2hlY2tlZDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gZGVmYXVsdFZhbHVlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiB0b2dnbGUoZSkge1xyXG4gICAgICAgIHZhbHVlID0gZS50YXJnZXQuY2hlY2tlZDtcclxuICAgICAgICBkYXRhW25hbWVdID0gdmFsdWU7XHJcbiAgICAgICAgcmVkcmF3KCk7XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gcmVkcmF3KCkge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlKCk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVyci5tZXNzYWdlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgY2hlY2tib3ggPSB7XHJcbiAgICAgICAgZWxlbWVudCxcclxuICAgICAgICBsYWJlbFxyXG4gICAgfTtcclxuXHJcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoY2hlY2tib3gsICd2YWx1ZScsIHtcclxuICAgICAgICBnZXQ6ICgpID0+IHZhbHVlLFxyXG4gICAgICAgIHNldDogKG5ld1ZhbHVlKSA9PiB7XHJcbiAgICAgICAgICAgIHZhbHVlID0gbmV3VmFsdWU7XHJcbiAgICAgICAgICAgIGVsZW1lbnQuY2hlY2tlZCA9IHZhbHVlO1xyXG4gICAgICAgICAgICBkYXRhW25hbWVdID0gdmFsdWU7XHJcbiAgICAgICAgICAgIHJlZHJhdygpO1xyXG4gICAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiBjaGVja2JveDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHRhYmxlKGRhdGEsIGxheW91dCkge1xyXG4gICAgY29uc3QgdGhlYWQgPSBlbGVtZW50KCd0aGVhZCcsIGVsZW1lbnQoJ3RyJywgbGF5b3V0Lm1hcChoID0+IGVsZW1lbnQoJ3RoJywgaC5sYWJlbCkpKSk7XHJcbiAgICBjb25zdCB0Ym9keSA9IGVsZW1lbnQoJ3Rib2R5JywgZGF0YS5tYXAociA9PiBlbGVtZW50KCd0cicsIGxheW91dC5tYXAoaCA9PiBlbGVtZW50KCd0ZCcsIHJbaC5uYW1lXSkpKSkpO1xyXG5cclxuICAgIGNvbnN0IHRhYmxlID0gZWxlbWVudCgndGFibGUnLCBbdGhlYWQsIHRib2R5XSk7XHJcbiAgICB0YWJsZS50aGVhZCA9IHRoZWFkO1xyXG4gICAgdGFibGUudGJvZHkgPSB0Ym9keTtcclxuXHJcbiAgICByZXR1cm4gdGFibGU7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBBdXRvY29tcGxldGUoeyB2YWx1ZXMsIGN1cnJlbnQgfSkge1xyXG4gICAgbGV0IGF1dG9jb21wbGV0ZSA9IGVsZW1lbnQoJ2RpdicsIFtcclxuICAgICAgICBlbGVtZW50KCdpbnB1dCcsIHVuZGVmaW5lZCwgeyBjbGFzc05hbWU6ICdzZXMtc2VhcmNoLWF1dG9jb21wbGV0ZS1pbnB1dCcgfSksXHJcbiAgICAgICAgZWxlbWVudCgnZGl2JywgZWxlbWVudCgndWwnKSwgeyBjbGFzc05hbWU6ICdzZXMtc2VhcmNoLWF1dG9jb21wbGV0ZS1zdWdnZXN0aW9ucycgfSlcclxuICAgIF0sIHsgY2xhc3NOYW1lOiAnc2VzLXNlYXJjaC1hdXRvY29tcGxldGUtY29udGFpbmVyJyB9KTtcclxuXHJcbiAgICBjb25zdCBzdWdnZXN0aW9uc0NvbnRhaW5lciA9IGF1dG9jb21wbGV0ZS5xdWVyeVNlbGVjdG9yKCcuc2VzLXNlYXJjaC1hdXRvY29tcGxldGUtc3VnZ2VzdGlvbnMnKTtcclxuICAgIGNvbnN0IGlucHV0ID0gYXV0b2NvbXBsZXRlLnF1ZXJ5U2VsZWN0b3IoJy5zZXMtc2VhcmNoLWF1dG9jb21wbGV0ZS1pbnB1dCcpO1xyXG4gICAgbGV0IHNlbGVjdGVkSW5kZXggPSB1bmRlZmluZWQ7XHJcblxyXG4gICAgaWYgKGN1cnJlbnQgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgaW5wdXQudmFsdWUgPSBjdXJyZW50O1xyXG4gICAgfVxyXG5cclxuICAgIGF1dG9jb21wbGV0ZS5nZXRWYWx1ZSA9IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICByZXR1cm4gaW5wdXQudmFsdWU7XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gc2VhcmNoSGFuZGxlcihlKSB7XHJcbiAgICAgICAgY29uc3QgaW5wdXRWYWwgPSBlLmN1cnJlbnRUYXJnZXQudmFsdWU7XHJcbiAgICAgICAgbGV0IHJlc3VsdHMgPSB2YWx1ZXM7XHJcbiAgICAgICAgaWYgKGlucHV0VmFsLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgcmVzdWx0cyA9IHZhbHVlcy5maWx0ZXIoeCA9PiB4LnRvTG93ZXJDYXNlKCkuaW5kZXhPZihpbnB1dFZhbC50b0xvd2VyQ2FzZSgpKSA+IC0xKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgc2hvd1N1Z2dlc3Rpb25zKHJlc3VsdHMsIGlucHV0VmFsKTtcclxuICAgICAgICBpZiAoZS5rZXlDb2RlID09PSAzOCB8fCBlLmtleUNvZGUgPT09IDQwIHx8IGUua2V5Q29kZSA9PT0gMTMpIHtcclxuICAgICAgICAgICAgc2Nyb2xsUmVzdWx0cyhlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gc2hvd1N1Z2dlc3Rpb25zKHJlc3VsdHMsIGlucHV0VmFsKSB7XHJcbiAgICAgICAgbGV0IHN1Z2dlc3Rpb25zID0gc3VnZ2VzdGlvbnNDb250YWluZXIucXVlcnlTZWxlY3RvcigndWwnKTtcclxuICAgICAgICByZXBsYWNlQ29udGVudHMoc3VnZ2VzdGlvbnMsICcnKTtcclxuICAgICAgICBzdWdnZXN0aW9ucyA9IHN1Z2dlc3Rpb25zQ29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoJ3VsJyk7O1xyXG5cclxuICAgICAgICBpZiAocmVzdWx0cy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcmVzdWx0cy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgbGV0IGl0ZW0gPSByZXN1bHRzW2ldO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgbWF0Y2ggPSBpdGVtLm1hdGNoKG5ldyBSZWdFeHAoaW5wdXRWYWwsICdpJykpO1xyXG4gICAgICAgICAgICAgICAgaXRlbSA9IGl0ZW0ucmVwbGFjZShtYXRjaFswXSwgYDxzdHJvbmc+JHttYXRjaFswXX08L3N0cm9uZz5gKTtcclxuICAgICAgICAgICAgICAgIGxldCBuZXdMaSA9IGVsZW1lbnQoJ2xpJywgaXRlbSwgdW5kZWZpbmVkLCB7IGZvcmNlVHlwZTogXCJIVE1MXCIgfSk7XHJcbiAgICAgICAgICAgICAgICBzdWdnZXN0aW9ucy5hcHBlbmRDaGlsZChuZXdMaSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgc3VnZ2VzdGlvbnMuY2xhc3NMaXN0LmFkZCgnaGFzLXN1Z2dlc3Rpb25zJyk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgc3VnZ2VzdGlvbnMuY2xhc3NMaXN0LnJlbW92ZSgnaGFzLXN1Z2dlc3Rpb25zJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIHVzZVN1Z2dlc3Rpb24oZSkge1xyXG4gICAgICAgIGlucHV0LnZhbHVlID0gZS50YXJnZXQudGV4dENvbnRlbnQ7XHJcbiAgICAgICAgaW5wdXQuZm9jdXMoKTtcclxuICAgICAgICBsZXQgc3VnZ2VzdGlvbnMgPSBzdWdnZXN0aW9uc0NvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCd1bCcpO1xyXG4gICAgICAgIHJlcGxhY2VDb250ZW50cyhzdWdnZXN0aW9ucywgJycpO1xyXG4gICAgICAgIHN1Z2dlc3Rpb25zID0gc3VnZ2VzdGlvbnNDb250YWluZXIucXVlcnlTZWxlY3RvcigndWwnKTtcclxuICAgICAgICBzdWdnZXN0aW9ucy5jbGFzc0xpc3QucmVtb3ZlKCdoYXMtc3VnZ2VzdGlvbnMnKTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBzY3JvbGxSZXN1bHRzKGUpIHtcclxuICAgICAgICBsZXQgYWxsU3VnZ2VzdGlvbnMgPSBbLi4uc3VnZ2VzdGlvbnNDb250YWluZXIucXVlcnlTZWxlY3RvckFsbCgndWwgbGknKV07XHJcbiAgICAgICAgbGV0IG9sZEluZGV4ID0gdW5kZWZpbmVkO1xyXG4gICAgICAgIGxldCBpbmRleENoYW5nZSA9IDE7XHJcblxyXG4gICAgICAgIC8vIGVudGVyXHJcbiAgICAgICAgaWYgKGUua2V5Q29kZSA9PT0gMTMpIHtcclxuICAgICAgICAgICAgaW5wdXQudmFsdWUgPSBhbGxTdWdnZXN0aW9uc1tzZWxlY3RlZEluZGV4XS50ZXh0Q29udGVudDtcclxuICAgICAgICAgICAgc2VsZWN0ZWRJbmRleCA9IHVuZGVmaW5lZDtcclxuICAgICAgICAgICAgbGV0IHN1Z2dlc3Rpb25zID0gc3VnZ2VzdGlvbnNDb250YWluZXIucXVlcnlTZWxlY3RvcigndWwnKTtcclxuICAgICAgICAgICAgc3VnZ2VzdGlvbnMuY2xhc3NMaXN0LnJlbW92ZSgnaGFzLXN1Z2dlc3Rpb25zJyk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChlLmtleUNvZGUgPT09IDQwKSB7XHJcbiAgICAgICAgICAgIC8vIGRvd24gYXJyb3dcclxuICAgICAgICAgICAgaW5kZXhDaGFuZ2UgPSAxO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoZS5rZXlDb2RlID09PSAzOCkge1xyXG4gICAgICAgICAgICAvLyB1cCBhcnJvd1xyXG4gICAgICAgICAgICBpbmRleENoYW5nZSA9IC0xO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHNlbGVjdGVkSW5kZXggPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIHNlbGVjdGVkSW5kZXggPSBpbmRleENoYW5nZSA9PT0gMSA/IDAgOiBhbGxTdWdnZXN0aW9ucy5sZW5ndGggLSAxO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIG9sZEluZGV4ID0gc2VsZWN0ZWRJbmRleDtcclxuICAgICAgICAgICAgc2VsZWN0ZWRJbmRleCA9ICgoc2VsZWN0ZWRJbmRleCArIGluZGV4Q2hhbmdlKSArIGFsbFN1Z2dlc3Rpb25zLmxlbmd0aCkgJSBhbGxTdWdnZXN0aW9ucy5sZW5ndGg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAob2xkSW5kZXggIT09IHVuZGVmaW5lZCAmJiBvbGRJbmRleCA8IGFsbFN1Z2dlc3Rpb25zLmxlbmd0aCkge1xyXG4gICAgICAgICAgICBhbGxTdWdnZXN0aW9uc1tvbGRJbmRleF0uY2xhc3NMaXN0LnJlbW92ZSgnc2VsZWN0ZWQnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGFsbFN1Z2dlc3Rpb25zW3NlbGVjdGVkSW5kZXhdLmNsYXNzTGlzdC5hZGQoJ3NlbGVjdGVkJyk7XHJcbiAgICB9XHJcblxyXG4gICAgaW5wdXQuYWRkRXZlbnRMaXN0ZW5lcigna2V5dXAnLCBzZWFyY2hIYW5kbGVyKTtcclxuICAgIHN1Z2dlc3Rpb25zQ29udGFpbmVyLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgdXNlU3VnZ2VzdGlvbik7XHJcbiAgICByZXR1cm4gYXV0b2NvbXBsZXRlO1xyXG59XHJcblxyXG4vKipcclxuICogQ3JlYXRlcyBhIHNwYW4gZWxlbWVudCB0aGF0IHJlcHJlc2VudHMgYSBkb3dubG9hZCBwcm9ncmVzcyBiYXJcclxuICogQHBhcmFtIHsge2Rvd25sb2FkRnVuY3Rpb246IChvblByb2dyZXNzOiBpbXBvcnQoJy4vdXRpbC5qcycpLk9uUHJvZ3Jlc3NGdW5jdGlvbiksIHJldHVybkZ1bmN0aW9uOiBmdW5jdGlvbn0gfSBzZXR0aW5ncyBDb250YWlucyB0aGUgZnVuY3Rpb24gdGhhdCB3aWxsIGRvd25sb2FkIHRoZSByZXNvdXJjZXMsIHdoaWNoIHdpbGwgYmUgY2FsbGVkIHdpdGggb25Qcm9ncmVzc1xyXG4gKiBhbmQgdGhlIHJldHVybkZ1bmN0aW9uIHdoaWNoIHdpbGwgYmUgY2FsbGVkIHdpdGggdGhlIHJlc3VsdHMgYWZ0ZXIgdGhlIGRvd25sb2FkIGZpbmlzaGVzXHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gRG93bmxvYWRQcm9ncmVzc0Jhcih7IGRvd25sb2FkRnVuY3Rpb24sIHJldHVybkZ1bmN0aW9uIH0pIHtcclxuICAgIGNvbnN0IHBlcmNlbnQgPSA8c3Bhbj4wJTwvc3Bhbj47XHJcbiAgICBjb25zdCBiYXIgPSA8c3BhbiBzdHlsZT17eyBwYWRkaW5nOiAnMCAwLjVlbScsIGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snLCB3aWR0aDogJzI1JScsIGJhY2tncm91bmQ6ICdsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICNmZmEwMDAgMCUsICNlZWUgMCknIH19PntwZXJjZW50fSDQodCy0LDQu9GP0L3QtTwvc3Bhbj47XHJcbiAgICBkb3dubG9hZEZ1bmN0aW9uKG9uUHJvZ3Jlc3MpLnRoZW4oZGF0YSA9PiB7XHJcbiAgICAgICAgaWYgKHJldHVybkZ1bmN0aW9uKSB7XHJcbiAgICAgICAgICAgIHJldHVybkZ1bmN0aW9uKGRhdGEpXHJcbiAgICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIGJhcjtcclxuXHJcbiAgICBmdW5jdGlvbiBvblByb2dyZXNzKGNvbXBsZXRlZCwgdG90YWwsIHJlc3BvbnNlLCBpbmRleCkge1xyXG4gICAgICAgIGNvbnN0IHByb2dyZXNzID0gTWF0aC5mbG9vcihjb21wbGV0ZWQgLyB0b3RhbCAqIDEwMCk7XHJcbiAgICAgICAgcGVyY2VudC50ZXh0Q29udGVudCA9IHByb2dyZXNzICsgJyUnO1xyXG4gICAgICAgIGJhci5zdHlsZS5iYWNrZ3JvdW5kID0gYGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgI2ZmYTAwMCAke3Byb2dyZXNzfSUsICNlZWUgMClgO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCB7XHJcbiAgICBlbGVtZW50XHJcbn07IiwiLyogZ2xvYmFscyB4bHN4LCBKU1ppcCAqL1xyXG5cclxuaW1wb3J0IHBhcnNlIGZyb20gJy4vcGFyc2UnO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGltcG9ydFF1aXpGcm9tWGxzeChibG9iKSB7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XHJcbiAgICAgICAgcmVhZGVyLm9ubG9hZCA9IGZ1bmN0aW9uIChlKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGZpbGVEYXRhID0gZS50YXJnZXQucmVzdWx0O1xyXG4gICAgICAgICAgICBjb25zdCB3YiA9IHhsc3gucmVhZChmaWxlRGF0YSwge1xyXG4gICAgICAgICAgICAgICAgdHlwZTogJ2JpbmFyeSdcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIGNvbnN0IGZpcnN0U2hlZXQgPSB3Yi5TaGVldHNbd2IuU2hlZXROYW1lc1swXV07XHJcbiAgICAgICAgICAgIGNvbnN0IGFwaURhdGEgPSB4bHN4LnV0aWxzXHJcbiAgICAgICAgICAgICAgICAuc2hlZXRfdG9fanNvbihmaXJzdFNoZWV0LCB7IGhlYWRlcjogMSB9KVxyXG4gICAgICAgICAgICAgICAgLnNsaWNlKDEpIC8vIHJlbW92ZSBmaXJzdCByb3dcclxuICAgICAgICAgICAgICAgIC5yZWR1Y2UoKGRhdGEsIGN1cnJlbnRSb3cpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoY3VycmVudFJvdy5sZW5ndGggIT09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY29ycmVjdEFuc3dlckluZGV4ID0gY3VycmVudFJvdy5wb3AoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcXVlc3Rpb24gPSBjdXJyZW50Um93WzBdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBhbGxBbnN3ZXJzID0gY3VycmVudFJvdy5zbGljZSgxKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY29ycmVjdEFuc3dlciA9IGN1cnJlbnRSb3dbY29ycmVjdEFuc3dlckluZGV4XTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGFbcXVlc3Rpb25dID0gYWxsQW5zd2Vycy5yZWR1Y2UoKGFuc3dlcnMsIGEpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChhICE9IHVuZGVmaW5lZCAmJiBhLnRvU3RyaW5nKCkudHJpbSgpICE9PSAnJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcnNbYV0gPSBhID09PSBjb3JyZWN0QW5zd2VyO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBhbnN3ZXJzO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LCB7fSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZGF0YTtcclxuICAgICAgICAgICAgICAgIH0sIHt9KTtcclxuXHJcbiAgICAgICAgICAgIHJlc29sdmUoYXBpRGF0YSk7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgcmVhZGVyLnJlYWRBc0JpbmFyeVN0cmluZyhibG9iKTtcclxuICAgIH0pO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaW1wb3J0RnJvbVhsc3goYmxvYiwgdXNlQ2VsbERhdGVzID0gZmFsc2UpIHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcclxuICAgICAgICByZWFkZXIub25sb2FkID0gZnVuY3Rpb24gKGUpIHtcclxuICAgICAgICAgICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LnJlc3VsdDtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHdiID0geGxzeC5yZWFkKGZpbGUsIHtcclxuICAgICAgICAgICAgICAgICAgICB0eXBlOiAnYmluYXJ5JyxcclxuICAgICAgICAgICAgICAgICAgICBjZWxsRGF0ZXM6IHVzZUNlbGxEYXRlc1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBmaXJzdFNoZWV0ID0gd2IuU2hlZXRzW3diLlNoZWV0TmFtZXNbMF1dO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgZGF0YSA9IHhsc3gudXRpbHMuc2hlZXRfdG9fanNvbihmaXJzdFNoZWV0LCB7IGhlYWRlcjogMSB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICByZXNvbHZlKGRhdGEpO1xyXG4gICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdFcnJvciBwYXJzaW5nIFhMU1ggZmlsZSwgbWFrZSBzdXJlIHRoZSBsaWJyYXJ5IGlzIGxvYWRlZCcpO1xyXG4gICAgICAgICAgICAgICAgcmVqZWN0KGVycik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgICAgIHJlYWRlci5vbmVycm9yID0gZnVuY3Rpb24gKGUpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ0Vycm9yIHJlYWRpbmcgZmlsZScpO1xyXG4gICAgICAgICAgICByZWplY3QoZSk7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgcmVhZGVyLnJlYWRBc0JpbmFyeVN0cmluZyhibG9iKTtcclxuICAgIH0pO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdG9YbHN4RmlsZSh0YWJsZSwgbmFtZSA9ICdPdXRwdXQnLCB3c19uYW1lKSB7XHJcbiAgICBpZiAod3NfbmFtZSA9PT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgd3NfbmFtZSA9IG5hbWUuc2xpY2UoMCwgMzEpO1xyXG4gICAgfVxyXG4gICAgY29uc3Qgd2IgPSB4bHN4LnV0aWxzLmJvb2tfbmV3KCksIHdzID0geGxzeC51dGlscy5hb2FfdG9fc2hlZXQodGFibGUpO1xyXG4gICAgLy8gd2IuV29ya2Jvb2sgPSB7IFZpZXdzOiBbJ1dpbmRvdzInXSB9O1xyXG4gICAgeGxzeC51dGlscy5ib29rX2FwcGVuZF9zaGVldCh3Yiwgd3MsIHdzX25hbWUpO1xyXG4gICAgY29uc3QgZGF0YSA9IHhsc3gud3JpdGUod2IsIHtcclxuICAgICAgICB0eXBlOiAnYXJyYXknLFxyXG4gICAgICAgIGJvb2tUeXBlOiAneGxzeCdcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IGZpbGUgPSBuZXcgRmlsZShbZGF0YV0sIG5hbWUgKyAnLnhsc3gnLCB7IHR5cGU6ICdhcHBsaWNhdGlvbi92bmQub3BlbnhtbGZvcm1hdHMtb2ZmaWNlZG9jdW1lbnQuc3ByZWFkc2hlZXRtbC5zaGVldCcgfSk7XHJcblxyXG4gICAgcmV0dXJuIGZpbGU7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiB0b0xlZ2FjeVhsc0ZpbGUodGFibGUsIG5hbWUgPSAnT3V0cHV0Jywgd3NfbmFtZSkge1xyXG4gICAgaWYgKHdzX25hbWUgPT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgIHdzX25hbWUgPSBuYW1lLnNsaWNlKDAsIDMxKTtcclxuICAgIH1cclxuICAgIGNvbnN0IHdiID0geGxzeC51dGlscy5ib29rX25ldygpLCB3cyA9IHhsc3gudXRpbHMuYW9hX3RvX3NoZWV0KHRhYmxlKTtcclxuICAgIHdiLldvcmtib29rID0geyBWaWV3czogWydXaW5kb3cyJ10gfTtcclxuICAgIHhsc3gudXRpbHMuYm9va19hcHBlbmRfc2hlZXQod2IsIHdzLCB3c19uYW1lKTtcclxuICAgIGNvbnN0IGRhdGEgPSB4bHN4LndyaXRlKHdiLCB7XHJcbiAgICAgICAgdHlwZTogJ2FycmF5JyxcclxuICAgICAgICBib29rVHlwZTogJ2JpZmY4J1xyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgZmlsZSA9IG5ldyBGaWxlKFtkYXRhXSwgbmFtZSArICcueGxzJywgeyB0eXBlOiAnYXBwbGljYXRpb24vdm5kLm1zLWV4Y2VsJyB9KTtcclxuXHJcbiAgICByZXR1cm4gZmlsZTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGV4cG9ydFRvWGxzeCh0YWJsZSwgbmFtZSA9ICdPdXRwdXQnLCB3c19uYW1lKSB7XHJcbiAgICBjb25zdCBmaWxlbmFtZSA9IGAke25hbWV9Lnhsc3hgO1xyXG4gICAgaWYgKHdzX25hbWUgPT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgIHdzX25hbWUgPSBuYW1lLnNsaWNlKDAsIDMxKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBTaGVldCBuYW1lIGNhbm5vdCBjb250YWluOiBcXCAvID8gKiBbIF1cclxuICAgIGNvbnN0IHNoZWV0UmVnZXggPSAvW1xcW1xcXVxcXFxcXC9cXCpdL2dpO1xyXG4gICAgaWYgKHNoZWV0UmVnZXgudGVzdCh3c19uYW1lKSkge1xyXG4gICAgICAgIHdzX25hbWUgPSB3c19uYW1lLnJlcGxhY2Uoc2hlZXRSZWdleCwgJy0nKTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCB3YiA9IHhsc3gudXRpbHMuYm9va19uZXcoKSwgd3MgPSB4bHN4LnV0aWxzLmFvYV90b19zaGVldCh0YWJsZSk7XHJcbiAgICB4bHN4LnV0aWxzLmJvb2tfYXBwZW5kX3NoZWV0KHdiLCB3cywgd3NfbmFtZSk7XHJcbiAgICB4bHN4LndyaXRlRmlsZSh3YiwgZmlsZW5hbWUpO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZXhwb3J0UGF5bWVudHNUb1hsc3goZGF0YSwgeWVhciwgbW9udGgpIHtcclxuICAgIGNvbnN0IGZpbGVuYW1lID0gYFBheW1lbnRzLSR7cGFyc2UubW9udGhOYW1lW21vbnRoXX0tJHt5ZWFyfS54bHN4YDtcclxuICAgIGNvbnN0IHdzX25hbWUgPSBgUGF5bWVudHMgJHtwYXJzZS5tb250aE5hbWVbbW9udGhdfSAke3llYXJ9YDtcclxuICAgIGNvbnN0IHdiID0geGxzeC51dGlscy5ib29rX25ldygpLCB3cyA9IHhsc3gudXRpbHMuYW9hX3RvX3NoZWV0KGRhdGEpO1xyXG4gICAgeGxzeC51dGlscy5ib29rX2FwcGVuZF9zaGVldCh3Yiwgd3MsIHdzX25hbWUpO1xyXG4gICAgeGxzeC53cml0ZUZpbGUod2IsIGZpbGVuYW1lKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGV4cG9ydFRvSnNvbihkYXRhLCBuYW1lID0gJ091dHB1dCcpIHtcclxuICAgIGNvbnN0IGJsb2IgPSBuZXcgQmxvYihbZGF0YV0sIHsgdHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nIH0pO1xyXG4gICAgaWYgKHdpbmRvdy5uYXZpZ2F0b3IubXNTYXZlT3JPcGVuQmxvYikge1xyXG4gICAgICAgIHdpbmRvdy5uYXZpZ2F0b3IubXNTYXZlQmxvYihibG9iLCBuYW1lICsgJy5qc29uJyk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIHZhciBlbGVtID0gd2luZG93LmRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcclxuICAgICAgICBlbGVtLmhyZWYgPSB3aW5kb3cuVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTtcclxuICAgICAgICBlbGVtLmRvd25sb2FkID0gbmFtZSArICcuanNvbic7XHJcbiAgICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChlbGVtKTtcclxuICAgICAgICBlbGVtLmNsaWNrKCk7XHJcbiAgICAgICAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChlbGVtKTtcclxuICAgIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIEBwYXJhbSB7e2ZvbGRlcjogc3RyaW5nLCBmaWxlczogRmlsZVtdfVtdfSBmaWxlcyBcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB6aXBGaWxlcyhmaWxlcykge1xyXG4gICAgY29uc3QgemlwID0gbmV3IEpTWmlwKCk7XHJcbiAgICBmb3IgKGxldCBlbnRyeSBvZiBmaWxlcykge1xyXG4gICAgICAgIGNvbnN0IGN1cnJlbnQgPSB6aXAuZm9sZGVyKGVudHJ5LmZvbGRlcik7XHJcbiAgICAgICAgY3VycmVudC5maWxlKGVudHJ5LmZpbGVzLnBob3RvLm5hbWUsIGF3YWl0IGJsb2JUb0Jhc2U2NChlbnRyeS5maWxlcy5waG90by5maWxlKSwgeyBiYXNlNjQ6IHRydWUgfSk7XHJcbiAgICAgICAgY3VycmVudC5maWxlKGVudHJ5LmZpbGVzLm1lZGljYWwubmFtZSwgYXdhaXQgYmxvYlRvQmFzZTY0KGVudHJ5LmZpbGVzLm1lZGljYWwuZmlsZSksIHsgYmFzZTY0OiB0cnVlIH0pO1xyXG4gICAgICAgIGN1cnJlbnQuZmlsZShlbnRyeS5maWxlcy5kaXBsb21hLm5hbWUsIGF3YWl0IGJsb2JUb0Jhc2U2NChlbnRyeS5maWxlcy5kaXBsb21hLmZpbGUpLCB7IGJhc2U2NDogdHJ1ZSB9KTtcclxuICAgIH1cclxuICAgIHJldHVybiB6aXAuZ2VuZXJhdGVBc3luYyh7IHR5cGU6ICdibG9iJyB9KTtcclxuXHJcbiAgICBmdW5jdGlvbiBibG9iVG9CYXNlNjQoYmxvYikge1xyXG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShyZXNvbHZlID0+IHtcclxuICAgICAgICAgICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcclxuICAgICAgICAgICAgcmVhZGVyLm9ubG9hZCA9IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGRhdGFVcmwgPSByZWFkZXIucmVzdWx0O1xyXG4gICAgICAgICAgICAgICAgY29uc3QgYmFzZTY0ID0gZGF0YVVybC5zcGxpdCgnLCcpWzFdO1xyXG4gICAgICAgICAgICAgICAgcmVzb2x2ZShiYXNlNjQpO1xyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICByZWFkZXIucmVhZEFzRGF0YVVSTChibG9iKTtcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcbn1cclxuXHJcbmNvbnN0IG1pbWVzID0ge1xyXG4gICAgJ2JtcCc6ICdpbWFnZS9ibXAnLFxyXG4gICAgJ2dpZic6ICdpbWFnZS9naWYnLFxyXG4gICAgJ2pwZWcnOiAnaW1hZ2UvanBlZycsXHJcbiAgICAnanBnJzogJ2ltYWdlL2pwZWcnLFxyXG4gICAgJ3BuZyc6ICdpbWFnZS9wbmcnLFxyXG4gICAgJ3BkZic6ICdhcHBsaWNhdGlvbi9wZGYnLFxyXG4gICAgJ3RpZic6ICdpbWFnZS90aWZmJyxcclxuICAgICd0aWZmJzogJ2ltYWdlL3RpZmYnLFxyXG4gICAgJ3dlYnAnOiAnaW1hZ2Uvd2VicCcsXHJcbiAgICAnemlwJzogJ2FwcGxpY2F0aW9uL3ppcCcsXHJcbiAgICAnN3onOiAnYXBwbGljYXRpb24veC03ei1jb21wcmVzc2VkJyxcclxuICAgICd0YXInOiAnYXBwbGljYXRpb24veC10YXInLFxyXG4gICAgJ3Jhcic6ICdhcHBsaWNhdGlvbi92bmQucmFyJ1xyXG59O1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGdldE1pbWUoZXh0ZW5zaW9uKSB7XHJcbiAgICBleHRlbnNpb24gPSBleHRlbnNpb24udG9Mb2NhbGVMb3dlckNhc2UoKTtcclxuICAgIHJldHVybiBtaW1lc1tleHRlbnNpb25dIHx8ICdhcHBsaWNhdGlvbi9vY3RldC1zdHJlYW0nO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gb3BlbkZpbGUoZmlsZSwgbmFtZSA9ICdvdXRwdXQudHh0Jykge1xyXG4gICAgdHJ5IHtcclxuICAgICAgICB2YXIgZWxlbSA9IHdpbmRvdy5kb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XHJcbiAgICAgICAgZWxlbS50YXJnZXQgPSAnX2JsYW5rJztcclxuICAgICAgICBlbGVtLmRvd25sb2FkID0gbmFtZTtcclxuICAgICAgICBjb25zdCBocmVmID0gd2luZG93LlVSTC5jcmVhdGVPYmplY3RVUkwoZmlsZSk7XHJcbiAgICAgICAgZWxlbS5ocmVmID0gaHJlZjtcclxuICAgICAgICBlbGVtLmNsaWNrKCk7XHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiBVUkwucmV2b2tlT2JqZWN0VVJMKGhyZWYpLCA2MDAwMCk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBkb3dubG9hZChibG9iLCBuYW1lID0gJ291dHB1dC50eHQnKSB7XHJcbiAgICBpZiAod2luZG93Lm5hdmlnYXRvci5tc1NhdmVPck9wZW5CbG9iKSB7XHJcbiAgICAgICAgd2luZG93Lm5hdmlnYXRvci5tc1NhdmVCbG9iKGJsb2IsIG5hbWUpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICB2YXIgZWxlbSA9IHdpbmRvdy5kb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XHJcbiAgICAgICAgZWxlbS50YXJnZXQgPSAnX2JsYW5rJztcclxuICAgICAgICBjb25zdCBocmVmID0gd2luZG93LlVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYik7XHJcbiAgICAgICAgZWxlbS5ocmVmID0gaHJlZjtcclxuICAgICAgICBlbGVtLmRvd25sb2FkID0gbmFtZTtcclxuICAgICAgICBlbGVtLmNsaWNrKCk7XHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiBVUkwucmV2b2tlT2JqZWN0VVJMKGhyZWYpLCA2MDAwMCk7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcm9zc0Jyb3dzZXJGaWxlVXBsb2FkKGFwaUNhbGwsIGZpbGUpIHtcclxuICAgIGlmICghIXdpbmRvdy5jaHJvbWUpIHtcclxuICAgICAgICBjb25zdCBmaWxlVXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChmaWxlKTtcclxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBhcGlDYWxsKHsgZmlsZVVybCwgbmFtZTogZmlsZS5uYW1lIH0pO1xyXG4gICAgICAgIFVSTC5yZXZva2VPYmplY3RVUkwoZmlsZVVybCk7XHJcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIGF3YWl0IGFwaUNhbGwoeyBmaWxlIH0pO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0U3Vic2l0ZSgpIHtcclxuICAgIHN3aXRjaCAod2luZG93LmxvY2F0aW9uLmhvc3Quc3Vic3RyKDAsIDcpKSB7XHJcbiAgICAgICAgY2FzZSAnZGlnaXRhbCc6XHJcbiAgICAgICAgICAgIHJldHVybiAnZGlnaXRhbCc7XHJcbiAgICAgICAgY2FzZSAnY3JlYXRpdic6XHJcbiAgICAgICAgICAgIHJldHVybiAnY3JlYXRpdmUnO1xyXG4gICAgICAgIGNhc2UgJ3BsYXRmb3InOlxyXG4gICAgICAgICAgICByZXR1cm4gJ3BsYXRmb3JtJztcclxuICAgICAgICBjYXNlICdhaS5zb2Z0JzpcclxuICAgICAgICAgICAgcmV0dXJuICdhaSc7XHJcbiAgICAgICAgY2FzZSAnZmluYW5jZSc6XHJcbiAgICAgICAgICAgIHJldHVybiAnZmluYW5jZWFjYWRlbXknO1xyXG4gICAgICAgIGNhc2UgJ2Rldi5kaWcnOlxyXG4gICAgICAgICAgICByZXR1cm4gJ2RldmRpZ2l0YWwnO1xyXG4gICAgICAgIGNhc2UgJ2Rldi5zb2YnOlxyXG4gICAgICAgICAgICByZXR1cm4gJ2RldnNvZnR1bmknO1xyXG4gICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgIHJldHVybiAncHJvZ3JhbW1pbmcnO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaGFzQ1BPQWNjZXNzKCkge1xyXG4gICAgcmV0dXJuIFsnZGlnaXRhbCcsICdjcmVhdGl2ZScsICdwcm9ncmFtbWluZycsICdkZXZkaWdpdGFsJywgJ2RldnNvZnR1bmknXS5pbmNsdWRlcyhnZXRTdWJzaXRlKCkpO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaXNBZG1pbigpIHtcclxuICAgIGNvbnN0IGUgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCdhW2hyZWY9XCIvYWRtaW5pc3RyYXRpb24vbmF2aWdhdGlvblwiIGldJyk7XHJcbiAgICBpZiAoZS5sZW5ndGggPiAwKSB7IHJldHVybiB0cnVlOyB9XHJcbiAgICBlbHNlIHsgcmV0dXJuIGZhbHNlOyB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBzZXJpYWxpemVDYWxscyhmbkFycmF5LCBkZWxheSkge1xyXG4gICAgY29uc3QgY2FsbEFycmF5ID0gW107XHJcblxyXG4gICAgaWYgKGRlbGF5ICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGZuQXJyYXkubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgY29uc3QgaGFuZGxlciA9IChyZXMsIHJlaikgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0VGltZW91dChhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZm5BcnJheVtpXSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXMocmVzdWx0KTtcclxuICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVqKGVycik7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSwgaSAqIGRlbGF5KTtcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgY29uc3QgcHIgPSBuZXcgUHJvbWlzZShoYW5kbGVyKTtcclxuXHJcbiAgICAgICAgICAgIGNhbGxBcnJheS5wdXNoKHByKTtcclxuICAgICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZm5BcnJheS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBjb25zdCBoYW5kbGVyID0gKHJlcywgcmVqKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoaSA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICBjYWxsQXJyYXlbaSAtIDFdLmZpbmFsbHkoYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZm5BcnJheVtpXSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzKHJlc3VsdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVqKGVycik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZm5BcnJheVtpXSgpLnRoZW4ocmVzKS5jYXRjaChyZWopO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBjb25zdCBwciA9IG5ldyBQcm9taXNlKGhhbmRsZXIpO1xyXG5cclxuICAgICAgICAgICAgY2FsbEFycmF5LnB1c2gocHIpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gY2FsbEFycmF5O1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gd2l0aFByb2dyZXNzKGNhbGxBcnJheSwgb25DaGFuZ2UsIGRlbGF5ID0gMTApIHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgLy8gRmFpbHNhdmUgZm9yIGVtcHR5IGNhbGxBcnJheVxyXG4gICAgICAgIGlmIChjYWxsQXJyYXkubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgb25DaGFuZ2UodW5kZWZpbmVkLCAwLCAxLCAxKTtcclxuICAgICAgICAgICAgcmVzb2x2ZShbXSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgcmVzb2x2ZWQgPSAwO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gW107XHJcbiAgICAgICAgY2FsbE5leHQoMCk7XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIGNhbGxOZXh0KGkpIHtcclxuICAgICAgICAgICAgaWYgKGkgPj0gY2FsbEFycmF5Lmxlbmd0aCkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY2FsbEFycmF5W2ldXHJcbiAgICAgICAgICAgICAgICAgICAgLnRoZW4ocmVzID0+IG9uUmVzb2x2ZShyZXMsIGkpKVxyXG4gICAgICAgICAgICAgICAgICAgIC5jYXRjaChvbkVycm9yKTtcclxuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4gY2FsbE5leHQoaSArIDEpLCBkZWxheSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIG9uUmVzb2x2ZShyZXMsIGluZGV4KSB7XHJcbiAgICAgICAgICAgIHJlc29sdmVkKys7XHJcbiAgICAgICAgICAgIGlmIChvbkNoYW5nZSkge1xyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2UocmVzLCBpbmRleCwgcmVzb2x2ZWQsIGNhbGxBcnJheS5sZW5ndGgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJlc3BvbnNlW2luZGV4XSA9IHJlcztcclxuICAgICAgICAgICAgaWYgKHJlc29sdmVkID09PSBjYWxsQXJyYXkubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgICAgICByZXNvbHZlKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZnVuY3Rpb24gb25FcnJvcihlKSB7XHJcbiAgICAgICAgICAgIHJlamVjdChlKTtcclxuICAgICAgICB9XHJcbiAgICB9KTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEB0eXBlZGVmIHsoY29tcGxldGVkOiBudW1iZXIsIHRvdGFsOiBudW1iZXIsIHJlc3BvbnNlLCBpbmRleDogbnVtYmVyKSA9PiB2b2lkfSBPblByb2dyZXNzRnVuY3Rpb25cclxuICovXHJcblxyXG4vKipcclxuICogQHR5cGVkZWYgeygpID0+IFByb21pc2V9IEFzeW5jRnVuY3Rpb25cclxuICovXHJcblxyXG4vKipcclxuICogSW5pdGlhdGUgcmVtb3RlIGNhbGxzIGF0IGludGVydmFsc1xyXG4gKiBAcGFyYW0ge0FycmF5PEFzeW5jRnVuY3Rpb24+fSBmbkFycmF5IFxyXG4gKiBAcGFyYW0ge09uUHJvZ3Jlc3NGdW5jdGlvbn0gb25Qcm9ncmVzcyBcclxuICogQHBhcmFtIHtudW1iZXJ9IFtkZWxheT0xMF1cclxuICogQHJldHVybnMgXHJcbiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGlzdHJpYnV0ZShmbkFycmF5LCBvblByb2dyZXNzLCBkZWxheSA9IDEwKSB7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHRvdGFsID0gZm5BcnJheS5sZW5ndGg7XHJcbiAgICAgICAgbGV0IGNvbXBsZXRlZCA9IDA7XHJcbiAgICAgICAgbGV0IHJlc29sdmVkID0gMDtcclxuXHJcbiAgICAgICAgLy8gRmFpbHNhdmUgZm9yIGVtcHR5IGZuQXJyYXlcclxuICAgICAgICBpZiAodG90YWwgPT0gMCkge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIG9uUHJvZ3Jlc3MgPT0gJ2Z1bmN0aW9uJykge1xyXG4gICAgICAgICAgICAgICAgb25Qcm9ncmVzcyh1bmRlZmluZWQsIDAsIDEsIDEpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJlc29sdmUoW10pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgY2FsbHMgPSBmbkFycmF5Lm1hcCgoZm4sIGkpID0+IHtcclxuICAgICAgICAgICAgY29uc3QgY2FsbCA9IHtcclxuICAgICAgICAgICAgICAgIGZuLFxyXG4gICAgICAgICAgICAgICAgc2VudDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICBjYW5jZWxsZWQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2U6IHVuZGVmaW5lZCxcclxuICAgICAgICAgICAgICAgIHRpbWVyOiBudWxsLFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBjYWxsLm9uQ2FsbCA9IG9uQ2FsbC5iaW5kKGNhbGwsIGkpO1xyXG4gICAgICAgICAgICBjYWxsLmNhbmNlbCA9IG9uQ2FuY2VsLmJpbmQoY2FsbCk7XHJcbiAgICAgICAgICAgIGNhbGwudGltZXIgPSBzZXRUaW1lb3V0KGNhbGwub25DYWxsLCBpICogZGVsYXkpO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuIGNhbGw7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgY2FsbHMuZm9yRWFjaCgoYywgaSkgPT4gYy5uZXh0ID0gY2FsbHNbaSArIDFdKTtcclxuXHJcbiAgICAgICAgYXN5bmMgZnVuY3Rpb24gb25DYWxsKGkpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuc2VudCA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgY2xlYXJUaW1lb3V0KHRoaXMudGltZXIpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNhbmNlbGxlZCA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zZW50ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcHJvbWlzZSA9IHRoaXMuZm4oKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnJlc3BvbnNlID0gYXdhaXQgcHJvbWlzZTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocHJvbWlzZS5fY2FjaGVIaXQgJiYgdGhpcy5uZXh0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubmV4dC5vbkNhbGwoKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZWQrKztcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5jYW5jZWxsZWQgPT0gZmFsc2UgJiYgcmVzb2x2ZWQgPT09IHRvdGFsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUoY2FsbHMubWFwKGMgPT4gYy5yZXNwb25zZSkpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICAgICAgICAgIG9uRXJyb3IoZXJyKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjb21wbGV0ZWQrKztcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBvblByb2dyZXNzID09ICdmdW5jdGlvbicpIHtcclxuICAgICAgICAgICAgICAgIG9uUHJvZ3Jlc3MoY29tcGxldGVkLCB0b3RhbCwgdGhpcy5yZXNwb25zZSwgaSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIG9uQ2FuY2VsKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jYW5jZWxsZWQgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY2FuY2VsbGVkID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLnNlbnQgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICBjbGVhclRpbWVvdXQodGhpcy50aW1lcik7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5vbkNhbGwoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZnVuY3Rpb24gb25FcnJvcihlKSB7XHJcbiAgICAgICAgICAgIGNhbGxzLmZvckVhY2goYyA9PiBjLmNhbmNlbCgpKTtcclxuICAgICAgICAgICAgaWYgKGUgaW5zdGFuY2VvZiBFcnJvcikge1xyXG4gICAgICAgICAgICAgICAgZS5fcmVzcG9uc2VzID0gY2FsbHMubWFwKGMgPT4gYy5yZXNwb25zZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmVqZWN0KGUpO1xyXG4gICAgICAgIH1cclxuICAgIH0pO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gYXNzZXJ0VGVtcGxhdGUodGVtcGxhdGUsIHRhcmdldCwgYm90dG9tID0gZmFsc2UpIHtcclxuICAgIGlmICh0ZW1wbGF0ZS5EYXRhICE9PSB1bmRlZmluZWQgJiYgdGVtcGxhdGUuVG90YWwgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgIHRlbXBsYXRlID0gdGVtcGxhdGUuRGF0YTtcclxuICAgICAgICB0YXJnZXQgPSB0YXJnZXQuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoQXJyYXkuaXNBcnJheSh0ZW1wbGF0ZSkpIHtcclxuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheSh0YXJnZXQpKSB7XHJcbiAgICAgICAgICAgIGlmIChib3R0b20pIHtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGFzc2VydFRlbXBsYXRlKHRlbXBsYXRlWzBdLCB0YXJnZXRbMF0sIHRydWUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignVGFyZ2V0IHR5cGUgbWlzbWF0Y2gnKTtcclxuICAgICAgICB9XHJcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiB0ZW1wbGF0ZSA9PT0gJ29iamVjdCcpIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRhcmdldCA9PT0gJ29iamVjdCcpIHtcclxuICAgICAgICAgICAgY29uc3QgbW9kZWwgPSBPYmplY3Qua2V5cyh0ZW1wbGF0ZSk7XHJcbiAgICAgICAgICAgIGZvciAobGV0IHByb3Agb2YgbW9kZWwpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0YXJnZXQuaGFzT3duUHJvcGVydHkocHJvcCkgPT09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignTWlzc2luZyBwcm9wZXJ0eSBvbiB0YXJnZXQ6ICcgKyBwcm9wKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1RhcmdldCB0eXBlIG1pc21hdGNoJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfSBlbHNlIGlmICh0eXBlb2YgdGVtcGxhdGUgIT09IHR5cGVvZiB0YXJnZXQpIHtcclxuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdUYXJnZXQgdHlwZSBtaXNtYXRjaCcpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGdldExvY2FsZSgpIHtcclxuICAgIHJldHVybiAnYmcnO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlVGhyb3R0bGVkRXhlY3V0b3IoY2FsbGJhY2ssIGRlbGF5KSB7XHJcbiAgICBsZXQgdGltZXIgPSBudWxsO1xyXG5cclxuICAgIHJldHVybiBmdW5jdGlvbiAoLi4ucGFyYW1zKSB7XHJcbiAgICAgICAgY2xlYXIoKTtcclxuICAgICAgICB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICBjbGVhcigpO1xyXG4gICAgICAgICAgICBjYWxsYmFjayguLi5wYXJhbXMpO1xyXG4gICAgICAgIH0sIGRlbGF5KTtcclxuICAgIH07XHJcblxyXG4gICAgZnVuY3Rpb24gY2xlYXIoKSB7XHJcbiAgICAgICAgaWYgKHRpbWVyICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aW1lcik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaWNvbkFzc2V0KG5hbWUpIHtcclxuICAgIHJldHVybiBicm93c2VyLnJ1bnRpbWUuZ2V0VVJMKGBpY29ucy8ke25hbWV9LnBuZ2ApO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZXNjYXBlSFRNTChzdHIpIHtcclxuICAgIHJldHVybiBzdHIucmVwbGFjZSgvWyY8Pl0vZyxcclxuICAgICAgICB0YWcgPT4gKHtcclxuICAgICAgICAgICAgJyYnOiAnJmFtcDsnLFxyXG4gICAgICAgICAgICAnPCc6ICcmbHQ7JyxcclxuICAgICAgICAgICAgJz4nOiAnJmd0OydcclxuICAgICAgICB9W3RhZ10pKVxyXG59O1xyXG5cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRGdW5kYW1lbnRhbExldmVsSWRzKGFwcG5hbWUpIHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgJ3Byb2dyYW1taW5nJzogW1xyXG4gICAgICAgICAgICAxOSxcclxuICAgICAgICAgICAgNDQsXHJcbiAgICAgICAgICAgIDU3LFxyXG4gICAgICAgICAgICA3MCxcclxuICAgICAgICAgICAgMTA2XHJcbiAgICAgICAgXSxcclxuICAgICAgICAnZGlnaXRhbCc6IFtcclxuICAgICAgICAgICAgNixcclxuICAgICAgICAgICAgNyxcclxuICAgICAgICAgICAgOCxcclxuICAgICAgICAgICAgMjMsXHJcbiAgICAgICAgICAgIDI0LFxyXG4gICAgICAgICAgICAyNSxcclxuICAgICAgICAgICAgMjcsXHJcbiAgICAgICAgICAgIDMzLFxyXG4gICAgICAgICAgICAzNSxcclxuICAgICAgICAgICAgNDBcclxuICAgICAgICBdLFxyXG4gICAgICAgICdjcmVhdGl2ZSc6IFtcclxuICAgICAgICAgICAgMjMsXHJcbiAgICAgICAgICAgIDI0LFxyXG4gICAgICAgICAgICA0MixcclxuICAgICAgICAgICAgNTJcclxuICAgICAgICBdXHJcbiAgICB9W2FwcG5hbWVdO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0UHJvZmVzc2lvbkluc3RhbmNlSWRzKGFwcG5hbWUpIHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgLy8gQ29tbWVudGVkIGFyZSBmb3IgUUFcclxuICAgICAgICAncHJvZ3JhbW1pbmcnOiBbXHJcbiAgICAgICAgICAgIDEwMDcsXHJcbiAgICAgICAgICAgIDEwMDksXHJcbiAgICAgICAgICAgIDEwMTAsXHJcbiAgICAgICAgICAgIDEwMTEsXHJcbiAgICAgICAgICAgIDEwMTIsXHJcbiAgICAgICAgICAgIDEwMTMsXHJcbiAgICAgICAgICAgIDEwMTQsXHJcbiAgICAgICAgICAgIDEwMTUsXHJcbiAgICAgICAgICAgIDEwMTYsXHJcbiAgICAgICAgICAgIDEwMTcsXHJcbiAgICAgICAgICAgIDEwMTgsXHJcbiAgICAgICAgICAgIDEwMjAsXHJcbiAgICAgICAgICAgIDEwMjIsXHJcbiAgICAgICAgICAgIDEwMjMsXHJcbiAgICAgICAgICAgIDEwMjQsXHJcbiAgICAgICAgICAgIDEwMjUsXHJcbiAgICAgICAgICAgIDEwMjYsXHJcbiAgICAgICAgICAgIC8vIDEwMjgsXHJcbiAgICAgICAgICAgIDEwMjksXHJcbiAgICAgICAgICAgIDEwMzAsXHJcbiAgICAgICAgICAgIDEwMzEsXHJcbiAgICAgICAgICAgIDEwMzIsXHJcbiAgICAgICAgICAgIDEwMzMsXHJcbiAgICAgICAgICAgIDEwMzQsXHJcbiAgICAgICAgICAgIDEwMzUsXHJcbiAgICAgICAgICAgIDEwMzYsXHJcbiAgICAgICAgICAgIDEwMzcsXHJcbiAgICAgICAgICAgIDEwMzgsXHJcbiAgICAgICAgICAgIDEwMzksXHJcbiAgICAgICAgICAgIDEwNDAsXHJcbiAgICAgICAgICAgIDEwNDEsXHJcbiAgICAgICAgICAgIDEwNDIsXHJcbiAgICAgICAgICAgIDEwNDMsXHJcbiAgICAgICAgICAgIDEwNDQsXHJcbiAgICAgICAgICAgIDEwNDUsXHJcbiAgICAgICAgICAgIDEwNDYsXHJcbiAgICAgICAgICAgIDEwNDcsXHJcbiAgICAgICAgICAgIDEwNDgsXHJcbiAgICAgICAgICAgIDEwNDksXHJcbiAgICAgICAgICAgIDEwNTAsXHJcbiAgICAgICAgICAgIDEwNTEsXHJcbiAgICAgICAgICAgIDEwNTIsXHJcbiAgICAgICAgICAgIDEwNTMsXHJcbiAgICAgICAgICAgIDEwNTQsXHJcbiAgICAgICAgICAgIDEwNTUsXHJcbiAgICAgICAgICAgIDEwNTYsXHJcbiAgICAgICAgICAgIDEwNTcsXHJcbiAgICAgICAgICAgIDEwNTgsXHJcbiAgICAgICAgICAgIDEwNTksXHJcbiAgICAgICAgICAgIDEwNjAsXHJcbiAgICAgICAgICAgIDEwNjEsXHJcbiAgICAgICAgICAgIDEwNjIsXHJcbiAgICAgICAgICAgIDEwNjMsXHJcbiAgICAgICAgICAgIDEwNjQsXHJcbiAgICAgICAgICAgIDEwNjUsXHJcbiAgICAgICAgICAgIDEwNjYsXHJcbiAgICAgICAgICAgIC8vIDEwNjcsXHJcbiAgICAgICAgICAgIC8vIDEwNjgsXHJcbiAgICAgICAgICAgIC8vIDEwNjksXHJcbiAgICAgICAgICAgIDEwNzAsXHJcbiAgICAgICAgICAgIDEwNzEsXHJcbiAgICAgICAgICAgIDEwNzIsXHJcbiAgICAgICAgICAgIDEwNzMsXHJcbiAgICAgICAgICAgIDEwNzQsXHJcbiAgICAgICAgICAgIDEwNzUsXHJcbiAgICAgICAgICAgIDEwNzYsXHJcbiAgICAgICAgICAgIDEwNzcsXHJcbiAgICAgICAgICAgIDEwNzhcclxuICAgICAgICBdLFxyXG4gICAgICAgICdkaWdpdGFsJzogW1xyXG4gICAgICAgICAgICAxLFxyXG4gICAgICAgICAgICAzLFxyXG4gICAgICAgICAgICA0LFxyXG4gICAgICAgICAgICA1LFxyXG4gICAgICAgICAgICA2LFxyXG4gICAgICAgICAgICA3LFxyXG4gICAgICAgICAgICA4LFxyXG4gICAgICAgICAgICA5XHJcbiAgICAgICAgXSxcclxuICAgICAgICAnY3JlYXRpdmUnOiBbXHJcbiAgICAgICAgICAgIDEsXHJcbiAgICAgICAgICAgIDMsXHJcbiAgICAgICAgICAgIDQsXHJcbiAgICAgICAgICAgIDVcclxuICAgICAgICBdLFxyXG4gICAgICAgICdkZXZkaWdpdGFsJzogW1xyXG4gICAgICAgICAgICAxLFxyXG4gICAgICAgICAgICAzLFxyXG4gICAgICAgICAgICA0LFxyXG4gICAgICAgICAgICA1LFxyXG4gICAgICAgICAgICA2LFxyXG4gICAgICAgICAgICA3LFxyXG4gICAgICAgICAgICA4LFxyXG4gICAgICAgICAgICA5XHJcbiAgICAgICAgXSxcclxuICAgICAgICAnYWknOltdXHJcbiAgICB9W2FwcG5hbWVdO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0RXhjbHVkZWRNb2R1bGVzKGFwcG5hbWUpIHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgJ3Byb2dyYW1taW5nJzogW1xyXG4gICAgICAgICAgICAyXHJcbiAgICAgICAgXVxyXG4gICAgfVthcHBuYW1lXTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGdldEV4Y2x1ZGVkTW9kdWxlSW5zdGFuY2VzKGFwcG5hbWUpIHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgJ2RpZ2l0YWwnOiBbXHJcbiAgICAgICAgICAgIDUsXHJcbiAgICAgICAgICAgIDUwXHJcbiAgICAgICAgXSxcclxuICAgICAgICAnY3JlYXRpdmUnOiBbXHJcbiAgICAgICAgICAgIDEsXHJcbiAgICAgICAgICAgIDE0LFxyXG4gICAgICAgICAgICAyOCxcclxuICAgICAgICAgICAgNDZcclxuICAgICAgICBdLFxyXG4gICAgICAgICdkZXZkaWdpdGFsJzogW1xyXG4gICAgICAgICAgICA1LFxyXG4gICAgICAgICAgICA1MFxyXG4gICAgICAgIF0sXHJcbiAgICB9W2FwcG5hbWVdO1xyXG59XHJcblxyXG4vKipcclxuICogQGRlc2NyaXB0aW9uIFJvdW5kcyB1cCBhIG51bWJlciB1cCB0byBzcGVjaWZpZWQgbnVtYmVyIG9mIGRlY2ltYWwgcGxhY2VzIHVzaW5nIGEgc3BlY2lmaWVkIG51bWJlciBvZiBkZWNpbWFsIHBsYWNlcyBhcyBwcmVjaXNpb24uXHJcbiAqIFRoaXMgYWxsb3dzIGNvcnJlY3Qgcm91bmRpbmcgb2YgcHJvYmxlbWF0aWMgZmxvYXRpbmcgcG9pbnQgbnVtYmVycyBsaWtlIFwiNTUuMDAwMDAwMDAwMDAwMDFcIiBvciBcIjAuNDYwMDAwMDAwMDAwMDAxXCJcclxuICogQHBhcmFtIHtOdW1iZXJ9IG51bWJlciBUaGUgbnVtYmVyIHRvIHJvdW5kIHVwXHJcbiAqIEBwYXJhbSB7TnVtYmVyfSBkZWNpbWFsUGxhY2VzVG9Sb3VuZFRvIFRoZSBudW1iZXIgb2YgZGVjaW1hbCBwbGFjZXMgdG8gcm91bmQgdG9cclxuICogQHBhcmFtIHtOdW1iZXJ9IGRlY2ltYWxQbGFjZXNQcmVjaXNpb24gVGhlIG51bWJlciBvZiBkZWNpbWFsIHBsYWNlcyB0aGF0IHNob3VsZCBiZSBjb25zaWRlcmVkIGZvciB0aGUgcm91bmRpbmcuIFNob3VsZCBiZSBsYXJnZXIgdGhhbiBkZWNpbWFsUGxhY2VzVG9Sb3VuZFRvXHJcbiAqIEByZXR1cm5zIFRoZSByb3VuZGVkIG51bWJlclxyXG4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIHJvdW5kVXBXaXRoUHJlY2lzaW9uKG51bWJlciwgZGVjaW1hbFBsYWNlc1RvUm91bmRUbywgZGVjaW1hbFBsYWNlc1ByZWNpc2lvbikge1xyXG4gICAgaWYgKGRlY2ltYWxQbGFjZXNQcmVjaXNpb24gPD0gZGVjaW1hbFBsYWNlc1RvUm91bmRUbykge1xyXG4gICAgICAgIHRocm93IG5ldyBSYW5nZUVycm9yKCdkZWNpbWFsUGxhY2VzUHJlY2lzaW9uIHNob3VsZCBiZSBsYXJnZXIgdGhhbiBkZWNpbWFsUGxhY2VzVG9Sb3VuZFRvJyk7XHJcbiAgICB9XHJcblxyXG4gICAgbGV0IHByZWNpc2lvblZhbHVlID0gMTAgKiogZGVjaW1hbFBsYWNlc1ByZWNpc2lvbjtcclxuICAgIGxldCByb3VuZGluZ1ZhbHVlID0gMTAgKiogZGVjaW1hbFBsYWNlc1RvUm91bmRUbztcclxuICAgIGxldCByb3VuZGluZ1ZhbHVlQmlnSW50ID0gQmlnSW50KHJvdW5kaW5nVmFsdWUpO1xyXG4gICAgbGV0IHByZWNpc2lvbkRpZmZlcmVuY2VWYWx1ZSA9IEJpZ0ludChwcmVjaXNpb25WYWx1ZSAvIHJvdW5kaW5nVmFsdWUpO1xyXG5cclxuICAgIGxldCBiaWdJbnQgPSBCaWdJbnQoTWF0aC50cnVuYyhudW1iZXIgKiBwcmVjaXNpb25WYWx1ZSkpO1xyXG4gICAgbGV0IHJvdW5kZWRQbGFjZXNOdW1iZXJQYXJ0ID0gYmlnSW50IC8gcHJlY2lzaW9uRGlmZmVyZW5jZVZhbHVlO1xyXG5cclxuICAgIGxldCBwcmVjaXNpb25EaWZmZXJlbmNlTGVmdG92ZXIgPSBiaWdJbnQgJSBwcmVjaXNpb25EaWZmZXJlbmNlVmFsdWU7XHJcbiAgICByb3VuZGVkUGxhY2VzTnVtYmVyUGFydCArPSBwcmVjaXNpb25EaWZmZXJlbmNlTGVmdG92ZXIgPiAwID8gMW4gOiAwbjtcclxuXHJcbiAgICBsZXQgbnVtYmVyUGFydCA9IHJvdW5kZWRQbGFjZXNOdW1iZXJQYXJ0IC8gcm91bmRpbmdWYWx1ZUJpZ0ludDtcclxuICAgIGxldCBkZWNpbWFsUGFydCA9IHJvdW5kZWRQbGFjZXNOdW1iZXJQYXJ0ICUgcm91bmRpbmdWYWx1ZUJpZ0ludDtcclxuXHJcbiAgICBsZXQgcm91bmRlZE51bSA9IE51bWJlcihgJHtudW1iZXJQYXJ0fS4ke2RlY2ltYWxQYXJ0LnRvU3RyaW5nKCkucGFkU3RhcnQoZGVjaW1hbFBsYWNlc1RvUm91bmRUbywgJzAnKX1gKTtcclxuICAgIHJldHVybiByb3VuZGVkTnVtO1xyXG59IiwiIWZ1bmN0aW9uKHUsRCl7XCJvYmplY3RcIj09dHlwZW9mIGV4cG9ydHMmJlwidW5kZWZpbmVkXCIhPXR5cGVvZiBtb2R1bGU/bW9kdWxlLmV4cG9ydHM9RCgpOlwiZnVuY3Rpb25cIj09dHlwZW9mIGRlZmluZSYmZGVmaW5lLmFtZD9kZWZpbmUoRCk6dS5KU09ONT1EKCl9KHRoaXMsZnVuY3Rpb24oKXtcInVzZSBzdHJpY3RcIjtmdW5jdGlvbiB1KHUsRCl7cmV0dXJuIHUoRD17ZXhwb3J0czp7fX0sRC5leHBvcnRzKSxELmV4cG9ydHN9dmFyIEQ9dShmdW5jdGlvbih1KXt2YXIgRD11LmV4cG9ydHM9XCJ1bmRlZmluZWRcIiE9dHlwZW9mIHdpbmRvdyYmd2luZG93Lk1hdGg9PU1hdGg/d2luZG93OlwidW5kZWZpbmVkXCIhPXR5cGVvZiBzZWxmJiZzZWxmLk1hdGg9PU1hdGg/c2VsZjpGdW5jdGlvbihcInJldHVybiB0aGlzXCIpKCk7XCJudW1iZXJcIj09dHlwZW9mIF9fZyYmKF9fZz1EKX0pLGU9dShmdW5jdGlvbih1KXt2YXIgRD11LmV4cG9ydHM9e3ZlcnNpb246XCIyLjYuNVwifTtcIm51bWJlclwiPT10eXBlb2YgX19lJiYoX19lPUQpfSksdD0oZS52ZXJzaW9uLGZ1bmN0aW9uKHUpe3JldHVyblwib2JqZWN0XCI9PXR5cGVvZiB1P251bGwhPT11OlwiZnVuY3Rpb25cIj09dHlwZW9mIHV9KSxyPWZ1bmN0aW9uKHUpe2lmKCF0KHUpKXRocm93IFR5cGVFcnJvcih1K1wiIGlzIG5vdCBhbiBvYmplY3QhXCIpO3JldHVybiB1fSxGPWZ1bmN0aW9uKHUpe3RyeXtyZXR1cm4hIXUoKX1jYXRjaCh1KXtyZXR1cm4hMH19LG49IUYoZnVuY3Rpb24oKXtyZXR1cm4gNyE9T2JqZWN0LmRlZmluZVByb3BlcnR5KHt9LFwiYVwiLHtnZXQ6ZnVuY3Rpb24oKXtyZXR1cm4gN319KS5hfSksQz1ELmRvY3VtZW50LEE9dChDKSYmdChDLmNyZWF0ZUVsZW1lbnQpLGk9IW4mJiFGKGZ1bmN0aW9uKCl7cmV0dXJuIDchPU9iamVjdC5kZWZpbmVQcm9wZXJ0eSgodT1cImRpdlwiLEE/Qy5jcmVhdGVFbGVtZW50KHUpOnt9KSxcImFcIix7Z2V0OmZ1bmN0aW9uKCl7cmV0dXJuIDd9fSkuYTt2YXIgdX0pLEU9T2JqZWN0LmRlZmluZVByb3BlcnR5LG89e2Y6bj9PYmplY3QuZGVmaW5lUHJvcGVydHk6ZnVuY3Rpb24odSxELGUpe2lmKHIodSksRD1mdW5jdGlvbih1LEQpe2lmKCF0KHUpKXJldHVybiB1O3ZhciBlLHI7aWYoRCYmXCJmdW5jdGlvblwiPT10eXBlb2YoZT11LnRvU3RyaW5nKSYmIXQocj1lLmNhbGwodSkpKXJldHVybiByO2lmKFwiZnVuY3Rpb25cIj09dHlwZW9mKGU9dS52YWx1ZU9mKSYmIXQocj1lLmNhbGwodSkpKXJldHVybiByO2lmKCFEJiZcImZ1bmN0aW9uXCI9PXR5cGVvZihlPXUudG9TdHJpbmcpJiYhdChyPWUuY2FsbCh1KSkpcmV0dXJuIHI7dGhyb3cgVHlwZUVycm9yKFwiQ2FuJ3QgY29udmVydCBvYmplY3QgdG8gcHJpbWl0aXZlIHZhbHVlXCIpfShELCEwKSxyKGUpLGkpdHJ5e3JldHVybiBFKHUsRCxlKX1jYXRjaCh1KXt9aWYoXCJnZXRcImluIGV8fFwic2V0XCJpbiBlKXRocm93IFR5cGVFcnJvcihcIkFjY2Vzc29ycyBub3Qgc3VwcG9ydGVkIVwiKTtyZXR1cm5cInZhbHVlXCJpbiBlJiYodVtEXT1lLnZhbHVlKSx1fX0sYT1uP2Z1bmN0aW9uKHUsRCxlKXtyZXR1cm4gby5mKHUsRCxmdW5jdGlvbih1LEQpe3JldHVybntlbnVtZXJhYmxlOiEoMSZ1KSxjb25maWd1cmFibGU6ISgyJnUpLHdyaXRhYmxlOiEoNCZ1KSx2YWx1ZTpEfX0oMSxlKSl9OmZ1bmN0aW9uKHUsRCxlKXtyZXR1cm4gdVtEXT1lLHV9LGM9e30uaGFzT3duUHJvcGVydHksQj1mdW5jdGlvbih1LEQpe3JldHVybiBjLmNhbGwodSxEKX0scz0wLGY9TWF0aC5yYW5kb20oKSxsPXUoZnVuY3Rpb24odSl7dmFyIHQ9RFtcIl9fY29yZS1qc19zaGFyZWRfX1wiXXx8KERbXCJfX2NvcmUtanNfc2hhcmVkX19cIl09e30pOyh1LmV4cG9ydHM9ZnVuY3Rpb24odSxEKXtyZXR1cm4gdFt1XXx8KHRbdV09dm9pZCAwIT09RD9EOnt9KX0pKFwidmVyc2lvbnNcIixbXSkucHVzaCh7dmVyc2lvbjplLnZlcnNpb24sbW9kZTpcImdsb2JhbFwiLGNvcHlyaWdodDpcIsKpIDIwMTkgRGVuaXMgUHVzaGthcmV2ICh6bG9pcm9jay5ydSlcIn0pfSkoXCJuYXRpdmUtZnVuY3Rpb24tdG8tc3RyaW5nXCIsRnVuY3Rpb24udG9TdHJpbmcpLGQ9dShmdW5jdGlvbih1KXt2YXIgdCxyPVwiU3ltYm9sKFwiLmNvbmNhdCh2b2lkIDA9PT0odD1cInNyY1wiKT9cIlwiOnQsXCIpX1wiLCgrK3MrZikudG9TdHJpbmcoMzYpKSxGPShcIlwiK2wpLnNwbGl0KFwidG9TdHJpbmdcIik7ZS5pbnNwZWN0U291cmNlPWZ1bmN0aW9uKHUpe3JldHVybiBsLmNhbGwodSl9LCh1LmV4cG9ydHM9ZnVuY3Rpb24odSxlLHQsbil7dmFyIEM9XCJmdW5jdGlvblwiPT10eXBlb2YgdDtDJiYoQih0LFwibmFtZVwiKXx8YSh0LFwibmFtZVwiLGUpKSx1W2VdIT09dCYmKEMmJihCKHQscil8fGEodCxyLHVbZV0/XCJcIit1W2VdOkYuam9pbihTdHJpbmcoZSkpKSksdT09PUQ/dVtlXT10Om4/dVtlXT91W2VdPXQ6YSh1LGUsdCk6KGRlbGV0ZSB1W2VdLGEodSxlLHQpKSl9KShGdW5jdGlvbi5wcm90b3R5cGUsXCJ0b1N0cmluZ1wiLGZ1bmN0aW9uKCl7cmV0dXJuXCJmdW5jdGlvblwiPT10eXBlb2YgdGhpcyYmdGhpc1tyXXx8bC5jYWxsKHRoaXMpfSl9KSx2PWZ1bmN0aW9uKHUsRCxlKXtpZihmdW5jdGlvbih1KXtpZihcImZ1bmN0aW9uXCIhPXR5cGVvZiB1KXRocm93IFR5cGVFcnJvcih1K1wiIGlzIG5vdCBhIGZ1bmN0aW9uIVwiKX0odSksdm9pZCAwPT09RClyZXR1cm4gdTtzd2l0Y2goZSl7Y2FzZSAxOnJldHVybiBmdW5jdGlvbihlKXtyZXR1cm4gdS5jYWxsKEQsZSl9O2Nhc2UgMjpyZXR1cm4gZnVuY3Rpb24oZSx0KXtyZXR1cm4gdS5jYWxsKEQsZSx0KX07Y2FzZSAzOnJldHVybiBmdW5jdGlvbihlLHQscil7cmV0dXJuIHUuY2FsbChELGUsdCxyKX19cmV0dXJuIGZ1bmN0aW9uKCl7cmV0dXJuIHUuYXBwbHkoRCxhcmd1bWVudHMpfX0scD1mdW5jdGlvbih1LHQscil7dmFyIEYsbixDLEEsaT11JnAuRixFPXUmcC5HLG89dSZwLlMsYz11JnAuUCxCPXUmcC5CLHM9RT9EOm8/RFt0XXx8KERbdF09e30pOihEW3RdfHx7fSkucHJvdG90eXBlLGY9RT9lOmVbdF18fChlW3RdPXt9KSxsPWYucHJvdG90eXBlfHwoZi5wcm90b3R5cGU9e30pO2ZvcihGIGluIEUmJihyPXQpLHIpQz0oKG49IWkmJnMmJnZvaWQgMCE9PXNbRl0pP3M6cilbRl0sQT1CJiZuP3YoQyxEKTpjJiZcImZ1bmN0aW9uXCI9PXR5cGVvZiBDP3YoRnVuY3Rpb24uY2FsbCxDKTpDLHMmJmQocyxGLEMsdSZwLlUpLGZbRl0hPUMmJmEoZixGLEEpLGMmJmxbRl0hPUMmJihsW0ZdPUMpfTtELmNvcmU9ZSxwLkY9MSxwLkc9MixwLlM9NCxwLlA9OCxwLkI9MTYscC5XPTMyLHAuVT02NCxwLlI9MTI4O3ZhciBoLG09cCxnPU1hdGguY2VpbCx5PU1hdGguZmxvb3Isdz1mdW5jdGlvbih1KXtyZXR1cm4gaXNOYU4odT0rdSk/MDoodT4wP3k6ZykodSl9LFM9KGg9ITEsZnVuY3Rpb24odSxEKXt2YXIgZSx0LHI9U3RyaW5nKGZ1bmN0aW9uKHUpe2lmKG51bGw9PXUpdGhyb3cgVHlwZUVycm9yKFwiQ2FuJ3QgY2FsbCBtZXRob2Qgb24gIFwiK3UpO3JldHVybiB1fSh1KSksRj13KEQpLG49ci5sZW5ndGg7cmV0dXJuIEY8MHx8Rj49bj9oP1wiXCI6dm9pZCAwOihlPXIuY2hhckNvZGVBdChGKSk8NTUyOTZ8fGU+NTYzMTl8fEYrMT09PW58fCh0PXIuY2hhckNvZGVBdChGKzEpKTw1NjMyMHx8dD41NzM0Mz9oP3IuY2hhckF0KEYpOmU6aD9yLnNsaWNlKEYsRisyKTp0LTU2MzIwKyhlLTU1Mjk2PDwxMCkrNjU1MzZ9KTttKG0uUCxcIlN0cmluZ1wiLHtjb2RlUG9pbnRBdDpmdW5jdGlvbih1KXtyZXR1cm4gUyh0aGlzLHUpfX0pO2UuU3RyaW5nLmNvZGVQb2ludEF0O3ZhciBiPU1hdGgubWF4LHg9TWF0aC5taW4sTj1TdHJpbmcuZnJvbUNoYXJDb2RlLFA9U3RyaW5nLmZyb21Db2RlUG9pbnQ7bShtLlMrbS5GKighIVAmJjEhPVAubGVuZ3RoKSxcIlN0cmluZ1wiLHtmcm9tQ29kZVBvaW50OmZ1bmN0aW9uKHUpe2Zvcih2YXIgRCxlLHQscj1hcmd1bWVudHMsRj1bXSxuPWFyZ3VtZW50cy5sZW5ndGgsQz0wO24+Qzspe2lmKEQ9K3JbQysrXSx0PTExMTQxMTEsKChlPXcoZT1EKSk8MD9iKGUrdCwwKTp4KGUsdCkpIT09RCl0aHJvdyBSYW5nZUVycm9yKEQrXCIgaXMgbm90IGEgdmFsaWQgY29kZSBwb2ludFwiKTtGLnB1c2goRDw2NTUzNj9OKEQpOk4oNTUyOTYrKChELT02NTUzNik+PjEwKSxEJTEwMjQrNTYzMjApKX1yZXR1cm4gRi5qb2luKFwiXCIpfX0pO2UuU3RyaW5nLmZyb21Db2RlUG9pbnQ7dmFyIF8sSSxPLGosVixKLE0sayxMLFQseixILCQsUixHPXtTcGFjZV9TZXBhcmF0b3I6L1tcXHUxNjgwXFx1MjAwMC1cXHUyMDBBXFx1MjAyRlxcdTIwNUZcXHUzMDAwXS8sSURfU3RhcnQ6L1tcXHhBQVxceEI1XFx4QkFcXHhDMC1cXHhENlxceEQ4LVxceEY2XFx4RjgtXFx1MDJDMVxcdTAyQzYtXFx1MDJEMVxcdTAyRTAtXFx1MDJFNFxcdTAyRUNcXHUwMkVFXFx1MDM3MC1cXHUwMzc0XFx1MDM3NlxcdTAzNzdcXHUwMzdBLVxcdTAzN0RcXHUwMzdGXFx1MDM4NlxcdTAzODgtXFx1MDM4QVxcdTAzOENcXHUwMzhFLVxcdTAzQTFcXHUwM0EzLVxcdTAzRjVcXHUwM0Y3LVxcdTA0ODFcXHUwNDhBLVxcdTA1MkZcXHUwNTMxLVxcdTA1NTZcXHUwNTU5XFx1MDU2MS1cXHUwNTg3XFx1MDVEMC1cXHUwNUVBXFx1MDVGMC1cXHUwNUYyXFx1MDYyMC1cXHUwNjRBXFx1MDY2RVxcdTA2NkZcXHUwNjcxLVxcdTA2RDNcXHUwNkQ1XFx1MDZFNVxcdTA2RTZcXHUwNkVFXFx1MDZFRlxcdTA2RkEtXFx1MDZGQ1xcdTA2RkZcXHUwNzEwXFx1MDcxMi1cXHUwNzJGXFx1MDc0RC1cXHUwN0E1XFx1MDdCMVxcdTA3Q0EtXFx1MDdFQVxcdTA3RjRcXHUwN0Y1XFx1MDdGQVxcdTA4MDAtXFx1MDgxNVxcdTA4MUFcXHUwODI0XFx1MDgyOFxcdTA4NDAtXFx1MDg1OFxcdTA4NjAtXFx1MDg2QVxcdTA4QTAtXFx1MDhCNFxcdTA4QjYtXFx1MDhCRFxcdTA5MDQtXFx1MDkzOVxcdTA5M0RcXHUwOTUwXFx1MDk1OC1cXHUwOTYxXFx1MDk3MS1cXHUwOTgwXFx1MDk4NS1cXHUwOThDXFx1MDk4RlxcdTA5OTBcXHUwOTkzLVxcdTA5QThcXHUwOUFBLVxcdTA5QjBcXHUwOUIyXFx1MDlCNi1cXHUwOUI5XFx1MDlCRFxcdTA5Q0VcXHUwOURDXFx1MDlERFxcdTA5REYtXFx1MDlFMVxcdTA5RjBcXHUwOUYxXFx1MDlGQ1xcdTBBMDUtXFx1MEEwQVxcdTBBMEZcXHUwQTEwXFx1MEExMy1cXHUwQTI4XFx1MEEyQS1cXHUwQTMwXFx1MEEzMlxcdTBBMzNcXHUwQTM1XFx1MEEzNlxcdTBBMzhcXHUwQTM5XFx1MEE1OS1cXHUwQTVDXFx1MEE1RVxcdTBBNzItXFx1MEE3NFxcdTBBODUtXFx1MEE4RFxcdTBBOEYtXFx1MEE5MVxcdTBBOTMtXFx1MEFBOFxcdTBBQUEtXFx1MEFCMFxcdTBBQjJcXHUwQUIzXFx1MEFCNS1cXHUwQUI5XFx1MEFCRFxcdTBBRDBcXHUwQUUwXFx1MEFFMVxcdTBBRjlcXHUwQjA1LVxcdTBCMENcXHUwQjBGXFx1MEIxMFxcdTBCMTMtXFx1MEIyOFxcdTBCMkEtXFx1MEIzMFxcdTBCMzJcXHUwQjMzXFx1MEIzNS1cXHUwQjM5XFx1MEIzRFxcdTBCNUNcXHUwQjVEXFx1MEI1Ri1cXHUwQjYxXFx1MEI3MVxcdTBCODNcXHUwQjg1LVxcdTBCOEFcXHUwQjhFLVxcdTBCOTBcXHUwQjkyLVxcdTBCOTVcXHUwQjk5XFx1MEI5QVxcdTBCOUNcXHUwQjlFXFx1MEI5RlxcdTBCQTNcXHUwQkE0XFx1MEJBOC1cXHUwQkFBXFx1MEJBRS1cXHUwQkI5XFx1MEJEMFxcdTBDMDUtXFx1MEMwQ1xcdTBDMEUtXFx1MEMxMFxcdTBDMTItXFx1MEMyOFxcdTBDMkEtXFx1MEMzOVxcdTBDM0RcXHUwQzU4LVxcdTBDNUFcXHUwQzYwXFx1MEM2MVxcdTBDODBcXHUwQzg1LVxcdTBDOENcXHUwQzhFLVxcdTBDOTBcXHUwQzkyLVxcdTBDQThcXHUwQ0FBLVxcdTBDQjNcXHUwQ0I1LVxcdTBDQjlcXHUwQ0JEXFx1MENERVxcdTBDRTBcXHUwQ0UxXFx1MENGMVxcdTBDRjJcXHUwRDA1LVxcdTBEMENcXHUwRDBFLVxcdTBEMTBcXHUwRDEyLVxcdTBEM0FcXHUwRDNEXFx1MEQ0RVxcdTBENTQtXFx1MEQ1NlxcdTBENUYtXFx1MEQ2MVxcdTBEN0EtXFx1MEQ3RlxcdTBEODUtXFx1MEQ5NlxcdTBEOUEtXFx1MERCMVxcdTBEQjMtXFx1MERCQlxcdTBEQkRcXHUwREMwLVxcdTBEQzZcXHUwRTAxLVxcdTBFMzBcXHUwRTMyXFx1MEUzM1xcdTBFNDAtXFx1MEU0NlxcdTBFODFcXHUwRTgyXFx1MEU4NFxcdTBFODdcXHUwRTg4XFx1MEU4QVxcdTBFOERcXHUwRTk0LVxcdTBFOTdcXHUwRTk5LVxcdTBFOUZcXHUwRUExLVxcdTBFQTNcXHUwRUE1XFx1MEVBN1xcdTBFQUFcXHUwRUFCXFx1MEVBRC1cXHUwRUIwXFx1MEVCMlxcdTBFQjNcXHUwRUJEXFx1MEVDMC1cXHUwRUM0XFx1MEVDNlxcdTBFREMtXFx1MEVERlxcdTBGMDBcXHUwRjQwLVxcdTBGNDdcXHUwRjQ5LVxcdTBGNkNcXHUwRjg4LVxcdTBGOENcXHUxMDAwLVxcdTEwMkFcXHUxMDNGXFx1MTA1MC1cXHUxMDU1XFx1MTA1QS1cXHUxMDVEXFx1MTA2MVxcdTEwNjVcXHUxMDY2XFx1MTA2RS1cXHUxMDcwXFx1MTA3NS1cXHUxMDgxXFx1MTA4RVxcdTEwQTAtXFx1MTBDNVxcdTEwQzdcXHUxMENEXFx1MTBEMC1cXHUxMEZBXFx1MTBGQy1cXHUxMjQ4XFx1MTI0QS1cXHUxMjREXFx1MTI1MC1cXHUxMjU2XFx1MTI1OFxcdTEyNUEtXFx1MTI1RFxcdTEyNjAtXFx1MTI4OFxcdTEyOEEtXFx1MTI4RFxcdTEyOTAtXFx1MTJCMFxcdTEyQjItXFx1MTJCNVxcdTEyQjgtXFx1MTJCRVxcdTEyQzBcXHUxMkMyLVxcdTEyQzVcXHUxMkM4LVxcdTEyRDZcXHUxMkQ4LVxcdTEzMTBcXHUxMzEyLVxcdTEzMTVcXHUxMzE4LVxcdTEzNUFcXHUxMzgwLVxcdTEzOEZcXHUxM0EwLVxcdTEzRjVcXHUxM0Y4LVxcdTEzRkRcXHUxNDAxLVxcdTE2NkNcXHUxNjZGLVxcdTE2N0ZcXHUxNjgxLVxcdTE2OUFcXHUxNkEwLVxcdTE2RUFcXHUxNkVFLVxcdTE2RjhcXHUxNzAwLVxcdTE3MENcXHUxNzBFLVxcdTE3MTFcXHUxNzIwLVxcdTE3MzFcXHUxNzQwLVxcdTE3NTFcXHUxNzYwLVxcdTE3NkNcXHUxNzZFLVxcdTE3NzBcXHUxNzgwLVxcdTE3QjNcXHUxN0Q3XFx1MTdEQ1xcdTE4MjAtXFx1MTg3N1xcdTE4ODAtXFx1MTg4NFxcdTE4ODctXFx1MThBOFxcdTE4QUFcXHUxOEIwLVxcdTE4RjVcXHUxOTAwLVxcdTE5MUVcXHUxOTUwLVxcdTE5NkRcXHUxOTcwLVxcdTE5NzRcXHUxOTgwLVxcdTE5QUJcXHUxOUIwLVxcdTE5QzlcXHUxQTAwLVxcdTFBMTZcXHUxQTIwLVxcdTFBNTRcXHUxQUE3XFx1MUIwNS1cXHUxQjMzXFx1MUI0NS1cXHUxQjRCXFx1MUI4My1cXHUxQkEwXFx1MUJBRVxcdTFCQUZcXHUxQkJBLVxcdTFCRTVcXHUxQzAwLVxcdTFDMjNcXHUxQzRELVxcdTFDNEZcXHUxQzVBLVxcdTFDN0RcXHUxQzgwLVxcdTFDODhcXHUxQ0U5LVxcdTFDRUNcXHUxQ0VFLVxcdTFDRjFcXHUxQ0Y1XFx1MUNGNlxcdTFEMDAtXFx1MURCRlxcdTFFMDAtXFx1MUYxNVxcdTFGMTgtXFx1MUYxRFxcdTFGMjAtXFx1MUY0NVxcdTFGNDgtXFx1MUY0RFxcdTFGNTAtXFx1MUY1N1xcdTFGNTlcXHUxRjVCXFx1MUY1RFxcdTFGNUYtXFx1MUY3RFxcdTFGODAtXFx1MUZCNFxcdTFGQjYtXFx1MUZCQ1xcdTFGQkVcXHUxRkMyLVxcdTFGQzRcXHUxRkM2LVxcdTFGQ0NcXHUxRkQwLVxcdTFGRDNcXHUxRkQ2LVxcdTFGREJcXHUxRkUwLVxcdTFGRUNcXHUxRkYyLVxcdTFGRjRcXHUxRkY2LVxcdTFGRkNcXHUyMDcxXFx1MjA3RlxcdTIwOTAtXFx1MjA5Q1xcdTIxMDJcXHUyMTA3XFx1MjEwQS1cXHUyMTEzXFx1MjExNVxcdTIxMTktXFx1MjExRFxcdTIxMjRcXHUyMTI2XFx1MjEyOFxcdTIxMkEtXFx1MjEyRFxcdTIxMkYtXFx1MjEzOVxcdTIxM0MtXFx1MjEzRlxcdTIxNDUtXFx1MjE0OVxcdTIxNEVcXHUyMTYwLVxcdTIxODhcXHUyQzAwLVxcdTJDMkVcXHUyQzMwLVxcdTJDNUVcXHUyQzYwLVxcdTJDRTRcXHUyQ0VCLVxcdTJDRUVcXHUyQ0YyXFx1MkNGM1xcdTJEMDAtXFx1MkQyNVxcdTJEMjdcXHUyRDJEXFx1MkQzMC1cXHUyRDY3XFx1MkQ2RlxcdTJEODAtXFx1MkQ5NlxcdTJEQTAtXFx1MkRBNlxcdTJEQTgtXFx1MkRBRVxcdTJEQjAtXFx1MkRCNlxcdTJEQjgtXFx1MkRCRVxcdTJEQzAtXFx1MkRDNlxcdTJEQzgtXFx1MkRDRVxcdTJERDAtXFx1MkRENlxcdTJERDgtXFx1MkRERVxcdTJFMkZcXHUzMDA1LVxcdTMwMDdcXHUzMDIxLVxcdTMwMjlcXHUzMDMxLVxcdTMwMzVcXHUzMDM4LVxcdTMwM0NcXHUzMDQxLVxcdTMwOTZcXHUzMDlELVxcdTMwOUZcXHUzMEExLVxcdTMwRkFcXHUzMEZDLVxcdTMwRkZcXHUzMTA1LVxcdTMxMkVcXHUzMTMxLVxcdTMxOEVcXHUzMUEwLVxcdTMxQkFcXHUzMUYwLVxcdTMxRkZcXHUzNDAwLVxcdTREQjVcXHU0RTAwLVxcdTlGRUFcXHVBMDAwLVxcdUE0OENcXHVBNEQwLVxcdUE0RkRcXHVBNTAwLVxcdUE2MENcXHVBNjEwLVxcdUE2MUZcXHVBNjJBXFx1QTYyQlxcdUE2NDAtXFx1QTY2RVxcdUE2N0YtXFx1QTY5RFxcdUE2QTAtXFx1QTZFRlxcdUE3MTctXFx1QTcxRlxcdUE3MjItXFx1QTc4OFxcdUE3OEItXFx1QTdBRVxcdUE3QjAtXFx1QTdCN1xcdUE3RjctXFx1QTgwMVxcdUE4MDMtXFx1QTgwNVxcdUE4MDctXFx1QTgwQVxcdUE4MEMtXFx1QTgyMlxcdUE4NDAtXFx1QTg3M1xcdUE4ODItXFx1QThCM1xcdUE4RjItXFx1QThGN1xcdUE4RkJcXHVBOEZEXFx1QTkwQS1cXHVBOTI1XFx1QTkzMC1cXHVBOTQ2XFx1QTk2MC1cXHVBOTdDXFx1QTk4NC1cXHVBOUIyXFx1QTlDRlxcdUE5RTAtXFx1QTlFNFxcdUE5RTYtXFx1QTlFRlxcdUE5RkEtXFx1QTlGRVxcdUFBMDAtXFx1QUEyOFxcdUFBNDAtXFx1QUE0MlxcdUFBNDQtXFx1QUE0QlxcdUFBNjAtXFx1QUE3NlxcdUFBN0FcXHVBQTdFLVxcdUFBQUZcXHVBQUIxXFx1QUFCNVxcdUFBQjZcXHVBQUI5LVxcdUFBQkRcXHVBQUMwXFx1QUFDMlxcdUFBREItXFx1QUFERFxcdUFBRTAtXFx1QUFFQVxcdUFBRjItXFx1QUFGNFxcdUFCMDEtXFx1QUIwNlxcdUFCMDktXFx1QUIwRVxcdUFCMTEtXFx1QUIxNlxcdUFCMjAtXFx1QUIyNlxcdUFCMjgtXFx1QUIyRVxcdUFCMzAtXFx1QUI1QVxcdUFCNUMtXFx1QUI2NVxcdUFCNzAtXFx1QUJFMlxcdUFDMDAtXFx1RDdBM1xcdUQ3QjAtXFx1RDdDNlxcdUQ3Q0ItXFx1RDdGQlxcdUY5MDAtXFx1RkE2RFxcdUZBNzAtXFx1RkFEOVxcdUZCMDAtXFx1RkIwNlxcdUZCMTMtXFx1RkIxN1xcdUZCMURcXHVGQjFGLVxcdUZCMjhcXHVGQjJBLVxcdUZCMzZcXHVGQjM4LVxcdUZCM0NcXHVGQjNFXFx1RkI0MFxcdUZCNDFcXHVGQjQzXFx1RkI0NFxcdUZCNDYtXFx1RkJCMVxcdUZCRDMtXFx1RkQzRFxcdUZENTAtXFx1RkQ4RlxcdUZEOTItXFx1RkRDN1xcdUZERjAtXFx1RkRGQlxcdUZFNzAtXFx1RkU3NFxcdUZFNzYtXFx1RkVGQ1xcdUZGMjEtXFx1RkYzQVxcdUZGNDEtXFx1RkY1QVxcdUZGNjYtXFx1RkZCRVxcdUZGQzItXFx1RkZDN1xcdUZGQ0EtXFx1RkZDRlxcdUZGRDItXFx1RkZEN1xcdUZGREEtXFx1RkZEQ118XFx1RDgwMFtcXHVEQzAwLVxcdURDMEJcXHVEQzBELVxcdURDMjZcXHVEQzI4LVxcdURDM0FcXHVEQzNDXFx1REMzRFxcdURDM0YtXFx1REM0RFxcdURDNTAtXFx1REM1RFxcdURDODAtXFx1RENGQVxcdURENDAtXFx1REQ3NFxcdURFODAtXFx1REU5Q1xcdURFQTAtXFx1REVEMFxcdURGMDAtXFx1REYxRlxcdURGMkQtXFx1REY0QVxcdURGNTAtXFx1REY3NVxcdURGODAtXFx1REY5RFxcdURGQTAtXFx1REZDM1xcdURGQzgtXFx1REZDRlxcdURGRDEtXFx1REZENV18XFx1RDgwMVtcXHVEQzAwLVxcdURDOURcXHVEQ0IwLVxcdURDRDNcXHVEQ0Q4LVxcdURDRkJcXHVERDAwLVxcdUREMjdcXHVERDMwLVxcdURENjNcXHVERTAwLVxcdURGMzZcXHVERjQwLVxcdURGNTVcXHVERjYwLVxcdURGNjddfFxcdUQ4MDJbXFx1REMwMC1cXHVEQzA1XFx1REMwOFxcdURDMEEtXFx1REMzNVxcdURDMzdcXHVEQzM4XFx1REMzQ1xcdURDM0YtXFx1REM1NVxcdURDNjAtXFx1REM3NlxcdURDODAtXFx1REM5RVxcdURDRTAtXFx1RENGMlxcdURDRjRcXHVEQ0Y1XFx1REQwMC1cXHVERDE1XFx1REQyMC1cXHVERDM5XFx1REQ4MC1cXHVEREI3XFx1RERCRVxcdUREQkZcXHVERTAwXFx1REUxMC1cXHVERTEzXFx1REUxNS1cXHVERTE3XFx1REUxOS1cXHVERTMzXFx1REU2MC1cXHVERTdDXFx1REU4MC1cXHVERTlDXFx1REVDMC1cXHVERUM3XFx1REVDOS1cXHVERUU0XFx1REYwMC1cXHVERjM1XFx1REY0MC1cXHVERjU1XFx1REY2MC1cXHVERjcyXFx1REY4MC1cXHVERjkxXXxcXHVEODAzW1xcdURDMDAtXFx1REM0OFxcdURDODAtXFx1RENCMlxcdURDQzAtXFx1RENGMl18XFx1RDgwNFtcXHVEQzAzLVxcdURDMzdcXHVEQzgzLVxcdURDQUZcXHVEQ0QwLVxcdURDRThcXHVERDAzLVxcdUREMjZcXHVERDUwLVxcdURENzJcXHVERDc2XFx1REQ4My1cXHVEREIyXFx1RERDMS1cXHVEREM0XFx1REREQVxcdURERENcXHVERTAwLVxcdURFMTFcXHVERTEzLVxcdURFMkJcXHVERTgwLVxcdURFODZcXHVERTg4XFx1REU4QS1cXHVERThEXFx1REU4Ri1cXHVERTlEXFx1REU5Ri1cXHVERUE4XFx1REVCMC1cXHVERURFXFx1REYwNS1cXHVERjBDXFx1REYwRlxcdURGMTBcXHVERjEzLVxcdURGMjhcXHVERjJBLVxcdURGMzBcXHVERjMyXFx1REYzM1xcdURGMzUtXFx1REYzOVxcdURGM0RcXHVERjUwXFx1REY1RC1cXHVERjYxXXxcXHVEODA1W1xcdURDMDAtXFx1REMzNFxcdURDNDctXFx1REM0QVxcdURDODAtXFx1RENBRlxcdURDQzRcXHVEQ0M1XFx1RENDN1xcdUREODAtXFx1RERBRVxcdURERDgtXFx1REREQlxcdURFMDAtXFx1REUyRlxcdURFNDRcXHVERTgwLVxcdURFQUFcXHVERjAwLVxcdURGMTldfFxcdUQ4MDZbXFx1RENBMC1cXHVEQ0RGXFx1RENGRlxcdURFMDBcXHVERTBCLVxcdURFMzJcXHVERTNBXFx1REU1MFxcdURFNUMtXFx1REU4M1xcdURFODYtXFx1REU4OVxcdURFQzAtXFx1REVGOF18XFx1RDgwN1tcXHVEQzAwLVxcdURDMDhcXHVEQzBBLVxcdURDMkVcXHVEQzQwXFx1REM3Mi1cXHVEQzhGXFx1REQwMC1cXHVERDA2XFx1REQwOFxcdUREMDlcXHVERDBCLVxcdUREMzBcXHVERDQ2XXxcXHVEODA4W1xcdURDMDAtXFx1REY5OV18XFx1RDgwOVtcXHVEQzAwLVxcdURDNkVcXHVEQzgwLVxcdURENDNdfFtcXHVEODBDXFx1RDgxQy1cXHVEODIwXFx1RDg0MC1cXHVEODY4XFx1RDg2QS1cXHVEODZDXFx1RDg2Ri1cXHVEODcyXFx1RDg3NC1cXHVEODc5XVtcXHVEQzAwLVxcdURGRkZdfFxcdUQ4MERbXFx1REMwMC1cXHVEQzJFXXxcXHVEODExW1xcdURDMDAtXFx1REU0Nl18XFx1RDgxQVtcXHVEQzAwLVxcdURFMzhcXHVERTQwLVxcdURFNUVcXHVERUQwLVxcdURFRURcXHVERjAwLVxcdURGMkZcXHVERjQwLVxcdURGNDNcXHVERjYzLVxcdURGNzdcXHVERjdELVxcdURGOEZdfFxcdUQ4MUJbXFx1REYwMC1cXHVERjQ0XFx1REY1MFxcdURGOTMtXFx1REY5RlxcdURGRTBcXHVERkUxXXxcXHVEODIxW1xcdURDMDAtXFx1REZFQ118XFx1RDgyMltcXHVEQzAwLVxcdURFRjJdfFxcdUQ4MkNbXFx1REMwMC1cXHVERDFFXFx1REQ3MC1cXHVERUZCXXxcXHVEODJGW1xcdURDMDAtXFx1REM2QVxcdURDNzAtXFx1REM3Q1xcdURDODAtXFx1REM4OFxcdURDOTAtXFx1REM5OV18XFx1RDgzNVtcXHVEQzAwLVxcdURDNTRcXHVEQzU2LVxcdURDOUNcXHVEQzlFXFx1REM5RlxcdURDQTJcXHVEQ0E1XFx1RENBNlxcdURDQTktXFx1RENBQ1xcdURDQUUtXFx1RENCOVxcdURDQkJcXHVEQ0JELVxcdURDQzNcXHVEQ0M1LVxcdUREMDVcXHVERDA3LVxcdUREMEFcXHVERDBELVxcdUREMTRcXHVERDE2LVxcdUREMUNcXHVERDFFLVxcdUREMzlcXHVERDNCLVxcdUREM0VcXHVERDQwLVxcdURENDRcXHVERDQ2XFx1REQ0QS1cXHVERDUwXFx1REQ1Mi1cXHVERUE1XFx1REVBOC1cXHVERUMwXFx1REVDMi1cXHVERURBXFx1REVEQy1cXHVERUZBXFx1REVGQy1cXHVERjE0XFx1REYxNi1cXHVERjM0XFx1REYzNi1cXHVERjRFXFx1REY1MC1cXHVERjZFXFx1REY3MC1cXHVERjg4XFx1REY4QS1cXHVERkE4XFx1REZBQS1cXHVERkMyXFx1REZDNC1cXHVERkNCXXxcXHVEODNBW1xcdURDMDAtXFx1RENDNFxcdUREMDAtXFx1REQ0M118XFx1RDgzQltcXHVERTAwLVxcdURFMDNcXHVERTA1LVxcdURFMUZcXHVERTIxXFx1REUyMlxcdURFMjRcXHVERTI3XFx1REUyOS1cXHVERTMyXFx1REUzNC1cXHVERTM3XFx1REUzOVxcdURFM0JcXHVERTQyXFx1REU0N1xcdURFNDlcXHVERTRCXFx1REU0RC1cXHVERTRGXFx1REU1MVxcdURFNTJcXHVERTU0XFx1REU1N1xcdURFNTlcXHVERTVCXFx1REU1RFxcdURFNUZcXHVERTYxXFx1REU2MlxcdURFNjRcXHVERTY3LVxcdURFNkFcXHVERTZDLVxcdURFNzJcXHVERTc0LVxcdURFNzdcXHVERTc5LVxcdURFN0NcXHVERTdFXFx1REU4MC1cXHVERTg5XFx1REU4Qi1cXHVERTlCXFx1REVBMS1cXHVERUEzXFx1REVBNS1cXHVERUE5XFx1REVBQi1cXHVERUJCXXxcXHVEODY5W1xcdURDMDAtXFx1REVENlxcdURGMDAtXFx1REZGRl18XFx1RDg2RFtcXHVEQzAwLVxcdURGMzRcXHVERjQwLVxcdURGRkZdfFxcdUQ4NkVbXFx1REMwMC1cXHVEQzFEXFx1REMyMC1cXHVERkZGXXxcXHVEODczW1xcdURDMDAtXFx1REVBMVxcdURFQjAtXFx1REZGRl18XFx1RDg3QVtcXHVEQzAwLVxcdURGRTBdfFxcdUQ4N0VbXFx1REMwMC1cXHVERTFEXS8sSURfQ29udGludWU6L1tcXHhBQVxceEI1XFx4QkFcXHhDMC1cXHhENlxceEQ4LVxceEY2XFx4RjgtXFx1MDJDMVxcdTAyQzYtXFx1MDJEMVxcdTAyRTAtXFx1MDJFNFxcdTAyRUNcXHUwMkVFXFx1MDMwMC1cXHUwMzc0XFx1MDM3NlxcdTAzNzdcXHUwMzdBLVxcdTAzN0RcXHUwMzdGXFx1MDM4NlxcdTAzODgtXFx1MDM4QVxcdTAzOENcXHUwMzhFLVxcdTAzQTFcXHUwM0EzLVxcdTAzRjVcXHUwM0Y3LVxcdTA0ODFcXHUwNDgzLVxcdTA0ODdcXHUwNDhBLVxcdTA1MkZcXHUwNTMxLVxcdTA1NTZcXHUwNTU5XFx1MDU2MS1cXHUwNTg3XFx1MDU5MS1cXHUwNUJEXFx1MDVCRlxcdTA1QzFcXHUwNUMyXFx1MDVDNFxcdTA1QzVcXHUwNUM3XFx1MDVEMC1cXHUwNUVBXFx1MDVGMC1cXHUwNUYyXFx1MDYxMC1cXHUwNjFBXFx1MDYyMC1cXHUwNjY5XFx1MDY2RS1cXHUwNkQzXFx1MDZENS1cXHUwNkRDXFx1MDZERi1cXHUwNkU4XFx1MDZFQS1cXHUwNkZDXFx1MDZGRlxcdTA3MTAtXFx1MDc0QVxcdTA3NEQtXFx1MDdCMVxcdTA3QzAtXFx1MDdGNVxcdTA3RkFcXHUwODAwLVxcdTA4MkRcXHUwODQwLVxcdTA4NUJcXHUwODYwLVxcdTA4NkFcXHUwOEEwLVxcdTA4QjRcXHUwOEI2LVxcdTA4QkRcXHUwOEQ0LVxcdTA4RTFcXHUwOEUzLVxcdTA5NjNcXHUwOTY2LVxcdTA5NkZcXHUwOTcxLVxcdTA5ODNcXHUwOTg1LVxcdTA5OENcXHUwOThGXFx1MDk5MFxcdTA5OTMtXFx1MDlBOFxcdTA5QUEtXFx1MDlCMFxcdTA5QjJcXHUwOUI2LVxcdTA5QjlcXHUwOUJDLVxcdTA5QzRcXHUwOUM3XFx1MDlDOFxcdTA5Q0ItXFx1MDlDRVxcdTA5RDdcXHUwOURDXFx1MDlERFxcdTA5REYtXFx1MDlFM1xcdTA5RTYtXFx1MDlGMVxcdTA5RkNcXHUwQTAxLVxcdTBBMDNcXHUwQTA1LVxcdTBBMEFcXHUwQTBGXFx1MEExMFxcdTBBMTMtXFx1MEEyOFxcdTBBMkEtXFx1MEEzMFxcdTBBMzJcXHUwQTMzXFx1MEEzNVxcdTBBMzZcXHUwQTM4XFx1MEEzOVxcdTBBM0NcXHUwQTNFLVxcdTBBNDJcXHUwQTQ3XFx1MEE0OFxcdTBBNEItXFx1MEE0RFxcdTBBNTFcXHUwQTU5LVxcdTBBNUNcXHUwQTVFXFx1MEE2Ni1cXHUwQTc1XFx1MEE4MS1cXHUwQTgzXFx1MEE4NS1cXHUwQThEXFx1MEE4Ri1cXHUwQTkxXFx1MEE5My1cXHUwQUE4XFx1MEFBQS1cXHUwQUIwXFx1MEFCMlxcdTBBQjNcXHUwQUI1LVxcdTBBQjlcXHUwQUJDLVxcdTBBQzVcXHUwQUM3LVxcdTBBQzlcXHUwQUNCLVxcdTBBQ0RcXHUwQUQwXFx1MEFFMC1cXHUwQUUzXFx1MEFFNi1cXHUwQUVGXFx1MEFGOS1cXHUwQUZGXFx1MEIwMS1cXHUwQjAzXFx1MEIwNS1cXHUwQjBDXFx1MEIwRlxcdTBCMTBcXHUwQjEzLVxcdTBCMjhcXHUwQjJBLVxcdTBCMzBcXHUwQjMyXFx1MEIzM1xcdTBCMzUtXFx1MEIzOVxcdTBCM0MtXFx1MEI0NFxcdTBCNDdcXHUwQjQ4XFx1MEI0Qi1cXHUwQjREXFx1MEI1NlxcdTBCNTdcXHUwQjVDXFx1MEI1RFxcdTBCNUYtXFx1MEI2M1xcdTBCNjYtXFx1MEI2RlxcdTBCNzFcXHUwQjgyXFx1MEI4M1xcdTBCODUtXFx1MEI4QVxcdTBCOEUtXFx1MEI5MFxcdTBCOTItXFx1MEI5NVxcdTBCOTlcXHUwQjlBXFx1MEI5Q1xcdTBCOUVcXHUwQjlGXFx1MEJBM1xcdTBCQTRcXHUwQkE4LVxcdTBCQUFcXHUwQkFFLVxcdTBCQjlcXHUwQkJFLVxcdTBCQzJcXHUwQkM2LVxcdTBCQzhcXHUwQkNBLVxcdTBCQ0RcXHUwQkQwXFx1MEJEN1xcdTBCRTYtXFx1MEJFRlxcdTBDMDAtXFx1MEMwM1xcdTBDMDUtXFx1MEMwQ1xcdTBDMEUtXFx1MEMxMFxcdTBDMTItXFx1MEMyOFxcdTBDMkEtXFx1MEMzOVxcdTBDM0QtXFx1MEM0NFxcdTBDNDYtXFx1MEM0OFxcdTBDNEEtXFx1MEM0RFxcdTBDNTVcXHUwQzU2XFx1MEM1OC1cXHUwQzVBXFx1MEM2MC1cXHUwQzYzXFx1MEM2Ni1cXHUwQzZGXFx1MEM4MC1cXHUwQzgzXFx1MEM4NS1cXHUwQzhDXFx1MEM4RS1cXHUwQzkwXFx1MEM5Mi1cXHUwQ0E4XFx1MENBQS1cXHUwQ0IzXFx1MENCNS1cXHUwQ0I5XFx1MENCQy1cXHUwQ0M0XFx1MENDNi1cXHUwQ0M4XFx1MENDQS1cXHUwQ0NEXFx1MENENVxcdTBDRDZcXHUwQ0RFXFx1MENFMC1cXHUwQ0UzXFx1MENFNi1cXHUwQ0VGXFx1MENGMVxcdTBDRjJcXHUwRDAwLVxcdTBEMDNcXHUwRDA1LVxcdTBEMENcXHUwRDBFLVxcdTBEMTBcXHUwRDEyLVxcdTBENDRcXHUwRDQ2LVxcdTBENDhcXHUwRDRBLVxcdTBENEVcXHUwRDU0LVxcdTBENTdcXHUwRDVGLVxcdTBENjNcXHUwRDY2LVxcdTBENkZcXHUwRDdBLVxcdTBEN0ZcXHUwRDgyXFx1MEQ4M1xcdTBEODUtXFx1MEQ5NlxcdTBEOUEtXFx1MERCMVxcdTBEQjMtXFx1MERCQlxcdTBEQkRcXHUwREMwLVxcdTBEQzZcXHUwRENBXFx1MERDRi1cXHUwREQ0XFx1MERENlxcdTBERDgtXFx1MERERlxcdTBERTYtXFx1MERFRlxcdTBERjJcXHUwREYzXFx1MEUwMS1cXHUwRTNBXFx1MEU0MC1cXHUwRTRFXFx1MEU1MC1cXHUwRTU5XFx1MEU4MVxcdTBFODJcXHUwRTg0XFx1MEU4N1xcdTBFODhcXHUwRThBXFx1MEU4RFxcdTBFOTQtXFx1MEU5N1xcdTBFOTktXFx1MEU5RlxcdTBFQTEtXFx1MEVBM1xcdTBFQTVcXHUwRUE3XFx1MEVBQVxcdTBFQUJcXHUwRUFELVxcdTBFQjlcXHUwRUJCLVxcdTBFQkRcXHUwRUMwLVxcdTBFQzRcXHUwRUM2XFx1MEVDOC1cXHUwRUNEXFx1MEVEMC1cXHUwRUQ5XFx1MEVEQy1cXHUwRURGXFx1MEYwMFxcdTBGMThcXHUwRjE5XFx1MEYyMC1cXHUwRjI5XFx1MEYzNVxcdTBGMzdcXHUwRjM5XFx1MEYzRS1cXHUwRjQ3XFx1MEY0OS1cXHUwRjZDXFx1MEY3MS1cXHUwRjg0XFx1MEY4Ni1cXHUwRjk3XFx1MEY5OS1cXHUwRkJDXFx1MEZDNlxcdTEwMDAtXFx1MTA0OVxcdTEwNTAtXFx1MTA5RFxcdTEwQTAtXFx1MTBDNVxcdTEwQzdcXHUxMENEXFx1MTBEMC1cXHUxMEZBXFx1MTBGQy1cXHUxMjQ4XFx1MTI0QS1cXHUxMjREXFx1MTI1MC1cXHUxMjU2XFx1MTI1OFxcdTEyNUEtXFx1MTI1RFxcdTEyNjAtXFx1MTI4OFxcdTEyOEEtXFx1MTI4RFxcdTEyOTAtXFx1MTJCMFxcdTEyQjItXFx1MTJCNVxcdTEyQjgtXFx1MTJCRVxcdTEyQzBcXHUxMkMyLVxcdTEyQzVcXHUxMkM4LVxcdTEyRDZcXHUxMkQ4LVxcdTEzMTBcXHUxMzEyLVxcdTEzMTVcXHUxMzE4LVxcdTEzNUFcXHUxMzVELVxcdTEzNUZcXHUxMzgwLVxcdTEzOEZcXHUxM0EwLVxcdTEzRjVcXHUxM0Y4LVxcdTEzRkRcXHUxNDAxLVxcdTE2NkNcXHUxNjZGLVxcdTE2N0ZcXHUxNjgxLVxcdTE2OUFcXHUxNkEwLVxcdTE2RUFcXHUxNkVFLVxcdTE2RjhcXHUxNzAwLVxcdTE3MENcXHUxNzBFLVxcdTE3MTRcXHUxNzIwLVxcdTE3MzRcXHUxNzQwLVxcdTE3NTNcXHUxNzYwLVxcdTE3NkNcXHUxNzZFLVxcdTE3NzBcXHUxNzcyXFx1MTc3M1xcdTE3ODAtXFx1MTdEM1xcdTE3RDdcXHUxN0RDXFx1MTdERFxcdTE3RTAtXFx1MTdFOVxcdTE4MEItXFx1MTgwRFxcdTE4MTAtXFx1MTgxOVxcdTE4MjAtXFx1MTg3N1xcdTE4ODAtXFx1MThBQVxcdTE4QjAtXFx1MThGNVxcdTE5MDAtXFx1MTkxRVxcdTE5MjAtXFx1MTkyQlxcdTE5MzAtXFx1MTkzQlxcdTE5NDYtXFx1MTk2RFxcdTE5NzAtXFx1MTk3NFxcdTE5ODAtXFx1MTlBQlxcdTE5QjAtXFx1MTlDOVxcdTE5RDAtXFx1MTlEOVxcdTFBMDAtXFx1MUExQlxcdTFBMjAtXFx1MUE1RVxcdTFBNjAtXFx1MUE3Q1xcdTFBN0YtXFx1MUE4OVxcdTFBOTAtXFx1MUE5OVxcdTFBQTdcXHUxQUIwLVxcdTFBQkRcXHUxQjAwLVxcdTFCNEJcXHUxQjUwLVxcdTFCNTlcXHUxQjZCLVxcdTFCNzNcXHUxQjgwLVxcdTFCRjNcXHUxQzAwLVxcdTFDMzdcXHUxQzQwLVxcdTFDNDlcXHUxQzRELVxcdTFDN0RcXHUxQzgwLVxcdTFDODhcXHUxQ0QwLVxcdTFDRDJcXHUxQ0Q0LVxcdTFDRjlcXHUxRDAwLVxcdTFERjlcXHUxREZCLVxcdTFGMTVcXHUxRjE4LVxcdTFGMURcXHUxRjIwLVxcdTFGNDVcXHUxRjQ4LVxcdTFGNERcXHUxRjUwLVxcdTFGNTdcXHUxRjU5XFx1MUY1QlxcdTFGNURcXHUxRjVGLVxcdTFGN0RcXHUxRjgwLVxcdTFGQjRcXHUxRkI2LVxcdTFGQkNcXHUxRkJFXFx1MUZDMi1cXHUxRkM0XFx1MUZDNi1cXHUxRkNDXFx1MUZEMC1cXHUxRkQzXFx1MUZENi1cXHUxRkRCXFx1MUZFMC1cXHUxRkVDXFx1MUZGMi1cXHUxRkY0XFx1MUZGNi1cXHUxRkZDXFx1MjAzRlxcdTIwNDBcXHUyMDU0XFx1MjA3MVxcdTIwN0ZcXHUyMDkwLVxcdTIwOUNcXHUyMEQwLVxcdTIwRENcXHUyMEUxXFx1MjBFNS1cXHUyMEYwXFx1MjEwMlxcdTIxMDdcXHUyMTBBLVxcdTIxMTNcXHUyMTE1XFx1MjExOS1cXHUyMTFEXFx1MjEyNFxcdTIxMjZcXHUyMTI4XFx1MjEyQS1cXHUyMTJEXFx1MjEyRi1cXHUyMTM5XFx1MjEzQy1cXHUyMTNGXFx1MjE0NS1cXHUyMTQ5XFx1MjE0RVxcdTIxNjAtXFx1MjE4OFxcdTJDMDAtXFx1MkMyRVxcdTJDMzAtXFx1MkM1RVxcdTJDNjAtXFx1MkNFNFxcdTJDRUItXFx1MkNGM1xcdTJEMDAtXFx1MkQyNVxcdTJEMjdcXHUyRDJEXFx1MkQzMC1cXHUyRDY3XFx1MkQ2RlxcdTJEN0YtXFx1MkQ5NlxcdTJEQTAtXFx1MkRBNlxcdTJEQTgtXFx1MkRBRVxcdTJEQjAtXFx1MkRCNlxcdTJEQjgtXFx1MkRCRVxcdTJEQzAtXFx1MkRDNlxcdTJEQzgtXFx1MkRDRVxcdTJERDAtXFx1MkRENlxcdTJERDgtXFx1MkRERVxcdTJERTAtXFx1MkRGRlxcdTJFMkZcXHUzMDA1LVxcdTMwMDdcXHUzMDIxLVxcdTMwMkZcXHUzMDMxLVxcdTMwMzVcXHUzMDM4LVxcdTMwM0NcXHUzMDQxLVxcdTMwOTZcXHUzMDk5XFx1MzA5QVxcdTMwOUQtXFx1MzA5RlxcdTMwQTEtXFx1MzBGQVxcdTMwRkMtXFx1MzBGRlxcdTMxMDUtXFx1MzEyRVxcdTMxMzEtXFx1MzE4RVxcdTMxQTAtXFx1MzFCQVxcdTMxRjAtXFx1MzFGRlxcdTM0MDAtXFx1NERCNVxcdTRFMDAtXFx1OUZFQVxcdUEwMDAtXFx1QTQ4Q1xcdUE0RDAtXFx1QTRGRFxcdUE1MDAtXFx1QTYwQ1xcdUE2MTAtXFx1QTYyQlxcdUE2NDAtXFx1QTY2RlxcdUE2NzQtXFx1QTY3RFxcdUE2N0YtXFx1QTZGMVxcdUE3MTctXFx1QTcxRlxcdUE3MjItXFx1QTc4OFxcdUE3OEItXFx1QTdBRVxcdUE3QjAtXFx1QTdCN1xcdUE3RjctXFx1QTgyN1xcdUE4NDAtXFx1QTg3M1xcdUE4ODAtXFx1QThDNVxcdUE4RDAtXFx1QThEOVxcdUE4RTAtXFx1QThGN1xcdUE4RkJcXHVBOEZEXFx1QTkwMC1cXHVBOTJEXFx1QTkzMC1cXHVBOTUzXFx1QTk2MC1cXHVBOTdDXFx1QTk4MC1cXHVBOUMwXFx1QTlDRi1cXHVBOUQ5XFx1QTlFMC1cXHVBOUZFXFx1QUEwMC1cXHVBQTM2XFx1QUE0MC1cXHVBQTREXFx1QUE1MC1cXHVBQTU5XFx1QUE2MC1cXHVBQTc2XFx1QUE3QS1cXHVBQUMyXFx1QUFEQi1cXHVBQUREXFx1QUFFMC1cXHVBQUVGXFx1QUFGMi1cXHVBQUY2XFx1QUIwMS1cXHVBQjA2XFx1QUIwOS1cXHVBQjBFXFx1QUIxMS1cXHVBQjE2XFx1QUIyMC1cXHVBQjI2XFx1QUIyOC1cXHVBQjJFXFx1QUIzMC1cXHVBQjVBXFx1QUI1Qy1cXHVBQjY1XFx1QUI3MC1cXHVBQkVBXFx1QUJFQ1xcdUFCRURcXHVBQkYwLVxcdUFCRjlcXHVBQzAwLVxcdUQ3QTNcXHVEN0IwLVxcdUQ3QzZcXHVEN0NCLVxcdUQ3RkJcXHVGOTAwLVxcdUZBNkRcXHVGQTcwLVxcdUZBRDlcXHVGQjAwLVxcdUZCMDZcXHVGQjEzLVxcdUZCMTdcXHVGQjFELVxcdUZCMjhcXHVGQjJBLVxcdUZCMzZcXHVGQjM4LVxcdUZCM0NcXHVGQjNFXFx1RkI0MFxcdUZCNDFcXHVGQjQzXFx1RkI0NFxcdUZCNDYtXFx1RkJCMVxcdUZCRDMtXFx1RkQzRFxcdUZENTAtXFx1RkQ4RlxcdUZEOTItXFx1RkRDN1xcdUZERjAtXFx1RkRGQlxcdUZFMDAtXFx1RkUwRlxcdUZFMjAtXFx1RkUyRlxcdUZFMzNcXHVGRTM0XFx1RkU0RC1cXHVGRTRGXFx1RkU3MC1cXHVGRTc0XFx1RkU3Ni1cXHVGRUZDXFx1RkYxMC1cXHVGRjE5XFx1RkYyMS1cXHVGRjNBXFx1RkYzRlxcdUZGNDEtXFx1RkY1QVxcdUZGNjYtXFx1RkZCRVxcdUZGQzItXFx1RkZDN1xcdUZGQ0EtXFx1RkZDRlxcdUZGRDItXFx1RkZEN1xcdUZGREEtXFx1RkZEQ118XFx1RDgwMFtcXHVEQzAwLVxcdURDMEJcXHVEQzBELVxcdURDMjZcXHVEQzI4LVxcdURDM0FcXHVEQzNDXFx1REMzRFxcdURDM0YtXFx1REM0RFxcdURDNTAtXFx1REM1RFxcdURDODAtXFx1RENGQVxcdURENDAtXFx1REQ3NFxcdURERkRcXHVERTgwLVxcdURFOUNcXHVERUEwLVxcdURFRDBcXHVERUUwXFx1REYwMC1cXHVERjFGXFx1REYyRC1cXHVERjRBXFx1REY1MC1cXHVERjdBXFx1REY4MC1cXHVERjlEXFx1REZBMC1cXHVERkMzXFx1REZDOC1cXHVERkNGXFx1REZEMS1cXHVERkQ1XXxcXHVEODAxW1xcdURDMDAtXFx1REM5RFxcdURDQTAtXFx1RENBOVxcdURDQjAtXFx1RENEM1xcdURDRDgtXFx1RENGQlxcdUREMDAtXFx1REQyN1xcdUREMzAtXFx1REQ2M1xcdURFMDAtXFx1REYzNlxcdURGNDAtXFx1REY1NVxcdURGNjAtXFx1REY2N118XFx1RDgwMltcXHVEQzAwLVxcdURDMDVcXHVEQzA4XFx1REMwQS1cXHVEQzM1XFx1REMzN1xcdURDMzhcXHVEQzNDXFx1REMzRi1cXHVEQzU1XFx1REM2MC1cXHVEQzc2XFx1REM4MC1cXHVEQzlFXFx1RENFMC1cXHVEQ0YyXFx1RENGNFxcdURDRjVcXHVERDAwLVxcdUREMTVcXHVERDIwLVxcdUREMzlcXHVERDgwLVxcdUREQjdcXHVEREJFXFx1RERCRlxcdURFMDAtXFx1REUwM1xcdURFMDVcXHVERTA2XFx1REUwQy1cXHVERTEzXFx1REUxNS1cXHVERTE3XFx1REUxOS1cXHVERTMzXFx1REUzOC1cXHVERTNBXFx1REUzRlxcdURFNjAtXFx1REU3Q1xcdURFODAtXFx1REU5Q1xcdURFQzAtXFx1REVDN1xcdURFQzktXFx1REVFNlxcdURGMDAtXFx1REYzNVxcdURGNDAtXFx1REY1NVxcdURGNjAtXFx1REY3MlxcdURGODAtXFx1REY5MV18XFx1RDgwM1tcXHVEQzAwLVxcdURDNDhcXHVEQzgwLVxcdURDQjJcXHVEQ0MwLVxcdURDRjJdfFxcdUQ4MDRbXFx1REMwMC1cXHVEQzQ2XFx1REM2Ni1cXHVEQzZGXFx1REM3Ri1cXHVEQ0JBXFx1RENEMC1cXHVEQ0U4XFx1RENGMC1cXHVEQ0Y5XFx1REQwMC1cXHVERDM0XFx1REQzNi1cXHVERDNGXFx1REQ1MC1cXHVERDczXFx1REQ3NlxcdUREODAtXFx1RERDNFxcdUREQ0EtXFx1RERDQ1xcdURERDAtXFx1REREQVxcdURERENcXHVERTAwLVxcdURFMTFcXHVERTEzLVxcdURFMzdcXHVERTNFXFx1REU4MC1cXHVERTg2XFx1REU4OFxcdURFOEEtXFx1REU4RFxcdURFOEYtXFx1REU5RFxcdURFOUYtXFx1REVBOFxcdURFQjAtXFx1REVFQVxcdURFRjAtXFx1REVGOVxcdURGMDAtXFx1REYwM1xcdURGMDUtXFx1REYwQ1xcdURGMEZcXHVERjEwXFx1REYxMy1cXHVERjI4XFx1REYyQS1cXHVERjMwXFx1REYzMlxcdURGMzNcXHVERjM1LVxcdURGMzlcXHVERjNDLVxcdURGNDRcXHVERjQ3XFx1REY0OFxcdURGNEItXFx1REY0RFxcdURGNTBcXHVERjU3XFx1REY1RC1cXHVERjYzXFx1REY2Ni1cXHVERjZDXFx1REY3MC1cXHVERjc0XXxcXHVEODA1W1xcdURDMDAtXFx1REM0QVxcdURDNTAtXFx1REM1OVxcdURDODAtXFx1RENDNVxcdURDQzdcXHVEQ0QwLVxcdURDRDlcXHVERDgwLVxcdUREQjVcXHVEREI4LVxcdUREQzBcXHVEREQ4LVxcdURERERcXHVERTAwLVxcdURFNDBcXHVERTQ0XFx1REU1MC1cXHVERTU5XFx1REU4MC1cXHVERUI3XFx1REVDMC1cXHVERUM5XFx1REYwMC1cXHVERjE5XFx1REYxRC1cXHVERjJCXFx1REYzMC1cXHVERjM5XXxcXHVEODA2W1xcdURDQTAtXFx1RENFOVxcdURDRkZcXHVERTAwLVxcdURFM0VcXHVERTQ3XFx1REU1MC1cXHVERTgzXFx1REU4Ni1cXHVERTk5XFx1REVDMC1cXHVERUY4XXxcXHVEODA3W1xcdURDMDAtXFx1REMwOFxcdURDMEEtXFx1REMzNlxcdURDMzgtXFx1REM0MFxcdURDNTAtXFx1REM1OVxcdURDNzItXFx1REM4RlxcdURDOTItXFx1RENBN1xcdURDQTktXFx1RENCNlxcdUREMDAtXFx1REQwNlxcdUREMDhcXHVERDA5XFx1REQwQi1cXHVERDM2XFx1REQzQVxcdUREM0NcXHVERDNEXFx1REQzRi1cXHVERDQ3XFx1REQ1MC1cXHVERDU5XXxcXHVEODA4W1xcdURDMDAtXFx1REY5OV18XFx1RDgwOVtcXHVEQzAwLVxcdURDNkVcXHVEQzgwLVxcdURENDNdfFtcXHVEODBDXFx1RDgxQy1cXHVEODIwXFx1RDg0MC1cXHVEODY4XFx1RDg2QS1cXHVEODZDXFx1RDg2Ri1cXHVEODcyXFx1RDg3NC1cXHVEODc5XVtcXHVEQzAwLVxcdURGRkZdfFxcdUQ4MERbXFx1REMwMC1cXHVEQzJFXXxcXHVEODExW1xcdURDMDAtXFx1REU0Nl18XFx1RDgxQVtcXHVEQzAwLVxcdURFMzhcXHVERTQwLVxcdURFNUVcXHVERTYwLVxcdURFNjlcXHVERUQwLVxcdURFRURcXHVERUYwLVxcdURFRjRcXHVERjAwLVxcdURGMzZcXHVERjQwLVxcdURGNDNcXHVERjUwLVxcdURGNTlcXHVERjYzLVxcdURGNzdcXHVERjdELVxcdURGOEZdfFxcdUQ4MUJbXFx1REYwMC1cXHVERjQ0XFx1REY1MC1cXHVERjdFXFx1REY4Ri1cXHVERjlGXFx1REZFMFxcdURGRTFdfFxcdUQ4MjFbXFx1REMwMC1cXHVERkVDXXxcXHVEODIyW1xcdURDMDAtXFx1REVGMl18XFx1RDgyQ1tcXHVEQzAwLVxcdUREMUVcXHVERDcwLVxcdURFRkJdfFxcdUQ4MkZbXFx1REMwMC1cXHVEQzZBXFx1REM3MC1cXHVEQzdDXFx1REM4MC1cXHVEQzg4XFx1REM5MC1cXHVEQzk5XFx1REM5RFxcdURDOUVdfFxcdUQ4MzRbXFx1REQ2NS1cXHVERDY5XFx1REQ2RC1cXHVERDcyXFx1REQ3Qi1cXHVERDgyXFx1REQ4NS1cXHVERDhCXFx1RERBQS1cXHVEREFEXFx1REU0Mi1cXHVERTQ0XXxcXHVEODM1W1xcdURDMDAtXFx1REM1NFxcdURDNTYtXFx1REM5Q1xcdURDOUVcXHVEQzlGXFx1RENBMlxcdURDQTVcXHVEQ0E2XFx1RENBOS1cXHVEQ0FDXFx1RENBRS1cXHVEQ0I5XFx1RENCQlxcdURDQkQtXFx1RENDM1xcdURDQzUtXFx1REQwNVxcdUREMDctXFx1REQwQVxcdUREMEQtXFx1REQxNFxcdUREMTYtXFx1REQxQ1xcdUREMUUtXFx1REQzOVxcdUREM0ItXFx1REQzRVxcdURENDAtXFx1REQ0NFxcdURENDZcXHVERDRBLVxcdURENTBcXHVERDUyLVxcdURFQTVcXHVERUE4LVxcdURFQzBcXHVERUMyLVxcdURFREFcXHVERURDLVxcdURFRkFcXHVERUZDLVxcdURGMTRcXHVERjE2LVxcdURGMzRcXHVERjM2LVxcdURGNEVcXHVERjUwLVxcdURGNkVcXHVERjcwLVxcdURGODhcXHVERjhBLVxcdURGQThcXHVERkFBLVxcdURGQzJcXHVERkM0LVxcdURGQ0JcXHVERkNFLVxcdURGRkZdfFxcdUQ4MzZbXFx1REUwMC1cXHVERTM2XFx1REUzQi1cXHVERTZDXFx1REU3NVxcdURFODRcXHVERTlCLVxcdURFOUZcXHVERUExLVxcdURFQUZdfFxcdUQ4MzhbXFx1REMwMC1cXHVEQzA2XFx1REMwOC1cXHVEQzE4XFx1REMxQi1cXHVEQzIxXFx1REMyM1xcdURDMjRcXHVEQzI2LVxcdURDMkFdfFxcdUQ4M0FbXFx1REMwMC1cXHVEQ0M0XFx1RENEMC1cXHVEQ0Q2XFx1REQwMC1cXHVERDRBXFx1REQ1MC1cXHVERDU5XXxcXHVEODNCW1xcdURFMDAtXFx1REUwM1xcdURFMDUtXFx1REUxRlxcdURFMjFcXHVERTIyXFx1REUyNFxcdURFMjdcXHVERTI5LVxcdURFMzJcXHVERTM0LVxcdURFMzdcXHVERTM5XFx1REUzQlxcdURFNDJcXHVERTQ3XFx1REU0OVxcdURFNEJcXHVERTRELVxcdURFNEZcXHVERTUxXFx1REU1MlxcdURFNTRcXHVERTU3XFx1REU1OVxcdURFNUJcXHVERTVEXFx1REU1RlxcdURFNjFcXHVERTYyXFx1REU2NFxcdURFNjctXFx1REU2QVxcdURFNkMtXFx1REU3MlxcdURFNzQtXFx1REU3N1xcdURFNzktXFx1REU3Q1xcdURFN0VcXHVERTgwLVxcdURFODlcXHVERThCLVxcdURFOUJcXHVERUExLVxcdURFQTNcXHVERUE1LVxcdURFQTlcXHVERUFCLVxcdURFQkJdfFxcdUQ4NjlbXFx1REMwMC1cXHVERUQ2XFx1REYwMC1cXHVERkZGXXxcXHVEODZEW1xcdURDMDAtXFx1REYzNFxcdURGNDAtXFx1REZGRl18XFx1RDg2RVtcXHVEQzAwLVxcdURDMURcXHVEQzIwLVxcdURGRkZdfFxcdUQ4NzNbXFx1REMwMC1cXHVERUExXFx1REVCMC1cXHVERkZGXXxcXHVEODdBW1xcdURDMDAtXFx1REZFMF18XFx1RDg3RVtcXHVEQzAwLVxcdURFMURdfFxcdURCNDBbXFx1REQwMC1cXHVEREVGXS99LFU9e2lzU3BhY2VTZXBhcmF0b3I6ZnVuY3Rpb24odSl7cmV0dXJuXCJzdHJpbmdcIj09dHlwZW9mIHUmJkcuU3BhY2VfU2VwYXJhdG9yLnRlc3QodSl9LGlzSWRTdGFydENoYXI6ZnVuY3Rpb24odSl7cmV0dXJuXCJzdHJpbmdcIj09dHlwZW9mIHUmJih1Pj1cImFcIiYmdTw9XCJ6XCJ8fHU+PVwiQVwiJiZ1PD1cIlpcInx8XCIkXCI9PT11fHxcIl9cIj09PXV8fEcuSURfU3RhcnQudGVzdCh1KSl9LGlzSWRDb250aW51ZUNoYXI6ZnVuY3Rpb24odSl7cmV0dXJuXCJzdHJpbmdcIj09dHlwZW9mIHUmJih1Pj1cImFcIiYmdTw9XCJ6XCJ8fHU+PVwiQVwiJiZ1PD1cIlpcInx8dT49XCIwXCImJnU8PVwiOVwifHxcIiRcIj09PXV8fFwiX1wiPT09dXx8XCLigIxcIj09PXV8fFwi4oCNXCI9PT11fHxHLklEX0NvbnRpbnVlLnRlc3QodSkpfSxpc0RpZ2l0OmZ1bmN0aW9uKHUpe3JldHVyblwic3RyaW5nXCI9PXR5cGVvZiB1JiYvWzAtOV0vLnRlc3QodSl9LGlzSGV4RGlnaXQ6ZnVuY3Rpb24odSl7cmV0dXJuXCJzdHJpbmdcIj09dHlwZW9mIHUmJi9bMC05QS1GYS1mXS8udGVzdCh1KX19O2Z1bmN0aW9uIFooKXtmb3IoVD1cImRlZmF1bHRcIix6PVwiXCIsSD0hMSwkPTE7Oyl7Uj1xKCk7dmFyIHU9WFtUXSgpO2lmKHUpcmV0dXJuIHV9fWZ1bmN0aW9uIHEoKXtpZihfW2pdKXJldHVybiBTdHJpbmcuZnJvbUNvZGVQb2ludChfLmNvZGVQb2ludEF0KGopKX1mdW5jdGlvbiBXKCl7dmFyIHU9cSgpO3JldHVyblwiXFxuXCI9PT11PyhWKyssSj0wKTp1P0orPXUubGVuZ3RoOkorKyx1JiYoais9dS5sZW5ndGgpLHV9dmFyIFg9e2RlZmF1bHQ6ZnVuY3Rpb24oKXtzd2l0Y2goUil7Y2FzZVwiXFx0XCI6Y2FzZVwiXFx2XCI6Y2FzZVwiXFxmXCI6Y2FzZVwiIFwiOmNhc2VcIsKgXCI6Y2FzZVwiXFx1ZmVmZlwiOmNhc2VcIlxcblwiOmNhc2VcIlxcclwiOmNhc2VcIlxcdTIwMjhcIjpjYXNlXCJcXHUyMDI5XCI6cmV0dXJuIHZvaWQgVygpO2Nhc2VcIi9cIjpyZXR1cm4gVygpLHZvaWQoVD1cImNvbW1lbnRcIik7Y2FzZSB2b2lkIDA6cmV0dXJuIFcoKSxLKFwiZW9mXCIpfWlmKCFVLmlzU3BhY2VTZXBhcmF0b3IoUikpcmV0dXJuIFhbSV0oKTtXKCl9LGNvbW1lbnQ6ZnVuY3Rpb24oKXtzd2l0Y2goUil7Y2FzZVwiKlwiOnJldHVybiBXKCksdm9pZChUPVwibXVsdGlMaW5lQ29tbWVudFwiKTtjYXNlXCIvXCI6cmV0dXJuIFcoKSx2b2lkKFQ9XCJzaW5nbGVMaW5lQ29tbWVudFwiKX10aHJvdyB0dShXKCkpfSxtdWx0aUxpbmVDb21tZW50OmZ1bmN0aW9uKCl7c3dpdGNoKFIpe2Nhc2VcIipcIjpyZXR1cm4gVygpLHZvaWQoVD1cIm11bHRpTGluZUNvbW1lbnRBc3Rlcmlza1wiKTtjYXNlIHZvaWQgMDp0aHJvdyB0dShXKCkpfVcoKX0sbXVsdGlMaW5lQ29tbWVudEFzdGVyaXNrOmZ1bmN0aW9uKCl7c3dpdGNoKFIpe2Nhc2VcIipcIjpyZXR1cm4gdm9pZCBXKCk7Y2FzZVwiL1wiOnJldHVybiBXKCksdm9pZChUPVwiZGVmYXVsdFwiKTtjYXNlIHZvaWQgMDp0aHJvdyB0dShXKCkpfVcoKSxUPVwibXVsdGlMaW5lQ29tbWVudFwifSxzaW5nbGVMaW5lQ29tbWVudDpmdW5jdGlvbigpe3N3aXRjaChSKXtjYXNlXCJcXG5cIjpjYXNlXCJcXHJcIjpjYXNlXCJcXHUyMDI4XCI6Y2FzZVwiXFx1MjAyOVwiOnJldHVybiBXKCksdm9pZChUPVwiZGVmYXVsdFwiKTtjYXNlIHZvaWQgMDpyZXR1cm4gVygpLEsoXCJlb2ZcIil9VygpfSx2YWx1ZTpmdW5jdGlvbigpe3N3aXRjaChSKXtjYXNlXCJ7XCI6Y2FzZVwiW1wiOnJldHVybiBLKFwicHVuY3R1YXRvclwiLFcoKSk7Y2FzZVwiblwiOnJldHVybiBXKCksUShcInVsbFwiKSxLKFwibnVsbFwiLG51bGwpO2Nhc2VcInRcIjpyZXR1cm4gVygpLFEoXCJydWVcIiksSyhcImJvb2xlYW5cIiwhMCk7Y2FzZVwiZlwiOnJldHVybiBXKCksUShcImFsc2VcIiksSyhcImJvb2xlYW5cIiwhMSk7Y2FzZVwiLVwiOmNhc2VcIitcIjpyZXR1cm5cIi1cIj09PVcoKSYmKCQ9LTEpLHZvaWQoVD1cInNpZ25cIik7Y2FzZVwiLlwiOnJldHVybiB6PVcoKSx2b2lkKFQ9XCJkZWNpbWFsUG9pbnRMZWFkaW5nXCIpO2Nhc2VcIjBcIjpyZXR1cm4gej1XKCksdm9pZChUPVwiemVyb1wiKTtjYXNlXCIxXCI6Y2FzZVwiMlwiOmNhc2VcIjNcIjpjYXNlXCI0XCI6Y2FzZVwiNVwiOmNhc2VcIjZcIjpjYXNlXCI3XCI6Y2FzZVwiOFwiOmNhc2VcIjlcIjpyZXR1cm4gej1XKCksdm9pZChUPVwiZGVjaW1hbEludGVnZXJcIik7Y2FzZVwiSVwiOnJldHVybiBXKCksUShcIm5maW5pdHlcIiksSyhcIm51bWVyaWNcIiwxLzApO2Nhc2VcIk5cIjpyZXR1cm4gVygpLFEoXCJhTlwiKSxLKFwibnVtZXJpY1wiLE5hTik7Y2FzZSdcIic6Y2FzZVwiJ1wiOnJldHVybiBIPSdcIic9PT1XKCksej1cIlwiLHZvaWQoVD1cInN0cmluZ1wiKX10aHJvdyB0dShXKCkpfSxpZGVudGlmaWVyTmFtZVN0YXJ0RXNjYXBlOmZ1bmN0aW9uKCl7aWYoXCJ1XCIhPT1SKXRocm93IHR1KFcoKSk7VygpO3ZhciB1PVkoKTtzd2l0Y2godSl7Y2FzZVwiJFwiOmNhc2VcIl9cIjpicmVhaztkZWZhdWx0OmlmKCFVLmlzSWRTdGFydENoYXIodSkpdGhyb3cgRnUoKX16Kz11LFQ9XCJpZGVudGlmaWVyTmFtZVwifSxpZGVudGlmaWVyTmFtZTpmdW5jdGlvbigpe3N3aXRjaChSKXtjYXNlXCIkXCI6Y2FzZVwiX1wiOmNhc2VcIuKAjFwiOmNhc2VcIuKAjVwiOnJldHVybiB2b2lkKHorPVcoKSk7Y2FzZVwiXFxcXFwiOnJldHVybiBXKCksdm9pZChUPVwiaWRlbnRpZmllck5hbWVFc2NhcGVcIil9aWYoIVUuaXNJZENvbnRpbnVlQ2hhcihSKSlyZXR1cm4gSyhcImlkZW50aWZpZXJcIix6KTt6Kz1XKCl9LGlkZW50aWZpZXJOYW1lRXNjYXBlOmZ1bmN0aW9uKCl7aWYoXCJ1XCIhPT1SKXRocm93IHR1KFcoKSk7VygpO3ZhciB1PVkoKTtzd2l0Y2godSl7Y2FzZVwiJFwiOmNhc2VcIl9cIjpjYXNlXCLigIxcIjpjYXNlXCLigI1cIjpicmVhaztkZWZhdWx0OmlmKCFVLmlzSWRDb250aW51ZUNoYXIodSkpdGhyb3cgRnUoKX16Kz11LFQ9XCJpZGVudGlmaWVyTmFtZVwifSxzaWduOmZ1bmN0aW9uKCl7c3dpdGNoKFIpe2Nhc2VcIi5cIjpyZXR1cm4gej1XKCksdm9pZChUPVwiZGVjaW1hbFBvaW50TGVhZGluZ1wiKTtjYXNlXCIwXCI6cmV0dXJuIHo9VygpLHZvaWQoVD1cInplcm9cIik7Y2FzZVwiMVwiOmNhc2VcIjJcIjpjYXNlXCIzXCI6Y2FzZVwiNFwiOmNhc2VcIjVcIjpjYXNlXCI2XCI6Y2FzZVwiN1wiOmNhc2VcIjhcIjpjYXNlXCI5XCI6cmV0dXJuIHo9VygpLHZvaWQoVD1cImRlY2ltYWxJbnRlZ2VyXCIpO2Nhc2VcIklcIjpyZXR1cm4gVygpLFEoXCJuZmluaXR5XCIpLEsoXCJudW1lcmljXCIsJCooMS8wKSk7Y2FzZVwiTlwiOnJldHVybiBXKCksUShcImFOXCIpLEsoXCJudW1lcmljXCIsTmFOKX10aHJvdyB0dShXKCkpfSx6ZXJvOmZ1bmN0aW9uKCl7c3dpdGNoKFIpe2Nhc2VcIi5cIjpyZXR1cm4geis9VygpLHZvaWQoVD1cImRlY2ltYWxQb2ludFwiKTtjYXNlXCJlXCI6Y2FzZVwiRVwiOnJldHVybiB6Kz1XKCksdm9pZChUPVwiZGVjaW1hbEV4cG9uZW50XCIpO2Nhc2VcInhcIjpjYXNlXCJYXCI6cmV0dXJuIHorPVcoKSx2b2lkKFQ9XCJoZXhhZGVjaW1hbFwiKX1yZXR1cm4gSyhcIm51bWVyaWNcIiwwKiQpfSxkZWNpbWFsSW50ZWdlcjpmdW5jdGlvbigpe3N3aXRjaChSKXtjYXNlXCIuXCI6cmV0dXJuIHorPVcoKSx2b2lkKFQ9XCJkZWNpbWFsUG9pbnRcIik7Y2FzZVwiZVwiOmNhc2VcIkVcIjpyZXR1cm4geis9VygpLHZvaWQoVD1cImRlY2ltYWxFeHBvbmVudFwiKX1pZighVS5pc0RpZ2l0KFIpKXJldHVybiBLKFwibnVtZXJpY1wiLCQqTnVtYmVyKHopKTt6Kz1XKCl9LGRlY2ltYWxQb2ludExlYWRpbmc6ZnVuY3Rpb24oKXtpZihVLmlzRGlnaXQoUikpcmV0dXJuIHorPVcoKSx2b2lkKFQ9XCJkZWNpbWFsRnJhY3Rpb25cIik7dGhyb3cgdHUoVygpKX0sZGVjaW1hbFBvaW50OmZ1bmN0aW9uKCl7c3dpdGNoKFIpe2Nhc2VcImVcIjpjYXNlXCJFXCI6cmV0dXJuIHorPVcoKSx2b2lkKFQ9XCJkZWNpbWFsRXhwb25lbnRcIil9cmV0dXJuIFUuaXNEaWdpdChSKT8oeis9VygpLHZvaWQoVD1cImRlY2ltYWxGcmFjdGlvblwiKSk6SyhcIm51bWVyaWNcIiwkKk51bWJlcih6KSl9LGRlY2ltYWxGcmFjdGlvbjpmdW5jdGlvbigpe3N3aXRjaChSKXtjYXNlXCJlXCI6Y2FzZVwiRVwiOnJldHVybiB6Kz1XKCksdm9pZChUPVwiZGVjaW1hbEV4cG9uZW50XCIpfWlmKCFVLmlzRGlnaXQoUikpcmV0dXJuIEsoXCJudW1lcmljXCIsJCpOdW1iZXIoeikpO3orPVcoKX0sZGVjaW1hbEV4cG9uZW50OmZ1bmN0aW9uKCl7c3dpdGNoKFIpe2Nhc2VcIitcIjpjYXNlXCItXCI6cmV0dXJuIHorPVcoKSx2b2lkKFQ9XCJkZWNpbWFsRXhwb25lbnRTaWduXCIpfWlmKFUuaXNEaWdpdChSKSlyZXR1cm4geis9VygpLHZvaWQoVD1cImRlY2ltYWxFeHBvbmVudEludGVnZXJcIik7dGhyb3cgdHUoVygpKX0sZGVjaW1hbEV4cG9uZW50U2lnbjpmdW5jdGlvbigpe2lmKFUuaXNEaWdpdChSKSlyZXR1cm4geis9VygpLHZvaWQoVD1cImRlY2ltYWxFeHBvbmVudEludGVnZXJcIik7dGhyb3cgdHUoVygpKX0sZGVjaW1hbEV4cG9uZW50SW50ZWdlcjpmdW5jdGlvbigpe2lmKCFVLmlzRGlnaXQoUikpcmV0dXJuIEsoXCJudW1lcmljXCIsJCpOdW1iZXIoeikpO3orPVcoKX0saGV4YWRlY2ltYWw6ZnVuY3Rpb24oKXtpZihVLmlzSGV4RGlnaXQoUikpcmV0dXJuIHorPVcoKSx2b2lkKFQ9XCJoZXhhZGVjaW1hbEludGVnZXJcIik7dGhyb3cgdHUoVygpKX0saGV4YWRlY2ltYWxJbnRlZ2VyOmZ1bmN0aW9uKCl7aWYoIVUuaXNIZXhEaWdpdChSKSlyZXR1cm4gSyhcIm51bWVyaWNcIiwkKk51bWJlcih6KSk7eis9VygpfSxzdHJpbmc6ZnVuY3Rpb24oKXtzd2l0Y2goUil7Y2FzZVwiXFxcXFwiOnJldHVybiBXKCksdm9pZCh6Kz1mdW5jdGlvbigpe3N3aXRjaChxKCkpe2Nhc2VcImJcIjpyZXR1cm4gVygpLFwiXFxiXCI7Y2FzZVwiZlwiOnJldHVybiBXKCksXCJcXGZcIjtjYXNlXCJuXCI6cmV0dXJuIFcoKSxcIlxcblwiO2Nhc2VcInJcIjpyZXR1cm4gVygpLFwiXFxyXCI7Y2FzZVwidFwiOnJldHVybiBXKCksXCJcXHRcIjtjYXNlXCJ2XCI6cmV0dXJuIFcoKSxcIlxcdlwiO2Nhc2VcIjBcIjppZihXKCksVS5pc0RpZ2l0KHEoKSkpdGhyb3cgdHUoVygpKTtyZXR1cm5cIlxcMFwiO2Nhc2VcInhcIjpyZXR1cm4gVygpLGZ1bmN0aW9uKCl7dmFyIHU9XCJcIixEPXEoKTtpZighVS5pc0hleERpZ2l0KEQpKXRocm93IHR1KFcoKSk7aWYodSs9VygpLEQ9cSgpLCFVLmlzSGV4RGlnaXQoRCkpdGhyb3cgdHUoVygpKTtyZXR1cm4gdSs9VygpLFN0cmluZy5mcm9tQ29kZVBvaW50KHBhcnNlSW50KHUsMTYpKX0oKTtjYXNlXCJ1XCI6cmV0dXJuIFcoKSxZKCk7Y2FzZVwiXFxuXCI6Y2FzZVwiXFx1MjAyOFwiOmNhc2VcIlxcdTIwMjlcIjpyZXR1cm4gVygpLFwiXCI7Y2FzZVwiXFxyXCI6cmV0dXJuIFcoKSxcIlxcblwiPT09cSgpJiZXKCksXCJcIjtjYXNlXCIxXCI6Y2FzZVwiMlwiOmNhc2VcIjNcIjpjYXNlXCI0XCI6Y2FzZVwiNVwiOmNhc2VcIjZcIjpjYXNlXCI3XCI6Y2FzZVwiOFwiOmNhc2VcIjlcIjpjYXNlIHZvaWQgMDp0aHJvdyB0dShXKCkpfXJldHVybiBXKCl9KCkpO2Nhc2UnXCInOnJldHVybiBIPyhXKCksSyhcInN0cmluZ1wiLHopKTp2b2lkKHorPVcoKSk7Y2FzZVwiJ1wiOnJldHVybiBIP3ZvaWQoeis9VygpKTooVygpLEsoXCJzdHJpbmdcIix6KSk7Y2FzZVwiXFxuXCI6Y2FzZVwiXFxyXCI6dGhyb3cgdHUoVygpKTtjYXNlXCJcXHUyMDI4XCI6Y2FzZVwiXFx1MjAyOVwiOiFmdW5jdGlvbih1KXtjb25zb2xlLndhcm4oXCJKU09ONTogJ1wiK251KHUpK1wiJyBpbiBzdHJpbmdzIGlzIG5vdCB2YWxpZCBFQ01BU2NyaXB0OyBjb25zaWRlciBlc2NhcGluZ1wiKX0oUik7YnJlYWs7Y2FzZSB2b2lkIDA6dGhyb3cgdHUoVygpKX16Kz1XKCl9LHN0YXJ0OmZ1bmN0aW9uKCl7c3dpdGNoKFIpe2Nhc2VcIntcIjpjYXNlXCJbXCI6cmV0dXJuIEsoXCJwdW5jdHVhdG9yXCIsVygpKX1UPVwidmFsdWVcIn0sYmVmb3JlUHJvcGVydHlOYW1lOmZ1bmN0aW9uKCl7c3dpdGNoKFIpe2Nhc2VcIiRcIjpjYXNlXCJfXCI6cmV0dXJuIHo9VygpLHZvaWQoVD1cImlkZW50aWZpZXJOYW1lXCIpO2Nhc2VcIlxcXFxcIjpyZXR1cm4gVygpLHZvaWQoVD1cImlkZW50aWZpZXJOYW1lU3RhcnRFc2NhcGVcIik7Y2FzZVwifVwiOnJldHVybiBLKFwicHVuY3R1YXRvclwiLFcoKSk7Y2FzZSdcIic6Y2FzZVwiJ1wiOnJldHVybiBIPSdcIic9PT1XKCksdm9pZChUPVwic3RyaW5nXCIpfWlmKFUuaXNJZFN0YXJ0Q2hhcihSKSlyZXR1cm4geis9VygpLHZvaWQoVD1cImlkZW50aWZpZXJOYW1lXCIpO3Rocm93IHR1KFcoKSl9LGFmdGVyUHJvcGVydHlOYW1lOmZ1bmN0aW9uKCl7aWYoXCI6XCI9PT1SKXJldHVybiBLKFwicHVuY3R1YXRvclwiLFcoKSk7dGhyb3cgdHUoVygpKX0sYmVmb3JlUHJvcGVydHlWYWx1ZTpmdW5jdGlvbigpe1Q9XCJ2YWx1ZVwifSxhZnRlclByb3BlcnR5VmFsdWU6ZnVuY3Rpb24oKXtzd2l0Y2goUil7Y2FzZVwiLFwiOmNhc2VcIn1cIjpyZXR1cm4gSyhcInB1bmN0dWF0b3JcIixXKCkpfXRocm93IHR1KFcoKSl9LGJlZm9yZUFycmF5VmFsdWU6ZnVuY3Rpb24oKXtpZihcIl1cIj09PVIpcmV0dXJuIEsoXCJwdW5jdHVhdG9yXCIsVygpKTtUPVwidmFsdWVcIn0sYWZ0ZXJBcnJheVZhbHVlOmZ1bmN0aW9uKCl7c3dpdGNoKFIpe2Nhc2VcIixcIjpjYXNlXCJdXCI6cmV0dXJuIEsoXCJwdW5jdHVhdG9yXCIsVygpKX10aHJvdyB0dShXKCkpfSxlbmQ6ZnVuY3Rpb24oKXt0aHJvdyB0dShXKCkpfX07ZnVuY3Rpb24gSyh1LEQpe3JldHVybnt0eXBlOnUsdmFsdWU6RCxsaW5lOlYsY29sdW1uOkp9fWZ1bmN0aW9uIFEodSl7Zm9yKHZhciBEPTAsZT11O0Q8ZS5sZW5ndGg7RCs9MSl7dmFyIHQ9ZVtEXTtpZihxKCkhPT10KXRocm93IHR1KFcoKSk7VygpfX1mdW5jdGlvbiBZKCl7Zm9yKHZhciB1PVwiXCIsRD00O0QtLSA+MDspe3ZhciBlPXEoKTtpZighVS5pc0hleERpZ2l0KGUpKXRocm93IHR1KFcoKSk7dSs9VygpfXJldHVybiBTdHJpbmcuZnJvbUNvZGVQb2ludChwYXJzZUludCh1LDE2KSl9dmFyIHV1PXtzdGFydDpmdW5jdGlvbigpe2lmKFwiZW9mXCI9PT1NLnR5cGUpdGhyb3cgcnUoKTtEdSgpfSxiZWZvcmVQcm9wZXJ0eU5hbWU6ZnVuY3Rpb24oKXtzd2l0Y2goTS50eXBlKXtjYXNlXCJpZGVudGlmaWVyXCI6Y2FzZVwic3RyaW5nXCI6cmV0dXJuIGs9TS52YWx1ZSx2b2lkKEk9XCJhZnRlclByb3BlcnR5TmFtZVwiKTtjYXNlXCJwdW5jdHVhdG9yXCI6cmV0dXJuIHZvaWQgZXUoKTtjYXNlXCJlb2ZcIjp0aHJvdyBydSgpfX0sYWZ0ZXJQcm9wZXJ0eU5hbWU6ZnVuY3Rpb24oKXtpZihcImVvZlwiPT09TS50eXBlKXRocm93IHJ1KCk7ST1cImJlZm9yZVByb3BlcnR5VmFsdWVcIn0sYmVmb3JlUHJvcGVydHlWYWx1ZTpmdW5jdGlvbigpe2lmKFwiZW9mXCI9PT1NLnR5cGUpdGhyb3cgcnUoKTtEdSgpfSxiZWZvcmVBcnJheVZhbHVlOmZ1bmN0aW9uKCl7aWYoXCJlb2ZcIj09PU0udHlwZSl0aHJvdyBydSgpO1wicHVuY3R1YXRvclwiIT09TS50eXBlfHxcIl1cIiE9PU0udmFsdWU/RHUoKTpldSgpfSxhZnRlclByb3BlcnR5VmFsdWU6ZnVuY3Rpb24oKXtpZihcImVvZlwiPT09TS50eXBlKXRocm93IHJ1KCk7c3dpdGNoKE0udmFsdWUpe2Nhc2VcIixcIjpyZXR1cm4gdm9pZChJPVwiYmVmb3JlUHJvcGVydHlOYW1lXCIpO2Nhc2VcIn1cIjpldSgpfX0sYWZ0ZXJBcnJheVZhbHVlOmZ1bmN0aW9uKCl7aWYoXCJlb2ZcIj09PU0udHlwZSl0aHJvdyBydSgpO3N3aXRjaChNLnZhbHVlKXtjYXNlXCIsXCI6cmV0dXJuIHZvaWQoST1cImJlZm9yZUFycmF5VmFsdWVcIik7Y2FzZVwiXVwiOmV1KCl9fSxlbmQ6ZnVuY3Rpb24oKXt9fTtmdW5jdGlvbiBEdSgpe3ZhciB1O3N3aXRjaChNLnR5cGUpe2Nhc2VcInB1bmN0dWF0b3JcIjpzd2l0Y2goTS52YWx1ZSl7Y2FzZVwie1wiOnU9e307YnJlYWs7Y2FzZVwiW1wiOnU9W119YnJlYWs7Y2FzZVwibnVsbFwiOmNhc2VcImJvb2xlYW5cIjpjYXNlXCJudW1lcmljXCI6Y2FzZVwic3RyaW5nXCI6dT1NLnZhbHVlfWlmKHZvaWQgMD09PUwpTD11O2Vsc2V7dmFyIEQ9T1tPLmxlbmd0aC0xXTtBcnJheS5pc0FycmF5KEQpP0QucHVzaCh1KTpEW2tdPXV9aWYobnVsbCE9PXUmJlwib2JqZWN0XCI9PXR5cGVvZiB1KU8ucHVzaCh1KSxJPUFycmF5LmlzQXJyYXkodSk/XCJiZWZvcmVBcnJheVZhbHVlXCI6XCJiZWZvcmVQcm9wZXJ0eU5hbWVcIjtlbHNle3ZhciBlPU9bTy5sZW5ndGgtMV07ST1udWxsPT1lP1wiZW5kXCI6QXJyYXkuaXNBcnJheShlKT9cImFmdGVyQXJyYXlWYWx1ZVwiOlwiYWZ0ZXJQcm9wZXJ0eVZhbHVlXCJ9fWZ1bmN0aW9uIGV1KCl7Ty5wb3AoKTt2YXIgdT1PW08ubGVuZ3RoLTFdO0k9bnVsbD09dT9cImVuZFwiOkFycmF5LmlzQXJyYXkodSk/XCJhZnRlckFycmF5VmFsdWVcIjpcImFmdGVyUHJvcGVydHlWYWx1ZVwifWZ1bmN0aW9uIHR1KHUpe3JldHVybiBDdSh2b2lkIDA9PT11P1wiSlNPTjU6IGludmFsaWQgZW5kIG9mIGlucHV0IGF0IFwiK1YrXCI6XCIrSjpcIkpTT041OiBpbnZhbGlkIGNoYXJhY3RlciAnXCIrbnUodSkrXCInIGF0IFwiK1YrXCI6XCIrSil9ZnVuY3Rpb24gcnUoKXtyZXR1cm4gQ3UoXCJKU09ONTogaW52YWxpZCBlbmQgb2YgaW5wdXQgYXQgXCIrVitcIjpcIitKKX1mdW5jdGlvbiBGdSgpe3JldHVybiBDdShcIkpTT041OiBpbnZhbGlkIGlkZW50aWZpZXIgY2hhcmFjdGVyIGF0IFwiK1YrXCI6XCIrKEotPTUpKX1mdW5jdGlvbiBudSh1KXt2YXIgRD17XCInXCI6XCJcXFxcJ1wiLCdcIic6J1xcXFxcIicsXCJcXFxcXCI6XCJcXFxcXFxcXFwiLFwiXFxiXCI6XCJcXFxcYlwiLFwiXFxmXCI6XCJcXFxcZlwiLFwiXFxuXCI6XCJcXFxcblwiLFwiXFxyXCI6XCJcXFxcclwiLFwiXFx0XCI6XCJcXFxcdFwiLFwiXFx2XCI6XCJcXFxcdlwiLFwiXFwwXCI6XCJcXFxcMFwiLFwiXFx1MjAyOFwiOlwiXFxcXHUyMDI4XCIsXCJcXHUyMDI5XCI6XCJcXFxcdTIwMjlcIn07aWYoRFt1XSlyZXR1cm4gRFt1XTtpZih1PFwiIFwiKXt2YXIgZT11LmNoYXJDb2RlQXQoMCkudG9TdHJpbmcoMTYpO3JldHVyblwiXFxcXHhcIisoXCIwMFwiK2UpLnN1YnN0cmluZyhlLmxlbmd0aCl9cmV0dXJuIHV9ZnVuY3Rpb24gQ3UodSl7dmFyIEQ9bmV3IFN5bnRheEVycm9yKHUpO3JldHVybiBELmxpbmVOdW1iZXI9VixELmNvbHVtbk51bWJlcj1KLER9cmV0dXJue3BhcnNlOmZ1bmN0aW9uKHUsRCl7Xz1TdHJpbmcodSksST1cInN0YXJ0XCIsTz1bXSxqPTAsVj0xLEo9MCxNPXZvaWQgMCxrPXZvaWQgMCxMPXZvaWQgMDtkb3tNPVooKSx1dVtJXSgpfXdoaWxlKFwiZW9mXCIhPT1NLnR5cGUpO3JldHVyblwiZnVuY3Rpb25cIj09dHlwZW9mIEQ/ZnVuY3Rpb24gdShELGUsdCl7dmFyIHI9RFtlXTtpZihudWxsIT1yJiZcIm9iamVjdFwiPT10eXBlb2Ygcilmb3IodmFyIEYgaW4gcil7dmFyIG49dShyLEYsdCk7dm9pZCAwPT09bj9kZWxldGUgcltGXTpyW0ZdPW59cmV0dXJuIHQuY2FsbChELGUscil9KHtcIlwiOkx9LFwiXCIsRCk6TH0sc3RyaW5naWZ5OmZ1bmN0aW9uKHUsRCxlKXt2YXIgdCxyLEYsbj1bXSxDPVwiXCIsQT1cIlwiO2lmKG51bGw9PUR8fFwib2JqZWN0XCIhPXR5cGVvZiBEfHxBcnJheS5pc0FycmF5KEQpfHwoZT1ELnNwYWNlLEY9RC5xdW90ZSxEPUQucmVwbGFjZXIpLFwiZnVuY3Rpb25cIj09dHlwZW9mIEQpcj1EO2Vsc2UgaWYoQXJyYXkuaXNBcnJheShEKSl7dD1bXTtmb3IodmFyIGk9MCxFPUQ7aTxFLmxlbmd0aDtpKz0xKXt2YXIgbz1FW2ldLGE9dm9pZCAwO1wic3RyaW5nXCI9PXR5cGVvZiBvP2E9bzooXCJudW1iZXJcIj09dHlwZW9mIG98fG8gaW5zdGFuY2VvZiBTdHJpbmd8fG8gaW5zdGFuY2VvZiBOdW1iZXIpJiYoYT1TdHJpbmcobykpLHZvaWQgMCE9PWEmJnQuaW5kZXhPZihhKTwwJiZ0LnB1c2goYSl9fXJldHVybiBlIGluc3RhbmNlb2YgTnVtYmVyP2U9TnVtYmVyKGUpOmUgaW5zdGFuY2VvZiBTdHJpbmcmJihlPVN0cmluZyhlKSksXCJudW1iZXJcIj09dHlwZW9mIGU/ZT4wJiYoZT1NYXRoLm1pbigxMCxNYXRoLmZsb29yKGUpKSxBPVwiICAgICAgICAgIFwiLnN1YnN0cigwLGUpKTpcInN0cmluZ1wiPT10eXBlb2YgZSYmKEE9ZS5zdWJzdHIoMCwxMCkpLGMoXCJcIix7XCJcIjp1fSk7ZnVuY3Rpb24gYyh1LEQpe3ZhciBlPURbdV07c3dpdGNoKG51bGwhPWUmJihcImZ1bmN0aW9uXCI9PXR5cGVvZiBlLnRvSlNPTjU/ZT1lLnRvSlNPTjUodSk6XCJmdW5jdGlvblwiPT10eXBlb2YgZS50b0pTT04mJihlPWUudG9KU09OKHUpKSksciYmKGU9ci5jYWxsKEQsdSxlKSksZSBpbnN0YW5jZW9mIE51bWJlcj9lPU51bWJlcihlKTplIGluc3RhbmNlb2YgU3RyaW5nP2U9U3RyaW5nKGUpOmUgaW5zdGFuY2VvZiBCb29sZWFuJiYoZT1lLnZhbHVlT2YoKSksZSl7Y2FzZSBudWxsOnJldHVyblwibnVsbFwiO2Nhc2UhMDpyZXR1cm5cInRydWVcIjtjYXNlITE6cmV0dXJuXCJmYWxzZVwifXJldHVyblwic3RyaW5nXCI9PXR5cGVvZiBlP0IoZSk6XCJudW1iZXJcIj09dHlwZW9mIGU/U3RyaW5nKGUpOlwib2JqZWN0XCI9PXR5cGVvZiBlP0FycmF5LmlzQXJyYXkoZSk/ZnVuY3Rpb24odSl7aWYobi5pbmRleE9mKHUpPj0wKXRocm93IFR5cGVFcnJvcihcIkNvbnZlcnRpbmcgY2lyY3VsYXIgc3RydWN0dXJlIHRvIEpTT041XCIpO24ucHVzaCh1KTt2YXIgRD1DO0MrPUE7Zm9yKHZhciBlLHQ9W10scj0wO3I8dS5sZW5ndGg7cisrKXt2YXIgRj1jKFN0cmluZyhyKSx1KTt0LnB1c2godm9pZCAwIT09Rj9GOlwibnVsbFwiKX1pZigwPT09dC5sZW5ndGgpZT1cIltdXCI7ZWxzZSBpZihcIlwiPT09QSl7dmFyIGk9dC5qb2luKFwiLFwiKTtlPVwiW1wiK2krXCJdXCJ9ZWxzZXt2YXIgRT1cIixcXG5cIitDLG89dC5qb2luKEUpO2U9XCJbXFxuXCIrQytvK1wiLFxcblwiK0QrXCJdXCJ9cmV0dXJuIG4ucG9wKCksQz1ELGV9KGUpOmZ1bmN0aW9uKHUpe2lmKG4uaW5kZXhPZih1KT49MCl0aHJvdyBUeXBlRXJyb3IoXCJDb252ZXJ0aW5nIGNpcmN1bGFyIHN0cnVjdHVyZSB0byBKU09ONVwiKTtuLnB1c2godSk7dmFyIEQ9QztDKz1BO2Zvcih2YXIgZSxyLEY9dHx8T2JqZWN0LmtleXModSksaT1bXSxFPTAsbz1GO0U8by5sZW5ndGg7RSs9MSl7dmFyIGE9b1tFXSxCPWMoYSx1KTtpZih2b2lkIDAhPT1CKXt2YXIgZj1zKGEpK1wiOlwiO1wiXCIhPT1BJiYoZis9XCIgXCIpLGYrPUIsaS5wdXNoKGYpfX1pZigwPT09aS5sZW5ndGgpZT1cInt9XCI7ZWxzZSBpZihcIlwiPT09QSlyPWkuam9pbihcIixcIiksZT1cIntcIityK1wifVwiO2Vsc2V7dmFyIGw9XCIsXFxuXCIrQztyPWkuam9pbihsKSxlPVwie1xcblwiK0MrcitcIixcXG5cIitEK1wifVwifXJldHVybiBuLnBvcCgpLEM9RCxlfShlKTp2b2lkIDB9ZnVuY3Rpb24gQih1KXtmb3IodmFyIEQ9e1wiJ1wiOi4xLCdcIic6LjJ9LGU9e1wiJ1wiOlwiXFxcXCdcIiwnXCInOidcXFxcXCInLFwiXFxcXFwiOlwiXFxcXFxcXFxcIixcIlxcYlwiOlwiXFxcXGJcIixcIlxcZlwiOlwiXFxcXGZcIixcIlxcblwiOlwiXFxcXG5cIixcIlxcclwiOlwiXFxcXHJcIixcIlxcdFwiOlwiXFxcXHRcIixcIlxcdlwiOlwiXFxcXHZcIixcIlxcMFwiOlwiXFxcXDBcIixcIlxcdTIwMjhcIjpcIlxcXFx1MjAyOFwiLFwiXFx1MjAyOVwiOlwiXFxcXHUyMDI5XCJ9LHQ9XCJcIixyPTA7cjx1Lmxlbmd0aDtyKyspe3ZhciBuPXVbcl07c3dpdGNoKG4pe2Nhc2VcIidcIjpjYXNlJ1wiJzpEW25dKyssdCs9bjtjb250aW51ZTtjYXNlXCJcXDBcIjppZihVLmlzRGlnaXQodVtyKzFdKSl7dCs9XCJcXFxceDAwXCI7Y29udGludWV9fWlmKGVbbl0pdCs9ZVtuXTtlbHNlIGlmKG48XCIgXCIpe3ZhciBDPW4uY2hhckNvZGVBdCgwKS50b1N0cmluZygxNik7dCs9XCJcXFxceFwiKyhcIjAwXCIrQykuc3Vic3RyaW5nKEMubGVuZ3RoKX1lbHNlIHQrPW59dmFyIEE9Rnx8T2JqZWN0LmtleXMoRCkucmVkdWNlKGZ1bmN0aW9uKHUsZSl7cmV0dXJuIERbdV08RFtlXT91OmV9KTtyZXR1cm4gQSsodD10LnJlcGxhY2UobmV3IFJlZ0V4cChBLFwiZ1wiKSxlW0FdKSkrQX1mdW5jdGlvbiBzKHUpe2lmKDA9PT11Lmxlbmd0aClyZXR1cm4gQih1KTt2YXIgRD1TdHJpbmcuZnJvbUNvZGVQb2ludCh1LmNvZGVQb2ludEF0KDApKTtpZighVS5pc0lkU3RhcnRDaGFyKEQpKXJldHVybiBCKHUpO2Zvcih2YXIgZT1ELmxlbmd0aDtlPHUubGVuZ3RoO2UrKylpZighVS5pc0lkQ29udGludWVDaGFyKFN0cmluZy5mcm9tQ29kZVBvaW50KHUuY29kZVBvaW50QXQoZSkpKSlyZXR1cm4gQih1KTtyZXR1cm4gdX19fX0pO1xuIiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHQvLyBubyBtb2R1bGUuaWQgbmVlZGVkXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbiIsIi8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSAobW9kdWxlKSA9PiB7XG5cdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuXHRcdCgpID0+IChtb2R1bGVbJ2RlZmF1bHQnXSkgOlxuXHRcdCgpID0+IChtb2R1bGUpO1xuXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCB7IGE6IGdldHRlciB9KTtcblx0cmV0dXJuIGdldHRlcjtcbn07IiwiLy8gZGVmaW5lIGdldHRlciBmdW5jdGlvbnMgZm9yIGhhcm1vbnkgZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5kID0gKGV4cG9ydHMsIGRlZmluaXRpb24pID0+IHtcblx0Zm9yKHZhciBrZXkgaW4gZGVmaW5pdGlvbikge1xuXHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhkZWZpbml0aW9uLCBrZXkpICYmICFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywga2V5KSkge1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIGtleSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGRlZmluaXRpb25ba2V5XSB9KTtcblx0XHR9XG5cdH1cbn07IiwiX193ZWJwYWNrX3JlcXVpcmVfXy5vID0gKG9iaiwgcHJvcCkgPT4gKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIHByb3ApKSIsIi8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uciA9IChleHBvcnRzKSA9PiB7XG5cdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuXHR9XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG59OyIsImltcG9ydCBkb20sIHsgRnJhZ21lbnQgfSBmcm9tICcuLi91dGlsL2pzeC1yZW5kZXItbW9kL2RvbSc7XHJcbmltcG9ydCByb3V0ZXIgZnJvbSAnLi4vdXRpbC9yb3V0ZXInO1xyXG5pbXBvcnQgeyBDb250YWluZXIgfSBmcm9tICcuLi91dGlsL3RlbXBsYXRlJztcclxuaW1wb3J0IEVtaXR0ZXIgZnJvbSAnLi4vY29tbW9uL0VtaXR0ZXInO1xyXG5pbXBvcnQgeyBjYXRhbG9nUGFnZSwgY3JlYXRlUGFnZSwgZWRpdFBhZ2UgfSBmcm9tICcuL2NhdGFsb2cnO1xyXG5cclxuXHJcbmRvY3VtZW50LnRpdGxlID0gJ1RlbXBsYXRlIEVkaXRvcic7XHJcblxyXG5jb25zdCBjb250YWluZXIgPSAoXHJcbiAgICA8Q29udGFpbmVyPlxyXG4gICAgICAgIDxoMSBpZD1cInRpdGxlSGVhZGluZ1wiPtCo0LDQsdC70L7QvdC4INC30LAg0L7Qv9C40YHQsNC90LjQtSDQvdCwINC40L3RgdGC0LDQvdGG0LjRjzwvaDE+XHJcbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiYm90dG9tLWJ1ZmZlclwiPlxyXG4gICAgICAgICAgICA8ZGl2IGlkPVwicGFnZUNvbnRlbnRcIj5cclxuXHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgIDwvQ29udGFpbmVyPlxyXG4pO1xyXG5cclxuZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnLmNvbnRlbnQnKVswXS5pbm5lckhUTUwgPSAnJztcclxuZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnLmNvbnRlbnQnKVswXS5hcHBlbmRDaGlsZChjb250YWluZXIpO1xyXG5cclxucm91dGVyLnJlZ2lzdGVyKFtcclxuICAgIHtcclxuICAgICAgICBtYXRjaDogbnVsbCxcclxuICAgICAgICBoYW5kbGVyOiBjYXRhbG9nUGFnZVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgICBtYXRjaDogJ25ldycsXHJcbiAgICAgICAgaGFuZGxlcjogY3JlYXRlUGFnZVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgICBtYXRjaDogJ2lkJyxcclxuICAgICAgICBoYW5kbGVyOiBlZGl0UGFnZVxyXG4gICAgfVxyXG5dLCBuZXcgRW1pdHRlcigpKTtcclxuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9