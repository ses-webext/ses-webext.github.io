/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/awesome-notifications/src/constants.js":
/*!*************************************************************!*\
  !*** ./node_modules/awesome-notifications/src/constants.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "eConsts": () => (/* binding */ eConsts),
/* harmony export */   "mConsts": () => (/* binding */ mConsts),
/* harmony export */   "tConsts": () => (/* binding */ tConsts)
/* harmony export */ });
const libName = "awn"
const prefix = {
  popup: `${libName}-popup`,
  toast: `${libName}-toast`,
  btn: `${libName}-btn`,
  confirm: `${libName}-confirm`
}

// Constants for toasts
const tConsts = {
  prefix: prefix.toast,
  klass: {
    label: `${prefix.toast}-label`,
    content: `${prefix.toast}-content`,
    icon: `${prefix.toast}-icon`,
    progressBar: `${prefix.toast}-progress-bar`,
    progressBarPause: `${prefix.toast}-progress-bar-paused`
  },
  ids: {
    container: `${prefix.toast}-container`
  }
}

// Constants for popups
const mConsts = {
  prefix: prefix.popup,
  klass: {
    buttons: `${libName}-buttons`,
    button: prefix.btn,
    successBtn: `${prefix.btn}-success`,
    cancelBtn: `${prefix.btn}-cancel`,
    title: `${prefix.popup}-title`,
    body: `${prefix.popup}-body`,
    content: `${prefix.popup}-content`,
    dotAnimation: `${prefix.popup}-loading-dots`
  },
  ids: {
    wrapper: `${prefix.popup}-wrapper`,
    confirmOk: `${prefix.confirm}-ok`,
    confirmCancel: `${prefix.confirm}-cancel`
  }
}

const eConsts = {
  klass: {
    hiding: `${libName}-hiding`
  },
  lib: libName
}


/***/ }),

/***/ "./node_modules/awesome-notifications/src/elem.js":
/*!********************************************************!*\
  !*** ./node_modules/awesome-notifications/src/elem.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./constants */ "./node_modules/awesome-notifications/src/constants.js");


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (class {
    constructor(parent, id, klass, style, options) {
        this.newNode = document.createElement('div')
        if (id) this.newNode.id = id
        if (klass) this.newNode.className = klass
        if (style) this.newNode.style.cssText = style
        this.parent = parent
        this.options = options
    }
    beforeInsert() {}
    afterInsert() {}
    insert() {
        this.beforeInsert()
        this.el = this.parent.appendChild(this.newNode)
        this.afterInsert()
        return this
    }

    replace(el) {
        if (!this.getElement()) return
        return this.beforeDelete().then(() => {
            this.updateType(el.type)
            this.parent.replaceChild(el.newNode, this.el)
            this.el = this.getElement(el.newNode)
            this.afterInsert()
            return this
        })
    }

    beforeDelete(el = this.el) {
        let timeLeft = 0
        if (this.start) {
            timeLeft = this.options.minDurations[this.type] + this.start - Date.now()
            if (timeLeft < 0) timeLeft = 0
        }

        return new Promise(resolve => {
            setTimeout(() => {
                el.classList.add(_constants__WEBPACK_IMPORTED_MODULE_0__.eConsts.klass.hiding)
                setTimeout(resolve, this.options.animationDuration)
            }, timeLeft)
        })
    }

    delete(el = this.el) {
        if (!this.getElement(el)) return null
        return this.beforeDelete(el).then(() => {
            el.remove()
            this.afterDelete()
        })
    }
    afterDelete() {}

    getElement(el = this.el) {
        if (!el) return null
        return document.getElementById(el.id)
    }

    addEvent(name, func) {
        this.el.addEventListener(name, func)
    }

    toggleClass(klass) {
        this.el.classList.toggle(klass)
    }
    updateType(type) {
        this.type = type
        this.duration = this.options.duration(this.type)
    }
});

/***/ }),

/***/ "./node_modules/awesome-notifications/src/index.js":
/*!*********************************************************!*\
  !*** ./node_modules/awesome-notifications/src/index.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Notifier)
/* harmony export */ });
/* harmony import */ var _options__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./options */ "./node_modules/awesome-notifications/src/options.js");
/* harmony import */ var _toast__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./toast */ "./node_modules/awesome-notifications/src/toast.js");
/* harmony import */ var _popup__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./popup */ "./node_modules/awesome-notifications/src/popup.js");
/* harmony import */ var _elem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./elem */ "./node_modules/awesome-notifications/src/elem.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./constants */ "./node_modules/awesome-notifications/src/constants.js");







class Notifier {
  constructor(options = {}) {
    this.options = new _options__WEBPACK_IMPORTED_MODULE_0__["default"](options)
  }

  tip(msg, options) {
    return this._addToast(msg, "tip", options).el
  }

  info(msg, options) {
    return this._addToast(msg, "info", options).el
  }

  success(msg, options) {
    return this._addToast(msg, "success", options).el
  }

  warning(msg, options) {
    return this._addToast(msg, "warning", options).el
  }

  alert(msg, options) {
    return this._addToast(msg, "alert", options).el
  }

  async (promise, onResolve, onReject, msg, options) {
    let asyncToast = this._addToast(msg, "async", options)
    return this._afterAsync(promise, onResolve, onReject, options, asyncToast)
  }

  confirm(msg, onOk, onCancel, options) {
    return this._addPopup(msg, "confirm", options, onOk, onCancel)
  }

  asyncBlock(promise, onResolve, onReject, msg, options) {
    let asyncBlock = this._addPopup(msg, "async-block", options)
    return this._afterAsync(promise, onResolve, onReject, options, asyncBlock)
  }

  modal(msg, className, options) {
    return this._addPopup(msg, className, options)
  }

  closeToasts() {
    let c = this.container
    while (c.firstChild) {
      c.removeChild(c.firstChild)
    }
  }

  // Tools
  _addPopup(msg, className, options, onOk, onCancel) {
    return new _popup__WEBPACK_IMPORTED_MODULE_2__["default"](msg, className, this.options.override(options), onOk, onCancel)
  }

  _addToast(msg, type, options, old) {
    options = this.options.override(options)
    let newToast = new _toast__WEBPACK_IMPORTED_MODULE_1__["default"](msg, type, options, this.container)
    if (old) {
      if (old instanceof _popup__WEBPACK_IMPORTED_MODULE_2__["default"]) return old.delete().then(() => newToast.insert())
      let i = old.replace(newToast)
      return i
    }
    return newToast.insert()
  }

  _afterAsync(promise, onResolve, onReject, options, oldElement) {
    return promise.then(
      this._responseHandler(onResolve, "success", options, oldElement),
      this._responseHandler(onReject, "alert", options, oldElement)
    )
  }

  _responseHandler(payload, toastName, options, oldElement) {
    return result => {
      switch (typeof payload) {
        case 'undefined':
        case 'string':
          let msg = toastName === 'alert' ? payload || result : payload
          this._addToast(msg, toastName, options, oldElement)
          break
        default:
          oldElement.delete().then(() => {
            if (payload) payload(result)
          })
      }
    }
  }

  _createContainer() {
    return new _elem__WEBPACK_IMPORTED_MODULE_3__["default"](document.body, _constants__WEBPACK_IMPORTED_MODULE_4__.tConsts.ids.container, `awn-${this.options.position}`).insert().el
  }

  get container() {
    return document.getElementById(_constants__WEBPACK_IMPORTED_MODULE_4__.tConsts.ids.container) || this._createContainer()
  }
}


/***/ }),

/***/ "./node_modules/awesome-notifications/src/options.js":
/*!***********************************************************!*\
  !*** ./node_modules/awesome-notifications/src/options.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Options)
/* harmony export */ });
const defaults = {
  maxNotifications: 10,
  animationDuration: 300,
  position: "bottom-right",
  labels: {
    tip: "Tip",
    info: "Info",
    success: "Success",
    warning: "Attention",
    alert: "Error",
    async: "Loading",
    confirm: "Confirmation required",
    confirmOk: "OK",
    confirmCancel: "Cancel"
  },
  icons: {
    tip: "question-circle",
    info: "info-circle",
    success: "check-circle",
    warning: "exclamation-circle",
    alert: "exclamation-triangle",
    async: "cog fa-spin",
    confirm: "exclamation-triangle",
    prefix: "<i class='fa fas fa-fw fa-",
    suffix: "'></i>",
    enabled: true
  },
  replacements: {
    tip: null,
    info: null,
    success: null,
    warning: null,
    alert: null,
    async: null,
    "async-block": null,
    modal: null,
    confirm: null,
    general: {
      "<script>": "",
      "</script>": ""
    }
  },
  messages: {
    tip: "",
    info: "",
    success: "Action has been succeeded",
    warning: "",
    alert: "Action has been failed",
    confirm: "This action can't be undone. Continue?",
    async: "Please, wait...",
    "async-block": "Loading"
  },
  formatError(err) {
    if (err.response) {
      if (!err.response.data) return '500 API Server Error'
      if (err.response.data.errors) {
        return err.response.data.errors.map(o => o.detail).join('<br>')
      }
      if (err.response.statusText) {
        return `${err.response.status} ${err.response.statusText}: ${err.response.data}`
      }
    }
    if (err.message) return err.message
    return err
  },
  durations: {
    global: 5000,
    success: null,
    info: null,
    tip: null,
    warning: null,
    alert: null
  },
  minDurations: {
    async: 1000,
    "async-block": 1000
  },
}
class Options {
  constructor(options = {}, global = defaults) {
    Object.assign(this, this.defaultsDeep(global, options))
  }

  icon(type) {
    if (this.icons.enabled) return `${this.icons.prefix}${this.icons[type]}${this.icons.suffix}`
    return ''
  }

  label(type) {
    return this.labels[type]
  }

  duration(type) {
    let duration = this.durations[type]
    return duration === null ? this.durations.global : duration
  }

  toSecs(value) {
    return `${value / 1000}s`
  }

  applyReplacements(str, type) {
    if (!str) return this.messages[type] || ""
    for (const n of ['general', type]) {
      if (!this.replacements[n]) continue
      for (const k in this.replacements[n]) {
        str = str.replace(k, this.replacements[n][k])
      }
    }
    return str
  }

  override(options) {
    if (options) return new Options(options, this)
    return this
  }

  defaultsDeep(defaults, overrides) {
    let result = {}
    for (const k in defaults) {
      if (overrides.hasOwnProperty(k)) {
        result[k] = typeof defaults[k] === "object" && defaults[k] !== null ? this.defaultsDeep(defaults[k], overrides[k]) : overrides[k]
      } else {
        result[k] = defaults[k]
      }
    }
    return result
  }
}


/***/ }),

/***/ "./node_modules/awesome-notifications/src/popup.js":
/*!*********************************************************!*\
  !*** ./node_modules/awesome-notifications/src/popup.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _elem__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./elem */ "./node_modules/awesome-notifications/src/elem.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./constants */ "./node_modules/awesome-notifications/src/constants.js");



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (class extends _elem__WEBPACK_IMPORTED_MODULE_0__["default"] {
  constructor(msg, type = 'modal', options, onOk, onCancel) {
    let animationDuration = `animation-duration: ${options.toSecs(options.animationDuration)};`
    super(document.body, _constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.wrapper, null, animationDuration, options)
    this[_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmOk] = onOk
    this[_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmCancel] = onCancel
    this.className = `${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.prefix}-${type}`
    if (!['confirm', 'async-block', 'modal'].includes(type)) type = 'modal'
    this.updateType(type)
    this.setInnerHtml(msg)
    this.insert()
  }

  setInnerHtml(html) {
    let innerHTML = this.options.applyReplacements(html, this.type)
    switch (this.type) {
      case "confirm":
        let buttons = [`<button class='${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.button} ${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.successBtn}'id='${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmOk}'>${this.options.labels.confirmOk}</button>`]
        if (this[_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmCancel] !== false) {
          buttons.push(`<button class='${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.button} ${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.cancelBtn}'id='${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmCancel}'>${this.options.labels.confirmCancel}</button>`)
        }
        innerHTML = `${this.options.icon(this.type)}<div class='${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.title}'>${this.options.label(this.type)}</div><div class="${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.content}">${innerHTML}</div><div class='${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.buttons} ${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.buttons}-${buttons.length}'>${buttons.join('')}</div>`
        break
      case "async-block":
        innerHTML = `${innerHTML}<div class="${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.dotAnimation}"></div>`
    }
    this.newNode.innerHTML = `<div class="${_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.klass.body} ${this.className}">${innerHTML}</div>`
  }

  keyupListener(e) {
    if (this.type === 'async-block') return e.preventDefault()
    switch (e.code) {
      case 'Escape':
        e.preventDefault()
        this.delete()
      case 'Tab':
        e.preventDefault()
        if (this.type !== 'confirm' || this[_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmCancel] === false) return true
        let next = this.okBtn
        if (e.shiftKey) {
          if (document.activeElement.id == _constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmOk) next = this.cancelBtn
        } else if (document.activeElement.id !== _constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmCancel) next = this.cancelBtn
        next.focus()
    }
  }
  afterInsert() {
    this.listener = e => this.keyupListener(e)
    window.addEventListener("keydown", this.listener)
    switch (this.type) {
      case 'async-block':
        this.start = Date.now()
        break
      case 'confirm':
        this.okBtn.focus()
        this.addEvent("click", e => {
          if (e.target.nodeName !== "BUTTON") return false
          this.delete()
          if (this[e.target.id]) this[e.target.id]()
        })
        break
      default:
        document.activeElement.blur()
        this.addEvent("click", e => {
          if (e.target.id === this.newNode.id) this.delete()
        })
    }
  }

  afterDelete() {
    window.removeEventListener("keydown", this.listener)
  }

  get okBtn() {
    return document.getElementById(_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmOk)
  }

  get cancelBtn() {
    return document.getElementById(_constants__WEBPACK_IMPORTED_MODULE_1__.mConsts.ids.confirmCancel)
  }
});


/***/ }),

/***/ "./node_modules/awesome-notifications/src/timer.js":
/*!*********************************************************!*\
  !*** ./node_modules/awesome-notifications/src/timer.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (class {
  constructor(callback, delay) {
    this.callback = callback
    this.remaining = delay
    this.resume()
  }
  pause() {
    this.paused = true
    window.clearTimeout(this.timerId)
    this.remaining -= new Date() - this.start
  }
  resume() {
    this.paused = false
    this.start = new Date()
    window.clearTimeout(this.timerId)
    this.timerId = window.setTimeout(() => {
      window.clearTimeout(this.timerId)
      this.callback()
    }, this.remaining)
  }
  toggle() {
    if (this.paused) this.resume()
    else this.pause()
  }
});


/***/ }),

/***/ "./node_modules/awesome-notifications/src/toast.js":
/*!*********************************************************!*\
  !*** ./node_modules/awesome-notifications/src/toast.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _elem__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./elem */ "./node_modules/awesome-notifications/src/elem.js");
/* harmony import */ var _timer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./timer */ "./node_modules/awesome-notifications/src/timer.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./constants */ "./node_modules/awesome-notifications/src/constants.js");





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (class extends _elem__WEBPACK_IMPORTED_MODULE_0__["default"] {
  constructor(msg, type, options, parent) {
    super(
      parent,
      `${_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.prefix}-${Math.floor(Date.now() - Math.random() * 100)}`,
      `${_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.prefix} ${_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.prefix}-${type}`,
      `animation-duration: ${options.toSecs(options.animationDuration)};`,
      options
    )
    this.updateType(type)
    this.setInnerHtml(msg)
  }

  setInnerHtml(html) {
    if (this.type === 'alert' && html) html = this.options.formatError(html)
    html = this.options.applyReplacements(html, this.type)
    this.newNode.innerHTML = `<div class="awn-toast-wrapper">${this.progressBar}${this.label}<div class="${_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.klass.content}">${html}</div><span class="${_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.klass.icon}">${this.options.icon(this.type)}</span></div>`
  }

  beforeInsert() {
    if (this.parent.childElementCount >= this.options.maxNotifications) {
      let elements = Array.from(this.parent.getElementsByClassName(_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.prefix))
      this.delete(elements.find(e => !this.isDeleted(e)))
    }
  }
  afterInsert() {
    if (this.type == "async") return this.start = Date.now()

    this.addEvent("click", () => this.delete())

    if (this.duration <= 0) return
    this.timer = new _timer__WEBPACK_IMPORTED_MODULE_1__["default"](() => this.delete(), this.duration)
    for (const e of ["mouseenter", "mouseleave"]) {
      this.addEvent(e, () => {
        if (this.isDeleted()) return
        this.toggleClass(_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.klass.progressBarPause)
        this.timer.toggle()
      })
    }
  }

  isDeleted(el = this.el) {
    return el.classList.contains(_constants__WEBPACK_IMPORTED_MODULE_2__.eConsts.klass.hiding)
  }
  get progressBar() {
    if (this.duration <= 0 || this.type === 'async') return ""
    return `<div class='${_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.klass.progressBar}' style="animation-duration:${this.options.toSecs(this.duration)};"></div>`
  }
  get label() {
    return `<b class="${_constants__WEBPACK_IMPORTED_MODULE_2__.tConsts.klass.label}">${this.options.label(this.type)}</b>`
  }

});


/***/ }),

/***/ "./src/api/api-index.js":
/*!******************************!*\
  !*** ./src/api/api-index.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ bindSiteApi)
/* harmony export */ });
/* harmony import */ var _trainings_trainings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./trainings/trainings */ "./src/api/trainings/trainings.js");
/* harmony import */ var _module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./module */ "./src/api/module.js");
/* harmony import */ var _payments__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./payments */ "./src/api/payments.js");
/* harmony import */ var _survey__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./survey */ "./src/api/survey.js");
/* harmony import */ var _common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./common */ "./src/api/common.js");
/* harmony import */ var _quiz__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./quiz */ "./src/api/quiz.js");
/* harmony import */ var _users__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./users */ "./src/api/users.js");
/* harmony import */ var _stream_stream__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./stream/stream */ "./src/api/stream/stream.js");
/* harmony import */ var _cpe_cpe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./cpe/cpe */ "./src/api/cpe/cpe.js");
/* harmony import */ var _storage_generic__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./storage/generic */ "./src/api/storage/generic.js");
/* harmony import */ var _storage_templates__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./storage/templates */ "./src/api/storage/templates.js");
/* harmony import */ var _storage_assessmentConfig__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./storage/assessmentConfig */ "./src/api/storage/assessmentConfig.js");
/* harmony import */ var _storage_paymentStats__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./storage/paymentStats */ "./src/api/storage/paymentStats.js");
/* harmony import */ var _storage_modulesData_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./storage/modulesData.js */ "./src/api/storage/modulesData.js");
/* harmony import */ var _judge_alphaJudge_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./judge/alphaJudge.js */ "./src/api/judge/alphaJudge.js");
/* harmony import */ var _util_contentTypes_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../util/contentTypes.js */ "./src/util/contentTypes.js");
















function bindSiteApi(appName) {
  const env = {
    interopHost,
    interopAppId,
    params,
    post,
    get,
    interopPlatformHost,
    interopAdminAlphaJudgeHost
  };
  const actions = { ...(0,_trainings_trainings__WEBPACK_IMPORTED_MODULE_0__["default"])(env),
    ...(0,_module__WEBPACK_IMPORTED_MODULE_1__["default"])(env),
    ...(0,_payments__WEBPACK_IMPORTED_MODULE_2__["default"])(env),
    ...(0,_survey__WEBPACK_IMPORTED_MODULE_3__["default"])(env),
    ...(0,_common__WEBPACK_IMPORTED_MODULE_4__["default"])(env),
    ...(0,_quiz__WEBPACK_IMPORTED_MODULE_5__["default"])(env),
    ...(0,_users__WEBPACK_IMPORTED_MODULE_6__["default"])(env),
    ...(0,_stream_stream__WEBPACK_IMPORTED_MODULE_7__["default"])(env),
    ...(0,_cpe_cpe__WEBPACK_IMPORTED_MODULE_8__["default"])(env),
    ...(0,_storage_generic__WEBPACK_IMPORTED_MODULE_9__["default"])(env),
    ...(0,_storage_templates__WEBPACK_IMPORTED_MODULE_10__["default"])(env),
    ...(0,_storage_assessmentConfig__WEBPACK_IMPORTED_MODULE_11__["default"])(env),
    ...(0,_storage_paymentStats__WEBPACK_IMPORTED_MODULE_12__["default"])(env),
    ...(0,_storage_modulesData_js__WEBPACK_IMPORTED_MODULE_13__["default"])(env),
    ...(0,_judge_alphaJudge_js__WEBPACK_IMPORTED_MODULE_14__["default"])(env)
  };

  if (appName === null) {
    return Object.keys(actions);
  } else {
    return actions;
  }

  function interopHost(endpoint) {
    switch (appName) {
      case 'digital':
        return 'https://digital.softuni.bg/' + endpoint;

      case 'creative':
        return 'https://creative.softuni.bg/' + endpoint;

      case 'ai':
        return 'https://ai.softuni.bg/' + endpoint;

      case 'financeacademy':
        return 'https://financeacademy.bg/' + endpoint;

      case 'devdigital':
        return 'https://dev.digital.softuni.bg/' + endpoint;

      case 'devsoftuni':
        return 'https://dev.softuni.bg/' + endpoint;

      default:
        return 'https://softuni.bg/' + endpoint;
    }
  }

  function interopAppId() {
    switch (appName) {
      case 'digital':
        return 'digital.softuni.bg';

      case 'creative':
        return 'creative.softuni.bg';

      case 'ai':
        return 'ai.softuni.bg';

      case 'financeacademy':
        return 'financeacademy.bg';

      case 'devdigital':
        return 'digital.softuni.bg';

      case 'devsoftuni':
        return 'softuni.bg';

      default:
        return 'softuni.bg';
    }
  }

  function interopPlatformHost() {
    switch (appName) {
      case 'digital':
        return 'https://platform.softuni.bg';

      case 'creative':
        return 'https://platform.softuni.bg';

      case 'ai':
        return 'https://platform.softuni.bg';

      case 'financeacademy':
        return 'https://platform.financeacademy.bg';

      case 'devdigital':
        return 'https://dev.platform.softuni.bg';

      case 'devsoftuni':
        return 'https://dev.platform.softuni.bg';

      default:
        return 'https://platform.softuni.bg';
    }
  }

  function interopAdminAlphaJudgeHost() {
    switch (appName) {
      case 'devsoftuni':
        return "https://admin.dev.alpha.judge.softuni.org";

      default:
        return "https://admin.alpha.judge.softuni.org";
    }
  }
}
let hosts = ['https://digital.softuni.bg/', 'https://creative.softuni.bg/', 'https://ai.softuni.bg/', 'https://financeacademy.bg/', 'https://dev.digital.softuni.bg/', 'https://dev.softuni.bg/', 'https://softuni.bg/'];
let platformHosts = ['https://platform.financeacademy.bg', 'https://dev.platform.softuni.bg', 'https://platform.softuni.bg'];
let judgeHosts = ["https://admin.alpha.judge.softuni.org", "https://dev.admin.alpha.judge.softuni.org", "https://alpha.judge.softuni.org", "https://dev.alpha.judge.softuni.org"];

function params(params = {}) {
  return Object.assign({
    sort: '',
    page: 1,
    pageSize: 10,
    group: '',
    filter: ''
  }, params);
}

async function post(url, params, contentType = _util_contentTypes_js__WEBPACK_IMPORTED_MODULE_15__.ContentType.UrlFormEncoded, asBlob = false) {
  let body = new URLSearchParams();

  if (contentType === _util_contentTypes_js__WEBPACK_IMPORTED_MODULE_15__.ContentType.ApplicationJson) {
    body = JSON.stringify(params);
  } else {
    for (let key of Object.keys(params)) {
      body.append(key, params[key]);
    }
  }

  const req = {
    method: 'POST',
    headers: {
      'Content-Type': contentType
    },
    body
  };

  try {
    const response = await fetch(url, req);

    if (response.status !== 200) {
      console.warn('Unsuccessful request');
      console.warn(params);
      console.warn(response);
      let error = new Error(`${response.status}: ${response.statusText} at ${response.url}`);
      error._status = response.status;
      throw error;
    }

    if (response.redirected || response.status == 302) {
      let urlDomain = hosts.find(x => url.startsWith(x));
      let platformDomain = platformHosts.find(x => url.startsWith(x));
      let judgeDomain = judgeHosts.find(x => url.startsWith(x));

      if (!urlDomain) {
        urlDomain = platformDomain;
      }

      if (!urlDomain) {
        urlDomain = judgeDomain;
      }

      console.error(`Request error fetching from ${url}, you're probably not logged in '${urlDomain}'.`);
      const error = new Error(`Request error, you're probably not logged in <a href="${urlDomain}" target="_blank">${urlDomain}</a>. Please login to <a href="${urlDomain}" target="_blank">${urlDomain}</a> and try again.`);
      error._url = url;
      throw error;
    }

    if (asBlob) {
      let filename = response.headers.get('Content-Disposition').split('filename=')[1].split(';')[0].replaceAll('\"', '');
      let blob = await response.blob();
      blob.filename = filename;
      return blob;
    }

    try {
      let result = await response.json();

      if (result.Errors) {
        let errorsParsed = JSON.stringify(result.Errors, undefined, 2);
        throw new Error(errorsParsed);
      }

      return result;
    } catch (e) {
      if (e instanceof SyntaxError) {
        return response;
      } else {
        throw e;
      }
    }
  } catch (e) {
    console.error(e);
    throw e;
  }
}

async function get(url, asBlob) {
  const req = {
    method: 'GET'
  };

  try {
    let response = await fetch(url, req);

    if (response.status !== 200) {
      console.warn('Unsuccessful request');
      console.warn(params);
      console.warn(response);
      throw new Error(`${response.statusText} at ${response.url}`);
    }

    if (response.redirected) {
      if (url.includes('platform')) {
        let platformDomain = platformHosts.find(x => url.startsWith(x));
        console.error(`Request error fetching from ${url}, you're probably not logged in to the platform.`);
        const error = new Error(`Request error, you're probably not logged in <a href="${platformDomain}" target="_blank">${platformDomain}</a>. Please login to <a href="${platformDomain}" target="_blank">${platformDomain}</a> and try again.`);
        error._url = url;
        throw error;
      } else {
        response = await fetch(response.url, req);
      }
    }

    if (asBlob) {
      return response.blob();
    }

    const reader = response.body.getReader();
    const utf8Decoder = new TextDecoder('utf-8');
    let result = '';

    while (true) {
      const {
        done,
        value
      } = await reader.read();

      if (done) {
        break;
      }

      result += utf8Decoder.decode(value);
    }

    try {
      return JSON.parse(result);
    } catch (e) {
      return result;
    }
  } catch (e) {
    console.error(e);
    throw e;
  }
}

/***/ }),

/***/ "./src/api/common.js":
/*!***************************!*\
  !*** ./src/api/common.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getBlogByUrl(blogUrl) {
    const uri = interopHost('administration_cms/news/read');
    const body = params({
      filter: `Url~eq~'${blogUrl}'`
    });
    return (await post(uri, body)).Data[0];
  }

  async function getHalls() {
    const dir = interopAppId() == 'softuni.bg' ? 'administration_university' : 'Administration';
    const uri = interopHost(dir + '/traininglabs/read');
    const body = params({
      pageSize: 1000
    });
    return post(uri, body);
  }

  async function getSoftwareUniversityHalls() {
    const uri = 'https://softuni.bg/administration_university/traininglabs/read';
    const body = params({
      pageSize: 1000
    });
    return post(uri, body);
  }

  function getHallBody(hall) {
    let currentDate = new Date(); // simplest way to convert date to ISO format in local Timezone as SULS requires

    currentDate.setMinutes(currentDate.getMinutes() - currentDate.getTimezoneOffset());
    let modifiedOnDate = currentDate.toISOString().slice(0, -1);
    const body = {
      sort: '',
      group: '',
      filter: '',
      Id: hall.Id,
      NameBg: hall.NameBg,
      NameEn: hall.NameEn,
      Address: hall.Address,
      Capacity: hall.Capacity,
      Description: hall.Description,
      DisableSecureLink: hall.DisableSecureLink,
      Floor: hall.Floor,
      GoogleCalendarId: hall.GoogleCalendarId,
      IsActive: hall.IsActive,
      IsFeatured: hall.IsFeatured,
      IsPhysical: hall.IsPhysical,
      ShowOnSchedule: hall.ShowOnSchedule,
      BranchId: hall.BranchId,
      SeatsConfiguration: hall.SeatsConfiguration,
      StreamingType: hall.StreamingType,
      YouTubeCode: hall.YouTubeCode,
      SoftUniStreamCode: hall.SoftUniStreamCode,
      StreamingServerBaseId: hall.StreamingServerBaseId,
      UcdnStreamingCode: hall.UcdnStreamingCode,
      CreatedOn: hall.CreatedOn,
      ModifiedOn: hall.ModifiedOn || modifiedOnDate
    };
    return body;
  }

  async function updateHall(hall) {
    let uri;

    if (interopAppId() === 'softuni.bg') {
      uri = interopHost('administration_university/traininglabs/update');
    } else {
      uri = interopHost('Administration/TrainingLabs/Update');
    }

    const body = getHallBody(hall);

    if (interopAppId() !== 'softuni.bg') {
      delete body.BranchId;
      delete body.SeatsConfiguration;
    }

    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function updateSoftwareUniversityHall(hall) {
    let uri = 'https://softuni.bg/administration_university/traininglabs/update';
    const body = getHallBody(hall);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  return {
    getBlogByUrl,
    getHalls,
    updateHall,
    getSoftwareUniversityHalls,
    updateSoftwareUniversityHall
  };
}

/***/ }),

/***/ "./src/api/cpe/cpe.js":
/*!****************************!*\
  !*** ./src/api/cpe/cpe.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _navet__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./navet */ "./src/api/cpe/navet.js");

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get,
  interopPlatformHost
}) {
  const navetApi = (0,_navet__WEBPACK_IMPORTED_MODULE_0__["default"])();

  async function getApplicationsByInstanceId(instanceId) {
    const uri = `${interopPlatformHost()}/administration/cpecertificateapplications/read?appId=${interopAppId()}`;
    const body = params({
      sort: 'CreatedOn-desc-asc',
      pageSize: 1000,
      filter: `TrainingId~eq~${instanceId}`
    });
    return (await post(uri, body)).Data;
  }

  async function getApplications(query, page) {
    const uri = `${interopPlatformHost()}/administration/cpecertificateapplications/read?appId=${interopAppId()}`;
    const filterTokens = [];

    if (query.instanceId) {
      filterTokens.push(`(TrainingId~eq~${query.instanceId})`);
    }

    if (query.instanceName) {
      filterTokens.push(`(TrainingName~contains~'${tokenize(query.instanceName).join('\'~and~TrainingName~contains~\'')}')`);
    }

    if (query.names) {
      const nameTokens = tokenize(query.names);
      let nameFilter = '';

      if (nameTokens.length == 1) {
        nameFilter = `(FirstName~contains~'${nameTokens[0]}'~or~MiddleName~contains~'${nameTokens[0]}'~or~LastName~contains~'${nameTokens[0]}')`;
      } else if (nameTokens.length == 2) {
        nameFilter = `(FirstName~contains~'${nameTokens[0]}'~and~(MiddleName~contains~'${nameTokens[1]}'~or~LastName~contains~'${nameTokens[1]}'))`;
      } else if (nameTokens.length == 3) {
        nameFilter = `(FirstName~contains~'${nameTokens[0]}'~and~MiddleName~contains~'${nameTokens[1]}'~and~LastName~contains~'${nameTokens[2]}')`;
      }

      filterTokens.push(nameFilter);
    }

    if (query.SSN) {
      filterTokens.push(`SSN~contains~'${query.SSN}'`);
    }

    const body = params({
      sort: 'CreatedOn-desc',
      pageSize: page ? 25 : 2000,
      page: page ? page : 1,
      filter: filterTokens.join('~and~')
    });
    return post(uri, body);
  }

  async function getAppZip(id) {
    const res = await fetch(`${interopPlatformHost()}/administration/cpecertificateapplications/getfileszip?id=${id}`);
    const blob = await res.blob();
    const serializedBlob = new Uint8Array(await blob.arrayBuffer());
    const blobData = {
      type: blob.type,
      buffer: Array.from(serializedBlob)
    };
    return blobData;
  } // ### External storage of application data (uses lectures inside a fixed course instance)


  const storeId = {
    'softuni.bg': 3124,
    'digital.softuni.bg': 2336,
    'creative.softuni.bg': 1193,
    'ai.softuni.bg': 8,
    'financeacademy.bg': 228
  };
  const statusModel = {
    sort: '',
    group: '',
    filter: '',
    Id: '',
    TrainingId: '',
    NameBg: '',
    NameEn: '',
    HasManualNumberOfStudyHours: '',
    NumberOfStudyHours: '',
    IsExcludedFromCertificate: '',
    HasHomework: '',
    ResourceMailsState: '',
    HomeworkMailsState: '',
    JudgeContestId: '',
    OrderBy: '',
    DescriptionBg: '',
    DescriptionEn: '',
    ExcludeFromCalendar: '',
    HasLiveStream: '',
    CreatedOn: '',
    ModifiedOn: ''
  };

  async function getAppStatus(id) {
    const uri = interopHost(`administration_trainings/lectures/read?foreignKeyId=${storeId[interopAppId()]}`);
    let filter = '';

    if (Array.isArray(id)) {
      filter = `NameEn~eq~'${id.join('\'~or~NameEn~eq~\'')}'`;
    } else {
      filter = `NameEn~eq~'${id}'`;
    }

    const body = params({
      pageSize: 1000,
      filter
    });
    return (await post(uri, body)).Data;
  }

  async function getAppStatusByInstanceId(id) {
    const uri = interopHost(`administration_trainings/lectures/read?foreignKeyId=${storeId[interopAppId()]}`);
    const body = params({
      pageSize: 1000,
      filter: `NameBg~eq~'${id}'`
    });
    return (await post(uri, body)).Data;
  }

  async function createStatus(status) {
    const uri = interopHost(`administration_trainings/lectures/create?foreignKeyId=${storeId[interopAppId()]}`);
    const body = Object.assign(params({}), statusModel);

    for (let field in body) {
      body[field] = status[field] === undefined ? body[field] : status[field];
    }

    body.TrainingId = storeId[interopAppId()];
    let startDate = new Date();
    let endDate = new Date(startDate);
    endDate.setUTCDate(endDate.getUTCDate() + 1);
    body[`DatesInfo[0].Start`] = startDate.toISOString();
    body[`DatesInfo[0].End`] = endDate.toISOString();
    body[`DatesInfo[0].ExtraInformation`] = '';
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return (await post(uri, body)).Data;
  }

  async function updateStatus(status) {
    const uri = interopHost(`administration_trainings/lectures/update?foreignKeyId=${storeId[interopAppId()]}`);
    const body = Object.assign(params({}), statusModel);

    for (let field in body) {
      body[field] = status[field] === undefined ? body[field] : status[field];
    }

    body.TrainingId = storeId[interopAppId()];
    let startDate = new Date();
    let endDate = new Date(startDate);
    endDate.setUTCDate(endDate.getUTCDate() + 1);
    body[`DatesInfo[0].Start`] = startDate.toISOString();
    body[`DatesInfo[0].End`] = endDate.toISOString();
    body[`DatesInfo[0].ExtraInformation`] = '';
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return (await post(uri, body)).Data;
  }

  async function destroyStatus(status) {
    const uri = interopHost(`administration_trainings/lectures/destroy?foreignKeyId=${storeId[interopAppId()]}`);
    const body = params({
      sort: '',
      group: '',
      filter: ''
    });
    Object.assign(body, status);
    body.TrainingId = storeId[interopAppId()];
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  return { ...navetApi,
    getApplicationsByInstanceId,
    getApplications,
    getAppZip,
    getAppStatus,
    getAppStatusByInstanceId,
    createStatus,
    updateStatus,
    destroyStatus
  };
}

function tokenize(asString) {
  return asString.split(' ').map(t => t.trim()).filter(t => t.length > 0);
}

/***/ }),

/***/ "./src/api/cpe/navet.js":
/*!******************************!*\
  !*** ./src/api/cpe/navet.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_json5_dist_index_min__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/json5/dist/index.min */ "./node_modules/json5/dist/index.min.js");
/* harmony import */ var _node_modules_json5_dist_index_min__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_json5_dist_index_min__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__() {
  const host = 'https://is.navet.government.bg/furia/Projects/napoo/index.new.php';

  async function get(url) {
    const res = await fetch(url);
    const text = await res.text();
    return text;
  }

  async function postForm(url, body) {
    Object.assign(body, {
      application: 'AJAXDataProvider',
      noCache: Date.now()
    });
    const query = [];

    for (let param in body) {
      query.push(`${param}=${encodeURIComponent(body[param])}`);
    }

    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-type': 'application/x-www-form-urlencoded; charset=utf-8'
      },
      body: query.join('&')
    });
    return res.text();
  }

  function parseResponse(data) {
    let json;
    json = _node_modules_json5_dist_index_min__WEBPACK_IMPORTED_MODULE_0___default().parse(data);

    if (json.hasOwnProperty('obj')) {
      return parseObject(json.obj);
    } else if (json.hasOwnProperty('objs')) {
      return json.objs.map(parseObject);
    } else if (json.hasOwnProperty('data') || json.status != 0) {
      return json;
    } else {
      console.error(json);

      if (json.status == 0) {
        console.error('Your session has expired. Please enter your credentials again.');
        throw new Error('Your session has expired. Please enter your credentials again.');
      } else {
        throw new TypeError('Unable to parse data: no keys [obj] or [objs] found. See console for details.');
      }
    }

    function parseObject(obj) {
      const parsed = {};

      for (let prop in obj) {
        parsed[prop] = obj[prop].value;
      }

      return parsed;
    }
  }

  async function getExtraCourseInfo(id) {
    const body = {
      invoke: `TbCourseGroupsManager.getByCourseGroupId(${id})`
    };
    return parseResponse(await postForm(host, body));
  }

  async function getNavetCurrentCourses() {
    const body = {
      invoke: 'ViewCourseGroupListManager.customGetByProviderIdAndCourseStatusId(2929,2)'
    };
    return parseResponse(await postForm(host, body));
  }

  async function getNavetClosedCourses() {
    const body = {
      invoke: 'ViewFinishedCourseGroupListManager.customGetByProviderIdAndCourseStatusIdNotArchived(2929)'
    };
    return parseResponse(await postForm(host, body));
  }

  async function getNavetArchivedCourses() {
    const body = {
      invoke: 'ViewFinishedCourseGroupListManager.customGetByProviderIdAndCourseStatusIdArchived(2929)'
    };
    return parseResponse(await postForm(host, body));
  }

  async function getNavetCourseInfo(id, type = 'current') {
    let extraInfo = getExtraCourseInfo(id);
    let courseList = [];

    switch (type) {
      case 'current':
        courseList = getNavetCurrentCourses();
        break;

      case 'concluded':
        courseList = getNavetClosedCourses();
        break;

      case 'archive':
        courseList = getNavetArchivedCourses();
        break;
    }

    [extraInfo, courseList] = await Promise.all([extraInfo, courseList]);
    const selected = courseList.find(c => c.id == id);
    selected._extra = extraInfo[0];
    return selected;
  }
  /* Replaced, because it doesn't provide the necessary information */

  /*
  async function getNavetCourseInfo(id) {
      const body = {
          invoke: `ViewCourseInfoManager.getById(${id})`
      };
      return parseResponse(await postForm(host, body));
  }
  */


  async function getNavetStudents(id) {
    const body = {
      invoke: `ViewClientCoursesManager.getByCourseGroupId(${id})`
    };
    return parseResponse(await postForm(host, body));
  }

  async function getNavetStudentInfo(clientId) {
    const body = {
      invoke: `TbClientsManager.getById(${clientId})`,
      id: clientId
    };
    return parseResponse(await postForm(host, body));
  }

  async function getNavetExistingFiles(courseId, id) {
    const body = {
      invoke: `TbClientsRequiredDocumentsManager.customGetValidByCourseGroupAndClient(${courseId},${id})`
    };
    return parseResponse(await postForm(host, body));
  }

  async function uploadFile(formData) {
    const result = await fetch(host, {
      method: 'POST',
      body: formData
    });
    const output = await result.text();

    if (output.search(/status:\s0/) != -1) {
      throw new Error('Your session has expired. Please enter your credentials again.');
    } else {
      return output;
    }
  }

  async function uploadMedical(courseId, id, fileDescriptor) {
    let blob;
    let filename;

    if (fileDescriptor.fileUrl !== undefined) {
      blob = await (await fetch(fileDescriptor.fileUrl)).blob();
      filename = fileDescriptor.name;
    } else {
      blob = fileDescriptor.file;
      filename = fileDescriptor.file.name;
    }

    const formData = new FormData();
    formData.append('id', null);
    formData.append('int_course_group_id', courseId);
    formData.append('is_valid', true);
    formData.append('oid_file_action', 'upload');
    formData.append('oid_file', blob, filename);
    formData.append('invoke', 'TbClientsRequiredDocumentsManager.createObject()');
    formData.append('application', 'AJAXDataProvider');
    formData.append('protocol', 'dataIFrame');
    formData.append('null', '');
    formData.append('int_code_course_group_required_documents_type_id', 1);
    formData.append('int_client_id', id);
    formData.append('vc_desciption', 'медицинско (auto)');
    formData.append('dt_document_date', '');
    formData.append('vc_document_reg_no', '');
    formData.append('vc_document_prn_no', '');
    formData.append('dt_document_official_date', '');
    formData.append('bool_before_date', false);
    formData.append('int_code_ext_register_id', null);
    formData.append('title', '<div class=\'napoo-title-dark\'>Медицинско свидетелство:</div>');
    formData.append('async_iframe_id', 'async_iframe_3152');
    return uploadFile(formData);
  }

  async function uploadDiploma(courseId, id, fileDescriptor, reg_no, prn_no, doc_date) {
    let blob;
    let filename;

    if (fileDescriptor.fileUrl !== undefined) {
      blob = await (await fetch(fileDescriptor.fileUrl)).blob();
      filename = fileDescriptor.name;
    } else {
      blob = fileDescriptor.file;
      filename = fileDescriptor.file.name;
    }

    const formData = new FormData();
    formData.append('id', null);
    formData.append('int_course_group_id', courseId);
    formData.append('is_valid', true);
    formData.append('int_code_education_id', 31);
    formData.append('341-text', 'завършено средно образование (или по-високо)');
    formData.append('vc_document_reg_no', reg_no);
    formData.append('vc_document_prn_no', prn_no);
    formData.append('oid_file_action', 'upload');
    formData.append('oid_file', blob, filename);
    formData.append('invoke', 'TbClientsRequiredDocumentsManager.createObject()');
    formData.append('application', 'AJAXDataProvider');
    formData.append('protocol', 'dataIFrame');
    formData.append('null', '');
    formData.append('int_client_id', id);
    formData.append('vc_desciption', 'диплома (auto)');
    formData.append('dt_document_date', '');
    formData.append('dt_document_official_date', doc_date);
    formData.append('bool_before_date', false);
    formData.append('int_code_ext_register_id', null);
    formData.append('title', '<div class=\'napoo-title-dark\'>Входящо минимално образователно равнище:</div>');
    formData.append('respInfo', '');
    formData.append('extraInfo', '');
    formData.append('check-in-edu-button', 'Провери в регистрите');
    formData.append('async_iframe_id', 'async_iframe_374');
    return uploadFile(formData);
  }

  async function openNavetFile(id) {
    const url = `${host}?application=AJAXDataProvider&invoke=TbClientsRequiredDocumentsManager.customDownloadFile(${id},"oid_file")`;
    const res = await fetch(url);
    const blob = await res.blob();
    const serializedBlob = new Uint8Array(await blob.arrayBuffer());
    let blobData = {
      type: blob.type,
      buffer: Array.from(serializedBlob)
    };
    return blobData;
  }

  async function deleteNavetFile(id) {
    const body = {
      invoke: `TbClientsRequiredDocumentsManager.customSetToFalse(${id})`
    };
    return parseResponse(await postForm(host, body));
  }
  /* Experimental */


  async function navetLogin(username, password) {
    const body = {
      response: 'client',
      request: 'login',
      username,
      password
    };
    const header = encodeURIComponent(JSON.stringify(body));
    const url = '/response';
    let request = new XMLHttpRequest();

    request.onreadystatechange = () => {
      if (request.readyState == 4 && (request.status == 200 || window.location.href.indexOf('http') == -1)) {
        let udat = JSON.parse(request.responseText);

        if (udat.status == 1) {
          window.location.href = '/';
        } else {
          throw new Error('Error: ' + udat.error_code);
        }

        request = null;
      }
    };

    const cache = '?' + new Date().getTime();
    request.open('GET', url + cache, true);
    request.setRequestHeader('ACCSSCTRL', header);
    request.send(null);
  }

  async function getGraduateInfo(id) {
    const body = {
      invoke: `RefClientsCoursesManager.getById(${id})`
    };
    return parseResponse(await postForm(host, body));
  }

  async function getNavetCertificate(id) {
    const body = {
      invoke: `ViewClientsCoursesDocumentsManager.getByClientCoursesId(${id})`
    };
    return parseResponse(await postForm(host, body));
  }

  async function openNavetCertificate(id, page) {
    const url = `${host}?application=AJAXDataProvider&invoke=TbClientsCoursesDocumentsManager.customDownloadFile(${id}, "document_${page}_file")`;
    const res = await fetch(url);
    const blob = await res.blob();

    if (blob.type == 'text/javascript') {
      console.error('Your session has expired. Please enter your credentials again.');
      throw new Error('Your session has expired. Please enter your credentials again.');
    }

    const serializedBlob = new Uint8Array(await blob.arrayBuffer());
    let blobData = {
      type: blob.type,
      buffer: Array.from(serializedBlob)
    };
    return blobData;
  }

  async function uploadNavetCertificate(meta, fileDescriptors) {
    const files = await Promise.all(fileDescriptors.map(async descriptor => {
      if (descriptor === null) {
        return null;
      } else if (descriptor.fileUrl !== undefined) {
        return {
          blob: await (await fetch(descriptor.fileUrl)).blob(),
          filename: descriptor.name
        };
      } else {
        return {
          blob: descriptor.file,
          filename: descriptor.file.name
        };
      }
    }));
    const formData = new FormData();
    formData.append('id', meta.id);
    formData.append('int_clients_courses_id', meta.int_clients_courses_id);
    formData.append('int_document_type_id', meta.int_document_type_id);
    formData.append('608-text', 'Удостоверение за професионално обучение');
    formData.append('int_course_finished_year', meta.int_course_finished_year); // need this added

    formData.append('vc_document_prn_no', '');
    formData.append('612-text', '');
    formData.append('vc_original_prn_no', meta.vc_document_prn_no);
    formData.append('vc_document_reg_no', meta.vc_document_reg_no); // need this added

    formData.append('vc_document_prot', meta.vc_document_prot);
    formData.append('num_theory_result', meta.num_theory_result);
    formData.append('num_practice_result', meta.num_practice_result);
    formData.append('vc_qualification_name', meta.vc_qualification_name);
    formData.append('vc_qualificatioj_level', meta.vc_qualificatioj_level);

    if (files[0] !== null) {
      formData.append('document_1_file_action', 'upload');
      formData.append('document_1_file', files[0].blob, files[0].filename);
    } else {
      formData.append('document_1_file_action', '');
      formData.append('document_1_file', new Blob(['']), '');
    }

    if (files[1] !== null) {
      formData.append('document_2_file_action', 'upload');
      formData.append('document_2_file', files[1].blob, files[1].filename);
    } else {
      formData.append('document_2_file_action', '');
      formData.append('document_2_file', new Blob(['']), '');
    }

    formData.append('invoke', `TbClientsCoursesDocumentsManager.updateObject(${meta.id})`);
    formData.append('application', 'AJAXDataProvider');
    formData.append('protocol', 'dataIFrame');
    formData.append('dt_document_date', meta.dt_document_date);
    formData.append('vc_document_type_name', meta.vc_document_type_name);
    formData.append('int_document_status', meta.int_document_status);
    formData.append('bool_with_note', meta.bool_with_note);
    formData.append('async_iframe_id', 'async_iframe_639');
    return uploadFile(formData);
  }

  async function updateNavetStudent(id, student) {
    const body = Object.assign({}, student, {
      invoke: `RefClientsCoursesManager.updateObject(${id})`
    });
    return parseResponse(await postForm(host, body));
  }

  async function createDocument(studentId, clientId, data) {
    const formData = new FormData();
    formData.append('id', null);
    formData.append('int_clients_courses_id', null);
    formData.append('int_document_type_id', '');
    formData.append('304-text', 'Удостоверение за професионално обучение');
    formData.append('int_course_finished_year', data.int_course_finished_year); // need this added

    formData.append('vc_document_prn_no', '');
    formData.append('308-text', '');
    formData.append('vc_document_reg_no', data.vc_document_reg_no); // need this added

    formData.append('vc_document_prot', '');
    formData.append('num_theory_result', 0);
    formData.append('num_practice_result', 0);
    formData.append('vc_qualification_name', '');
    formData.append('vc_qualificatioj_level', '');
    formData.append('document_1_file_action', '');
    formData.append('document_1_file', new Blob(['']), '');
    formData.append('document_2_file_action', '');
    formData.append('document_2_file', new Blob(['']), '');
    formData.append('invoke', 'CustomEventsManager.customTbClientsCoursesDocuments(1)');
    formData.append('application', 'AJAXDataProvider');
    formData.append('protocol', 'dataIFrame');
    formData.append('int_provider_id', 2929);
    formData.append('ref_clients_courses_id_t', studentId); //data.id

    formData.append('tb_clients_id_t', clientId); //data.int_client_id

    formData.append('dt_document_date_t', '');
    formData.append('int_client_course_id_t', studentId); //data.id

    formData.append('int_document_type_id_t', 2);
    formData.append('vc_document_prn_no_t', '');
    formData.append('vc_document_reg_no_t', data.vc_document_reg_no); // need this added, same as above

    formData.append('int_document_status', 0);
    formData.append('async_iframe_id', 'async_iframe_329');
    return uploadFile(formData);
  }

  return {
    getNavetCurrentCourses,
    getNavetClosedCourses,
    getNavetArchivedCourses,
    getNavetCourseInfo,
    getNavetStudents,
    getNavetStudentInfo,
    getNavetExistingFiles,
    uploadMedical,
    uploadDiploma,
    openNavetFile,
    deleteNavetFile,
    getGraduateInfo,
    getNavetCertificate,
    openNavetCertificate,
    uploadNavetCertificate,
    updateNavetStudent,
    createDocument,
    getExtraCourseInfo
  };
}

/***/ }),

/***/ "./src/api/judge/alphaJudge.js":
/*!*************************************!*\
  !*** ./src/api/judge/alphaJudge.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _util_contentTypes_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../util/contentTypes.js */ "./src/util/contentTypes.js");

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get,
  interopPlatformHost,
  interopAdminAlphaJudgeHost
}) {
  async function getContestCompeteResults(contestId) {
    const uri = `${interopAdminAlphaJudgeHost()}/api/contests/ExportResults`;
    const body = {
      id: contestId,
      type: 0
    };
    let blob = await post(uri, body, _util_contentTypes_js__WEBPACK_IMPORTED_MODULE_0__.ContentType.ApplicationJson, true);
    const serializedBlob = new Uint8Array(await blob.arrayBuffer());
    const blobData = {
      type: blob.type,
      filename: blob.filename,
      buffer: Array.from(serializedBlob)
    };
    return blobData;
  }

  async function getContestPracticeResults(contestId) {
    const uri = `${interopAdminAlphaJudgeHost()}/api/contests/ExportResults`;
    const body = {
      id: contestId,
      type: 1
    };
    let blob = await post(uri, body, _util_contentTypes_js__WEBPACK_IMPORTED_MODULE_0__.ContentType.ApplicationJson, true);
    const serializedBlob = new Uint8Array(await blob.arrayBuffer());
    const blobData = {
      type: blob.type,
      filename: blob.filename,
      buffer: Array.from(serializedBlob)
    };
    return blobData;
  }

  return {
    getContestCompeteResults,
    getContestPracticeResults
  };
}

/***/ }),

/***/ "./src/api/module.js":
/*!***************************!*\
  !*** ./src/api/module.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post
}) {
  async function getModulesInProfession(professionId) {
    const url = (() => {
      if (interopAppId() === 'softuni.bg') {
        return interopHost(`administration_professions/levelgroupsinprofessioninstances/read?foreignKeyId=${professionId}`);
      } else {
        return interopHost(`Administration_Professions/CourseGroupsInProfessionInstances/Read?foreignKeyId=${professionId}`);
      }
    })();

    const body = params({
      pageSize: 100
    });
    return post(url, body);
  }

  async function getModules() {
    const url = interopHost('administration_Levels/levels/read');
    const body = params({
      pageSize: 1000
    });
    return (await post(url, body)).Data;
  }

  async function getInstancesInModule(moduleId) {
    const url = (() => {
      if (interopAppId() === 'softuni.bg') {
        return interopHost(`administration_levels/levelinstances/read?importLevelId=${moduleId}&levelId=${moduleId}`);
      } else {
        return interopHost(`Administration_Levels/LevelInstances/Read?importLevelId=${moduleId}&levelId=${moduleId}&foreignKeyId=${moduleId}`);
      }
    })();

    const body = params({
      pageSize: 1000
    });
    return post(url, body);
  }

  async function getInstanceInModule(moduleId, moduleInstanceId) {
    const url = (() => {
      if (interopAppId() === 'softuni.bg') {
        return interopHost(`administration_levels/levelinstances/read?importLevelId=${moduleId}&levelId=${moduleId}`);
      } else {
        return interopHost(`Administration_Levels/LevelInstances/Read?importLevelId=${moduleId}&levelId=${moduleId}&foreignKeyId=${moduleId}`);
      }
    })();

    let filter = `Id~eq~${moduleInstanceId}`;

    if (Array.isArray(moduleInstanceId)) {
      filter = `Id~eq~${moduleInstanceId.join('~or~Id~eq~')}`;
    }

    const body = params({
      pageSize: 100,
      filter: filter
    });
    return post(url, body);
  }

  async function searchModules(query) {
    const url = interopHost('administration_levels/levels/read');
    const filter = `NameBg~contains~'${query.split(' ').filter(s => s.length > 0).join('\'~and~NameBg~contains~\'')}'`;
    const body = params({
      pageSize: 100,
      filter,
      sort: 'CreatedOn-desc'
    });
    return (await post(url, body)).Data;
  }

  return {
    getModulesInProfession,
    getModules,
    getInstancesInModule,
    searchModules,
    getInstanceInModule
  };
}

/***/ }),

/***/ "./src/api/payments.js":
/*!*****************************!*\
  !*** ./src/api/payments.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get,
  interopPlatformHost
}) {
  async function getPaymentsForPackage(packageName) {
    // This field does not work with multiple values

    /*
    const filter = (() => {
        if (Array.isArray(packageId)) {
            return `PaymentPackagesAsString~eq~'${packageId.join('\'~or~PaymentPackagesAsString~eq~\'')}'`;
            //return `PaymentStatus~eq~4~and~(PaymentPackagesAsString~eq~'${packageId.join('\'~or~PaymentPackagesAsString~eq~\'')}')`;
        } else {
            return `PaymentPackagesAsString~eq~'${packageId}'`;
            //return `PaymentStatus~eq~4~and~PaymentPackagesAsString~eq~${packageId}`;
        }
    })();
    */
    const url = `${interopPlatformHost()}/administration/payments/read?appId=${interopAppId()}`;
    const body = params({
      pageSize: 10000,
      filter: `PaymentStatus~eq~4~and~PaymentPackagesAsString~eq~'${packageName}'`
    });
    return post(url, body);
  }

  async function getPackagesForProduct(productId) {
    if (Array.isArray(productId) && productId.length === 0) {
      return {
        Data: []
      };
    }

    const filter = (() => {
      if (Array.isArray(productId)) {
        return `Name~doesnotcontain~'II'~and~(Product.Id~eq~${productId.join('~or~Product.Id~eq~')})`;
      } else {
        return `Name~doesnotcontain~'II'~and~Product.Id~eq~${productId}`;
      }
    })();

    const url = `${interopPlatformHost()}/administration/paymentpackages/read?appId=${interopAppId()}`;
    const body = params({
      pageSize: 1000,
      filter
    });
    return post(url, body);
  }

  async function getProductsForModule(moduleId) {
    const filter = (() => {
      if (Array.isArray(moduleId)) {
        return `Name~doesnotcontain~'II'~and~(LevelInstanceId~eq~${moduleId.join('~or~LevelInstanceId~eq~')})`;
      } else {
        return `Name~doesnotcontain~'II'~and~LevelInstanceId~eq~${moduleId}`;
      }
    })();

    const url = `${interopPlatformHost()}/administration/levelinstanceproducts/read?appId=${interopAppId()}`;
    const body = params({
      pageSize: 1000,
      filter
    });
    return post(url, body);
  }

  async function getProductsForCourse(instanceId, type = 'open') {
    const epStrings = (() => {
      switch (type) {
        case 'open':
          return {
            path: 'fasttrackinstanceproducts',
            param: 'FastTrackInstanceId'
          };
      }
    })();

    const filter = (() => {
      if (Array.isArray(instanceId)) {
        return `(${epStrings.param}~eq~${instanceId.join(`~or~${epStrings.param}~eq~`)})`;
      } else {
        return `${epStrings.param}~eq~${instanceId}`;
      }
    })();

    const url = `${interopPlatformHost()}/administration/${epStrings.path}/read?appId=${interopAppId()}`;
    const body = params({
      pageSize: 1000,
      filter
    });
    return post(url, body);
  }

  return {
    getPaymentsForPackage,
    getPackagesForProduct,
    getProductsForModule,
    getProductsForCourse
  };
}

/***/ }),

/***/ "./src/api/quiz.js":
/*!*************************!*\
  !*** ./src/api/quiz.js ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function createQuizInstance(payload) {
    const uri = interopHost('administration_testsystem/tests/create');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: 0,
      Name: payload.name,
      Description: payload.description,
      QuestionsCount: 0
    });
    return await post(uri, body);
  }

  async function addQuestion(quizId, question) {
    const uri = interopHost(`administration_testsystem/testquestions/create?foreignKeyId=${quizId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: 0,
      Type: 1,
      Content: question,
      CorrectAnswerPoints: 1,
      WrongAnswerPoints: 0,
      KeepAnswersOrder: false,
      ShowCorrectAnswersCount: false,
      CorrectCount: 0,
      WrongCount: 0,
      AllCount: 0,
      PercentCorrect: 0
    });
    return await post(uri, body);
  }

  async function addAnswer(questionId, answer, isCorrect) {
    const uri = interopHost(`administration_testsystem/testquestionanswers/create?foreignKeyId=${questionId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: 0,
      QuestionId: 0,
      Content: answer,
      IsCorrect: isCorrect,
      SelectedCount: 0
    });
    return await post(uri, body);
  }

  async function getAllQuizesByName(containingName, pageSize, page) {
    const uri = interopHost(`administration_testsystem/tests/read`);
    const body = params({
      sort: '',
      group: '',
      filter: `Name~contains~'${containingName}'`,
      pageSize,
      page
    });
    return await post(uri, body);
  }

  async function getQuestionsById(quizId, pageSize, page) {
    const uri = interopHost(`administration_testsystem/testquestions/read?foreignKeyId=${quizId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      pageSize,
      page
    });
    return await post(uri, body);
  }

  async function getAnswersByQuestionId(questionId, pageSize, page) {
    const uri = interopHost(`administration_testsystem/testquestionanswers/read?foreignKeyId=${questionId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      pageSize,
      page
    });
    return await post(uri, body);
  }

  return {
    createQuizInstance,
    addQuestion,
    addAnswer,
    getAllQuizesByName,
    getQuestionsById,
    getAnswersByQuestionId
  };
}

/***/ }),

/***/ "./src/api/storage/assessmentConfig.js":
/*!*********************************************!*\
  !*** ./src/api/storage/assessmentConfig.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _generic__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./generic */ "./src/api/storage/generic.js");

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  const genericApi = (0,_generic__WEBPACK_IMPORTED_MODULE_0__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const storeId = {
    'softuni.bg': 3797,
    'digital.softuni.bg': 3556,
    'creative.softuni.bg': 1411,
    'ai.softuni.bg': 6,
    'financeacademy.bg': 73
  };

  function serialize(data) {
    return {
      sort: '',
      group: '',
      filter: '',
      Id: data.Id || 0,
      TrainingId: storeId[interopAppId()],
      NameBg: '0000000000' + data.ExamId,
      NameEn: '0000000000',
      HasManualNumberOfStudyHours: true,
      NumberOfStudyHours: 0,
      IsExcludedFromCertificate: false,
      HasHomework: false,
      ResourceMailsState: 0,
      HomeworkMailsState: 0,
      JudgeContestId: '',
      OrderBy: 0,
      DescriptionBg: '0000000000' + JSON.stringify(data.Config),
      DescriptionEn: '0000000000',
      ExcludeFromCalendar: false,
      HasLiveStream: false,
      CreatedOn: '',
      ModifiedOn: ''
    };
  }

  function parse(entry) {
    if (entry) {
      return {
        Id: entry.Id,
        ExamId: Number((entry.NameBg || '').slice(10)),
        Config: JSON.parse((entry.DescriptionBg || '').slice(10))
      };
    } else {
      return undefined;
    }
  }

  async function getConfigs(examIds) {
    const data = await genericApi.getEntries(storeId[interopAppId()], `NameBg~eq~'${examIds.map(id => '0000000000' + id).join('\'~or~NameBg~eq~\'')}'`);
    return data.map(parse);
    ;
  }

  async function getConfigByExamId(examId) {
    const config = await genericApi.getEntries(storeId[interopAppId()], `NameBg~eq~'0000000000${examId}'`);
    return parse(config.Data[0]);
  }

  async function saveConfig(config) {
    const operation = config.Id ? genericApi.updateEntry : genericApi.createEntry;
    const result = await operation(serialize(config));
    return parse(result.Data[0]);
  }

  async function deleteConfig(config) {
    return genericApi.destroyEntry(serialize(config));
  }

  return {
    getConfigs,
    getConfigByExamId,
    saveConfig,
    deleteConfig
  };
}

/***/ }),

/***/ "./src/api/storage/generic.js":
/*!************************************!*\
  !*** ./src/api/storage/generic.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  /* Entry model:
        {
          sort: '',
          group: '',
          filter: '',
          Id: data.Id,
          TrainingId: storeId[interopAppId()],
          NameBg: '',                             String (3-200)
          NameEn: '',                             String (3-200)
          NumberOfStudyHours: 0,                  Integer
          IsExcludedFromCertificate: false,       Boolean
          HasHomework: false,                     Boolean
          ResourceMailsState: 0,
          HomeworkMailsState: 0,
          JudgeContestId: '',                     Integer (cannot be empty)
          OrderBy: 0,                             Integer
          DescriptionBg: '',                      String (10-6000)
          DescriptionEn: '',                      String (10-6000)
          ExcludeFromCalendar: false,             Boolean
          HasLiveStream: false,                   Boolean
          CreatedOn: '',
          ModifiedOn: ''
      };
  */
  const settingsStoreId = {
    'softuni.bg': 529,
    'digital.softuni.bg': 1064,
    'creative.softuni.bg': 101,
    'ai.softuni.bg': 5,
    'financeacademy.bg': 24
  };

  async function getStoreSettings(storeId) {
    const uri = interopHost(`administration_trainings/fasttrackinstances/read?foreignKeyId=${settingsStoreId[interopAppId()]}`);
    const body = params({
      filter: `Id~eq~${storeId}`
    });
    const store = (await post(uri, body)).Data[0];
    const asJson = (store.DescriptionBg || '').slice(10) + (store.DescriptionEn || '').slice(10);

    try {
      return {
        settings: JSON.parse(asJson),
        _ModifiedOn: store.ModifiedOn || store.CreatedOn
      };
    } catch (err) {
      console.error(err);
      return undefined;
    }
  }

  async function saveStoreSettings(storeId, settings) {
    const currentUri = interopHost(`administration_trainings/fasttrackinstances/read?foreignKeyId=${settingsStoreId[interopAppId()]}`);
    const currentBody = params({
      filter: `Id~eq~${storeId}`
    });
    const current = (await post(currentUri, currentBody)).Data[0];
    delete current.SharesLiveStreamWithTrainings;

    if (settings.hasOwnProperty('_ModifiedOn') && settings.hasOwnProperty('settings')) {
      settings = settings.settings;
    }

    const asJson = JSON.stringify(settings);
    current.DescriptionBg = '0000000000' + asJson.slice(0, 10000);
    current.DescriptionEn = '0000000000' + asJson.slice(10000); //Certificate type is now required (8 = None)

    current.CertificateType = 8;
    const uri = interopHost(`administration_trainings/fasttrackinstances/update?foreignKeyId=${settingsStoreId[interopAppId()]}`);
    const body = {
      'sort': '',
      'group': '',
      'filter': '',
      ...current,
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:01.317'
    };
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });

    try {
      const result = (await post(uri, body)).Data[0];
      return JSON.parse((result.DescriptionBg || '').slice(10));
    } catch (err) {
      console.error(err);
      return undefined;
    }
  }

  async function getEntries(storeId, filter) {
    const uri = interopHost(`administration_trainings/lectures/read?foreignKeyId=${storeId}`);
    const body = params({
      pageSize: 1000
    });

    if (filter) {
      body.filter = filter;
    }

    return (await post(uri, body)).Data;
  }

  async function updateEntry(entry) {
    let startDate = new Date();
    let endDate = new Date(startDate);
    endDate.setUTCDate(endDate.getUTCDate() + 1);
    const uri = interopHost(`administration_trainings/lectures/update?foreignKeyId=${entry.TrainingId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: entry.Id,
      TrainingId: entry.TrainingId,
      NameBg: entry.NameBg,
      NameEn: entry.NameEn,
      HasManualNumberOfStudyHours: true,
      NumberOfStudyHours: entry.NumberOfStudyHours,
      IsExcludedFromCertificate: entry.IsExcludedFromCertificate,
      HasHomework: entry.HasHomework,
      ResourceMailsState: entry.ResourceMailsState,
      HomeworkMailsState: entry.HomeworkMailsState,
      JudgeContestId: entry.JudgeContestId,
      OrderBy: entry.OrderBy,
      DescriptionBg: entry.DescriptionBg,
      DescriptionEn: entry.DescriptionEn,
      ExcludeFromCalendar: entry.ExcludeFromCalendar,
      HasLiveStream: entry.HasLiveStream,
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:02.317',
      DatesInfo: [{
        Start: startDate.toISOString(),
        End: endDate.toISOString(),
        ExtraInformation: ''
      }]
    });
    serializeDatesInfo(body);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function createEntry(entry) {
    let startDate = new Date();
    let endDate = new Date(startDate);
    endDate.setUTCDate(endDate.getUTCDate() + 1);
    const uri = interopHost(`administration_trainings/lectures/create?foreignKeyId=${entry.TrainingId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: entry.Id,
      TrainingId: entry.TrainingId,
      NameBg: entry.NameBg,
      NameEn: entry.NameEn,
      HasManualNumberOfStudyHours: true,
      NumberOfStudyHours: entry.NumberOfStudyHours,
      IsExcludedFromCertificate: entry.IsExcludedFromCertificate,
      HasHomework: entry.HasHomework,
      ResourceMailsState: entry.ResourceMailsState,
      HomeworkMailsState: entry.HomeworkMailsState,
      JudgeContestId: entry.JudgeContestId,
      OrderBy: entry.OrderBy,
      DescriptionBg: entry.DescriptionBg,
      DescriptionEn: entry.DescriptionEn,
      ExcludeFromCalendar: entry.ExcludeFromCalendar,
      HasLiveStream: entry.HasLiveStream,
      CreatedOn: '',
      ModifiedOn: '',
      DatesInfo: [{
        Start: startDate.toISOString(),
        End: endDate.toISOString(),
        ExtraInformation: ''
      }]
    });
    serializeDatesInfo(body);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function destroyEntry(entry) {
    const uri = interopHost(`administration_trainings/lectures/destroy?foreignKeyId=${entry.TrainingId}`);
    const body = params({
      sort: '',
      group: '',
      filter: ''
    });
    Object.assign(body, entry);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    return post(uri, body);
  }

  function serializeDatesInfo(body) {
    const datesInfo = body.DatesInfo;
    delete body.DatesInfo;

    for (let i = 0; i < datesInfo.length; i++) {
      const date = datesInfo[i];
      body[`DatesInfo[${i}].Start`] = date.Start;
      body[`DatesInfo[${i}].End`] = date.End;
      body[`DatesInfo[${i}].ExtraInformation`] = date.ExtraInformation;
    }
  }

  return {
    getStoreSettings,
    saveStoreSettings,
    getEntries,
    updateEntry,
    createEntry,
    destroyEntry
  };
}

/***/ }),

/***/ "./src/api/storage/modulesData.js":
/*!****************************************!*\
  !*** ./src/api/storage/modulesData.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _generic__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./generic */ "./src/api/storage/generic.js");

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  const genericApi = (0,_generic__WEBPACK_IMPORTED_MODULE_0__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const storeId = {
    'softuni.bg': 4492,
    'digital.softuni.bg': 3815,
    'creative.softuni.bg': 1612,
    'ai.softuni.bg': 9
  };
  return {
    getModuleDataSettings: () => genericApi.getStoreSettings(storeId[interopAppId()]),
    saveModuleDataSettings: settings => genericApi.saveStoreSettings(storeId[interopAppId()], settings)
  };
}

/***/ }),

/***/ "./src/api/storage/paymentStats.js":
/*!*****************************************!*\
  !*** ./src/api/storage/paymentStats.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _generic__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./generic */ "./src/api/storage/generic.js");

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  const genericApi = (0,_generic__WEBPACK_IMPORTED_MODULE_0__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const storeId = {
    'softuni.bg': 3833,
    'digital.softuni.bg': 3582,
    'creative.softuni.bg': 1428,
    'ai.softuni.bg': 10
  };

  function serialize(data) {
    const payload = {
      PaymentsByDate: data.PaymentsByDate,
      RetentionByDate: data.RetentionByDate,
      OnlinePayments: data.OnlinePayments || 0,
      OnlineRetention: data.OnlineRetention || 0,
      SitePayments: data.SitePayments || 0,
      SiteRetention: data.SiteRetention || 0
    };
    const asJson = JSON.stringify(payload);
    return {
      sort: '',
      group: '',
      filter: '',
      Id: data.Id || 0,
      TrainingId: storeId[interopAppId()],
      NameBg: '0000000000' + (data.NameBg + '::' + data.NameEn + '::' + data.LevelId),
      NameEn: '0000000000' + JSON.stringify(data.DateConfig),
      HasManualNumberOfStudyHours: true,
      NumberOfStudyHours: data.StartIndex || 0,
      IsExcludedFromCertificate: false,
      JudgeContestId: data.LevelId,
      HasHomework: false,
      ResourceMailsState: 0,
      HomeworkMailsState: 0,
      OrderBy: data.InstanceId,
      DescriptionBg: '0000000000' + asJson.slice(0, 5980),
      DescriptionEn: '0000000000' + asJson.slice(5980),
      ExcludeFromCalendar: !data.IsMainProgram,
      HasLiveStream: false,
      CreatedOn: '',
      ModifiedOn: ''
    };
  }

  function parse(entry) {
    if (entry) {
      try {
        const payloadJson = (entry.DescriptionBg || '').slice(10) + (entry.DescriptionEn || '').slice(10);
        const payload = JSON.parse(payloadJson);
        const namesAndLevel = entry.NameBg.slice(10).split('::');
        return {
          Id: entry.Id,
          InstanceId: Number(entry.OrderBy) || null,
          LevelId: Number(namesAndLevel[2]) || entry.JudgeContestId,
          NameBg: namesAndLevel[0],
          NameEn: namesAndLevel[1],
          DateConfig: JSON.parse((entry.NameEn || '').slice(10)),
          StartIndex: entry.NumberOfStudyHours,
          PaymentsByDate: payload.PaymentsByDate,
          RetentionByDate: payload.RetentionByDate,
          OnlinePayments: payload.OnlinePayments || 0,
          OnlineRetention: payload.OnlineRetention || 0,
          SitePayments: payload.SitePayments || 0,
          SiteRetention: payload.SiteRetention || 0,
          IsMainProgram: !entry.ExcludeFromCalendar,
          ModifiedOn: entry.ModifiedOn || entry.CreatedOn
        };
      } catch (err) {
        console.error('Destroying incompatible entry');
        console.log(entry);
        console.error(err);
        genericApi.destroyEntry(entry);
        return undefined;
      }
    } else {
      return undefined;
    }
  }

  async function getStats(instanceIds) {
    const data = await genericApi.getEntries(storeId[interopAppId()], `OrderBy~eq~${instanceIds.join('~or~OrderBy~eq~')}`);
    return data.map(parse);
  }

  async function getStatsByInstanceId(instanceId) {
    const config = await genericApi.getEntries(storeId[interopAppId()], `OrderBy~eq~${instanceId}`);
    return parse(config[0]);
  }

  async function getStatsByStartIndex(start, end) {
    const data = await genericApi.getEntries(storeId[interopAppId()], `NumberOfStudyHours~gte~${start}~and~NumberOfStudyHours~lte~${end}`);
    return data.map(parse);
  }

  async function saveStats(stats) {
    const operation = stats.Id ? genericApi.updateEntry : genericApi.createEntry;
    const result = await operation(serialize(stats));

    if (result.Errors) {
      const error = new Error('Request returned Errors');
      error._errorObject = result.Errors;
      throw error;
    } // console.log(JSON.stringify(result));


    return parse(result.Data[0]);
  }

  async function deleteStats(stats) {
    return genericApi.destroyEntry(serialize(stats));
  }

  return {
    getStatsSettings: () => genericApi.getStoreSettings(storeId[interopAppId()]),
    saveStatsSettings: settings => genericApi.saveStoreSettings(storeId[interopAppId()], settings),
    getStats,
    getStatsByInstanceId,
    getStatsByStartIndex,
    saveStats,
    deleteStats
  };
}

/***/ }),

/***/ "./src/api/storage/templates.js":
/*!**************************************!*\
  !*** ./src/api/storage/templates.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _generic__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./generic */ "./src/api/storage/generic.js");

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  const genericApi = (0,_generic__WEBPACK_IMPORTED_MODULE_0__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const templateStoreId = {
    'softuni.bg': 3519,
    'digital.softuni.bg': 3440,
    'creative.softuni.bg': 1300,
    'ai.softuni.bg': 7,
    'financeacademy.bg': 74
  };

  async function getTemplateStoreSettings() {
    return genericApi.getStoreSettings(templateStoreId[interopAppId()]);
  }

  function templateToEntry(data) {
    return {
      sort: '',
      group: '',
      filter: '',
      Id: data.Id || 0,
      TrainingId: templateStoreId[interopAppId()],
      NameBg: '0000000000' + data.Name,
      NameEn: '0000000000' + JSON.stringify(data.Category),
      HasManualNumberOfStudyHours: true,
      NumberOfStudyHours: 0,
      IsExcludedFromCertificate: data.Active,
      HasHomework: false,
      ResourceMailsState: 0,
      HomeworkMailsState: 0,
      JudgeContestId: '',
      OrderBy: 0,
      DescriptionBg: '0000000000' + data.Content,
      DescriptionEn: ('0000000000' + (data.InstanceId || '')).slice(-10),
      ExcludeFromCalendar: data.Compound,
      HasLiveStream: false,
      CreatedOn: '',
      ModifiedOn: ''
    };
  }

  function entryToTemplate(entry) {
    if (entry) {
      return {
        Id: entry.Id,
        Name: entry.NameBg.slice(10),
        Category: JSON.parse(entry.NameEn.slice(10)) || [],
        Active: entry.IsExcludedFromCertificate,
        Compound: entry.ExcludeFromCalendar,
        Content: (entry.DescriptionBg || '').slice(10),
        InstanceId: Number(entry.DescriptionEn) || null
      };
    } else {
      return undefined;
    }
  }

  async function getTemplates() {
    const data = await genericApi.getEntries(templateStoreId[interopAppId()]);
    return data.map(entryToTemplate).sort((a, b) => {
      return (b.Active ? 1 : 0) - (a.Active ? 1 : 0) || (b.Compound ? 1 : 0) - (a.Compound ? 1 : 0) || a.Name.localeCompare(b.Name);
    });
  }

  async function getTemplateByName(name) {
    const template = await genericApi.getEntries(templateStoreId[interopAppId()], `NameBg~eq~'${name}'`);
    return entryToTemplate(template[0]);
  }

  async function getTemplateByInstanceId(instanceId) {
    const template = await genericApi.getEntries(templateStoreId[interopAppId()], `DescriptionEn~eq~'${instanceId}'`);
    return entryToTemplate(template[0]);
  }

  async function saveTemplate(template) {
    const operation = template.Id ? genericApi.updateEntry : genericApi.createEntry;
    const result = await operation(templateToEntry(template));
    return entryToTemplate(result.Data[0]);
  }

  async function deleteTemplate(template) {
    return genericApi.destroyEntry(templateToEntry(template));
  }

  return {
    getTemplateStoreSettings,
    getTemplates,
    getTemplateByName,
    getTemplateByInstanceId,
    saveTemplate,
    deleteTemplate
  };
}

/***/ }),

/***/ "./src/api/stream/stream.js":
/*!**********************************!*\
  !*** ./src/api/stream/stream.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getInstanceConfig(instanceId) {
    const uri = `https://ses-webext.github.io/stream/${instanceId}.json`;

    try {
      const result = await get(uri);
      return result;
    } catch (err) {
      console.log(err);
      return null;
    }
  }

  return {
    getInstanceConfig
  };
}

/***/ }),

/***/ "./src/api/survey.js":
/*!***************************!*\
  !*** ./src/api/survey.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post
}) {
  async function getSurveys(page, query, filter, pageSize = 30) {
    if (pageSize == undefined) {
      pageSize = 30;
    }

    const url = interopHost('administration_surveys/surveys/read');
    const body = params({
      sort: 'ActiveTo-desc',
      pageSize: pageSize,
      page
    });

    if (query) {
      body.filter = `Name~contains~'${query}'`;
    }

    if (filter) {
      body.filter += `~and~(${filter})`;
    }

    return post(url, body);
  }

  async function getSurveysByNameAndStartAndEndDate(page, name, startDate, endDate, pageSize = 30) {
    if (pageSize == undefined) {
      pageSize = 30;
    }

    const url = interopHost('administration_surveys/surveys/read');
    const body = params({
      sort: 'ActiveTo-desc',
      pageSize: pageSize,
      page
    });
    body.filter = `Name~contains~'${name}'~and~ActiveFrom~gte~datetime'${startDate}'~and~ActiveFrom~lt~datetime'${endDate}'`;
    return post(url, body);
  }

  async function getSurveyById(surveyId) {
    const url = interopHost('administration_surveys/surveys/read');
    const body = params({
      filter: 'Id~eq~' + surveyId
    });
    return (await post(url, body)).Data[0];
  }

  async function getSurveyAnswers(surveyId) {
    const url = interopHost('administration_surveys/userpollanswers/read');
    const body = params({
      pageSize: 10000,
      filter: 'SurveyId~eq~' + surveyId
    });
    return post(url, body);
  }

  async function getSurveyTemplates() {
    const url = interopHost('administration_surveys/surveysectiontemplates/read');
    const body = params({
      pageSize: 10000
    });
    return post(url, body);
  }

  async function getSurveyQuestionsByTemplateId(templateId) {
    const url = interopHost(`administration_surveys/pollquestions/readpollquestions?surveySectionTemplateId=${templateId}`);
    const body = params({
      pageSize: 10000
    });
    return post(url, body);
  }

  async function getSurveySectionsByTemplateId(templateId) {
    const url = interopHost('administration_surveys/surveysections/read');
    const body = params({
      pageSize: 10000,
      filter: `SurveySectionTemplateId~eq~${templateId}`
    });
    return post(url, body);
  }

  async function getSurveySectionsById(sectionId) {
    const url = interopHost('administration_surveys/surveysections/read');
    const body = params({
      pageSize: 10000,
      filter: `Id~eq~${Array.isArray(sectionId) ? sectionId.join('~or~Id~eq~') : sectionId}`
    });
    return post(url, body);
  }

  async function findSectionsByTraining(nameBg) {
    const url = interopHost('administration_surveys/surveysections/read');
    const body = params({
      pageSize: 100,
      filter: `Training~eq~'${nameBg}'~and~Name~doesnotcontain~'обслужване'~and~Name~doesnotcontain~'информация'~and~Name~doesnotcontain~'свързани с курса'`
    });
    return (await post(url, body)).Data.map(s => s.Name);
  }

  async function findAnswersBySection(sectionNames) {
    const url = interopHost('administration_surveys/userpollanswers/read');
    const body = params({
      pageSize: 10000,
      filter: 'Section~eq~\'' + sectionNames.join('\'~or~Section~eq~\'') + '\''
    });
    return (await post(url, body)).Data;
  }

  async function findSurveyByTraining(nameBg) {
    const sections = await findSectionsByTraining(nameBg);
    console.log(sections);
    const answers = await findAnswersBySection(sections);
    const surveys = [...answers.reduce((p, c) => {
      p.add(c.SurveyId);
      return p;
    }, new Set())];
    return Promise.all(surveys.map(getSurveyById));
  }

  return {
    getSurveys,
    getSurveysByNameAndStartAndEndDate,
    getSurveyById,
    getSurveyAnswers,
    getSurveyTemplates,
    getSurveyQuestionsByTemplateId,
    getSurveySectionsByTemplateId,
    getSurveySectionsById,
    findSurveyByTraining
  };
}

/***/ }),

/***/ "./src/api/trainings/assessment.js":
/*!*****************************************!*\
  !*** ./src/api/trainings/assessment.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util */ "./src/api/util.js");

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getHomeworkResults(instanceId) {
    const uri = interopHost(`administration_crm/internalcoursecrmprofiles/readinternalcoursecrmprofiles/${instanceId}`);
    return await fetchNext();

    async function fetchNext(page = 1) {
      const body = params({
        sort: 'CreatedOn-desc',
        pageSize: 1000,
        page
      });
      const response = await post(uri, body);
      let result = response.Data;

      if (response.Total > page * 1000) {
        result = result.concat(await fetchNext(page + 1));
      }

      return result;
    }
  }

  async function getProtocol(instanceId) {
    const response = await fetch(interopHost(`administration_trainings/usersincourses/exporttrainingprotocol/${instanceId}`), {
      'credentials': 'include',
      'headers': {
        'Host': 'softuni.bg',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:97.0) Gecko/20100101 Firefox/97.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br',
        'Connection': 'keep-alive',
        'Referer': interopHost('administration_trainings/usersintrainingsmanagement'),
        'Upgrade-Insecure-Requests': 1,
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache'
      },
      'method': 'GET',
      'mode': 'cors'
    });
    const blob = await response.blob();
    const serializedBlob = new Uint8Array(await blob.arrayBuffer());
    const blobData = {
      type: blob.type,
      buffer: Array.from(serializedBlob)
    };
    return blobData;
  }

  async function uploadFile(url, formData) {
    const result = await fetch(url, {
      credentials: 'include',
      method: 'POST',
      body: formData
    });
    return result;
  }

  async function uploadExamResults(examName, examId, combo, fileDescriptor) {
    const url = interopHost('administration_trainings/exams/importexamresults');
    const {
      blob,
      filename
    } = await (0,_util__WEBPACK_IMPORTED_MODULE_0__.parseCrossBrowserFile)(fileDescriptor);
    const formData = new FormData();
    const rvt = await obtainRVT();
    formData.append('__RequestVerificationToken', rvt);
    formData.append('ExamId_input', examName);
    formData.append('ExamId', examId);
    formData.append('ResultsFile', blob, filename);

    if (combo.importPractice) {
      formData.append('ImportPreferences', 1); // Practice
    }

    if (combo.importQuiz) {
      formData.append('ImportPreferences', 2); // Quiz
    }

    formData.append('UsernameColumn', 1);
    formData.append('ResultColumn', 2);
    formData.append('CommentColumn', 3);
    formData.append('TheoryResultColumn', 4);
    formData.append('TheoryCommentColumn', 5);
    const result = await uploadFile(url, formData);
    return processExamResultOutcome(result);
  }

  async function processExamResultOutcome(result) {
    const page = await result.text();
    const successPattern = /<h3>Успешни записи:(.+?)<\/h3>/us;
    const failurePattern = /<h3>Неуспешни записи:(.+?)<\/h3>/us;
    const userlistPattern = /<p>.*?Успешно бяха вмъкнати резултатите на следните потребители:(.+?)<\/p>/us;

    try {
      const successful = Number(successPattern.exec(page)[1].trim());
      const failed = Number(failurePattern.exec(page)[1].trim());
      const list = userlistPattern.exec(page)[1].trim().split(',').map(u => u.trim());
      return {
        successful,
        failed,
        list
      };
    } catch (err) {
      console.error(err);
      throw new Error('Error processing file');
    }
  }

  async function obtainRVT() {
    const url = interopHost('administration_trainings/exams/importexamresults');
    const pageData = await get(url);
    const pattern = /<input.*?name="__RequestVerificationToken".*?value="(.+?)".*?>/i;
    const rvt = pattern.exec(pageData)[1];
    return rvt;
  }

  return {
    getHomeworkResults,
    getProtocol,
    uploadExamResults
  };
}

/***/ }),

/***/ "./src/api/trainings/events.js":
/*!*************************************!*\
  !*** ./src/api/trainings/events.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getEvents(instanceId) {
    const uri = interopHost('administration_trainings/traininggrouplectures/read');
    const body = params({
      sort: 'StartDateTime-asc',
      page: 1,
      pageSize: 100,
      group: '',
      filter: `TrainingId~eq~${instanceId}`
    });
    return (await post(uri, body)).Data;
  }

  async function updateEvent(event) {
    const uri = interopHost('administration_trainings/traininggrouplectures/update');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: event.Id,
      TrainingGroupId: event.TrainingGroupId,
      TrainingGroupName: event.TrainingGroupName,
      LectureId: event.LectureId,
      LectureName: event.LectureName,
      TrainingId: event.TrainingId,
      StartDateTime: event.StartDateTime,
      EndDateTime: event.EndDateTime,
      HasLiveStream: event.HasLiveStream,
      TrainingLabId: event.TrainingLabId,
      TrainingLabName: event.TrainingLabName,
      LastEditedUsername: '',
      CreatedOn: '',
      ModifiedOn: '',
      TrainingGroupId_input: ''
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function createEvent(event) {
    const uri = interopHost('administration_trainings/traininggrouplectures/create');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: event.Id,
      TrainingGroupId: event.TrainingGroupId,
      TrainingGroupName: event.TrainingGroupName,
      LectureId: event.LectureId,
      LectureName: event.LectureName,
      TrainingId: event.TrainingId,
      StartDateTime: event.StartDateTime,
      EndDateTime: event.EndDateTime,
      HasLiveStream: event.HasLiveStream,
      TrainingLabId: event.TrainingLabId,
      TrainingLabName: event.TrainingLabName,
      LastEditedUsername: '',
      CreatedOn: '',
      ModifiedOn: '',
      TrainingGroupId_input: ''
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function destroyEvent(event) {
    const uri = interopHost('administration_trainings/traininggrouplectures/destroy');
    const body = params({
      sort: '',
      group: '',
      filter: ''
    });
    Object.assign(body, event);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    return post(uri, body);
  }

  async function getEventsByDate(startDate, endDate) {
    // Date format yyyy-mm-dd example: 2020-03-25
    const uri = interopHost('administration_trainings/traininggrouplectures/read');
    const body = params({
      sort: 'StartDateTime-asc',
      page: 1,
      pageSize: 10000,
      group: '',
      filter: `StartDateTime~gte~datetime'${startDate}T00-00-00'~and~EndDateTime~lte~datetime'${endDate}T23-59-59'`
    });
    return (await post(uri, body)).Data;
  }

  async function getEventsById(eventId) {
    // Date format yyyy-mm-dd example: 2020-03-25
    const uri = interopHost('administration_trainings/traininggrouplectures/read');
    const body = params({
      sort: 'StartDateTime-asc',
      page: 1,
      pageSize: 1000,
      group: '',
      filter: `Id~eq~${eventId}`
    });
    return (await post(uri, body)).Data;
  }

  return {
    getEvents,
    updateEvent,
    createEvent,
    destroyEvent,
    getEventsByDate,
    getEventsById
  };
}

/***/ }),

/***/ "./src/api/trainings/exams.js":
/*!************************************!*\
  !*** ./src/api/trainings/exams.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getExamsById(ids) {
    if (Array.isArray(ids) == false) {
      ids = [ids];
    }

    if (ids.length == 0) {
      return [];
    }

    const uri = interopHost('administration_trainings/exams/read');
    const body = params({
      pageSize: 10000,
      filter: `Id~eq~${ids.join('~or~Id~eq~')}`
    });
    return (await post(uri, body)).Data;
  }

  async function getExamsByCourse(nameBg, instanceId) {
    const uri = interopHost('administration_trainings/exams/read');

    const filter = (() => {
      if (interopAppId() === 'softuni.bg') {
        return `TrainingNamesString~contains~'${nameBg}'`;
      } else {
        return '';
      }
    })();

    const body = params({
      pageSize: 10000,
      filter
    });
    const data = await post(uri, body);
    return data.Data.filter(e => e.PrimaryTrainings.filter(t => t.Id == instanceId).length > 0 || e.RetakenTrainings.filter(t => t.Id == instanceId).length > 0);
  }

  async function getExamsByName(query) {
    const uri = interopHost('administration_trainings/exams/read');

    const filter = (() => {
      if (Array.isArray(query)) {
        return `(NameBg~contains~'${query.join('\'~or~NameBg~contains~\'')}')~or~(NameEn~contains~'${query.join('\'~or~NameEn~contains~\'')}')`;
      } else {
        return `NameBg~contains~'${query}'~or~NameEn~contains~'${query}'`;
      }
    })();

    const body = params({
      sort: 'CreatedOn-desc',
      pageSize: 20,
      filter
    });
    const data = await post(uri, body);

    if (Array.isArray(query)) {
      const fullMatch = await getExamsByName(query.join(' '));
      const filtered = data.Data.filter(r => fullMatch.some(x => x.Id == r.Id) == false);
      return fullMatch.concat(filtered.slice(0, 20 - fullMatch.length));
    } else {
      return data.Data;
    }
  }

  async function getExamGroupsByExamId(examId) {
    if (Array.isArray(examId) == false) {
      examId = [examId];
    }

    if (examId.length == 0) {
      return [];
    }

    const uri = interopHost('administration_trainings/examgroups/read');
    const body = params({
      pageSize: 10000,
      filter: `ExamId~eq~${examId.join('~or~ExamId~eq~')}`
    });
    return (await post(uri, body)).Data;
  }

  async function getExamGroupsByDate(startDate, endDate) {
    // Date format yyyy-mm-dd example: 2020-03-25
    const uri = interopHost('administration_trainings/examgroups/read');
    const body = params({
      sort: 'StartTime-asc',
      page: 1,
      pageSize: 10000,
      group: '',
      filter: `StartTime~gte~datetime'${startDate}T00-00-00'~and~EndTime~lte~datetime'${endDate}T23-59-59'`
    });
    return (await post(uri, body)).Data;
  }

  async function getEnrolledByGroupId(examGroupId) {
    const uri = interopHost(`administration_trainings/examgroupparticipants/read?foreignKeyId=${examGroupId}`);
    const body = params({
      pageSize: 10000
    });
    return (await post(uri, body)).Data;
  }

  async function createExam(exam) {
    const uri = interopHost('administration_trainings/exams/create');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: exam.Id,
      NameBg: exam.NameBg,
      NameEn: exam.NameEn,
      Type: exam.Type,
      AllowChoosingSeatsWithComputer: exam.AllowChoosingSeatsWithComputer,
      AllowAllUsersInTrainingsToSitExam: exam.AllowAllUsersInTrainingsToSitExam,
      ExamGroupEnrollmentDeadline: exam.ExamGroupEnrollmentDeadline,
      TrainingNamesString: '',
      CreatedOn: '',
      ModifiedOn: ''
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    }); // Two-step process is necessary because of a server bug when the exam has associated training instances

    const result = await post(uri, body);

    if (result.Errors !== null) {
      return result;
    } else {
      const item = result.Data[0];
      item.PrimaryTrainings = exam.PrimaryTrainings;
      item.RetakenTrainings = exam.RetakenTrainings;
      const deadline = new Date(Number(item.ExamGroupEnrollmentDeadline.match(/\d+/)[0]));
      item.ExamGroupEnrollmentDeadline = Number.isNaN(deadline) ? '' : deadline.toISOString();
      return updateExam(item);
    }
  }

  async function updateExam(exam) {
    const uri = interopHost('administration_trainings/exams/update');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: exam.Id,
      NameBg: exam.NameBg,
      NameEn: exam.NameEn,
      Type: exam.Type,
      AllowChoosingSeatsWithComputer: exam.AllowChoosingSeatsWithComputer,
      AllowAllUsersInTrainingsToSitExam: exam.AllowAllUsersInTrainingsToSitExam,
      ExamGroupEnrollmentDeadline: exam.ExamGroupEnrollmentDeadline,
      TrainingNamesString: '',
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:01.317'
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    exam.PrimaryTrainings.forEach(trainingsToBody('PrimaryTrainings'));
    exam.RetakenTrainings.forEach(trainingsToBody('RetakenTrainings'));
    return post(uri, body);

    function trainingsToBody(propName) {
      return function (training, index) {
        body[`${propName}[${index}].Id`] = training.Id;
        body[`${propName}[${index}].Name`] = training.NameBg;
        body[`${propName}[${index}].NameBg`] = training.NameBg;
        body[`${propName}[${index}].NameEn`] = training.NameEn;
      };
    }
  }

  async function createExamGroup(group) {
    const uri = interopHost('administration_trainings/examgroups/create');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: '0',
      ExamId: group.ExamId,
      ExamName: '',
      StartTime: group.StartTime,
      EndTime: group.EndTime,
      TrainingLabId: group.TrainingLabId,
      JudgeSystemContestId: group.JudgeSystemContestId,
      TestSystemTestId: group.TestSystemTestId,
      ExamGroupParticipantsCount: group.ExamGroupParticipantsCount,
      Limit: group.Limit,
      IsAddedToGoogleCalendar: group.IsAddedToGoogleCalendar,
      CustomEnrollmentSuccessMessage: group.CustomEnrollmentSuccessMessage,
      CreatedOn: '',
      ModifiedOn: ''
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function updateExamGroup(group) {
    const uri = interopHost('administration_trainings/examgroups/update');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: group.Id,
      ExamId: group.ExamId,
      ExamName: group.ExamName,
      StartTime: group.StartTime,
      EndTime: group.EndTime,
      TrainingLabId: group.TrainingLabId,
      JudgeSystemContestId: group.JudgeSystemContestId,
      TestSystemTestId: group.TestSystemTestId,
      ExamGroupParticipantsCount: group.ExamGroupParticipantsCount,
      Limit: group.Limit,
      IsAddedToGoogleCalendar: group.IsAddedToGoogleCalendar,
      CustomEnrollmentSuccessMessage: group.CustomEnrollmentSuccessMessage,
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:01.317'
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function destroyExamGroup(group) {
    const uri = interopHost('administration_trainings/examgroups/destroy');
    const body = params({
      sort: '',
      group: '',
      filter: ''
    });
    Object.assign(body, group);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    return post(uri, body);
  }

  return {
    getExamsById,
    getExamsByCourse,
    getExamsByName,
    getExamGroupsByExamId,
    getEnrolledByGroupId,
    getExamGroupsByDate,
    createExam,
    updateExam,
    createExamGroup,
    updateExamGroup,
    destroyExamGroup
  };
}

/***/ }),

/***/ "./src/api/trainings/groups.js":
/*!*************************************!*\
  !*** ./src/api/trainings/groups.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getInsanceGroups(instanceId) {
    const uri = interopHost('administration_trainings/traininggroups/read');
    const body = params({
      pageSize: 100,
      filter: `TrainingId~eq~${instanceId}`
    });
    return (await post(uri, body)).Data;
  }

  async function getGroupById(groupId) {
    const uri = interopHost('administration_trainings/traininggroups/read');
    const body = params({
      pageSize: 100,
      filter: `Id~eq~${groupId}`
    });
    return (await post(uri, body)).Data[0];
  }

  async function createTrainingGroup(group) {
    const uri = interopHost('administration_trainings/traininggroups/create');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: group.Id,
      TrainingId: group.TrainingId,
      TrainingName: group.TrainingName,
      TrainingLabId: group.TrainingLabId,
      Name: group.Name,
      DayOfWeek: group.DayOfWeek,
      StartTime: group.StartTime,
      EndTime: group.EndTime,
      SkipWeeksCount: group.SkipWeeksCount,
      WeekLectureNumber: group.WeekLectureNumber,
      PeopleLimit: group.PeopleLimit,
      TakenPlaces: group.TakenPlaces,
      IsAddedToGoogleCalendar: group.IsAddedToGoogleCalendar,
      CreatedOn: '',
      ModifiedOn: ''
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function destroyGroup(group) {
    const uri = interopHost('administration_trainings/traininggroups/destroy');
    const body = params({
      sort: '',
      group: '',
      filter: ''
    });
    Object.assign(body, group);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    return post(uri, body);
  }

  return {
    getInsanceGroups,
    getGroupById,
    createTrainingGroup,
    destroyGroup
  };
}

/***/ }),

/***/ "./src/api/trainings/lectures.js":
/*!***************************************!*\
  !*** ./src/api/trainings/lectures.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getInstanceLectures(instanceId) {
    const uri = interopHost(`administration_trainings/lectures/read?foreignKeyId=${instanceId}`);
    const body = params({
      sort: 'OrderBy-asc',
      pageSize: 100
    });
    return (await post(uri, body)).Data;
  }

  async function getLecturesForExamsByTrainingId(trainingId) {
    const uri = interopHost(`administration_trainings/lectures/read?foreignKeyId=${trainingId}`);
    const examKeywords = ['exam', 'defence', 'defense', 'изпит', 'защита'];
    const examExcludeKeywords = ['preparation', 'подготовка'];
    const body = params({
      sort: 'OrderBy-asc',
      pageSize: 100,
      filter: `(NameBg~contains~'${examKeywords.join('\'~or~NameBg~contains~\'')}')~and~(NameBg~doesnotcontain~'${examExcludeKeywords.join('\'~and~NameBg~doesnotcontain~\'')}')`
    });
    return (await post(uri, body)).Data;
  }

  async function updateLecture(lecture) {
    console.log(lecture);
    const uri = interopHost(`administration_trainings/lectures/update?foreignKeyId=${lecture.TrainingId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: lecture.Id,
      TrainingId: lecture.TrainingId,
      NameBg: lecture.NameBg,
      NameEn: lecture.NameEn,
      HasManualNumberOfStudyHours: lecture.HasManualNumberOfStudyHours,
      NumberOfStudyHours: lecture.NumberOfStudyHours,
      IsExcludedFromCertificate: lecture.IsExcludedFromCertificate,
      HasHomework: lecture.HasHomework,
      ResourceMailsState: lecture.ResourceMailsState,
      HomeworkMailsState: lecture.HomeworkMailsState,
      JudgeContestId: lecture.JudgeContestId,
      AlphaJudgeContestId: lecture.AlphaJudgeContestId,
      OrderBy: lecture.OrderBy,
      DescriptionBg: lecture.DescriptionBg,
      DescriptionEn: lecture.DescriptionEn,
      DatesInfo: lecture.DatesInfo || [],
      Lecturer: lecture.Lecturer,
      LectureType: lecture.LectureType,
      ExcludeFromCalendar: lecture.ExcludeFromCalendar,
      HasLiveStream: lecture.HasLiveStream,
      ExamPassword: lecture.ExamPassword,
      DiscordChannel: lecture.DiscordChannel,
      SlidoCode: lecture.SlidoCode,
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:02.317'
    });
    serializeDatesInfo(body);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function createLecture(lecture) {
    const uri = interopHost(`administration_trainings/lectures/create?foreignKeyId=${lecture.TrainingId}`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: lecture.Id,
      TrainingId: lecture.TrainingId,
      NameBg: lecture.NameBg,
      NameEn: lecture.NameEn,
      HasManualNumberOfStudyHours: lecture.HasManualNumberOfStudyHours,
      NumberOfStudyHours: lecture.NumberOfStudyHours,
      IsExcludedFromCertificate: lecture.IsExcludedFromCertificate,
      HasHomework: lecture.HasHomework,
      ResourceMailsState: lecture.ResourceMailsState,
      HomeworkMailsState: lecture.HomeworkMailsState,
      JudgeContestId: lecture.JudgeContestId,
      AlphaJudgeContestId: lecture.AlphaJudgeContestId,
      OrderBy: lecture.OrderBy,
      DescriptionBg: lecture.DescriptionBg,
      DescriptionEn: lecture.DescriptionEn,
      DatesInfo: lecture.DatesInfo || [],
      Lecturer: lecture.Lecturer,
      LectureType: lecture.LectureType,
      ExcludeFromCalendar: lecture.ExcludeFromCalendar,
      HasLiveStream: lecture.HasLiveStream,
      ExamPassword: lecture.ExamPassword,
      DiscordChannel: lecture.DiscordChannel,
      SlidoCode: lecture.SlidoCode,
      CreatedOn: '',
      ModifiedOn: ''
    });
    serializeDatesInfo(body);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function destroyLecture(lecture) {
    const uri = interopHost(`administration_trainings/lectures/destroy?foreignKeyId=${lecture.TrainingId}`);
    const body = params({
      sort: '',
      group: '',
      filter: ''
    });
    Object.assign(body, lecture);
    serializeDatesInfo(body);
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    return post(uri, body);
  }

  async function getLectureDetails(trainingId, lectureId) {
    const url = interopHost(`trainings/trainings/getlecturedetails?trainingId=${trainingId}&lectureId=${lectureId}`);
    return get(url);
  }

  function serializeDatesInfo(body) {
    const datesInfo = body.DatesInfo;
    delete body.DatesInfo;

    for (let i = 0; i < datesInfo.length; i++) {
      const date = datesInfo[i];
      body[`DatesInfo[${i}].Start`] = date.Start;
      body[`DatesInfo[${i}].End`] = date.End;
      body[`DatesInfo[${i}].ExtraInformation`] = date.ExtraInformation;
    }
  }

  return {
    getInstanceLectures,
    updateLecture,
    createLecture,
    destroyLecture,
    getLectureDetails,
    getLecturesForExamsByTrainingId
  };
}

/***/ }),

/***/ "./src/api/trainings/seminars.js":
/*!***************************************!*\
  !*** ./src/api/trainings/seminars.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getSeminarsByDate(startDate, endDate) {
    // Date format yyyy-mm-dd example: 2020-03-25
    const uri = interopHost('administration_trainings/seminars/read');
    const body = params({
      sort: 'StartDate-asc',
      page: 1,
      pageSize: 10000,
      group: '',
      filter: `StartDate~gte~datetime'${startDate}T00-00-00'~and~EndDate~lte~datetime'${endDate}T23-59-59'`
    });
    return (await post(uri, body)).Data;
  }

  return {
    getSeminarsByDate
  };
}

/***/ }),

/***/ "./src/api/trainings/skills.js":
/*!*************************************!*\
  !*** ./src/api/trainings/skills.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getSkillsByInstance(name, instanceId) {
    const body = params({
      pageSize: 10000,
      sort: 'OrderBy-asc'
    });
    body.filter = `MergedTrainings~contains~'${name}'`;
    const data = await Promise.all([post(interopHost('administration_trainings/fasttrackinstanceskills/read'), body), post(interopHost('administration_trainings/courseinstanceskills/read'), body)]);
    let response = [];
    response = response.concat(data[0].Data.filter(i => i.Trainings.filter(t => t.Id == instanceId).length > 0).map(s => {
      s.Type = 'open';
      return s;
    }));
    response = response.concat(data[1].Data.filter(i => i.Trainings.filter(t => t.Id == instanceId).length > 0).map(s => {
      s.Type = 'main';
      return s;
    }));
    return response;
  }

  async function updateSkill(skill) {
    const uri = interopHost(`administration_trainings/${skill.Type === 'main' ? 'courseinstanceskills' : 'fasttrackinstanceskills'}/update`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: skill.Id,
      TextBg: skill.TextBg,
      OrderBy: skill.OrderBy,
      MergedTrainings: skill.MergedTrainings,
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:01.317'
    });

    for (let i = 0; i < skill.Trainings.length; i++) {
      const training = skill.Trainings[i];
      body[`Trainings[${i}].Id`] = training.Id;
      body[`Trainings[${i}].Name`] = training.Name;
      body[`Trainings[${i}].NameBg`] = training.NameBg;
      body[`Trainings[${i}].NameEn`] = training.NameEn;
    }

    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    const result = await post(uri, body);
    result.Data[0].Type = skill.Type;
    return result;
  }

  async function createSkill(skill) {
    const uri = interopHost(`administration_trainings/${skill.Type === 'main' ? 'courseinstanceskills' : 'fasttrackinstanceskills'}/create`);
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: skill.Id,
      TextBg: skill.TextBg,
      OrderBy: skill.OrderBy,
      MergedTrainings: skill.MergedTrainings,
      CreatedOn: '',
      ModifiedOn: ''
    });

    for (let i = 0; i < skill.Trainings.length; i++) {
      const training = skill.Trainings[i];
      body[`Trainings[${i}].Id`] = training.Id;
      body[`Trainings[${i}].Name`] = training.Name;
      body[`Trainings[${i}].NameBg`] = training.NameBg;
      body[`Trainings[${i}].NameEn`] = training.NameEn;
    }

    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    const result = await post(uri, body);
    result.Data[0].Type = skill.Type;
    return result;
  }

  async function destroySkill(skill) {
    const uri = interopHost(`administration_trainings/${skill.Type === 'main' ? 'courseinstanceskills' : 'fasttrackinstanceskills'}/destroy`);
    const body = params({
      sort: '',
      group: '',
      filter: ''
    });
    Object.assign(body, skill);

    for (let i = 0; i < skill.Trainings.length; i++) {
      const training = skill.Trainings[i];
      body[`Trainings[${i}].Id`] = training.Id;
      body[`Trainings[${i}].Name`] = training.Name;
      body[`Trainings[${i}].NameBg`] = training.NameBg;
      body[`Trainings[${i}].NameEn`] = training.NameEn;
    }

    delete body.Trainings;
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    return post(uri, body);
  }

  async function searchSkills(query, type) {
    const uri = interopHost(`administration_trainings/${type === 'main' ? 'courseinstanceskills' : 'fasttrackinstanceskills'}/read`);
    const body = params({
      pageSize: 15,
      sort: 'OrderBy-asc',
      filter: `TextBg~contains~'${query}'`
    });
    const data = await post(uri, body);
    data.Data.forEach(s => s.Type = type);
    return data.Data;
  }

  return {
    getSkillsByInstance,
    updateSkill,
    createSkill,
    destroySkill,
    searchSkills
  };
}

/***/ }),

/***/ "./src/api/trainings/trainings.js":
/*!****************************************!*\
  !*** ./src/api/trainings/trainings.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _events__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./events */ "./src/api/trainings/events.js");
/* harmony import */ var _lectures__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./lectures */ "./src/api/trainings/lectures.js");
/* harmony import */ var _skills__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./skills */ "./src/api/trainings/skills.js");
/* harmony import */ var _groups__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./groups */ "./src/api/trainings/groups.js");
/* harmony import */ var _exams__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./exams */ "./src/api/trainings/exams.js");
/* harmony import */ var _assessment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./assessment */ "./src/api/trainings/assessment.js");
/* harmony import */ var _seminars__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./seminars */ "./src/api/trainings/seminars.js");







/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get,
  interopPlatformHost
}) {
  const eventsApi = (0,_events__WEBPACK_IMPORTED_MODULE_0__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const lecturesApi = (0,_lectures__WEBPACK_IMPORTED_MODULE_1__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const skillsApi = (0,_skills__WEBPACK_IMPORTED_MODULE_2__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const groupsApi = (0,_groups__WEBPACK_IMPORTED_MODULE_3__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const examsApi = (0,_exams__WEBPACK_IMPORTED_MODULE_4__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const assessmentApi = (0,_assessment__WEBPACK_IMPORTED_MODULE_5__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });
  const seminarsApi = (0,_seminars__WEBPACK_IMPORTED_MODULE_6__["default"])({
    interopHost,
    interopAppId,
    params,
    post,
    get
  });

  async function searchByName(body) {
    const query = body.query.filter(f => f.length > 0);
    const courses = await Promise.all([body.main && getMainInstances(body.page, query), body.open && getOpenInstances(body.page, query), body.general && getGeneralInstances(body.page, query)]);
    const result = [];

    for (let course of courses[0] || []) {
      result.push({
        Id: course.Id,
        NameBg: course.NameBg,
        Type: 'main',
        CourseId: course.CourseId
      });
    }

    for (let course of courses[1] || []) {
      result.push({
        Id: course.Id,
        NameBg: course.NameBg,
        Type: 'open',
        CourseId: course.CourseId
      });
    }

    for (let course of courses[2] || []) {
      result.push({
        Id: course.Id,
        NameBg: course.NameBg,
        Type: 'general',
        CourseId: course.CourseId
      });
    }

    return result;
  }

  async function searchTrainingsByName(name, exact = false) {
    if (Array.isArray(name) == false) {
      name = [name];
    }

    const uri = interopHost('administration_trainings/trainings/read');
    const body = params({
      pageSize: 50,
      filter: exact ? `NameBg~eq~'${name.filter(s => s.length > 0).join('\'~or~NameBg~eq~\'')}'` : `NameBg~contains~'${name.filter(s => s.length > 0).join('\'~or~NameBg~contains~\'')}'`,
      sort: 'StartDate-desc',
      page: 1
    });
    return (await post(uri, body)).Data;
  }

  async function searchCourses(query) {
    const url = interopHost('administration_trainings/courses/read');
    const filter = `Name~contains~'${query.split(' ').filter(s => s.length > 0).join('\'~and~Name~contains~\'')}'`;
    const body = params({
      pageSize: 100,
      filter,
      sort: 'CreatedOn-desc'
    });
    const result = (await post(url, body)).Data;
    result.forEach(r => {
      r.NameBg = r.Name;
      r.NameEn = r.Name;
    });
    return result;
  }

  async function searchCourseInstancesByCourseNameAndInstanceId(courseNames, instanceIds, filter = undefined) {
    if (Array.isArray(courseNames) == false) {
      courseNames = [courseNames];
    }

    const url = interopHost('administration_trainings/courses/read');
    const coursesFilter = `Name~contains~'${courseNames.filter(s => s.length > 0).join('\'~and~Name~contains~\'')}'`;
    const body = params({
      pageSize: 100,
      filter: coursesFilter,
      sort: 'CreatedOn-desc'
    });
    const result = (await post(url, body)).Data;
    result.forEach(r => {
      r.NameBg = r.Name;
      r.NameEn = r.Name;
    });
    let courseInstancesPromises = [];
    result.forEach(c => {
      courseInstancesPromises.push(getCourseInstances(c.Id, filter));
    });

    if (Array.isArray(instanceIds) == false) {
      instanceIds = [instanceIds];
    }

    let allCourseInstances = (await Promise.all(courseInstancesPromises)).reduce((a, c) => a.concat(c), []);
    let filteredCourseInstances = instanceIds.length == 0 ? allCourseInstances : allCourseInstances.filter(ci => instanceIds.includes(ci.Id));
    return filteredCourseInstances;
  }

  async function getMainInstances(page, query) {
    const uri = interopHost('administration_trainings/usersincourses/readcourseinstances');
    const filter = query.map(e => `NameBg~contains~'${e}'`).join('~and~');
    const body = params({
      sort: 'IsActive-desc~CreatedOn-desc',
      page,
      pageSize: 25,
      filter
    });
    const data = await post(uri, body);
    return data.Data.map(e => ({
      Id: e.Id,
      NameBg: e.NameBg,
      CourseId: e.CourseId
    }));
  }

  async function getOpenInstances(page, query) {
    const uri = interopHost('/administration_trainings/usersinfasttracks/readfasttrackinstances');
    const filter = query.map(e => `NameBg~contains~'${e}'`).join('~and~');
    const body = params({
      sort: 'IsActive-desc~CreatedOn-desc',
      page,
      pageSize: 25,
      filter
    });
    const data = await post(uri, body);
    return data.Data.map(e => ({
      Id: e.Id,
      NameBg: e.NameBg,
      CourseId: e.CourseId
    }));
  }

  async function getGeneralInstances(page, query) {
    const uri = interopHost('administration_trainings/usersingeneralcourseinstances/readgeneralcourseinstances');
    const filter = query.map(e => `NameBg~contains~'${e}'`).join('~and~');
    const body = params({
      sort: 'IsActive-desc~CreatedOn-desc',
      page,
      pageSize: 25,
      filter
    });
    const data = await post(uri, body);
    return data.Data.map(e => ({
      Id: e.Id,
      NameBg: e.NameBg,
      CourseId: e.CourseId
    }));
  }

  async function getCourseData(courseId) {
    const uri = interopHost('administration_trainings/courses/read');
    const body = params({
      filter: `Id~eq~'${courseId}'`
    });
    return (await post(uri, body)).Data[0];
  }

  async function getCourseInstances(courseId, filter = undefined) {
    const body = params({
      sort: 'StartDate-desc',
      pageSize: 100
    });
    const data = await Promise.all([filter == undefined || filter.main === true ? post(interopHost(`administration_trainings/courseinstances/read?foreignKeyId=${courseId}`), body) : Promise.resolve(true), filter == undefined || filter.main === true ? post(interopHost(`administration_trainings/fasttrackinstances/read?foreignKeyId=${courseId}`), body) : Promise.resolve(true), filter == undefined || filter.general === true ? post(interopHost(`administration_trainings/generalcourseinstances/read?foreignKeyId=${courseId}`), body) : Promise.resolve(true)]);
    let response = [];
    response = response.concat(data[0].Data != undefined ? data[0].Data.map(c => {
      c.InstanceRefType = 'main';
      return c;
    }) : []);
    response = response.concat(data[1].Data != undefined ? data[1].Data.map(c => {
      c.InstanceRefType = 'open';
      return c;
    }) : []);
    response = response.concat(data[2].Data != undefined ? data[2].Data.map(c => {
      c.InstanceRefType = 'general';
      return c;
    }) : []);
    return response;
  }

  async function getInstanceData(instanceId, courseId, type) {
    try {
      if (type) {
        return getInstanceDataByType(instanceId, courseId, type);
      } else {
        const queryResults = await Promise.all([getInstanceDataByType(instanceId, courseId, 'main'), getInstanceDataByType(instanceId, courseId, 'open'), getInstanceDataByType(instanceId, courseId, 'general')]);
        return queryResults.filter(e => e !== undefined)[0];
      }
    } catch (e) {
      console.log(e);
    }
  }

  async function getInstanceDataByType(instanceId, courseId, type) {
    const uri = (() => {
      switch (type) {
        case 'main':
          return interopHost(`administration_trainings/courseinstances/read?foreignKeyId=${courseId}`);

        case 'open':
          return interopHost(`administration_trainings/fasttrackinstances/read?foreignKeyId=${courseId}`);

        case 'general':
          return interopHost(`administration_trainings/generalcourseinstances/read?foreignKeyId=${courseId}`);
      }
    })();

    const body = params({
      filter: `Id~eq~${instanceId}`
    });
    const instance = (await post(uri, body)).Data[0];

    if (instance !== undefined) {
      instance.InstanceRefType = type;
    }

    return instance;
  }

  async function getInstanceOverview(instanceIds) {
    if (Array.isArray(instanceIds) == false) {
      instanceIds = [instanceIds];
    }

    const uri = interopHost('administration_trainings/trainings/read');
    const body = params({
      pageSize: 1000,
      filter: `TrainingId~eq~${instanceIds.join('~or~TrainingId~eq~')}`
    });
    return (await post(uri, body)).Data;
  }

  function updateCourse(course) {
    const uri = interopHost('administration_trainings/courses/update');
    const body = params({
      sort: '',
      group: '',
      filter: '',
      Id: course.Id,
      Name: course.Name,
      DescriptionBg: course.DescriptionBg,
      DescriptionEn: course.DescriptionEn,
      UrlName: course.UrlName,
      IconUrl: course.IconUrl,
      Credits: course.Credits,
      IsActive: course.IsActive,
      IsHidden: course.IsHidden,
      OrderBy: course.OrderBy,
      MergedTags: course.MergedTags,
      CourseCategoryId: course.CourseCategoryId,
      CourseDifficultyLevel: course.CourseDifficultyLevel,
      CourseDifficultyLevelDescriptionBg: course.CourseDifficultyLevelDescriptionBg,
      CourseDifficultyLevelDescriptionEn: course.CourseDifficultyLevelDescriptionEn,
      CreatedOn: course.CreatedOn,
      ModifiedOn: course.ModifiedOn || course.CreatedOn
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function updateInstance(instance) {
    const uri = (() => {
      switch (instance.InstanceRefType) {
        case 'main':
          return interopHost(`administration_trainings/courseinstances/update?foreignKeyId=${instance.CourseId}`);

        case 'open':
          return interopHost(`administration_trainings/fasttrackinstances/update?foreignKeyId=${instance.CourseId}`);

        case 'general':
          return interopHost(`administration_trainings/generalcourseinstances/update?foreignKeyId=${instance.CourseId}`);

        default:
          return interopHost(`administration_trainings/fasttrackinstances/update?foreignKeyId=${instance.CourseId}`);
      }
    })();

    const body = Object.assign({}, instance, {
      sort: '',
      group: '',
      filter: '',
      ModifiedOn: instance.ModifiedOn || instance.CreatedOn
    });
    delete body.InstanceRefType;
    delete body.SharesLiveStreamWithTrainings;
    Object.keys(body).forEach(k => {
      if (body[k] === null) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function getStudents(instanceId, type = 'main') {
    const uri = (() => {
      switch (type) {
        case 'main':
          return interopHost(`administration_trainings/usersincourses/read?foreignKeyId=${instanceId}`);

        case 'open':
          return interopHost(`administration_trainings/usersinfasttracks/read?foreignKeyId=${instanceId}`);

        case 'general':
          return interopHost(`administration_trainings/usersingeneralcourseinstances/read?foreignKeyId=${instanceId}`);
      }
    })();

    return await fetchNext();

    async function fetchNext(page = 1) {
      const body = params({
        sort: 'CreatedOn-desc',
        pageSize: 1000,
        page
      });
      const response = await post(uri, body);
      let result = response.Data;

      if (response.Total > page * 1000) {
        result = result.concat(await fetchNext(page + 1));
      }

      return result;
    }
  }

  async function getCourseEvents(instanceId) {
    const data = await Promise.all([getMainById(instanceId), getOpenById(instanceId), getGeneralById(instanceId), eventsApi.getEvents(instanceId)]);

    for (let i = 0; i < 3; i++) {
      if (data[i].Total > 0) {
        const response = {
          Id: data[i].Data[0].Id,
          CourseId: data[i].Data[0].CourseId,
          NameBg: data[i].Data[0].NameBg,
          Events: data[3],
          InstanceRefType: {
            0: 'main',
            1: 'open',
            2: 'general'
          }[i]
        };
        return response;
      }
    }

    throw new Error('Error fetching instance data: All searches returned 0 matches');
  }

  async function getAnyById(instanceId) {
    if (Array.isArray(instanceId) && instanceId.length === 0) {
      return [];
    }

    const result = await Promise.all([getMainById(instanceId), getOpenById(instanceId), getGeneralById(instanceId)]);

    for (let i = 0; i < result.length; i++) {
      const instance = result[i];

      if (instance.Total > 0) {
        const type = {
          0: 'main',
          1: 'open',
          2: 'general'
        }[i];
        instance.Data.forEach(i => i.InstanceRefType = type);
      }
    }

    return result.reduce((p, c) => p.concat(c.Data), []);
  }

  async function getMainById(instanceId) {
    const filter = (() => {
      if (Array.isArray(instanceId)) {
        return `Id~eq~${instanceId.join('~or~Id~eq~')}`;
      } else {
        return `Id~eq~${instanceId}`;
      }
    })();

    const uri = interopHost('administration_trainings/usersincourses/readcourseinstances');
    const body = params({
      pageSize: 10000,
      filter
    });
    return post(uri, body);
  }

  async function getOpenById(instanceId) {
    const filter = (() => {
      if (Array.isArray(instanceId)) {
        return `Id~eq~${instanceId.join('~or~Id~eq~')}`;
      } else {
        return `Id~eq~${instanceId}`;
      }
    })();

    const uri = interopHost('administration_trainings/usersinfasttracks/readfasttrackinstances');
    const body = params({
      pageSize: 10000,
      filter
    });
    return post(uri, body);
  }

  async function getGeneralById(instanceId) {
    const filter = (() => {
      if (Array.isArray(instanceId)) {
        return `Id~eq~${instanceId.join('~or~Id~eq~')}`;
      } else {
        return `Id~eq~${instanceId}`;
      }
    })();

    const uri = interopHost('administration_trainings/usersingeneralcourseinstances/readgeneralcourseinstances');
    const body = params({
      pageSize: 10000,
      filter
    });
    return post(uri, body);
  }

  async function getInstancePage(instanceId) {
    const uri = interopHost(`trainings/trainings/getcoursedetails?id=${instanceId}`);
    return get(uri);
  }

  async function getInstanceFullPage(url) {
    return get(url);
  }

  async function getTrainerNames(instanceId) {
    return (await fetch(interopHost(`kendoremotedata/gettrainersbytraining?trainingId=${instanceId}`), {
      'credentials': 'include',
      'headers': {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:96.0) Gecko/20100101 Firefox/96.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'X-Requested-With': 'XMLHttpRequest',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'no-cors',
        'Sec-Fetch-Site': 'same-origin'
      },
      'method': 'GET',
      'mode': 'cors'
    })).json();
  }

  return { ...eventsApi,
    ...lecturesApi,
    ...skillsApi,
    ...groupsApi,
    ...examsApi,
    ...assessmentApi,
    ...seminarsApi,
    searchByName,
    searchCourses,
    getCourseData,
    getCourseInstances,
    getInstanceData,
    getInstanceOverview,
    updateCourse,
    updateInstance,
    getStudents,
    getCourseEvents,
    getAnyById,
    getInstancePage,
    getInstanceFullPage,
    getTrainerNames,
    searchCourseInstancesByCourseNameAndInstanceId,
    searchTrainingsByName
  };
}

/***/ }),

/***/ "./src/api/users.js":
/*!**************************!*\
  !*** ./src/api/users.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__({
  interopHost,
  interopAppId,
  params,
  post,
  get
}) {
  async function getTrainingsByTrainer(userId) {
    const uri = (() => {
      if (interopAppId() === 'softuni.bg') {
        return interopHost(`administration_users/trainersintrainings/readtrainingsoftrainer?trainerId=${userId}`);
      } else {
        return interopHost(`Administration_Users/TrainersInTrainings/Read?foreignKey=${userId}&foreignKeyId=${userId}`);
      }
    })();

    const body = params({
      pageSize: 100,
      sort: 'ModifiedOn-desc'
    });
    const result = await post(uri, body);
    result.Data.forEach(t => {
      t.DescriptionBg = t.DescriptionBg || '';
      t.DescriptionEn = t.DescriptionEn || '';
    });
    return result;
  }

  async function getTrainerById(userId) {
    const uri = (() => {
      if (interopAppId() === 'softuni.bg') {
        return interopHost('administration_users/trainersintrainings/read');
      } else {
        return interopHost('Administration_Users/Trainers/Read');
      }
    })();

    const body = params({
      pageSize: 100,
      filter: `UserId~eq~'${userId}'`
    });
    return post(uri, body);
  }

  async function updateTrainingByTrainer(training) {
    const uri = (() => {
      if (interopAppId() === 'softuni.bg') {
        return interopHost('administration_users/trainersintrainings/UpdateTrainerInTraining');
      } else {
        return interopHost('Administration_Users/TrainersInTrainings/Update');
      }
    })();

    const body = params({
      TrainingId: training.TrainingId,
      TrainingName: training.TrainingName,
      TrainerFirstName: training.TrainerFirstName,
      TrainerLastName: training.TrainerLastName,
      TrainerId: training.TrainerId,
      TrainerOrderBy: training.TrainerOrderBy,
      IsPublicTrainer: training.IsPublicTrainer,
      DescriptionBg: training.DescriptionBg,
      DescriptionEn: training.DescriptionEn,
      TrainerPhotoPath: training.TrainerPhotoPath,
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:01.317'
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null || body[k] === undefined) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function createTrainingByTrainer(training) {
    const uri = interopAppId() === 'softuni.bg' ? interopHost(`administration_users/trainersintrainings/AddTrainerToTraining?userId=${training.TrainerId}`) : interopHost(`Administration_Users/TrainersInTrainings/Create?foreignKey=${training.TrainerId}`);
    const body = params({
      TrainingId: training.TrainingId,
      TrainingName: training.TrainingName,
      TrainerFirstName: training.TrainerFirstName,
      TrainerLastName: training.TrainerLastName,
      TrainerId: training.TrainerId,
      TrainerOrderBy: training.TrainerOrderBy,
      IsPublicTrainer: training.IsPublicTrainer,
      DescriptionBg: training.DescriptionBg,
      DescriptionEn: training.DescriptionEn,
      TrainerPhotoPath: training.TrainerPhotoPath,
      CreatedOn: '2019-07-31T17:39:01.317',
      ModifiedOn: '2019-07-31T17:39:01.317'
    });
    Object.keys(body).forEach(k => {
      if (body[k] === null || body[k] === undefined) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function searchUsers(query, exclude) {
    const result = await Promise.all([searchUsersByName(query, exclude), searchUsersByUserName(query, exclude)]);
    return result[0].concat(result[1]);
  }

  async function destroyTrainingOfTrainer(training) {
    const uri = interopAppId() === 'softuni.bg' ? interopHost('administration_users/trainersintrainings/DeleteTrainerFromTraining') : interopHost('Administration_Users/TrainersInTrainings/Destroy');
    const body = Object.assign(params(), training);
    body.CreatedOn = '2019-07-31T17:39:01.317';
    body.ModifiedOn = '2019-07-31T17:39:01.317';
    Object.keys(body).forEach(k => {
      if (body[k] === null || body[k] === undefined) {
        body[k] = '';
      }
    });
    return post(uri, body);
  }

  async function searchUsersByName(name, exclude) {
    const uri = interopHost('administration_users/users/read');
    let filter = name.includes(' ') ? `(FirstNameEn~eq~'${name.split(' ')[0]}'~and~LastNameEn~startswith~'${name.split(' ')[1]}')~or~(FirstNameBg~eq~'${name.split(' ')[0]}'~and~LastNameBg~startswith~'${name.split(' ')[1]}')` : `FirstNameEn~contains~'${name}'~or~LastNameEn~contains~'${name}'~or~FirstNameBg~contains~'${name}'~or~LastNameBg~contains~'${name}'`;

    if (Array.isArray(exclude)) {
      filter = `(${filter})~and~(Id~neq~'${exclude.join('\'~and~Id~neq~\'')}')`;
    }

    const body = params({
      sort: 'UserName-asc',
      pageSize: 5,
      filter
    });
    return (await post(uri, body)).Data;
  }

  async function searchUsersByUserName(name, exclude) {
    if (name.includes(' ')) {
      return [];
    }

    const uri = interopHost('administration_users/users/read');
    let filter = `UserName~contains~'${name}'`;

    if (Array.isArray(exclude)) {
      filter = `(${filter})~and~(Id~neq~'${exclude.join('\'~and~Id~neq~\'')}')`;
    }

    const body = params({
      sort: 'UserName-asc',
      pageSize: 5,
      filter
    });
    return (await post(uri, body)).Data;
  }

  async function getTrainersByTraining(trainingId) {
    const uri = interopHost(`Administration_Trainings/TrainingsWithTrainers/Read?foreignKey=${trainingId}&foreignKeyId=${trainingId}`);
    const body = params({
      pageSize: 10,
      sort: 'OrderBy-asc'
    });
    const result = await post(uri, body);
    result.Data.forEach(t => {
      t.DescriptionBg = t.DescriptionBg || '';
      t.DescriptionEn = t.DescriptionEn || '';
    });
    return result.Data;
  }

  return {
    getTrainingsByTrainer,
    getTrainerById,
    updateTrainingByTrainer,
    createTrainingByTrainer,
    destroyTrainingOfTrainer,
    searchUsers,
    getTrainersByTraining
  };
}

/***/ }),

/***/ "./src/api/util.js":
/*!*************************!*\
  !*** ./src/api/util.js ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "parseCrossBrowserFile": () => (/* binding */ parseCrossBrowserFile)
/* harmony export */ });
async function parseCrossBrowserFile(fileDescriptor) {
  let blob;
  let filename;

  if (fileDescriptor.fileUrl !== undefined) {
    blob = await (await fetch(fileDescriptor.fileUrl)).blob();
    filename = fileDescriptor.name;
  } else {
    blob = fileDescriptor.file;
    filename = fileDescriptor.file.name;
  }

  return {
    blob,
    filename
  };
}

/***/ }),

/***/ "./src/common/Modal.js":
/*!*****************************!*\
  !*** ./src/common/Modal.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModalControls": () => (/* binding */ ModalControls),
/* harmony export */   "ModalOption": () => (/* binding */ ModalOption),
/* harmony export */   "createDialog": () => (/* binding */ createDialog),
/* harmony export */   "createLoadingModal": () => (/* binding */ createLoadingModal),
/* harmony export */   "createModal": () => (/* binding */ createModal),
/* harmony export */   "default": () => (/* binding */ Modal)
/* harmony export */ });
/* harmony import */ var _util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/jsx-render-mod/dom */ "./src/util/jsx-render-mod/dom.js");
/* harmony import */ var _common_ProgressBar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../common/ProgressBar */ "./src/common/ProgressBar.js");


const icons = {
  question: 'glyphicon-question-sign',
  wait: 'glyphicon-hourglass',
  wrench: 'glyphicon-wrench',
  import: 'glyphicon-import',
  download: 'glyphicon-download-alt',
  chart: 'glyphicon-signal'
};
function Modal({
  message,
  children,
  onClose,
  icon = 'question'
}) {
  if (Array.isArray(message) == false) {
    message = [message];
  }

  const content = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "ses-modal-content"
  }, children);
  const modal = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("section", {
    className: "ses-modal"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "ses-modal-window"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "ses-modal-message"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", null, icon && (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("i", {
    className: `glyphicon ${icons[icon]} ses-modal-icon`
  })), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", null, message.map(m => (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("p", null, m)))), content, onClose !== undefined ? (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "ses-modal-close"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("a", {
    href: "javascript:void(0);",
    onClick: onClose
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("i", {
    class: "glyphicon glyphicon-remove",
    style: {
      color: 'red'
    }
  }))) : null));
  modal._content = content;
  return modal;
}
function ModalControls({
  children
}) {
  return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("table", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tbody", null, children));
}
function ModalOption({
  icon = null,
  onClick,
  children
}) {
  return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tr", {
    className: "ses-modal-active",
    onClick: onClick
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, icon), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, children));
}
/**
 * 
 * @param {string} message 
 * @param {HTMLElement | Array<HTMLElement>} children 
 * @param {Boolean} canClose 
 * @returns {InteractiveModal}
 */

function createModal(message, children, canClose = true, icon = 'question') {
  /** @type {InteractiveModal} */
  const modal = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(Modal, {
    message: message,
    onClose: canClose ? close : undefined,
    icon: icon
  }, children);

  if (canClose) {
    modal.addEventListener('click', onClick);
  }

  modal.close = close;
  modal.onClose = null;
  document.body.appendChild(modal);
  const div = modal.children[0];
  adjustPosition();
  const resizeObserver = new ResizeObserver(adjustPosition);
  resizeObserver.observe(modal._content);
  window.addEventListener('resize', adjustPosition);
  return modal;

  function onClick(e) {
    if (e.target === modal) {
      close();
    }
  }

  function close(propagate = true) {
    window.removeEventListener('resize', adjustPosition);
    resizeObserver.disconnect();
    modal.remove();

    if (typeof modal.onClose == 'function' && propagate) {
      modal.onClose();
    }
  }

  function adjustPosition() {
    const newTop = (modal.offsetHeight - div.offsetHeight) / 3;
    div.style['margin-top'] = newTop + 'px';
  }
}
/**
 * @param {string} message 
 * @param {HTMLElement | Array<HTMLElement>} content 
 * @param {Array<OptionDescriptor>} options 
 * @param {Boolean} canClose 
 * @returns {Promise<boolean>}
 */

function createDialog(message, content, options, canClose = true, icon = 'question') {
  return new Promise((resolve, reject) => {
    const controls = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(ModalControls, null, options.map(createOption.bind(null, onConfirm, onCancel)));
    const modal = createModal(message, [content, controls].flat(1), canClose, icon);

    modal.onClose = () => resolve(false);

    function onConfirm() {
      modal.close(false);
      resolve(true);
    }

    function onCancel() {
      modal.close(false);
      resolve(false);
    }
  });
}
/**
 * @param {Function} onConfirm 
 * @param {Function} onCancel 
 * @param {OptionDescriptor | OptionEntry} option 
 * @returns {ModalOption}
 */

function createOption(onConfirm, onCancel, option, optionIndex) {
  const {
    icon = null,
    label,
    role,
    onClick,
    confirmCheck
  } = Array.isArray(option) ? {
    icon: option[0],
    label: option[1],
    role: option[2],
    onClick: option[2]
  } : option;
  return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(ModalOption, {
    icon: icon,
    onClick: callback
  }, label);

  function callback(event) {
    if (role == 'ok') {
      if (typeof confirmCheck == 'function' && confirmCheck() != true) {
        return;
      }

      onConfirm();
    } else if (role == 'cancel') {
      onCancel();
    }

    if (typeof onClick == 'function') {
      onClick(event, optionIndex);
    }
  }
}
/**
 * @param {Array<string> | string} messages 
 * @returns {{nextBar: Function} & InteractiveModal}
 */


function createLoadingModal(messages) {
  if (Array.isArray(messages) == false) {
    messages = [messages];
  }

  const bars = messages.map(m => (0,_common_ProgressBar__WEBPACK_IMPORTED_MODULE_1__["default"])(400, m, onFinish));
  let finished = 0;
  let current = 0;
  const modal = createModal(bars, null, false, 'wait');
  modal.nextBar = nextBar;
  return modal;

  function nextBar() {
    if (current < bars.length) {
      return bars[current++].onProgress;
    } else {
      return null;
    }
  }

  function onFinish() {
    finished++;

    if (finished == bars.length) {
      modal.close();
    }
  }
}
/**
 * @typedef {Object} OptionDescriptor
 * @property {HTMLElement} [icon=null]
 * @property {string} label
 * @property {"ok" | "cancel"} [role=]
 * @property {Function} [onClick=]
 */

/**
 * @typedef {[HTMLElement | null, string, "ok" | "cancel" | undefined | Function]} OptionEntry
 */

/**
 * @typedef {Object} InteractiveModal
 * @property {Function} close
 * @property {(event: Event, optionIndex: number) => {}} [onClose=null]
 */

/***/ }),

/***/ "./src/common/ProgressBar.js":
/*!***********************************!*\
  !*** ./src/common/ProgressBar.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ProgressBar)
/* harmony export */ });
/* harmony import */ var _util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/jsx-render-mod/dom */ "./src/util/jsx-render-mod/dom.js");

/**
 * @param {number} width 
 * @param {string} label 
 * @returns {ProgressBarElement}
 */

function ProgressBar(width, label, onFinish) {
  const percent = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", null, "0%");
  /** @type {ProgressBarElement} */

  const bar = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
    style: {
      padding: '0 0.5em',
      display: 'inline-block',
      width: width + 'px',
      background: 'linear-gradient(to right, #ffa000 0%, #eee 0)'
    }
  }, percent, label ? ` ${label}` : null);
  bar.onProgress = onProgress;
  return bar;

  function onProgress(completed, total) {
    const progress = total == 0 ? 100 : Math.floor(completed / total * 100);
    percent.textContent = progress + '%';
    bar.style.background = `linear-gradient(to right, #ffa000 ${progress}%, #eee 0)`;

    if ((total == 0 || completed == total) && typeof onFinish == 'function') {
      onFinish();
    }
  }
}
/**
 * @typedef {ProgressBarSpan & HTMLSpanElement} ProgressBarElement
 * @property {Function} onProgress
 */

/**
 * @typedef {Object} ProgressBarSpan
 * @property {Function} onProgress
 */

/***/ }),

/***/ "./src/payments/data/payments.js":
/*!***************************************!*\
  !*** ./src/payments/data/payments.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "clearPaymentsCache": () => (/* binding */ clearPaymentsCache),
/* harmony export */   "getPayments": () => (/* binding */ getPayments),
/* harmony export */   "parseAndDownloadReport": () => (/* binding */ parseAndDownloadReport)
/* harmony export */ });
/* harmony import */ var _util_api_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../util/api-connect */ "./src/util/api-connect.js");
/* harmony import */ var _util_data_connect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../util/data-connect */ "./src/util/data-connect.js");
/* harmony import */ var _util_parse__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../util/parse */ "./src/util/parse.js");
/* harmony import */ var _util_util__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../util/util */ "./src/util/util.js");



 //TODO: Extract into Payments Business service on the API side

/**
 * @typedef {Object} InstanceReference
 * @property {number} Id
 * @property {string} NameBg
 * @property {string} NameEn
 */

/**
 * @param {Array<InstanceReference>} items 
 * @param {import('../../util/util').OnProgressFunction} onChange 
 * @returns {Promise<Array<{instance: InstanceReference, payments: Array<SUPayment>}>>}
 */

async function getPayments(items, onChange) {
  const instances = items.reduce(_util_parse__WEBPACK_IMPORTED_MODULE_2__.toAssocArray, {});
  const products = await getProducts(instances);
  const packages = await getPackages(instances, products); // This pause facilitates the progress bar updater

  await new Promise(resolve => setTimeout(resolve, 10));
  const paymentsByInstanceId = (await (0,_util_util__WEBPACK_IMPORTED_MODULE_3__.distribute)(Object.values(packages).map(cachedPayments), onChange, 300)).map(r => r.Data).reduce((a, c) => {
    c.map(i => parsePayment(packages, i, a));
    return a;
  }, {}); //filter payments to 1 per user per level instance, to remove extra installment payments

  Object.keys(paymentsByInstanceId).forEach(k => {
    paymentsByInstanceId[k] = Array.from(paymentsByInstanceId[k].values());
  });
  const payments = Object.entries(paymentsByInstanceId).map(([InstanceId, payments]) => ({
    instance: instances[InstanceId],
    payments
  }));
  return payments;
}
/**
 * @typedef {Object} ProductViewModel
 * @property {number} Id
 * @property {number} EducationalForm
 * @property {number} LevelInstanceId
 * @property {string} NameBg
 * @property {string} NameEn
 * @property {string} Name
 */

/**
 * @param {Object.<number, InstanceReference>} instances 
 * @returns {Promise<Object.<number, ProductViewModel>>}
 */

async function getProducts(instances) {
  return (await _util_api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getProductsForModule(Object.keys(instances))).Data.map(e => ({
    Id: e.Id,
    EducationalForm: e.EducationalForm,
    LevelInstanceId: e.LevelInstanceId,
    NameBg: instances[e.LevelInstanceId].NameBg,
    NameEn: instances[e.LevelInstanceId].NameEn,
    Name: e.Name
  })).reduce(_util_parse__WEBPACK_IMPORTED_MODULE_2__["default"].toAssocArray, {});
}
/**
 * @typedef {Object} PackageViewModel
 * @property {number} Id
 * @property {number} EducationalForm
 * @property {number} LevelInstanceId
 * @property {string} NameBg
 * @property {string} NameEn
 * @property {string} Name
 */

/**
 * @param {Object.<number, InstanceReference>} instances 
 * @param {Object.<number, ProductViewModel>} products 
 * @returns {Promise<Object.<number, PackageViewModel>>}
 */


async function getPackages(instances, products) {
  return (await _util_api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getPackagesForProduct(Object.keys(products))).Data.map(p => ({
    Id: p.Id,
    EducationalForm: p.EducationalForm,
    LevelInstanceId: products[p.Product.Id].LevelInstanceId,
    NameBg: instances[products[p.Product.Id].LevelInstanceId].NameBg,
    NameEn: instances[products[p.Product.Id].LevelInstanceId].NameEn,
    Name: p.Name
  })).reduce(_util_parse__WEBPACK_IMPORTED_MODULE_2__["default"].toAssocArray, {});
}
/**
 * @param {Object.<number, PackageViewModel>} packages 
 * @param {*} payment 
 * @param {Object.<number, []>} accumulator 
 */


function parsePayment(packages, payment, accumulator) {
  try {
    let packageId = payment.PaymentPackages[0].Id; // Check if another package with the same name exists (in case the package was deleted and recreated for some reason)

    if (!packages[packageId]) {
      let packagesWithSameName = Object.values(packages).filter(p => p.Name === payment.PaymentPackages[0].Name);

      if (packagesWithSameName.length > 0) {
        packageId = packagesWithSameName[0].Id;
      }
    }

    if (!packages[packageId]) {
      // Handle missing payment package
      const module = accumulator['missing'];
      payment.EducationalForm = 0;
      payment.LevelInstanceId = 0;
      payment.ModuleNameBg = 'missing';
      payment.ModuleNameEn = 'missing';

      if (module === undefined) {
        accumulator['missing'] = [payment];
      } else {
        module.push(payment);
      }

      return;
    }

    const moduleId = packages[packageId].LevelInstanceId;
    const module = accumulator[moduleId];
    payment.EducationalForm = packages[packageId].EducationalForm;
    payment.LevelInstanceId = packages[packageId].LevelInstanceId;
    payment.ModuleNameBg = packages[packageId].NameBg;
    payment.ModuleNameEn = packages[packageId].NameEn;

    if (module === undefined) {
      accumulator[moduleId] = new Map([[payment.PaidForUserName, payment]]);
    } else {
      if (module.get(payment.PaidForUserName) === undefined) {
        module.set(payment.PaidForUserName, payment);
      }
    }
  } catch (e) {
    console.warn('Unable to process payment', payment);
  }
}

const paymentsCache = [];
/**
 * 
 * @param {PackageViewModel} p 
 * @returns {Promise<SUResponse<SUPayment>>}
 */

function cachedPayments(p) {
  return () => {
    const name = p.Name;
    const storeName = _util_data_connect__WEBPACK_IMPORTED_MODULE_1__.stores.PAYMENTS + (0,_util_util__WEBPACK_IMPORTED_MODULE_3__.getSubsite)() + name;
    paymentsCache.push(storeName);
    return (0,_util_data_connect__WEBPACK_IMPORTED_MODULE_1__.withCache)(_util_api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getPaymentsForPackage, storeName, 1800)(name);
  };
} /// TODO maybe add button to clear all cache


function clearPaymentsCache() {
  paymentsCache.forEach(c => (0,_util_data_connect__WEBPACK_IMPORTED_MODULE_1__.clearCache)(c));
  paymentsCache.length = 0;
}
/**
 * @param {Array<SUPayment>} payments 
 * @param {string} year 
 * @param {string} month 
 */

async function parseAndDownloadReport(payments, year, month) {
  (0,_util_util__WEBPACK_IMPORTED_MODULE_3__.exportPaymentsToXlsx)(_util_parse__WEBPACK_IMPORTED_MODULE_2__["default"].paymentsToMatrix(payments), year, month);
}

/***/ }),

/***/ "./src/survey/Details.js":
/*!*******************************!*\
  !*** ./src/survey/Details.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Details)
/* harmony export */ });
/* harmony import */ var _util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/jsx-render-mod/dom */ "./src/util/jsx-render-mod/dom.js");
/* harmony import */ var _common_Modal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../common/Modal */ "./src/common/Modal.js");
/* harmony import */ var _util_template__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../util/template */ "./src/util/template.js");



function Details({
  survey,
  summary,
  getAdvancedSummary
}) {
  // console.log(summary);
  let rawSummary = summary;
  let moduleBreakdownDiv = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("a", {
    className: "nav-back-link",
    href: "javascript:void(0)",
    onClick: async () => await replaceSummary(survey)
  }, "Load Module/Course Breakdown"));
  let summaryTable = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("table", {
    className: "survey-table"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tbody", null, summary.map(Section)));
  let detailsContainer = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", null, moduleBreakdownDiv, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("a", {
    id: "ses-survey-raw",
    className: "nav-back-link",
    href: "javascript:void(0)",
    onClick: () => console.log(survey, rawSummary)
  }, "Log Raw Data"), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("p", null, "Survey participants: ", summary.participants), summaryTable));
  return detailsContainer;

  async function replaceSummary(survey) {
    const loader = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_2__.DownloadProgressBar, {
      downloadFunction: onProgress => getAdvancedSummary(survey, onProgress),
      returnFunction: afterDownload
    }); // let advancedSummary = await getAdvancedSummary(survey);

    moduleBreakdownDiv = (0,_util_template__WEBPACK_IMPORTED_MODULE_2__.replaceContents)(moduleBreakdownDiv, loader);

    async function afterDownload(advancedSummary) {
      rawSummary = advancedSummary; // console.log(advancedSummary);

      summaryTable.removeChild(summaryTable.firstElementChild);
      summaryTable.appendChild((0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tbody", null, advancedSummary.map(Section))));
      (0,_util_template__WEBPACK_IMPORTED_MODULE_2__.swap)(moduleBreakdownDiv, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__.Fragment, null));
    }
  }
}

function Section(section) {
  let mean = null;
  let summaryInstance = section.exclSummaryByInstance ? section.exclSummaryByInstance : section.summaryByInstance;

  if (section.exclMean && section.exclMean != section.mean) {
    mean = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
      className: "average"
    }, "Average: ", section.exclMean, " ", (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
      className: "average-untracked"
    }, "(", section.mean, ")"));
  } else if (section.mean) {
    mean = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
      className: "average"
    }, "Average: ", section.mean);
  }

  let breakdownMeans = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, summaryInstance !== undefined ? Object.entries(summaryInstance).sort(([aKey, aValue], [bKey, bValue]) => aValue.instanceType?.localeCompare(bValue.instanceType)).map(([iKey, iValue]) => (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("abbr", {
    title: `${iKey}\nParticipants: ${iValue.count}`
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
    className: "average",
    style: {
      'background-color': iValue.instanceType?.startsWith('Module') ? 'purple' : iValue.instanceType?.startsWith('Open') ? 'navy' : 'darkred'
    }
  }, iValue.mean || 'N/A'))) : '');
  return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tr", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("h3", null, section.name, mean, breakdownMeans), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("table", {
    className: "nested-table"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tbody", null, section.questions.map(createQuestion)))));
}

function createQuestion(question) {
  if (question.type === 'free') {
    return FreeQuestion(question);
  } else if (question.type === 'choice') {
    return ChoiceQuestion(question);
  } else {
    return Question(question);
  }
}
/**
 * @param {import('./stats').SummarizedQuestion} question 
 * @returns {DocumentFragment}
 */


function FreeQuestion(question) {
  let showAdvancedBreakdown = question.instances !== undefined;
  return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tr", {
    className: "question"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, question.name)), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tr", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "comments"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("a", {
    className: "commentsToggle",
    href: "javascript:void(0)",
    onClick: toggleComments
  }, "Show ", question.answers.length, " comments"), showAdvancedBreakdown ? question.instances.map(i => (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
    className: "ses-sub-heading"
  }, i.name), i.answers.map(answer => (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "freeText"
  }, answer.text, " ", (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("abbr", {
    title: answer.related.map(r => ({
      name: r.name,
      questions: r.questions.filter(q => q.type == 'scale' && Number.isFinite(q.feedback))
    })).filter(r => r.questions.length > 0).map(r => `${r.name}\n${r.questions.map(q => ` - ${q.name.trim()} [${q.feedback}]`).join('\n')}`).join('\n\n')
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("i", {
    onClick: () => showDetails(answer.index, answer.related),
    class: "glyphicon glyphicon-info-sign"
  })))))) : question.answers.map(answer => (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "freeText"
  }, answer.text, " ", (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("abbr", {
    title: answer.related.map(r => ({
      name: r.name,
      questions: r.questions.filter(q => q.type == 'scale' && Number.isFinite(q.feedback))
    })).filter(r => r.questions.length > 0).map(r => `${r.name}\n${r.questions.map(q => ` - ${q.name.trim()} [${q.feedback}]`).join('\n')}`).join('\n\n')
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("i", {
    onClick: () => showDetails(answer.index, answer.related),
    class: "glyphicon glyphicon-info-sign"
  }))))))));

  function toggleComments(e) {
    if (e.target.parentNode.classList.contains('comments')) {
      e.target.parentNode.classList.remove('comments');
      e.target.textContent = 'Hide' + e.target.textContent.substr(4);
    } else {
      e.target.parentNode.classList.add('comments');
      e.target.textContent = 'Show' + e.target.textContent.substr(4);
    }
  }
}

function ChoiceQuestion(question) {
  let showAdvancedBreakdown = question.instances !== undefined;
  return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tr", {
    className: "question"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, question.name)), question.answers.map(answer => (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tr", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
    className: "bar",
    style: {
      background: `linear-gradient(to right, #ffa000 ${answer.fraction}%, #eee 0)`
    }
  }, answer.fraction, "% (", answer.count, ")"), showAdvancedBreakdown ? question.instances.sort((a, b) => a.instanceType?.localeCompare(b.instanceType)).map(i => {
    let instanceAnswer = i.answers.find(a => a.name === answer.name) ?? {
      name: answer.name,
      value: answer.value,
      count: 0,
      fraction: 0
    };
    return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("abbr", {
      title: `${i.name}`
    }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
      className: "bar",
      style: {
        background: `linear-gradient(to right, ${i.instanceType?.startsWith('Module') ? 'rgba(128,0,128,0.5)' : i.instanceType?.startsWith('Open') ? 'rgba(0,0,128,0.35)' : 'rgba(128,0,0,0.35)'} ${instanceAnswer.fraction}%, #eee 0)`
      }
    }, instanceAnswer.fraction, "% (", instanceAnswer.count, ")")));
  }) : '', answer.name))));
}

function Question(question) {
  let showAdvancedBreakdown = question.summaryByInstance !== undefined;
  return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tr", {
    className: "question"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, question.name, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
    className: question.summarize ? 'average' : 'average-untracked'
  }, " Average: ", question.mean), showAdvancedBreakdown ? Object.entries(question.summaryByInstance).sort(([aKey, aValue], [bKey, bValue]) => aValue.instanceType?.localeCompare(bValue.instanceType)).map(([iKey, iValue]) => (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("abbr", {
    title: `${iKey}\nParticipants: ${iValue.count}`
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
    className: "average",
    style: {
      'background-color': iValue.instanceType?.startsWith('Module') ? 'purple' : iValue.instanceType?.startsWith('Open') ? 'navy' : 'darkred'
    }
  }, iValue.mean || 'N/A'))) : '')), question.answers.map(answer => (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tr", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
    className: "bar",
    style: {
      background: `linear-gradient(to right, #ffa000 ${answer.fraction}%, #eee 0)`
    }
  }, answer.fraction, "% (", answer.count, ")"), showAdvancedBreakdown ? question.instances.map(i => {
    let instanceAnswer = i.answers.find(a => a.name === answer.name) ?? {
      name: answer.name,
      value: answer.value,
      count: 0,
      fraction: 0
    };
    return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("abbr", {
      title: `${i.name}`
    }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
      className: "bar",
      style: {
        background: `linear-gradient(to right, ${i.instanceType?.startsWith('Module') ? 'rgba(128,0,128,0.5)' : i.instanceType?.startsWith('Open') ? 'rgba(0,0,128,0.35)' : 'rgba(128,0,0,0.35)'} ${instanceAnswer.fraction}%, #eee 0)`
      }
    }, instanceAnswer.fraction, "% (", instanceAnswer.count, ")")));
  }) : '', answer.name))));
}

function showDetails(index, related) {
  (0,_common_Modal__WEBPACK_IMPORTED_MODULE_1__.createDialog)('Детайлна обратна връзка от потребител ' + index, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    className: "ses-scroll"
  }, related.map(r => (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("h3", null, r.name), r.questions.map(q => (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("p", {
    style: {
      fontWeight: 'bold'
    }
  }, q.name), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("p", {
    style: {
      'background-color': 'rgb(238, 238, 238)'
    }
  }, q.feedback == undefined ? (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("i", {
    class: "glyphicon glyphicon-minus"
  }) : q.feedback)))))), [[(0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_2__.Yes, null), 'Обратно', 'ok']], true, null);
}

/***/ }),

/***/ "./src/survey/Summary.js":
/*!*******************************!*\
  !*** ./src/survey/Summary.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Summary)
/* harmony export */ });
/* harmony import */ var _util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/jsx-render-mod/dom */ "./src/util/jsx-render-mod/dom.js");
/* harmony import */ var _util_template__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/template */ "./src/util/template.js");
/* harmony import */ var _util_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../util/router */ "./src/util/router.js");
/* harmony import */ var _util_parse__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../util/parse */ "./src/util/parse.js");
/* harmony import */ var _data_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./data.js */ "./src/survey/data.js");
/* harmony import */ var _util_util__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../util/util */ "./src/util/util.js");






function Summary({
  page,
  pages,
  surveys,
  pageSelect,
  getDetails,
  getSummary,
  getAdvancedSummary,
  getFinalizedSurveysExport,
  searchInput,
  searchQuery
}) {
  searchQuery = searchQuery ? `&search=${encodeURIComponent(searchQuery)}` : ''; // let exportAllCheckbox = (<input id="ses-export-all" type="checkbox" onChange={toggleExportAll} />);

  let dateFromInput = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("input", {
    id: "ses-date-from",
    class: "ses-date-input date-from",
    placeholder: "YYYY-MM-DD",
    pattern: "\\d{4}-\\d{2}-\\d{2}"
  });
  let dateToInput = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("input", {
    id: "ses-date-to",
    class: "ses-date-input date-to",
    placeholder: "YYYY-MM-DD",
    pattern: "\\d{4}-\\d{2}-\\d{2}"
  });
  let exportsFinalGradesDropdown = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    class: "ses-export-final-grades-dropdown hidden"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("label", {
    for: "ses-date-from"
  }, "From"), dateFromInput, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("label", {
    for: "ses-date-to"
  }, "To"), dateToInput, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("button", {
    onClick: exportFinalSurveyGrades
  }, "Export"));
  let exportControls = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    class: "ses-export-controls"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    class: "ses-exports-btn-section"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("button", {
    class: "ses-export-final-grades-btn",
    onClick: toggleExportFinalGradesDropdown
  }, "Export Final Survey Grades")), exportsFinalGradesDropdown);
  return (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    class: "ses-controls"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    class: "ses-pager-container"
  }, page > 1 && (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_router__WEBPACK_IMPORTED_MODULE_2__.Link, {
    to: pageSelect,
    className: "ses-pager-button",
    href: `/ses/surveys?page=${page - 1}${searchQuery}`
  }, "< Prev"), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
    className: "ses-pager"
  }, page, " of ", pages), page < pages && (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_router__WEBPACK_IMPORTED_MODULE_2__.Link, {
    to: pageSelect,
    className: "ses-pager-button",
    href: `/ses/surveys?page=${page + 1}${searchQuery}`
  }, "Next >")), exportControls), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("table", {
    class: "data-table"
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("thead", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tr", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("th", null, searchInput), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("th", null, "Aggregate"), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("th", null, "Active From"), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("th", null, "Expires"))), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tbody", null, surveys.map(e => Row(e, getDetails, getSummary, getAdvancedSummary)))), page > 1 && (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_router__WEBPACK_IMPORTED_MODULE_2__.Link, {
    to: pageSelect,
    className: "ses-pager-button",
    href: `/ses/surveys?page=${page - 1}${searchQuery}`
  }, "< Prev"), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
    className: "ses-pager"
  }, page, " of ", pages), page < pages && (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_router__WEBPACK_IMPORTED_MODULE_2__.Link, {
    to: pageSelect,
    className: "ses-pager-button",
    href: `/ses/surveys?page=${page + 1}${searchQuery}`
  }, "Next >")); // function toggleExportAll() {
  //     if (exportAllCheckbox.checked) {
  //         dateFromInput.disabled = true;
  //         dateToInput.disabled = true;
  //     } else {
  //         dateFromInput.disabled = false;
  //         dateToInput.disabled = false;
  //     }
  // }

  function toggleExportFinalGradesDropdown() {
    exportsFinalGradesDropdown.classList.toggle('hidden');
  }

  async function exportFinalSurveyGrades() {
    console.log('trigger export');
    let dateFromValue = dateFromInput.value;
    let dateToValue = dateToInput.value;
    let baseStartDate = `${dateFromValue}T00-00-00`;
    let baseEndDate = `${dateToValue}T00-00-00`;
    let dateFrom = Date.parse(`${dateFromValue}T00:00:00`);
    let dateFromDate = new Date(dateFrom);
    let dateTo = Date.parse(`${dateToValue}T00:00:00`);
    let dateToDate = new Date(dateTo);
    let diff = Math.abs(dateTo - dateFrom);
    let differenceInDays = Math.round(diff / (1000 * 3600 * 24));
    let loops = differenceInDays / 180;
    let totalLoops = Math.ceil(loops);

    for (let index = 0; index < totalLoops; index++) {
      let startDate = new Date(dateFrom);
      let endDate = new Date(dateFrom);
      startDate.setDate(dateFromDate.getDate() + index * 180); // endDate.setDate(dateFromDate.getDate() + ((index + 1) * 180));

      if (index === totalLoops - 1) {
        endDate = new Date(dateTo);
      } else {
        endDate.setDate(dateFromDate.getDate() + (index + 1) * 180);
      }

      let baseStartDateString = `${startDate.getFullYear()}-${(startDate.getMonth() + 1).toString().padStart(2, '0')}-${startDate.getDate().toString().padStart(2, '0')}`;
      let baseEndDateString = `${endDate.getFullYear()}-${(endDate.getMonth() + 1).toString().padStart(2, '0')}-${endDate.getDate().toString().padStart(2, '0')}`;
      let startDateString = `${baseStartDateString}T00-00-00`;
      let endDateString = `${baseEndDateString}T00-00-00`;
      let afterDownloadFunc = undefined;
      let exportCompletePromise = new Promise((resolve, reject) => {
        afterDownloadFunc = async function (results) {
          let excelFile = (0,_util_util__WEBPACK_IMPORTED_MODULE_5__.toXlsxFile)(results, `SurveysFinal_${baseStartDateString}-${baseEndDateString}`, 'Surveys');
          (0,_util_util__WEBPACK_IMPORTED_MODULE_5__.openFile)(excelFile, excelFile.name);
          loader.remove();
          await new Promise(r => setTimeout(r, 2000));
          resolve();
        };
      });
      const loader = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", {
        colspan: "4"
      }, "Loading summary \u2026 ", (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_1__.Loading, {
        color: "black"
      }), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_1__.DownloadProgressBar, {
        downloadFunction: onProgress => getFinalizedSurveysExport(startDateString, endDateString, onProgress),
        returnFunction: afterDownloadFunc
      }));
      exportControls.appendChild(loader);
      await exportCompletePromise;
    }
  }
}

function Row(entry, getDetails, getSummary, getAdvancedSummary) {
  const from = _util_parse__WEBPACK_IMPORTED_MODULE_3__["default"].formatDate(new Date(entry.ActiveFrom));
  const now = new Date();
  const activeToDate = new Date(entry.ActiveTo);
  const diff = _util_parse__WEBPACK_IMPORTED_MODULE_3__["default"].dateDiff(activeToDate, now);
  const to = _util_parse__WEBPACK_IMPORTED_MODULE_3__["default"].dateDiffToDays(diff);
  const hasActiveToPassed = activeToDate < now;
  const recentlyPassed = diff <= 7 && diff >= 0 && hasActiveToPassed;
  let summarized = false;
  let summaryRow;
  const summaryBtn = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("a", {
    className: "summary-link",
    href: "javascript:void(0)",
    onClick: toggleSummary
  }, "View Summary");
  const element = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tr", {
    "data-surveyid": entry.Id,
    title: recentlyPassed ? 'Recently finished' : '',
    className: recentlyPassed ? 'highlight' : ''
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_router__WEBPACK_IMPORTED_MODULE_2__.Link, {
    to: getDetails,
    className: "survey-link",
    href: `?id=${entry.Id}`
  }, entry.Name)), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, summaryBtn), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, from), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", null, to));
  return element;

  async function toggleSummary() {
    if (summarized) {
      summarized = false;
      summaryBtn.textContent = 'View Summary';
      summaryRow.remove();
    } else {
      summarized = true;
      summaryBtn.textContent = 'Hide Summary';
      summaryRow = summaryRow || (await createSummary());
      const table = element.parentNode;
      table.insertBefore(summaryRow, element.nextSibling);
    }
  }

  async function createSummary() {
    // const loader = <td colspan="4">Loading summary &hellip; <Loading color="black" /></td>;
    const summaryRow = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("tr", null);
    replaceSummaryData(summaryRow);
    return summaryRow;
  }

  async function replaceSummaryData(summaryRow, withModuleBreakdown = false) {
    let summaryMethod = withModuleBreakdown ? getAdvancedSummary : getSummary;
    const loader = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", {
      colspan: "4"
    }, "Loading summary \u2026 ", (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_1__.Loading, {
      color: "black"
    }), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_1__.DownloadProgressBar, {
      downloadFunction: onProgress => summaryMethod(entry, onProgress),
      returnFunction: afterDownload
    }));

    if (summaryRow.firstElementChild) {
      summaryRow.removeChild(summaryRow.firstElementChild);
    }

    summaryRow.appendChild(loader);

    async function afterDownload(summary) {
      let lecturerCount = 0;
      let lecturerSum = 0;
      let numberOfLecturers = 0;
      let lecturerSummaryInstance = undefined;
      let included = summary.filter(s => s.summarize);

      if (included.length == 0) {
        included = summary;
      } // console.log(summary);


      const content = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("td", {
        colspan: "4"
      }, withModuleBreakdown == true ? '' : (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("a", {
        className: "summary-link",
        href: "javascript:void(0)",
        onClick: () => replaceSummaryData(summaryRow, true)
      }, "Load Module Breakdown")), included.map(section => {
        let result = null;
        let summaryInstance = section.exclSummaryByInstance ? section.exclSummaryByInstance : section.summaryByInstance;

        if (section.lecturer) {
          lecturerCount += section.exclCount || section.count;
          lecturerSum += section.exclCount * section.exclMean || section.count * section.mean;
          section.name = section.name.split(' - ')[0];
          numberOfLecturers++;

          if (withModuleBreakdown) {
            if (lecturerSummaryInstance == undefined) {
              lecturerSummaryInstance = {};
            }

            Object.keys(summaryInstance).forEach(k => {
              if (lecturerSummaryInstance[k] == undefined) {
                lecturerSummaryInstance[k] = {
                  lecturersAvg: 0,
                  lecturersCount: 0
                };
              }

              lecturerSummaryInstance[k].lecturersAvg += summaryInstance[k].avg;
              lecturerSummaryInstance[k].lecturersCount += summaryInstance[k].count;
              lecturerSummaryInstance[k].instanceType = summaryInstance[k].instanceType;
            });
          }
        }

        result = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
          className: "ses-survey"
        }, section.name, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("abbr", {
          title: "Total"
        }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
          className: "average"
        }, section.exclMean || section.mean || 'N/A')), summaryInstance !== undefined ? Object.entries(summaryInstance).sort(([aKey, aValue], [bKey, bValue]) => (aValue.instanceType ?? '').localeCompare(bValue.instanceType ?? '')).map(([iKey, iValue]) => (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("abbr", {
          title: `${iKey}\nParticipants: ${iValue.count}`
        }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
          className: "average",
          style: {
            'background-color': iValue.instanceType?.startsWith('Module') ? 'purple' : iValue.instanceType?.startsWith('Open') ? 'navy' : 'darkred'
          }
        }, iValue.mean || 'N/A'))) : '');
        return result;
      }), lecturerCount > 0 && (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
        className: "ses-survey"
      }, "Lecturer average", (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("abbr", {
        title: "Total"
      }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
        className: "average"
      }, Number((lecturerSum / lecturerCount).toFixed(2)))), lecturerSummaryInstance !== undefined ? Object.entries(lecturerSummaryInstance).sort(([aKey, aValue], [bKey, bValue]) => (aValue.instanceType ?? '').localeCompare(bValue.instanceType ?? '')).map(([iKey, iValue]) => (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("abbr", {
        title: `${iKey}\n${iValue.lecturersCount} votes over ${numberOfLecturers} questions`
      }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
        className: "average",
        style: {
          'background-color': iValue.instanceType?.startsWith('Module') ? 'purple' : iValue.instanceType?.startsWith('Open') ? 'navy' : 'darkred'
        }
      }, Number((iValue.lecturersAvg / iValue.lecturersCount).toFixed(2)) || 'N/A'))) : ''), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
        className: "ses-survey"
      }, "Participants: ", summary.participants));
      loader.remove();
      summaryRow.appendChild(content);
    }
  }
}

/***/ }),

/***/ "./src/survey/data.js":
/*!****************************!*\
  !*** ./src/survey/data.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getAdvancedSummary": () => (/* binding */ getAdvancedSummary),
/* harmony export */   "getAllSurveys": () => (/* binding */ getAllSurveys),
/* harmony export */   "getFinalizedSurveysExport": () => (/* binding */ getFinalizedSurveysExport),
/* harmony export */   "getSummary": () => (/* binding */ getSummary),
/* harmony export */   "getSurveyAnswersBySurveyId": () => (/* binding */ getSurveyAnswersBySurveyId),
/* harmony export */   "getSurveyById": () => (/* binding */ getSurveyById),
/* harmony export */   "getSurveySections": () => (/* binding */ getSurveySections),
/* harmony export */   "getSurveys": () => (/* binding */ getSurveys)
/* harmony export */ });
/* harmony import */ var _util_data_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/data-connect */ "./src/util/data-connect.js");
/* harmony import */ var _stats__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./stats */ "./src/survey/stats.js");
/* harmony import */ var _util_util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../util/util */ "./src/util/util.js");
/* harmony import */ var _payments_data_payments__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../payments/data/payments */ "./src/payments/data/payments.js");
/// <reference path="../util/api.d.ts" />




/**
 * @param {SUAPI} api 
 */

async function getSurveys(api, page, query) {
  return (0,_util_data_connect__WEBPACK_IMPORTED_MODULE_0__.withCache)(api.getSurveys, _util_data_connect__WEBPACK_IMPORTED_MODULE_0__.stores.SURVEYS + (0,_util_util__WEBPACK_IMPORTED_MODULE_2__.getSubsite)() + query + page, 3600)(page, query);
}
/**
 * @param {SUAPI} api 
 */

async function getAllSurveys(api, page, query, startDate, endDate, pageSize) {
  return (0,_util_data_connect__WEBPACK_IMPORTED_MODULE_0__.withCache)(api.getSurveysByNameAndStartAndEndDate, _util_data_connect__WEBPACK_IMPORTED_MODULE_0__.stores.SURVEYS_ALL + (0,_util_util__WEBPACK_IMPORTED_MODULE_2__.getSubsite)() + query + '_' + startDate + '_' + endDate, 3600)(page, query, startDate, endDate, pageSize);
}
/**
 * @param {SUAPI} api 
 */

async function getSurveyById(api, surveyId) {
  return (0,_util_data_connect__WEBPACK_IMPORTED_MODULE_0__.withCache)(api.getSurveyById, _util_data_connect__WEBPACK_IMPORTED_MODULE_0__.stores.SURVEY + (0,_util_util__WEBPACK_IMPORTED_MODULE_2__.getSubsite)() + surveyId, 3600)(surveyId);
}
/**
 * @param {SUAPI} api 
 */

async function getSurveyAnswersBySurveyId(api, surveyId) {
  return (0,_util_data_connect__WEBPACK_IMPORTED_MODULE_0__.withCache)(api.getSurveyAnswers, _util_data_connect__WEBPACK_IMPORTED_MODULE_0__.stores.SURVEY + (0,_util_util__WEBPACK_IMPORTED_MODULE_2__.getSubsite)() + surveyId + '_ANSWERS', 600)(surveyId);
}
/**
 * @param {SUAPI} api 
 */

async function getSurveySections(api, surveyId, sectionIds) {
  return (0,_util_data_connect__WEBPACK_IMPORTED_MODULE_0__.withCache)(api.getSurveySectionsById, _util_data_connect__WEBPACK_IMPORTED_MODULE_0__.stores.SURVEY + (0,_util_util__WEBPACK_IMPORTED_MODULE_2__.getSubsite)() + surveyId + '_SECTIONS', 3600)(sectionIds);
}
/**
 * @param {SUAPI} api 
 */

async function getSummary(api, survey) {
  const answers = (await getSurveyAnswersBySurveyId(api, survey.Id)).Data;
  const sections = survey.Sections.length > 0 ? (await getSurveySections(api, survey.Id, survey.Sections.map(s => s.Id))).Data : [];
  return _stats__WEBPACK_IMPORTED_MODULE_1__["default"].summarize(sections, answers);
}
/**
 * @param {SUAPI} api 
 */

async function getAdvancedSummary(api, survey, onProgress = undefined) {
  const answers = (await getSurveyAnswersBySurveyId(api, survey.Id)).Data;
  const sections = survey.Sections.length > 0 ? (await getSurveySections(api, survey.Id, survey.Sections.map(s => s.Id))).Data : []; //TODO: switch to getting course instance from survey property, when it's correctly added to survey and use getting by name as a fallback

  let surveyCourseInstanceName = survey.Name.substring(0, survey.Name.lastIndexOf(' - ')).trim();
  let appName = (0,_util_util__WEBPACK_IMPORTED_MODULE_2__.getSubsite)(); // Cache modules for 2 hours, the actual modules will probably not be updated very often

  let modules = await (0,_util_data_connect__WEBPACK_IMPORTED_MODULE_0__.withCache)(api.getModules, `${_util_data_connect__WEBPACK_IMPORTED_MODULE_0__.stores.MODULES}-${appName}`, 7200)();
  let moduleInstances = (await (0,_util_util__WEBPACK_IMPORTED_MODULE_2__.distribute)(modules.map(x => () => (0,_util_data_connect__WEBPACK_IMPORTED_MODULE_0__.withCache)(api.getInstancesInModule, `${_util_data_connect__WEBPACK_IMPORTED_MODULE_0__.stores.MODULE_INSTANCES}-${appName}-${x.Id}`, 7200)(x.Id)), onProgress, 300)).flatMap(m => m.Data);
  let moduleInstancesWhichContainSurveyCourse = moduleInstances.reduce((a, c) => {
    if (c.CourseInstances.some(x => surveyCourseInstanceName.includes(x.trim()))) {
      a.push(c);
    }

    return a;
  }, []); // Module Instance payments

  let moduleInstancePaymentsKeyValueCollection = [];

  if (moduleInstancesWhichContainSurveyCourse.length > 0) {
    let moduleInstancePayments = await (0,_payments_data_payments__WEBPACK_IMPORTED_MODULE_3__.getPayments)(moduleInstancesWhichContainSurveyCourse); // console.log(moduleInstancePayments);

    moduleInstancePaymentsKeyValueCollection = moduleInstancePayments.flatMap(x => x.payments).map(x => {
      x.InstanceType = 'Module';
      x.InstanceName = x.ModuleNameBg;
      x.InstanceId = x.LevelInstanceId;
      return [x.PaidForUserName, x];
    });
  } // Course Instance Payments


  let trainings = await api.searchTrainingsByName(surveyCourseInstanceName);
  let courseInstancePaymentsKeyValueCollection = [];

  if (trainings.length > 0) {
    let training = trainings[0]; //TODO: Extract a payments business service to reuse it

    let courseInstanceProducts = (await api.getProductsForCourse(training.TrainingId)).Data;
    let courseInstancePackages = [];

    if (courseInstanceProducts.length > 0) {
      courseInstancePackages = (await api.getPackagesForProduct(courseInstanceProducts.map(x => x.Id))).Data;
    }

    let paymentsByInstanceId = [];

    if (courseInstancePackages.length > 0) {
      paymentsByInstanceId = (await (0,_util_util__WEBPACK_IMPORTED_MODULE_2__.distribute)(courseInstancePackages.map(x => cachedPayments(x, api)), undefined, 300)).flatMap(x => x.Data);
      console.log(paymentsByInstanceId);
    }

    courseInstancePaymentsKeyValueCollection = paymentsByInstanceId.map(x => {
      x.InstanceType = 'Open Course';
      x.InstanceName = training.NameBg;
      x.InstanceId = training.TrainingId;
      return [x.PaidForUserName, x];
    });
  } // Group Module Instance and Course Instance payments to check users against them


  let allPaymentsKeyValueCollection = moduleInstancePaymentsKeyValueCollection.concat(courseInstancePaymentsKeyValueCollection);
  let paymentsMap = new Map(allPaymentsKeyValueCollection); //Decorate payments with info about module/course

  answers.forEach(a => {
    let payment = paymentsMap.get(a.UserName);

    if (payment != undefined) {
      a.InstanceType = payment.InstanceType;
      a.InstanceName = payment.InstanceName;
      a.InstanceId = payment.InstanceId;
    }
  });
  return _stats__WEBPACK_IMPORTED_MODULE_1__["default"].summarize(sections, answers, true);
}
/**
 * @param {SUAPI} api 
 */

async function getFinalizedSurveysExport(api, startDate, endDate, onProgress = undefined) {
  const surveysRequest = await getAllSurveys(api, 1, 'финална', startDate, endDate, 10000);
  const surveys = surveysRequest.Data;
  console.log(surveys);
  let surveyAnswers = (await (0,_util_util__WEBPACK_IMPORTED_MODULE_2__.distribute)(surveys.map(x => () => getSurveyAnswersBySurveyId(api, x.Id).then(d => ({
    SurveyId: x.Id,
    Data: d.Data
  }))), onProgress, 300)).reduce((a, c) => {
    let data = c.Data;
    a[c.SurveyId] = data;
    return a;
  }, {});
  console.log(surveyAnswers);
  let surveySections = (await (0,_util_util__WEBPACK_IMPORTED_MODULE_2__.distribute)(surveys.map(x => () => x.Sections.length > 0 ? getSurveySections(api, x.Id, x.Sections.map(s => s.Id)).then(d => ({
    SurveyId: x.Id,
    Data: d.Data
  })) : Promise.resolve([])), onProgress, 300)).reduce((a, c) => {
    let data = c.Data;
    a[c.SurveyId] = data;
    return a;
  }, {});
  console.log(surveySections);
  let results = [['Survey Name', 'Active From', 'Average Grade']];
  let totalSummarize = [];

  for (const survey of surveys) {
    let key = survey.Id; // const answers = (await getSurveyAnswersBySurveyId(api, survey.Id)).Data;
    // const sections = survey.Sections.length > 0 ? (await getSurveySections(api, survey.Id, survey.Sections.map(s => s.Id))).Data : [];

    let result = _stats__WEBPACK_IMPORTED_MODULE_1__["default"].summarize(surveySections[key], surveyAnswers[key]);
    console.log(result);
    totalSummarize.push(result); // let summarizedCourseSection = result.find(x => x.name.startsWith('Въпроси за курса -'));

    let allQuestions = result.flatMap(x => x.questions);
    let summarizedGrade = [survey.Name, 'N/A', 'N/A'];
    let summarizedGradeQuestion = allQuestions.find(x => (x.name.includes('Как оценявате качеството на курса?') || x.name.includes('Каква е оценката Ви за курса като цяло?') || x.name.includes('Каква е цялостната Ви оценка за курса?') || x.name.includes('Каква е оценката Ви за провеждането на занятията?')) && x.type === 'scale');

    if (summarizedGradeQuestion) {
      summarizedGrade = [survey.Name, survey.ActiveFrom, summarizedGradeQuestion.mean];
    }

    results.push(summarizedGrade);
  }

  console.log(results);
  return results;
}
/**
 * 
 * @param {SUPackage} p 
 * @param {SUAPI} api
 * @returns {Promise<SUResponse<SUPayment>>}
 */

function cachedPayments(p, api) {
  return () => {
    const name = p.Name;
    const storeName = _util_data_connect__WEBPACK_IMPORTED_MODULE_0__.stores.PAYMENTS + (0,_util_util__WEBPACK_IMPORTED_MODULE_2__.getSubsite)() + name;
    return (0,_util_data_connect__WEBPACK_IMPORTED_MODULE_0__.withCache)(api.getPaymentsForPackage, storeName, 1800)(name);
  };
}

/***/ }),

/***/ "./src/survey/stats.js":
/*!*****************************!*\
  !*** ./src/survey/stats.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _util_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/util */ "./src/util/util.js");

const summarizable = {
  'programming': {
    templates: new Set([165, 164, 143, 142, 141, 140, 137, 134, 131, 130, 129, 127, 126, 125]),
    questions: new Set(['Как оценявате качеството на курса до момента?', 'Как оценявате качеството на курса?']),
    lecturer: new Set([136, 130])
  },
  'digital': {
    templates: new Set([61, 60, 47, 46, 45, 44, 43, 42, 39, 36, 35, 34, 32, 31, 30, 28, 27]),
    questions: new Set(['Как оценявате качеството на курса до момента?', 'Как оценявате качеството на курса?', 'What is your overall grade for the course?']),
    lecturer: new Set([35, 31, 28])
  },
  'creative': {
    templates: new Set([42, 41, 37, 36, 34, 31, 28, 27, 26, 24, 23, 22]),
    questions: new Set(['Как оценявате качеството на курса до момента?', 'Как оценявате качеството на курса?']),
    lecturer: new Set([27, 23])
  },
  'ai': {
    templates: new Set([61, 60, 47, 46, 44, 43, 42, 39, 36, 35, 34, 32, 31, 30, 28, 27]),
    questions: new Set(['Как оценявате качеството на курса до момента?', 'Как оценявате качеството на курса?', 'What is your overall grade for the course?']),
    lecturer: new Set([35, 31, 28])
  },
  'devdigital': {
    templates: new Set([61, 60, 47, 46, 45, 44, 43, 42, 39, 36, 35, 34, 32, 31, 30, 28, 27]),
    questions: new Set(['Как оценявате качеството на курса до момента?', 'Как оценявате качеството на курса?', 'What is your overall grade for the course?']),
    lecturer: new Set([35, 31, 28])
  },
  'devsoftuni': {
    templates: new Set([165, 164, 143, 142, 141, 140, 137, 134, 131, 130, 129, 127, 126, 125]),
    questions: new Set(['Как оценявате качеството на курса до момента?', 'Как оценявате качеството на курса?']),
    lecturer: new Set([136, 130])
  },
  'financeacademy': {
    templates: new Set([61, 60, 47, 46, 44, 43, 42, 39, 36, 35, 34, 32, 31, 30, 28, 27]),
    questions: new Set(['Как оценявате качеството на курса до момента?', 'Как оценявате качеството на курса?', 'What is your overall grade for the course?']),
    lecturer: new Set([35, 31, 28])
  }
};
/**
 * @typedef {Object} SurveyAnswer
 * @property {number} Id
 * @property {number} SurveyId
 * @property {string} Section
 * @property {string} Question
 * @property {string | null} Answer 
 * @property {string | null} FreeText 
 */

/**
 * @param {Array<SurveyAnswer>} answers 
 */

function summarize(sectionData, answers, breakdownByModule = false) {
  const summary = answers.reduce(breakdownByModule ? toSectionsWithModuleBreakdown : toSections, {
    sections: {},
    votes: new Set()
  });
  const result = Object.entries(summary.sections).map(breakdownByModule ? summarizeSectionWithModuleBreakdown : summarizeSection).map(s => sectionToTemplate(s, sectionData));
  result.participants = summary.votes.size;

  if (breakdownByModule) {
    createIndexWithModuleBreakdown(result);
  } else {
    createIndex(result);
  }

  return result;
} // Base summarize

/**
 * @param {Object} result 
 * @param {SurveyAnswer} answer 
 */


function toSections(result, answer) {
  result.votes.add(answer.UserName || answer.ParticipationKey);
  const section = getOrCreate(result.sections, answer.Section);
  const question = getOrCreate(section, answer.Question, {
    choices: [],
    comments: []
  });

  if (answer.Answer) {
    // add numeric grade
    question.choices.push({
      index: answer.UserName || answer.ParticipationKey,
      choice: answer.Answer
    });
  } else {
    // add free text answer
    question.comments.push({
      index: answer.UserName || answer.ParticipationKey,
      text: answer.FreeText
    });
  }

  return result;
}

function summarizeSection([sectionName, questions]) {
  const result = {
    name: sectionName
  };
  result.questions = Object.entries(questions).map(summarizeQuestion);
  const grades = result.questions.filter(q => q.type == 'scale').reduce((c, q) => Object.assign(c, {
    count: c.count + q.count,
    avg: c.avg + q.mean * q.count
  }, q.summarize ? {
    exclCount: c.exclCount + q.count,
    exclAvg: c.exclAvg + q.mean * q.count
  } : {}), {
    count: 0,
    avg: 0,
    exclCount: 0,
    exclAvg: 0
  });

  if (grades.exclCount > 0) {
    result.exclCount = grades.exclCount;
    result.exclMean = Number((grades.exclAvg / grades.exclCount).toFixed(2));
  }

  if (grades.count > 0) {
    result.count = grades.count;
    result.mean = Number((grades.avg / grades.count).toFixed(2));
  }

  return result;
}

function summarizeQuestion([questionName, question]) {
  const result = {
    name: questionName,
    summarize: summarizable[(0,_util_util__WEBPACK_IMPORTED_MODULE_0__.getSubsite)()].questions.has(questionName),
    answers: []
  };

  if (question.comments.length == 0) {
    scaleQuestion(question, result);
  } else {
    result.answers = question.comments;
    result.type = 'free';
  }

  return result;
}
/**
 * @param {Array<SummarizedSection>} summary 
 */


function createIndex(summary) {
  for (const section of summary) {
    for (const question of section.questions.filter(q => q.type == 'free')) {
      for (const answer of question.answers) {
        answer.related = summary.map(s => ({
          name: s.name,
          questions: s.questions.map(q => ({
            name: q.name,
            type: q.type,
            feedback: q.index?.[answer.index] || q.answers.filter(a => a.index == answer.index)[0]?.text
          }))
        })).filter(s => s.questions.length > 0);
      }
    }
  }
} //Summarize with Module breakdowns

/**
 * @param {Object} result 
 * @param {SurveyAnswer} answer 
 */


function toSectionsWithModuleBreakdown(result, answer) {
  result.votes.add(answer.UserName || answer.ParticipationKey);
  const section = getOrCreate(result.sections, answer.Section);
  const question = getOrCreate(section, answer.Question);
  let instanceName = answer.InstanceName ? `${answer.InstanceType}: ${answer.InstanceName}` : 'N/A';
  const instance = getOrCreate(question, instanceName, {
    choices: [],
    comments: [],
    instanceType: answer.InstanceType
  });

  if (answer.Answer) {
    // add numeric grade
    instance.choices.push({
      index: answer.UserName || answer.ParticipationKey,
      choice: answer.Answer
    });
  } else {
    // add free text answer
    instance.comments.push({
      index: answer.UserName || answer.ParticipationKey,
      text: answer.FreeText
    });
  }

  return result;
}

function summarizeSectionWithModuleBreakdown([sectionName, questions]) {
  const result = {
    name: sectionName
  };
  result.questions = Object.entries(questions).map(summarizeQuestionWithModuleBreakdown);
  const grades = result.questions.filter(q => q.type == 'scale').reduce((c, q) => {
    c.count += q.count;
    c.avg += q.mean * q.count;
    c.questionsCount++; // Breakdown summary of the section, grouped by the user's module/course

    Object.entries(q.summaryByInstance).forEach(([instanceName, instance]) => {
      if (!c.summaryByInstance[instanceName]) {
        c.summaryByInstance[instanceName] = {
          count: 0,
          avg: 0,
          instanceType: instance.instanceType
        };
      }

      c.summaryByInstance[instanceName].count += instance.count;
      c.summaryByInstance[instanceName].avg += instance.avg;
    });

    if (q.summarize) {
      c.exclCount += q.count;
      c.exclAvg += q.mean * q.count; // Breakdown summary of the section, grouped by the user's module/course

      Object.entries(q.summaryByInstance).forEach(([instanceName, instance]) => {
        if (!c.exclSummaryByInstance[instanceName]) {
          c.exclSummaryByInstance[instanceName] = {
            count: 0,
            avg: 0,
            instanceType: instance.instanceType
          };
        }

        c.exclSummaryByInstance[instanceName].count += instance.count;
        c.exclSummaryByInstance[instanceName].avg += instance.avg;
      });
    }

    return c;
  }, {
    count: 0,
    avg: 0,
    questionsCount: 0,
    summaryByInstance: {},
    exclCount: 0,
    exclAvg: 0,
    exclSummaryByInstance: {}
  });

  if (grades.exclCount > 0) {
    result.exclCount = grades.exclCount;
    result.exclMean = Number((grades.exclAvg / grades.exclCount).toFixed(2));
    result.exclSummaryByInstance = grades.exclSummaryByInstance;
    Object.keys(result.exclSummaryByInstance).forEach(key => {
      result.exclSummaryByInstance[key].mean = Number((result.exclSummaryByInstance[key].avg / result.exclSummaryByInstance[key].count).toFixed(2));
      result.exclSummaryByInstance[key].avg = result.exclSummaryByInstance[key].avg / grades.questionsCount;
      result.exclSummaryByInstance[key].count = result.exclSummaryByInstance[key].count / grades.questionsCount;
    });
  }

  if (grades.count > 0) {
    result.count = grades.count;
    result.mean = Number((grades.avg / grades.count).toFixed(2));
    result.summaryByInstance = grades.summaryByInstance;
    Object.keys(result.summaryByInstance).forEach(key => {
      result.summaryByInstance[key].mean = Number((result.summaryByInstance[key].avg / result.summaryByInstance[key].count).toFixed(2));
      result.summaryByInstance[key].avg = result.summaryByInstance[key].avg / grades.questionsCount;
      result.summaryByInstance[key].count = result.summaryByInstance[key].count / grades.questionsCount;
    });
  }

  return result;
}

function summarizeQuestionWithModuleBreakdown([questionName, instances]) {
  const result = {
    name: questionName,
    summarize: summarizable[(0,_util_util__WEBPACK_IMPORTED_MODULE_0__.getSubsite)()].questions.has(questionName),
    answers: new Map()
  };
  result.instances = Object.entries(instances).map(summarizeInstance);
  const grades = result.instances.filter(i => i.type == 'scale' || i.type == 'choice').reduce((c, i) => {
    //Total summary for question
    c.count += i.count;
    c.avg += i.mean * i.count; // Breakdown summary of the question, grouped by the user's module/course

    if (!c.summaryByInstance[i.name]) {
      c.summaryByInstance[i.name] = {
        count: 0,
        avg: 0,
        instanceType: i.instanceType
      };
    }

    c.summaryByInstance[i.name].count += i.count;
    c.summaryByInstance[i.name].avg += i.mean * i.count; // aggregate all instance answers into question answers

    i.answers.forEach(a => {
      if (result.answers.has(a.name)) {
        let currentAnswer = result.answers.get(a.name);
        currentAnswer.count += a.count;
        currentAnswer.fraction = undefined;
        result.answers.set(a.name, currentAnswer);
      } else {
        result.answers.set(a.name, Object.assign({}, a));
      }
    });
    return c;
  }, {
    count: 0,
    avg: 0,
    summaryByInstance: {}
  }); // Recalculate fractions for each answer

  result.answers = [...result.answers.values()];
  let totalAnswersCount = result.answers.reduce((a, c) => a + c.count, 0);
  result.answers.forEach(a => a.fraction = Math.round(a.count / totalAnswersCount * 100));
  result.type = result.instances[0].type;

  if (result.type == 'scale' && grades.count > 0) {
    result.count = grades.count;
    result.mean = Number((grades.avg / grades.count).toFixed(2));
    result.summaryByInstance = grades.summaryByInstance;
    Object.keys(result.summaryByInstance).forEach(key => {
      result.summaryByInstance[key].mean = Number((result.summaryByInstance[key].avg / result.summaryByInstance[key].count).toFixed(2));
    }); // result.type = 'scale';
  } else if (result.type === 'free') {
    result.answers = result.instances.filter(i => i.type == result.type).flatMap(i => i.answers);
  }

  return result;
}

function summarizeInstance([instanceName, instance]) {
  const result = {
    name: instanceName,
    answers: []
  };

  if (instance.comments.length == 0) {
    scaleQuestion(instance, result);
  } else {
    result.answers = instance.comments;
    result.type = 'free';
  }

  return result;
}
/**
 * @param {Array<SummarizedSection>} summary 
 */


function createIndexWithModuleBreakdown(summary) {
  for (const section of summary) {
    for (const question of section.questions) {
      for (const instance of question.instances.filter(q => q.type == 'free' || q.type == 'choice')) {
        for (const answer of instance.answers) {
          answer.related = summary.map(s => ({
            name: s.name,
            questions: s.questions.map(q => ({
              name: q.name,
              type: q.type,
              feedback: q.instances?.find(x => x.name === instance.name)?.index?.[answer.index] || q.instances?.find(x => x.name === instance.name)?.answers.filter(a => a.index == answer.index)[0]?.text
            }))
          })).filter(s => s.questions.length > 0);
        }
      }
    }
  }
} //Shared methods


function scaleQuestion(question, output) {
  const questionIndex = {};
  output.count = question.choices.length;
  const choiceGroups = Object.entries(question.choices.reduce((acc, {
    index,
    choice
  }) => {
    acc[choice] = (acc[choice] || 0) + 1;
    let val = parseInt(choice);

    if (Number.isNaN(val)) {
      val = choice;
    }

    questionIndex[index] = val;
    return acc;
  }, {})).map(([choice, count]) => ({
    name: choice,
    value: parseInt(choice),
    count,
    fraction: Math.round(count / output.count * 100),
    originalValue: choice
  }));

  if (choiceGroups.filter(c => Number.isNaN(c.value) == false).length * 2 >= choiceGroups.length) {
    choiceGroups.sort((a, b) => Number.isNaN(a.value) ? 1 : b.value - a.value);
    const numericChoices = choiceGroups.filter(c => Number.isNaN(c.value) == false);
    const numericCount = numericChoices.reduce((acc, c) => acc + c.count, 0);
    output.mean = Number((numericChoices.reduce((acc, c) => acc + c.value * c.count, 0) / numericCount).toFixed(2));
    output.type = 'scale';
  } else {
    choiceGroups.sort((a, b) => b.count - a.count);
    choiceGroups.forEach(x => x.value = Number.isNaN(x.value) ? x.originalValue : x.value);
    output.type = 'choice';
  }

  output.index = questionIndex;
  output.answers = choiceGroups;

  if (question.instanceType) {
    output.instanceType = question.instanceType;
  }
}

function getOrCreate(collection, key, initial = {}) {
  if (!collection[key]) {
    collection[key] = initial;
  }

  return collection[key];
}

function sectionToTemplate(section, sectionData) {
  section.TemplateId = (sectionData.find(s => s.Name == section.name) || {
    SurveySectionTemplateId: undefined
  }).SurveySectionTemplateId;
  section.summarize = summarizable[(0,_util_util__WEBPACK_IMPORTED_MODULE_0__.getSubsite)()].templates.has(section.TemplateId);
  section.lecturer = summarizable[(0,_util_util__WEBPACK_IMPORTED_MODULE_0__.getSubsite)()].lecturer.has(section.TemplateId);
  return section;
}
/**
 * @typedef {Object} SummarizedSection
 * @property {number} TemplateId
 * @property {string} name
 * @property {number} count
 * @property {number} mean
 * @property {boolean} lecturer
 * @property {boolean} summarize
 * @property {Array<SummarizedQuestion>} questions
 */

/**
 * @typedef {Object} SummarizedQuestion
 * @property {string} name
 * @property {string} type
 * @property {number} count
 * @property {number} mean
 * @property {boolean} summarize
 * @property {Object.<string, string>?} index
 * @property {Array<ScaleAnswer|FreeAnswer>} answers
 */

/**
 * @typedef {Object} ScaleAnswer
 * @property {string} name
 * @property {number} value
 * @property {number} count
 * @property {number} fraction
 */

/**
 * @typedef {Object} FreeAnswer
 * @property {string} index
 * @property {string} text
 * @property {Array<{name: string, questions: Array<RelatedModel>}>?} related
 */

/**
 * @typedef {Object} RelatedModel
 * @property {string} name
 * @property {string} type
 * @property {string} feedback
 */


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  summarize
});

/***/ }),

/***/ "./src/util/api-connect.js":
/*!*********************************!*\
  !*** ./src/util/api-connect.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _parse__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parse */ "./src/util/parse.js");
/* harmony import */ var _api_api_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../api/api-index */ "./src/api/api-index.js");
/* harmony import */ var _node_modules_awesome_notifications_src_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../node_modules/awesome-notifications/src/index.js */ "./node_modules/awesome-notifications/src/index.js");
/// <reference path="./api.d.ts" />



const dispatcher = {};
let bgPort;
startSesApiPort();

function startSesApiPort() {
  bgPort = browser.runtime.connect({
    name: 'ses-api-port'
  });
  bgPort.onMessage.addListener(onMessage);
  bgPort.onDisconnect.addListener(() => {
    startSesApiPort();
  });
}

function getData(type, params) {
  return new Promise((resolve, reject) => {
    const _uuid = (0,_parse__WEBPACK_IMPORTED_MODULE_0__.uuid)();

    bgPort.postMessage({
      _uuid,
      appName: interopAppName(),
      type,
      params
    });
    dispatcher[_uuid] = {
      resolve,
      reject,
      type
    };
  });
}

function onMessage(m) {
  const uuid = m._uuid;

  if (m._rejected) {
    console.info('Operation reject:', dispatcher[uuid].type);
    const error = new Error(m._error);
    let notifier = new _node_modules_awesome_notifications_src_index_js__WEBPACK_IMPORTED_MODULE_2__["default"]();
    notifier.alert(`${m._error}`, {
      durations: {
        alert: 10000
      }
    }); //maybe update to show only in debug mode, providing more detailed error information using the _meta property

    console.dir(error);
    error._meta = m._meta;
    dispatcher[uuid].reject(error);
  } else {
    dispatcher[uuid].resolve(m.data);
  }

  delete dispatcher[uuid];
}

function interopAppName() {
  switch (window.location.host.slice(0, 7)) {
    case 'digital':
      return 'digital';

    case 'creativ':
      return 'creative';

    case 'ai.soft':
      return 'ai';

    case 'finance':
      return 'financeacademy';

    case 'dev.dig':
      return 'devdigital';

    case 'dev.sof':
      return 'devsoftuni';

    default:
      return 'programming';
  }
}
/** @type {SUAPI} */


const actions = (0,_api_api_index__WEBPACK_IMPORTED_MODULE_1__["default"])(null).map(a => ({
  name: a,
  func: (...params) => getData(a, params)
})).reduce((p, c) => {
  p[c.name] = c.func;
  return p;
}, {});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (actions);

/***/ }),

/***/ "./src/util/api.js":
/*!*************************!*\
  !*** ./src/util/api.js ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "addQuizQuestion": () => (/* binding */ addQuizQuestion),
/* harmony export */   "addQuizQuestionAnswer": () => (/* binding */ addQuizQuestionAnswer),
/* harmony export */   "createDocument": () => (/* binding */ createDocument),
/* harmony export */   "createEvent": () => (/* binding */ createEvent),
/* harmony export */   "createExam": () => (/* binding */ createExam),
/* harmony export */   "createExamGroup": () => (/* binding */ createExamGroup),
/* harmony export */   "createLecture": () => (/* binding */ createLecture),
/* harmony export */   "createQuizInstance": () => (/* binding */ createQuizInstance),
/* harmony export */   "createSkill": () => (/* binding */ createSkill),
/* harmony export */   "createStatus": () => (/* binding */ createStatus),
/* harmony export */   "createTrainingByTrainer": () => (/* binding */ createTrainingByTrainer),
/* harmony export */   "createTrainingGroup": () => (/* binding */ createTrainingGroup),
/* harmony export */   "deleteConfig": () => (/* binding */ deleteConfig),
/* harmony export */   "deleteNavetFile": () => (/* binding */ deleteNavetFile),
/* harmony export */   "deleteTemplate": () => (/* binding */ deleteTemplate),
/* harmony export */   "destroyEvent": () => (/* binding */ destroyEvent),
/* harmony export */   "destroyExamGroup": () => (/* binding */ destroyExamGroup),
/* harmony export */   "destroyGroup": () => (/* binding */ destroyGroup),
/* harmony export */   "destroyLecture": () => (/* binding */ destroyLecture),
/* harmony export */   "destroySkill": () => (/* binding */ destroySkill),
/* harmony export */   "destroyStatus": () => (/* binding */ destroyStatus),
/* harmony export */   "destroyTrainingOfTrainer": () => (/* binding */ destroyTrainingOfTrainer),
/* harmony export */   "findSurveyByTraining": () => (/* binding */ findSurveyByTraining),
/* harmony export */   "getAllQuizesByName": () => (/* binding */ getAllQuizesByName),
/* harmony export */   "getAnswersByQuestionId": () => (/* binding */ getAnswersByQuestionId),
/* harmony export */   "getAnyById": () => (/* binding */ getAnyById),
/* harmony export */   "getAppStatus": () => (/* binding */ getAppStatus),
/* harmony export */   "getAppStatusByInstanceId": () => (/* binding */ getAppStatusByInstanceId),
/* harmony export */   "getAppZip": () => (/* binding */ getAppZip),
/* harmony export */   "getApplications": () => (/* binding */ getApplications),
/* harmony export */   "getApplicationsByInstanceId": () => (/* binding */ getApplicationsByInstanceId),
/* harmony export */   "getBlogByUrl": () => (/* binding */ getBlogByUrl),
/* harmony export */   "getConfigByExamId": () => (/* binding */ getConfigByExamId),
/* harmony export */   "getConfigs": () => (/* binding */ getConfigs),
/* harmony export */   "getContestCompeteResults": () => (/* binding */ getContestCompeteResults),
/* harmony export */   "getCourseData": () => (/* binding */ getCourseData),
/* harmony export */   "getCourseEvents": () => (/* binding */ getCourseEvents),
/* harmony export */   "getCourseInstances": () => (/* binding */ getCourseInstances),
/* harmony export */   "getEnrolledByGroupId": () => (/* binding */ getEnrolledByGroupId),
/* harmony export */   "getEvents": () => (/* binding */ getEvents),
/* harmony export */   "getEventsByDate": () => (/* binding */ getEventsByDate),
/* harmony export */   "getEventsById": () => (/* binding */ getEventsById),
/* harmony export */   "getExamGroupsByExamId": () => (/* binding */ getExamGroupsByExamId),
/* harmony export */   "getExamsByCourse": () => (/* binding */ getExamsByCourse),
/* harmony export */   "getExamsByName": () => (/* binding */ getExamsByName),
/* harmony export */   "getExtraCourseInfo": () => (/* binding */ getExtraCourseInfo),
/* harmony export */   "getGraduateInfo": () => (/* binding */ getGraduateInfo),
/* harmony export */   "getGroupById": () => (/* binding */ getGroupById),
/* harmony export */   "getHalls": () => (/* binding */ getHalls),
/* harmony export */   "getHomeworkResults": () => (/* binding */ getHomeworkResults),
/* harmony export */   "getInsanceGroups": () => (/* binding */ getInsanceGroups),
/* harmony export */   "getInstanceConfig": () => (/* binding */ getInstanceConfig),
/* harmony export */   "getInstanceData": () => (/* binding */ getInstanceData),
/* harmony export */   "getInstanceFullPage": () => (/* binding */ getInstanceFullPage),
/* harmony export */   "getInstanceInModule": () => (/* binding */ getInstanceInModule),
/* harmony export */   "getInstanceLectures": () => (/* binding */ getInstanceLectures),
/* harmony export */   "getInstancePage": () => (/* binding */ getInstancePage),
/* harmony export */   "getInstancesInModule": () => (/* binding */ getInstancesInModule),
/* harmony export */   "getLectureDetails": () => (/* binding */ getLectureDetails),
/* harmony export */   "getLecturesForExamsByTrainingId": () => (/* binding */ getLecturesForExamsByTrainingId),
/* harmony export */   "getModules": () => (/* binding */ getModules),
/* harmony export */   "getModulesInProfession": () => (/* binding */ getModulesInProfession),
/* harmony export */   "getNavetArchivedCourses": () => (/* binding */ getNavetArchivedCourses),
/* harmony export */   "getNavetCertificate": () => (/* binding */ getNavetCertificate),
/* harmony export */   "getNavetClosedCourses": () => (/* binding */ getNavetClosedCourses),
/* harmony export */   "getNavetCourseInfo": () => (/* binding */ getNavetCourseInfo),
/* harmony export */   "getNavetCurrentCourses": () => (/* binding */ getNavetCurrentCourses),
/* harmony export */   "getNavetExistingFiles": () => (/* binding */ getNavetExistingFiles),
/* harmony export */   "getNavetStudentInfo": () => (/* binding */ getNavetStudentInfo),
/* harmony export */   "getNavetStudents": () => (/* binding */ getNavetStudents),
/* harmony export */   "getPackagesForProduct": () => (/* binding */ getPackagesForProduct),
/* harmony export */   "getPaymentsForPackage": () => (/* binding */ getPaymentsForPackage),
/* harmony export */   "getProductsForCourse": () => (/* binding */ getProductsForCourse),
/* harmony export */   "getProductsForModule": () => (/* binding */ getProductsForModule),
/* harmony export */   "getProtocol": () => (/* binding */ getProtocol),
/* harmony export */   "getQuestionsById": () => (/* binding */ getQuestionsById),
/* harmony export */   "getSeminarsByDate": () => (/* binding */ getSeminarsByDate),
/* harmony export */   "getSkillsByInstance": () => (/* binding */ getSkillsByInstance),
/* harmony export */   "getStoreSettings": () => (/* binding */ getStoreSettings),
/* harmony export */   "getStudents": () => (/* binding */ getStudents),
/* harmony export */   "getSurveyAnswers": () => (/* binding */ getSurveyAnswers),
/* harmony export */   "getSurveyById": () => (/* binding */ getSurveyById),
/* harmony export */   "getSurveyQuestionsByTemplateId": () => (/* binding */ getSurveyQuestionsByTemplateId),
/* harmony export */   "getSurveySectionsById": () => (/* binding */ getSurveySectionsById),
/* harmony export */   "getSurveySectionsByTemplateId": () => (/* binding */ getSurveySectionsByTemplateId),
/* harmony export */   "getSurveyTemplates": () => (/* binding */ getSurveyTemplates),
/* harmony export */   "getSurveys": () => (/* binding */ getSurveys),
/* harmony export */   "getSurveysByNameAndStartAndEndDate": () => (/* binding */ getSurveysByNameAndStartAndEndDate),
/* harmony export */   "getTemplateByInstanceId": () => (/* binding */ getTemplateByInstanceId),
/* harmony export */   "getTemplateByName": () => (/* binding */ getTemplateByName),
/* harmony export */   "getTemplateStoreSettings": () => (/* binding */ getTemplateStoreSettings),
/* harmony export */   "getTemplates": () => (/* binding */ getTemplates),
/* harmony export */   "getTrainerById": () => (/* binding */ getTrainerById),
/* harmony export */   "getTrainerNames": () => (/* binding */ getTrainerNames),
/* harmony export */   "getTrainersByTraining": () => (/* binding */ getTrainersByTraining),
/* harmony export */   "getTrainingsByTrainer": () => (/* binding */ getTrainingsByTrainer),
/* harmony export */   "openNavetCertificate": () => (/* binding */ openNavetCertificate),
/* harmony export */   "openNavetFile": () => (/* binding */ openNavetFile),
/* harmony export */   "saveConfig": () => (/* binding */ saveConfig),
/* harmony export */   "saveTemplate": () => (/* binding */ saveTemplate),
/* harmony export */   "searchByName": () => (/* binding */ searchByName),
/* harmony export */   "searchCourseInstancesByCourseNameAndInstanceId": () => (/* binding */ searchCourseInstancesByCourseNameAndInstanceId),
/* harmony export */   "searchCourses": () => (/* binding */ searchCourses),
/* harmony export */   "searchModules": () => (/* binding */ searchModules),
/* harmony export */   "searchSkills": () => (/* binding */ searchSkills),
/* harmony export */   "searchTrainingsByName": () => (/* binding */ searchTrainingsByName),
/* harmony export */   "searchUsers": () => (/* binding */ searchUsers),
/* harmony export */   "updateCourse": () => (/* binding */ updateCourse),
/* harmony export */   "updateEvent": () => (/* binding */ updateEvent),
/* harmony export */   "updateExam": () => (/* binding */ updateExam),
/* harmony export */   "updateExamGroup": () => (/* binding */ updateExamGroup),
/* harmony export */   "updateHall": () => (/* binding */ updateHall),
/* harmony export */   "updateInstance": () => (/* binding */ updateInstance),
/* harmony export */   "updateLecture": () => (/* binding */ updateLecture),
/* harmony export */   "updateNavetStudent": () => (/* binding */ updateNavetStudent),
/* harmony export */   "updateSkill": () => (/* binding */ updateSkill),
/* harmony export */   "updateStatus": () => (/* binding */ updateStatus),
/* harmony export */   "updateTrainingByTrainer": () => (/* binding */ updateTrainingByTrainer),
/* harmony export */   "uploadDiploma": () => (/* binding */ uploadDiploma),
/* harmony export */   "uploadExamResults": () => (/* binding */ uploadExamResults),
/* harmony export */   "uploadMedical": () => (/* binding */ uploadMedical),
/* harmony export */   "uploadNavetCertificate": () => (/* binding */ uploadNavetCertificate)
/* harmony export */ });
/* harmony import */ var _api_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./api-connect */ "./src/util/api-connect.js");
 // ########################################################################################################################
// ### Common Data
// ########################################################################################################################

async function getBlogByUrl(blogUrl) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getBlogByUrl(blogUrl);
}
async function getHalls() {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getHalls();
}
async function updateHall(hall) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateHall(hall);
} // ########################################################################################################################
// ### Module Data
// ########################################################################################################################

async function getModulesInProfession(professionId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getModulesInProfession(professionId);
}
async function getModules() {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getModules();
}
async function getInstancesInModule(moduleId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInstancesInModule(moduleId);
}
async function searchModules(query) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].searchModules(query);
}
async function getInstanceInModule(moduleId, moduleInstanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInstanceInModule(moduleId, moduleInstanceId);
} // ########################################################################################################################
// ### Payments Data
// ########################################################################################################################

async function getPaymentsForPackage(packageName) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getPaymentsForPackage(packageName);
}
async function getPackagesForProduct(productId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getPackagesForProduct(productId);
}
async function getProductsForModule(moduleId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getProductsForModule(moduleId);
}
async function getProductsForCourse(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getProductsForCourse(instanceId);
} // ########################################################################################################################
// ### Payments Data
// ########################################################################################################################

async function getContestCompeteResults(contestId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getContestCompeteResults(contestId);
} // ########################################################################################################################
// ### Quiz Data
// ########################################################################################################################

async function createQuizInstance(payload) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createQuizInstance(payload);
}
async function addQuizQuestion(quizId, content) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].addQuestion(quizId, content);
}
async function addQuizQuestionAnswer(questionId, answer, isCorrect) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].addAnswer(questionId, answer, isCorrect);
}
async function getAllQuizesByName(containingName, pageSize, page) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getAllQuizesByName(containingName, pageSize, page);
}
async function getQuestionsById(quizId, pageSize, page) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getQuestionsById(quizId, pageSize, page);
}
async function getAnswersByQuestionId(questionId, pageSize, page) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getAnswersByQuestionId(questionId, pageSize, page);
} // ########################################################################################################################
// ### Survey Data
// ########################################################################################################################

async function getSurveys(page, query, pageSize) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveys(page, query, pageSize);
}
async function getSurveysByNameAndStartAndEndDate(page, name, startDate, endDate, pageSize) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveysByNameAndStartAndEndDate(page, name, startDate, endDate, pageSize);
}
async function getSurveyById(surveyId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveyById(surveyId);
}
async function getSurveyAnswers(surveyId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveyAnswers(surveyId);
}
async function getSurveyTemplates() {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveyTemplates();
}
async function getSurveyQuestionsByTemplateId(templateId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveyQuestionsByTemplateId(templateId);
}
async function getSurveySectionsByTemplateId(templateId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveySectionsByTemplateId(templateId);
}
async function getSurveySectionsById(sectionId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSurveySectionsById(sectionId);
}
async function findSurveyByTraining(nameBg) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].findSurveyByTraining(nameBg);
} // ########################################################################################################################
// ### User Data
// ########################################################################################################################

async function getTrainingsByTrainer(userId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTrainingsByTrainer(userId);
}
async function getTrainerById(userId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTrainerById(userId);
}
async function updateTrainingByTrainer(training) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateTrainingByTrainer(training);
}
async function createTrainingByTrainer(training) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createTrainingByTrainer(training);
}
async function destroyTrainingOfTrainer(training) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].destroyTrainingOfTrainer(training);
}
async function searchUsers(query, exclude) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].searchUsers(query, exclude);
}
async function getTrainersByTraining(trainingId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTrainersByTraining(trainingId);
} // ########################################################################################################################
// ### Course Data
// ########################################################################################################################

async function searchByName(body) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].searchByName(body);
}
async function searchCourses(query) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].searchCourses(query);
}
async function getCourseData(courseId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getCourseData(courseId);
}
async function getCourseInstances(courseId, filter = undefined) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getCourseInstances(courseId, filter = undefined);
}
async function getInstanceData(instanceId, courseId, type) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInstanceData(instanceId, courseId, type);
}
async function updateCourse(course) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateCourse(course);
}
async function updateInstance(instance) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateInstance(instance);
}
async function getStudents(instanceId, type = 'main') {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getStudents(instanceId, type);
}
async function getCourseEvents(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getCourseEvents(instanceId);
}
async function getAnyById(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getAnyById(instanceId);
}
async function getInstancePage(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInstancePage(instanceId);
}
async function getInstanceFullPage(url) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInstanceFullPage(url);
}
async function getTrainerNames(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTrainerNames(instanceId);
}
async function searchCourseInstancesByCourseNameAndInstanceId(courseName, instanceId, filter = undefined) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].searchCourseInstancesByCourseNameAndInstanceId(courseName, instanceId, filter = undefined);
}
async function searchTrainingsByName(name, exact = false) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].searchTrainingsByName(name, exact);
} // ########################################################################################################################
// ### Exam Data
// ########################################################################################################################

async function getExamsByCourse(nameBg, instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getExamsByCourse(nameBg, instanceId);
}
async function getExamsByName(query) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getExamsByName(query);
}
async function getExamGroupsByExamId(examId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getExamGroupsByExamId(examId);
}
async function getEnrolledByGroupId(examGroupId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getEnrolledByGroupId(examGroupId);
}
async function createExam(exam) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createExam(exam);
}
async function updateExam(exam) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateExam(exam);
}
async function createExamGroup(group) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createExamGroup(group);
}
async function updateExamGroup(group) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateExamGroup(group);
}
async function destroyExamGroup(group) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].destroyExamGroup(group);
} // ########################################################################################################################
// ### Event Data
// ########################################################################################################################

async function getEvents(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getEvents(instanceId);
}
async function updateEvent(event) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateEvent(event);
}
async function createEvent(event) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createEvent(event);
}
async function destroyEvent(event) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].destroyEvent(event);
}
async function getEventsByDate(startDate, endDate) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getEventsByDate(startDate, endDate);
}
async function getEventsById(eventId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getEventsById(eventId);
} // ########################################################################################################################
// ### Group Data
// ########################################################################################################################

async function getInsanceGroups(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInsanceGroups(instanceId);
}
async function getGroupById(groupId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getGroupById(groupId);
}
async function createTrainingGroup(group) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createTrainingGroup(group);
}
async function destroyGroup(group) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].destroyGroup(group);
} // ########################################################################################################################
// ### Lecture Data
// ########################################################################################################################

async function getInstanceLectures(instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInstanceLectures(instanceId);
}
async function updateLecture(lecture) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateLecture(lecture);
}
async function createLecture(lecture) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createLecture(lecture);
}
async function destroyLecture(lecture) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].destroyLecture(lecture);
}
async function getLectureDetails(trainingId, lectureId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getLectureDetails(trainingId, lectureId);
}
async function getLecturesForExamsByTrainingId(trainingId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getLecturesForExamsByTrainingId(trainingId);
} // ########################################################################################################################
// ### Skill Data
// ########################################################################################################################

async function getSkillsByInstance(name, instanceId) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSkillsByInstance(name, instanceId);
}
async function updateSkill(skill) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateSkill(skill);
}
async function createSkill(skill) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createSkill(skill);
}
async function destroySkill(skill) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].destroySkill(skill);
}
async function searchSkills(query, type) {
  return _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].searchSkills(query, type);
} // ########################################################################################################################
// ### Stream Data
// ########################################################################################################################

async function getInstanceConfig(instanceId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getInstanceConfig(instanceId);
} // ########################################################################################################################
// ### CPE Data
// ########################################################################################################################

async function getApplicationsByInstanceId(instanceId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getApplicationsByInstanceId(instanceId);
}
async function getApplications(query, page) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getApplications(query, page);
}
async function getAppZip(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getAppZip(id);
}
async function getAppStatus(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getAppStatus(id);
}
async function getAppStatusByInstanceId(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getAppStatusByInstanceId(id);
}
async function createStatus(status) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createStatus(status);
}
async function updateStatus(status) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateStatus(status);
}
async function destroyStatus(status) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].destroyStatus(status);
} // ########################################################################################################################
// ### NAVET Data
// ########################################################################################################################

async function getNavetCurrentCourses() {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetCurrentCourses();
}
async function getNavetClosedCourses() {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetClosedCourses();
}
async function getNavetArchivedCourses() {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetArchivedCourses();
}
async function getNavetCourseInfo(id, type) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetCourseInfo(id, type);
}
async function getNavetStudents(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetStudents(id);
}
async function getNavetStudentInfo(clientId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetStudentInfo(clientId);
}
async function getNavetExistingFiles(courseId, id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetExistingFiles(courseId, id);
}
async function uploadMedical(courseId, id, fileDescriptor) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].uploadMedical(courseId, id, fileDescriptor);
}
async function uploadDiploma(courseId, id, fileDescriptor, reg_no, prn_no, doc_date) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].uploadDiploma(courseId, id, fileDescriptor, reg_no, prn_no, doc_date);
}
async function openNavetFile(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].openNavetFile(id);
}
async function deleteNavetFile(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].deleteNavetFile(id);
}
async function getGraduateInfo(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getGraduateInfo(id);
}
async function getNavetCertificate(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getNavetCertificate(id);
}
async function openNavetCertificate(id, page) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].openNavetCertificate(id, page);
}
async function uploadNavetCertificate(meta, fileDescriptors) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].uploadNavetCertificate(meta, fileDescriptors);
}
async function updateNavetStudent(id, student) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].updateNavetStudent(id, student);
}
async function createDocument(studentId, clientId, data) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].createDocument(studentId, clientId, data);
}
async function getExtraCourseInfo(id) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getExtraCourseInfo(id);
} // ########################################################################################################################
// ### Generic Data Store
// ########################################################################################################################

async function getStoreSettings(storeId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getStoreSettings(storeId);
} // ########################################################################################################################
// ### Templates Data
// ########################################################################################################################

async function getTemplateStoreSettings() {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTemplateStoreSettings();
}
async function getTemplates() {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTemplates();
}
async function getTemplateByName(name) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTemplateByName(name);
}
async function getTemplateByInstanceId(instanceId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getTemplateByInstanceId(instanceId);
}
async function saveTemplate(template) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].saveTemplate(template);
}
async function deleteTemplate(template) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].deleteTemplate(template);
} // ########################################################################################################################
// ### Assessment Data
// ########################################################################################################################

async function getHomeworkResults(instanceId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getHomeworkResults(instanceId);
}
async function getProtocol(instanceId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getProtocol(instanceId);
}
async function uploadExamResults(examName, examId, combo, fileDescriptor) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].uploadExamResults(examName, examId, combo, fileDescriptor);
}
async function getConfigs(examIds) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getConfigs(examIds);
}
async function getConfigByExamId(examId) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getConfigByExamId(examId);
}
async function saveConfig(config) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].saveConfig(config);
}
async function deleteConfig(config) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].deleteConfig(config);
} // ########################################################################################################################
// ### Seminar Data
// ########################################################################################################################

async function getSeminarsByDate(startDate, endDate) {
  return await _api_connect__WEBPACK_IMPORTED_MODULE_0__["default"].getSeminarsByDate(startDate, endDate);
}

/***/ }),

/***/ "./src/util/contentTypes.js":
/*!**********************************!*\
  !*** ./src/util/contentTypes.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ContentType": () => (/* binding */ ContentType)
/* harmony export */ });
class ContentType {
  // Private Fields
  static #_UrlFormEncoded = 'application/x-www-form-urlencoded; charset=UTF-8';
  static #_ApplictionJson = 'application/json'; // Accessors for "get" functions only (no "set" functions)

  static get UrlFormEncoded() {
    return this.#_UrlFormEncoded;
  }

  static get ApplicationJson() {
    return this.#_ApplictionJson;
  }

}

/***/ }),

/***/ "./src/util/data-connect.js":
/*!**********************************!*\
  !*** ./src/util/data-connect.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "clearCache": () => (/* binding */ clearCache),
/* harmony export */   "getData": () => (/* binding */ getData),
/* harmony export */   "setData": () => (/* binding */ setData),
/* harmony export */   "stores": () => (/* binding */ stores),
/* harmony export */   "withCache": () => (/* binding */ withCache)
/* harmony export */ });
/* harmony import */ var _parse__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parse */ "./src/util/parse.js");

const dispatch = {};
const stores = {
  MAIN_MODULES: 'STORE_MAIN_MODULES',
  MODULES: 'STORE_MODULES',
  MODULE_INSTANCES: 'STORE_MODULE_INSTANCES',
  PAYMENTS: 'STORE_PAYMENTS',
  TRAINING_HALLS: 'TRAINING_HALLS',
  COURSE_INFO: 'COURSE_INFO',
  STREAM_CONFIG: 'STREAM_CONFIG',
  SURVEYS: 'SURVEYS',
  SURVEYS_ALL: 'SURVEYS_ALL',
  SURVEY: 'SURVEY_ID_',
  TEMPLATE_CONFIG: 'TEMPLATE_CONFIG',
  STATISTICS_CONFIG: 'STATISTICS_CONFIG'
};
const bgPort = browser.runtime.connect({
  name: 'ses-data-port'
});
bgPort.onMessage.addListener(onMessage);
/**
 * Create function with cached response
 * @param {Function} func Function call to cache
 * @param {Symbol} storeId Store identifier
 * @param {Number=} maxAge Cache age threshold, in seconds. If omitted, the cache is considered non-expiring (resets on reinstalling/updating extension)
 */

function withCache(func, storeId, maxAge) {
  return function (...params) {
    const callbacks = {};
    const promise = new Promise((resolve, reject) => {
      callbacks.resolve = resolve;
      callbacks.reject = reject;
    });
    executor();
    return promise;

    async function executor() {
      try {
        let rawCache = await getData(storeId);

        if (rawCache.data !== undefined && isFresh(rawCache.when, maxAge)) {
          promise._cacheHit = true;
          callbacks.resolve(rawCache.data);
        } else {
          const value = await func(...params);
          setData(storeId, value);
          callbacks.resolve(value);
        }
      } catch (err) {
        callbacks.reject(err);
      }
    }
  };
}

;

function isFresh(creationDate, maxAge) {
  if (maxAge === undefined) {
    return true;
  } else if ((Date.now() - creationDate) / 1000 <= maxAge) {
    return true;
  } else {
    return false;
  }
}

function clearCache(name) {
  bgPort.postMessage({
    clear: name
  });
}
/**
 * Retrieve data from the background store
 * @param {String} name Item name
 */


function getData(name) {
  return new Promise(resolve => {
    const _uuid = (0,_parse__WEBPACK_IMPORTED_MODULE_0__.uuid)();

    bgPort.postMessage({
      _uuid,
      get: name
    });
    dispatch[_uuid] = resolve;
  });
}
/**
 * Save data in the background store
 * @param {String} name Item name
 * @param {*} data Data to save in the store
 */


function setData(name, data) {
  bgPort.postMessage({
    set: name,
    data
  });
}

function onMessage(m) {
  const uuid = m._uuid;
  delete m._uuid;
  dispatch[uuid](m);
  delete dispatch[uuid];
}



/***/ }),

/***/ "./src/util/jsx-render-mod/dom.js":
/*!****************************************!*\
  !*** ./src/util/jsx-render-mod/dom.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Fragment": () => (/* binding */ Fragment),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "portalCreator": () => (/* binding */ portalCreator)
/* harmony export */ });
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils */ "./src/util/jsx-render-mod/utils.js");

/**
 * The tag name and create an html together with the attributes
 *
 * @param  {String} tagName name as string, e.g. 'div', 'span', 'svg'
 * @param  {Object} attrs html attributes e.g. data-, width, src
 * @param  {Array} children html nodes from inside de elements
 * @return {HTMLElement|SVGElement} html node with attrs
 */

function createElements(tagName, attrs, children) {
  const element = (0,_utils__WEBPACK_IMPORTED_MODULE_0__.isSVG)(tagName) ? document.createElementNS('http://www.w3.org/2000/svg', tagName) : document.createElement(tagName); // one or multiple will be evaluated to append as string or HTMLElement

  const fragment = (0,_utils__WEBPACK_IMPORTED_MODULE_0__.createFragmentFrom)(children);
  element.appendChild(fragment);
  Object.keys(attrs || {}).forEach(prop => {
    if (prop === 'style') {
      // e.g. origin: <element style={{ prop: value }} />
      Object.assign(element.style, attrs[prop]);
    } else if (prop === 'ref' && typeof attrs.ref === 'function') {
      attrs.ref(element, attrs);
    } else if (prop === 'className') {
      element.setAttribute('class', attrs[prop]);
    } else if (prop === 'xlinkHref') {
      element.setAttributeNS('http://www.w3.org/1999/xlink', 'xlink:href', attrs[prop]);
    } else if (prop === 'dangerouslySetInnerHTML') {
      // eslint-disable-next-line no-underscore-dangle
      element.innerHTML = attrs[prop].__html;
    } else if (prop in _utils__WEBPACK_IMPORTED_MODULE_0__.EVENT_LISTENERS) {
      element.addEventListener(_utils__WEBPACK_IMPORTED_MODULE_0__.EVENT_LISTENERS[prop], attrs[prop]);
    } else {
      // any other prop will be set as attribute
      element.setAttribute(prop, attrs[prop]);
    }
  });
  return element;
}
/**
 * The JSXTag will be unwrapped returning the html
 *
 * @param  {Function} JSXTag name as string, e.g. 'div', 'span', 'svg'
 * @param  {Object} elementProps custom jsx attributes e.g. fn, strings
 * @param  {Array} children html nodes from inside de elements
 *
 * @return {Function} returns de 'dom' (fn) executed, leaving the HTMLElement
 *
 * JSXTag:  function Comp(props) {
 *   return dom("span", null, props.num);
 * }
 */


function composeToFunction(JSXTag, elementProps, children) {
  const props = Object.assign({}, JSXTag.defaultProps || {}, elementProps, {
    children
  });
  const bridge = JSXTag.prototype && JSXTag.prototype.render ? new JSXTag(props).render : JSXTag;
  const result = bridge(props);

  switch (result) {
    case 'FRAGMENT':
      return (0,_utils__WEBPACK_IMPORTED_MODULE_0__.createFragmentFrom)(children);
    // Portals are useful to render modals
    // allow render on a different element than the parent of the chain
    // and leave a comment instead

    case 'PORTAL':
      bridge.target.appendChild((0,_utils__WEBPACK_IMPORTED_MODULE_0__.createFragmentFrom)(children));
      return document.createComment('Portal Used');

    default:
      return result;
  }
}

function dom(element, attrs, ...children) {
  // Custom Components will be functions
  if (typeof element === 'function') {
    if (element.hasOwnProperty('propTypes')) {
      for (let prop of element.propTypes) {
        if (attrs.hasOwnProperty(prop) === false) {
          console.error(`JSX Error: Missing property '${prop}' from '${element.name}' invocation`);
        }
      }
    } // e.g. const CustomTag = ({ w }) => <span width={w} />
    // will be used
    // e.g. <CustomTag w={1} />
    // becomes: CustomTag({ w: 1})


    return composeToFunction(element, attrs, children);
  } // regular html components will be strings to create the elements
  // this is handled by the babel plugins


  if (typeof element === 'string') {
    return createElements(element, attrs, children);
  }

  return console.error(`jsx-render does not handle ${typeof tag}`);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (dom);
const Fragment = () => 'FRAGMENT';
const portalCreator = node => {
  function Portal() {
    return 'PORTAL';
  }

  Portal.target = document.body;

  if (node && node.nodeType === Node.ELEMENT_NODE) {
    Portal.target = node;
  }

  return Portal;
};

/***/ }),

/***/ "./src/util/jsx-render-mod/utils.js":
/*!******************************************!*\
  !*** ./src/util/jsx-render-mod/utils.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EVENT_LISTENERS": () => (/* binding */ EVENT_LISTENERS),
/* harmony export */   "createFragmentFrom": () => (/* binding */ createFragmentFrom),
/* harmony export */   "isSVG": () => (/* binding */ isSVG)
/* harmony export */ });
function isSVG(element) {
  const patt = new RegExp(`^${element}$`, 'i');
  const SVGTags = ['path', 'svg', 'use', 'g'];
  return SVGTags.some(tag => patt.test(tag));
}
function createFragmentFrom(children) {
  // fragments will help later to append multiple children to the initial node
  const fragment = document.createDocumentFragment();

  function processDOMNodes(child) {
    if (child instanceof HTMLElement || child instanceof SVGElement || child instanceof Comment || child instanceof DocumentFragment) {
      fragment.appendChild(child);
    } else if (typeof child === 'string' || typeof child === 'number') {
      const textnode = document.createTextNode(child);
      fragment.appendChild(textnode);
    } else if (child instanceof Array) {
      child.forEach(processDOMNodes);
    } else if (child === false || child === null) {// expression evaluated as false e.g. {false && <Elem />}
      // expression evaluated as false e.g. {null && <Elem />}
    } else if (typeof child === 'function') {} else if (true) {
      // later other things could not be HTMLElement nor strings
      console.log(child, 'is not appendable');
    }
  }

  children.forEach(processDOMNodes);
  return fragment;
} // Map from JSX property (e.g. onClick) to event name (e.g. 'click').

const EVENT_LISTENERS = {
  // Clipboard Events
  onCopy: 'copy',
  onCut: 'cut',
  onPaste: 'paste',
  // Composition Events
  onCompositionEnd: 'compositionend',
  onCompositionStart: 'compositionstart',
  onCompositionUpdate: 'compositionupdate',
  // Focus Events
  onFocus: 'focus',
  onBlur: 'blur',
  // Form Events
  onChange: 'change',
  onBeforeInput: 'beforeinput',
  onInput: 'input',
  onReset: 'reset',
  onSubmit: 'submit',
  onInvalid: 'invalid',
  // Image Events
  onLoad: 'load',
  onError: 'error',
  // Keyboard Events
  onKeyDown: 'keydown',
  onKeyPress: 'keypress',
  onKeyUp: 'keyup',
  // Media Events
  onAbort: 'abort',
  onCanPlay: 'canplay',
  onCanPlayThrough: 'canplaythrough',
  onDurationChange: 'durationchange',
  onEmptied: 'emptied',
  onEncrypted: 'encrypted',
  onEnded: 'ended',
  onLoadedData: 'loadeddata',
  onLoadedMetadata: 'loadedmetadata',
  onLoadStart: 'loadstart',
  onPause: 'pause',
  onPlay: 'play',
  onPlaying: 'playing',
  onProgress: 'progress',
  onRateChange: 'ratechange',
  onSeeked: 'seeked',
  onSeeking: 'seeking',
  onStalled: 'stalled',
  onSuspend: 'suspend',
  onTimeUpdate: 'timeupdate',
  onVolumeChange: 'volumechange',
  onWaiting: 'waiting',
  // MouseEvents
  onClick: 'click',
  onContextMenu: 'contextmenu',
  onDoubleClick: 'doubleclick',
  onDrag: 'drag',
  onDragEnd: 'dragend',
  onDragEnter: 'dragenter',
  onDragExit: 'dragexit',
  onDragLeave: 'dragleave',
  onDragOver: 'dragover',
  onDragStart: 'dragstart',
  onDrop: 'drop',
  onMouseDown: 'mousedown',
  onMouseEnter: 'mouseenter',
  onMouseLeave: 'mouseleave',
  onMouseMove: 'mousemove',
  onMouseOut: 'mouseout',
  onMouseOver: 'mouseover',
  onMouseUp: 'mouseup',
  // Selection Events
  onSelect: 'select',
  // Touch Events
  onTouchCancel: 'touchcancel',
  onTouchEnd: 'touchend',
  onTouchMove: 'touchmove',
  onTouchStart: 'touchstart',
  // Pointer Events
  onPointerDown: 'pointerdown',
  onPointerMove: 'pointermove',
  onPointerUp: 'pointerup',
  onPointerCancel: 'pointercancel',
  onPointerEnter: 'pointerenter',
  onPointerLeave: 'pointerleave',
  onPointerOver: 'pointerover',
  onPointerOut: 'pointerout',
  // UI Events
  onScroll: 'scroll',
  // Wheel Events
  onWheel: 'wheel',
  // Animation Events
  onAnimationStart: 'animationstart',
  onAnimationEnd: 'animationend',
  onAnimationIteration: 'animationiteration',
  // Transition Events
  onTransitionEnd: 'transitionend'
};

/***/ }),

/***/ "./src/util/parse.js":
/*!***************************!*\
  !*** ./src/util/parse.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dateDiff": () => (/* binding */ dateDiff),
/* harmony export */   "dateDiffToDays": () => (/* binding */ dateDiffToDays),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "formatDate": () => (/* binding */ formatDate),
/* harmony export */   "formatLocaleDate": () => (/* binding */ formatLocaleDate),
/* harmony export */   "formatLocaleWeekday": () => (/* binding */ formatLocaleWeekday),
/* harmony export */   "formatTime": () => (/* binding */ formatTime),
/* harmony export */   "getDateIndex": () => (/* binding */ getDateIndex),
/* harmony export */   "getMonday": () => (/* binding */ getMonday),
/* harmony export */   "getOffsetByDays": () => (/* binding */ getOffsetByDays),
/* harmony export */   "getSunday": () => (/* binding */ getSunday),
/* harmony export */   "hasValue": () => (/* binding */ hasValue),
/* harmony export */   "htmlToText": () => (/* binding */ htmlToText),
/* harmony export */   "instanceMetaFromHref": () => (/* binding */ instanceMetaFromHref),
/* harmony export */   "isLastDay": () => (/* binding */ isLastDay),
/* harmony export */   "isLastWeek": () => (/* binding */ isLastWeek),
/* harmony export */   "localeMonthName": () => (/* binding */ localeMonthName),
/* harmony export */   "monthName": () => (/* binding */ monthName),
/* harmony export */   "normalizeDateTime": () => (/* binding */ normalizeDateTime),
/* harmony export */   "offsetByDays": () => (/* binding */ offsetByDays),
/* harmony export */   "paymentsToMatrix": () => (/* binding */ paymentsToMatrix),
/* harmony export */   "prettyJSON": () => (/* binding */ prettyJSON),
/* harmony export */   "queryString": () => (/* binding */ queryString),
/* harmony export */   "sumArrayMax": () => (/* binding */ sumArrayMax),
/* harmony export */   "toAssocArray": () => (/* binding */ toAssocArray),
/* harmony export */   "toCustomAssocArray": () => (/* binding */ toCustomAssocArray),
/* harmony export */   "uuid": () => (/* binding */ uuid),
/* harmony export */   "valueOrEmpty": () => (/* binding */ valueOrEmpty)
/* harmony export */ });
function queryString(query) {
  if (!query) {
    return null;
  }

  return query.split('?')[1].split('&').map(a => a.split('=')).reduce((a, c) => {
    a[c[0]] = c[1];
    return a;
  }, {});
}
/**
 * Calculate number of days passing between two dates
 * @param {Date} a Starting date
 * @param {Date} b Ending date
 * @returns {number} Number of days
 */


function dateDiff(a, b) {
  if (a.getFullYear() == b.getFullYear() && a.getMonth() == b.getMonth() && a.getDate() == b.getDate()) {
    return 0;
  } else {
    return b - a > 0 ? Math.ceil((b - a) / 86400000) : Math.floor((b - a) / 86400000);
  }
}

function dateDiffToDays(days) {
  if (days == 0) {
    return 'Today';
  } else {
    if (days <= 0) {
      return `In ${-days} day${days == -1 ? '' : 's'}`;
    } else {
      return `${days} day${days == 1 ? '' : 's'} ago`;
    }
  }
}
/**
 * Is the date in the last day of a month
 * @param {Date} date
 * @returns {boolean}
 */


function isLastDay(date) {
  const nextDay = new Date(date);
  nextDay.setDate(nextDay.getDate() + 1);
  return date.getMonth() != nextDay.getMonth();
}
/**
 * Is the date in the last week of a month
 * @param {Date} date
 * @returns {boolean}
 */


function isLastWeek(date) {
  const nextWeek = new Date(date);
  nextWeek.setDate(nextWeek.getDate() + 7);
  return date.getMonth() != nextWeek.getMonth();
}

function formatDate(date) {
  const asString = date.toLocaleDateString('en-US', {
    month: 'short',
    year: 'numeric'
  });
  return `${date.getDate()} ${asString}`;
}

function formatTime(date) {
  return date.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: 'numeric',
    // hour12: false,
    hourCycle: 'h23'
  });
}

function formatLocaleDate(date) {
  const day = date.getDate();
  const month = ['януари', 'февруари', 'март', 'април', 'май', 'юни', 'юли', 'август', 'септември', 'октомври', 'ноември', 'декември'][date.getMonth()];
  return `${day} ${month}`;
}

function formatLocaleWeekday(day, getAdj) {
  const weekday = ['неделя', 'понеделник', 'вторник', 'сряда', 'четвъртък', 'петък', 'събота'][day];

  if (getAdj) {
    return [weekday, ['всяка', 'всеки', 'всеки', 'всяка', 'всеки', 'всеки', 'всяка'][day]];
  }

  return weekday;
}
/**
 * Get a new date offset by the specified number of days
 * @param {Date} date Base date
 * @param {number} days How many days to offset
 * @returns {Date}
 */


function getOffsetByDays(date, days) {
  const result = new Date(date);
  result.setUTCDate(result.getUTCDate() + days);
  return result;
}
/**
 * Offset the given date in place by the specified number of days
 * @param {Date} date Base date
 * @param {number} days How many days to offset
 */

function offsetByDays(date, days) {
  date.setUTCDate(date.getUTCDate() + days);
}
/**
 * Create date index as string
 * @param {Date|string} date Base date
 * @returns {string}
 */

function getDateIndex(date) {
  if (typeof date == 'string') {
    date = new Date(date);
  }

  return date.toISOString().slice(0, 10);
}

function prettyJSON(obj) {
  return JSON.stringify(obj, null, 2).replace(/ /gmi, '&nbsp;').replace(/\n/gmi, '<br>');
}

function getMonday(date) {
  const monday = new Date(`${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()} 12:00:00`);
  monday.setDate(monday.getDate() - (monday.getDay() + 6) % 7);
  return monday;
}

function getSunday(date) {
  const sunday = new Date(`${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()} 23:59:59`);
  sunday.setDate(sunday.getDate() + (7 - sunday.getDay()) % 7);
  return sunday;
}

const monthName = {
  1: 'January',
  2: 'February',
  3: 'March',
  4: 'April',
  5: 'May',
  6: 'June',
  7: 'July',
  8: 'August',
  9: 'September',
  10: 'October',
  11: 'November',
  12: 'December'
};
const localeMonthName = {
  1: 'януари',
  2: 'февруари',
  3: 'март',
  4: 'април',
  5: 'май',
  6: 'юни',
  7: 'юли',
  8: 'август',
  9: 'септември',
  10: 'октомври',
  11: 'ноември',
  12: 'декември'
};

function toAssocArray(p, c, i, a) {
  p[c.Id] = c;
  return p;
}

function toCustomAssocArray(indexName, overwrite = false) {
  return (p, c, i, a) => {
    if (p[c[indexName]] !== undefined && overwrite == false) {
      if (Array.isArray(p[c[indexName]])) {
        p[c[indexName]].push(c);
      } else {
        p[c[indexName]] = [p[c[indexName]], c];
      }
    } else {
      p[c[indexName]] = c;
    }

    return p;
  };
}
/**
 * @param {Array<SUPayment>} data 
 * @returns {Array<PaymentViewModel>}
 */

function paymentsToMatrix(data) {
  const template = ['Id', 'PaymentNumber', 'ModuleNameEn', 'PaymentPackagesAsString', 'PaidForUserName', 'Price', 'EducationalForm', 'PaymentDateTime'];
  const parsed = data.map(e => {
    e.EducationalForm = e.EducationalForm == 1 ? 'online' : 'onsite';
    const entry = [];

    for (let prop of template) {
      if (prop === 'PaymentDateTime') {
        entry.push(new Date(e[prop]));
      } else {
        entry.push(e[prop]);
      }
    }

    return entry;
  });
  return [template, ...parsed];
}

function uuid() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    let r = Math.random() * 16 | 0,
        v = c == 'x' ? r : r & 0x3 | 0x8;
    return v.toString(16);
  });
}
function normalizeDateTime(datetime) {
  if (!datetime) {
    return '';
  } else if (datetime.toString().includes('Date(')) {
    const match = /Date\((.+)\)/.exec(datetime);

    if (match !== null) {
      const d = new Date(Number(match[1]));
      return `${('0000' + d.getFullYear()).slice(-4)}-${pt(d.getMonth() + 1)}-${pt(d.getDate())}T${pt(d.getHours())}:${pt(d.getMinutes())}`;
    } else {
      return datetime;
    }
  } else {
    return datetime;
  }
}

function pt(s) {
  return `0${s}`.slice(-2);
}

function htmlToText(html) {
  const div = document.createElement('div');
  div.innerHTML = html;
  return div.textContent;
}

function instanceMetaFromHref(href) {
  const instanceMeta = queryString(href);

  instanceMeta.InstanceRefType = (() => {
    switch (instanceMeta.type) {
      case 'course':
        return 'main';

      case 'fast-track':
        return 'open';

      case 'general-course-instance':
        return 'general';
    }
  })();

  return instanceMeta;
}
function hasValue(value) {
  return value !== null && value !== undefined && value !== '';
}
function valueOrEmpty(value, alt = '') {
  if (value === null || value === undefined || value === '') {
    return alt;
  } else {
    return value;
  }
}
function sumArrayMax(arr) {
  if (arr[0].length == 0 && arr[1].length == 0) {
    return null;
  }

  let result = 0;

  if (arr[0].length > 0) {
    result += Math.max(...arr[0]);
  }

  if (arr[1].length > 0) {
    result += Math.max(...arr[1]);
  }

  return result;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  queryString,
  dateDiff,
  dateDiffToDays,
  isLastDay,
  isLastWeek,
  formatDate,
  formatTime,
  formatLocaleDate,
  formatLocaleWeekday,
  prettyJSON,
  getMonday,
  getSunday,
  monthName,
  localeMonthName,
  toAssocArray,
  paymentsToMatrix,
  htmlToText
});


/***/ }),

/***/ "./src/util/router.js":
/*!****************************!*\
  !*** ./src/util/router.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Link": () => (/* binding */ Link),
/* harmony export */   "back": () => (/* binding */ back),
/* harmony export */   "checkActiveNav": () => (/* binding */ checkActiveNav),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "redirect": () => (/* binding */ redirect)
/* harmony export */ });
/* harmony import */ var _parse__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parse */ "./src/util/parse.js");

function Link({
  href,
  to,
  nav,
  partial,
  req,
  children,
  ...props
}) {
  try {
    const element = document.createElement('a');

    if (href !== undefined) {
      element.setAttribute('href', href);
      element.addEventListener('click', e => handler(e, element));
    }

    for (let prop of Object.keys(props)) {
      element[prop] = props[prop];
    }

    if (nav) {
      element.classList.add('ses-nav');
      const hrefTokens = _parse__WEBPACK_IMPORTED_MODULE_0__["default"].queryString(element.href);

      const matcher = nav => matchRoute(hrefTokens, nav);

      element.checkActiveNav = () => {
        if (window.location.search.split('?')[1] === element.href.split('?')[1]) {
          return element.classList.add('active');
        } else if (partial) {
          if (activeNav.some(matcher)) {
            if (req === undefined) {
              return element.classList.add('active');
            } else if (activeNav.some(nav => matchRoute(req, nav))) {
              return element.classList.add('active');
            }
          }
        }

        element.classList.remove('active');
      };

      element.checkActiveNav();
    }

    appendAll(children, element);
    return element;
  } catch (err) {
    console.error(err.message);
  }

  function handler(e, element) {
    e.preventDefault();
    const title = document.title;
    window.history.pushState({}, title, href);

    if (to !== undefined) {
      if (nav) {
        checkActiveNav();
      }

      to();
    } else {
      trigger();
    }
  }

  function appendAll(children, element) {
    for (let child of children) {
      if (Array.isArray(child)) {
        appendAll(child, element);
      } else if (typeof child === 'string' || typeof child === 'number') {
        element.appendChild(document.createTextNode(child));
      } else {
        element.appendChild(child);
      }
    }
  }
}
function redirect(href) {
  const title = document.title;
  window.history.pushState({}, title, href);
  trigger();
}
function back() {
  window.history.back();
}
function checkActiveNav() {
  document.querySelectorAll('.ses-nav').forEach(e => e.checkActiveNav());
}

function link(callback, title) {
  return function (element) {
    element.addEventListener('click', e => {
      e.preventDefault();
      title = title || document.title;
      window.history.pushState({}, title, e.target.href);
      callback(e);
    });
  };
}

window.onpopstate = function (e) {
  try {
    trigger();
  } catch (e) {
    console.error('Routing handler error:');
    console.error(e.message);
  }
}; // must have a static instance available - starting with top level on first call to register, replaced by active route upon load/navigation
// subsequent calls to register add the routes to the active router

/**
 * @typedef {Object} Route
 * @property {{name: string}} match - Name of query parameter and its value
 * @property {Function} handler - Callback to be executed on match. Expected to render content
 * @property {*=} context - Optional object that will be passed to handler
 * @property {Route[]=} routes - Nested routes
 */

/** @type {number} - Debug counter */

/** @type {Route[]} */


const routes = [];
/** @type {Route} */

let activeRoute = null;
let activeNav = [];
/**
 * Add nested routes to currently active route. If first call, top level routes are defined
 * @param {Route[]} options - List of routes
 * @param {*=} context - Optional object that will be passed to handlers
 */

function register(options, context) {
  let currentRoutes = routes;

  if (activeRoute !== null) {
    activeRoute.routes = activeRoute.routes || [];
    currentRoutes = activeRoute.routes;
  }

  const newRoutes = [];

  for (let route of options) {
    route = Object.assign(route, {
      context
    });
    const routeId = currentRoutes.reduce((p, c, i) => matchRoute(route.match, c.match) ? i : p, undefined);

    if (routeId !== undefined) {
      currentRoutes[routeId] = route;
    } else {
      newRoutes.push(route);
    }
  }

  newRoutes.forEach(r => currentRoutes.push(r));
  trigger(currentRoutes);
}
/**
 * Run a check against the routing list and execute matching handlers
 * @param {Route[]=} currentRoutes - Currently active routing list
 */


function trigger(currentRoutes) {
  if (currentRoutes === undefined || currentRoutes === routes) {
    currentRoutes = routes;
    activeNav = [];
  }
  /** @type {Object.<string, string>?} */


  const query = _parse__WEBPACK_IMPORTED_MODULE_0__["default"].queryString(document.location.search);

  for (let route of currentRoutes) {
    if (matchRoute(query, route.match)) {
      activeRoute = route;
      activeNav.push(activeRoute.match);
      checkActiveNav();
      return route.handler(query, route.context);
    }
  }
}
/**
 * Check if a given query object matches a given route pattern
 * @param {Object.<string, string>?} query - Query parameters
 * @param {{name: string}} match - Parameter name and value that must match
 * @returns {boolean}
 */


function matchRoute(query, match) {
  if (match === query) {
    return true;
  } else if (query) {
    if (typeof match === 'string' && query.hasOwnProperty(match)) {
      return true;
    } else {
      for (let name in match) {
        if (query[name] === match[name]) {
          return true;
        }
      }
    }
  } // No match


  return false;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  link,
  register
});

/***/ }),

/***/ "./src/util/template.js":
/*!******************************!*\
  !*** ./src/util/template.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Alert": () => (/* binding */ Alert),
/* harmony export */   "Autocomplete": () => (/* binding */ Autocomplete),
/* harmony export */   "Container": () => (/* binding */ Container),
/* harmony export */   "DownloadProgressBar": () => (/* binding */ DownloadProgressBar),
/* harmony export */   "Loading": () => (/* binding */ Loading),
/* harmony export */   "No": () => (/* binding */ No),
/* harmony export */   "Question": () => (/* binding */ Question),
/* harmony export */   "Remote": () => (/* binding */ Remote),
/* harmony export */   "Spinner": () => (/* binding */ Spinner),
/* harmony export */   "Yes": () => (/* binding */ Yes),
/* harmony export */   "applyBeginRequest": () => (/* binding */ applyBeginRequest),
/* harmony export */   "applyRequestError": () => (/* binding */ applyRequestError),
/* harmony export */   "applyRequestSuccess": () => (/* binding */ applyRequestSuccess),
/* harmony export */   "createCheckbox": () => (/* binding */ createCheckbox),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "element": () => (/* binding */ element),
/* harmony export */   "getEditorDecoration": () => (/* binding */ getEditorDecoration),
/* harmony export */   "popupTable": () => (/* binding */ popupTable),
/* harmony export */   "replaceContents": () => (/* binding */ replaceContents),
/* harmony export */   "swap": () => (/* binding */ swap),
/* harmony export */   "table": () => (/* binding */ table)
/* harmony export */ });
/* harmony import */ var _parse__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parse */ "./src/util/parse.js");
/* harmony import */ var _util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/jsx-render-mod/dom */ "./src/util/jsx-render-mod/dom.js");


/**
 * 
 * @param {*} type 
 * @param {*} content 
 * @param {*} attributes 
 * @param {{forceType: 'Text' | 'HTML'}} options 
 * @returns 
 */

function element(type, content, attributes, options = undefined) {
  const result = document.createElement(type);

  if (attributes) {
    for (let attr of Object.keys(attributes)) {
      result[attr] = attributes[attr];
    }
  }

  result.append = append.bind(result);

  result.appendTo = parent => {
    parent.append(result);
    return result;
  };

  if (content !== undefined && content !== null) {
    result.append(content, options);
  }

  return result;
}

function append(child, options = undefined) {
  if (typeof child === 'string' || typeof child === 'number') {
    if (options?.forceType != 'Text' && (options?.forceType === 'HTML' || child.toString().trim()[0] === '<')) {
      this.innerHTML = child;
    } else {
      child = document.createTextNode(child);
      this.appendChild(child);
    }
  } else if (Array.isArray(child)) {
    for (let node of child) {
      append.call(this, node);
    }
  } else {
    this.appendChild(child);
  }

  return this;
}

function replaceContents(node, newContents) {
  const cNode = node.cloneNode(false);
  append.call(cNode, newContents);

  try {
    node.parentNode.replaceChild(cNode, node);
  } catch (err) {
    console.info('Node has no parent or another problem occured');
  }

  return cNode;
}
function swap(oldNode, newNode) {
  oldNode.parentNode.replaceChild(newNode, oldNode);
  return newNode;
}
function Spinner({
  id
}) {
  const node = element('div', [element('div', null, {
    classList: 'sk-cube sk-cube1'
  }), element('div', null, {
    classList: 'sk-cube sk-cube2'
  }), element('div', null, {
    classList: 'sk-cube sk-cube3'
  }), element('div', null, {
    classList: 'sk-cube sk-cube4'
  }), element('div', null, {
    classList: 'sk-cube sk-cube5'
  }), element('div', null, {
    classList: 'sk-cube sk-cube6'
  }), element('div', null, {
    classList: 'sk-cube sk-cube7'
  }), element('div', null, {
    classList: 'sk-cube sk-cube8'
  }), element('div', null, {
    classList: 'sk-cube sk-cube9'
  })], {
    classList: 'sk-cube-grid'
  });

  if (id) {
    node.setAttribute('id', id);
  }

  return node;
}
function Loading({
  id,
  color = 'white'
}) {
  const node = element('div', [element('div', null, {
    classList: 'rect1'
  }), element('div', null, {
    classList: 'rect2'
  }), element('div', null, {
    classList: 'rect3'
  }), element('div', null, {
    classList: 'rect4'
  }), element('div', null, {
    classList: 'rect5'
  })], {
    classList: getClass()
  });

  if (id) {
    node.setAttribute('id', id);
  }

  return node;

  function getClass() {
    return `spinner ${color}`;
  }
}
function Remote({
  src,
  parse,
  component,
  color = 'white',
  onReady,
  onError
}) {
  const id = (0,_parse__WEBPACK_IMPORTED_MODULE_0__.uuid)();
  resolve();
  const loader = Loading({
    id,
    color
  });
  return loader;

  async function resolve() {
    let data = await (async () => {
      try {
        return (await (src instanceof Promise)) ? src : src();
      } catch (e) {
        if (onError) {
          onError(e, loader);
          throw e;
        }

        const retryBtn = element('button', [element('i', null, {
          className: 'glyphicon glyphicon-repeat'
        }), 'Retry'], {
          style: 'background-color: green'
        });
        retryBtn.addEventListener('click', () => {
          replaceSelf(Remote({
            src,
            parse,
            component,
            color
          }));
        });
        return element('div', [element('i', null, {
          className: 'glyphicon glyphicon-remove',
          style: 'color: red'
        }), e.message, retryBtn], {
          id: id
        });
      }
    })();

    if (parse) {
      data = parse(data);
    }

    replaceSelf(data);

    function replaceSelf(data) {
      //const loader = document.getElementById(id);
      const parent = loader.parentNode;

      if (component) {
        parent.insertBefore(component(data), loader);
      } else {
        append(data);
      } //await new Promise(resolve => setTimeout(10, resolve));
      //console.log(document.getElementById(id));


      loader.remove();

      if (onReady) {
        onReady();
      }

      function append(child) {
        if (typeof child === 'string' || typeof child === 'number') {
          if (child.toString().trim()[0] === '<') {
            const fragment = element('div', child);
            fragment.childNodes.forEach(n => parent.insertBefore(n.cloneNode(true), loader));
          } else {
            parent.insertBefore(document.createTextNode(child), loader);
          }
        } else if (Array.isArray(child)) {
          for (let node of child) {
            append(node);
          }
        } else {
          parent.insertBefore(child, loader);
        }
      }
    }
  }
}
function Yes() {
  const el = document.createElement('i');
  el.className = 'glyphicon glyphicon-ok';
  el.style.color = 'green';
  return el;
}
function No() {
  const el = document.createElement('i');
  el.className = 'glyphicon glyphicon-remove';
  el.style.color = 'red';
  return el;
}
function Question([title, answers]) {
  return element('div', [element('h2', title), element('ul', Object.entries(answers).map(([a, isCorrect]) => element('li', a, {
    classList: isCorrect ? 'correct-answer' : 'none'
  }, true)))], {
    classList: 'question-container'
  });
}
;
function Alert() {
  const el = document.createElement('i');
  el.className = 'glyphicon glyphicon-warning-sign';
  el.style.color = 'orange';
  return el;
}
function Container({
  children,
  className
}) {
  const section = element('section', children, {
    className: className ? 'event-container' : 'container'
  });
  const el = element('div', section, {
    className: className ? className : 'container administration-container ses-container'
  });
  return el;
}
function popupTable(data) {
  let html = `
        <style>
            table {
                border-collapse: collapse;
            }
            tr, td, th {
                border: 1px solid black;
                padding: 0.25em 0.5em;
            }
        </style>
        `;
  html += '<table><thead><tr>';

  for (let col of data[0]) {
    html += `<th>${col}</th>`;
  }

  html += '</tr></thead><tbody>';

  for (let row = 1; row < data.length; row++) {
    html += '<tr>';

    for (let col of data[row]) {
      html += `<td>${col}</td>`;
    }

    html += '</tr>';
  }

  html += '</tbody></table>';
  return html;
}
function getEditorDecoration(element) {
  function enable() {
    element.classList.add('enabled');
  }

  function disable() {
    element.classList.remove('enabled');
  }

  function working() {
    element.classList.remove('enabled');
    element.classList.add('working');
  }

  function updated() {
    element.classList.remove('working');
    element.classList.add('updated');
    setTimeout(() => element.classList.remove('updated'), 3000);
  }

  function failure() {
    element.classList.remove('working');
    element.classList.add('failed');
  }

  function _clear() {
    element.classList.remove('enabled');
    element.classList.remove('working');
    element.classList.remove('updated');
    element.classList.remove('failed');
  }

  return {
    enable,
    disable,
    working,
    updated,
    failure,
    _clear
  };
}
function applyBeginRequest(element) {
  element.childNodes.forEach(c => c.childNodes.forEach(n => n.disabled = true));
  element.classList.remove('enabled');
  element.classList.remove('failed');
  element.classList.add('working');
}
function applyRequestSuccess(element) {
  element.classList.remove('working');
  element.classList.add('updated');
  setTimeout(() => element.classList.remove('updated'), 3000);
}
function applyRequestError(refElement, errorContainer, fields) {
  refElement.childNodes.forEach(c => c.childNodes.forEach(n => n.disabled = false));
  refElement.classList.remove('working');
  refElement.classList.add('failed');
  console.warn(errorContainer);

  if (errorContainer.message !== undefined) {
    alert(errorContainer.message);
  } else {
    for (let error of Object.keys(errorContainer)) {
      if (error.length == 0) {
        alert(errorContainer[error].errors.join('\n'));
      } else {
        const field = fields[error];

        for (let message of errorContainer[error].errors) {
          field.appendChild(element('p', message));
        }
      }
    }
  }
}
function createCheckbox(name, data, text, onChange, defaultValue = false) {
  const id = 'ses-' + name;
  let value = readPrevInput();
  data[name] = value;
  let element = document.createElement('input');
  element.type = 'checkbox';
  element.id = id;
  element.name = name;
  let label = document.createElement('label');
  label.htmlFor = id;
  label.textContent = text;
  /*
  let element = <input type="checkbox" className="ses-check" id={id} name={name} />;
  let label = <label for={id}>{text}</label>;
  */

  element.checked = value;
  element.addEventListener('change', toggle);

  function readPrevInput() {
    let prevInput = document.getElementById(id);

    if (prevInput) {
      return prevInput.checked;
    } else {
      return defaultValue;
    }
  }

  function toggle(e) {
    value = e.target.checked;
    data[name] = value;
    redraw();
  }

  function redraw() {
    try {
      onChange();
    } catch (err) {
      console.log(err.message);
    }
  }

  const checkbox = {
    element,
    label
  };
  Object.defineProperty(checkbox, 'value', {
    get: () => value,
    set: newValue => {
      value = newValue;
      element.checked = value;
      data[name] = value;
      redraw();
    }
  });
  return checkbox;
}
function table(data, layout) {
  const thead = element('thead', element('tr', layout.map(h => element('th', h.label))));
  const tbody = element('tbody', data.map(r => element('tr', layout.map(h => element('td', r[h.name])))));
  const table = element('table', [thead, tbody]);
  table.thead = thead;
  table.tbody = tbody;
  return table;
}
function Autocomplete({
  values,
  current
}) {
  let autocomplete = element('div', [element('input', undefined, {
    className: 'ses-search-autocomplete-input'
  }), element('div', element('ul'), {
    className: 'ses-search-autocomplete-suggestions'
  })], {
    className: 'ses-search-autocomplete-container'
  });
  const suggestionsContainer = autocomplete.querySelector('.ses-search-autocomplete-suggestions');
  const input = autocomplete.querySelector('.ses-search-autocomplete-input');
  let selectedIndex = undefined;

  if (current != undefined) {
    input.value = current;
  }

  autocomplete.getValue = function () {
    return input.value;
  };

  function searchHandler(e) {
    const inputVal = e.currentTarget.value;
    let results = values;

    if (inputVal.length > 0) {
      results = values.filter(x => x.toLowerCase().indexOf(inputVal.toLowerCase()) > -1);
    }

    showSuggestions(results, inputVal);

    if (e.keyCode === 38 || e.keyCode === 40 || e.keyCode === 13) {
      scrollResults(e);
    }
  }

  function showSuggestions(results, inputVal) {
    let suggestions = suggestionsContainer.querySelector('ul');
    replaceContents(suggestions, '');
    suggestions = suggestionsContainer.querySelector('ul');
    ;

    if (results.length > 0) {
      for (let i = 0; i < results.length; i++) {
        let item = results[i];
        const match = item.match(new RegExp(inputVal, 'i'));
        item = item.replace(match[0], `<strong>${match[0]}</strong>`);
        let newLi = element('li', item, undefined, {
          forceType: "HTML"
        });
        suggestions.appendChild(newLi);
      }

      suggestions.classList.add('has-suggestions');
    } else {
      suggestions.classList.remove('has-suggestions');
    }
  }

  function useSuggestion(e) {
    input.value = e.target.textContent;
    input.focus();
    let suggestions = suggestionsContainer.querySelector('ul');
    replaceContents(suggestions, '');
    suggestions = suggestionsContainer.querySelector('ul');
    suggestions.classList.remove('has-suggestions');
  }

  function scrollResults(e) {
    let allSuggestions = [...suggestionsContainer.querySelectorAll('ul li')];
    let oldIndex = undefined;
    let indexChange = 1; // enter

    if (e.keyCode === 13) {
      input.value = allSuggestions[selectedIndex].textContent;
      selectedIndex = undefined;
      let suggestions = suggestionsContainer.querySelector('ul');
      suggestions.classList.remove('has-suggestions');
      return;
    }

    if (e.keyCode === 40) {
      // down arrow
      indexChange = 1;
    } else if (e.keyCode === 38) {
      // up arrow
      indexChange = -1;
    }

    if (selectedIndex == undefined) {
      selectedIndex = indexChange === 1 ? 0 : allSuggestions.length - 1;
    } else {
      oldIndex = selectedIndex;
      selectedIndex = (selectedIndex + indexChange + allSuggestions.length) % allSuggestions.length;
    }

    if (oldIndex !== undefined && oldIndex < allSuggestions.length) {
      allSuggestions[oldIndex].classList.remove('selected');
    }

    allSuggestions[selectedIndex].classList.add('selected');
  }

  input.addEventListener('keyup', searchHandler);
  suggestionsContainer.addEventListener('click', useSuggestion);
  return autocomplete;
}
/**
 * Creates a span element that represents a download progress bar
 * @param { {downloadFunction: (onProgress: import('./util.js').OnProgressFunction), returnFunction: function} } settings Contains the function that will download the resources, which will be called with onProgress
 * and the returnFunction which will be called with the results after the download finishes
 */

function DownloadProgressBar({
  downloadFunction,
  returnFunction
}) {
  const percent = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_1__["default"])("span", null, "0%");
  const bar = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_1__["default"])("span", {
    style: {
      padding: '0 0.5em',
      display: 'inline-block',
      width: '25%',
      background: 'linear-gradient(to right, #ffa000 0%, #eee 0)'
    }
  }, percent, " \u0421\u0432\u0430\u043B\u044F\u043D\u0435");
  downloadFunction(onProgress).then(data => {
    if (returnFunction) {
      returnFunction(data);
    }
  });
  return bar;

  function onProgress(completed, total, response, index) {
    const progress = Math.floor(completed / total * 100);
    percent.textContent = progress + '%';
    bar.style.background = `linear-gradient(to right, #ffa000 ${progress}%, #eee 0)`;
  }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  element
});

/***/ }),

/***/ "./src/util/util.js":
/*!**************************!*\
  !*** ./src/util/util.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "assertTemplate": () => (/* binding */ assertTemplate),
/* harmony export */   "createThrottledExecutor": () => (/* binding */ createThrottledExecutor),
/* harmony export */   "crossBrowserFileUpload": () => (/* binding */ crossBrowserFileUpload),
/* harmony export */   "distribute": () => (/* binding */ distribute),
/* harmony export */   "download": () => (/* binding */ download),
/* harmony export */   "escapeHTML": () => (/* binding */ escapeHTML),
/* harmony export */   "exportPaymentsToXlsx": () => (/* binding */ exportPaymentsToXlsx),
/* harmony export */   "exportToJson": () => (/* binding */ exportToJson),
/* harmony export */   "exportToXlsx": () => (/* binding */ exportToXlsx),
/* harmony export */   "getExcludedModuleInstances": () => (/* binding */ getExcludedModuleInstances),
/* harmony export */   "getExcludedModules": () => (/* binding */ getExcludedModules),
/* harmony export */   "getFundamentalLevelIds": () => (/* binding */ getFundamentalLevelIds),
/* harmony export */   "getLocale": () => (/* binding */ getLocale),
/* harmony export */   "getMime": () => (/* binding */ getMime),
/* harmony export */   "getProfessionInstanceIds": () => (/* binding */ getProfessionInstanceIds),
/* harmony export */   "getSubsite": () => (/* binding */ getSubsite),
/* harmony export */   "hasCPOAccess": () => (/* binding */ hasCPOAccess),
/* harmony export */   "iconAsset": () => (/* binding */ iconAsset),
/* harmony export */   "importFromXlsx": () => (/* binding */ importFromXlsx),
/* harmony export */   "importQuizFromXlsx": () => (/* binding */ importQuizFromXlsx),
/* harmony export */   "isAdmin": () => (/* binding */ isAdmin),
/* harmony export */   "openFile": () => (/* binding */ openFile),
/* harmony export */   "roundUpWithPrecision": () => (/* binding */ roundUpWithPrecision),
/* harmony export */   "serializeCalls": () => (/* binding */ serializeCalls),
/* harmony export */   "toLegacyXlsFile": () => (/* binding */ toLegacyXlsFile),
/* harmony export */   "toXlsxFile": () => (/* binding */ toXlsxFile),
/* harmony export */   "withProgress": () => (/* binding */ withProgress),
/* harmony export */   "zipFiles": () => (/* binding */ zipFiles)
/* harmony export */ });
/* harmony import */ var _parse__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parse */ "./src/util/parse.js");
/* globals xlsx, JSZip */

function importQuizFromXlsx(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = function (e) {
      const fileData = e.target.result;
      const wb = xlsx.read(fileData, {
        type: 'binary'
      });
      const firstSheet = wb.Sheets[wb.SheetNames[0]];
      const apiData = xlsx.utils.sheet_to_json(firstSheet, {
        header: 1
      }).slice(1) // remove first row
      .reduce((data, currentRow) => {
        if (currentRow.length !== 0) {
          const correctAnswerIndex = currentRow.pop();
          const question = currentRow[0];
          const allAnswers = currentRow.slice(1);
          const correctAnswer = currentRow[correctAnswerIndex];
          data[question] = allAnswers.reduce((answers, a) => {
            if (a != undefined && a.toString().trim() !== '') {
              answers[a] = a === correctAnswer;
            }

            return answers;
          }, {});
        }

        return data;
      }, {});
      resolve(apiData);
    };

    reader.readAsBinaryString(blob);
  });
}
function importFromXlsx(blob, useCellDates = false) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = function (e) {
      const file = e.target.result;

      try {
        const wb = xlsx.read(file, {
          type: 'binary',
          cellDates: useCellDates
        });
        const firstSheet = wb.Sheets[wb.SheetNames[0]];
        const data = xlsx.utils.sheet_to_json(firstSheet, {
          header: 1
        });
        resolve(data);
      } catch (err) {
        console.log('Error parsing XLSX file, make sure the library is loaded');
        reject(err);
      }
    };

    reader.onerror = function (e) {
      console.log('Error reading file');
      reject(e);
    };

    reader.readAsBinaryString(blob);
  });
}
function toXlsxFile(table, name = 'Output', ws_name) {
  if (ws_name === undefined) {
    ws_name = name.slice(0, 31);
  }

  const wb = xlsx.utils.book_new(),
        ws = xlsx.utils.aoa_to_sheet(table); // wb.Workbook = { Views: ['Window2'] };

  xlsx.utils.book_append_sheet(wb, ws, ws_name);
  const data = xlsx.write(wb, {
    type: 'array',
    bookType: 'xlsx'
  });
  const file = new File([data], name + '.xlsx', {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  });
  return file;
}
function toLegacyXlsFile(table, name = 'Output', ws_name) {
  if (ws_name === undefined) {
    ws_name = name.slice(0, 31);
  }

  const wb = xlsx.utils.book_new(),
        ws = xlsx.utils.aoa_to_sheet(table);
  wb.Workbook = {
    Views: ['Window2']
  };
  xlsx.utils.book_append_sheet(wb, ws, ws_name);
  const data = xlsx.write(wb, {
    type: 'array',
    bookType: 'biff8'
  });
  const file = new File([data], name + '.xls', {
    type: 'application/vnd.ms-excel'
  });
  return file;
}
function exportToXlsx(table, name = 'Output', ws_name) {
  const filename = `${name}.xlsx`;

  if (ws_name === undefined) {
    ws_name = name.slice(0, 31);
  } // Sheet name cannot contain: \ / ? * [ ]


  const sheetRegex = /[\[\]\\\/\*]/gi;

  if (sheetRegex.test(ws_name)) {
    ws_name = ws_name.replace(sheetRegex, '-');
  }

  const wb = xlsx.utils.book_new(),
        ws = xlsx.utils.aoa_to_sheet(table);
  xlsx.utils.book_append_sheet(wb, ws, ws_name);
  xlsx.writeFile(wb, filename);
}
function exportPaymentsToXlsx(data, year, month) {
  const filename = `Payments-${_parse__WEBPACK_IMPORTED_MODULE_0__["default"].monthName[month]}-${year}.xlsx`;
  const ws_name = `Payments ${_parse__WEBPACK_IMPORTED_MODULE_0__["default"].monthName[month]} ${year}`;
  const wb = xlsx.utils.book_new(),
        ws = xlsx.utils.aoa_to_sheet(data);
  xlsx.utils.book_append_sheet(wb, ws, ws_name);
  xlsx.writeFile(wb, filename);
}
function exportToJson(data, name = 'Output') {
  const blob = new Blob([data], {
    type: 'application/json'
  });

  if (window.navigator.msSaveOrOpenBlob) {
    window.navigator.msSaveBlob(blob, name + '.json');
  } else {
    var elem = window.document.createElement('a');
    elem.href = window.URL.createObjectURL(blob);
    elem.download = name + '.json';
    document.body.appendChild(elem);
    elem.click();
    document.body.removeChild(elem);
  }
}
/**
 * @param {{folder: string, files: File[]}[]} files 
 */

async function zipFiles(files) {
  const zip = new JSZip();

  for (let entry of files) {
    const current = zip.folder(entry.folder);
    current.file(entry.files.photo.name, await blobToBase64(entry.files.photo.file), {
      base64: true
    });
    current.file(entry.files.medical.name, await blobToBase64(entry.files.medical.file), {
      base64: true
    });
    current.file(entry.files.diploma.name, await blobToBase64(entry.files.diploma.file), {
      base64: true
    });
  }

  return zip.generateAsync({
    type: 'blob'
  });

  function blobToBase64(blob) {
    return new Promise(resolve => {
      const reader = new FileReader();

      reader.onload = function () {
        const dataUrl = reader.result;
        const base64 = dataUrl.split(',')[1];
        resolve(base64);
      };

      reader.readAsDataURL(blob);
    });
  }

  ;
}
const mimes = {
  'bmp': 'image/bmp',
  'gif': 'image/gif',
  'jpeg': 'image/jpeg',
  'jpg': 'image/jpeg',
  'png': 'image/png',
  'pdf': 'application/pdf',
  'tif': 'image/tiff',
  'tiff': 'image/tiff',
  'webp': 'image/webp',
  'zip': 'application/zip',
  '7z': 'application/x-7z-compressed',
  'tar': 'application/x-tar',
  'rar': 'application/vnd.rar'
};
function getMime(extension) {
  extension = extension.toLocaleLowerCase();
  return mimes[extension] || 'application/octet-stream';
}
async function openFile(file, name = 'output.txt') {
  try {
    var elem = window.document.createElement('a');
    elem.target = '_blank';
    elem.download = name;
    const href = window.URL.createObjectURL(file);
    elem.href = href;
    elem.click();
    setTimeout(() => URL.revokeObjectURL(href), 60000);
  } catch (err) {
    console.error(err);
  }
}
function download(blob, name = 'output.txt') {
  if (window.navigator.msSaveOrOpenBlob) {
    window.navigator.msSaveBlob(blob, name);
  } else {
    var elem = window.document.createElement('a');
    elem.target = '_blank';
    const href = window.URL.createObjectURL(blob);
    elem.href = href;
    elem.download = name;
    elem.click();
    setTimeout(() => URL.revokeObjectURL(href), 60000);
  }
}
async function crossBrowserFileUpload(apiCall, file) {
  if (!!window.chrome) {
    const fileUrl = URL.createObjectURL(file);
    const result = await apiCall({
      fileUrl,
      name: file.name
    });
    URL.revokeObjectURL(fileUrl);
    return result;
  } else {
    return await apiCall({
      file
    });
  }
}
function getSubsite() {
  switch (window.location.host.substr(0, 7)) {
    case 'digital':
      return 'digital';

    case 'creativ':
      return 'creative';

    case 'platfor':
      return 'platform';

    case 'ai.soft':
      return 'ai';

    case 'finance':
      return 'financeacademy';

    case 'dev.dig':
      return 'devdigital';

    case 'dev.sof':
      return 'devsoftuni';

    default:
      return 'programming';
  }
}
function hasCPOAccess() {
  return ['digital', 'creative', 'programming', 'devdigital', 'devsoftuni'].includes(getSubsite());
}
function isAdmin() {
  const e = document.querySelectorAll('a[href="/administration/navigation" i]');

  if (e.length > 0) {
    return true;
  } else {
    return false;
  }
}
function serializeCalls(fnArray, delay) {
  const callArray = [];

  if (delay !== undefined) {
    for (let i = 0; i < fnArray.length; i++) {
      const handler = (res, rej) => {
        setTimeout(async () => {
          try {
            const result = await fnArray[i]();
            res(result);
          } catch (err) {
            rej(err);
          }
        }, i * delay);
      };

      const pr = new Promise(handler);
      callArray.push(pr);
    }
  } else {
    for (let i = 0; i < fnArray.length; i++) {
      const handler = (res, rej) => {
        if (i > 0) {
          callArray[i - 1].finally(async () => {
            try {
              const result = await fnArray[i]();
              res(result);
            } catch (err) {
              rej(err);
            }
          });
        } else {
          fnArray[i]().then(res).catch(rej);
        }
      };

      const pr = new Promise(handler);
      callArray.push(pr);
    }
  }

  return callArray;
}
async function withProgress(callArray, onChange, delay = 10) {
  return new Promise((resolve, reject) => {
    // Failsave for empty callArray
    if (callArray.length == 0) {
      onChange(undefined, 0, 1, 1);
      resolve([]);
    }

    let resolved = 0;
    const response = [];
    callNext(0);

    function callNext(i) {
      if (i >= callArray.length) {
        return;
      } else {
        callArray[i].then(res => onResolve(res, i)).catch(onError);
        setTimeout(() => callNext(i + 1), delay);
      }
    }

    function onResolve(res, index) {
      resolved++;

      if (onChange) {
        onChange(res, index, resolved, callArray.length);
      }

      response[index] = res;

      if (resolved === callArray.length) {
        resolve(response);
      }
    }

    function onError(e) {
      reject(e);
    }
  });
}
/**
 * @typedef {(completed: number, total: number, response, index: number) => void} OnProgressFunction
 */

/**
 * @typedef {() => Promise} AsyncFunction
 */

/**
 * Initiate remote calls at intervals
 * @param {Array<AsyncFunction>} fnArray 
 * @param {OnProgressFunction} onProgress 
 * @param {number} [delay=10]
 * @returns 
 */

async function distribute(fnArray, onProgress, delay = 10) {
  return new Promise((resolve, reject) => {
    const total = fnArray.length;
    let completed = 0;
    let resolved = 0; // Failsave for empty fnArray

    if (total == 0) {
      if (typeof onProgress == 'function') {
        onProgress(undefined, 0, 1, 1);
      }

      resolve([]);
    }

    const calls = fnArray.map((fn, i) => {
      const call = {
        fn,
        sent: false,
        cancelled: false,
        response: undefined,
        timer: null
      };
      call.onCall = onCall.bind(call, i);
      call.cancel = onCancel.bind(call);
      call.timer = setTimeout(call.onCall, i * delay);
      return call;
    });
    calls.forEach((c, i) => c.next = calls[i + 1]);

    async function onCall(i) {
      if (this.sent == false) {
        clearTimeout(this.timer);
      }

      if (this.cancelled == false) {
        this.sent = true;

        try {
          const promise = this.fn();
          this.response = await promise;

          if (promise._cacheHit && this.next) {
            this.next.onCall();
          }

          resolved++;

          if (this.cancelled == false && resolved === total) {
            resolve(calls.map(c => c.response));
          }
        } catch (err) {
          onError(err);
        }
      }

      completed++;

      if (typeof onProgress == 'function') {
        onProgress(completed, total, this.response, i);
      }
    }

    function onCancel() {
      if (this.cancelled == false) {
        this.cancelled = true;

        if (this.sent == false) {
          clearTimeout(this.timer);
          this.onCall();
        }
      }
    }

    function onError(e) {
      calls.forEach(c => c.cancel());

      if (e instanceof Error) {
        e._responses = calls.map(c => c.response);
      }

      reject(e);
    }
  });
}
function assertTemplate(template, target, bottom = false) {
  if (template.Data !== undefined && template.Total !== undefined) {
    template = template.Data;
    target = target.Data;
  }

  if (Array.isArray(template)) {
    if (Array.isArray(target)) {
      if (bottom) {
        return;
      } else {
        assertTemplate(template[0], target[0], true);
      }
    } else {
      throw new TypeError('Target type mismatch');
    }
  } else if (typeof template === 'object') {
    if (typeof target === 'object') {
      const model = Object.keys(template);

      for (let prop of model) {
        if (target.hasOwnProperty(prop) === false) {
          throw new TypeError('Missing property on target: ' + prop);
        }
      }
    } else {
      throw new TypeError('Target type mismatch');
    }
  } else if (typeof template !== typeof target) {
    throw new TypeError('Target type mismatch');
  } else {
    return true;
  }
}
function getLocale() {
  return 'bg';
}
function createThrottledExecutor(callback, delay) {
  let timer = null;
  return function (...params) {
    clear();
    timer = setTimeout(() => {
      clear();
      callback(...params);
    }, delay);
  };

  function clear() {
    if (timer !== null) {
      clearTimeout(timer);
    }
  }
}
function iconAsset(name) {
  return browser.runtime.getURL(`icons/${name}.png`);
}
function escapeHTML(str) {
  return str.replace(/[&<>]/g, tag => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;'
  })[tag]);
}
;
function getFundamentalLevelIds(appname) {
  return {
    'programming': [19, 44, 57, 70, 106],
    'digital': [6, 7, 8, 23, 24, 25, 27, 33, 35, 40],
    'creative': [23, 24, 42, 52]
  }[appname];
}
function getProfessionInstanceIds(appname) {
  return {
    // Commented are for QA
    'programming': [1007, 1009, 1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1020, 1022, 1023, 1024, 1025, 1026, // 1028,
    1029, 1030, 1031, 1032, 1033, 1034, 1035, 1036, 1037, 1038, 1039, 1040, 1041, 1042, 1043, 1044, 1045, 1046, 1047, 1048, 1049, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1062, 1063, 1064, 1065, 1066, // 1067,
    // 1068,
    // 1069,
    1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078],
    'digital': [1, 3, 4, 5, 6, 7, 8, 9],
    'creative': [1, 3, 4, 5],
    'devdigital': [1, 3, 4, 5, 6, 7, 8, 9],
    'ai': []
  }[appname];
}
function getExcludedModules(appname) {
  return {
    'programming': [2]
  }[appname];
}
function getExcludedModuleInstances(appname) {
  return {
    'digital': [5, 50],
    'creative': [1, 14, 28, 46],
    'devdigital': [5, 50]
  }[appname];
}
/**
 * @description Rounds up a number up to specified number of decimal places using a specified number of decimal places as precision.
 * This allows correct rounding of problematic floating point numbers like "55.00000000000001" or "0.460000000000001"
 * @param {Number} number The number to round up
 * @param {Number} decimalPlacesToRoundTo The number of decimal places to round to
 * @param {Number} decimalPlacesPrecision The number of decimal places that should be considered for the rounding. Should be larger than decimalPlacesToRoundTo
 * @returns The rounded number
 */

function roundUpWithPrecision(number, decimalPlacesToRoundTo, decimalPlacesPrecision) {
  if (decimalPlacesPrecision <= decimalPlacesToRoundTo) {
    throw new RangeError('decimalPlacesPrecision should be larger than decimalPlacesToRoundTo');
  }

  let precisionValue = 10 ** decimalPlacesPrecision;
  let roundingValue = 10 ** decimalPlacesToRoundTo;
  let roundingValueBigInt = BigInt(roundingValue);
  let precisionDifferenceValue = BigInt(precisionValue / roundingValue);
  let bigInt = BigInt(Math.trunc(number * precisionValue));
  let roundedPlacesNumberPart = bigInt / precisionDifferenceValue;
  let precisionDifferenceLeftover = bigInt % precisionDifferenceValue;
  roundedPlacesNumberPart += precisionDifferenceLeftover > 0 ? 1n : 0n;
  let numberPart = roundedPlacesNumberPart / roundingValueBigInt;
  let decimalPart = roundedPlacesNumberPart % roundingValueBigInt;
  let roundedNum = Number(`${numberPart}.${decimalPart.toString().padStart(decimalPlacesToRoundTo, '0')}`);
  return roundedNum;
}

/***/ }),

/***/ "./node_modules/json5/dist/index.min.js":
/*!**********************************************!*\
  !*** ./node_modules/json5/dist/index.min.js ***!
  \**********************************************/
/***/ (function(module) {

!function(u,D){ true?module.exports=D():0}(this,function(){"use strict";function u(u,D){return u(D={exports:{}},D.exports),D.exports}var D=u(function(u){var D=u.exports="undefined"!=typeof window&&window.Math==Math?window:"undefined"!=typeof self&&self.Math==Math?self:Function("return this")();"number"==typeof __g&&(__g=D)}),e=u(function(u){var D=u.exports={version:"2.6.5"};"number"==typeof __e&&(__e=D)}),t=(e.version,function(u){return"object"==typeof u?null!==u:"function"==typeof u}),r=function(u){if(!t(u))throw TypeError(u+" is not an object!");return u},F=function(u){try{return!!u()}catch(u){return!0}},n=!F(function(){return 7!=Object.defineProperty({},"a",{get:function(){return 7}}).a}),C=D.document,A=t(C)&&t(C.createElement),i=!n&&!F(function(){return 7!=Object.defineProperty((u="div",A?C.createElement(u):{}),"a",{get:function(){return 7}}).a;var u}),E=Object.defineProperty,o={f:n?Object.defineProperty:function(u,D,e){if(r(u),D=function(u,D){if(!t(u))return u;var e,r;if(D&&"function"==typeof(e=u.toString)&&!t(r=e.call(u)))return r;if("function"==typeof(e=u.valueOf)&&!t(r=e.call(u)))return r;if(!D&&"function"==typeof(e=u.toString)&&!t(r=e.call(u)))return r;throw TypeError("Can't convert object to primitive value")}(D,!0),r(e),i)try{return E(u,D,e)}catch(u){}if("get"in e||"set"in e)throw TypeError("Accessors not supported!");return"value"in e&&(u[D]=e.value),u}},a=n?function(u,D,e){return o.f(u,D,function(u,D){return{enumerable:!(1&u),configurable:!(2&u),writable:!(4&u),value:D}}(1,e))}:function(u,D,e){return u[D]=e,u},c={}.hasOwnProperty,B=function(u,D){return c.call(u,D)},s=0,f=Math.random(),l=u(function(u){var t=D["__core-js_shared__"]||(D["__core-js_shared__"]={});(u.exports=function(u,D){return t[u]||(t[u]=void 0!==D?D:{})})("versions",[]).push({version:e.version,mode:"global",copyright:"© 2019 Denis Pushkarev (zloirock.ru)"})})("native-function-to-string",Function.toString),d=u(function(u){var t,r="Symbol(".concat(void 0===(t="src")?"":t,")_",(++s+f).toString(36)),F=(""+l).split("toString");e.inspectSource=function(u){return l.call(u)},(u.exports=function(u,e,t,n){var C="function"==typeof t;C&&(B(t,"name")||a(t,"name",e)),u[e]!==t&&(C&&(B(t,r)||a(t,r,u[e]?""+u[e]:F.join(String(e)))),u===D?u[e]=t:n?u[e]?u[e]=t:a(u,e,t):(delete u[e],a(u,e,t)))})(Function.prototype,"toString",function(){return"function"==typeof this&&this[r]||l.call(this)})}),v=function(u,D,e){if(function(u){if("function"!=typeof u)throw TypeError(u+" is not a function!")}(u),void 0===D)return u;switch(e){case 1:return function(e){return u.call(D,e)};case 2:return function(e,t){return u.call(D,e,t)};case 3:return function(e,t,r){return u.call(D,e,t,r)}}return function(){return u.apply(D,arguments)}},p=function(u,t,r){var F,n,C,A,i=u&p.F,E=u&p.G,o=u&p.S,c=u&p.P,B=u&p.B,s=E?D:o?D[t]||(D[t]={}):(D[t]||{}).prototype,f=E?e:e[t]||(e[t]={}),l=f.prototype||(f.prototype={});for(F in E&&(r=t),r)C=((n=!i&&s&&void 0!==s[F])?s:r)[F],A=B&&n?v(C,D):c&&"function"==typeof C?v(Function.call,C):C,s&&d(s,F,C,u&p.U),f[F]!=C&&a(f,F,A),c&&l[F]!=C&&(l[F]=C)};D.core=e,p.F=1,p.G=2,p.S=4,p.P=8,p.B=16,p.W=32,p.U=64,p.R=128;var h,m=p,g=Math.ceil,y=Math.floor,w=function(u){return isNaN(u=+u)?0:(u>0?y:g)(u)},S=(h=!1,function(u,D){var e,t,r=String(function(u){if(null==u)throw TypeError("Can't call method on  "+u);return u}(u)),F=w(D),n=r.length;return F<0||F>=n?h?"":void 0:(e=r.charCodeAt(F))<55296||e>56319||F+1===n||(t=r.charCodeAt(F+1))<56320||t>57343?h?r.charAt(F):e:h?r.slice(F,F+2):t-56320+(e-55296<<10)+65536});m(m.P,"String",{codePointAt:function(u){return S(this,u)}});e.String.codePointAt;var b=Math.max,x=Math.min,N=String.fromCharCode,P=String.fromCodePoint;m(m.S+m.F*(!!P&&1!=P.length),"String",{fromCodePoint:function(u){for(var D,e,t,r=arguments,F=[],n=arguments.length,C=0;n>C;){if(D=+r[C++],t=1114111,((e=w(e=D))<0?b(e+t,0):x(e,t))!==D)throw RangeError(D+" is not a valid code point");F.push(D<65536?N(D):N(55296+((D-=65536)>>10),D%1024+56320))}return F.join("")}});e.String.fromCodePoint;var _,I,O,j,V,J,M,k,L,T,z,H,$,R,G={Space_Separator:/[\u1680\u2000-\u200A\u202F\u205F\u3000]/,ID_Start:/[\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0559\u0561-\u0587\u05D0-\u05EA\u05F0-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u0860-\u086A\u08A0-\u08B4\u08B6-\u08BD\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u09FC\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C60\u0C61\u0C80\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D05-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D54-\u0D56\u0D5F-\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E87\u0E88\u0E8A\u0E8D\u0E94-\u0E97\u0E99-\u0E9F\u0EA1-\u0EA3\u0EA5\u0EA7\u0EAA\u0EAB\u0EAD-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u170C\u170E-\u1711\u1720-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1877\u1880-\u1884\u1887-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4B\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1C80-\u1C88\u1CE9-\u1CEC\u1CEE-\u1CF1\u1CF5\u1CF6\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2160-\u2188\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312E\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FEA\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6EF\uA717-\uA71F\uA722-\uA788\uA78B-\uA7AE\uA7B0-\uA7B7\uA7F7-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA8FD\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uA9E0-\uA9E4\uA9E6-\uA9EF\uA9FA-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB65\uAB70-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDD40-\uDD74\uDE80-\uDE9C\uDEA0-\uDED0\uDF00-\uDF1F\uDF2D-\uDF4A\uDF50-\uDF75\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF\uDFD1-\uDFD5]|\uD801[\uDC00-\uDC9D\uDCB0-\uDCD3\uDCD8-\uDCFB\uDD00-\uDD27\uDD30-\uDD63\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC60-\uDC76\uDC80-\uDC9E\uDCE0-\uDCF2\uDCF4\uDCF5\uDD00-\uDD15\uDD20-\uDD39\uDD80-\uDDB7\uDDBE\uDDBF\uDE00\uDE10-\uDE13\uDE15-\uDE17\uDE19-\uDE33\uDE60-\uDE7C\uDE80-\uDE9C\uDEC0-\uDEC7\uDEC9-\uDEE4\uDF00-\uDF35\uDF40-\uDF55\uDF60-\uDF72\uDF80-\uDF91]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2]|\uD804[\uDC03-\uDC37\uDC83-\uDCAF\uDCD0-\uDCE8\uDD03-\uDD26\uDD50-\uDD72\uDD76\uDD83-\uDDB2\uDDC1-\uDDC4\uDDDA\uDDDC\uDE00-\uDE11\uDE13-\uDE2B\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEDE\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3D\uDF50\uDF5D-\uDF61]|\uD805[\uDC00-\uDC34\uDC47-\uDC4A\uDC80-\uDCAF\uDCC4\uDCC5\uDCC7\uDD80-\uDDAE\uDDD8-\uDDDB\uDE00-\uDE2F\uDE44\uDE80-\uDEAA\uDF00-\uDF19]|\uD806[\uDCA0-\uDCDF\uDCFF\uDE00\uDE0B-\uDE32\uDE3A\uDE50\uDE5C-\uDE83\uDE86-\uDE89\uDEC0-\uDEF8]|\uD807[\uDC00-\uDC08\uDC0A-\uDC2E\uDC40\uDC72-\uDC8F\uDD00-\uDD06\uDD08\uDD09\uDD0B-\uDD30\uDD46]|\uD808[\uDC00-\uDF99]|\uD809[\uDC00-\uDC6E\uDC80-\uDD43]|[\uD80C\uD81C-\uD820\uD840-\uD868\uD86A-\uD86C\uD86F-\uD872\uD874-\uD879][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2E]|\uD811[\uDC00-\uDE46]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDED0-\uDEED\uDF00-\uDF2F\uDF40-\uDF43\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDF00-\uDF44\uDF50\uDF93-\uDF9F\uDFE0\uDFE1]|\uD821[\uDC00-\uDFEC]|\uD822[\uDC00-\uDEF2]|\uD82C[\uDC00-\uDD1E\uDD70-\uDEFB]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB]|\uD83A[\uDC00-\uDCC4\uDD00-\uDD43]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD869[\uDC00-\uDED6\uDF00-\uDFFF]|\uD86D[\uDC00-\uDF34\uDF40-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEA1\uDEB0-\uDFFF]|\uD87A[\uDC00-\uDFE0]|\uD87E[\uDC00-\uDE1D]/,ID_Continue:/[\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0300-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u0483-\u0487\u048A-\u052F\u0531-\u0556\u0559\u0561-\u0587\u0591-\u05BD\u05BF\u05C1\u05C2\u05C4\u05C5\u05C7\u05D0-\u05EA\u05F0-\u05F2\u0610-\u061A\u0620-\u0669\u066E-\u06D3\u06D5-\u06DC\u06DF-\u06E8\u06EA-\u06FC\u06FF\u0710-\u074A\u074D-\u07B1\u07C0-\u07F5\u07FA\u0800-\u082D\u0840-\u085B\u0860-\u086A\u08A0-\u08B4\u08B6-\u08BD\u08D4-\u08E1\u08E3-\u0963\u0966-\u096F\u0971-\u0983\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BC-\u09C4\u09C7\u09C8\u09CB-\u09CE\u09D7\u09DC\u09DD\u09DF-\u09E3\u09E6-\u09F1\u09FC\u0A01-\u0A03\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A3C\u0A3E-\u0A42\u0A47\u0A48\u0A4B-\u0A4D\u0A51\u0A59-\u0A5C\u0A5E\u0A66-\u0A75\u0A81-\u0A83\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABC-\u0AC5\u0AC7-\u0AC9\u0ACB-\u0ACD\u0AD0\u0AE0-\u0AE3\u0AE6-\u0AEF\u0AF9-\u0AFF\u0B01-\u0B03\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3C-\u0B44\u0B47\u0B48\u0B4B-\u0B4D\u0B56\u0B57\u0B5C\u0B5D\u0B5F-\u0B63\u0B66-\u0B6F\u0B71\u0B82\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BBE-\u0BC2\u0BC6-\u0BC8\u0BCA-\u0BCD\u0BD0\u0BD7\u0BE6-\u0BEF\u0C00-\u0C03\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D-\u0C44\u0C46-\u0C48\u0C4A-\u0C4D\u0C55\u0C56\u0C58-\u0C5A\u0C60-\u0C63\u0C66-\u0C6F\u0C80-\u0C83\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBC-\u0CC4\u0CC6-\u0CC8\u0CCA-\u0CCD\u0CD5\u0CD6\u0CDE\u0CE0-\u0CE3\u0CE6-\u0CEF\u0CF1\u0CF2\u0D00-\u0D03\u0D05-\u0D0C\u0D0E-\u0D10\u0D12-\u0D44\u0D46-\u0D48\u0D4A-\u0D4E\u0D54-\u0D57\u0D5F-\u0D63\u0D66-\u0D6F\u0D7A-\u0D7F\u0D82\u0D83\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0DCA\u0DCF-\u0DD4\u0DD6\u0DD8-\u0DDF\u0DE6-\u0DEF\u0DF2\u0DF3\u0E01-\u0E3A\u0E40-\u0E4E\u0E50-\u0E59\u0E81\u0E82\u0E84\u0E87\u0E88\u0E8A\u0E8D\u0E94-\u0E97\u0E99-\u0E9F\u0EA1-\u0EA3\u0EA5\u0EA7\u0EAA\u0EAB\u0EAD-\u0EB9\u0EBB-\u0EBD\u0EC0-\u0EC4\u0EC6\u0EC8-\u0ECD\u0ED0-\u0ED9\u0EDC-\u0EDF\u0F00\u0F18\u0F19\u0F20-\u0F29\u0F35\u0F37\u0F39\u0F3E-\u0F47\u0F49-\u0F6C\u0F71-\u0F84\u0F86-\u0F97\u0F99-\u0FBC\u0FC6\u1000-\u1049\u1050-\u109D\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u135D-\u135F\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u170C\u170E-\u1714\u1720-\u1734\u1740-\u1753\u1760-\u176C\u176E-\u1770\u1772\u1773\u1780-\u17D3\u17D7\u17DC\u17DD\u17E0-\u17E9\u180B-\u180D\u1810-\u1819\u1820-\u1877\u1880-\u18AA\u18B0-\u18F5\u1900-\u191E\u1920-\u192B\u1930-\u193B\u1946-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u19D0-\u19D9\u1A00-\u1A1B\u1A20-\u1A5E\u1A60-\u1A7C\u1A7F-\u1A89\u1A90-\u1A99\u1AA7\u1AB0-\u1ABD\u1B00-\u1B4B\u1B50-\u1B59\u1B6B-\u1B73\u1B80-\u1BF3\u1C00-\u1C37\u1C40-\u1C49\u1C4D-\u1C7D\u1C80-\u1C88\u1CD0-\u1CD2\u1CD4-\u1CF9\u1D00-\u1DF9\u1DFB-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u203F\u2040\u2054\u2071\u207F\u2090-\u209C\u20D0-\u20DC\u20E1\u20E5-\u20F0\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2160-\u2188\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D7F-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2DE0-\u2DFF\u2E2F\u3005-\u3007\u3021-\u302F\u3031-\u3035\u3038-\u303C\u3041-\u3096\u3099\u309A\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312E\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FEA\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA62B\uA640-\uA66F\uA674-\uA67D\uA67F-\uA6F1\uA717-\uA71F\uA722-\uA788\uA78B-\uA7AE\uA7B0-\uA7B7\uA7F7-\uA827\uA840-\uA873\uA880-\uA8C5\uA8D0-\uA8D9\uA8E0-\uA8F7\uA8FB\uA8FD\uA900-\uA92D\uA930-\uA953\uA960-\uA97C\uA980-\uA9C0\uA9CF-\uA9D9\uA9E0-\uA9FE\uAA00-\uAA36\uAA40-\uAA4D\uAA50-\uAA59\uAA60-\uAA76\uAA7A-\uAAC2\uAADB-\uAADD\uAAE0-\uAAEF\uAAF2-\uAAF6\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB65\uAB70-\uABEA\uABEC\uABED\uABF0-\uABF9\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE00-\uFE0F\uFE20-\uFE2F\uFE33\uFE34\uFE4D-\uFE4F\uFE70-\uFE74\uFE76-\uFEFC\uFF10-\uFF19\uFF21-\uFF3A\uFF3F\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDD40-\uDD74\uDDFD\uDE80-\uDE9C\uDEA0-\uDED0\uDEE0\uDF00-\uDF1F\uDF2D-\uDF4A\uDF50-\uDF7A\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF\uDFD1-\uDFD5]|\uD801[\uDC00-\uDC9D\uDCA0-\uDCA9\uDCB0-\uDCD3\uDCD8-\uDCFB\uDD00-\uDD27\uDD30-\uDD63\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC60-\uDC76\uDC80-\uDC9E\uDCE0-\uDCF2\uDCF4\uDCF5\uDD00-\uDD15\uDD20-\uDD39\uDD80-\uDDB7\uDDBE\uDDBF\uDE00-\uDE03\uDE05\uDE06\uDE0C-\uDE13\uDE15-\uDE17\uDE19-\uDE33\uDE38-\uDE3A\uDE3F\uDE60-\uDE7C\uDE80-\uDE9C\uDEC0-\uDEC7\uDEC9-\uDEE6\uDF00-\uDF35\uDF40-\uDF55\uDF60-\uDF72\uDF80-\uDF91]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2]|\uD804[\uDC00-\uDC46\uDC66-\uDC6F\uDC7F-\uDCBA\uDCD0-\uDCE8\uDCF0-\uDCF9\uDD00-\uDD34\uDD36-\uDD3F\uDD50-\uDD73\uDD76\uDD80-\uDDC4\uDDCA-\uDDCC\uDDD0-\uDDDA\uDDDC\uDE00-\uDE11\uDE13-\uDE37\uDE3E\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEEA\uDEF0-\uDEF9\uDF00-\uDF03\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3C-\uDF44\uDF47\uDF48\uDF4B-\uDF4D\uDF50\uDF57\uDF5D-\uDF63\uDF66-\uDF6C\uDF70-\uDF74]|\uD805[\uDC00-\uDC4A\uDC50-\uDC59\uDC80-\uDCC5\uDCC7\uDCD0-\uDCD9\uDD80-\uDDB5\uDDB8-\uDDC0\uDDD8-\uDDDD\uDE00-\uDE40\uDE44\uDE50-\uDE59\uDE80-\uDEB7\uDEC0-\uDEC9\uDF00-\uDF19\uDF1D-\uDF2B\uDF30-\uDF39]|\uD806[\uDCA0-\uDCE9\uDCFF\uDE00-\uDE3E\uDE47\uDE50-\uDE83\uDE86-\uDE99\uDEC0-\uDEF8]|\uD807[\uDC00-\uDC08\uDC0A-\uDC36\uDC38-\uDC40\uDC50-\uDC59\uDC72-\uDC8F\uDC92-\uDCA7\uDCA9-\uDCB6\uDD00-\uDD06\uDD08\uDD09\uDD0B-\uDD36\uDD3A\uDD3C\uDD3D\uDD3F-\uDD47\uDD50-\uDD59]|\uD808[\uDC00-\uDF99]|\uD809[\uDC00-\uDC6E\uDC80-\uDD43]|[\uD80C\uD81C-\uD820\uD840-\uD868\uD86A-\uD86C\uD86F-\uD872\uD874-\uD879][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2E]|\uD811[\uDC00-\uDE46]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDE60-\uDE69\uDED0-\uDEED\uDEF0-\uDEF4\uDF00-\uDF36\uDF40-\uDF43\uDF50-\uDF59\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDF00-\uDF44\uDF50-\uDF7E\uDF8F-\uDF9F\uDFE0\uDFE1]|\uD821[\uDC00-\uDFEC]|\uD822[\uDC00-\uDEF2]|\uD82C[\uDC00-\uDD1E\uDD70-\uDEFB]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99\uDC9D\uDC9E]|\uD834[\uDD65-\uDD69\uDD6D-\uDD72\uDD7B-\uDD82\uDD85-\uDD8B\uDDAA-\uDDAD\uDE42-\uDE44]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB\uDFCE-\uDFFF]|\uD836[\uDE00-\uDE36\uDE3B-\uDE6C\uDE75\uDE84\uDE9B-\uDE9F\uDEA1-\uDEAF]|\uD838[\uDC00-\uDC06\uDC08-\uDC18\uDC1B-\uDC21\uDC23\uDC24\uDC26-\uDC2A]|\uD83A[\uDC00-\uDCC4\uDCD0-\uDCD6\uDD00-\uDD4A\uDD50-\uDD59]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD869[\uDC00-\uDED6\uDF00-\uDFFF]|\uD86D[\uDC00-\uDF34\uDF40-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEA1\uDEB0-\uDFFF]|\uD87A[\uDC00-\uDFE0]|\uD87E[\uDC00-\uDE1D]|\uDB40[\uDD00-\uDDEF]/},U={isSpaceSeparator:function(u){return"string"==typeof u&&G.Space_Separator.test(u)},isIdStartChar:function(u){return"string"==typeof u&&(u>="a"&&u<="z"||u>="A"&&u<="Z"||"$"===u||"_"===u||G.ID_Start.test(u))},isIdContinueChar:function(u){return"string"==typeof u&&(u>="a"&&u<="z"||u>="A"&&u<="Z"||u>="0"&&u<="9"||"$"===u||"_"===u||"‌"===u||"‍"===u||G.ID_Continue.test(u))},isDigit:function(u){return"string"==typeof u&&/[0-9]/.test(u)},isHexDigit:function(u){return"string"==typeof u&&/[0-9A-Fa-f]/.test(u)}};function Z(){for(T="default",z="",H=!1,$=1;;){R=q();var u=X[T]();if(u)return u}}function q(){if(_[j])return String.fromCodePoint(_.codePointAt(j))}function W(){var u=q();return"\n"===u?(V++,J=0):u?J+=u.length:J++,u&&(j+=u.length),u}var X={default:function(){switch(R){case"\t":case"\v":case"\f":case" ":case" ":case"\ufeff":case"\n":case"\r":case"\u2028":case"\u2029":return void W();case"/":return W(),void(T="comment");case void 0:return W(),K("eof")}if(!U.isSpaceSeparator(R))return X[I]();W()},comment:function(){switch(R){case"*":return W(),void(T="multiLineComment");case"/":return W(),void(T="singleLineComment")}throw tu(W())},multiLineComment:function(){switch(R){case"*":return W(),void(T="multiLineCommentAsterisk");case void 0:throw tu(W())}W()},multiLineCommentAsterisk:function(){switch(R){case"*":return void W();case"/":return W(),void(T="default");case void 0:throw tu(W())}W(),T="multiLineComment"},singleLineComment:function(){switch(R){case"\n":case"\r":case"\u2028":case"\u2029":return W(),void(T="default");case void 0:return W(),K("eof")}W()},value:function(){switch(R){case"{":case"[":return K("punctuator",W());case"n":return W(),Q("ull"),K("null",null);case"t":return W(),Q("rue"),K("boolean",!0);case"f":return W(),Q("alse"),K("boolean",!1);case"-":case"+":return"-"===W()&&($=-1),void(T="sign");case".":return z=W(),void(T="decimalPointLeading");case"0":return z=W(),void(T="zero");case"1":case"2":case"3":case"4":case"5":case"6":case"7":case"8":case"9":return z=W(),void(T="decimalInteger");case"I":return W(),Q("nfinity"),K("numeric",1/0);case"N":return W(),Q("aN"),K("numeric",NaN);case'"':case"'":return H='"'===W(),z="",void(T="string")}throw tu(W())},identifierNameStartEscape:function(){if("u"!==R)throw tu(W());W();var u=Y();switch(u){case"$":case"_":break;default:if(!U.isIdStartChar(u))throw Fu()}z+=u,T="identifierName"},identifierName:function(){switch(R){case"$":case"_":case"‌":case"‍":return void(z+=W());case"\\":return W(),void(T="identifierNameEscape")}if(!U.isIdContinueChar(R))return K("identifier",z);z+=W()},identifierNameEscape:function(){if("u"!==R)throw tu(W());W();var u=Y();switch(u){case"$":case"_":case"‌":case"‍":break;default:if(!U.isIdContinueChar(u))throw Fu()}z+=u,T="identifierName"},sign:function(){switch(R){case".":return z=W(),void(T="decimalPointLeading");case"0":return z=W(),void(T="zero");case"1":case"2":case"3":case"4":case"5":case"6":case"7":case"8":case"9":return z=W(),void(T="decimalInteger");case"I":return W(),Q("nfinity"),K("numeric",$*(1/0));case"N":return W(),Q("aN"),K("numeric",NaN)}throw tu(W())},zero:function(){switch(R){case".":return z+=W(),void(T="decimalPoint");case"e":case"E":return z+=W(),void(T="decimalExponent");case"x":case"X":return z+=W(),void(T="hexadecimal")}return K("numeric",0*$)},decimalInteger:function(){switch(R){case".":return z+=W(),void(T="decimalPoint");case"e":case"E":return z+=W(),void(T="decimalExponent")}if(!U.isDigit(R))return K("numeric",$*Number(z));z+=W()},decimalPointLeading:function(){if(U.isDigit(R))return z+=W(),void(T="decimalFraction");throw tu(W())},decimalPoint:function(){switch(R){case"e":case"E":return z+=W(),void(T="decimalExponent")}return U.isDigit(R)?(z+=W(),void(T="decimalFraction")):K("numeric",$*Number(z))},decimalFraction:function(){switch(R){case"e":case"E":return z+=W(),void(T="decimalExponent")}if(!U.isDigit(R))return K("numeric",$*Number(z));z+=W()},decimalExponent:function(){switch(R){case"+":case"-":return z+=W(),void(T="decimalExponentSign")}if(U.isDigit(R))return z+=W(),void(T="decimalExponentInteger");throw tu(W())},decimalExponentSign:function(){if(U.isDigit(R))return z+=W(),void(T="decimalExponentInteger");throw tu(W())},decimalExponentInteger:function(){if(!U.isDigit(R))return K("numeric",$*Number(z));z+=W()},hexadecimal:function(){if(U.isHexDigit(R))return z+=W(),void(T="hexadecimalInteger");throw tu(W())},hexadecimalInteger:function(){if(!U.isHexDigit(R))return K("numeric",$*Number(z));z+=W()},string:function(){switch(R){case"\\":return W(),void(z+=function(){switch(q()){case"b":return W(),"\b";case"f":return W(),"\f";case"n":return W(),"\n";case"r":return W(),"\r";case"t":return W(),"\t";case"v":return W(),"\v";case"0":if(W(),U.isDigit(q()))throw tu(W());return"\0";case"x":return W(),function(){var u="",D=q();if(!U.isHexDigit(D))throw tu(W());if(u+=W(),D=q(),!U.isHexDigit(D))throw tu(W());return u+=W(),String.fromCodePoint(parseInt(u,16))}();case"u":return W(),Y();case"\n":case"\u2028":case"\u2029":return W(),"";case"\r":return W(),"\n"===q()&&W(),"";case"1":case"2":case"3":case"4":case"5":case"6":case"7":case"8":case"9":case void 0:throw tu(W())}return W()}());case'"':return H?(W(),K("string",z)):void(z+=W());case"'":return H?void(z+=W()):(W(),K("string",z));case"\n":case"\r":throw tu(W());case"\u2028":case"\u2029":!function(u){console.warn("JSON5: '"+nu(u)+"' in strings is not valid ECMAScript; consider escaping")}(R);break;case void 0:throw tu(W())}z+=W()},start:function(){switch(R){case"{":case"[":return K("punctuator",W())}T="value"},beforePropertyName:function(){switch(R){case"$":case"_":return z=W(),void(T="identifierName");case"\\":return W(),void(T="identifierNameStartEscape");case"}":return K("punctuator",W());case'"':case"'":return H='"'===W(),void(T="string")}if(U.isIdStartChar(R))return z+=W(),void(T="identifierName");throw tu(W())},afterPropertyName:function(){if(":"===R)return K("punctuator",W());throw tu(W())},beforePropertyValue:function(){T="value"},afterPropertyValue:function(){switch(R){case",":case"}":return K("punctuator",W())}throw tu(W())},beforeArrayValue:function(){if("]"===R)return K("punctuator",W());T="value"},afterArrayValue:function(){switch(R){case",":case"]":return K("punctuator",W())}throw tu(W())},end:function(){throw tu(W())}};function K(u,D){return{type:u,value:D,line:V,column:J}}function Q(u){for(var D=0,e=u;D<e.length;D+=1){var t=e[D];if(q()!==t)throw tu(W());W()}}function Y(){for(var u="",D=4;D-- >0;){var e=q();if(!U.isHexDigit(e))throw tu(W());u+=W()}return String.fromCodePoint(parseInt(u,16))}var uu={start:function(){if("eof"===M.type)throw ru();Du()},beforePropertyName:function(){switch(M.type){case"identifier":case"string":return k=M.value,void(I="afterPropertyName");case"punctuator":return void eu();case"eof":throw ru()}},afterPropertyName:function(){if("eof"===M.type)throw ru();I="beforePropertyValue"},beforePropertyValue:function(){if("eof"===M.type)throw ru();Du()},beforeArrayValue:function(){if("eof"===M.type)throw ru();"punctuator"!==M.type||"]"!==M.value?Du():eu()},afterPropertyValue:function(){if("eof"===M.type)throw ru();switch(M.value){case",":return void(I="beforePropertyName");case"}":eu()}},afterArrayValue:function(){if("eof"===M.type)throw ru();switch(M.value){case",":return void(I="beforeArrayValue");case"]":eu()}},end:function(){}};function Du(){var u;switch(M.type){case"punctuator":switch(M.value){case"{":u={};break;case"[":u=[]}break;case"null":case"boolean":case"numeric":case"string":u=M.value}if(void 0===L)L=u;else{var D=O[O.length-1];Array.isArray(D)?D.push(u):D[k]=u}if(null!==u&&"object"==typeof u)O.push(u),I=Array.isArray(u)?"beforeArrayValue":"beforePropertyName";else{var e=O[O.length-1];I=null==e?"end":Array.isArray(e)?"afterArrayValue":"afterPropertyValue"}}function eu(){O.pop();var u=O[O.length-1];I=null==u?"end":Array.isArray(u)?"afterArrayValue":"afterPropertyValue"}function tu(u){return Cu(void 0===u?"JSON5: invalid end of input at "+V+":"+J:"JSON5: invalid character '"+nu(u)+"' at "+V+":"+J)}function ru(){return Cu("JSON5: invalid end of input at "+V+":"+J)}function Fu(){return Cu("JSON5: invalid identifier character at "+V+":"+(J-=5))}function nu(u){var D={"'":"\\'",'"':'\\"',"\\":"\\\\","\b":"\\b","\f":"\\f","\n":"\\n","\r":"\\r","\t":"\\t","\v":"\\v","\0":"\\0","\u2028":"\\u2028","\u2029":"\\u2029"};if(D[u])return D[u];if(u<" "){var e=u.charCodeAt(0).toString(16);return"\\x"+("00"+e).substring(e.length)}return u}function Cu(u){var D=new SyntaxError(u);return D.lineNumber=V,D.columnNumber=J,D}return{parse:function(u,D){_=String(u),I="start",O=[],j=0,V=1,J=0,M=void 0,k=void 0,L=void 0;do{M=Z(),uu[I]()}while("eof"!==M.type);return"function"==typeof D?function u(D,e,t){var r=D[e];if(null!=r&&"object"==typeof r)for(var F in r){var n=u(r,F,t);void 0===n?delete r[F]:r[F]=n}return t.call(D,e,r)}({"":L},"",D):L},stringify:function(u,D,e){var t,r,F,n=[],C="",A="";if(null==D||"object"!=typeof D||Array.isArray(D)||(e=D.space,F=D.quote,D=D.replacer),"function"==typeof D)r=D;else if(Array.isArray(D)){t=[];for(var i=0,E=D;i<E.length;i+=1){var o=E[i],a=void 0;"string"==typeof o?a=o:("number"==typeof o||o instanceof String||o instanceof Number)&&(a=String(o)),void 0!==a&&t.indexOf(a)<0&&t.push(a)}}return e instanceof Number?e=Number(e):e instanceof String&&(e=String(e)),"number"==typeof e?e>0&&(e=Math.min(10,Math.floor(e)),A="          ".substr(0,e)):"string"==typeof e&&(A=e.substr(0,10)),c("",{"":u});function c(u,D){var e=D[u];switch(null!=e&&("function"==typeof e.toJSON5?e=e.toJSON5(u):"function"==typeof e.toJSON&&(e=e.toJSON(u))),r&&(e=r.call(D,u,e)),e instanceof Number?e=Number(e):e instanceof String?e=String(e):e instanceof Boolean&&(e=e.valueOf()),e){case null:return"null";case!0:return"true";case!1:return"false"}return"string"==typeof e?B(e):"number"==typeof e?String(e):"object"==typeof e?Array.isArray(e)?function(u){if(n.indexOf(u)>=0)throw TypeError("Converting circular structure to JSON5");n.push(u);var D=C;C+=A;for(var e,t=[],r=0;r<u.length;r++){var F=c(String(r),u);t.push(void 0!==F?F:"null")}if(0===t.length)e="[]";else if(""===A){var i=t.join(",");e="["+i+"]"}else{var E=",\n"+C,o=t.join(E);e="[\n"+C+o+",\n"+D+"]"}return n.pop(),C=D,e}(e):function(u){if(n.indexOf(u)>=0)throw TypeError("Converting circular structure to JSON5");n.push(u);var D=C;C+=A;for(var e,r,F=t||Object.keys(u),i=[],E=0,o=F;E<o.length;E+=1){var a=o[E],B=c(a,u);if(void 0!==B){var f=s(a)+":";""!==A&&(f+=" "),f+=B,i.push(f)}}if(0===i.length)e="{}";else if(""===A)r=i.join(","),e="{"+r+"}";else{var l=",\n"+C;r=i.join(l),e="{\n"+C+r+",\n"+D+"}"}return n.pop(),C=D,e}(e):void 0}function B(u){for(var D={"'":.1,'"':.2},e={"'":"\\'",'"':'\\"',"\\":"\\\\","\b":"\\b","\f":"\\f","\n":"\\n","\r":"\\r","\t":"\\t","\v":"\\v","\0":"\\0","\u2028":"\\u2028","\u2029":"\\u2029"},t="",r=0;r<u.length;r++){var n=u[r];switch(n){case"'":case'"':D[n]++,t+=n;continue;case"\0":if(U.isDigit(u[r+1])){t+="\\x00";continue}}if(e[n])t+=e[n];else if(n<" "){var C=n.charCodeAt(0).toString(16);t+="\\x"+("00"+C).substring(C.length)}else t+=n}var A=F||Object.keys(D).reduce(function(u,e){return D[u]<D[e]?u:e});return A+(t=t.replace(new RegExp(A,"g"),e[A]))+A}function s(u){if(0===u.length)return B(u);var D=String.fromCodePoint(u.codePointAt(0));if(!U.isIdStartChar(D))return B(u);for(var e=D.length;e<u.length;e++)if(!U.isIdContinueChar(String.fromCodePoint(u.codePointAt(e))))return B(u);return u}}}});


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
/*!******************************!*\
  !*** ./src/survey/survey.js ***!
  \******************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/jsx-render-mod/dom */ "./src/util/jsx-render-mod/dom.js");
/* harmony import */ var _util_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/api */ "./src/util/api.js");
/* harmony import */ var _util_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../util/router */ "./src/util/router.js");
/* harmony import */ var _util_parse__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../util/parse */ "./src/util/parse.js");
/* harmony import */ var _util_template__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../util/template */ "./src/util/template.js");
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./data */ "./src/survey/data.js");
/* harmony import */ var _Summary__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Summary */ "./src/survey/Summary.js");
/* harmony import */ var _Details__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Details */ "./src/survey/Details.js");








document.title = 'Survey Results';
document.querySelectorAll('.content')[0].innerHTML = '';
let container = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  id: "surveyContent"
});
document.querySelectorAll('.content')[0].appendChild((0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  class: "container administration-container"
}, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("section", {
  class: "container"
}, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("h1", null, "Survey Results"), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("section", {
  class: "bottom-buffer"
}, container))));
_util_router__WEBPACK_IMPORTED_MODULE_2__["default"].register([{
  match: null,
  handler: fetchSurveys
}, {
  match: 'page',
  handler: fetchSurveys
}, {
  match: 'search',
  handler: fetchSurveys
}, {
  match: 'id',
  handler: getDetails
}]);

async function fetchSurveys() {
  const query = _util_parse__WEBPACK_IMPORTED_MODULE_3__["default"].queryString(document.location.search);
  const page = Number(query && query.page) || 1;
  container = (0,_util_template__WEBPACK_IMPORTED_MODULE_4__.replaceContents)(container, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", null, "Loading surveys\u2026 ", (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_4__.Loading, {
    color: "black"
  })));
  const currentQuery = decodeURIComponent((query ? query.search : '') || '');
  const searchInput = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("form", {
    onSubmit: filterSurveys
  }, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("input", {
    type: "text",
    name: "query",
    value: currentQuery
  }), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("input", {
    type: "submit",
    value: "Filter"
  }));
  const response = await (0,_data__WEBPACK_IMPORTED_MODULE_5__.getSurveys)(_util_api__WEBPACK_IMPORTED_MODULE_1__, page, currentQuery);
  const pages = Math.ceil(response.Total / 30);
  container = (0,_util_template__WEBPACK_IMPORTED_MODULE_4__.replaceContents)(container, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_Summary__WEBPACK_IMPORTED_MODULE_6__["default"], {
    page: page,
    pages: pages,
    surveys: response.Data,
    pageSelect: fetchSurveys,
    getDetails: getDetails,
    getSummary: survey => (0,_data__WEBPACK_IMPORTED_MODULE_5__.getSummary)(_util_api__WEBPACK_IMPORTED_MODULE_1__, survey),
    getAdvancedSummary: (survey, onProgress = undefined) => (0,_data__WEBPACK_IMPORTED_MODULE_5__.getAdvancedSummary)(_util_api__WEBPACK_IMPORTED_MODULE_1__, survey, onProgress),
    getFinalizedSurveysExport: (startDate, endDate, onProgress = undefined) => (0,_data__WEBPACK_IMPORTED_MODULE_5__.getFinalizedSurveysExport)(_util_api__WEBPACK_IMPORTED_MODULE_1__, startDate, endDate, onProgress),
    searchInput: searchInput,
    searchQuery: currentQuery
  }));

  function filterSurveys(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    (0,_util_router__WEBPACK_IMPORTED_MODULE_2__.redirect)(`/ses/surveys?search=${encodeURIComponent(formData.get('query').trim() || '')}`);
  }
}

async function getDetails() {
  const query = _util_parse__WEBPACK_IMPORTED_MODULE_3__["default"].queryString(document.location.search);
  const surveyId = query.id;
  const survey = await (0,_data__WEBPACK_IMPORTED_MODULE_5__.getSurveyById)(_util_api__WEBPACK_IMPORTED_MODULE_1__, surveyId);
  let resultsDiv = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    id: "surveyResults"
  }, "Loading details\u2026 ", (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_template__WEBPACK_IMPORTED_MODULE_4__.Loading, {
    color: "black"
  }));
  container = (0,_util_template__WEBPACK_IMPORTED_MODULE_4__.replaceContents)(container, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])("h2", null, survey.Name), (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_util_router__WEBPACK_IMPORTED_MODULE_2__.Link, {
    to: fetchSurveys,
    className: "nav-back-link",
    href: "/ses/surveys"
  }, "Back to list"), resultsDiv));
  const summary = await (0,_data__WEBPACK_IMPORTED_MODULE_5__.getSummary)(_util_api__WEBPACK_IMPORTED_MODULE_1__, survey);

  const getAdvancedSummaryPartial = (s, onProgress) => (0,_data__WEBPACK_IMPORTED_MODULE_5__.getAdvancedSummary)(_util_api__WEBPACK_IMPORTED_MODULE_1__, s, onProgress);

  resultsDiv = (0,_util_template__WEBPACK_IMPORTED_MODULE_4__.replaceContents)(resultsDiv, (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_0__["default"])(_Details__WEBPACK_IMPORTED_MODULE_7__["default"], {
    survey: survey,
    summary: summary,
    getAdvancedSummary: getAdvancedSummaryPartial
  }));
}
})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9kZXYvL2NvbnRlbnQtc2NyaXB0cy9zdXJ2ZXkuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7OztBQzlDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6R0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoSUE7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7OztBQ3BGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hCQTtBQUNBO0FBQ0E7QUFJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1REE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFQQTtBQVVBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWZBOztBQWtCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBZEE7QUFnQkE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFkQTtBQWdCQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQWRBO0FBaUJBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFKQTtBQU1BO0FBQ0E7QUFFQTtBQVVBO0FBTUE7O0FBT0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMQTtBQU9BOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBTEE7O0FBUUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFEQTs7QUFJQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTs7Ozs7Ozs7Ozs7Ozs7O0FDelJBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFEQTtBQUlBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQURBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQURBO0FBSUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBekJBO0FBNEJBO0FBRUE7O0FBRUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUdBO0FBQ0E7QUFFQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBO0FBT0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUMzR0E7QUFHQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFNQTtBQUNBOztBQUVBO0FBQ0E7QUFFQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSkE7QUFPQTtBQUNBOztBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOzs7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMQTtBQVFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBckJBOztBQXdCQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQUtBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7O0FBR0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBVEE7QUFXQTs7QUFFQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDM01BO0FBRUE7QUFDQTs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBTEE7QUFPQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBREE7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQURBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFUQTs7QUFXQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBRUE7QUFDQTtBQUNBO0FBREE7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFJQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQURBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7QUFHQTs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSkE7QUFPQTtBQUVBO0FBRUE7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBREE7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQURBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUVBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFJQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBSUE7QUFDQTtBQUdBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQURBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWxCQTtBQW9CQTs7Ozs7Ozs7Ozs7Ozs7OztBQ3BjQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBTUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQU1BO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRkE7QUFJQTs7Ozs7Ozs7Ozs7Ozs7O0FDM0NBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQURBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQURBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFEQTtBQUlBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFNQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBO0FBT0E7Ozs7Ozs7Ozs7Ozs7OztBQ2xGQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUZBO0FBT0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUpBO0FBTUE7Ozs7Ozs7Ozs7Ozs7OztBQzdGQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBUEE7QUFVQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFkQTtBQWlCQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFSQTtBQVdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBO0FBUUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTEE7QUFRQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMQTtBQVFBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFOQTtBQVFBOzs7Ozs7Ozs7Ozs7Ozs7O0FDdEdBO0FBR0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBOztBQVFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFyQkE7QUF1QkE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFLQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFBQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKQTtBQU1BOzs7Ozs7Ozs7Ozs7Ozs7QUNoRkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMQTs7QUFRQTtBQUNBO0FBQ0E7QUFDQTtBQURBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQURBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU5BO0FBUUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBREE7O0FBR0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFIQTtBQXZCQTtBQThCQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBSEE7QUF2QkE7QUErQkE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQUtBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU5BO0FBUUE7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqT0E7QUFHQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUpBO0FBT0E7QUFDQTtBQUNBO0FBRkE7QUFJQTs7Ozs7Ozs7Ozs7Ozs7OztBQ2xCQTtBQUdBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSkE7O0FBT0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU5BO0FBUUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXJCQTtBQXVCQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWZBO0FBaUJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFQQTtBQVNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDaklBO0FBR0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBOztBQVFBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBckJBO0FBdUJBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBUEE7QUFTQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFHQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFOQTtBQVFBOzs7Ozs7Ozs7Ozs7Ozs7QUNyR0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQURBO0FBR0E7Ozs7Ozs7Ozs7Ozs7OztBQ2pCQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7O0FBS0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQU1BO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQURBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBREE7QUFJQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBREE7QUFJQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFJQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFUQTtBQVdBOzs7Ozs7Ozs7Ozs7Ozs7O0FDdklBO0FBR0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBO0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBTUE7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWRBO0FBZ0JBO0FBQ0E7QUFuQkE7QUFzQkE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFNQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBRUE7QUFFQTtBQUVBO0FBQ0E7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFLQTs7Ozs7Ozs7Ozs7Ozs7O0FDMUlBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBO0FBUUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFsQkE7QUFvQkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBbEJBO0FBb0JBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBS0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTEE7QUFRQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBO0FBUUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU5BO0FBUUE7Ozs7Ozs7Ozs7Ozs7OztBQ3ZIQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7QUFFQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQU1BOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBO0FBUUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQURBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWJBO0FBZUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFHQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBYkE7QUFlQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTtBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBakJBO0FBbUJBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFqQkE7QUFtQkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFLQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFYQTtBQWFBOzs7Ozs7Ozs7Ozs7Ozs7QUN6UEE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBbEJBO0FBb0JBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBS0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUpBO0FBTUE7Ozs7Ozs7Ozs7Ozs7OztBQ3RFQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBTUE7QUFDQTs7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBNUJBO0FBOEJBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUE1QkE7QUE4QkE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQUtBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTkE7QUFRQTs7Ozs7Ozs7Ozs7Ozs7O0FDL0lBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTEE7QUFRQTtBQUNBOztBQUVBO0FBQ0E7QUFEQTtBQUdBOzs7Ozs7Ozs7Ozs7Ozs7QUNsQkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFFQTtBQUlBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBVEE7O0FBV0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVRBOztBQVdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQUtBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBTUE7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTEE7QUFPQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pIQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFFQTtBQUNBO0FBRUE7QUFLQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKQTtBQU1BOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUpBO0FBTUE7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSkE7QUFNQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQU5BO0FBU0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBTUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFNQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFJQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKQTtBQU9BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQUtBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKQTtBQU9BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQUtBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKQTtBQU9BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQUtBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBREE7QUFJQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQVlBO0FBRUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFOQTtBQVFBOztBQUNBO0FBQ0E7QUFEQTtBQUdBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFwQkE7QUFzQkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQVJBO0FBVUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUpBO0FBT0E7QUFDQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBTkE7QUFRQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFNQTtBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBR0E7QUFDQTs7QUFNQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFMQTtBQVdBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQU1BO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBS0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBVEE7QUFXQTtBQUNBO0FBZEE7QUFnQkE7O0FBRUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXZCQTtBQXlCQTs7Ozs7Ozs7Ozs7Ozs7O0FDamdCQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWkE7QUFjQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFaQTtBQWNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFLQTtBQUNBOztBQUVBO0FBQ0E7QUFJQTtBQUNBO0FBQ0E7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBRUE7O0FBR0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFNQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBRUE7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSEE7QUFNQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFQQTtBQVNBOzs7Ozs7Ozs7Ozs7Ozs7QUNoTEE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNaQTtBQUNBO0FBSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFOQTtBQVNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUFBO0FBQUE7QUFJQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUVBO0FBQUE7QUFRQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU9BO0FBRUE7QUFDQTtBQUVBO0FBQUE7QUFBQTtBQUNBO0FBS0E7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFJQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBSUE7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUpBO0FBT0E7QUFBQTtBQUFBO0FBQUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7OztBQzdOQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbkNBO0FBQ0E7QUFDQTtBQUNBOztBQUlBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUdBO0FBRUE7QUFHQTtBQUNBO0FBQ0E7O0FBR0E7QUFDQTtBQUNBO0FBRUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFOQTtBQVFBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFOQTtBQVFBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1S0E7QUFDQTtBQUNBO0FBR0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBR0E7QUFBQTtBQUFBO0FBS0E7QUFJQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTUE7O0FBRUE7QUFDQTtBQUFBO0FBQUE7QUFBQTs7QUFFQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFPQTtBQUNBO0FBQ0E7QUFDQTs7QUFJQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFDQTs7QUFFQTtBQUdBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBS0E7QUFFQTtBQUFBO0FBSUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFFQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFJQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBREE7QUFPQTtBQUFBO0FBQUE7QUFJQTtBQUFBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFEQTtBQU9BO0FBQUE7QUFBQTs7QUFPQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBTUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUdBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFLQTtBQUtBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFHQTtBQUFBO0FBR0E7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFNQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBR0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUtBO0FBS0E7O0FBRUE7QUFDQTtBQUFBO0FBQUE7QUFJQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUlBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNyTkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7O0FBR0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUVBO0FBQUE7QUFJQTtBQUFBO0FBRUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUtBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUtBO0FBQUE7QUFZQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUlBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBT0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUFBO0FBQUE7QUFHQTtBQUFBO0FBQUE7QUFBQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFJQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUtBO0FBQ0E7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFJQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUlBO0FBQUE7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzNQQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBR0E7QUFFQTs7QUFFQTtBQUNBO0FBTUE7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFHQTs7QUFDQTtBQUNBOztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNBOztBQUNBO0FBQ0E7O0FBR0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7O0FBR0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBRUE7QUFDQTtBQUFBO0FBQUE7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFHQTs7QUFDQTtBQUNBO0FBRUE7O0FBQ0E7QUFDQTtBQUNBOztBQUdBO0FBQ0E7QUFDQTs7QUFNQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUM3TUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUlBO0FBTkE7QUFRQTtBQUNBO0FBQ0E7QUFLQTtBQVBBO0FBU0E7QUFDQTtBQUNBO0FBSUE7QUFOQTtBQVFBO0FBQ0E7QUFDQTtBQUtBO0FBUEE7QUFTQTtBQUNBO0FBQ0E7QUFLQTtBQVBBO0FBU0E7QUFDQTtBQUNBO0FBSUE7QUFOQTtBQVFBO0FBQ0E7QUFDQTtBQUtBO0FBUEE7QUFwREE7QUErREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUdBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBRUE7QUFBQTtBQUFBO0FBRUE7QUFLQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUdBO0FBQ0E7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUFBOztBQUVBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUlBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUlBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBREE7QUFJQTtBQUVBO0FBR0E7QUFDQTtBQUZBO0FBSUE7QUFDQTtBQUZBO0FBR0E7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTs7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFIQTtBQUhBO0FBU0E7QUFDQTtBQUNBO0FBQ0E7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUVBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUlBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUlBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBREE7QUFJQTtBQUNBO0FBR0E7QUFDQTtBQUNBOztBQUdBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFHQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBTUE7QUFFQTtBQUdBO0FBQ0E7QUFDQTs7QUFHQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTs7QUFDQTtBQUNBOztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUdBO0FBQ0E7QUFDQTtBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFGQTs7QUFJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBRkE7QUFTQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMQTs7QUFRQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBRUE7QUFDQTtBQURBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0ZUE7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSkE7QUFPQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFFQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQWRBO0FBZ0JBO0FBRUE7OztBQUNBO0FBRUE7QUFDQTtBQUZBO0FBS0E7QUFDQTtBQUNBO0FBRUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakZBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUlBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBR0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFHQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7O0FDMWpCQTtBQUNBO0FBQ0E7QUFDQTs7QUFHQTtBQUFBO0FBQUE7O0FBQ0E7QUFBQTtBQUFBOztBQVBBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBRUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVpBO0FBZUE7QUFDQTtBQURBO0FBSUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUFBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFJQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaEhBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUtBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBWEE7QUFhQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUdBOzs7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcEhBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQU1BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUdBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBRUE7QUFDQTs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQTNHQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDMUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBS0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKQTtBQU1BOztBQUVBO0FBQ0E7QUFDQTtBQWNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFTQTtBQUNBO0FBU0E7O0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFaQTtBQWdCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVpBOztBQWVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQVVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFHQTtBQUNBO0FBQ0E7QUFBQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFBQTs7QUFDQTtBQUFBOztBQUNBO0FBQUE7QUFIQTtBQUtBOztBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWpCQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDN1VBO0FBR0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBOzs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUZBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbE1BO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7O0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBOztBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBRUE7QUFBQTtBQUFBO0FBQUE7QUFFQTs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUFBO0FBRUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUpBO0FBTUE7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUdBO0FBQUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBOzs7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBREE7QUFHQTtBQUNBO0FBREE7QUFHQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTkE7QUFRQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUZBO0FBS0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVBBO0FBVUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUFBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFEQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3RnQkE7QUFFQTtBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQURBO0FBR0E7QUFDQTtBQUNBO0FBQUE7QUFEQTtBQUlBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUlBO0FBQ0E7QUFBQTtBQUFBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUtBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7QUFFQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7O0FBR0E7O0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUFBO0FBQUE7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFDQTs7QUFDQTtBQUFBO0FBQUE7O0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUFBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBYkE7QUFnQkE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQWhCQTtBQWtCQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0FBQ0E7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBO0FBT0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFIQTtBQUtBO0FBQUE7QUFHQTtBQUNBO0FBQ0E7QUFPQTtBQVlBO0FBcEJBO0FBMkJBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFtQkE7QUF1Q0E7QUFDQTtBQUNBO0FBVUE7QUFVQTtBQU1BO0FBVUE7QUFsR0E7QUFvR0E7QUFFQTtBQUNBO0FBQ0E7QUFEQTtBQUtBO0FBRUE7QUFDQTtBQUNBO0FBSUE7QUFNQTtBQVhBO0FBZ0JBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7Ozs7Ozs7OztBQ3RyQkE7Ozs7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7QUN2QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7QUNQQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7OztBQ1BBOzs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ05BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUVBO0FBRUE7QUFBQTtBQUFBO0FBRUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUVBO0FBQUE7QUFPQTtBQUVBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7QUFGQTtBQUtBO0FBQ0E7QUFGQTs7QUFNQTtBQUNBO0FBQ0E7QUFFQTtBQUFBO0FBQUE7QUFFQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBR0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFWQTs7QUFhQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUlBOztBQUNBOztBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9ub2RlX21vZHVsZXMvYXdlc29tZS1ub3RpZmljYXRpb25zL3NyYy9jb25zdGFudHMuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL25vZGVfbW9kdWxlcy9hd2Vzb21lLW5vdGlmaWNhdGlvbnMvc3JjL2VsZW0uanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL25vZGVfbW9kdWxlcy9hd2Vzb21lLW5vdGlmaWNhdGlvbnMvc3JjL2luZGV4LmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9ub2RlX21vZHVsZXMvYXdlc29tZS1ub3RpZmljYXRpb25zL3NyYy9vcHRpb25zLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9ub2RlX21vZHVsZXMvYXdlc29tZS1ub3RpZmljYXRpb25zL3NyYy9wb3B1cC5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vbm9kZV9tb2R1bGVzL2F3ZXNvbWUtbm90aWZpY2F0aW9ucy9zcmMvdGltZXIuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL25vZGVfbW9kdWxlcy9hd2Vzb21lLW5vdGlmaWNhdGlvbnMvc3JjL3RvYXN0LmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvYXBpL2FwaS1pbmRleC5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL2FwaS9jb21tb24uanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvY3BlL2NwZS5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL2FwaS9jcGUvbmF2ZXQuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvanVkZ2UvYWxwaGFKdWRnZS5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL2FwaS9tb2R1bGUuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvcGF5bWVudHMuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvcXVpei5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL2FwaS9zdG9yYWdlL2Fzc2Vzc21lbnRDb25maWcuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvc3RvcmFnZS9nZW5lcmljLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvYXBpL3N0b3JhZ2UvbW9kdWxlc0RhdGEuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvc3RvcmFnZS9wYXltZW50U3RhdHMuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvc3RvcmFnZS90ZW1wbGF0ZXMuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvc3RyZWFtL3N0cmVhbS5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL2FwaS9zdXJ2ZXkuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvdHJhaW5pbmdzL2Fzc2Vzc21lbnQuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvdHJhaW5pbmdzL2V2ZW50cy5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL2FwaS90cmFpbmluZ3MvZXhhbXMuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvdHJhaW5pbmdzL2dyb3Vwcy5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL2FwaS90cmFpbmluZ3MvbGVjdHVyZXMuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvdHJhaW5pbmdzL3NlbWluYXJzLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvYXBpL3RyYWluaW5ncy9za2lsbHMuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hcGkvdHJhaW5pbmdzL3RyYWluaW5ncy5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL2FwaS91c2Vycy5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL2FwaS91dGlsLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvY29tbW9uL01vZGFsLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvY29tbW9uL1Byb2dyZXNzQmFyLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvcGF5bWVudHMvZGF0YS9wYXltZW50cy5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL3N1cnZleS9EZXRhaWxzLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvc3VydmV5L1N1bW1hcnkuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9zdXJ2ZXkvZGF0YS5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL3N1cnZleS9zdGF0cy5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL3V0aWwvYXBpLWNvbm5lY3QuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy91dGlsL2FwaS5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL3V0aWwvY29udGVudFR5cGVzLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvdXRpbC9kYXRhLWNvbm5lY3QuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy91dGlsL2pzeC1yZW5kZXItbW9kL2RvbS5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL3V0aWwvanN4LXJlbmRlci1tb2QvdXRpbHMuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy91dGlsL3BhcnNlLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvdXRpbC9yb3V0ZXIuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy91dGlsL3RlbXBsYXRlLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvdXRpbC91dGlsLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9ub2RlX21vZHVsZXMvanNvbjUvZGlzdC9pbmRleC5taW4uanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS93ZWJwYWNrL2Jvb3RzdHJhcCIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlL3dlYnBhY2svcnVudGltZS9jb21wYXQgZ2V0IGRlZmF1bHQgZXhwb3J0Iiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvd2VicGFjay9ydW50aW1lL2RlZmluZSBwcm9wZXJ0eSBnZXR0ZXJzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvd2VicGFjay9ydW50aW1lL2hhc093blByb3BlcnR5IHNob3J0aGFuZCIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlL3dlYnBhY2svcnVudGltZS9tYWtlIG5hbWVzcGFjZSBvYmplY3QiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9zdXJ2ZXkvc3VydmV5LmpzIl0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IGxpYk5hbWUgPSBcImF3blwiXG5jb25zdCBwcmVmaXggPSB7XG4gIHBvcHVwOiBgJHtsaWJOYW1lfS1wb3B1cGAsXG4gIHRvYXN0OiBgJHtsaWJOYW1lfS10b2FzdGAsXG4gIGJ0bjogYCR7bGliTmFtZX0tYnRuYCxcbiAgY29uZmlybTogYCR7bGliTmFtZX0tY29uZmlybWBcbn1cblxuLy8gQ29uc3RhbnRzIGZvciB0b2FzdHNcbmV4cG9ydCBjb25zdCB0Q29uc3RzID0ge1xuICBwcmVmaXg6IHByZWZpeC50b2FzdCxcbiAga2xhc3M6IHtcbiAgICBsYWJlbDogYCR7cHJlZml4LnRvYXN0fS1sYWJlbGAsXG4gICAgY29udGVudDogYCR7cHJlZml4LnRvYXN0fS1jb250ZW50YCxcbiAgICBpY29uOiBgJHtwcmVmaXgudG9hc3R9LWljb25gLFxuICAgIHByb2dyZXNzQmFyOiBgJHtwcmVmaXgudG9hc3R9LXByb2dyZXNzLWJhcmAsXG4gICAgcHJvZ3Jlc3NCYXJQYXVzZTogYCR7cHJlZml4LnRvYXN0fS1wcm9ncmVzcy1iYXItcGF1c2VkYFxuICB9LFxuICBpZHM6IHtcbiAgICBjb250YWluZXI6IGAke3ByZWZpeC50b2FzdH0tY29udGFpbmVyYFxuICB9XG59XG5cbi8vIENvbnN0YW50cyBmb3IgcG9wdXBzXG5leHBvcnQgY29uc3QgbUNvbnN0cyA9IHtcbiAgcHJlZml4OiBwcmVmaXgucG9wdXAsXG4gIGtsYXNzOiB7XG4gICAgYnV0dG9uczogYCR7bGliTmFtZX0tYnV0dG9uc2AsXG4gICAgYnV0dG9uOiBwcmVmaXguYnRuLFxuICAgIHN1Y2Nlc3NCdG46IGAke3ByZWZpeC5idG59LXN1Y2Nlc3NgLFxuICAgIGNhbmNlbEJ0bjogYCR7cHJlZml4LmJ0bn0tY2FuY2VsYCxcbiAgICB0aXRsZTogYCR7cHJlZml4LnBvcHVwfS10aXRsZWAsXG4gICAgYm9keTogYCR7cHJlZml4LnBvcHVwfS1ib2R5YCxcbiAgICBjb250ZW50OiBgJHtwcmVmaXgucG9wdXB9LWNvbnRlbnRgLFxuICAgIGRvdEFuaW1hdGlvbjogYCR7cHJlZml4LnBvcHVwfS1sb2FkaW5nLWRvdHNgXG4gIH0sXG4gIGlkczoge1xuICAgIHdyYXBwZXI6IGAke3ByZWZpeC5wb3B1cH0td3JhcHBlcmAsXG4gICAgY29uZmlybU9rOiBgJHtwcmVmaXguY29uZmlybX0tb2tgLFxuICAgIGNvbmZpcm1DYW5jZWw6IGAke3ByZWZpeC5jb25maXJtfS1jYW5jZWxgXG4gIH1cbn1cblxuZXhwb3J0IGNvbnN0IGVDb25zdHMgPSB7XG4gIGtsYXNzOiB7XG4gICAgaGlkaW5nOiBgJHtsaWJOYW1lfS1oaWRpbmdgXG4gIH0sXG4gIGxpYjogbGliTmFtZVxufVxuIiwiaW1wb3J0IHtcbiAgICBlQ29uc3RzXG59IGZyb20gXCIuL2NvbnN0YW50c1wiXG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIHtcbiAgICBjb25zdHJ1Y3RvcihwYXJlbnQsIGlkLCBrbGFzcywgc3R5bGUsIG9wdGlvbnMpIHtcbiAgICAgICAgdGhpcy5uZXdOb2RlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JylcbiAgICAgICAgaWYgKGlkKSB0aGlzLm5ld05vZGUuaWQgPSBpZFxuICAgICAgICBpZiAoa2xhc3MpIHRoaXMubmV3Tm9kZS5jbGFzc05hbWUgPSBrbGFzc1xuICAgICAgICBpZiAoc3R5bGUpIHRoaXMubmV3Tm9kZS5zdHlsZS5jc3NUZXh0ID0gc3R5bGVcbiAgICAgICAgdGhpcy5wYXJlbnQgPSBwYXJlbnRcbiAgICAgICAgdGhpcy5vcHRpb25zID0gb3B0aW9uc1xuICAgIH1cbiAgICBiZWZvcmVJbnNlcnQoKSB7fVxuICAgIGFmdGVySW5zZXJ0KCkge31cbiAgICBpbnNlcnQoKSB7XG4gICAgICAgIHRoaXMuYmVmb3JlSW5zZXJ0KClcbiAgICAgICAgdGhpcy5lbCA9IHRoaXMucGFyZW50LmFwcGVuZENoaWxkKHRoaXMubmV3Tm9kZSlcbiAgICAgICAgdGhpcy5hZnRlckluc2VydCgpXG4gICAgICAgIHJldHVybiB0aGlzXG4gICAgfVxuXG4gICAgcmVwbGFjZShlbCkge1xuICAgICAgICBpZiAoIXRoaXMuZ2V0RWxlbWVudCgpKSByZXR1cm5cbiAgICAgICAgcmV0dXJuIHRoaXMuYmVmb3JlRGVsZXRlKCkudGhlbigoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnVwZGF0ZVR5cGUoZWwudHlwZSlcbiAgICAgICAgICAgIHRoaXMucGFyZW50LnJlcGxhY2VDaGlsZChlbC5uZXdOb2RlLCB0aGlzLmVsKVxuICAgICAgICAgICAgdGhpcy5lbCA9IHRoaXMuZ2V0RWxlbWVudChlbC5uZXdOb2RlKVxuICAgICAgICAgICAgdGhpcy5hZnRlckluc2VydCgpXG4gICAgICAgICAgICByZXR1cm4gdGhpc1xuICAgICAgICB9KVxuICAgIH1cblxuICAgIGJlZm9yZURlbGV0ZShlbCA9IHRoaXMuZWwpIHtcbiAgICAgICAgbGV0IHRpbWVMZWZ0ID0gMFxuICAgICAgICBpZiAodGhpcy5zdGFydCkge1xuICAgICAgICAgICAgdGltZUxlZnQgPSB0aGlzLm9wdGlvbnMubWluRHVyYXRpb25zW3RoaXMudHlwZV0gKyB0aGlzLnN0YXJ0IC0gRGF0ZS5ub3coKVxuICAgICAgICAgICAgaWYgKHRpbWVMZWZ0IDwgMCkgdGltZUxlZnQgPSAwXG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UocmVzb2x2ZSA9PiB7XG4gICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICBlbC5jbGFzc0xpc3QuYWRkKGVDb25zdHMua2xhc3MuaGlkaW5nKVxuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQocmVzb2x2ZSwgdGhpcy5vcHRpb25zLmFuaW1hdGlvbkR1cmF0aW9uKVxuICAgICAgICAgICAgfSwgdGltZUxlZnQpXG4gICAgICAgIH0pXG4gICAgfVxuXG4gICAgZGVsZXRlKGVsID0gdGhpcy5lbCkge1xuICAgICAgICBpZiAoIXRoaXMuZ2V0RWxlbWVudChlbCkpIHJldHVybiBudWxsXG4gICAgICAgIHJldHVybiB0aGlzLmJlZm9yZURlbGV0ZShlbCkudGhlbigoKSA9PiB7XG4gICAgICAgICAgICBlbC5yZW1vdmUoKVxuICAgICAgICAgICAgdGhpcy5hZnRlckRlbGV0ZSgpXG4gICAgICAgIH0pXG4gICAgfVxuICAgIGFmdGVyRGVsZXRlKCkge31cblxuICAgIGdldEVsZW1lbnQoZWwgPSB0aGlzLmVsKSB7XG4gICAgICAgIGlmICghZWwpIHJldHVybiBudWxsXG4gICAgICAgIHJldHVybiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChlbC5pZClcbiAgICB9XG5cbiAgICBhZGRFdmVudChuYW1lLCBmdW5jKSB7XG4gICAgICAgIHRoaXMuZWwuYWRkRXZlbnRMaXN0ZW5lcihuYW1lLCBmdW5jKVxuICAgIH1cblxuICAgIHRvZ2dsZUNsYXNzKGtsYXNzKSB7XG4gICAgICAgIHRoaXMuZWwuY2xhc3NMaXN0LnRvZ2dsZShrbGFzcylcbiAgICB9XG4gICAgdXBkYXRlVHlwZSh0eXBlKSB7XG4gICAgICAgIHRoaXMudHlwZSA9IHR5cGVcbiAgICAgICAgdGhpcy5kdXJhdGlvbiA9IHRoaXMub3B0aW9ucy5kdXJhdGlvbih0aGlzLnR5cGUpXG4gICAgfVxufSIsImltcG9ydCBPcHRpb25zIGZyb20gXCIuL29wdGlvbnNcIlxuaW1wb3J0IFRvYXN0IGZyb20gXCIuL3RvYXN0XCJcbmltcG9ydCBQb3B1cCBmcm9tIFwiLi9wb3B1cFwiXG5pbXBvcnQgRWxlbSBmcm9tIFwiLi9lbGVtXCJcblxuaW1wb3J0IHtcbiAgdENvbnN0c1xufSBmcm9tIFwiLi9jb25zdGFudHNcIlxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBOb3RpZmllciB7XG4gIGNvbnN0cnVjdG9yKG9wdGlvbnMgPSB7fSkge1xuICAgIHRoaXMub3B0aW9ucyA9IG5ldyBPcHRpb25zKG9wdGlvbnMpXG4gIH1cblxuICB0aXAobXNnLCBvcHRpb25zKSB7XG4gICAgcmV0dXJuIHRoaXMuX2FkZFRvYXN0KG1zZywgXCJ0aXBcIiwgb3B0aW9ucykuZWxcbiAgfVxuXG4gIGluZm8obXNnLCBvcHRpb25zKSB7XG4gICAgcmV0dXJuIHRoaXMuX2FkZFRvYXN0KG1zZywgXCJpbmZvXCIsIG9wdGlvbnMpLmVsXG4gIH1cblxuICBzdWNjZXNzKG1zZywgb3B0aW9ucykge1xuICAgIHJldHVybiB0aGlzLl9hZGRUb2FzdChtc2csIFwic3VjY2Vzc1wiLCBvcHRpb25zKS5lbFxuICB9XG5cbiAgd2FybmluZyhtc2csIG9wdGlvbnMpIHtcbiAgICByZXR1cm4gdGhpcy5fYWRkVG9hc3QobXNnLCBcIndhcm5pbmdcIiwgb3B0aW9ucykuZWxcbiAgfVxuXG4gIGFsZXJ0KG1zZywgb3B0aW9ucykge1xuICAgIHJldHVybiB0aGlzLl9hZGRUb2FzdChtc2csIFwiYWxlcnRcIiwgb3B0aW9ucykuZWxcbiAgfVxuXG4gIGFzeW5jIChwcm9taXNlLCBvblJlc29sdmUsIG9uUmVqZWN0LCBtc2csIG9wdGlvbnMpIHtcbiAgICBsZXQgYXN5bmNUb2FzdCA9IHRoaXMuX2FkZFRvYXN0KG1zZywgXCJhc3luY1wiLCBvcHRpb25zKVxuICAgIHJldHVybiB0aGlzLl9hZnRlckFzeW5jKHByb21pc2UsIG9uUmVzb2x2ZSwgb25SZWplY3QsIG9wdGlvbnMsIGFzeW5jVG9hc3QpXG4gIH1cblxuICBjb25maXJtKG1zZywgb25Paywgb25DYW5jZWwsIG9wdGlvbnMpIHtcbiAgICByZXR1cm4gdGhpcy5fYWRkUG9wdXAobXNnLCBcImNvbmZpcm1cIiwgb3B0aW9ucywgb25Paywgb25DYW5jZWwpXG4gIH1cblxuICBhc3luY0Jsb2NrKHByb21pc2UsIG9uUmVzb2x2ZSwgb25SZWplY3QsIG1zZywgb3B0aW9ucykge1xuICAgIGxldCBhc3luY0Jsb2NrID0gdGhpcy5fYWRkUG9wdXAobXNnLCBcImFzeW5jLWJsb2NrXCIsIG9wdGlvbnMpXG4gICAgcmV0dXJuIHRoaXMuX2FmdGVyQXN5bmMocHJvbWlzZSwgb25SZXNvbHZlLCBvblJlamVjdCwgb3B0aW9ucywgYXN5bmNCbG9jaylcbiAgfVxuXG4gIG1vZGFsKG1zZywgY2xhc3NOYW1lLCBvcHRpb25zKSB7XG4gICAgcmV0dXJuIHRoaXMuX2FkZFBvcHVwKG1zZywgY2xhc3NOYW1lLCBvcHRpb25zKVxuICB9XG5cbiAgY2xvc2VUb2FzdHMoKSB7XG4gICAgbGV0IGMgPSB0aGlzLmNvbnRhaW5lclxuICAgIHdoaWxlIChjLmZpcnN0Q2hpbGQpIHtcbiAgICAgIGMucmVtb3ZlQ2hpbGQoYy5maXJzdENoaWxkKVxuICAgIH1cbiAgfVxuXG4gIC8vIFRvb2xzXG4gIF9hZGRQb3B1cChtc2csIGNsYXNzTmFtZSwgb3B0aW9ucywgb25Paywgb25DYW5jZWwpIHtcbiAgICByZXR1cm4gbmV3IFBvcHVwKG1zZywgY2xhc3NOYW1lLCB0aGlzLm9wdGlvbnMub3ZlcnJpZGUob3B0aW9ucyksIG9uT2ssIG9uQ2FuY2VsKVxuICB9XG5cbiAgX2FkZFRvYXN0KG1zZywgdHlwZSwgb3B0aW9ucywgb2xkKSB7XG4gICAgb3B0aW9ucyA9IHRoaXMub3B0aW9ucy5vdmVycmlkZShvcHRpb25zKVxuICAgIGxldCBuZXdUb2FzdCA9IG5ldyBUb2FzdChtc2csIHR5cGUsIG9wdGlvbnMsIHRoaXMuY29udGFpbmVyKVxuICAgIGlmIChvbGQpIHtcbiAgICAgIGlmIChvbGQgaW5zdGFuY2VvZiBQb3B1cCkgcmV0dXJuIG9sZC5kZWxldGUoKS50aGVuKCgpID0+IG5ld1RvYXN0Lmluc2VydCgpKVxuICAgICAgbGV0IGkgPSBvbGQucmVwbGFjZShuZXdUb2FzdClcbiAgICAgIHJldHVybiBpXG4gICAgfVxuICAgIHJldHVybiBuZXdUb2FzdC5pbnNlcnQoKVxuICB9XG5cbiAgX2FmdGVyQXN5bmMocHJvbWlzZSwgb25SZXNvbHZlLCBvblJlamVjdCwgb3B0aW9ucywgb2xkRWxlbWVudCkge1xuICAgIHJldHVybiBwcm9taXNlLnRoZW4oXG4gICAgICB0aGlzLl9yZXNwb25zZUhhbmRsZXIob25SZXNvbHZlLCBcInN1Y2Nlc3NcIiwgb3B0aW9ucywgb2xkRWxlbWVudCksXG4gICAgICB0aGlzLl9yZXNwb25zZUhhbmRsZXIob25SZWplY3QsIFwiYWxlcnRcIiwgb3B0aW9ucywgb2xkRWxlbWVudClcbiAgICApXG4gIH1cblxuICBfcmVzcG9uc2VIYW5kbGVyKHBheWxvYWQsIHRvYXN0TmFtZSwgb3B0aW9ucywgb2xkRWxlbWVudCkge1xuICAgIHJldHVybiByZXN1bHQgPT4ge1xuICAgICAgc3dpdGNoICh0eXBlb2YgcGF5bG9hZCkge1xuICAgICAgICBjYXNlICd1bmRlZmluZWQnOlxuICAgICAgICBjYXNlICdzdHJpbmcnOlxuICAgICAgICAgIGxldCBtc2cgPSB0b2FzdE5hbWUgPT09ICdhbGVydCcgPyBwYXlsb2FkIHx8IHJlc3VsdCA6IHBheWxvYWRcbiAgICAgICAgICB0aGlzLl9hZGRUb2FzdChtc2csIHRvYXN0TmFtZSwgb3B0aW9ucywgb2xkRWxlbWVudClcbiAgICAgICAgICBicmVha1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgIG9sZEVsZW1lbnQuZGVsZXRlKCkudGhlbigoKSA9PiB7XG4gICAgICAgICAgICBpZiAocGF5bG9hZCkgcGF5bG9hZChyZXN1bHQpXG4gICAgICAgICAgfSlcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBfY3JlYXRlQ29udGFpbmVyKCkge1xuICAgIHJldHVybiBuZXcgRWxlbShkb2N1bWVudC5ib2R5LCB0Q29uc3RzLmlkcy5jb250YWluZXIsIGBhd24tJHt0aGlzLm9wdGlvbnMucG9zaXRpb259YCkuaW5zZXJ0KCkuZWxcbiAgfVxuXG4gIGdldCBjb250YWluZXIoKSB7XG4gICAgcmV0dXJuIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKHRDb25zdHMuaWRzLmNvbnRhaW5lcikgfHwgdGhpcy5fY3JlYXRlQ29udGFpbmVyKClcbiAgfVxufVxuIiwiY29uc3QgZGVmYXVsdHMgPSB7XG4gIG1heE5vdGlmaWNhdGlvbnM6IDEwLFxuICBhbmltYXRpb25EdXJhdGlvbjogMzAwLFxuICBwb3NpdGlvbjogXCJib3R0b20tcmlnaHRcIixcbiAgbGFiZWxzOiB7XG4gICAgdGlwOiBcIlRpcFwiLFxuICAgIGluZm86IFwiSW5mb1wiLFxuICAgIHN1Y2Nlc3M6IFwiU3VjY2Vzc1wiLFxuICAgIHdhcm5pbmc6IFwiQXR0ZW50aW9uXCIsXG4gICAgYWxlcnQ6IFwiRXJyb3JcIixcbiAgICBhc3luYzogXCJMb2FkaW5nXCIsXG4gICAgY29uZmlybTogXCJDb25maXJtYXRpb24gcmVxdWlyZWRcIixcbiAgICBjb25maXJtT2s6IFwiT0tcIixcbiAgICBjb25maXJtQ2FuY2VsOiBcIkNhbmNlbFwiXG4gIH0sXG4gIGljb25zOiB7XG4gICAgdGlwOiBcInF1ZXN0aW9uLWNpcmNsZVwiLFxuICAgIGluZm86IFwiaW5mby1jaXJjbGVcIixcbiAgICBzdWNjZXNzOiBcImNoZWNrLWNpcmNsZVwiLFxuICAgIHdhcm5pbmc6IFwiZXhjbGFtYXRpb24tY2lyY2xlXCIsXG4gICAgYWxlcnQ6IFwiZXhjbGFtYXRpb24tdHJpYW5nbGVcIixcbiAgICBhc3luYzogXCJjb2cgZmEtc3BpblwiLFxuICAgIGNvbmZpcm06IFwiZXhjbGFtYXRpb24tdHJpYW5nbGVcIixcbiAgICBwcmVmaXg6IFwiPGkgY2xhc3M9J2ZhIGZhcyBmYS1mdyBmYS1cIixcbiAgICBzdWZmaXg6IFwiJz48L2k+XCIsXG4gICAgZW5hYmxlZDogdHJ1ZVxuICB9LFxuICByZXBsYWNlbWVudHM6IHtcbiAgICB0aXA6IG51bGwsXG4gICAgaW5mbzogbnVsbCxcbiAgICBzdWNjZXNzOiBudWxsLFxuICAgIHdhcm5pbmc6IG51bGwsXG4gICAgYWxlcnQ6IG51bGwsXG4gICAgYXN5bmM6IG51bGwsXG4gICAgXCJhc3luYy1ibG9ja1wiOiBudWxsLFxuICAgIG1vZGFsOiBudWxsLFxuICAgIGNvbmZpcm06IG51bGwsXG4gICAgZ2VuZXJhbDoge1xuICAgICAgXCI8c2NyaXB0PlwiOiBcIlwiLFxuICAgICAgXCI8L3NjcmlwdD5cIjogXCJcIlxuICAgIH1cbiAgfSxcbiAgbWVzc2FnZXM6IHtcbiAgICB0aXA6IFwiXCIsXG4gICAgaW5mbzogXCJcIixcbiAgICBzdWNjZXNzOiBcIkFjdGlvbiBoYXMgYmVlbiBzdWNjZWVkZWRcIixcbiAgICB3YXJuaW5nOiBcIlwiLFxuICAgIGFsZXJ0OiBcIkFjdGlvbiBoYXMgYmVlbiBmYWlsZWRcIixcbiAgICBjb25maXJtOiBcIlRoaXMgYWN0aW9uIGNhbid0IGJlIHVuZG9uZS4gQ29udGludWU/XCIsXG4gICAgYXN5bmM6IFwiUGxlYXNlLCB3YWl0Li4uXCIsXG4gICAgXCJhc3luYy1ibG9ja1wiOiBcIkxvYWRpbmdcIlxuICB9LFxuICBmb3JtYXRFcnJvcihlcnIpIHtcbiAgICBpZiAoZXJyLnJlc3BvbnNlKSB7XG4gICAgICBpZiAoIWVyci5yZXNwb25zZS5kYXRhKSByZXR1cm4gJzUwMCBBUEkgU2VydmVyIEVycm9yJ1xuICAgICAgaWYgKGVyci5yZXNwb25zZS5kYXRhLmVycm9ycykge1xuICAgICAgICByZXR1cm4gZXJyLnJlc3BvbnNlLmRhdGEuZXJyb3JzLm1hcChvID0+IG8uZGV0YWlsKS5qb2luKCc8YnI+JylcbiAgICAgIH1cbiAgICAgIGlmIChlcnIucmVzcG9uc2Uuc3RhdHVzVGV4dCkge1xuICAgICAgICByZXR1cm4gYCR7ZXJyLnJlc3BvbnNlLnN0YXR1c30gJHtlcnIucmVzcG9uc2Uuc3RhdHVzVGV4dH06ICR7ZXJyLnJlc3BvbnNlLmRhdGF9YFxuICAgICAgfVxuICAgIH1cbiAgICBpZiAoZXJyLm1lc3NhZ2UpIHJldHVybiBlcnIubWVzc2FnZVxuICAgIHJldHVybiBlcnJcbiAgfSxcbiAgZHVyYXRpb25zOiB7XG4gICAgZ2xvYmFsOiA1MDAwLFxuICAgIHN1Y2Nlc3M6IG51bGwsXG4gICAgaW5mbzogbnVsbCxcbiAgICB0aXA6IG51bGwsXG4gICAgd2FybmluZzogbnVsbCxcbiAgICBhbGVydDogbnVsbFxuICB9LFxuICBtaW5EdXJhdGlvbnM6IHtcbiAgICBhc3luYzogMTAwMCxcbiAgICBcImFzeW5jLWJsb2NrXCI6IDEwMDBcbiAgfSxcbn1cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE9wdGlvbnMge1xuICBjb25zdHJ1Y3RvcihvcHRpb25zID0ge30sIGdsb2JhbCA9IGRlZmF1bHRzKSB7XG4gICAgT2JqZWN0LmFzc2lnbih0aGlzLCB0aGlzLmRlZmF1bHRzRGVlcChnbG9iYWwsIG9wdGlvbnMpKVxuICB9XG5cbiAgaWNvbih0eXBlKSB7XG4gICAgaWYgKHRoaXMuaWNvbnMuZW5hYmxlZCkgcmV0dXJuIGAke3RoaXMuaWNvbnMucHJlZml4fSR7dGhpcy5pY29uc1t0eXBlXX0ke3RoaXMuaWNvbnMuc3VmZml4fWBcbiAgICByZXR1cm4gJydcbiAgfVxuXG4gIGxhYmVsKHR5cGUpIHtcbiAgICByZXR1cm4gdGhpcy5sYWJlbHNbdHlwZV1cbiAgfVxuXG4gIGR1cmF0aW9uKHR5cGUpIHtcbiAgICBsZXQgZHVyYXRpb24gPSB0aGlzLmR1cmF0aW9uc1t0eXBlXVxuICAgIHJldHVybiBkdXJhdGlvbiA9PT0gbnVsbCA/IHRoaXMuZHVyYXRpb25zLmdsb2JhbCA6IGR1cmF0aW9uXG4gIH1cblxuICB0b1NlY3ModmFsdWUpIHtcbiAgICByZXR1cm4gYCR7dmFsdWUgLyAxMDAwfXNgXG4gIH1cblxuICBhcHBseVJlcGxhY2VtZW50cyhzdHIsIHR5cGUpIHtcbiAgICBpZiAoIXN0cikgcmV0dXJuIHRoaXMubWVzc2FnZXNbdHlwZV0gfHwgXCJcIlxuICAgIGZvciAoY29uc3QgbiBvZiBbJ2dlbmVyYWwnLCB0eXBlXSkge1xuICAgICAgaWYgKCF0aGlzLnJlcGxhY2VtZW50c1tuXSkgY29udGludWVcbiAgICAgIGZvciAoY29uc3QgayBpbiB0aGlzLnJlcGxhY2VtZW50c1tuXSkge1xuICAgICAgICBzdHIgPSBzdHIucmVwbGFjZShrLCB0aGlzLnJlcGxhY2VtZW50c1tuXVtrXSlcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHN0clxuICB9XG5cbiAgb3ZlcnJpZGUob3B0aW9ucykge1xuICAgIGlmIChvcHRpb25zKSByZXR1cm4gbmV3IE9wdGlvbnMob3B0aW9ucywgdGhpcylcbiAgICByZXR1cm4gdGhpc1xuICB9XG5cbiAgZGVmYXVsdHNEZWVwKGRlZmF1bHRzLCBvdmVycmlkZXMpIHtcbiAgICBsZXQgcmVzdWx0ID0ge31cbiAgICBmb3IgKGNvbnN0IGsgaW4gZGVmYXVsdHMpIHtcbiAgICAgIGlmIChvdmVycmlkZXMuaGFzT3duUHJvcGVydHkoaykpIHtcbiAgICAgICAgcmVzdWx0W2tdID0gdHlwZW9mIGRlZmF1bHRzW2tdID09PSBcIm9iamVjdFwiICYmIGRlZmF1bHRzW2tdICE9PSBudWxsID8gdGhpcy5kZWZhdWx0c0RlZXAoZGVmYXVsdHNba10sIG92ZXJyaWRlc1trXSkgOiBvdmVycmlkZXNba11cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlc3VsdFtrXSA9IGRlZmF1bHRzW2tdXG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiByZXN1bHRcbiAgfVxufVxuIiwiaW1wb3J0IEVsZW0gZnJvbSBcIi4vZWxlbVwiXG5pbXBvcnQge1xuICBtQ29uc3RzXG59IGZyb20gXCIuL2NvbnN0YW50c1wiXG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIGV4dGVuZHMgRWxlbSB7XG4gIGNvbnN0cnVjdG9yKG1zZywgdHlwZSA9ICdtb2RhbCcsIG9wdGlvbnMsIG9uT2ssIG9uQ2FuY2VsKSB7XG4gICAgbGV0IGFuaW1hdGlvbkR1cmF0aW9uID0gYGFuaW1hdGlvbi1kdXJhdGlvbjogJHtvcHRpb25zLnRvU2VjcyhvcHRpb25zLmFuaW1hdGlvbkR1cmF0aW9uKX07YFxuICAgIHN1cGVyKGRvY3VtZW50LmJvZHksIG1Db25zdHMuaWRzLndyYXBwZXIsIG51bGwsIGFuaW1hdGlvbkR1cmF0aW9uLCBvcHRpb25zKVxuICAgIHRoaXNbbUNvbnN0cy5pZHMuY29uZmlybU9rXSA9IG9uT2tcbiAgICB0aGlzW21Db25zdHMuaWRzLmNvbmZpcm1DYW5jZWxdID0gb25DYW5jZWxcbiAgICB0aGlzLmNsYXNzTmFtZSA9IGAke21Db25zdHMucHJlZml4fS0ke3R5cGV9YFxuICAgIGlmICghWydjb25maXJtJywgJ2FzeW5jLWJsb2NrJywgJ21vZGFsJ10uaW5jbHVkZXModHlwZSkpIHR5cGUgPSAnbW9kYWwnXG4gICAgdGhpcy51cGRhdGVUeXBlKHR5cGUpXG4gICAgdGhpcy5zZXRJbm5lckh0bWwobXNnKVxuICAgIHRoaXMuaW5zZXJ0KClcbiAgfVxuXG4gIHNldElubmVySHRtbChodG1sKSB7XG4gICAgbGV0IGlubmVySFRNTCA9IHRoaXMub3B0aW9ucy5hcHBseVJlcGxhY2VtZW50cyhodG1sLCB0aGlzLnR5cGUpXG4gICAgc3dpdGNoICh0aGlzLnR5cGUpIHtcbiAgICAgIGNhc2UgXCJjb25maXJtXCI6XG4gICAgICAgIGxldCBidXR0b25zID0gW2A8YnV0dG9uIGNsYXNzPScke21Db25zdHMua2xhc3MuYnV0dG9ufSAke21Db25zdHMua2xhc3Muc3VjY2Vzc0J0bn0naWQ9JyR7bUNvbnN0cy5pZHMuY29uZmlybU9rfSc+JHt0aGlzLm9wdGlvbnMubGFiZWxzLmNvbmZpcm1Pa308L2J1dHRvbj5gXVxuICAgICAgICBpZiAodGhpc1ttQ29uc3RzLmlkcy5jb25maXJtQ2FuY2VsXSAhPT0gZmFsc2UpIHtcbiAgICAgICAgICBidXR0b25zLnB1c2goYDxidXR0b24gY2xhc3M9JyR7bUNvbnN0cy5rbGFzcy5idXR0b259ICR7bUNvbnN0cy5rbGFzcy5jYW5jZWxCdG59J2lkPScke21Db25zdHMuaWRzLmNvbmZpcm1DYW5jZWx9Jz4ke3RoaXMub3B0aW9ucy5sYWJlbHMuY29uZmlybUNhbmNlbH08L2J1dHRvbj5gKVxuICAgICAgICB9XG4gICAgICAgIGlubmVySFRNTCA9IGAke3RoaXMub3B0aW9ucy5pY29uKHRoaXMudHlwZSl9PGRpdiBjbGFzcz0nJHttQ29uc3RzLmtsYXNzLnRpdGxlfSc+JHt0aGlzLm9wdGlvbnMubGFiZWwodGhpcy50eXBlKX08L2Rpdj48ZGl2IGNsYXNzPVwiJHttQ29uc3RzLmtsYXNzLmNvbnRlbnR9XCI+JHtpbm5lckhUTUx9PC9kaXY+PGRpdiBjbGFzcz0nJHttQ29uc3RzLmtsYXNzLmJ1dHRvbnN9ICR7bUNvbnN0cy5rbGFzcy5idXR0b25zfS0ke2J1dHRvbnMubGVuZ3RofSc+JHtidXR0b25zLmpvaW4oJycpfTwvZGl2PmBcbiAgICAgICAgYnJlYWtcbiAgICAgIGNhc2UgXCJhc3luYy1ibG9ja1wiOlxuICAgICAgICBpbm5lckhUTUwgPSBgJHtpbm5lckhUTUx9PGRpdiBjbGFzcz1cIiR7bUNvbnN0cy5rbGFzcy5kb3RBbmltYXRpb259XCI+PC9kaXY+YFxuICAgIH1cbiAgICB0aGlzLm5ld05vZGUuaW5uZXJIVE1MID0gYDxkaXYgY2xhc3M9XCIke21Db25zdHMua2xhc3MuYm9keX0gJHt0aGlzLmNsYXNzTmFtZX1cIj4ke2lubmVySFRNTH08L2Rpdj5gXG4gIH1cblxuICBrZXl1cExpc3RlbmVyKGUpIHtcbiAgICBpZiAodGhpcy50eXBlID09PSAnYXN5bmMtYmxvY2snKSByZXR1cm4gZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgc3dpdGNoIChlLmNvZGUpIHtcbiAgICAgIGNhc2UgJ0VzY2FwZSc6XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgICB0aGlzLmRlbGV0ZSgpXG4gICAgICBjYXNlICdUYWInOlxuICAgICAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICAgICAgaWYgKHRoaXMudHlwZSAhPT0gJ2NvbmZpcm0nIHx8IHRoaXNbbUNvbnN0cy5pZHMuY29uZmlybUNhbmNlbF0gPT09IGZhbHNlKSByZXR1cm4gdHJ1ZVxuICAgICAgICBsZXQgbmV4dCA9IHRoaXMub2tCdG5cbiAgICAgICAgaWYgKGUuc2hpZnRLZXkpIHtcbiAgICAgICAgICBpZiAoZG9jdW1lbnQuYWN0aXZlRWxlbWVudC5pZCA9PSBtQ29uc3RzLmlkcy5jb25maXJtT2spIG5leHQgPSB0aGlzLmNhbmNlbEJ0blxuICAgICAgICB9IGVsc2UgaWYgKGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQuaWQgIT09IG1Db25zdHMuaWRzLmNvbmZpcm1DYW5jZWwpIG5leHQgPSB0aGlzLmNhbmNlbEJ0blxuICAgICAgICBuZXh0LmZvY3VzKClcbiAgICB9XG4gIH1cbiAgYWZ0ZXJJbnNlcnQoKSB7XG4gICAgdGhpcy5saXN0ZW5lciA9IGUgPT4gdGhpcy5rZXl1cExpc3RlbmVyKGUpXG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIHRoaXMubGlzdGVuZXIpXG4gICAgc3dpdGNoICh0aGlzLnR5cGUpIHtcbiAgICAgIGNhc2UgJ2FzeW5jLWJsb2NrJzpcbiAgICAgICAgdGhpcy5zdGFydCA9IERhdGUubm93KClcbiAgICAgICAgYnJlYWtcbiAgICAgIGNhc2UgJ2NvbmZpcm0nOlxuICAgICAgICB0aGlzLm9rQnRuLmZvY3VzKClcbiAgICAgICAgdGhpcy5hZGRFdmVudChcImNsaWNrXCIsIGUgPT4ge1xuICAgICAgICAgIGlmIChlLnRhcmdldC5ub2RlTmFtZSAhPT0gXCJCVVRUT05cIikgcmV0dXJuIGZhbHNlXG4gICAgICAgICAgdGhpcy5kZWxldGUoKVxuICAgICAgICAgIGlmICh0aGlzW2UudGFyZ2V0LmlkXSkgdGhpc1tlLnRhcmdldC5pZF0oKVxuICAgICAgICB9KVxuICAgICAgICBicmVha1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgZG9jdW1lbnQuYWN0aXZlRWxlbWVudC5ibHVyKClcbiAgICAgICAgdGhpcy5hZGRFdmVudChcImNsaWNrXCIsIGUgPT4ge1xuICAgICAgICAgIGlmIChlLnRhcmdldC5pZCA9PT0gdGhpcy5uZXdOb2RlLmlkKSB0aGlzLmRlbGV0ZSgpXG4gICAgICAgIH0pXG4gICAgfVxuICB9XG5cbiAgYWZ0ZXJEZWxldGUoKSB7XG4gICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIHRoaXMubGlzdGVuZXIpXG4gIH1cblxuICBnZXQgb2tCdG4oKSB7XG4gICAgcmV0dXJuIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKG1Db25zdHMuaWRzLmNvbmZpcm1PaylcbiAgfVxuXG4gIGdldCBjYW5jZWxCdG4oKSB7XG4gICAgcmV0dXJuIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKG1Db25zdHMuaWRzLmNvbmZpcm1DYW5jZWwpXG4gIH1cbn1cbiIsImV4cG9ydCBkZWZhdWx0IGNsYXNzIHtcbiAgY29uc3RydWN0b3IoY2FsbGJhY2ssIGRlbGF5KSB7XG4gICAgdGhpcy5jYWxsYmFjayA9IGNhbGxiYWNrXG4gICAgdGhpcy5yZW1haW5pbmcgPSBkZWxheVxuICAgIHRoaXMucmVzdW1lKClcbiAgfVxuICBwYXVzZSgpIHtcbiAgICB0aGlzLnBhdXNlZCA9IHRydWVcbiAgICB3aW5kb3cuY2xlYXJUaW1lb3V0KHRoaXMudGltZXJJZClcbiAgICB0aGlzLnJlbWFpbmluZyAtPSBuZXcgRGF0ZSgpIC0gdGhpcy5zdGFydFxuICB9XG4gIHJlc3VtZSgpIHtcbiAgICB0aGlzLnBhdXNlZCA9IGZhbHNlXG4gICAgdGhpcy5zdGFydCA9IG5ldyBEYXRlKClcbiAgICB3aW5kb3cuY2xlYXJUaW1lb3V0KHRoaXMudGltZXJJZClcbiAgICB0aGlzLnRpbWVySWQgPSB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICB3aW5kb3cuY2xlYXJUaW1lb3V0KHRoaXMudGltZXJJZClcbiAgICAgIHRoaXMuY2FsbGJhY2soKVxuICAgIH0sIHRoaXMucmVtYWluaW5nKVxuICB9XG4gIHRvZ2dsZSgpIHtcbiAgICBpZiAodGhpcy5wYXVzZWQpIHRoaXMucmVzdW1lKClcbiAgICBlbHNlIHRoaXMucGF1c2UoKVxuICB9XG59XG4iLCJpbXBvcnQgRWxlbSBmcm9tIFwiLi9lbGVtXCJcbmltcG9ydCBUaW1lciBmcm9tIFwiLi90aW1lclwiXG5cbmltcG9ydCB7XG4gIHRDb25zdHMsXG4gIGVDb25zdHNcbn0gZnJvbSBcIi4vY29uc3RhbnRzXCJcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgZXh0ZW5kcyBFbGVtIHtcbiAgY29uc3RydWN0b3IobXNnLCB0eXBlLCBvcHRpb25zLCBwYXJlbnQpIHtcbiAgICBzdXBlcihcbiAgICAgIHBhcmVudCxcbiAgICAgIGAke3RDb25zdHMucHJlZml4fS0ke01hdGguZmxvb3IoRGF0ZS5ub3coKSAtIE1hdGgucmFuZG9tKCkgKiAxMDApfWAsXG4gICAgICBgJHt0Q29uc3RzLnByZWZpeH0gJHt0Q29uc3RzLnByZWZpeH0tJHt0eXBlfWAsXG4gICAgICBgYW5pbWF0aW9uLWR1cmF0aW9uOiAke29wdGlvbnMudG9TZWNzKG9wdGlvbnMuYW5pbWF0aW9uRHVyYXRpb24pfTtgLFxuICAgICAgb3B0aW9uc1xuICAgIClcbiAgICB0aGlzLnVwZGF0ZVR5cGUodHlwZSlcbiAgICB0aGlzLnNldElubmVySHRtbChtc2cpXG4gIH1cblxuICBzZXRJbm5lckh0bWwoaHRtbCkge1xuICAgIGlmICh0aGlzLnR5cGUgPT09ICdhbGVydCcgJiYgaHRtbCkgaHRtbCA9IHRoaXMub3B0aW9ucy5mb3JtYXRFcnJvcihodG1sKVxuICAgIGh0bWwgPSB0aGlzLm9wdGlvbnMuYXBwbHlSZXBsYWNlbWVudHMoaHRtbCwgdGhpcy50eXBlKVxuICAgIHRoaXMubmV3Tm9kZS5pbm5lckhUTUwgPSBgPGRpdiBjbGFzcz1cImF3bi10b2FzdC13cmFwcGVyXCI+JHt0aGlzLnByb2dyZXNzQmFyfSR7dGhpcy5sYWJlbH08ZGl2IGNsYXNzPVwiJHt0Q29uc3RzLmtsYXNzLmNvbnRlbnR9XCI+JHtodG1sfTwvZGl2PjxzcGFuIGNsYXNzPVwiJHt0Q29uc3RzLmtsYXNzLmljb259XCI+JHt0aGlzLm9wdGlvbnMuaWNvbih0aGlzLnR5cGUpfTwvc3Bhbj48L2Rpdj5gXG4gIH1cblxuICBiZWZvcmVJbnNlcnQoKSB7XG4gICAgaWYgKHRoaXMucGFyZW50LmNoaWxkRWxlbWVudENvdW50ID49IHRoaXMub3B0aW9ucy5tYXhOb3RpZmljYXRpb25zKSB7XG4gICAgICBsZXQgZWxlbWVudHMgPSBBcnJheS5mcm9tKHRoaXMucGFyZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUodENvbnN0cy5wcmVmaXgpKVxuICAgICAgdGhpcy5kZWxldGUoZWxlbWVudHMuZmluZChlID0+ICF0aGlzLmlzRGVsZXRlZChlKSkpXG4gICAgfVxuICB9XG4gIGFmdGVySW5zZXJ0KCkge1xuICAgIGlmICh0aGlzLnR5cGUgPT0gXCJhc3luY1wiKSByZXR1cm4gdGhpcy5zdGFydCA9IERhdGUubm93KClcblxuICAgIHRoaXMuYWRkRXZlbnQoXCJjbGlja1wiLCAoKSA9PiB0aGlzLmRlbGV0ZSgpKVxuXG4gICAgaWYgKHRoaXMuZHVyYXRpb24gPD0gMCkgcmV0dXJuXG4gICAgdGhpcy50aW1lciA9IG5ldyBUaW1lcigoKSA9PiB0aGlzLmRlbGV0ZSgpLCB0aGlzLmR1cmF0aW9uKVxuICAgIGZvciAoY29uc3QgZSBvZiBbXCJtb3VzZWVudGVyXCIsIFwibW91c2VsZWF2ZVwiXSkge1xuICAgICAgdGhpcy5hZGRFdmVudChlLCAoKSA9PiB7XG4gICAgICAgIGlmICh0aGlzLmlzRGVsZXRlZCgpKSByZXR1cm5cbiAgICAgICAgdGhpcy50b2dnbGVDbGFzcyh0Q29uc3RzLmtsYXNzLnByb2dyZXNzQmFyUGF1c2UpXG4gICAgICAgIHRoaXMudGltZXIudG9nZ2xlKClcbiAgICAgIH0pXG4gICAgfVxuICB9XG5cbiAgaXNEZWxldGVkKGVsID0gdGhpcy5lbCkge1xuICAgIHJldHVybiBlbC5jbGFzc0xpc3QuY29udGFpbnMoZUNvbnN0cy5rbGFzcy5oaWRpbmcpXG4gIH1cbiAgZ2V0IHByb2dyZXNzQmFyKCkge1xuICAgIGlmICh0aGlzLmR1cmF0aW9uIDw9IDAgfHwgdGhpcy50eXBlID09PSAnYXN5bmMnKSByZXR1cm4gXCJcIlxuICAgIHJldHVybiBgPGRpdiBjbGFzcz0nJHt0Q29uc3RzLmtsYXNzLnByb2dyZXNzQmFyfScgc3R5bGU9XCJhbmltYXRpb24tZHVyYXRpb246JHt0aGlzLm9wdGlvbnMudG9TZWNzKHRoaXMuZHVyYXRpb24pfTtcIj48L2Rpdj5gXG4gIH1cbiAgZ2V0IGxhYmVsKCkge1xuICAgIHJldHVybiBgPGIgY2xhc3M9XCIke3RDb25zdHMua2xhc3MubGFiZWx9XCI+JHt0aGlzLm9wdGlvbnMubGFiZWwodGhpcy50eXBlKX08L2I+YFxuICB9XG5cbn1cbiIsImltcG9ydCBjb3Vyc2VBcGkgZnJvbSAnLi90cmFpbmluZ3MvdHJhaW5pbmdzJztcclxuaW1wb3J0IG1vZHVsZUFwaSBmcm9tICcuL21vZHVsZSc7XHJcbmltcG9ydCBwYXltZW50c0FwaSBmcm9tICcuL3BheW1lbnRzJztcclxuaW1wb3J0IHN1cnZleUFwaSBmcm9tICcuL3N1cnZleSc7XHJcbmltcG9ydCBjb21tb25BcGkgZnJvbSAnLi9jb21tb24nO1xyXG5pbXBvcnQgcXVpekFwaSBmcm9tICcuL3F1aXonO1xyXG5pbXBvcnQgdXNlcnNBcGkgZnJvbSAnLi91c2Vycyc7XHJcbmltcG9ydCBzdHJlYW1BcGkgZnJvbSAnLi9zdHJlYW0vc3RyZWFtJztcclxuaW1wb3J0IGNwZUFwaSBmcm9tICcuL2NwZS9jcGUnO1xyXG5pbXBvcnQgZ2VuZXJpY0FwaSBmcm9tICcuL3N0b3JhZ2UvZ2VuZXJpYyc7XHJcbmltcG9ydCB0ZW1wbGF0ZXNBcGkgZnJvbSAnLi9zdG9yYWdlL3RlbXBsYXRlcyc7XHJcbmltcG9ydCBhc3Nlc3NtZW50QXBpIGZyb20gJy4vc3RvcmFnZS9hc3Nlc3NtZW50Q29uZmlnJztcclxuaW1wb3J0IHN0YXRzQXBpIGZyb20gJy4vc3RvcmFnZS9wYXltZW50U3RhdHMnO1xyXG5pbXBvcnQgbW9kdWxlc0RhdGFBcGkgZnJvbSAnLi9zdG9yYWdlL21vZHVsZXNEYXRhLmpzJztcclxuaW1wb3J0IGFscGhhSnVkZ2VBcGkgZnJvbSAnLi9qdWRnZS9hbHBoYUp1ZGdlLmpzJztcclxuaW1wb3J0IHsgQ29udGVudFR5cGUgfSBmcm9tICcuLi91dGlsL2NvbnRlbnRUeXBlcy5qcyc7XHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gYmluZFNpdGVBcGkoYXBwTmFtZSkge1xyXG4gICAgY29uc3QgZW52ID0ge1xyXG4gICAgICAgIGludGVyb3BIb3N0LFxyXG4gICAgICAgIGludGVyb3BBcHBJZCxcclxuICAgICAgICBwYXJhbXMsXHJcbiAgICAgICAgcG9zdCxcclxuICAgICAgICBnZXQsXHJcbiAgICAgICAgaW50ZXJvcFBsYXRmb3JtSG9zdCxcclxuICAgICAgICBpbnRlcm9wQWRtaW5BbHBoYUp1ZGdlSG9zdFxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBhY3Rpb25zID0ge1xyXG4gICAgICAgIC4uLmNvdXJzZUFwaShlbnYpLFxyXG4gICAgICAgIC4uLm1vZHVsZUFwaShlbnYpLFxyXG4gICAgICAgIC4uLnBheW1lbnRzQXBpKGVudiksXHJcbiAgICAgICAgLi4uc3VydmV5QXBpKGVudiksXHJcbiAgICAgICAgLi4uY29tbW9uQXBpKGVudiksXHJcbiAgICAgICAgLi4ucXVpekFwaShlbnYpLFxyXG4gICAgICAgIC4uLnVzZXJzQXBpKGVudiksXHJcbiAgICAgICAgLi4uc3RyZWFtQXBpKGVudiksXHJcbiAgICAgICAgLi4uY3BlQXBpKGVudiksXHJcbiAgICAgICAgLi4uZ2VuZXJpY0FwaShlbnYpLFxyXG4gICAgICAgIC4uLnRlbXBsYXRlc0FwaShlbnYpLFxyXG4gICAgICAgIC4uLmFzc2Vzc21lbnRBcGkoZW52KSxcclxuICAgICAgICAuLi5zdGF0c0FwaShlbnYpLFxyXG4gICAgICAgIC4uLm1vZHVsZXNEYXRhQXBpKGVudiksXHJcbiAgICAgICAgLi4uYWxwaGFKdWRnZUFwaShlbnYpXHJcbiAgICB9O1xyXG5cclxuICAgIGlmIChhcHBOYW1lID09PSBudWxsKSB7XHJcbiAgICAgICAgcmV0dXJuIE9iamVjdC5rZXlzKGFjdGlvbnMpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gYWN0aW9ucztcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBpbnRlcm9wSG9zdChlbmRwb2ludCkge1xyXG4gICAgICAgIHN3aXRjaCAoYXBwTmFtZSkge1xyXG4gICAgICAgICAgICBjYXNlICdkaWdpdGFsJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiAnaHR0cHM6Ly9kaWdpdGFsLnNvZnR1bmkuYmcvJyArIGVuZHBvaW50O1xyXG4gICAgICAgICAgICBjYXNlICdjcmVhdGl2ZSc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJ2h0dHBzOi8vY3JlYXRpdmUuc29mdHVuaS5iZy8nICsgZW5kcG9pbnQ7XHJcbiAgICAgICAgICAgIGNhc2UgJ2FpJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiAnaHR0cHM6Ly9haS5zb2Z0dW5pLmJnLycgKyBlbmRwb2ludDtcclxuICAgICAgICAgICAgY2FzZSAnZmluYW5jZWFjYWRlbXknOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdodHRwczovL2ZpbmFuY2VhY2FkZW15LmJnLycgKyBlbmRwb2ludDtcclxuICAgICAgICAgICAgY2FzZSAnZGV2ZGlnaXRhbCc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJ2h0dHBzOi8vZGV2LmRpZ2l0YWwuc29mdHVuaS5iZy8nICsgZW5kcG9pbnQ7XHJcbiAgICAgICAgICAgIGNhc2UgJ2RldnNvZnR1bmknOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdodHRwczovL2Rldi5zb2Z0dW5pLmJnLycgKyBlbmRwb2ludDtcclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIHJldHVybiAnaHR0cHM6Ly9zb2Z0dW5pLmJnLycgKyBlbmRwb2ludDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gaW50ZXJvcEFwcElkKCkge1xyXG4gICAgICAgIHN3aXRjaCAoYXBwTmFtZSkge1xyXG4gICAgICAgICAgICBjYXNlICdkaWdpdGFsJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiAnZGlnaXRhbC5zb2Z0dW5pLmJnJztcclxuICAgICAgICAgICAgY2FzZSAnY3JlYXRpdmUnOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdjcmVhdGl2ZS5zb2Z0dW5pLmJnJztcclxuICAgICAgICAgICAgY2FzZSAnYWknOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdhaS5zb2Z0dW5pLmJnJztcclxuICAgICAgICAgICAgY2FzZSAnZmluYW5jZWFjYWRlbXknOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdmaW5hbmNlYWNhZGVteS5iZyc7XHJcbiAgICAgICAgICAgIGNhc2UgJ2RldmRpZ2l0YWwnOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdkaWdpdGFsLnNvZnR1bmkuYmcnO1xyXG4gICAgICAgICAgICBjYXNlICdkZXZzb2Z0dW5pJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiAnc29mdHVuaS5iZyc7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJ3NvZnR1bmkuYmcnO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBpbnRlcm9wUGxhdGZvcm1Ib3N0KCkge1xyXG4gICAgICAgIHN3aXRjaCAoYXBwTmFtZSkge1xyXG4gICAgICAgICAgICBjYXNlICdkaWdpdGFsJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiAnaHR0cHM6Ly9wbGF0Zm9ybS5zb2Z0dW5pLmJnJztcclxuICAgICAgICAgICAgY2FzZSAnY3JlYXRpdmUnOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdodHRwczovL3BsYXRmb3JtLnNvZnR1bmkuYmcnO1xyXG4gICAgICAgICAgICBjYXNlICdhaSc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJ2h0dHBzOi8vcGxhdGZvcm0uc29mdHVuaS5iZyc7XHJcbiAgICAgICAgICAgIGNhc2UgJ2ZpbmFuY2VhY2FkZW15JzpcclxuICAgICAgICAgICAgICAgIHJldHVybiAnaHR0cHM6Ly9wbGF0Zm9ybS5maW5hbmNlYWNhZGVteS5iZyc7XHJcbiAgICAgICAgICAgIGNhc2UgJ2RldmRpZ2l0YWwnOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdodHRwczovL2Rldi5wbGF0Zm9ybS5zb2Z0dW5pLmJnJztcclxuICAgICAgICAgICAgY2FzZSAnZGV2c29mdHVuaSc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJ2h0dHBzOi8vZGV2LnBsYXRmb3JtLnNvZnR1bmkuYmcnO1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdodHRwczovL3BsYXRmb3JtLnNvZnR1bmkuYmcnO1xyXG5cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gaW50ZXJvcEFkbWluQWxwaGFKdWRnZUhvc3QoKSB7XHJcbiAgICAgICAgc3dpdGNoIChhcHBOYW1lKSB7XHJcbiAgICAgICAgICAgIGNhc2UgJ2RldnNvZnR1bmknOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIFwiaHR0cHM6Ly9hZG1pbi5kZXYuYWxwaGEuanVkZ2Uuc29mdHVuaS5vcmdcIlxyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIFwiaHR0cHM6Ly9hZG1pbi5hbHBoYS5qdWRnZS5zb2Z0dW5pLm9yZ1wiO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxubGV0IGhvc3RzID0gW1xyXG4gICAgJ2h0dHBzOi8vZGlnaXRhbC5zb2Z0dW5pLmJnLycsXHJcbiAgICAnaHR0cHM6Ly9jcmVhdGl2ZS5zb2Z0dW5pLmJnLycsXHJcbiAgICAnaHR0cHM6Ly9haS5zb2Z0dW5pLmJnLycsXHJcbiAgICAnaHR0cHM6Ly9maW5hbmNlYWNhZGVteS5iZy8nLFxyXG4gICAgJ2h0dHBzOi8vZGV2LmRpZ2l0YWwuc29mdHVuaS5iZy8nLFxyXG4gICAgJ2h0dHBzOi8vZGV2LnNvZnR1bmkuYmcvJyxcclxuICAgICdodHRwczovL3NvZnR1bmkuYmcvJ1xyXG5dXHJcblxyXG5sZXQgcGxhdGZvcm1Ib3N0cyA9IFtcclxuICAgICdodHRwczovL3BsYXRmb3JtLmZpbmFuY2VhY2FkZW15LmJnJyxcclxuICAgICdodHRwczovL2Rldi5wbGF0Zm9ybS5zb2Z0dW5pLmJnJyxcclxuICAgICdodHRwczovL3BsYXRmb3JtLnNvZnR1bmkuYmcnXHJcbl1cclxuXHJcbmxldCBqdWRnZUhvc3RzID0gW1xyXG4gICAgXCJodHRwczovL2FkbWluLmFscGhhLmp1ZGdlLnNvZnR1bmkub3JnXCIsXHJcbiAgICBcImh0dHBzOi8vZGV2LmFkbWluLmFscGhhLmp1ZGdlLnNvZnR1bmkub3JnXCIsXHJcbiAgICBcImh0dHBzOi8vYWxwaGEuanVkZ2Uuc29mdHVuaS5vcmdcIixcclxuICAgIFwiaHR0cHM6Ly9kZXYuYWxwaGEuanVkZ2Uuc29mdHVuaS5vcmdcIixcclxuXVxyXG5cclxuZnVuY3Rpb24gcGFyYW1zKHBhcmFtcyA9IHt9KSB7XHJcbiAgICByZXR1cm4gT2JqZWN0LmFzc2lnbih7XHJcbiAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgcGFnZTogMSxcclxuICAgICAgICBwYWdlU2l6ZTogMTAsXHJcbiAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgIGZpbHRlcjogJydcclxuICAgIH0sIHBhcmFtcyk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHBvc3QodXJsLCBwYXJhbXMsIGNvbnRlbnRUeXBlID0gQ29udGVudFR5cGUuVXJsRm9ybUVuY29kZWQsIGFzQmxvYiA9IGZhbHNlKSB7XHJcbiAgICBsZXQgYm9keSA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoKTtcclxuICAgIGlmKGNvbnRlbnRUeXBlID09PSBDb250ZW50VHlwZS5BcHBsaWNhdGlvbkpzb24pIHtcclxuICAgICAgICBib2R5ID0gSlNPTi5zdHJpbmdpZnkocGFyYW1zKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgZm9yIChsZXQga2V5IG9mIE9iamVjdC5rZXlzKHBhcmFtcykpIHtcclxuICAgICAgICAgICAgYm9keS5hcHBlbmQoa2V5LCBwYXJhbXNba2V5XSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHJlcSA9IHtcclxuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiBjb250ZW50VHlwZVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYm9keVxyXG4gICAgfTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2godXJsLCByZXEpO1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgIT09IDIwMCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ1Vuc3VjY2Vzc2Z1bCByZXF1ZXN0Jyk7XHJcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihwYXJhbXMpO1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4ocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICBsZXQgZXJyb3IgPSBuZXcgRXJyb3IoYCR7cmVzcG9uc2Uuc3RhdHVzfTogJHtyZXNwb25zZS5zdGF0dXNUZXh0fSBhdCAke3Jlc3BvbnNlLnVybH1gKTtcclxuICAgICAgICAgICAgZXJyb3IuX3N0YXR1cyA9IHJlc3BvbnNlLnN0YXR1cztcclxuICAgICAgICAgICAgdGhyb3cgZXJyb3I7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChyZXNwb25zZS5yZWRpcmVjdGVkIHx8IHJlc3BvbnNlLnN0YXR1cyA9PSAzMDIpIHtcclxuICAgICAgICAgICAgbGV0IHVybERvbWFpbiA9IGhvc3RzLmZpbmQoeCA9PiB1cmwuc3RhcnRzV2l0aCh4KSk7XHJcbiAgICAgICAgICAgIGxldCBwbGF0Zm9ybURvbWFpbiA9IHBsYXRmb3JtSG9zdHMuZmluZCh4ID0+IHVybC5zdGFydHNXaXRoKHgpKTtcclxuICAgICAgICAgICAgbGV0IGp1ZGdlRG9tYWluID0ganVkZ2VIb3N0cy5maW5kKHggPT4gdXJsLnN0YXJ0c1dpdGgoeCkpO1xyXG5cclxuICAgICAgICAgICAgaWYoIXVybERvbWFpbikge1xyXG4gICAgICAgICAgICAgICAgdXJsRG9tYWluID0gcGxhdGZvcm1Eb21haW47XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmKCF1cmxEb21haW4pIHtcclxuICAgICAgICAgICAgICAgIHVybERvbWFpbiA9IGp1ZGdlRG9tYWluO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGBSZXF1ZXN0IGVycm9yIGZldGNoaW5nIGZyb20gJHt1cmx9LCB5b3UncmUgcHJvYmFibHkgbm90IGxvZ2dlZCBpbiAnJHt1cmxEb21haW59Jy5gKTtcclxuICAgICAgICAgICAgY29uc3QgZXJyb3IgPSBuZXcgRXJyb3IoYFJlcXVlc3QgZXJyb3IsIHlvdSdyZSBwcm9iYWJseSBub3QgbG9nZ2VkIGluIDxhIGhyZWY9XCIke3VybERvbWFpbn1cIiB0YXJnZXQ9XCJfYmxhbmtcIj4ke3VybERvbWFpbn08L2E+LiBQbGVhc2UgbG9naW4gdG8gPGEgaHJlZj1cIiR7dXJsRG9tYWlufVwiIHRhcmdldD1cIl9ibGFua1wiPiR7dXJsRG9tYWlufTwvYT4gYW5kIHRyeSBhZ2Fpbi5gKTtcclxuICAgICAgICAgICAgZXJyb3IuX3VybCA9IHVybDtcclxuICAgICAgICAgICAgdGhyb3cgZXJyb3I7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZihhc0Jsb2IpIHtcclxuICAgICAgICAgICAgbGV0IGZpbGVuYW1lID0gcmVzcG9uc2UuaGVhZGVycy5nZXQoJ0NvbnRlbnQtRGlzcG9zaXRpb24nKS5zcGxpdCgnZmlsZW5hbWU9JylbMV0uc3BsaXQoJzsnKVswXS5yZXBsYWNlQWxsKCdcXFwiJywgJycpO1xyXG4gICAgICAgICAgICBsZXQgYmxvYiA9IGF3YWl0IHJlc3BvbnNlLmJsb2IoKTtcclxuICAgICAgICAgICAgYmxvYi5maWxlbmFtZSA9IGZpbGVuYW1lO1xyXG4gICAgICAgICAgICByZXR1cm4gYmxvYjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGxldCByZXN1bHQgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XHJcbiAgICAgICAgICAgIGlmKHJlc3VsdC5FcnJvcnMpIHtcclxuICAgICAgICAgICAgICAgIGxldCBlcnJvcnNQYXJzZWQgPSBKU09OLnN0cmluZ2lmeShyZXN1bHQuRXJyb3JzLCB1bmRlZmluZWQsIDIpO1xyXG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGVycm9yc1BhcnNlZClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgaWYgKGUgaW5zdGFuY2VvZiBTeW50YXhFcnJvcikge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhyb3cgZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIGNhdGNoIChlKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihlKTtcclxuICAgICAgICB0aHJvdyBlO1xyXG4gICAgfVxyXG5cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZ2V0KHVybCwgYXNCbG9iKSB7XHJcbiAgICBjb25zdCByZXEgPSB7XHJcbiAgICAgICAgbWV0aG9kOiAnR0VUJ1xyXG4gICAgfTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICAgIGxldCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHVybCwgcmVxKTtcclxuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzICE9PSAyMDApIHtcclxuICAgICAgICAgICAgY29uc29sZS53YXJuKCdVbnN1Y2Nlc3NmdWwgcmVxdWVzdCcpO1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4ocGFyYW1zKTtcclxuICAgICAgICAgICAgY29uc29sZS53YXJuKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3Jlc3BvbnNlLnN0YXR1c1RleHR9IGF0ICR7cmVzcG9uc2UudXJsfWApO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAocmVzcG9uc2UucmVkaXJlY3RlZCkge1xyXG4gICAgICAgICAgICBpZiAodXJsLmluY2x1ZGVzKCdwbGF0Zm9ybScpKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgcGxhdGZvcm1Eb21haW4gPSBwbGF0Zm9ybUhvc3RzLmZpbmQoeCA9PiB1cmwuc3RhcnRzV2l0aCh4KSk7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGBSZXF1ZXN0IGVycm9yIGZldGNoaW5nIGZyb20gJHt1cmx9LCB5b3UncmUgcHJvYmFibHkgbm90IGxvZ2dlZCBpbiB0byB0aGUgcGxhdGZvcm0uYCk7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBlcnJvciA9IG5ldyBFcnJvcihgUmVxdWVzdCBlcnJvciwgeW91J3JlIHByb2JhYmx5IG5vdCBsb2dnZWQgaW4gPGEgaHJlZj1cIiR7cGxhdGZvcm1Eb21haW59XCIgdGFyZ2V0PVwiX2JsYW5rXCI+JHtwbGF0Zm9ybURvbWFpbn08L2E+LiBQbGVhc2UgbG9naW4gdG8gPGEgaHJlZj1cIiR7cGxhdGZvcm1Eb21haW59XCIgdGFyZ2V0PVwiX2JsYW5rXCI+JHtwbGF0Zm9ybURvbWFpbn08L2E+IGFuZCB0cnkgYWdhaW4uYCk7XHJcbiAgICAgICAgICAgICAgICBlcnJvci5fdXJsID0gdXJsO1xyXG4gICAgICAgICAgICAgICAgdGhyb3cgZXJyb3I7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXNwb25zZSA9IGF3YWl0IGZldGNoKHJlc3BvbnNlLnVybCwgcmVxKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGFzQmxvYikge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuYmxvYigpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgcmVhZGVyID0gcmVzcG9uc2UuYm9keS5nZXRSZWFkZXIoKTtcclxuICAgICAgICBjb25zdCB1dGY4RGVjb2RlciA9IG5ldyBUZXh0RGVjb2RlcigndXRmLTgnKTtcclxuICAgICAgICBsZXQgcmVzdWx0ID0gJyc7XHJcbiAgICAgICAgd2hpbGUgKHRydWUpIHtcclxuICAgICAgICAgICAgY29uc3QgeyBkb25lLCB2YWx1ZSB9ID0gYXdhaXQgcmVhZGVyLnJlYWQoKTtcclxuICAgICAgICAgICAgaWYgKGRvbmUpIHtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJlc3VsdCArPSB1dGY4RGVjb2Rlci5kZWNvZGUodmFsdWUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UocmVzdWx0KTtcclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgY2F0Y2ggKGUpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKGUpO1xyXG4gICAgICAgIHRocm93IGU7XHJcbiAgICB9XHJcblxyXG59IiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSkge1xyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0QmxvZ0J5VXJsKGJsb2dVcmwpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fY21zL25ld3MvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBmaWx0ZXI6IGBVcmx+ZXF+JyR7YmxvZ1VybH0nYFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YVswXTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRIYWxscygpIHtcclxuICAgICAgICBjb25zdCBkaXIgPSBpbnRlcm9wQXBwSWQoKSA9PSAnc29mdHVuaS5iZycgPyAnYWRtaW5pc3RyYXRpb25fdW5pdmVyc2l0eScgOiAnQWRtaW5pc3RyYXRpb24nO1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGRpciArICcvdHJhaW5pbmdsYWJzL3JlYWQnKTtcclxuXHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0U29mdHdhcmVVbml2ZXJzaXR5SGFsbHMoKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gJ2h0dHBzOi8vc29mdHVuaS5iZy9hZG1pbmlzdHJhdGlvbl91bml2ZXJzaXR5L3RyYWluaW5nbGFicy9yZWFkJztcclxuXHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gZ2V0SGFsbEJvZHkoaGFsbCkge1xyXG4gICAgICAgIGxldCBjdXJyZW50RGF0ZSA9IG5ldyBEYXRlKCk7XHJcbiAgICAgICAgLy8gc2ltcGxlc3Qgd2F5IHRvIGNvbnZlcnQgZGF0ZSB0byBJU08gZm9ybWF0IGluIGxvY2FsIFRpbWV6b25lIGFzIFNVTFMgcmVxdWlyZXNcclxuICAgICAgICBjdXJyZW50RGF0ZS5zZXRNaW51dGVzKGN1cnJlbnREYXRlLmdldE1pbnV0ZXMoKSAtIGN1cnJlbnREYXRlLmdldFRpbWV6b25lT2Zmc2V0KCkpXHJcbiAgICAgICAgbGV0IG1vZGlmaWVkT25EYXRlID0gY3VycmVudERhdGUudG9JU09TdHJpbmcoKS5zbGljZSgwLCAtMSk7XHJcblxyXG4gICAgICAgIGNvbnN0IGJvZHkgPSB7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiBoYWxsLklkLFxyXG4gICAgICAgICAgICBOYW1lQmc6IGhhbGwuTmFtZUJnLFxyXG4gICAgICAgICAgICBOYW1lRW46IGhhbGwuTmFtZUVuLFxyXG4gICAgICAgICAgICBBZGRyZXNzOiBoYWxsLkFkZHJlc3MsXHJcbiAgICAgICAgICAgIENhcGFjaXR5OiBoYWxsLkNhcGFjaXR5LFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbjogaGFsbC5EZXNjcmlwdGlvbixcclxuICAgICAgICAgICAgRGlzYWJsZVNlY3VyZUxpbms6IGhhbGwuRGlzYWJsZVNlY3VyZUxpbmssXHJcbiAgICAgICAgICAgIEZsb29yOiBoYWxsLkZsb29yLFxyXG4gICAgICAgICAgICBHb29nbGVDYWxlbmRhcklkOiBoYWxsLkdvb2dsZUNhbGVuZGFySWQsXHJcbiAgICAgICAgICAgIElzQWN0aXZlOiBoYWxsLklzQWN0aXZlLFxyXG4gICAgICAgICAgICBJc0ZlYXR1cmVkOiBoYWxsLklzRmVhdHVyZWQsXHJcbiAgICAgICAgICAgIElzUGh5c2ljYWw6IGhhbGwuSXNQaHlzaWNhbCxcclxuICAgICAgICAgICAgU2hvd09uU2NoZWR1bGU6IGhhbGwuU2hvd09uU2NoZWR1bGUsXHJcbiAgICAgICAgICAgIEJyYW5jaElkOiBoYWxsLkJyYW5jaElkLFxyXG4gICAgICAgICAgICBTZWF0c0NvbmZpZ3VyYXRpb246IGhhbGwuU2VhdHNDb25maWd1cmF0aW9uLFxyXG4gICAgICAgICAgICBTdHJlYW1pbmdUeXBlOiBoYWxsLlN0cmVhbWluZ1R5cGUsXHJcbiAgICAgICAgICAgIFlvdVR1YmVDb2RlOiBoYWxsLllvdVR1YmVDb2RlLFxyXG4gICAgICAgICAgICBTb2Z0VW5pU3RyZWFtQ29kZTogaGFsbC5Tb2Z0VW5pU3RyZWFtQ29kZSxcclxuICAgICAgICAgICAgU3RyZWFtaW5nU2VydmVyQmFzZUlkOiBoYWxsLlN0cmVhbWluZ1NlcnZlckJhc2VJZCxcclxuICAgICAgICAgICAgVWNkblN0cmVhbWluZ0NvZGU6IGhhbGwuVWNkblN0cmVhbWluZ0NvZGUsXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogaGFsbC5DcmVhdGVkT24sXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246IGhhbGwuTW9kaWZpZWRPbiB8fCBtb2RpZmllZE9uRGF0ZVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHJldHVybiBib2R5O1xyXG5cclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB1cGRhdGVIYWxsKGhhbGwpIHtcclxuICAgICAgICBsZXQgdXJpO1xyXG4gICAgICAgIGlmIChpbnRlcm9wQXBwSWQoKSA9PT0gJ3NvZnR1bmkuYmcnKSB7XHJcbiAgICAgICAgICAgIHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl91bml2ZXJzaXR5L3RyYWluaW5nbGFicy91cGRhdGUnKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB1cmkgPSBpbnRlcm9wSG9zdCgnQWRtaW5pc3RyYXRpb24vVHJhaW5pbmdMYWJzL1VwZGF0ZScpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgYm9keSA9IGdldEhhbGxCb2R5KGhhbGwpO1xyXG5cclxuICAgICAgICBpZiAoaW50ZXJvcEFwcElkKCkgIT09ICdzb2Z0dW5pLmJnJykge1xyXG4gICAgICAgICAgICBkZWxldGUgYm9keS5CcmFuY2hJZDtcclxuICAgICAgICAgICAgZGVsZXRlIGJvZHkuU2VhdHNDb25maWd1cmF0aW9uO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB1cGRhdGVTb2Z0d2FyZVVuaXZlcnNpdHlIYWxsKGhhbGwpIHtcclxuICAgICAgICBsZXQgdXJpID0gJ2h0dHBzOi8vc29mdHVuaS5iZy9hZG1pbmlzdHJhdGlvbl91bml2ZXJzaXR5L3RyYWluaW5nbGFicy91cGRhdGUnO1xyXG5cclxuICAgICAgICBjb25zdCBib2R5ID0gZ2V0SGFsbEJvZHkoaGFsbCk7XHJcblxyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldEJsb2dCeVVybCxcclxuICAgICAgICBnZXRIYWxscyxcclxuICAgICAgICB1cGRhdGVIYWxsLFxyXG4gICAgICAgIGdldFNvZnR3YXJlVW5pdmVyc2l0eUhhbGxzLFxyXG4gICAgICAgIHVwZGF0ZVNvZnR3YXJlVW5pdmVyc2l0eUhhbGxcclxuICAgIH07XHJcbn0iLCJpbXBvcnQgbmF2ZXRBcGlGYWN0b3J5IGZyb20gJy4vbmF2ZXQnO1xyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCwgZ2V0LCBpbnRlcm9wUGxhdGZvcm1Ib3N0IH0pIHtcclxuICAgIGNvbnN0IG5hdmV0QXBpID0gbmF2ZXRBcGlGYWN0b3J5KCk7XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0QXBwbGljYXRpb25zQnlJbnN0YW5jZUlkKGluc3RhbmNlSWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBgJHtpbnRlcm9wUGxhdGZvcm1Ib3N0KCl9L2FkbWluaXN0cmF0aW9uL2NwZWNlcnRpZmljYXRlYXBwbGljYXRpb25zL3JlYWQ/YXBwSWQ9JHtpbnRlcm9wQXBwSWQoKX1gO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnQ3JlYXRlZE9uLWRlc2MtYXNjJyxcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogYFRyYWluaW5nSWR+ZXF+JHtpbnN0YW5jZUlkfWBcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0QXBwbGljYXRpb25zKHF1ZXJ5LCBwYWdlKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gYCR7aW50ZXJvcFBsYXRmb3JtSG9zdCgpfS9hZG1pbmlzdHJhdGlvbi9jcGVjZXJ0aWZpY2F0ZWFwcGxpY2F0aW9ucy9yZWFkP2FwcElkPSR7aW50ZXJvcEFwcElkKCl9YDtcclxuXHJcbiAgICAgICAgY29uc3QgZmlsdGVyVG9rZW5zID0gW107XHJcbiAgICAgICAgaWYgKHF1ZXJ5Lmluc3RhbmNlSWQpIHtcclxuICAgICAgICAgICAgZmlsdGVyVG9rZW5zLnB1c2goYChUcmFpbmluZ0lkfmVxfiR7cXVlcnkuaW5zdGFuY2VJZH0pYCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChxdWVyeS5pbnN0YW5jZU5hbWUpIHtcclxuICAgICAgICAgICAgZmlsdGVyVG9rZW5zLnB1c2goYChUcmFpbmluZ05hbWV+Y29udGFpbnN+JyR7dG9rZW5pemUocXVlcnkuaW5zdGFuY2VOYW1lKS5qb2luKCdcXCd+YW5kflRyYWluaW5nTmFtZX5jb250YWluc35cXCcnKX0nKWApO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAocXVlcnkubmFtZXMpIHtcclxuICAgICAgICAgICAgY29uc3QgbmFtZVRva2VucyA9IHRva2VuaXplKHF1ZXJ5Lm5hbWVzKTtcclxuICAgICAgICAgICAgbGV0IG5hbWVGaWx0ZXIgPSAnJztcclxuICAgICAgICAgICAgaWYgKG5hbWVUb2tlbnMubGVuZ3RoID09IDEpIHtcclxuICAgICAgICAgICAgICAgIG5hbWVGaWx0ZXIgPSBgKEZpcnN0TmFtZX5jb250YWluc34nJHtuYW1lVG9rZW5zWzBdfSd+b3J+TWlkZGxlTmFtZX5jb250YWluc34nJHtuYW1lVG9rZW5zWzBdfSd+b3J+TGFzdE5hbWV+Y29udGFpbnN+JyR7bmFtZVRva2Vuc1swXX0nKWA7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAobmFtZVRva2Vucy5sZW5ndGggPT0gMikge1xyXG4gICAgICAgICAgICAgICAgbmFtZUZpbHRlciA9IGAoRmlyc3ROYW1lfmNvbnRhaW5zficke25hbWVUb2tlbnNbMF19J35hbmR+KE1pZGRsZU5hbWV+Y29udGFpbnN+JyR7bmFtZVRva2Vuc1sxXX0nfm9yfkxhc3ROYW1lfmNvbnRhaW5zficke25hbWVUb2tlbnNbMV19JykpYDtcclxuICAgICAgICAgICAgfSBlbHNlIGlmIChuYW1lVG9rZW5zLmxlbmd0aCA9PSAzKSB7XHJcbiAgICAgICAgICAgICAgICBuYW1lRmlsdGVyID0gYChGaXJzdE5hbWV+Y29udGFpbnN+JyR7bmFtZVRva2Vuc1swXX0nfmFuZH5NaWRkbGVOYW1lfmNvbnRhaW5zficke25hbWVUb2tlbnNbMV19J35hbmR+TGFzdE5hbWV+Y29udGFpbnN+JyR7bmFtZVRva2Vuc1syXX0nKWA7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGZpbHRlclRva2Vucy5wdXNoKG5hbWVGaWx0ZXIpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAocXVlcnkuU1NOKSB7XHJcbiAgICAgICAgICAgIGZpbHRlclRva2Vucy5wdXNoKGBTU05+Y29udGFpbnN+JyR7cXVlcnkuU1NOfSdgKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnQ3JlYXRlZE9uLWRlc2MnLFxyXG4gICAgICAgICAgICBwYWdlU2l6ZTogcGFnZSA/IDI1IDogMjAwMCxcclxuICAgICAgICAgICAgcGFnZTogcGFnZSA/IHBhZ2UgOiAxLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGZpbHRlclRva2Vucy5qb2luKCd+YW5kficpXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0QXBwWmlwKGlkKSB7XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7aW50ZXJvcFBsYXRmb3JtSG9zdCgpfS9hZG1pbmlzdHJhdGlvbi9jcGVjZXJ0aWZpY2F0ZWFwcGxpY2F0aW9ucy9nZXRmaWxlc3ppcD9pZD0ke2lkfWApO1xyXG5cclxuICAgICAgICBjb25zdCBibG9iID0gYXdhaXQgcmVzLmJsb2IoKTtcclxuICAgICAgICBjb25zdCBzZXJpYWxpemVkQmxvYiA9IG5ldyBVaW50OEFycmF5KGF3YWl0IGJsb2IuYXJyYXlCdWZmZXIoKSk7XHJcbiAgXHJcbiAgICAgICAgY29uc3QgYmxvYkRhdGEgPSB7XHJcbiAgICAgICAgICAgIHR5cGU6IGJsb2IudHlwZSxcclxuICAgICAgICAgICAgYnVmZmVyOiBBcnJheS5mcm9tKHNlcmlhbGl6ZWRCbG9iKVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHJldHVybiBibG9iRGF0YTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLy8gIyMjIEV4dGVybmFsIHN0b3JhZ2Ugb2YgYXBwbGljYXRpb24gZGF0YSAodXNlcyBsZWN0dXJlcyBpbnNpZGUgYSBmaXhlZCBjb3Vyc2UgaW5zdGFuY2UpXHJcblxyXG4gICAgY29uc3Qgc3RvcmVJZCA9IHtcclxuICAgICAgICAnc29mdHVuaS5iZyc6IDMxMjQsXHJcbiAgICAgICAgJ2RpZ2l0YWwuc29mdHVuaS5iZyc6IDIzMzYsXHJcbiAgICAgICAgJ2NyZWF0aXZlLnNvZnR1bmkuYmcnOiAxMTkzLFxyXG4gICAgICAgICdhaS5zb2Z0dW5pLmJnJzogOCxcclxuICAgICAgICAnZmluYW5jZWFjYWRlbXkuYmcnOiAyMjhcclxuICAgIH07XHJcblxyXG4gICAgY29uc3Qgc3RhdHVzTW9kZWwgPSB7XHJcbiAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgSWQ6ICcnLFxyXG4gICAgICAgIFRyYWluaW5nSWQ6ICcnLFxyXG4gICAgICAgIE5hbWVCZzogJycsXHJcbiAgICAgICAgTmFtZUVuOiAnJyxcclxuICAgICAgICBIYXNNYW51YWxOdW1iZXJPZlN0dWR5SG91cnM6ICcnLFxyXG4gICAgICAgIE51bWJlck9mU3R1ZHlIb3VyczogJycsXHJcbiAgICAgICAgSXNFeGNsdWRlZEZyb21DZXJ0aWZpY2F0ZTogJycsXHJcbiAgICAgICAgSGFzSG9tZXdvcms6ICcnLFxyXG4gICAgICAgIFJlc291cmNlTWFpbHNTdGF0ZTogJycsXHJcbiAgICAgICAgSG9tZXdvcmtNYWlsc1N0YXRlOiAnJyxcclxuICAgICAgICBKdWRnZUNvbnRlc3RJZDogJycsXHJcbiAgICAgICAgT3JkZXJCeTogJycsXHJcbiAgICAgICAgRGVzY3JpcHRpb25CZzogJycsXHJcbiAgICAgICAgRGVzY3JpcHRpb25FbjogJycsXHJcbiAgICAgICAgRXhjbHVkZUZyb21DYWxlbmRhcjogJycsXHJcbiAgICAgICAgSGFzTGl2ZVN0cmVhbTogJycsXHJcbiAgICAgICAgQ3JlYXRlZE9uOiAnJyxcclxuICAgICAgICBNb2RpZmllZE9uOiAnJ1xyXG4gICAgfTtcclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRBcHBTdGF0dXMoaWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2xlY3R1cmVzL3JlYWQ/Zm9yZWlnbktleUlkPSR7c3RvcmVJZFtpbnRlcm9wQXBwSWQoKV19YCk7XHJcbiAgICAgICAgbGV0IGZpbHRlciA9ICcnO1xyXG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KGlkKSkge1xyXG4gICAgICAgICAgICBmaWx0ZXIgPSBgTmFtZUVufmVxficke2lkLmpvaW4oJ1xcJ35vcn5OYW1lRW5+ZXF+XFwnJyl9J2A7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgZmlsdGVyID0gYE5hbWVFbn5lcX4nJHtpZH0nYDtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwLFxyXG4gICAgICAgICAgICBmaWx0ZXJcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0QXBwU3RhdHVzQnlJbnN0YW5jZUlkKGlkKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9sZWN0dXJlcy9yZWFkP2ZvcmVpZ25LZXlJZD0ke3N0b3JlSWRbaW50ZXJvcEFwcElkKCldfWApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMCxcclxuICAgICAgICAgICAgZmlsdGVyOiBgTmFtZUJnfmVxficke2lkfSdgXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmksIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVN0YXR1cyhzdGF0dXMpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2xlY3R1cmVzL2NyZWF0ZT9mb3JlaWduS2V5SWQ9JHtzdG9yZUlkW2ludGVyb3BBcHBJZCgpXX1gKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gT2JqZWN0LmFzc2lnbihwYXJhbXMoe30pLCBzdGF0dXNNb2RlbCk7XHJcbiAgICAgICAgZm9yIChsZXQgZmllbGQgaW4gYm9keSkge1xyXG4gICAgICAgICAgICBib2R5W2ZpZWxkXSA9IHN0YXR1c1tmaWVsZF0gPT09IHVuZGVmaW5lZCA/IGJvZHlbZmllbGRdIDogc3RhdHVzW2ZpZWxkXTtcclxuICAgICAgICB9XHJcbiAgICAgICAgYm9keS5UcmFpbmluZ0lkID0gc3RvcmVJZFtpbnRlcm9wQXBwSWQoKV07XHJcblxyXG4gICAgICAgIGxldCBzdGFydERhdGUgPSBuZXcgRGF0ZSgpO1xyXG4gICAgICAgIGxldCBlbmREYXRlID0gbmV3IERhdGUoc3RhcnREYXRlKTtcclxuICAgICAgICBlbmREYXRlLnNldFVUQ0RhdGUoZW5kRGF0ZS5nZXRVVENEYXRlKCkgICsgMSk7XHJcbiAgICAgICAgYm9keVtgRGF0ZXNJbmZvWzBdLlN0YXJ0YF0gPSBzdGFydERhdGUudG9JU09TdHJpbmcoKTtcclxuICAgICAgICBib2R5W2BEYXRlc0luZm9bMF0uRW5kYF0gPSBlbmREYXRlLnRvSVNPU3RyaW5nKCk7XHJcbiAgICAgICAgYm9keVtgRGF0ZXNJbmZvWzBdLkV4dHJhSW5mb3JtYXRpb25gXSA9ICcnO1xyXG5cclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCkgeyBib2R5W2tdID0gJyc7IH0gfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmksIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVN0YXR1cyhzdGF0dXMpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2xlY3R1cmVzL3VwZGF0ZT9mb3JlaWduS2V5SWQ9JHtzdG9yZUlkW2ludGVyb3BBcHBJZCgpXX1gKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gT2JqZWN0LmFzc2lnbihwYXJhbXMoe30pLCBzdGF0dXNNb2RlbCk7XHJcbiAgICAgICAgZm9yIChsZXQgZmllbGQgaW4gYm9keSkge1xyXG4gICAgICAgICAgICBib2R5W2ZpZWxkXSA9IHN0YXR1c1tmaWVsZF0gPT09IHVuZGVmaW5lZCA/IGJvZHlbZmllbGRdIDogc3RhdHVzW2ZpZWxkXTtcclxuICAgICAgICB9XHJcbiAgICAgICAgYm9keS5UcmFpbmluZ0lkID0gc3RvcmVJZFtpbnRlcm9wQXBwSWQoKV07XHJcblxyXG4gICAgICAgIGxldCBzdGFydERhdGUgPSBuZXcgRGF0ZSgpO1xyXG4gICAgICAgIGxldCBlbmREYXRlID0gbmV3IERhdGUoc3RhcnREYXRlKTtcclxuICAgICAgICBlbmREYXRlLnNldFVUQ0RhdGUoZW5kRGF0ZS5nZXRVVENEYXRlKCkgICsgMSk7XHJcbiAgICAgICAgYm9keVtgRGF0ZXNJbmZvWzBdLlN0YXJ0YF0gPSBzdGFydERhdGUudG9JU09TdHJpbmcoKTtcclxuICAgICAgICBib2R5W2BEYXRlc0luZm9bMF0uRW5kYF0gPSBlbmREYXRlLnRvSVNPU3RyaW5nKCk7XHJcbiAgICAgICAgYm9keVtgRGF0ZXNJbmZvWzBdLkV4dHJhSW5mb3JtYXRpb25gXSA9ICcnO1xyXG5cclxuICAgICAgICBib2R5LkNyZWF0ZWRPbiA9ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNyc7XHJcbiAgICAgICAgYm9keS5Nb2RpZmllZE9uID0gJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JztcclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCkgeyBib2R5W2tdID0gJyc7IH0gfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmksIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGRlc3Ryb3lTdGF0dXMoc3RhdHVzKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9sZWN0dXJlcy9kZXN0cm95P2ZvcmVpZ25LZXlJZD0ke3N0b3JlSWRbaW50ZXJvcEFwcElkKCldfWApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgT2JqZWN0LmFzc2lnbihib2R5LCBzdGF0dXMpO1xyXG4gICAgICAgIGJvZHkuVHJhaW5pbmdJZCA9IHN0b3JlSWRbaW50ZXJvcEFwcElkKCldO1xyXG4gICAgICAgIGJvZHkuQ3JlYXRlZE9uID0gJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JztcclxuICAgICAgICBib2R5Lk1vZGlmaWVkT24gPSAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICAuLi5uYXZldEFwaSxcclxuICAgICAgICBnZXRBcHBsaWNhdGlvbnNCeUluc3RhbmNlSWQsXHJcbiAgICAgICAgZ2V0QXBwbGljYXRpb25zLFxyXG4gICAgICAgIGdldEFwcFppcCxcclxuICAgICAgICBnZXRBcHBTdGF0dXMsXHJcbiAgICAgICAgZ2V0QXBwU3RhdHVzQnlJbnN0YW5jZUlkLFxyXG4gICAgICAgIGNyZWF0ZVN0YXR1cyxcclxuICAgICAgICB1cGRhdGVTdGF0dXMsXHJcbiAgICAgICAgZGVzdHJveVN0YXR1c1xyXG4gICAgfTtcclxufVxyXG5cclxuZnVuY3Rpb24gdG9rZW5pemUoYXNTdHJpbmcpIHtcclxuICAgIHJldHVybiBhc1N0cmluZy5zcGxpdCgnICcpLm1hcCh0ID0+IHQudHJpbSgpKS5maWx0ZXIodCA9PiB0Lmxlbmd0aCA+IDApO1xyXG59IiwiaW1wb3J0IEpTT041IGZyb20gJy4uLy4uLy4uL25vZGVfbW9kdWxlcy9qc29uNS9kaXN0L2luZGV4Lm1pbic7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAoKSB7XHJcbiAgICBjb25zdCBob3N0ID0gJ2h0dHBzOi8vaXMubmF2ZXQuZ292ZXJubWVudC5iZy9mdXJpYS9Qcm9qZWN0cy9uYXBvby9pbmRleC5uZXcucGhwJztcclxuXHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0KHVybCkge1xyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKHVybCk7XHJcbiAgICAgICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XHJcbiAgICAgICAgcmV0dXJuIHRleHQ7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gcG9zdEZvcm0odXJsLCBib2R5KSB7XHJcbiAgICAgICAgT2JqZWN0LmFzc2lnbihib2R5LCB7IGFwcGxpY2F0aW9uOiAnQUpBWERhdGFQcm92aWRlcicsIG5vQ2FjaGU6IERhdGUubm93KCkgfSk7XHJcbiAgICAgICAgY29uc3QgcXVlcnkgPSBbXTtcclxuICAgICAgICBmb3IgKGxldCBwYXJhbSBpbiBib2R5KSB7XHJcbiAgICAgICAgICAgIHF1ZXJ5LnB1c2goYCR7cGFyYW19PSR7ZW5jb2RlVVJJQ29tcG9uZW50KGJvZHlbcGFyYW1dKX1gKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2godXJsLCB7XHJcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAnQ29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZDsgY2hhcnNldD11dGYtOCdcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYm9keTogcXVlcnkuam9pbignJicpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIHJlcy50ZXh0KCk7XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gcGFyc2VSZXNwb25zZShkYXRhKSB7XHJcbiAgICAgICAgbGV0IGpzb247XHJcbiAgICAgICAganNvbiA9IEpTT041LnBhcnNlKGRhdGEpO1xyXG5cclxuICAgICAgICBpZiAoanNvbi5oYXNPd25Qcm9wZXJ0eSgnb2JqJykpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHBhcnNlT2JqZWN0KGpzb24ub2JqKTtcclxuICAgICAgICB9IGVsc2UgaWYgKGpzb24uaGFzT3duUHJvcGVydHkoJ29ianMnKSkge1xyXG4gICAgICAgICAgICByZXR1cm4ganNvbi5vYmpzLm1hcChwYXJzZU9iamVjdCk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChqc29uLmhhc093blByb3BlcnR5KCdkYXRhJykgfHwganNvbi5zdGF0dXMgIT0gMCkge1xyXG4gICAgICAgICAgICByZXR1cm4ganNvbjtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGpzb24pO1xyXG4gICAgICAgICAgICBpZiAoanNvbi5zdGF0dXMgPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignWW91ciBzZXNzaW9uIGhhcyBleHBpcmVkLiBQbGVhc2UgZW50ZXIgeW91ciBjcmVkZW50aWFscyBhZ2Fpbi4nKTtcclxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignWW91ciBzZXNzaW9uIGhhcyBleHBpcmVkLiBQbGVhc2UgZW50ZXIgeW91ciBjcmVkZW50aWFscyBhZ2Fpbi4nKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1VuYWJsZSB0byBwYXJzZSBkYXRhOiBubyBrZXlzIFtvYmpdIG9yIFtvYmpzXSBmb3VuZC4gU2VlIGNvbnNvbGUgZm9yIGRldGFpbHMuJyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIHBhcnNlT2JqZWN0KG9iaikge1xyXG4gICAgICAgICAgICBjb25zdCBwYXJzZWQgPSB7fTtcclxuICAgICAgICAgICAgZm9yIChsZXQgcHJvcCBpbiBvYmopIHtcclxuICAgICAgICAgICAgICAgIHBhcnNlZFtwcm9wXSA9IG9ialtwcm9wXS52YWx1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gcGFyc2VkO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRFeHRyYUNvdXJzZUluZm8oaWQpIHtcclxuICAgICAgICBjb25zdCBib2R5ID0ge1xyXG4gICAgICAgICAgICBpbnZva2U6IGBUYkNvdXJzZUdyb3Vwc01hbmFnZXIuZ2V0QnlDb3Vyc2VHcm91cElkKCR7aWR9KWAsXHJcbiAgICAgICAgfTtcclxuICAgICAgICByZXR1cm4gcGFyc2VSZXNwb25zZShhd2FpdCBwb3N0Rm9ybShob3N0LCBib2R5KSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRDdXJyZW50Q291cnNlcygpIHtcclxuICAgICAgICBjb25zdCBib2R5ID0ge1xyXG4gICAgICAgICAgICBpbnZva2U6ICdWaWV3Q291cnNlR3JvdXBMaXN0TWFuYWdlci5jdXN0b21HZXRCeVByb3ZpZGVySWRBbmRDb3Vyc2VTdGF0dXNJZCgyOTI5LDIpJyxcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKGF3YWl0IHBvc3RGb3JtKGhvc3QsIGJvZHkpKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXROYXZldENsb3NlZENvdXJzZXMoKSB7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHtcclxuICAgICAgICAgICAgaW52b2tlOiAnVmlld0ZpbmlzaGVkQ291cnNlR3JvdXBMaXN0TWFuYWdlci5jdXN0b21HZXRCeVByb3ZpZGVySWRBbmRDb3Vyc2VTdGF0dXNJZE5vdEFyY2hpdmVkKDI5MjkpJyxcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKGF3YWl0IHBvc3RGb3JtKGhvc3QsIGJvZHkpKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXROYXZldEFyY2hpdmVkQ291cnNlcygpIHtcclxuICAgICAgICBjb25zdCBib2R5ID0ge1xyXG4gICAgICAgICAgICBpbnZva2U6ICdWaWV3RmluaXNoZWRDb3Vyc2VHcm91cExpc3RNYW5hZ2VyLmN1c3RvbUdldEJ5UHJvdmlkZXJJZEFuZENvdXJzZVN0YXR1c0lkQXJjaGl2ZWQoMjkyOSknLFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UoYXdhaXQgcG9zdEZvcm0oaG9zdCwgYm9keSkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldE5hdmV0Q291cnNlSW5mbyhpZCwgdHlwZSA9ICdjdXJyZW50Jykge1xyXG4gICAgICAgIGxldCBleHRyYUluZm8gPSBnZXRFeHRyYUNvdXJzZUluZm8oaWQpO1xyXG4gICAgICAgIGxldCBjb3Vyc2VMaXN0ID0gW107XHJcbiAgICAgICAgc3dpdGNoICh0eXBlKSB7XHJcbiAgICAgICAgICAgIGNhc2UgJ2N1cnJlbnQnOlxyXG4gICAgICAgICAgICAgICAgY291cnNlTGlzdCA9IGdldE5hdmV0Q3VycmVudENvdXJzZXMoKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICdjb25jbHVkZWQnOlxyXG4gICAgICAgICAgICAgICAgY291cnNlTGlzdCA9IGdldE5hdmV0Q2xvc2VkQ291cnNlcygpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgJ2FyY2hpdmUnOlxyXG4gICAgICAgICAgICAgICAgY291cnNlTGlzdCA9IGdldE5hdmV0QXJjaGl2ZWRDb3Vyc2VzKCk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICAgICAgW2V4dHJhSW5mbywgY291cnNlTGlzdF0gPSBhd2FpdCBQcm9taXNlLmFsbChbZXh0cmFJbmZvLCBjb3Vyc2VMaXN0XSk7XHJcbiAgICAgICAgY29uc3Qgc2VsZWN0ZWQgPSBjb3Vyc2VMaXN0LmZpbmQoYyA9PiBjLmlkID09IGlkKTtcclxuICAgICAgICBzZWxlY3RlZC5fZXh0cmEgPSBleHRyYUluZm9bMF07XHJcblxyXG4gICAgICAgIHJldHVybiBzZWxlY3RlZDtcclxuICAgIH1cclxuXHJcbiAgICAvKiBSZXBsYWNlZCwgYmVjYXVzZSBpdCBkb2Vzbid0IHByb3ZpZGUgdGhlIG5lY2Vzc2FyeSBpbmZvcm1hdGlvbiAqL1xyXG4gICAgLypcclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldE5hdmV0Q291cnNlSW5mbyhpZCkge1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSB7XHJcbiAgICAgICAgICAgIGludm9rZTogYFZpZXdDb3Vyc2VJbmZvTWFuYWdlci5nZXRCeUlkKCR7aWR9KWBcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKGF3YWl0IHBvc3RGb3JtKGhvc3QsIGJvZHkpKTtcclxuICAgIH1cclxuICAgICovXHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRTdHVkZW50cyhpZCkge1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSB7XHJcbiAgICAgICAgICAgIGludm9rZTogYFZpZXdDbGllbnRDb3Vyc2VzTWFuYWdlci5nZXRCeUNvdXJzZUdyb3VwSWQoJHtpZH0pYFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgcmV0dXJuIHBhcnNlUmVzcG9uc2UoYXdhaXQgcG9zdEZvcm0oaG9zdCwgYm9keSkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldE5hdmV0U3R1ZGVudEluZm8oY2xpZW50SWQpIHtcclxuICAgICAgICBjb25zdCBib2R5ID0ge1xyXG4gICAgICAgICAgICBpbnZva2U6IGBUYkNsaWVudHNNYW5hZ2VyLmdldEJ5SWQoJHtjbGllbnRJZH0pYCxcclxuICAgICAgICAgICAgaWQ6IGNsaWVudElkXHJcbiAgICAgICAgfTtcclxuICAgICAgICByZXR1cm4gcGFyc2VSZXNwb25zZShhd2FpdCBwb3N0Rm9ybShob3N0LCBib2R5KSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRFeGlzdGluZ0ZpbGVzKGNvdXJzZUlkLCBpZCkge1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSB7XHJcbiAgICAgICAgICAgIGludm9rZTogYFRiQ2xpZW50c1JlcXVpcmVkRG9jdW1lbnRzTWFuYWdlci5jdXN0b21HZXRWYWxpZEJ5Q291cnNlR3JvdXBBbmRDbGllbnQoJHtjb3Vyc2VJZH0sJHtpZH0pYCxcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKGF3YWl0IHBvc3RGb3JtKGhvc3QsIGJvZHkpKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB1cGxvYWRGaWxlKGZvcm1EYXRhKSB7XHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZmV0Y2goaG9zdCwge1xyXG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICAgICAgYm9keTogZm9ybURhdGFcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3Qgb3V0cHV0ID0gYXdhaXQgcmVzdWx0LnRleHQoKTtcclxuICAgICAgICBpZiAob3V0cHV0LnNlYXJjaCgvc3RhdHVzOlxcczAvKSAhPSAtMSkge1xyXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1lvdXIgc2Vzc2lvbiBoYXMgZXhwaXJlZC4gUGxlYXNlIGVudGVyIHlvdXIgY3JlZGVudGlhbHMgYWdhaW4uJyk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIG91dHB1dDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gdXBsb2FkTWVkaWNhbChjb3Vyc2VJZCwgaWQsIGZpbGVEZXNjcmlwdG9yKSB7XHJcbiAgICAgICAgbGV0IGJsb2I7XHJcbiAgICAgICAgbGV0IGZpbGVuYW1lO1xyXG4gICAgICAgIGlmIChmaWxlRGVzY3JpcHRvci5maWxlVXJsICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgYmxvYiA9IGF3YWl0IChhd2FpdCBmZXRjaChmaWxlRGVzY3JpcHRvci5maWxlVXJsKSkuYmxvYigpO1xyXG4gICAgICAgICAgICBmaWxlbmFtZSA9IGZpbGVEZXNjcmlwdG9yLm5hbWU7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgYmxvYiA9IGZpbGVEZXNjcmlwdG9yLmZpbGU7XHJcbiAgICAgICAgICAgIGZpbGVuYW1lID0gZmlsZURlc2NyaXB0b3IuZmlsZS5uYW1lO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xyXG5cclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2lkJywgbnVsbCk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnRfY291cnNlX2dyb3VwX2lkJywgY291cnNlSWQpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaXNfdmFsaWQnLCB0cnVlKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ29pZF9maWxlX2FjdGlvbicsICd1cGxvYWQnKTtcclxuXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdvaWRfZmlsZScsIGJsb2IsIGZpbGVuYW1lKTtcclxuXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnZva2UnLCAnVGJDbGllbnRzUmVxdWlyZWREb2N1bWVudHNNYW5hZ2VyLmNyZWF0ZU9iamVjdCgpJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdhcHBsaWNhdGlvbicsICdBSkFYRGF0YVByb3ZpZGVyJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdwcm90b2NvbCcsICdkYXRhSUZyYW1lJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdudWxsJywgJycpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaW50X2NvZGVfY291cnNlX2dyb3VwX3JlcXVpcmVkX2RvY3VtZW50c190eXBlX2lkJywgMSk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnRfY2xpZW50X2lkJywgaWQpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndmNfZGVzY2lwdGlvbicsICfQvNC10LTQuNGG0LjQvdGB0LrQviAoYXV0byknKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2R0X2RvY3VtZW50X2RhdGUnLCAnJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCd2Y19kb2N1bWVudF9yZWdfbm8nLCAnJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCd2Y19kb2N1bWVudF9wcm5fbm8nLCAnJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdkdF9kb2N1bWVudF9vZmZpY2lhbF9kYXRlJywgJycpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnYm9vbF9iZWZvcmVfZGF0ZScsIGZhbHNlKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludF9jb2RlX2V4dF9yZWdpc3Rlcl9pZCcsIG51bGwpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndGl0bGUnLCAnPGRpdiBjbGFzcz1cXCduYXBvby10aXRsZS1kYXJrXFwnPtCc0LXQtNC40YbQuNC90YHQutC+INGB0LLQuNC00LXRgtC10LvRgdGC0LLQvjo8L2Rpdj4nKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2FzeW5jX2lmcmFtZV9pZCcsICdhc3luY19pZnJhbWVfMzE1MicpO1xyXG5cclxuICAgICAgICByZXR1cm4gdXBsb2FkRmlsZShmb3JtRGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gdXBsb2FkRGlwbG9tYShjb3Vyc2VJZCwgaWQsIGZpbGVEZXNjcmlwdG9yLCByZWdfbm8sIHBybl9ubywgZG9jX2RhdGUpIHtcclxuICAgICAgICBsZXQgYmxvYjtcclxuICAgICAgICBsZXQgZmlsZW5hbWU7XHJcbiAgICAgICAgaWYgKGZpbGVEZXNjcmlwdG9yLmZpbGVVcmwgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICBibG9iID0gYXdhaXQgKGF3YWl0IGZldGNoKGZpbGVEZXNjcmlwdG9yLmZpbGVVcmwpKS5ibG9iKCk7XHJcbiAgICAgICAgICAgIGZpbGVuYW1lID0gZmlsZURlc2NyaXB0b3IubmFtZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBibG9iID0gZmlsZURlc2NyaXB0b3IuZmlsZTtcclxuICAgICAgICAgICAgZmlsZW5hbWUgPSBmaWxlRGVzY3JpcHRvci5maWxlLm5hbWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IGZvcm1EYXRhID0gbmV3IEZvcm1EYXRhKCk7XHJcblxyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaWQnLCBudWxsKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludF9jb3Vyc2VfZ3JvdXBfaWQnLCBjb3Vyc2VJZCk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpc192YWxpZCcsIHRydWUpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaW50X2NvZGVfZWR1Y2F0aW9uX2lkJywgMzEpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnMzQxLXRleHQnLCAn0LfQsNCy0YrRgNGI0LXQvdC+INGB0YDQtdC00L3QviDQvtCx0YDQsNC30L7QstCw0L3QuNC1ICjQuNC70Lgg0L/Qvi3QstC40YHQvtC60L4pJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCd2Y19kb2N1bWVudF9yZWdfbm8nLCByZWdfbm8pO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndmNfZG9jdW1lbnRfcHJuX25vJywgcHJuX25vKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ29pZF9maWxlX2FjdGlvbicsICd1cGxvYWQnKTtcclxuXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdvaWRfZmlsZScsIGJsb2IsIGZpbGVuYW1lKTtcclxuXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnZva2UnLCAnVGJDbGllbnRzUmVxdWlyZWREb2N1bWVudHNNYW5hZ2VyLmNyZWF0ZU9iamVjdCgpJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdhcHBsaWNhdGlvbicsICdBSkFYRGF0YVByb3ZpZGVyJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdwcm90b2NvbCcsICdkYXRhSUZyYW1lJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdudWxsJywgJycpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaW50X2NsaWVudF9pZCcsIGlkKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX2Rlc2NpcHRpb24nLCAn0LTQuNC/0LvQvtC80LAgKGF1dG8pJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdkdF9kb2N1bWVudF9kYXRlJywgJycpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnZHRfZG9jdW1lbnRfb2ZmaWNpYWxfZGF0ZScsIGRvY19kYXRlKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2Jvb2xfYmVmb3JlX2RhdGUnLCBmYWxzZSk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnRfY29kZV9leHRfcmVnaXN0ZXJfaWQnLCBudWxsKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3RpdGxlJywgJzxkaXYgY2xhc3M9XFwnbmFwb28tdGl0bGUtZGFya1xcJz7QktGF0L7QtNGP0YnQviDQvNC40L3QuNC80LDQu9C90L4g0L7QsdGA0LDQt9C+0LLQsNGC0LXQu9C90L4g0YDQsNCy0L3QuNGJ0LU6PC9kaXY+Jyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdyZXNwSW5mbycsICcnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2V4dHJhSW5mbycsICcnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2NoZWNrLWluLWVkdS1idXR0b24nLCAn0J/RgNC+0LLQtdGA0Lgg0LIg0YDQtdCz0LjRgdGC0YDQuNGC0LUnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2FzeW5jX2lmcmFtZV9pZCcsICdhc3luY19pZnJhbWVfMzc0Jyk7XHJcblxyXG4gICAgICAgIHJldHVybiB1cGxvYWRGaWxlKGZvcm1EYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBvcGVuTmF2ZXRGaWxlKGlkKSB7XHJcbiAgICAgICAgY29uc3QgdXJsID0gYCR7aG9zdH0/YXBwbGljYXRpb249QUpBWERhdGFQcm92aWRlciZpbnZva2U9VGJDbGllbnRzUmVxdWlyZWREb2N1bWVudHNNYW5hZ2VyLmN1c3RvbURvd25sb2FkRmlsZSgke2lkfSxcIm9pZF9maWxlXCIpYDtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCh1cmwpO1xyXG5cclxuICAgICAgICBjb25zdCBibG9iID0gYXdhaXQgcmVzLmJsb2IoKTtcclxuICAgICAgICBjb25zdCBzZXJpYWxpemVkQmxvYiA9IG5ldyBVaW50OEFycmF5KGF3YWl0IGJsb2IuYXJyYXlCdWZmZXIoKSk7XHJcbiAgXHJcbiAgICAgICAgbGV0IGJsb2JEYXRhID0ge1xyXG4gICAgICAgICAgICB0eXBlOiBibG9iLnR5cGUsXHJcbiAgICAgICAgICAgIGJ1ZmZlcjogQXJyYXkuZnJvbShzZXJpYWxpemVkQmxvYilcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICByZXR1cm4gYmxvYkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZGVsZXRlTmF2ZXRGaWxlKGlkKSB7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHtcclxuICAgICAgICAgICAgaW52b2tlOiBgVGJDbGllbnRzUmVxdWlyZWREb2N1bWVudHNNYW5hZ2VyLmN1c3RvbVNldFRvRmFsc2UoJHtpZH0pYCxcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKGF3YWl0IHBvc3RGb3JtKGhvc3QsIGJvZHkpKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyogRXhwZXJpbWVudGFsICovXHJcbiAgICBhc3luYyBmdW5jdGlvbiBuYXZldExvZ2luKHVzZXJuYW1lLCBwYXNzd29yZCkge1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSB7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlOiAnY2xpZW50JyxcclxuICAgICAgICAgICAgcmVxdWVzdDogJ2xvZ2luJyxcclxuICAgICAgICAgICAgdXNlcm5hbWUsXHJcbiAgICAgICAgICAgIHBhc3N3b3JkXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgY29uc3QgaGVhZGVyID0gZW5jb2RlVVJJQ29tcG9uZW50KEpTT04uc3RyaW5naWZ5KGJvZHkpKTtcclxuXHJcbiAgICAgICAgY29uc3QgdXJsID0gJy9yZXNwb25zZSc7XHJcblxyXG4gICAgICAgIGxldCByZXF1ZXN0ID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XHJcbiAgICAgICAgcmVxdWVzdC5vbnJlYWR5c3RhdGVjaGFuZ2UgPSAoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChyZXF1ZXN0LnJlYWR5U3RhdGUgPT0gNCAmJiAocmVxdWVzdC5zdGF0dXMgPT0gMjAwIHx8IHdpbmRvdy5sb2NhdGlvbi5ocmVmLmluZGV4T2YoJ2h0dHAnKSA9PSAtMSkpIHtcclxuICAgICAgICAgICAgICAgIGxldCB1ZGF0ID0gSlNPTi5wYXJzZShyZXF1ZXN0LnJlc3BvbnNlVGV4dCk7XHJcbiAgICAgICAgICAgICAgICBpZiAodWRhdC5zdGF0dXMgPT0gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gJy8nO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Vycm9yOiAnICsgdWRhdC5lcnJvcl9jb2RlKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHJlcXVlc3QgPSBudWxsO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgY29uc3QgY2FjaGUgPSAnPycgKyBuZXcgRGF0ZSgpLmdldFRpbWUoKTtcclxuICAgICAgICByZXF1ZXN0Lm9wZW4oJ0dFVCcsIHVybCArIGNhY2hlLCB0cnVlKTtcclxuICAgICAgICByZXF1ZXN0LnNldFJlcXVlc3RIZWFkZXIoJ0FDQ1NTQ1RSTCcsIGhlYWRlcik7XHJcbiAgICAgICAgcmVxdWVzdC5zZW5kKG51bGwpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEdyYWR1YXRlSW5mbyhpZCkge1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSB7XHJcbiAgICAgICAgICAgIGludm9rZTogYFJlZkNsaWVudHNDb3Vyc2VzTWFuYWdlci5nZXRCeUlkKCR7aWR9KWAsXHJcbiAgICAgICAgfTtcclxuICAgICAgICByZXR1cm4gcGFyc2VSZXNwb25zZShhd2FpdCBwb3N0Rm9ybShob3N0LCBib2R5KSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRDZXJ0aWZpY2F0ZShpZCkge1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSB7XHJcbiAgICAgICAgICAgIGludm9rZTogYFZpZXdDbGllbnRzQ291cnNlc0RvY3VtZW50c01hbmFnZXIuZ2V0QnlDbGllbnRDb3Vyc2VzSWQoJHtpZH0pYCxcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKGF3YWl0IHBvc3RGb3JtKGhvc3QsIGJvZHkpKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBvcGVuTmF2ZXRDZXJ0aWZpY2F0ZShpZCwgcGFnZSkge1xyXG4gICAgICAgIGNvbnN0IHVybCA9IGAke2hvc3R9P2FwcGxpY2F0aW9uPUFKQVhEYXRhUHJvdmlkZXImaW52b2tlPVRiQ2xpZW50c0NvdXJzZXNEb2N1bWVudHNNYW5hZ2VyLmN1c3RvbURvd25sb2FkRmlsZSgke2lkfSwgXCJkb2N1bWVudF8ke3BhZ2V9X2ZpbGVcIilgO1xyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKHVybCk7XHJcbiAgICAgICAgY29uc3QgYmxvYiA9IGF3YWl0IHJlcy5ibG9iKCk7XHJcbiAgICAgICAgaWYgKGJsb2IudHlwZSA9PSAndGV4dC9qYXZhc2NyaXB0Jykge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdZb3VyIHNlc3Npb24gaGFzIGV4cGlyZWQuIFBsZWFzZSBlbnRlciB5b3VyIGNyZWRlbnRpYWxzIGFnYWluLicpO1xyXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1lvdXIgc2Vzc2lvbiBoYXMgZXhwaXJlZC4gUGxlYXNlIGVudGVyIHlvdXIgY3JlZGVudGlhbHMgYWdhaW4uJyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCBzZXJpYWxpemVkQmxvYiA9IG5ldyBVaW50OEFycmF5KGF3YWl0IGJsb2IuYXJyYXlCdWZmZXIoKSk7XHJcbiAgXHJcbiAgICAgICAgbGV0IGJsb2JEYXRhID0ge1xyXG4gICAgICAgICAgICB0eXBlOiBibG9iLnR5cGUsXHJcbiAgICAgICAgICAgIGJ1ZmZlcjogQXJyYXkuZnJvbShzZXJpYWxpemVkQmxvYilcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICByZXR1cm4gYmxvYkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gdXBsb2FkTmF2ZXRDZXJ0aWZpY2F0ZShtZXRhLCBmaWxlRGVzY3JpcHRvcnMpIHtcclxuICAgICAgICBjb25zdCBmaWxlcyA9IGF3YWl0IFByb21pc2UuYWxsKGZpbGVEZXNjcmlwdG9ycy5tYXAoYXN5bmMgZGVzY3JpcHRvciA9PiB7XHJcbiAgICAgICAgICAgIGlmIChkZXNjcmlwdG9yID09PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICAgICAgfSBlbHNlIGlmIChkZXNjcmlwdG9yLmZpbGVVcmwgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgICAgICBibG9iOiBhd2FpdCAoYXdhaXQgZmV0Y2goZGVzY3JpcHRvci5maWxlVXJsKSkuYmxvYigpLFxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGVuYW1lOiBkZXNjcmlwdG9yLm5hbWVcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGJsb2I6IGRlc2NyaXB0b3IuZmlsZSxcclxuICAgICAgICAgICAgICAgICAgICBmaWxlbmFtZTogZGVzY3JpcHRvci5maWxlLm5hbWVcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KSk7XHJcblxyXG5cclxuICAgICAgICBjb25zdCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xyXG5cclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2lkJywgbWV0YS5pZCk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnRfY2xpZW50c19jb3Vyc2VzX2lkJywgbWV0YS5pbnRfY2xpZW50c19jb3Vyc2VzX2lkKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludF9kb2N1bWVudF90eXBlX2lkJywgbWV0YS5pbnRfZG9jdW1lbnRfdHlwZV9pZCk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCc2MDgtdGV4dCcsICfQo9C00L7RgdGC0L7QstC10YDQtdC90LjQtSDQt9CwINC/0YDQvtGE0LXRgdC40L7QvdCw0LvQvdC+INC+0LHRg9GH0LXQvdC40LUnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludF9jb3Vyc2VfZmluaXNoZWRfeWVhcicsIG1ldGEuaW50X2NvdXJzZV9maW5pc2hlZF95ZWFyKTsgLy8gbmVlZCB0aGlzIGFkZGVkXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCd2Y19kb2N1bWVudF9wcm5fbm8nLCAnJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCc2MTItdGV4dCcsICcnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX29yaWdpbmFsX3Bybl9ubycsIG1ldGEudmNfZG9jdW1lbnRfcHJuX25vKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX2RvY3VtZW50X3JlZ19ubycsIG1ldGEudmNfZG9jdW1lbnRfcmVnX25vKTsgLy8gbmVlZCB0aGlzIGFkZGVkXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCd2Y19kb2N1bWVudF9wcm90JywgbWV0YS52Y19kb2N1bWVudF9wcm90KTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ251bV90aGVvcnlfcmVzdWx0JywgbWV0YS5udW1fdGhlb3J5X3Jlc3VsdCk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdudW1fcHJhY3RpY2VfcmVzdWx0JywgbWV0YS5udW1fcHJhY3RpY2VfcmVzdWx0KTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX3F1YWxpZmljYXRpb25fbmFtZScsIG1ldGEudmNfcXVhbGlmaWNhdGlvbl9uYW1lKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX3F1YWxpZmljYXRpb2pfbGV2ZWwnLCBtZXRhLnZjX3F1YWxpZmljYXRpb2pfbGV2ZWwpO1xyXG5cclxuICAgICAgICBpZiAoZmlsZXNbMF0gIT09IG51bGwpIHtcclxuICAgICAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdkb2N1bWVudF8xX2ZpbGVfYWN0aW9uJywgJ3VwbG9hZCcpO1xyXG4gICAgICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2RvY3VtZW50XzFfZmlsZScsIGZpbGVzWzBdLmJsb2IsIGZpbGVzWzBdLmZpbGVuYW1lKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2RvY3VtZW50XzFfZmlsZV9hY3Rpb24nLCAnJyk7XHJcbiAgICAgICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnZG9jdW1lbnRfMV9maWxlJywgbmV3IEJsb2IoWycnXSksICcnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChmaWxlc1sxXSAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2RvY3VtZW50XzJfZmlsZV9hY3Rpb24nLCAndXBsb2FkJyk7XHJcbiAgICAgICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnZG9jdW1lbnRfMl9maWxlJywgZmlsZXNbMV0uYmxvYiwgZmlsZXNbMV0uZmlsZW5hbWUpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnZG9jdW1lbnRfMl9maWxlX2FjdGlvbicsICcnKTtcclxuICAgICAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdkb2N1bWVudF8yX2ZpbGUnLCBuZXcgQmxvYihbJyddKSwgJycpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnZva2UnLCBgVGJDbGllbnRzQ291cnNlc0RvY3VtZW50c01hbmFnZXIudXBkYXRlT2JqZWN0KCR7bWV0YS5pZH0pYCk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdhcHBsaWNhdGlvbicsICdBSkFYRGF0YVByb3ZpZGVyJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdwcm90b2NvbCcsICdkYXRhSUZyYW1lJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdkdF9kb2N1bWVudF9kYXRlJywgbWV0YS5kdF9kb2N1bWVudF9kYXRlKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX2RvY3VtZW50X3R5cGVfbmFtZScsIG1ldGEudmNfZG9jdW1lbnRfdHlwZV9uYW1lKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludF9kb2N1bWVudF9zdGF0dXMnLCBtZXRhLmludF9kb2N1bWVudF9zdGF0dXMpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnYm9vbF93aXRoX25vdGUnLCBtZXRhLmJvb2xfd2l0aF9ub3RlKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2FzeW5jX2lmcmFtZV9pZCcsICdhc3luY19pZnJhbWVfNjM5Jyk7XHJcblxyXG5cclxuICAgICAgICByZXR1cm4gdXBsb2FkRmlsZShmb3JtRGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gdXBkYXRlTmF2ZXRTdHVkZW50KGlkLCBzdHVkZW50KSB7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IE9iamVjdC5hc3NpZ24oe30sIHN0dWRlbnQsIHtcclxuICAgICAgICAgICAgaW52b2tlOiBgUmVmQ2xpZW50c0NvdXJzZXNNYW5hZ2VyLnVwZGF0ZU9iamVjdCgke2lkfSlgLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKGF3YWl0IHBvc3RGb3JtKGhvc3QsIGJvZHkpKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBjcmVhdGVEb2N1bWVudChzdHVkZW50SWQsIGNsaWVudElkLCBkYXRhKSB7XHJcbiAgICAgICAgY29uc3QgZm9ybURhdGEgPSBuZXcgRm9ybURhdGEoKTtcclxuICAgICAgICBcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2lkJywgbnVsbCk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnRfY2xpZW50c19jb3Vyc2VzX2lkJywgbnVsbCk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnRfZG9jdW1lbnRfdHlwZV9pZCcsICcnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJzMwNC10ZXh0JywgJ9Cj0LTQvtGB0YLQvtCy0LXRgNC10L3QuNC1INC30LAg0L/RgNC+0YTQtdGB0LjQvtC90LDQu9C90L4g0L7QsdGD0YfQtdC90LjQtScpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnaW50X2NvdXJzZV9maW5pc2hlZF95ZWFyJywgZGF0YS5pbnRfY291cnNlX2ZpbmlzaGVkX3llYXIpOyAvLyBuZWVkIHRoaXMgYWRkZWRcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX2RvY3VtZW50X3Bybl9ubycsICcnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJzMwOC10ZXh0JywgJycpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndmNfZG9jdW1lbnRfcmVnX25vJywgZGF0YS52Y19kb2N1bWVudF9yZWdfbm8pOyAvLyBuZWVkIHRoaXMgYWRkZWRcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX2RvY3VtZW50X3Byb3QnLCAnJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdudW1fdGhlb3J5X3Jlc3VsdCcsIDApO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnbnVtX3ByYWN0aWNlX3Jlc3VsdCcsIDApO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndmNfcXVhbGlmaWNhdGlvbl9uYW1lJywgJycpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndmNfcXVhbGlmaWNhdGlval9sZXZlbCcsICcnKTtcclxuXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdkb2N1bWVudF8xX2ZpbGVfYWN0aW9uJywgJycpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnZG9jdW1lbnRfMV9maWxlJywgbmV3IEJsb2IoWycnXSksICcnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2RvY3VtZW50XzJfZmlsZV9hY3Rpb24nLCAnJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdkb2N1bWVudF8yX2ZpbGUnLCBuZXcgQmxvYihbJyddKSwgJycpO1xyXG5cclxuICAgICAgICBcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludm9rZScsICdDdXN0b21FdmVudHNNYW5hZ2VyLmN1c3RvbVRiQ2xpZW50c0NvdXJzZXNEb2N1bWVudHMoMSknKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2FwcGxpY2F0aW9uJywgJ0FKQVhEYXRhUHJvdmlkZXInKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3Byb3RvY29sJywgJ2RhdGFJRnJhbWUnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludF9wcm92aWRlcl9pZCcsIDI5MjkpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgncmVmX2NsaWVudHNfY291cnNlc19pZF90Jywgc3R1ZGVudElkKTsgLy9kYXRhLmlkXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCd0Yl9jbGllbnRzX2lkX3QnLCBjbGllbnRJZCk7IC8vZGF0YS5pbnRfY2xpZW50X2lkXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdkdF9kb2N1bWVudF9kYXRlX3QnLCAnJyk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnRfY2xpZW50X2NvdXJzZV9pZF90Jywgc3R1ZGVudElkKTsgLy9kYXRhLmlkXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbnRfZG9jdW1lbnRfdHlwZV9pZF90JywgMik7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCd2Y19kb2N1bWVudF9wcm5fbm9fdCcsICcnKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZjX2RvY3VtZW50X3JlZ19ub190JywgZGF0YS52Y19kb2N1bWVudF9yZWdfbm8pOyAvLyBuZWVkIHRoaXMgYWRkZWQsIHNhbWUgYXMgYWJvdmVcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ludF9kb2N1bWVudF9zdGF0dXMnLCAwKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2FzeW5jX2lmcmFtZV9pZCcsICdhc3luY19pZnJhbWVfMzI5Jyk7XHJcblxyXG5cclxuICAgICAgICByZXR1cm4gdXBsb2FkRmlsZShmb3JtRGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBnZXROYXZldEN1cnJlbnRDb3Vyc2VzLFxyXG4gICAgICAgIGdldE5hdmV0Q2xvc2VkQ291cnNlcyxcclxuICAgICAgICBnZXROYXZldEFyY2hpdmVkQ291cnNlcyxcclxuICAgICAgICBnZXROYXZldENvdXJzZUluZm8sXHJcbiAgICAgICAgZ2V0TmF2ZXRTdHVkZW50cyxcclxuICAgICAgICBnZXROYXZldFN0dWRlbnRJbmZvLFxyXG4gICAgICAgIGdldE5hdmV0RXhpc3RpbmdGaWxlcyxcclxuICAgICAgICB1cGxvYWRNZWRpY2FsLFxyXG4gICAgICAgIHVwbG9hZERpcGxvbWEsXHJcbiAgICAgICAgb3Blbk5hdmV0RmlsZSxcclxuICAgICAgICBkZWxldGVOYXZldEZpbGUsXHJcbiAgICAgICAgZ2V0R3JhZHVhdGVJbmZvLFxyXG4gICAgICAgIGdldE5hdmV0Q2VydGlmaWNhdGUsXHJcbiAgICAgICAgb3Blbk5hdmV0Q2VydGlmaWNhdGUsXHJcbiAgICAgICAgdXBsb2FkTmF2ZXRDZXJ0aWZpY2F0ZSxcclxuICAgICAgICB1cGRhdGVOYXZldFN0dWRlbnQsXHJcbiAgICAgICAgY3JlYXRlRG9jdW1lbnQsXHJcbiAgICAgICAgZ2V0RXh0cmFDb3Vyc2VJbmZvXHJcbiAgICB9O1xyXG59IiwiaW1wb3J0IHsgQ29udGVudFR5cGUgfSBmcm9tIFwiLi4vLi4vdXRpbC9jb250ZW50VHlwZXMuanNcIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCwgZ2V0LCBpbnRlcm9wUGxhdGZvcm1Ib3N0LCBpbnRlcm9wQWRtaW5BbHBoYUp1ZGdlSG9zdCB9KSB7XHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRDb250ZXN0Q29tcGV0ZVJlc3VsdHMoY29udGVzdElkKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gYCR7aW50ZXJvcEFkbWluQWxwaGFKdWRnZUhvc3QoKX0vYXBpL2NvbnRlc3RzL0V4cG9ydFJlc3VsdHNgO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSB7XHJcbiAgICAgICAgICAgIGlkOiBjb250ZXN0SWQsXHJcbiAgICAgICAgICAgIHR5cGU6IDAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGxldCBibG9iID0gYXdhaXQgcG9zdCh1cmksIGJvZHksIENvbnRlbnRUeXBlLkFwcGxpY2F0aW9uSnNvbiwgdHJ1ZSk7XHJcbiAgICAgICAgY29uc3Qgc2VyaWFsaXplZEJsb2IgPSBuZXcgVWludDhBcnJheShhd2FpdCBibG9iLmFycmF5QnVmZmVyKCkpO1xyXG4gICAgICAgIGNvbnN0IGJsb2JEYXRhID0ge1xyXG4gICAgICAgICAgICB0eXBlOiBibG9iLnR5cGUsXHJcbiAgICAgICAgICAgIGZpbGVuYW1lOiBibG9iLmZpbGVuYW1lLFxyXG4gICAgICAgICAgICBidWZmZXI6IEFycmF5LmZyb20oc2VyaWFsaXplZEJsb2IpXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgcmV0dXJuIGJsb2JEYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldENvbnRlc3RQcmFjdGljZVJlc3VsdHMoY29udGVzdElkKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gYCR7aW50ZXJvcEFkbWluQWxwaGFKdWRnZUhvc3QoKX0vYXBpL2NvbnRlc3RzL0V4cG9ydFJlc3VsdHNgO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSB7XHJcbiAgICAgICAgICAgIGlkOiBjb250ZXN0SWQsXHJcbiAgICAgICAgICAgIHR5cGU6IDEgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgbGV0IGJsb2IgPSBhd2FpdCBwb3N0KHVyaSwgYm9keSwgQ29udGVudFR5cGUuQXBwbGljYXRpb25Kc29uLCB0cnVlKTtcclxuICAgICAgICBjb25zdCBzZXJpYWxpemVkQmxvYiA9IG5ldyBVaW50OEFycmF5KGF3YWl0IGJsb2IuYXJyYXlCdWZmZXIoKSk7XHJcbiAgICAgICAgY29uc3QgYmxvYkRhdGEgPSB7XHJcbiAgICAgICAgICAgIHR5cGU6IGJsb2IudHlwZSxcclxuICAgICAgICAgICAgZmlsZW5hbWU6IGJsb2IuZmlsZW5hbWUsXHJcbiAgICAgICAgICAgIGJ1ZmZlcjogQXJyYXkuZnJvbShzZXJpYWxpemVkQmxvYilcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICByZXR1cm4gYmxvYkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBnZXRDb250ZXN0Q29tcGV0ZVJlc3VsdHMsXHJcbiAgICAgICAgZ2V0Q29udGVzdFByYWN0aWNlUmVzdWx0c1xyXG4gICAgfTtcclxufSIsImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCB9KSB7XHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRNb2R1bGVzSW5Qcm9mZXNzaW9uKHByb2Zlc3Npb25JZCkge1xyXG4gICAgICAgIGNvbnN0IHVybCA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChpbnRlcm9wQXBwSWQoKSA9PT0gJ3NvZnR1bmkuYmcnKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3Byb2Zlc3Npb25zL2xldmVsZ3JvdXBzaW5wcm9mZXNzaW9uaW5zdGFuY2VzL3JlYWQ/Zm9yZWlnbktleUlkPSR7cHJvZmVzc2lvbklkfWApO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGludGVyb3BIb3N0KGBBZG1pbmlzdHJhdGlvbl9Qcm9mZXNzaW9ucy9Db3Vyc2VHcm91cHNJblByb2Zlc3Npb25JbnN0YW5jZXMvUmVhZD9mb3JlaWduS2V5SWQ9JHtwcm9mZXNzaW9uSWR9YCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KSgpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVybCwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0TW9kdWxlcygpIHtcclxuICAgICAgICBjb25zdCB1cmwgPSAgaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX0xldmVscy9sZXZlbHMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJsLCBib2R5KSkuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRJbnN0YW5jZXNJbk1vZHVsZShtb2R1bGVJZCkge1xyXG4gICAgICAgIGNvbnN0IHVybCA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChpbnRlcm9wQXBwSWQoKSA9PT0gJ3NvZnR1bmkuYmcnKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX2xldmVscy9sZXZlbGluc3RhbmNlcy9yZWFkP2ltcG9ydExldmVsSWQ9JHttb2R1bGVJZH0mbGV2ZWxJZD0ke21vZHVsZUlkfWApO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGludGVyb3BIb3N0KGBBZG1pbmlzdHJhdGlvbl9MZXZlbHMvTGV2ZWxJbnN0YW5jZXMvUmVhZD9pbXBvcnRMZXZlbElkPSR7bW9kdWxlSWR9JmxldmVsSWQ9JHttb2R1bGVJZH0mZm9yZWlnbktleUlkPSR7bW9kdWxlSWR9YCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KSgpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmwsIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEluc3RhbmNlSW5Nb2R1bGUobW9kdWxlSWQsIG1vZHVsZUluc3RhbmNlSWQpIHtcclxuICAgICAgICBjb25zdCB1cmwgPSAoKCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoaW50ZXJvcEFwcElkKCkgPT09ICdzb2Z0dW5pLmJnJykge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl9sZXZlbHMvbGV2ZWxpbnN0YW5jZXMvcmVhZD9pbXBvcnRMZXZlbElkPSR7bW9kdWxlSWR9JmxldmVsSWQ9JHttb2R1bGVJZH1gKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdChgQWRtaW5pc3RyYXRpb25fTGV2ZWxzL0xldmVsSW5zdGFuY2VzL1JlYWQ/aW1wb3J0TGV2ZWxJZD0ke21vZHVsZUlkfSZsZXZlbElkPSR7bW9kdWxlSWR9JmZvcmVpZ25LZXlJZD0ke21vZHVsZUlkfWApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSkoKTtcclxuXHJcbiAgICAgICAgbGV0IGZpbHRlciA9IGBJZH5lcX4ke21vZHVsZUluc3RhbmNlSWR9YDtcclxuXHJcbiAgICAgICAgaWYoQXJyYXkuaXNBcnJheShtb2R1bGVJbnN0YW5jZUlkKSkge1xyXG4gICAgICAgICAgICBmaWx0ZXIgPSBgSWR+ZXF+JHttb2R1bGVJbnN0YW5jZUlkLmpvaW4oJ35vcn5JZH5lcX4nKX1gO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogZmlsdGVyXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVybCwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gc2VhcmNoTW9kdWxlcyhxdWVyeSkge1xyXG4gICAgICAgIGNvbnN0IHVybCA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl9sZXZlbHMvbGV2ZWxzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSBgTmFtZUJnfmNvbnRhaW5zficke3F1ZXJ5LnNwbGl0KCcgJykuZmlsdGVyKHMgPT4gcy5sZW5ndGggPiAwKS5qb2luKCdcXCd+YW5kfk5hbWVCZ35jb250YWluc35cXCcnKX0nYDtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMCxcclxuICAgICAgICAgICAgZmlsdGVyLFxyXG4gICAgICAgICAgICBzb3J0OiAnQ3JlYXRlZE9uLWRlc2MnXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmwsIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgZ2V0TW9kdWxlc0luUHJvZmVzc2lvbixcclxuICAgICAgICBnZXRNb2R1bGVzLFxyXG4gICAgICAgIGdldEluc3RhbmNlc0luTW9kdWxlLFxyXG4gICAgICAgIHNlYXJjaE1vZHVsZXMsXHJcbiAgICAgICAgZ2V0SW5zdGFuY2VJbk1vZHVsZVxyXG4gICAgfTtcclxufSIsImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCwgZ2V0LCBpbnRlcm9wUGxhdGZvcm1Ib3N0IH0pIHtcclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFBheW1lbnRzRm9yUGFja2FnZShwYWNrYWdlTmFtZSkge1xyXG4gICAgICAgIC8vIFRoaXMgZmllbGQgZG9lcyBub3Qgd29yayB3aXRoIG11bHRpcGxlIHZhbHVlc1xyXG4gICAgICAgIC8qXHJcbiAgICAgICAgY29uc3QgZmlsdGVyID0gKCgpID0+IHtcclxuICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkocGFja2FnZUlkKSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGBQYXltZW50UGFja2FnZXNBc1N0cmluZ35lcX4nJHtwYWNrYWdlSWQuam9pbignXFwnfm9yflBheW1lbnRQYWNrYWdlc0FzU3RyaW5nfmVxflxcJycpfSdgO1xyXG4gICAgICAgICAgICAgICAgLy9yZXR1cm4gYFBheW1lbnRTdGF0dXN+ZXF+NH5hbmR+KFBheW1lbnRQYWNrYWdlc0FzU3RyaW5nfmVxficke3BhY2thZ2VJZC5qb2luKCdcXCd+b3J+UGF5bWVudFBhY2thZ2VzQXNTdHJpbmd+ZXF+XFwnJyl9JylgO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGBQYXltZW50UGFja2FnZXNBc1N0cmluZ35lcX4nJHtwYWNrYWdlSWR9J2A7XHJcbiAgICAgICAgICAgICAgICAvL3JldHVybiBgUGF5bWVudFN0YXR1c35lcX40fmFuZH5QYXltZW50UGFja2FnZXNBc1N0cmluZ35lcX4ke3BhY2thZ2VJZH1gO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSkoKTtcclxuICAgICAgICAqL1xyXG5cclxuICAgICAgICBjb25zdCB1cmwgPSBgJHtpbnRlcm9wUGxhdGZvcm1Ib3N0KCl9L2FkbWluaXN0cmF0aW9uL3BheW1lbnRzL3JlYWQ/YXBwSWQ9JHtpbnRlcm9wQXBwSWQoKX1gO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogYFBheW1lbnRTdGF0dXN+ZXF+NH5hbmR+UGF5bWVudFBhY2thZ2VzQXNTdHJpbmd+ZXF+JyR7cGFja2FnZU5hbWV9J2BcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJsLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRQYWNrYWdlc0ZvclByb2R1Y3QocHJvZHVjdElkKSB7XHJcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkocHJvZHVjdElkKSAmJiBwcm9kdWN0SWQubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB7IERhdGE6IFtdIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KHByb2R1Y3RJZCkpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBgTmFtZX5kb2Vzbm90Y29udGFpbn4nSUknfmFuZH4oUHJvZHVjdC5JZH5lcX4ke3Byb2R1Y3RJZC5qb2luKCd+b3J+UHJvZHVjdC5JZH5lcX4nKX0pYDtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBgTmFtZX5kb2Vzbm90Y29udGFpbn4nSUknfmFuZH5Qcm9kdWN0LklkfmVxfiR7cHJvZHVjdElkfWA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KSgpO1xyXG4gICAgICAgIGNvbnN0IHVybCA9IGAke2ludGVyb3BQbGF0Zm9ybUhvc3QoKX0vYWRtaW5pc3RyYXRpb24vcGF5bWVudHBhY2thZ2VzL3JlYWQ/YXBwSWQ9JHtpbnRlcm9wQXBwSWQoKX1gO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMCxcclxuICAgICAgICAgICAgZmlsdGVyXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVybCwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0UHJvZHVjdHNGb3JNb2R1bGUobW9kdWxlSWQpIHtcclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSAoKCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShtb2R1bGVJZCkpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBgTmFtZX5kb2Vzbm90Y29udGFpbn4nSUknfmFuZH4oTGV2ZWxJbnN0YW5jZUlkfmVxfiR7bW9kdWxlSWQuam9pbignfm9yfkxldmVsSW5zdGFuY2VJZH5lcX4nKX0pYDtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBgTmFtZX5kb2Vzbm90Y29udGFpbn4nSUknfmFuZH5MZXZlbEluc3RhbmNlSWR+ZXF+JHttb2R1bGVJZH1gO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSkoKTtcclxuICAgICAgICBjb25zdCB1cmwgPSBgJHtpbnRlcm9wUGxhdGZvcm1Ib3N0KCl9L2FkbWluaXN0cmF0aW9uL2xldmVsaW5zdGFuY2Vwcm9kdWN0cy9yZWFkP2FwcElkPSR7aW50ZXJvcEFwcElkKCl9YDtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAsXHJcbiAgICAgICAgICAgIGZpbHRlclxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmwsIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFByb2R1Y3RzRm9yQ291cnNlKGluc3RhbmNlSWQsIHR5cGUgPSAnb3BlbicpIHtcclxuICAgICAgICBjb25zdCBlcFN0cmluZ3MgPSAoKCkgPT4ge1xyXG4gICAgICAgICAgICBzd2l0Y2ggKHR5cGUpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgJ29wZW4nOlxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhdGg6ICdmYXN0dHJhY2tpbnN0YW5jZXByb2R1Y3RzJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW06ICdGYXN0VHJhY2tJbnN0YW5jZUlkJ1xyXG4gICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KSgpO1xyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KGluc3RhbmNlSWQpKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gYCgke2VwU3RyaW5ncy5wYXJhbX1+ZXF+JHtpbnN0YW5jZUlkLmpvaW4oYH5vcn4ke2VwU3RyaW5ncy5wYXJhbX1+ZXF+YCl9KWA7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gYCR7ZXBTdHJpbmdzLnBhcmFtfX5lcX4ke2luc3RhbmNlSWR9YDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKCk7XHJcbiAgICAgICAgY29uc3QgdXJsID0gYCR7aW50ZXJvcFBsYXRmb3JtSG9zdCgpfS9hZG1pbmlzdHJhdGlvbi8ke2VwU3RyaW5ncy5wYXRofS9yZWFkP2FwcElkPSR7aW50ZXJvcEFwcElkKCl9YDtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAsXHJcbiAgICAgICAgICAgIGZpbHRlclxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmwsIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgZ2V0UGF5bWVudHNGb3JQYWNrYWdlLFxyXG4gICAgICAgIGdldFBhY2thZ2VzRm9yUHJvZHVjdCxcclxuICAgICAgICBnZXRQcm9kdWN0c0Zvck1vZHVsZSxcclxuICAgICAgICBnZXRQcm9kdWN0c0ZvckNvdXJzZVxyXG4gICAgfTtcclxufSIsImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCwgZ2V0IH0pIHtcclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBjcmVhdGVRdWl6SW5zdGFuY2UocGF5bG9hZCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90ZXN0c3lzdGVtL3Rlc3RzL2NyZWF0ZScpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnLFxyXG4gICAgICAgICAgICBJZDogMCxcclxuICAgICAgICAgICAgTmFtZTogcGF5bG9hZC5uYW1lLFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbjogcGF5bG9hZC5kZXNjcmlwdGlvbixcclxuICAgICAgICAgICAgUXVlc3Rpb25zQ291bnQ6IDBcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIGF3YWl0IHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBhZGRRdWVzdGlvbihxdWl6SWQsIHF1ZXN0aW9uKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3Rlc3RzeXN0ZW0vdGVzdHF1ZXN0aW9ucy9jcmVhdGU/Zm9yZWlnbktleUlkPSR7cXVpeklkfWApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnLFxyXG4gICAgICAgICAgICBJZDogMCxcclxuICAgICAgICAgICAgVHlwZTogMSxcclxuICAgICAgICAgICAgQ29udGVudDogcXVlc3Rpb24sXHJcbiAgICAgICAgICAgIENvcnJlY3RBbnN3ZXJQb2ludHM6IDEsXHJcbiAgICAgICAgICAgIFdyb25nQW5zd2VyUG9pbnRzOiAwLFxyXG4gICAgICAgICAgICBLZWVwQW5zd2Vyc09yZGVyOiBmYWxzZSxcclxuICAgICAgICAgICAgU2hvd0NvcnJlY3RBbnN3ZXJzQ291bnQ6IGZhbHNlLFxyXG4gICAgICAgICAgICBDb3JyZWN0Q291bnQ6IDAsXHJcbiAgICAgICAgICAgIFdyb25nQ291bnQ6IDAsXHJcbiAgICAgICAgICAgIEFsbENvdW50OiAwLFxyXG4gICAgICAgICAgICBQZXJjZW50Q29ycmVjdDogMFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gYXdhaXQgcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGFkZEFuc3dlcihxdWVzdGlvbklkLCBhbnN3ZXIsIGlzQ29ycmVjdCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90ZXN0c3lzdGVtL3Rlc3RxdWVzdGlvbmFuc3dlcnMvY3JlYXRlP2ZvcmVpZ25LZXlJZD0ke3F1ZXN0aW9uSWR9YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiAwLFxyXG4gICAgICAgICAgICBRdWVzdGlvbklkOiAwLFxyXG4gICAgICAgICAgICBDb250ZW50OiBhbnN3ZXIsXHJcbiAgICAgICAgICAgIElzQ29ycmVjdDogaXNDb3JyZWN0LFxyXG4gICAgICAgICAgICBTZWxlY3RlZENvdW50OiAwXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBhd2FpdCBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0QWxsUXVpemVzQnlOYW1lKGNvbnRhaW5pbmdOYW1lLCBwYWdlU2l6ZSwgcGFnZSkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90ZXN0c3lzdGVtL3Rlc3RzL3JlYWRgKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiBgTmFtZX5jb250YWluc34nJHtjb250YWluaW5nTmFtZX0nYCxcclxuICAgICAgICAgICAgcGFnZVNpemUsXHJcbiAgICAgICAgICAgIHBhZ2VcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIGF3YWl0IHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRRdWVzdGlvbnNCeUlkKHF1aXpJZCwgcGFnZVNpemUsIHBhZ2UpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdGVzdHN5c3RlbS90ZXN0cXVlc3Rpb25zL3JlYWQ/Zm9yZWlnbktleUlkPSR7cXVpeklkfWApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnLFxyXG4gICAgICAgICAgICBwYWdlU2l6ZSxcclxuICAgICAgICAgICAgcGFnZVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gYXdhaXQgcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEFuc3dlcnNCeVF1ZXN0aW9uSWQocXVlc3Rpb25JZCwgcGFnZVNpemUsIHBhZ2UpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdGVzdHN5c3RlbS90ZXN0cXVlc3Rpb25hbnN3ZXJzL3JlYWQ/Zm9yZWlnbktleUlkPSR7cXVlc3Rpb25JZH1gKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgcGFnZVNpemUsXHJcbiAgICAgICAgICAgIHBhZ2VcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIGF3YWl0IHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGNyZWF0ZVF1aXpJbnN0YW5jZSxcclxuICAgICAgICBhZGRRdWVzdGlvbixcclxuICAgICAgICBhZGRBbnN3ZXIsXHJcbiAgICAgICAgZ2V0QWxsUXVpemVzQnlOYW1lLFxyXG4gICAgICAgIGdldFF1ZXN0aW9uc0J5SWQsXHJcbiAgICAgICAgZ2V0QW5zd2Vyc0J5UXVlc3Rpb25JZFxyXG4gICAgfTtcclxufSIsImltcG9ydCBnZW5lcmljQXBpRmFjdG9yeSBmcm9tICcuL2dlbmVyaWMnO1xyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCwgZ2V0IH0pIHtcclxuICAgIGNvbnN0IGdlbmVyaWNBcGkgPSBnZW5lcmljQXBpRmFjdG9yeSh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCwgZ2V0IH0pO1xyXG5cclxuXHJcbiAgICBjb25zdCBzdG9yZUlkID0ge1xyXG4gICAgICAgICdzb2Z0dW5pLmJnJzogMzc5NyxcclxuICAgICAgICAnZGlnaXRhbC5zb2Z0dW5pLmJnJzogMzU1NixcclxuICAgICAgICAnY3JlYXRpdmUuc29mdHVuaS5iZyc6IDE0MTEsXHJcbiAgICAgICAgJ2FpLnNvZnR1bmkuYmcnOiA2LFxyXG4gICAgICAgICdmaW5hbmNlYWNhZGVteS5iZyc6IDczXHJcbiAgICB9O1xyXG5cclxuICAgIGZ1bmN0aW9uIHNlcmlhbGl6ZShkYXRhKSB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgSWQ6IGRhdGEuSWQgfHwgMCxcclxuICAgICAgICAgICAgVHJhaW5pbmdJZDogc3RvcmVJZFtpbnRlcm9wQXBwSWQoKV0sXHJcbiAgICAgICAgICAgIE5hbWVCZzogJzAwMDAwMDAwMDAnICsgZGF0YS5FeGFtSWQsXHJcbiAgICAgICAgICAgIE5hbWVFbjogJzAwMDAwMDAwMDAnLFxyXG4gICAgICAgICAgICBIYXNNYW51YWxOdW1iZXJPZlN0dWR5SG91cnM6IHRydWUsXHJcbiAgICAgICAgICAgIE51bWJlck9mU3R1ZHlIb3VyczogMCxcclxuICAgICAgICAgICAgSXNFeGNsdWRlZEZyb21DZXJ0aWZpY2F0ZTogZmFsc2UsXHJcbiAgICAgICAgICAgIEhhc0hvbWV3b3JrOiBmYWxzZSxcclxuICAgICAgICAgICAgUmVzb3VyY2VNYWlsc1N0YXRlOiAwLFxyXG4gICAgICAgICAgICBIb21ld29ya01haWxzU3RhdGU6IDAsXHJcbiAgICAgICAgICAgIEp1ZGdlQ29udGVzdElkOiAnJyxcclxuICAgICAgICAgICAgT3JkZXJCeTogMCxcclxuICAgICAgICAgICAgRGVzY3JpcHRpb25CZzogJzAwMDAwMDAwMDAnICsgSlNPTi5zdHJpbmdpZnkoZGF0YS5Db25maWcpLFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkVuOiAnMDAwMDAwMDAwMCcsXHJcbiAgICAgICAgICAgIEV4Y2x1ZGVGcm9tQ2FsZW5kYXI6IGZhbHNlLFxyXG4gICAgICAgICAgICBIYXNMaXZlU3RyZWFtOiBmYWxzZSxcclxuICAgICAgICAgICAgQ3JlYXRlZE9uOiAnJyxcclxuICAgICAgICAgICAgTW9kaWZpZWRPbjogJydcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIHBhcnNlKGVudHJ5KSB7XHJcbiAgICAgICAgaWYgKGVudHJ5KSB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICBJZDogZW50cnkuSWQsXHJcbiAgICAgICAgICAgICAgICBFeGFtSWQ6IE51bWJlcigoZW50cnkuTmFtZUJnIHx8ICcnKS5zbGljZSgxMCkpLFxyXG4gICAgICAgICAgICAgICAgQ29uZmlnOiBKU09OLnBhcnNlKChlbnRyeS5EZXNjcmlwdGlvbkJnIHx8ICcnKS5zbGljZSgxMCkpLFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldENvbmZpZ3MoZXhhbUlkcykge1xyXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBnZW5lcmljQXBpLmdldEVudHJpZXMoc3RvcmVJZFtpbnRlcm9wQXBwSWQoKV0sIGBOYW1lQmd+ZXF+JyR7ZXhhbUlkcy5tYXAoaWQgPT4gJzAwMDAwMDAwMDAnICsgaWQpLmpvaW4oJ1xcJ35vcn5OYW1lQmd+ZXF+XFwnJyl9J2ApO1xyXG4gICAgICAgIHJldHVybiBkYXRhLm1hcChwYXJzZSk7O1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldENvbmZpZ0J5RXhhbUlkKGV4YW1JZCkge1xyXG4gICAgICAgIGNvbnN0IGNvbmZpZyA9IGF3YWl0IGdlbmVyaWNBcGkuZ2V0RW50cmllcyhzdG9yZUlkW2ludGVyb3BBcHBJZCgpXSwgYE5hbWVCZ35lcX4nMDAwMDAwMDAwMCR7ZXhhbUlkfSdgKTtcclxuICAgICAgICByZXR1cm4gcGFyc2UoY29uZmlnLkRhdGFbMF0pO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHNhdmVDb25maWcoY29uZmlnKSB7XHJcbiAgICAgICAgY29uc3Qgb3BlcmF0aW9uID0gY29uZmlnLklkID8gZ2VuZXJpY0FwaS51cGRhdGVFbnRyeSA6IGdlbmVyaWNBcGkuY3JlYXRlRW50cnk7XHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgb3BlcmF0aW9uKHNlcmlhbGl6ZShjb25maWcpKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBhcnNlKHJlc3VsdC5EYXRhWzBdKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBkZWxldGVDb25maWcoY29uZmlnKSB7XHJcbiAgICAgICAgcmV0dXJuIGdlbmVyaWNBcGkuZGVzdHJveUVudHJ5KHNlcmlhbGl6ZShjb25maWcpKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldENvbmZpZ3MsXHJcbiAgICAgICAgZ2V0Q29uZmlnQnlFeGFtSWQsXHJcbiAgICAgICAgc2F2ZUNvbmZpZyxcclxuICAgICAgICBkZWxldGVDb25maWdcclxuICAgIH07XHJcbn0iLCJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KSB7XHJcblxyXG4gICAgLyogRW50cnkgbW9kZWw6XHJcblxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgSWQ6IGRhdGEuSWQsXHJcbiAgICAgICAgICAgIFRyYWluaW5nSWQ6IHN0b3JlSWRbaW50ZXJvcEFwcElkKCldLFxyXG4gICAgICAgICAgICBOYW1lQmc6ICcnLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU3RyaW5nICgzLTIwMClcclxuICAgICAgICAgICAgTmFtZUVuOiAnJywgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFN0cmluZyAoMy0yMDApXHJcbiAgICAgICAgICAgIE51bWJlck9mU3R1ZHlIb3VyczogMCwgICAgICAgICAgICAgICAgICBJbnRlZ2VyXHJcbiAgICAgICAgICAgIElzRXhjbHVkZWRGcm9tQ2VydGlmaWNhdGU6IGZhbHNlLCAgICAgICBCb29sZWFuXHJcbiAgICAgICAgICAgIEhhc0hvbWV3b3JrOiBmYWxzZSwgICAgICAgICAgICAgICAgICAgICBCb29sZWFuXHJcbiAgICAgICAgICAgIFJlc291cmNlTWFpbHNTdGF0ZTogMCxcclxuICAgICAgICAgICAgSG9tZXdvcmtNYWlsc1N0YXRlOiAwLFxyXG4gICAgICAgICAgICBKdWRnZUNvbnRlc3RJZDogJycsICAgICAgICAgICAgICAgICAgICAgSW50ZWdlciAoY2Fubm90IGJlIGVtcHR5KVxyXG4gICAgICAgICAgICBPcmRlckJ5OiAwLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSW50ZWdlclxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkJnOiAnJywgICAgICAgICAgICAgICAgICAgICAgU3RyaW5nICgxMC02MDAwKVxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkVuOiAnJywgICAgICAgICAgICAgICAgICAgICAgU3RyaW5nICgxMC02MDAwKVxyXG4gICAgICAgICAgICBFeGNsdWRlRnJvbUNhbGVuZGFyOiBmYWxzZSwgICAgICAgICAgICAgQm9vbGVhblxyXG4gICAgICAgICAgICBIYXNMaXZlU3RyZWFtOiBmYWxzZSwgICAgICAgICAgICAgICAgICAgQm9vbGVhblxyXG4gICAgICAgICAgICBDcmVhdGVkT246ICcnLFxyXG4gICAgICAgICAgICBNb2RpZmllZE9uOiAnJ1xyXG4gICAgICAgIH07XHJcbiAgICAqL1xyXG5cclxuICAgIGNvbnN0IHNldHRpbmdzU3RvcmVJZCA9IHtcclxuICAgICAgICAnc29mdHVuaS5iZyc6IDUyOSxcclxuICAgICAgICAnZGlnaXRhbC5zb2Z0dW5pLmJnJzogMTA2NCxcclxuICAgICAgICAnY3JlYXRpdmUuc29mdHVuaS5iZyc6IDEwMSxcclxuICAgICAgICAnYWkuc29mdHVuaS5iZyc6IDUsXHJcbiAgICAgICAgJ2ZpbmFuY2VhY2FkZW15LmJnJzogMjRcclxuICAgIH07XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0U3RvcmVTZXR0aW5ncyhzdG9yZUlkKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9mYXN0dHJhY2tpbnN0YW5jZXMvcmVhZD9mb3JlaWduS2V5SWQ9JHtzZXR0aW5nc1N0b3JlSWRbaW50ZXJvcEFwcElkKCldfWApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBmaWx0ZXI6IGBJZH5lcX4ke3N0b3JlSWR9YFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjb25zdCBzdG9yZSA9IChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGFbMF07XHJcbiAgICAgICAgY29uc3QgYXNKc29uID0gKHN0b3JlLkRlc2NyaXB0aW9uQmcgfHwgJycpLnNsaWNlKDEwKSArIChzdG9yZS5EZXNjcmlwdGlvbkVuIHx8ICcnKS5zbGljZSgxMCk7XHJcblxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICBzZXR0aW5nczogSlNPTi5wYXJzZShhc0pzb24pLFxyXG4gICAgICAgICAgICAgICAgX01vZGlmaWVkT246IHN0b3JlLk1vZGlmaWVkT24gfHwgc3RvcmUuQ3JlYXRlZE9uXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gc2F2ZVN0b3JlU2V0dGluZ3Moc3RvcmVJZCwgc2V0dGluZ3MpIHtcclxuICAgICAgICBjb25zdCBjdXJyZW50VXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9mYXN0dHJhY2tpbnN0YW5jZXMvcmVhZD9mb3JlaWduS2V5SWQ9JHtzZXR0aW5nc1N0b3JlSWRbaW50ZXJvcEFwcElkKCldfWApO1xyXG4gICAgICAgIGNvbnN0IGN1cnJlbnRCb2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgZmlsdGVyOiBgSWR+ZXF+JHtzdG9yZUlkfWBcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgY3VycmVudCA9IChhd2FpdCBwb3N0KGN1cnJlbnRVcmksIGN1cnJlbnRCb2R5KSkuRGF0YVswXTtcclxuICAgICAgICBkZWxldGUgY3VycmVudC5TaGFyZXNMaXZlU3RyZWFtV2l0aFRyYWluaW5ncztcclxuXHJcbiAgICAgICAgaWYgKHNldHRpbmdzLmhhc093blByb3BlcnR5KCdfTW9kaWZpZWRPbicpICYmIHNldHRpbmdzLmhhc093blByb3BlcnR5KCdzZXR0aW5ncycpKSB7XHJcbiAgICAgICAgICAgIHNldHRpbmdzID0gc2V0dGluZ3Muc2V0dGluZ3M7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCBhc0pzb24gPSBKU09OLnN0cmluZ2lmeShzZXR0aW5ncyk7XHJcbiAgICAgICAgY3VycmVudC5EZXNjcmlwdGlvbkJnID0gJzAwMDAwMDAwMDAnICsgYXNKc29uLnNsaWNlKDAsIDEwMDAwKTtcclxuICAgICAgICBjdXJyZW50LkRlc2NyaXB0aW9uRW4gPSAnMDAwMDAwMDAwMCcgKyBhc0pzb24uc2xpY2UoMTAwMDApO1xyXG4gICAgICAgIC8vQ2VydGlmaWNhdGUgdHlwZSBpcyBub3cgcmVxdWlyZWQgKDggPSBOb25lKVxyXG4gICAgICAgIGN1cnJlbnQuQ2VydGlmaWNhdGVUeXBlID0gODtcclxuXHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9mYXN0dHJhY2tpbnN0YW5jZXMvdXBkYXRlP2ZvcmVpZ25LZXlJZD0ke3NldHRpbmdzU3RvcmVJZFtpbnRlcm9wQXBwSWQoKV19YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHtcclxuICAgICAgICAgICAgJ3NvcnQnOiAnJyxcclxuICAgICAgICAgICAgJ2dyb3VwJzogJycsXHJcbiAgICAgICAgICAgICdmaWx0ZXInOiAnJyxcclxuICAgICAgICAgICAgLi4uY3VycmVudCxcclxuICAgICAgICAgICAgQ3JlYXRlZE9uOiAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnLFxyXG4gICAgICAgICAgICBNb2RpZmllZE9uOiAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnXHJcbiAgICAgICAgfTtcclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCkgeyBib2R5W2tdID0gJyc7IH0gfSk7XHJcblxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGFbMF07XHJcbiAgICAgICAgICAgIHJldHVybiBKU09OLnBhcnNlKChyZXN1bHQuRGVzY3JpcHRpb25CZyB8fCAnJykuc2xpY2UoMTApKTtcclxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4gICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRFbnRyaWVzKHN0b3JlSWQsIGZpbHRlcikge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvbGVjdHVyZXMvcmVhZD9mb3JlaWduS2V5SWQ9JHtzdG9yZUlkfWApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMCxcclxuICAgICAgICB9KTtcclxuICAgICAgICBpZiAoZmlsdGVyKSB7XHJcbiAgICAgICAgICAgIGJvZHkuZmlsdGVyID0gZmlsdGVyO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gdXBkYXRlRW50cnkoZW50cnkpIHtcclxuICAgICAgICBsZXQgc3RhcnREYXRlID0gbmV3IERhdGUoKTtcclxuICAgICAgICBsZXQgZW5kRGF0ZSA9IG5ldyBEYXRlKHN0YXJ0RGF0ZSk7XHJcbiAgICAgICAgZW5kRGF0ZS5zZXRVVENEYXRlKGVuZERhdGUuZ2V0VVRDRGF0ZSgpICArIDEpO1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvbGVjdHVyZXMvdXBkYXRlP2ZvcmVpZ25LZXlJZD0ke2VudHJ5LlRyYWluaW5nSWR9YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiBlbnRyeS5JZCxcclxuICAgICAgICAgICAgVHJhaW5pbmdJZDogZW50cnkuVHJhaW5pbmdJZCxcclxuICAgICAgICAgICAgTmFtZUJnOiBlbnRyeS5OYW1lQmcsXHJcbiAgICAgICAgICAgIE5hbWVFbjogZW50cnkuTmFtZUVuLFxyXG4gICAgICAgICAgICBIYXNNYW51YWxOdW1iZXJPZlN0dWR5SG91cnM6IHRydWUsXHJcbiAgICAgICAgICAgIE51bWJlck9mU3R1ZHlIb3VyczogZW50cnkuTnVtYmVyT2ZTdHVkeUhvdXJzLFxyXG4gICAgICAgICAgICBJc0V4Y2x1ZGVkRnJvbUNlcnRpZmljYXRlOiBlbnRyeS5Jc0V4Y2x1ZGVkRnJvbUNlcnRpZmljYXRlLFxyXG4gICAgICAgICAgICBIYXNIb21ld29yazogZW50cnkuSGFzSG9tZXdvcmssXHJcbiAgICAgICAgICAgIFJlc291cmNlTWFpbHNTdGF0ZTogZW50cnkuUmVzb3VyY2VNYWlsc1N0YXRlLFxyXG4gICAgICAgICAgICBIb21ld29ya01haWxzU3RhdGU6IGVudHJ5LkhvbWV3b3JrTWFpbHNTdGF0ZSxcclxuICAgICAgICAgICAgSnVkZ2VDb250ZXN0SWQ6IGVudHJ5Lkp1ZGdlQ29udGVzdElkLFxyXG4gICAgICAgICAgICBPcmRlckJ5OiBlbnRyeS5PcmRlckJ5LFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkJnOiBlbnRyeS5EZXNjcmlwdGlvbkJnLFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkVuOiBlbnRyeS5EZXNjcmlwdGlvbkVuLFxyXG4gICAgICAgICAgICBFeGNsdWRlRnJvbUNhbGVuZGFyOiBlbnRyeS5FeGNsdWRlRnJvbUNhbGVuZGFyLFxyXG4gICAgICAgICAgICBIYXNMaXZlU3RyZWFtOiBlbnRyeS5IYXNMaXZlU3RyZWFtLFxyXG4gICAgICAgICAgICBDcmVhdGVkT246ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcyMDE5LTA3LTMxVDE3OjM5OjAyLjMxNycsXHJcbiAgICAgICAgICAgIERhdGVzSW5mbzogW1xyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIFN0YXJ0OiBzdGFydERhdGUudG9JU09TdHJpbmcoKSxcclxuICAgICAgICAgICAgICAgICAgICBFbmQ6IGVuZERhdGUudG9JU09TdHJpbmcoKSxcclxuICAgICAgICAgICAgICAgICAgICBFeHRyYUluZm9ybWF0aW9uOiAnJ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBdIFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNlcmlhbGl6ZURhdGVzSW5mbyhib2R5KTtcclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCkgeyBib2R5W2tdID0gJyc7IH0gfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gY3JlYXRlRW50cnkoZW50cnkpIHtcclxuICAgICAgICBsZXQgc3RhcnREYXRlID0gbmV3IERhdGUoKTtcclxuICAgICAgICBsZXQgZW5kRGF0ZSA9IG5ldyBEYXRlKHN0YXJ0RGF0ZSk7XHJcbiAgICAgICAgZW5kRGF0ZS5zZXRVVENEYXRlKGVuZERhdGUuZ2V0VVRDRGF0ZSgpICArIDEpO1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvbGVjdHVyZXMvY3JlYXRlP2ZvcmVpZ25LZXlJZD0ke2VudHJ5LlRyYWluaW5nSWR9YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiBlbnRyeS5JZCxcclxuICAgICAgICAgICAgVHJhaW5pbmdJZDogZW50cnkuVHJhaW5pbmdJZCxcclxuICAgICAgICAgICAgTmFtZUJnOiBlbnRyeS5OYW1lQmcsXHJcbiAgICAgICAgICAgIE5hbWVFbjogZW50cnkuTmFtZUVuLFxyXG4gICAgICAgICAgICBIYXNNYW51YWxOdW1iZXJPZlN0dWR5SG91cnM6IHRydWUsXHJcbiAgICAgICAgICAgIE51bWJlck9mU3R1ZHlIb3VyczogZW50cnkuTnVtYmVyT2ZTdHVkeUhvdXJzLFxyXG4gICAgICAgICAgICBJc0V4Y2x1ZGVkRnJvbUNlcnRpZmljYXRlOiBlbnRyeS5Jc0V4Y2x1ZGVkRnJvbUNlcnRpZmljYXRlLFxyXG4gICAgICAgICAgICBIYXNIb21ld29yazogZW50cnkuSGFzSG9tZXdvcmssXHJcbiAgICAgICAgICAgIFJlc291cmNlTWFpbHNTdGF0ZTogZW50cnkuUmVzb3VyY2VNYWlsc1N0YXRlLFxyXG4gICAgICAgICAgICBIb21ld29ya01haWxzU3RhdGU6IGVudHJ5LkhvbWV3b3JrTWFpbHNTdGF0ZSxcclxuICAgICAgICAgICAgSnVkZ2VDb250ZXN0SWQ6IGVudHJ5Lkp1ZGdlQ29udGVzdElkLFxyXG4gICAgICAgICAgICBPcmRlckJ5OiBlbnRyeS5PcmRlckJ5LFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkJnOiBlbnRyeS5EZXNjcmlwdGlvbkJnLFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkVuOiBlbnRyeS5EZXNjcmlwdGlvbkVuLFxyXG4gICAgICAgICAgICBFeGNsdWRlRnJvbUNhbGVuZGFyOiBlbnRyeS5FeGNsdWRlRnJvbUNhbGVuZGFyLFxyXG4gICAgICAgICAgICBIYXNMaXZlU3RyZWFtOiBlbnRyeS5IYXNMaXZlU3RyZWFtLFxyXG4gICAgICAgICAgICBDcmVhdGVkT246ICcnLFxyXG4gICAgICAgICAgICBNb2RpZmllZE9uOiAnJyxcclxuICAgICAgICAgICAgRGF0ZXNJbmZvOiBbXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgU3RhcnQ6IHN0YXJ0RGF0ZS50b0lTT1N0cmluZygpLFxyXG4gICAgICAgICAgICAgICAgICAgIEVuZDogZW5kRGF0ZS50b0lTT1N0cmluZygpLFxyXG4gICAgICAgICAgICAgICAgICAgIEV4dHJhSW5mb3JtYXRpb246ICcnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIF0gXHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNlcmlhbGl6ZURhdGVzSW5mbyhib2R5KTtcclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCkgeyBib2R5W2tdID0gJyc7IH0gfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZGVzdHJveUVudHJ5KGVudHJ5KSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9sZWN0dXJlcy9kZXN0cm95P2ZvcmVpZ25LZXlJZD0ke2VudHJ5LlRyYWluaW5nSWR9YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJydcclxuICAgICAgICB9KTtcclxuICAgICAgICBPYmplY3QuYXNzaWduKGJvZHksIGVudHJ5KTtcclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCkgeyBib2R5W2tdID0gJyc7IH0gfSk7XHJcbiAgICAgICAgYm9keS5DcmVhdGVkT24gPSAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnO1xyXG4gICAgICAgIGJvZHkuTW9kaWZpZWRPbiA9ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNyc7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gc2VyaWFsaXplRGF0ZXNJbmZvKGJvZHkpIHtcclxuICAgICAgICBjb25zdCBkYXRlc0luZm8gPSBib2R5LkRhdGVzSW5mbztcclxuICAgICAgICBkZWxldGUgYm9keS5EYXRlc0luZm87XHJcbiAgICAgICAgXHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRlc0luZm8ubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgY29uc3QgZGF0ZSA9IGRhdGVzSW5mb1tpXTtcclxuICAgICAgICAgICAgYm9keVtgRGF0ZXNJbmZvWyR7aX1dLlN0YXJ0YF0gPSBkYXRlLlN0YXJ0O1xyXG4gICAgICAgICAgICBib2R5W2BEYXRlc0luZm9bJHtpfV0uRW5kYF0gPSBkYXRlLkVuZDtcclxuICAgICAgICAgICAgYm9keVtgRGF0ZXNJbmZvWyR7aX1dLkV4dHJhSW5mb3JtYXRpb25gXSA9IGRhdGUuRXh0cmFJbmZvcm1hdGlvbjtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBnZXRTdG9yZVNldHRpbmdzLFxyXG4gICAgICAgIHNhdmVTdG9yZVNldHRpbmdzLFxyXG4gICAgICAgIGdldEVudHJpZXMsXHJcbiAgICAgICAgdXBkYXRlRW50cnksXHJcbiAgICAgICAgY3JlYXRlRW50cnksXHJcbiAgICAgICAgZGVzdHJveUVudHJ5XHJcbiAgICB9O1xyXG59IiwiaW1wb3J0IGdlbmVyaWNBcGlGYWN0b3J5IGZyb20gJy4vZ2VuZXJpYyc7XHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSkge1xyXG4gICAgY29uc3QgZ2VuZXJpY0FwaSA9IGdlbmVyaWNBcGlGYWN0b3J5KHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSk7XHJcblxyXG5cclxuICAgIGNvbnN0IHN0b3JlSWQgPSB7XHJcbiAgICAgICAgJ3NvZnR1bmkuYmcnOiA0NDkyLFxyXG4gICAgICAgICdkaWdpdGFsLnNvZnR1bmkuYmcnOiAzODE1LFxyXG4gICAgICAgICdjcmVhdGl2ZS5zb2Z0dW5pLmJnJzogMTYxMixcclxuICAgICAgICAnYWkuc29mdHVuaS5iZyc6IDlcclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBnZXRNb2R1bGVEYXRhU2V0dGluZ3M6ICgpID0+IGdlbmVyaWNBcGkuZ2V0U3RvcmVTZXR0aW5ncyhzdG9yZUlkW2ludGVyb3BBcHBJZCgpXSksXHJcbiAgICAgICAgc2F2ZU1vZHVsZURhdGFTZXR0aW5nczogKHNldHRpbmdzKSA9PiBnZW5lcmljQXBpLnNhdmVTdG9yZVNldHRpbmdzKHN0b3JlSWRbaW50ZXJvcEFwcElkKCldLCBzZXR0aW5ncyksXHJcbiAgICB9O1xyXG59IiwiaW1wb3J0IGdlbmVyaWNBcGlGYWN0b3J5IGZyb20gJy4vZ2VuZXJpYyc7XHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSkge1xyXG4gICAgY29uc3QgZ2VuZXJpY0FwaSA9IGdlbmVyaWNBcGlGYWN0b3J5KHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSk7XHJcblxyXG5cclxuICAgIGNvbnN0IHN0b3JlSWQgPSB7XHJcbiAgICAgICAgJ3NvZnR1bmkuYmcnOiAzODMzLFxyXG4gICAgICAgICdkaWdpdGFsLnNvZnR1bmkuYmcnOiAzNTgyLFxyXG4gICAgICAgICdjcmVhdGl2ZS5zb2Z0dW5pLmJnJzogMTQyOCxcclxuICAgICAgICAnYWkuc29mdHVuaS5iZyc6IDEwXHJcbiAgICB9O1xyXG5cclxuICAgIGZ1bmN0aW9uIHNlcmlhbGl6ZShkYXRhKSB7XHJcbiAgICAgICAgY29uc3QgcGF5bG9hZCA9IHtcclxuICAgICAgICAgICAgUGF5bWVudHNCeURhdGU6IGRhdGEuUGF5bWVudHNCeURhdGUsXHJcbiAgICAgICAgICAgIFJldGVudGlvbkJ5RGF0ZTogZGF0YS5SZXRlbnRpb25CeURhdGUsXHJcbiAgICAgICAgICAgIE9ubGluZVBheW1lbnRzOiBkYXRhLk9ubGluZVBheW1lbnRzIHx8IDAsXHJcbiAgICAgICAgICAgIE9ubGluZVJldGVudGlvbjogZGF0YS5PbmxpbmVSZXRlbnRpb24gfHwgMCxcclxuICAgICAgICAgICAgU2l0ZVBheW1lbnRzOiBkYXRhLlNpdGVQYXltZW50cyB8fCAwLFxyXG4gICAgICAgICAgICBTaXRlUmV0ZW50aW9uOiBkYXRhLlNpdGVSZXRlbnRpb24gfHwgMFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgY29uc3QgYXNKc29uID0gSlNPTi5zdHJpbmdpZnkocGF5bG9hZCk7XHJcblxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiBkYXRhLklkIHx8IDAsXHJcbiAgICAgICAgICAgIFRyYWluaW5nSWQ6IHN0b3JlSWRbaW50ZXJvcEFwcElkKCldLFxyXG4gICAgICAgICAgICBOYW1lQmc6ICcwMDAwMDAwMDAwJyArIChkYXRhLk5hbWVCZyArICc6OicgKyBkYXRhLk5hbWVFbiArICc6OicgKyBkYXRhLkxldmVsSWQpLFxyXG4gICAgICAgICAgICBOYW1lRW46ICcwMDAwMDAwMDAwJyArIEpTT04uc3RyaW5naWZ5KGRhdGEuRGF0ZUNvbmZpZyksXHJcbiAgICAgICAgICAgIEhhc01hbnVhbE51bWJlck9mU3R1ZHlIb3VyczogdHJ1ZSxcclxuICAgICAgICAgICAgTnVtYmVyT2ZTdHVkeUhvdXJzOiBkYXRhLlN0YXJ0SW5kZXggfHwgMCxcclxuICAgICAgICAgICAgSXNFeGNsdWRlZEZyb21DZXJ0aWZpY2F0ZTogZmFsc2UsXHJcbiAgICAgICAgICAgIEp1ZGdlQ29udGVzdElkOiBkYXRhLkxldmVsSWQsXHJcbiAgICAgICAgICAgIEhhc0hvbWV3b3JrOiBmYWxzZSxcclxuICAgICAgICAgICAgUmVzb3VyY2VNYWlsc1N0YXRlOiAwLFxyXG4gICAgICAgICAgICBIb21ld29ya01haWxzU3RhdGU6IDAsXHJcbiAgICAgICAgICAgIE9yZGVyQnk6IGRhdGEuSW5zdGFuY2VJZCxcclxuICAgICAgICAgICAgRGVzY3JpcHRpb25CZzogJzAwMDAwMDAwMDAnICsgYXNKc29uLnNsaWNlKDAsIDU5ODApLFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkVuOiAnMDAwMDAwMDAwMCcgKyBhc0pzb24uc2xpY2UoNTk4MCksXHJcbiAgICAgICAgICAgIEV4Y2x1ZGVGcm9tQ2FsZW5kYXI6ICFkYXRhLklzTWFpblByb2dyYW0sXHJcbiAgICAgICAgICAgIEhhc0xpdmVTdHJlYW06IGZhbHNlLFxyXG4gICAgICAgICAgICBDcmVhdGVkT246ICcnLFxyXG4gICAgICAgICAgICBNb2RpZmllZE9uOiAnJ1xyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gcGFyc2UoZW50cnkpIHtcclxuICAgICAgICBpZiAoZW50cnkpIHtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHBheWxvYWRKc29uID0gKGVudHJ5LkRlc2NyaXB0aW9uQmcgfHwgJycpLnNsaWNlKDEwKSArIChlbnRyeS5EZXNjcmlwdGlvbkVuIHx8ICcnKS5zbGljZSgxMCk7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBwYXlsb2FkID0gSlNPTi5wYXJzZShwYXlsb2FkSnNvbik7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBuYW1lc0FuZExldmVsID0gZW50cnkuTmFtZUJnLnNsaWNlKDEwKS5zcGxpdCgnOjonKTtcclxuXHJcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgICAgIElkOiBlbnRyeS5JZCxcclxuICAgICAgICAgICAgICAgICAgICBJbnN0YW5jZUlkOiBOdW1iZXIoZW50cnkuT3JkZXJCeSkgfHwgbnVsbCxcclxuICAgICAgICAgICAgICAgICAgICBMZXZlbElkOiBOdW1iZXIobmFtZXNBbmRMZXZlbFsyXSkgfHwgZW50cnkuSnVkZ2VDb250ZXN0SWQsXHJcbiAgICAgICAgICAgICAgICAgICAgTmFtZUJnOiBuYW1lc0FuZExldmVsWzBdLFxyXG4gICAgICAgICAgICAgICAgICAgIE5hbWVFbjogbmFtZXNBbmRMZXZlbFsxXSxcclxuICAgICAgICAgICAgICAgICAgICBEYXRlQ29uZmlnOiBKU09OLnBhcnNlKChlbnRyeS5OYW1lRW4gfHwgJycpLnNsaWNlKDEwKSksXHJcbiAgICAgICAgICAgICAgICAgICAgU3RhcnRJbmRleDogZW50cnkuTnVtYmVyT2ZTdHVkeUhvdXJzLFxyXG4gICAgICAgICAgICAgICAgICAgIFBheW1lbnRzQnlEYXRlOiBwYXlsb2FkLlBheW1lbnRzQnlEYXRlLFxyXG4gICAgICAgICAgICAgICAgICAgIFJldGVudGlvbkJ5RGF0ZTogcGF5bG9hZC5SZXRlbnRpb25CeURhdGUsXHJcbiAgICAgICAgICAgICAgICAgICAgT25saW5lUGF5bWVudHM6IHBheWxvYWQuT25saW5lUGF5bWVudHMgfHwgMCxcclxuICAgICAgICAgICAgICAgICAgICBPbmxpbmVSZXRlbnRpb246IHBheWxvYWQuT25saW5lUmV0ZW50aW9uIHx8IDAsXHJcbiAgICAgICAgICAgICAgICAgICAgU2l0ZVBheW1lbnRzOiBwYXlsb2FkLlNpdGVQYXltZW50cyB8fCAwLFxyXG4gICAgICAgICAgICAgICAgICAgIFNpdGVSZXRlbnRpb246IHBheWxvYWQuU2l0ZVJldGVudGlvbiB8fCAwLFxyXG4gICAgICAgICAgICAgICAgICAgIElzTWFpblByb2dyYW06ICFlbnRyeS5FeGNsdWRlRnJvbUNhbGVuZGFyLFxyXG4gICAgICAgICAgICAgICAgICAgIE1vZGlmaWVkT246IGVudHJ5Lk1vZGlmaWVkT24gfHwgZW50cnkuQ3JlYXRlZE9uXHJcbiAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Rlc3Ryb3lpbmcgaW5jb21wYXRpYmxlIGVudHJ5Jyk7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlbnRyeSk7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbiAgICAgICAgICAgICAgICBnZW5lcmljQXBpLmRlc3Ryb3lFbnRyeShlbnRyeSk7XHJcblxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFN0YXRzKGluc3RhbmNlSWRzKSB7XHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGdlbmVyaWNBcGkuZ2V0RW50cmllcyhzdG9yZUlkW2ludGVyb3BBcHBJZCgpXSwgYE9yZGVyQnl+ZXF+JHtpbnN0YW5jZUlkcy5qb2luKCd+b3J+T3JkZXJCeX5lcX4nKX1gKTtcclxuICAgICAgICByZXR1cm4gZGF0YS5tYXAocGFyc2UpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFN0YXRzQnlJbnN0YW5jZUlkKGluc3RhbmNlSWQpIHtcclxuICAgICAgICBjb25zdCBjb25maWcgPSBhd2FpdCBnZW5lcmljQXBpLmdldEVudHJpZXMoc3RvcmVJZFtpbnRlcm9wQXBwSWQoKV0sIGBPcmRlckJ5fmVxfiR7aW5zdGFuY2VJZH1gKTtcclxuICAgICAgICByZXR1cm4gcGFyc2UoY29uZmlnWzBdKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRTdGF0c0J5U3RhcnRJbmRleChzdGFydCwgZW5kKSB7XHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGdlbmVyaWNBcGkuZ2V0RW50cmllcyhzdG9yZUlkW2ludGVyb3BBcHBJZCgpXSwgYE51bWJlck9mU3R1ZHlIb3Vyc35ndGV+JHtzdGFydH1+YW5kfk51bWJlck9mU3R1ZHlIb3Vyc35sdGV+JHtlbmR9YCk7XHJcbiAgICAgICAgcmV0dXJuIGRhdGEubWFwKHBhcnNlKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBzYXZlU3RhdHMoc3RhdHMpIHtcclxuICAgICAgICBjb25zdCBvcGVyYXRpb24gPSBzdGF0cy5JZCA/IGdlbmVyaWNBcGkudXBkYXRlRW50cnkgOiBnZW5lcmljQXBpLmNyZWF0ZUVudHJ5O1xyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IG9wZXJhdGlvbihzZXJpYWxpemUoc3RhdHMpKTtcclxuXHJcbiAgICAgICAgaWYocmVzdWx0LkVycm9ycykge1xyXG4gICAgICAgICAgICBjb25zdCBlcnJvciA9IG5ldyBFcnJvcignUmVxdWVzdCByZXR1cm5lZCBFcnJvcnMnKTtcclxuICAgICAgICAgICAgZXJyb3IuX2Vycm9yT2JqZWN0ID0gcmVzdWx0LkVycm9ycztcclxuICAgICAgICAgICAgdGhyb3cgZXJyb3I7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhKU09OLnN0cmluZ2lmeShyZXN1bHQpKTtcclxuICAgICAgICByZXR1cm4gcGFyc2UocmVzdWx0LkRhdGFbMF0pO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGRlbGV0ZVN0YXRzKHN0YXRzKSB7XHJcbiAgICAgICAgcmV0dXJuIGdlbmVyaWNBcGkuZGVzdHJveUVudHJ5KHNlcmlhbGl6ZShzdGF0cykpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgZ2V0U3RhdHNTZXR0aW5nczogKCkgPT4gZ2VuZXJpY0FwaS5nZXRTdG9yZVNldHRpbmdzKHN0b3JlSWRbaW50ZXJvcEFwcElkKCldKSxcclxuICAgICAgICBzYXZlU3RhdHNTZXR0aW5nczogKHNldHRpbmdzKSA9PiBnZW5lcmljQXBpLnNhdmVTdG9yZVNldHRpbmdzKHN0b3JlSWRbaW50ZXJvcEFwcElkKCldLCBzZXR0aW5ncyksXHJcbiAgICAgICAgZ2V0U3RhdHMsXHJcbiAgICAgICAgZ2V0U3RhdHNCeUluc3RhbmNlSWQsXHJcbiAgICAgICAgZ2V0U3RhdHNCeVN0YXJ0SW5kZXgsXHJcbiAgICAgICAgc2F2ZVN0YXRzLFxyXG4gICAgICAgIGRlbGV0ZVN0YXRzXHJcbiAgICB9O1xyXG59IiwiaW1wb3J0IGdlbmVyaWNBcGlGYWN0b3J5IGZyb20gJy4vZ2VuZXJpYyc7XHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSkge1xyXG4gICAgY29uc3QgZ2VuZXJpY0FwaSA9IGdlbmVyaWNBcGlGYWN0b3J5KHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSk7XHJcblxyXG5cclxuICAgIGNvbnN0IHRlbXBsYXRlU3RvcmVJZCA9IHtcclxuICAgICAgICAnc29mdHVuaS5iZyc6IDM1MTksXHJcbiAgICAgICAgJ2RpZ2l0YWwuc29mdHVuaS5iZyc6IDM0NDAsXHJcbiAgICAgICAgJ2NyZWF0aXZlLnNvZnR1bmkuYmcnOiAxMzAwLFxyXG4gICAgICAgICdhaS5zb2Z0dW5pLmJnJzogNyxcclxuICAgICAgICAnZmluYW5jZWFjYWRlbXkuYmcnOiA3NFxyXG4gICAgfTtcclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRUZW1wbGF0ZVN0b3JlU2V0dGluZ3MoKSB7XHJcbiAgICAgICAgcmV0dXJuIGdlbmVyaWNBcGkuZ2V0U3RvcmVTZXR0aW5ncyh0ZW1wbGF0ZVN0b3JlSWRbaW50ZXJvcEFwcElkKCldKTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiB0ZW1wbGF0ZVRvRW50cnkoZGF0YSkge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiBkYXRhLklkIHx8IDAsXHJcbiAgICAgICAgICAgIFRyYWluaW5nSWQ6IHRlbXBsYXRlU3RvcmVJZFtpbnRlcm9wQXBwSWQoKV0sXHJcbiAgICAgICAgICAgIE5hbWVCZzogJzAwMDAwMDAwMDAnICsgZGF0YS5OYW1lLFxyXG4gICAgICAgICAgICBOYW1lRW46ICcwMDAwMDAwMDAwJyArIEpTT04uc3RyaW5naWZ5KGRhdGEuQ2F0ZWdvcnkpLFxyXG4gICAgICAgICAgICBIYXNNYW51YWxOdW1iZXJPZlN0dWR5SG91cnM6IHRydWUsXHJcbiAgICAgICAgICAgIE51bWJlck9mU3R1ZHlIb3VyczogMCxcclxuICAgICAgICAgICAgSXNFeGNsdWRlZEZyb21DZXJ0aWZpY2F0ZTogZGF0YS5BY3RpdmUsXHJcbiAgICAgICAgICAgIEhhc0hvbWV3b3JrOiBmYWxzZSxcclxuICAgICAgICAgICAgUmVzb3VyY2VNYWlsc1N0YXRlOiAwLFxyXG4gICAgICAgICAgICBIb21ld29ya01haWxzU3RhdGU6IDAsXHJcbiAgICAgICAgICAgIEp1ZGdlQ29udGVzdElkOiAnJyxcclxuICAgICAgICAgICAgT3JkZXJCeTogMCxcclxuICAgICAgICAgICAgRGVzY3JpcHRpb25CZzogJzAwMDAwMDAwMDAnICsgZGF0YS5Db250ZW50LFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkVuOiAoJzAwMDAwMDAwMDAnICsgKGRhdGEuSW5zdGFuY2VJZCB8fCAnJykpLnNsaWNlKC0xMCksXHJcbiAgICAgICAgICAgIEV4Y2x1ZGVGcm9tQ2FsZW5kYXI6IGRhdGEuQ29tcG91bmQsXHJcbiAgICAgICAgICAgIEhhc0xpdmVTdHJlYW06IGZhbHNlLFxyXG4gICAgICAgICAgICBDcmVhdGVkT246ICcnLFxyXG4gICAgICAgICAgICBNb2RpZmllZE9uOiAnJ1xyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gZW50cnlUb1RlbXBsYXRlKGVudHJ5KSB7XHJcbiAgICAgICAgaWYgKGVudHJ5KSB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICBJZDogZW50cnkuSWQsXHJcbiAgICAgICAgICAgICAgICBOYW1lOiBlbnRyeS5OYW1lQmcuc2xpY2UoMTApLFxyXG4gICAgICAgICAgICAgICAgQ2F0ZWdvcnk6IEpTT04ucGFyc2UoZW50cnkuTmFtZUVuLnNsaWNlKDEwKSkgfHwgW10sXHJcbiAgICAgICAgICAgICAgICBBY3RpdmU6IGVudHJ5LklzRXhjbHVkZWRGcm9tQ2VydGlmaWNhdGUsXHJcbiAgICAgICAgICAgICAgICBDb21wb3VuZDogZW50cnkuRXhjbHVkZUZyb21DYWxlbmRhcixcclxuICAgICAgICAgICAgICAgIENvbnRlbnQ6IChlbnRyeS5EZXNjcmlwdGlvbkJnIHx8ICcnKS5zbGljZSgxMCksXHJcbiAgICAgICAgICAgICAgICBJbnN0YW5jZUlkOiBOdW1iZXIoZW50cnkuRGVzY3JpcHRpb25FbikgfHwgbnVsbFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFRlbXBsYXRlcygpIHtcclxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgZ2VuZXJpY0FwaS5nZXRFbnRyaWVzKHRlbXBsYXRlU3RvcmVJZFtpbnRlcm9wQXBwSWQoKV0pO1xyXG4gICAgICAgIHJldHVybiBkYXRhXHJcbiAgICAgICAgICAgIC5tYXAoZW50cnlUb1RlbXBsYXRlKVxyXG4gICAgICAgICAgICAuc29ydCgoYSwgYikgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuICgoYi5BY3RpdmUgPyAxIDogMCkgLSAoYS5BY3RpdmUgPyAxIDogMCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfHwgKChiLkNvbXBvdW5kID8gMSA6IDApIC0gKGEuQ29tcG91bmQgPyAxIDogMCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfHwgYS5OYW1lLmxvY2FsZUNvbXBhcmUoYi5OYW1lKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0VGVtcGxhdGVCeU5hbWUobmFtZSkge1xyXG4gICAgICAgIGNvbnN0IHRlbXBsYXRlID0gYXdhaXQgZ2VuZXJpY0FwaS5nZXRFbnRyaWVzKHRlbXBsYXRlU3RvcmVJZFtpbnRlcm9wQXBwSWQoKV0sIGBOYW1lQmd+ZXF+JyR7bmFtZX0nYCk7XHJcbiAgICAgICAgcmV0dXJuIGVudHJ5VG9UZW1wbGF0ZSh0ZW1wbGF0ZVswXSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0VGVtcGxhdGVCeUluc3RhbmNlSWQoaW5zdGFuY2VJZCkge1xyXG4gICAgICAgIGNvbnN0IHRlbXBsYXRlID0gYXdhaXQgZ2VuZXJpY0FwaS5nZXRFbnRyaWVzKHRlbXBsYXRlU3RvcmVJZFtpbnRlcm9wQXBwSWQoKV0sIGBEZXNjcmlwdGlvbkVufmVxficke2luc3RhbmNlSWR9J2ApO1xyXG4gICAgICAgIHJldHVybiBlbnRyeVRvVGVtcGxhdGUodGVtcGxhdGVbMF0pO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHNhdmVUZW1wbGF0ZSh0ZW1wbGF0ZSkge1xyXG4gICAgICAgIGNvbnN0IG9wZXJhdGlvbiA9IHRlbXBsYXRlLklkID8gZ2VuZXJpY0FwaS51cGRhdGVFbnRyeSA6IGdlbmVyaWNBcGkuY3JlYXRlRW50cnk7XHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgb3BlcmF0aW9uKHRlbXBsYXRlVG9FbnRyeSh0ZW1wbGF0ZSkpO1xyXG5cclxuICAgICAgICByZXR1cm4gZW50cnlUb1RlbXBsYXRlKHJlc3VsdC5EYXRhWzBdKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBkZWxldGVUZW1wbGF0ZSh0ZW1wbGF0ZSkge1xyXG4gICAgICAgIHJldHVybiBnZW5lcmljQXBpLmRlc3Ryb3lFbnRyeSh0ZW1wbGF0ZVRvRW50cnkodGVtcGxhdGUpKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldFRlbXBsYXRlU3RvcmVTZXR0aW5ncyxcclxuICAgICAgICBnZXRUZW1wbGF0ZXMsXHJcbiAgICAgICAgZ2V0VGVtcGxhdGVCeU5hbWUsXHJcbiAgICAgICAgZ2V0VGVtcGxhdGVCeUluc3RhbmNlSWQsXHJcbiAgICAgICAgc2F2ZVRlbXBsYXRlLFxyXG4gICAgICAgIGRlbGV0ZVRlbXBsYXRlXHJcbiAgICB9O1xyXG59IiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSkge1xyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEluc3RhbmNlQ29uZmlnKGluc3RhbmNlSWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBgaHR0cHM6Ly9zZXMtd2ViZXh0LmdpdGh1Yi5pby9zdHJlYW0vJHtpbnN0YW5jZUlkfS5qc29uYDtcclxuXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZ2V0KHVyaSk7XHJcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldEluc3RhbmNlQ29uZmlnXHJcbiAgICB9O1xyXG59IiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0IH0pIHtcclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFN1cnZleXMocGFnZSwgcXVlcnksIGZpbHRlciwgcGFnZVNpemUgPSAzMCkge1xyXG4gICAgICAgIGlmIChwYWdlU2l6ZSA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgcGFnZVNpemUgPSAzMDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IHVybCA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl9zdXJ2ZXlzL3N1cnZleXMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnQWN0aXZlVG8tZGVzYycsXHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiBwYWdlU2l6ZSxcclxuICAgICAgICAgICAgcGFnZVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGlmIChxdWVyeSkge1xyXG4gICAgICAgICAgICBib2R5LmZpbHRlciA9IGBOYW1lfmNvbnRhaW5zficke3F1ZXJ5fSdgO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGZpbHRlcikge1xyXG4gICAgICAgICAgICBib2R5LmZpbHRlciArPSBgfmFuZH4oJHtmaWx0ZXJ9KWBcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVybCwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0U3VydmV5c0J5TmFtZUFuZFN0YXJ0QW5kRW5kRGF0ZShwYWdlLCBuYW1lLCBzdGFydERhdGUsIGVuZERhdGUsIHBhZ2VTaXplID0gMzApIHtcclxuICAgICAgICBpZiAocGFnZVNpemUgPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplID0gMzA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCB1cmwgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fc3VydmV5cy9zdXJ2ZXlzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJ0FjdGl2ZVRvLWRlc2MnLFxyXG4gICAgICAgICAgICBwYWdlU2l6ZTogcGFnZVNpemUsXHJcbiAgICAgICAgICAgIHBhZ2VcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgYm9keS5maWx0ZXIgPSBgTmFtZX5jb250YWluc34nJHtuYW1lfSd+YW5kfkFjdGl2ZUZyb21+Z3RlfmRhdGV0aW1lJyR7c3RhcnREYXRlfSd+YW5kfkFjdGl2ZUZyb21+bHR+ZGF0ZXRpbWUnJHtlbmREYXRlfSdgO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmwsIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFN1cnZleUJ5SWQoc3VydmV5SWQpIHtcclxuICAgICAgICBjb25zdCB1cmwgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fc3VydmV5cy9zdXJ2ZXlzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgZmlsdGVyOiAnSWR+ZXF+JyArIHN1cnZleUlkLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmwsIGJvZHkpKS5EYXRhWzBdO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFN1cnZleUFuc3dlcnMoc3VydmV5SWQpIHtcclxuICAgICAgICBjb25zdCB1cmwgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fc3VydmV5cy91c2VycG9sbGFuc3dlcnMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJ1N1cnZleUlkfmVxficgKyBzdXJ2ZXlJZFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmwsIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFN1cnZleVRlbXBsYXRlcygpIHtcclxuICAgICAgICBjb25zdCB1cmwgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fc3VydmV5cy9zdXJ2ZXlzZWN0aW9udGVtcGxhdGVzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAwLFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmwsIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFN1cnZleVF1ZXN0aW9uc0J5VGVtcGxhdGVJZCh0ZW1wbGF0ZUlkKSB7XHJcbiAgICAgICAgY29uc3QgdXJsID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3N1cnZleXMvcG9sbHF1ZXN0aW9ucy9yZWFkcG9sbHF1ZXN0aW9ucz9zdXJ2ZXlTZWN0aW9uVGVtcGxhdGVJZD0ke3RlbXBsYXRlSWR9YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwMCxcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJsLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRTdXJ2ZXlTZWN0aW9uc0J5VGVtcGxhdGVJZCh0ZW1wbGF0ZUlkKSB7XHJcbiAgICAgICAgY29uc3QgdXJsID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3N1cnZleXMvc3VydmV5c2VjdGlvbnMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogYFN1cnZleVNlY3Rpb25UZW1wbGF0ZUlkfmVxfiR7dGVtcGxhdGVJZH1gXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVybCwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0U3VydmV5U2VjdGlvbnNCeUlkKHNlY3Rpb25JZCkge1xyXG4gICAgICAgIGNvbnN0IHVybCA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl9zdXJ2ZXlzL3N1cnZleXNlY3Rpb25zL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAwLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGBJZH5lcX4ke0FycmF5LmlzQXJyYXkoc2VjdGlvbklkKSA/IHNlY3Rpb25JZC5qb2luKCd+b3J+SWR+ZXF+JykgOiBzZWN0aW9uSWR9YFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmwsIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGZpbmRTZWN0aW9uc0J5VHJhaW5pbmcobmFtZUJnKSB7XHJcbiAgICAgICAgY29uc3QgdXJsID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3N1cnZleXMvc3VydmV5c2VjdGlvbnMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGBUcmFpbmluZ35lcX4nJHtuYW1lQmd9J35hbmR+TmFtZX5kb2Vzbm90Y29udGFpbn4n0L7QsdGB0LvRg9C20LLQsNC90LUnfmFuZH5OYW1lfmRvZXNub3Rjb250YWlufifQuNC90YTQvtGA0LzQsNGG0LjRjyd+YW5kfk5hbWV+ZG9lc25vdGNvbnRhaW5+J9GB0LLRitGA0LfQsNC90Lgg0YEg0LrRg9GA0YHQsCdgXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVybCwgYm9keSkpLkRhdGEubWFwKHMgPT4gcy5OYW1lKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBmaW5kQW5zd2Vyc0J5U2VjdGlvbihzZWN0aW9uTmFtZXMpIHtcclxuICAgICAgICBjb25zdCB1cmwgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fc3VydmV5cy91c2VycG9sbGFuc3dlcnMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJ1NlY3Rpb25+ZXF+XFwnJyArIHNlY3Rpb25OYW1lcy5qb2luKCdcXCd+b3J+U2VjdGlvbn5lcX5cXCcnKSArICdcXCcnXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmwsIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGZpbmRTdXJ2ZXlCeVRyYWluaW5nKG5hbWVCZykge1xyXG4gICAgICAgIGNvbnN0IHNlY3Rpb25zID0gYXdhaXQgZmluZFNlY3Rpb25zQnlUcmFpbmluZyhuYW1lQmcpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKHNlY3Rpb25zKTtcclxuICAgICAgICBjb25zdCBhbnN3ZXJzID0gYXdhaXQgZmluZEFuc3dlcnNCeVNlY3Rpb24oc2VjdGlvbnMpO1xyXG4gICAgICAgIGNvbnN0IHN1cnZleXMgPSBbLi4uYW5zd2Vycy5yZWR1Y2UoKHAsIGMpID0+IHsgcC5hZGQoYy5TdXJ2ZXlJZCk7IHJldHVybiBwOyB9LCBuZXcgU2V0KCkpXTtcclxuXHJcbiAgICAgICAgcmV0dXJuIFByb21pc2UuYWxsKHN1cnZleXMubWFwKGdldFN1cnZleUJ5SWQpKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldFN1cnZleXMsXHJcbiAgICAgICAgZ2V0U3VydmV5c0J5TmFtZUFuZFN0YXJ0QW5kRW5kRGF0ZSxcclxuICAgICAgICBnZXRTdXJ2ZXlCeUlkLFxyXG4gICAgICAgIGdldFN1cnZleUFuc3dlcnMsXHJcbiAgICAgICAgZ2V0U3VydmV5VGVtcGxhdGVzLFxyXG4gICAgICAgIGdldFN1cnZleVF1ZXN0aW9uc0J5VGVtcGxhdGVJZCxcclxuICAgICAgICBnZXRTdXJ2ZXlTZWN0aW9uc0J5VGVtcGxhdGVJZCxcclxuICAgICAgICBnZXRTdXJ2ZXlTZWN0aW9uc0J5SWQsXHJcbiAgICAgICAgZmluZFN1cnZleUJ5VHJhaW5pbmdcclxuICAgIH07XHJcbn0iLCJpbXBvcnQgeyBwYXJzZUNyb3NzQnJvd3NlckZpbGUgfSBmcm9tICcuLi91dGlsJztcclxuXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KSB7XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0SG9tZXdvcmtSZXN1bHRzKGluc3RhbmNlSWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fY3JtL2ludGVybmFsY291cnNlY3JtcHJvZmlsZXMvcmVhZGludGVybmFsY291cnNlY3JtcHJvZmlsZXMvJHtpbnN0YW5jZUlkfWApO1xyXG5cclxuICAgICAgICByZXR1cm4gYXdhaXQgZmV0Y2hOZXh0KCk7XHJcblxyXG4gICAgICAgIGFzeW5jIGZ1bmN0aW9uIGZldGNoTmV4dChwYWdlID0gMSkge1xyXG4gICAgICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgICAgIHNvcnQ6ICdDcmVhdGVkT24tZGVzYycsXHJcbiAgICAgICAgICAgICAgICBwYWdlU2l6ZTogMTAwMCxcclxuICAgICAgICAgICAgICAgIHBhZ2VcclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHBvc3QodXJpLCBib2R5KTtcclxuXHJcbiAgICAgICAgICAgIGxldCByZXN1bHQgPSByZXNwb25zZS5EYXRhO1xyXG5cclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLlRvdGFsID4gcGFnZSAqIDEwMDApIHtcclxuICAgICAgICAgICAgICAgIHJlc3VsdCA9IHJlc3VsdC5jb25jYXQoYXdhaXQgZmV0Y2hOZXh0KHBhZ2UgKyAxKSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFByb3RvY29sKGluc3RhbmNlSWQpIHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdXNlcnNpbmNvdXJzZXMvZXhwb3J0dHJhaW5pbmdwcm90b2NvbC8ke2luc3RhbmNlSWR9YCksIHtcclxuICAgICAgICAgICAgJ2NyZWRlbnRpYWxzJzogJ2luY2x1ZGUnLFxyXG4gICAgICAgICAgICAnaGVhZGVycyc6IHtcclxuICAgICAgICAgICAgICAgICdIb3N0JzogJ3NvZnR1bmkuYmcnLFxyXG4gICAgICAgICAgICAgICAgJ1VzZXItQWdlbnQnOiAnTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NDsgcnY6OTcuMCkgR2Vja28vMjAxMDAxMDEgRmlyZWZveC85Ny4wJyxcclxuICAgICAgICAgICAgICAgICdBY2NlcHQnOiAndGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2UvYXZpZixpbWFnZS93ZWJwLCovKjtxPTAuOCcsXHJcbiAgICAgICAgICAgICAgICAnQWNjZXB0LUxhbmd1YWdlJzogJ2VuLVVTLGVuO3E9MC41JyxcclxuICAgICAgICAgICAgICAgICdBY2NlcHQtRW5jb2RpbmcnOiAnZ3ppcCwgZGVmbGF0ZSwgYnInLFxyXG4gICAgICAgICAgICAgICAgJ0Nvbm5lY3Rpb24nOiAna2VlcC1hbGl2ZScsXHJcbiAgICAgICAgICAgICAgICAnUmVmZXJlcic6IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdXNlcnNpbnRyYWluaW5nc21hbmFnZW1lbnQnKSxcclxuICAgICAgICAgICAgICAgICdVcGdyYWRlLUluc2VjdXJlLVJlcXVlc3RzJzogMSxcclxuICAgICAgICAgICAgICAgICdTZWMtRmV0Y2gtRGVzdCc6ICdkb2N1bWVudCcsXHJcbiAgICAgICAgICAgICAgICAnU2VjLUZldGNoLU1vZGUnOiAnbmF2aWdhdGUnLFxyXG4gICAgICAgICAgICAgICAgJ1NlYy1GZXRjaC1TaXRlJzogJ3NhbWUtb3JpZ2luJyxcclxuICAgICAgICAgICAgICAgICdTZWMtRmV0Y2gtVXNlcic6ICc/MScsXHJcbiAgICAgICAgICAgICAgICAnUHJhZ21hJzogJ25vLWNhY2hlJyxcclxuICAgICAgICAgICAgICAgICdDYWNoZS1Db250cm9sJzogJ25vLWNhY2hlJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAnbWV0aG9kJzogJ0dFVCcsXHJcbiAgICAgICAgICAgICdtb2RlJzogJ2NvcnMnXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGNvbnN0IGJsb2IgPSBhd2FpdCByZXNwb25zZS5ibG9iKCk7XHJcbiAgICAgICAgY29uc3Qgc2VyaWFsaXplZEJsb2IgPSBuZXcgVWludDhBcnJheShhd2FpdCBibG9iLmFycmF5QnVmZmVyKCkpO1xyXG4gIFxyXG4gICAgICAgIGNvbnN0IGJsb2JEYXRhID0ge1xyXG4gICAgICAgICAgICB0eXBlOiBibG9iLnR5cGUsXHJcbiAgICAgICAgICAgIGJ1ZmZlcjogQXJyYXkuZnJvbShzZXJpYWxpemVkQmxvYilcclxuICAgICAgICB9O1xyXG4gICAgICAgIFxyXG4gICAgICAgIHJldHVybiBibG9iRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB1cGxvYWRGaWxlKHVybCwgZm9ybURhdGEpIHtcclxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBmZXRjaCh1cmwsIHtcclxuICAgICAgICAgICAgY3JlZGVudGlhbHM6ICdpbmNsdWRlJyxcclxuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgICAgIGJvZHk6IGZvcm1EYXRhLFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHVwbG9hZEV4YW1SZXN1bHRzKGV4YW1OYW1lLCBleGFtSWQsIGNvbWJvLCBmaWxlRGVzY3JpcHRvcikge1xyXG4gICAgICAgIGNvbnN0IHVybCA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvZXhhbXMvaW1wb3J0ZXhhbXJlc3VsdHMnKTtcclxuICAgICAgICBjb25zdCB7IGJsb2IsIGZpbGVuYW1lIH0gPSBhd2FpdCBwYXJzZUNyb3NzQnJvd3NlckZpbGUoZmlsZURlc2NyaXB0b3IpO1xyXG5cclxuICAgICAgICBjb25zdCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xyXG5cclxuICAgICAgICBjb25zdCBydnQgPSBhd2FpdCBvYnRhaW5SVlQoKTtcclxuXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdfX1JlcXVlc3RWZXJpZmljYXRpb25Ub2tlbicsIHJ2dCk7XHJcblxyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnRXhhbUlkX2lucHV0JywgZXhhbU5hbWUpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnRXhhbUlkJywgZXhhbUlkKTtcclxuXHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdSZXN1bHRzRmlsZScsIGJsb2IsIGZpbGVuYW1lKTtcclxuXHJcbiAgICAgICAgaWYgKGNvbWJvLmltcG9ydFByYWN0aWNlKSB7XHJcbiAgICAgICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnSW1wb3J0UHJlZmVyZW5jZXMnLCAxKTsgICAgLy8gUHJhY3RpY2VcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGNvbWJvLmltcG9ydFF1aXopIHtcclxuICAgICAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdJbXBvcnRQcmVmZXJlbmNlcycsIDIpOyAgICAvLyBRdWl6XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ1VzZXJuYW1lQ29sdW1uJywgMSk7XHJcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdSZXN1bHRDb2x1bW4nLCAyKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ0NvbW1lbnRDb2x1bW4nLCAzKTtcclxuICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ1RoZW9yeVJlc3VsdENvbHVtbicsIDQpO1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnVGhlb3J5Q29tbWVudENvbHVtbicsIDUpO1xyXG5cclxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB1cGxvYWRGaWxlKHVybCwgZm9ybURhdGEpO1xyXG4gICAgICAgIHJldHVybiBwcm9jZXNzRXhhbVJlc3VsdE91dGNvbWUocmVzdWx0KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBwcm9jZXNzRXhhbVJlc3VsdE91dGNvbWUocmVzdWx0KSB7XHJcbiAgICAgICAgY29uc3QgcGFnZSA9IGF3YWl0IHJlc3VsdC50ZXh0KCk7XHJcblxyXG4gICAgICAgIGNvbnN0IHN1Y2Nlc3NQYXR0ZXJuID0gLzxoMz7Qo9GB0L/QtdGI0L3QuCDQt9Cw0L/QuNGB0Lg6KC4rPyk8XFwvaDM+L3VzO1xyXG4gICAgICAgIGNvbnN0IGZhaWx1cmVQYXR0ZXJuID0gLzxoMz7QndC10YPRgdC/0LXRiNC90Lgg0LfQsNC/0LjRgdC4OiguKz8pPFxcL2gzPi91cztcclxuICAgICAgICBjb25zdCB1c2VybGlzdFBhdHRlcm4gPSAvPHA+Lio/0KPRgdC/0LXRiNC90L4g0LHRj9GF0LAg0LLQvNGK0LrQvdCw0YLQuCDRgNC10LfRg9C70YLQsNGC0LjRgtC1INC90LAg0YHQu9C10LTQvdC40YLQtSDQv9C+0YLRgNC10LHQuNGC0LXQu9C4OiguKz8pPFxcL3A+L3VzO1xyXG5cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb25zdCBzdWNjZXNzZnVsID0gTnVtYmVyKHN1Y2Nlc3NQYXR0ZXJuLmV4ZWMocGFnZSlbMV0udHJpbSgpKTtcclxuICAgICAgICAgICAgY29uc3QgZmFpbGVkID0gTnVtYmVyKGZhaWx1cmVQYXR0ZXJuLmV4ZWMocGFnZSlbMV0udHJpbSgpKTtcclxuICAgICAgICAgICAgY29uc3QgbGlzdCA9IHVzZXJsaXN0UGF0dGVybi5leGVjKHBhZ2UpWzFdLnRyaW0oKS5zcGxpdCgnLCcpLm1hcCh1ID0+IHUudHJpbSgpKTtcclxuXHJcbiAgICAgICAgICAgIHJldHVybiB7IHN1Y2Nlc3NmdWwsIGZhaWxlZCwgbGlzdCB9O1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignRXJyb3IgcHJvY2Vzc2luZyBmaWxlJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIG9idGFpblJWVCgpIHtcclxuICAgICAgICBjb25zdCB1cmwgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2V4YW1zL2ltcG9ydGV4YW1yZXN1bHRzJyk7XHJcbiAgICAgICAgY29uc3QgcGFnZURhdGEgPSBhd2FpdCBnZXQodXJsKTtcclxuICAgICAgICBjb25zdCBwYXR0ZXJuID0gLzxpbnB1dC4qP25hbWU9XCJfX1JlcXVlc3RWZXJpZmljYXRpb25Ub2tlblwiLio/dmFsdWU9XCIoLis/KVwiLio/Pi9pO1xyXG4gICAgICAgIGNvbnN0IHJ2dCA9IHBhdHRlcm4uZXhlYyhwYWdlRGF0YSlbMV07XHJcblxyXG4gICAgICAgIHJldHVybiBydnQ7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBnZXRIb21ld29ya1Jlc3VsdHMsXHJcbiAgICAgICAgZ2V0UHJvdG9jb2wsXHJcbiAgICAgICAgdXBsb2FkRXhhbVJlc3VsdHNcclxuICAgIH07XHJcbn1cclxuIiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSkge1xyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0RXZlbnRzKGluc3RhbmNlSWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3RyYWluaW5nZ3JvdXBsZWN0dXJlcy9yZWFkJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICdTdGFydERhdGVUaW1lLWFzYycsXHJcbiAgICAgICAgICAgIHBhZ2U6IDEsXHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiBgVHJhaW5pbmdJZH5lcX4ke2luc3RhbmNlSWR9YFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB1cGRhdGVFdmVudChldmVudCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdHJhaW5pbmdncm91cGxlY3R1cmVzL3VwZGF0ZScpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnLFxyXG4gICAgICAgICAgICBJZDogZXZlbnQuSWQsXHJcbiAgICAgICAgICAgIFRyYWluaW5nR3JvdXBJZDogZXZlbnQuVHJhaW5pbmdHcm91cElkLFxyXG4gICAgICAgICAgICBUcmFpbmluZ0dyb3VwTmFtZTogZXZlbnQuVHJhaW5pbmdHcm91cE5hbWUsXHJcbiAgICAgICAgICAgIExlY3R1cmVJZDogZXZlbnQuTGVjdHVyZUlkLFxyXG4gICAgICAgICAgICBMZWN0dXJlTmFtZTogZXZlbnQuTGVjdHVyZU5hbWUsXHJcbiAgICAgICAgICAgIFRyYWluaW5nSWQ6IGV2ZW50LlRyYWluaW5nSWQsXHJcbiAgICAgICAgICAgIFN0YXJ0RGF0ZVRpbWU6IGV2ZW50LlN0YXJ0RGF0ZVRpbWUsXHJcbiAgICAgICAgICAgIEVuZERhdGVUaW1lOiBldmVudC5FbmREYXRlVGltZSxcclxuICAgICAgICAgICAgSGFzTGl2ZVN0cmVhbTogZXZlbnQuSGFzTGl2ZVN0cmVhbSxcclxuICAgICAgICAgICAgVHJhaW5pbmdMYWJJZDogZXZlbnQuVHJhaW5pbmdMYWJJZCxcclxuICAgICAgICAgICAgVHJhaW5pbmdMYWJOYW1lOiBldmVudC5UcmFpbmluZ0xhYk5hbWUsXHJcbiAgICAgICAgICAgIExhc3RFZGl0ZWRVc2VybmFtZTogJycsXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogJycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcnLFxyXG4gICAgICAgICAgICBUcmFpbmluZ0dyb3VwSWRfaW5wdXQ6ICcnLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBjcmVhdGVFdmVudChldmVudCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdHJhaW5pbmdncm91cGxlY3R1cmVzL2NyZWF0ZScpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnLFxyXG4gICAgICAgICAgICBJZDogZXZlbnQuSWQsXHJcbiAgICAgICAgICAgIFRyYWluaW5nR3JvdXBJZDogZXZlbnQuVHJhaW5pbmdHcm91cElkLFxyXG4gICAgICAgICAgICBUcmFpbmluZ0dyb3VwTmFtZTogZXZlbnQuVHJhaW5pbmdHcm91cE5hbWUsXHJcbiAgICAgICAgICAgIExlY3R1cmVJZDogZXZlbnQuTGVjdHVyZUlkLFxyXG4gICAgICAgICAgICBMZWN0dXJlTmFtZTogZXZlbnQuTGVjdHVyZU5hbWUsXHJcbiAgICAgICAgICAgIFRyYWluaW5nSWQ6IGV2ZW50LlRyYWluaW5nSWQsXHJcbiAgICAgICAgICAgIFN0YXJ0RGF0ZVRpbWU6IGV2ZW50LlN0YXJ0RGF0ZVRpbWUsXHJcbiAgICAgICAgICAgIEVuZERhdGVUaW1lOiBldmVudC5FbmREYXRlVGltZSxcclxuICAgICAgICAgICAgSGFzTGl2ZVN0cmVhbTogZXZlbnQuSGFzTGl2ZVN0cmVhbSxcclxuICAgICAgICAgICAgVHJhaW5pbmdMYWJJZDogZXZlbnQuVHJhaW5pbmdMYWJJZCxcclxuICAgICAgICAgICAgVHJhaW5pbmdMYWJOYW1lOiBldmVudC5UcmFpbmluZ0xhYk5hbWUsXHJcbiAgICAgICAgICAgIExhc3RFZGl0ZWRVc2VybmFtZTogJycsXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogJycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcnLFxyXG4gICAgICAgICAgICBUcmFpbmluZ0dyb3VwSWRfaW5wdXQ6ICcnLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBkZXN0cm95RXZlbnQoZXZlbnQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3RyYWluaW5nZ3JvdXBsZWN0dXJlcy9kZXN0cm95Jyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJydcclxuICAgICAgICB9KTtcclxuICAgICAgICBPYmplY3QuYXNzaWduKGJvZHksIGV2ZW50KTtcclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCkgeyBib2R5W2tdID0gJyc7IH0gfSk7XHJcbiAgICAgICAgYm9keS5DcmVhdGVkT24gPSAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnO1xyXG4gICAgICAgIGJvZHkuTW9kaWZpZWRPbiA9ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNyc7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0RXZlbnRzQnlEYXRlKHN0YXJ0RGF0ZSwgZW5kRGF0ZSkge1xyXG4gICAgICAgIC8vIERhdGUgZm9ybWF0IHl5eXktbW0tZGQgZXhhbXBsZTogMjAyMC0wMy0yNVxyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdHJhaW5pbmdncm91cGxlY3R1cmVzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJ1N0YXJ0RGF0ZVRpbWUtYXNjJyxcclxuICAgICAgICAgICAgcGFnZTogMSxcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAwLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogYFN0YXJ0RGF0ZVRpbWV+Z3RlfmRhdGV0aW1lJyR7c3RhcnREYXRlfVQwMC0wMC0wMCd+YW5kfkVuZERhdGVUaW1lfmx0ZX5kYXRldGltZScke2VuZERhdGV9VDIzLTU5LTU5J2BcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0RXZlbnRzQnlJZChldmVudElkKSB7XHJcbiAgICAgICAgLy8gRGF0ZSBmb3JtYXQgeXl5eS1tbS1kZCBleGFtcGxlOiAyMDIwLTAzLTI1XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy90cmFpbmluZ2dyb3VwbGVjdHVyZXMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnU3RhcnREYXRlVGltZS1hc2MnLFxyXG4gICAgICAgICAgICBwYWdlOiAxLFxyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMCxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGBJZH5lcX4ke2V2ZW50SWR9YFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldEV2ZW50cyxcclxuICAgICAgICB1cGRhdGVFdmVudCxcclxuICAgICAgICBjcmVhdGVFdmVudCxcclxuICAgICAgICBkZXN0cm95RXZlbnQsXHJcbiAgICAgICAgZ2V0RXZlbnRzQnlEYXRlLFxyXG4gICAgICAgIGdldEV2ZW50c0J5SWRcclxuICAgIH07XHJcbn0iLCJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KSB7XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0RXhhbXNCeUlkKGlkcykge1xyXG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KGlkcykgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgaWRzID0gW2lkc107XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChpZHMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuIFtdO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2V4YW1zL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAwLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGBJZH5lcX4ke2lkcy5qb2luKCd+b3J+SWR+ZXF+Jyl9YFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRFeGFtc0J5Q291cnNlKG5hbWVCZywgaW5zdGFuY2VJZCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvZXhhbXMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChpbnRlcm9wQXBwSWQoKSA9PT0gJ3NvZnR1bmkuYmcnKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gYFRyYWluaW5nTmFtZXNTdHJpbmd+Y29udGFpbnN+JyR7bmFtZUJnfSdgO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuICcnO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSkoKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAwLFxyXG4gICAgICAgICAgICBmaWx0ZXJcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvc3QodXJpLCBib2R5KTtcclxuICAgICAgICByZXR1cm4gZGF0YS5EYXRhLmZpbHRlcihlID0+IGUuUHJpbWFyeVRyYWluaW5ncy5maWx0ZXIodCA9PiB0LklkID09IGluc3RhbmNlSWQpLmxlbmd0aCA+IDAgfHwgZS5SZXRha2VuVHJhaW5pbmdzLmZpbHRlcih0ID0+IHQuSWQgPT0gaW5zdGFuY2VJZCkubGVuZ3RoID4gMCk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0RXhhbXNCeU5hbWUocXVlcnkpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2V4YW1zL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSAoKCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShxdWVyeSkpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBgKE5hbWVCZ35jb250YWluc34nJHtxdWVyeS5qb2luKCdcXCd+b3J+TmFtZUJnfmNvbnRhaW5zflxcJycpfScpfm9yfihOYW1lRW5+Y29udGFpbnN+JyR7cXVlcnkuam9pbignXFwnfm9yfk5hbWVFbn5jb250YWluc35cXCcnKX0nKWA7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gYE5hbWVCZ35jb250YWluc34nJHtxdWVyeX0nfm9yfk5hbWVFbn5jb250YWluc34nJHtxdWVyeX0nYDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICdDcmVhdGVkT24tZGVzYycsXHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAyMCxcclxuICAgICAgICAgICAgZmlsdGVyXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkocXVlcnkpKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGZ1bGxNYXRjaCA9IGF3YWl0IGdldEV4YW1zQnlOYW1lKHF1ZXJ5LmpvaW4oJyAnKSk7XHJcbiAgICAgICAgICAgIGNvbnN0IGZpbHRlcmVkID0gZGF0YS5EYXRhLmZpbHRlcihyID0+IGZ1bGxNYXRjaC5zb21lKHggPT4geC5JZCA9PSByLklkKSA9PSBmYWxzZSk7XHJcbiAgICAgICAgICAgIHJldHVybiBmdWxsTWF0Y2guY29uY2F0KGZpbHRlcmVkLnNsaWNlKDAsIDIwIC0gZnVsbE1hdGNoLmxlbmd0aCkpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiBkYXRhLkRhdGE7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEV4YW1Hcm91cHNCeUV4YW1JZChleGFtSWQpIHtcclxuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShleGFtSWQpID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIGV4YW1JZCA9IFtleGFtSWRdO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoZXhhbUlkLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBbXTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9leGFtZ3JvdXBzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMDAwLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGBFeGFtSWR+ZXF+JHtleGFtSWQuam9pbignfm9yfkV4YW1JZH5lcX4nKX1gXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmksIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEV4YW1Hcm91cHNCeURhdGUoc3RhcnREYXRlLCBlbmREYXRlKSB7XHJcbiAgICAgICAgLy8gRGF0ZSBmb3JtYXQgeXl5eS1tbS1kZCBleGFtcGxlOiAyMDIwLTAzLTI1XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9leGFtZ3JvdXBzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJ1N0YXJ0VGltZS1hc2MnLFxyXG4gICAgICAgICAgICBwYWdlOiAxLFxyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDAsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiBgU3RhcnRUaW1lfmd0ZX5kYXRldGltZScke3N0YXJ0RGF0ZX1UMDAtMDAtMDAnfmFuZH5FbmRUaW1lfmx0ZX5kYXRldGltZScke2VuZERhdGV9VDIzLTU5LTU5J2BcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0RW5yb2xsZWRCeUdyb3VwSWQoZXhhbUdyb3VwSWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2V4YW1ncm91cHBhcnRpY2lwYW50cy9yZWFkP2ZvcmVpZ25LZXlJZD0ke2V4YW1Hcm91cElkfWApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDBcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gY3JlYXRlRXhhbShleGFtKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9leGFtcy9jcmVhdGUnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgSWQ6IGV4YW0uSWQsXHJcbiAgICAgICAgICAgIE5hbWVCZzogZXhhbS5OYW1lQmcsXHJcbiAgICAgICAgICAgIE5hbWVFbjogZXhhbS5OYW1lRW4sXHJcbiAgICAgICAgICAgIFR5cGU6IGV4YW0uVHlwZSxcclxuICAgICAgICAgICAgQWxsb3dDaG9vc2luZ1NlYXRzV2l0aENvbXB1dGVyOiBleGFtLkFsbG93Q2hvb3NpbmdTZWF0c1dpdGhDb21wdXRlcixcclxuICAgICAgICAgICAgQWxsb3dBbGxVc2Vyc0luVHJhaW5pbmdzVG9TaXRFeGFtOiBleGFtLkFsbG93QWxsVXNlcnNJblRyYWluaW5nc1RvU2l0RXhhbSxcclxuICAgICAgICAgICAgRXhhbUdyb3VwRW5yb2xsbWVudERlYWRsaW5lOiBleGFtLkV4YW1Hcm91cEVucm9sbG1lbnREZWFkbGluZSxcclxuICAgICAgICAgICAgVHJhaW5pbmdOYW1lc1N0cmluZzogJycsXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogJycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcnXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICAvLyBUd28tc3RlcCBwcm9jZXNzIGlzIG5lY2Vzc2FyeSBiZWNhdXNlIG9mIGEgc2VydmVyIGJ1ZyB3aGVuIHRoZSBleGFtIGhhcyBhc3NvY2lhdGVkIHRyYWluaW5nIGluc3RhbmNlc1xyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHBvc3QodXJpLCBib2R5KTtcclxuICAgICAgICBpZiAocmVzdWx0LkVycm9ycyAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGl0ZW0gPSByZXN1bHQuRGF0YVswXTtcclxuICAgICAgICAgICAgaXRlbS5QcmltYXJ5VHJhaW5pbmdzID0gZXhhbS5QcmltYXJ5VHJhaW5pbmdzO1xyXG4gICAgICAgICAgICBpdGVtLlJldGFrZW5UcmFpbmluZ3MgPSBleGFtLlJldGFrZW5UcmFpbmluZ3M7XHJcblxyXG4gICAgICAgICAgICBjb25zdCBkZWFkbGluZSA9IG5ldyBEYXRlKE51bWJlcihpdGVtLkV4YW1Hcm91cEVucm9sbG1lbnREZWFkbGluZS5tYXRjaCgvXFxkKy8pWzBdKSk7XHJcbiAgICAgICAgICAgIGl0ZW0uRXhhbUdyb3VwRW5yb2xsbWVudERlYWRsaW5lID0gTnVtYmVyLmlzTmFOKGRlYWRsaW5lKSA/ICcnIDogZGVhZGxpbmUudG9JU09TdHJpbmcoKTtcclxuXHJcbiAgICAgICAgICAgIHJldHVybiB1cGRhdGVFeGFtKGl0ZW0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB1cGRhdGVFeGFtKGV4YW0pIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2V4YW1zL3VwZGF0ZScpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnLFxyXG4gICAgICAgICAgICBJZDogZXhhbS5JZCxcclxuICAgICAgICAgICAgTmFtZUJnOiBleGFtLk5hbWVCZyxcclxuICAgICAgICAgICAgTmFtZUVuOiBleGFtLk5hbWVFbixcclxuICAgICAgICAgICAgVHlwZTogZXhhbS5UeXBlLFxyXG4gICAgICAgICAgICBBbGxvd0Nob29zaW5nU2VhdHNXaXRoQ29tcHV0ZXI6IGV4YW0uQWxsb3dDaG9vc2luZ1NlYXRzV2l0aENvbXB1dGVyLFxyXG4gICAgICAgICAgICBBbGxvd0FsbFVzZXJzSW5UcmFpbmluZ3NUb1NpdEV4YW06IGV4YW0uQWxsb3dBbGxVc2Vyc0luVHJhaW5pbmdzVG9TaXRFeGFtLFxyXG4gICAgICAgICAgICBFeGFtR3JvdXBFbnJvbGxtZW50RGVhZGxpbmU6IGV4YW0uRXhhbUdyb3VwRW5yb2xsbWVudERlYWRsaW5lLFxyXG4gICAgICAgICAgICBUcmFpbmluZ05hbWVzU3RyaW5nOiAnJyxcclxuICAgICAgICAgICAgQ3JlYXRlZE9uOiAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnLFxyXG4gICAgICAgICAgICBNb2RpZmllZE9uOiAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICBleGFtLlByaW1hcnlUcmFpbmluZ3MuZm9yRWFjaCh0cmFpbmluZ3NUb0JvZHkoJ1ByaW1hcnlUcmFpbmluZ3MnKSk7XHJcbiAgICAgICAgZXhhbS5SZXRha2VuVHJhaW5pbmdzLmZvckVhY2godHJhaW5pbmdzVG9Cb2R5KCdSZXRha2VuVHJhaW5pbmdzJykpO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG5cclxuICAgICAgICBmdW5jdGlvbiB0cmFpbmluZ3NUb0JvZHkocHJvcE5hbWUpIHtcclxuICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICh0cmFpbmluZywgaW5kZXgpIHtcclxuICAgICAgICAgICAgICAgIGJvZHlbYCR7cHJvcE5hbWV9WyR7aW5kZXh9XS5JZGBdID0gdHJhaW5pbmcuSWQ7XHJcbiAgICAgICAgICAgICAgICBib2R5W2Ake3Byb3BOYW1lfVske2luZGV4fV0uTmFtZWBdID0gdHJhaW5pbmcuTmFtZUJnO1xyXG4gICAgICAgICAgICAgICAgYm9keVtgJHtwcm9wTmFtZX1bJHtpbmRleH1dLk5hbWVCZ2BdID0gdHJhaW5pbmcuTmFtZUJnO1xyXG4gICAgICAgICAgICAgICAgYm9keVtgJHtwcm9wTmFtZX1bJHtpbmRleH1dLk5hbWVFbmBdID0gdHJhaW5pbmcuTmFtZUVuO1xyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBjcmVhdGVFeGFtR3JvdXAoZ3JvdXApIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2V4YW1ncm91cHMvY3JlYXRlJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiAnMCcsXHJcbiAgICAgICAgICAgIEV4YW1JZDogZ3JvdXAuRXhhbUlkLFxyXG4gICAgICAgICAgICBFeGFtTmFtZTogJycsXHJcbiAgICAgICAgICAgIFN0YXJ0VGltZTogZ3JvdXAuU3RhcnRUaW1lLFxyXG4gICAgICAgICAgICBFbmRUaW1lOiBncm91cC5FbmRUaW1lLFxyXG4gICAgICAgICAgICBUcmFpbmluZ0xhYklkOiBncm91cC5UcmFpbmluZ0xhYklkLFxyXG4gICAgICAgICAgICBKdWRnZVN5c3RlbUNvbnRlc3RJZDogZ3JvdXAuSnVkZ2VTeXN0ZW1Db250ZXN0SWQsXHJcbiAgICAgICAgICAgIFRlc3RTeXN0ZW1UZXN0SWQ6IGdyb3VwLlRlc3RTeXN0ZW1UZXN0SWQsXHJcbiAgICAgICAgICAgIEV4YW1Hcm91cFBhcnRpY2lwYW50c0NvdW50OiBncm91cC5FeGFtR3JvdXBQYXJ0aWNpcGFudHNDb3VudCxcclxuICAgICAgICAgICAgTGltaXQ6IGdyb3VwLkxpbWl0LFxyXG4gICAgICAgICAgICBJc0FkZGVkVG9Hb29nbGVDYWxlbmRhcjogZ3JvdXAuSXNBZGRlZFRvR29vZ2xlQ2FsZW5kYXIsXHJcbiAgICAgICAgICAgIEN1c3RvbUVucm9sbG1lbnRTdWNjZXNzTWVzc2FnZTogZ3JvdXAuQ3VzdG9tRW5yb2xsbWVudFN1Y2Nlc3NNZXNzYWdlLFxyXG4gICAgICAgICAgICBDcmVhdGVkT246ICcnLFxyXG4gICAgICAgICAgICBNb2RpZmllZE9uOiAnJ1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB1cGRhdGVFeGFtR3JvdXAoZ3JvdXApIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2V4YW1ncm91cHMvdXBkYXRlJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiBncm91cC5JZCxcclxuICAgICAgICAgICAgRXhhbUlkOiBncm91cC5FeGFtSWQsXHJcbiAgICAgICAgICAgIEV4YW1OYW1lOiBncm91cC5FeGFtTmFtZSxcclxuICAgICAgICAgICAgU3RhcnRUaW1lOiBncm91cC5TdGFydFRpbWUsXHJcbiAgICAgICAgICAgIEVuZFRpbWU6IGdyb3VwLkVuZFRpbWUsXHJcbiAgICAgICAgICAgIFRyYWluaW5nTGFiSWQ6IGdyb3VwLlRyYWluaW5nTGFiSWQsXHJcbiAgICAgICAgICAgIEp1ZGdlU3lzdGVtQ29udGVzdElkOiBncm91cC5KdWRnZVN5c3RlbUNvbnRlc3RJZCxcclxuICAgICAgICAgICAgVGVzdFN5c3RlbVRlc3RJZDogZ3JvdXAuVGVzdFN5c3RlbVRlc3RJZCxcclxuICAgICAgICAgICAgRXhhbUdyb3VwUGFydGljaXBhbnRzQ291bnQ6IGdyb3VwLkV4YW1Hcm91cFBhcnRpY2lwYW50c0NvdW50LFxyXG4gICAgICAgICAgICBMaW1pdDogZ3JvdXAuTGltaXQsXHJcbiAgICAgICAgICAgIElzQWRkZWRUb0dvb2dsZUNhbGVuZGFyOiBncm91cC5Jc0FkZGVkVG9Hb29nbGVDYWxlbmRhcixcclxuICAgICAgICAgICAgQ3VzdG9tRW5yb2xsbWVudFN1Y2Nlc3NNZXNzYWdlOiBncm91cC5DdXN0b21FbnJvbGxtZW50U3VjY2Vzc01lc3NhZ2UsXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JyxcclxuICAgICAgICAgICAgTW9kaWZpZWRPbjogJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3J1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBkZXN0cm95RXhhbUdyb3VwKGdyb3VwKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9leGFtZ3JvdXBzL2Rlc3Ryb3knKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJ1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIE9iamVjdC5hc3NpZ24oYm9keSwgZ3JvdXApO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuICAgICAgICBib2R5LkNyZWF0ZWRPbiA9ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNyc7XHJcbiAgICAgICAgYm9keS5Nb2RpZmllZE9uID0gJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JztcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldEV4YW1zQnlJZCxcclxuICAgICAgICBnZXRFeGFtc0J5Q291cnNlLFxyXG4gICAgICAgIGdldEV4YW1zQnlOYW1lLFxyXG4gICAgICAgIGdldEV4YW1Hcm91cHNCeUV4YW1JZCxcclxuICAgICAgICBnZXRFbnJvbGxlZEJ5R3JvdXBJZCxcclxuICAgICAgICBnZXRFeGFtR3JvdXBzQnlEYXRlLFxyXG4gICAgICAgIGNyZWF0ZUV4YW0sXHJcbiAgICAgICAgdXBkYXRlRXhhbSxcclxuICAgICAgICBjcmVhdGVFeGFtR3JvdXAsXHJcbiAgICAgICAgdXBkYXRlRXhhbUdyb3VwLFxyXG4gICAgICAgIGRlc3Ryb3lFeGFtR3JvdXBcclxuICAgIH07XHJcbn1cclxuIiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSkge1xyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEluc2FuY2VHcm91cHMoaW5zdGFuY2VJZCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdHJhaW5pbmdncm91cHMvcmVhZCcpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGBUcmFpbmluZ0lkfmVxfiR7aW5zdGFuY2VJZH1gXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmksIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEdyb3VwQnlJZChncm91cElkKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy90cmFpbmluZ2dyb3Vwcy9yZWFkJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogYElkfmVxfiR7Z3JvdXBJZH1gXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmksIGJvZHkpKS5EYXRhWzBdO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVRyYWluaW5nR3JvdXAoZ3JvdXApIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3RyYWluaW5nZ3JvdXBzL2NyZWF0ZScpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnLFxyXG4gICAgICAgICAgICBJZDogZ3JvdXAuSWQsXHJcbiAgICAgICAgICAgIFRyYWluaW5nSWQ6IGdyb3VwLlRyYWluaW5nSWQsXHJcbiAgICAgICAgICAgIFRyYWluaW5nTmFtZTogZ3JvdXAuVHJhaW5pbmdOYW1lLFxyXG4gICAgICAgICAgICBUcmFpbmluZ0xhYklkOiBncm91cC5UcmFpbmluZ0xhYklkLFxyXG4gICAgICAgICAgICBOYW1lOiBncm91cC5OYW1lLFxyXG4gICAgICAgICAgICBEYXlPZldlZWs6IGdyb3VwLkRheU9mV2VlayxcclxuICAgICAgICAgICAgU3RhcnRUaW1lOiBncm91cC5TdGFydFRpbWUsXHJcbiAgICAgICAgICAgIEVuZFRpbWU6IGdyb3VwLkVuZFRpbWUsXHJcbiAgICAgICAgICAgIFNraXBXZWVrc0NvdW50OiBncm91cC5Ta2lwV2Vla3NDb3VudCxcclxuICAgICAgICAgICAgV2Vla0xlY3R1cmVOdW1iZXI6IGdyb3VwLldlZWtMZWN0dXJlTnVtYmVyLFxyXG4gICAgICAgICAgICBQZW9wbGVMaW1pdDogZ3JvdXAuUGVvcGxlTGltaXQsXHJcbiAgICAgICAgICAgIFRha2VuUGxhY2VzOiBncm91cC5UYWtlblBsYWNlcyxcclxuICAgICAgICAgICAgSXNBZGRlZFRvR29vZ2xlQ2FsZW5kYXI6IGdyb3VwLklzQWRkZWRUb0dvb2dsZUNhbGVuZGFyLFxyXG4gICAgICAgICAgICBDcmVhdGVkT246ICcnLFxyXG4gICAgICAgICAgICBNb2RpZmllZE9uOiAnJ1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBkZXN0cm95R3JvdXAoZ3JvdXApIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3RyYWluaW5nZ3JvdXBzL2Rlc3Ryb3knKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJ1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIE9iamVjdC5hc3NpZ24oYm9keSwgZ3JvdXApO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuICAgICAgICBib2R5LkNyZWF0ZWRPbiA9ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNyc7XHJcbiAgICAgICAgYm9keS5Nb2RpZmllZE9uID0gJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JztcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldEluc2FuY2VHcm91cHMsXHJcbiAgICAgICAgZ2V0R3JvdXBCeUlkLFxyXG4gICAgICAgIGNyZWF0ZVRyYWluaW5nR3JvdXAsXHJcbiAgICAgICAgZGVzdHJveUdyb3VwXHJcbiAgICB9O1xyXG59IiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSkge1xyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0SW5zdGFuY2VMZWN0dXJlcyhpbnN0YW5jZUlkKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9sZWN0dXJlcy9yZWFkP2ZvcmVpZ25LZXlJZD0ke2luc3RhbmNlSWR9YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICdPcmRlckJ5LWFzYycsXHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAsXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmksIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldExlY3R1cmVzRm9yRXhhbXNCeVRyYWluaW5nSWQodHJhaW5pbmdJZCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvbGVjdHVyZXMvcmVhZD9mb3JlaWduS2V5SWQ9JHt0cmFpbmluZ0lkfWApO1xyXG4gICAgICAgIGNvbnN0IGV4YW1LZXl3b3JkcyA9IFsnZXhhbScsICdkZWZlbmNlJywgJ2RlZmVuc2UnLCAn0LjQt9C/0LjRgicsICfQt9Cw0YnQuNGC0LAnXTtcclxuICAgICAgICBjb25zdCBleGFtRXhjbHVkZUtleXdvcmRzID0gWydwcmVwYXJhdGlvbicsICfQv9C+0LTQs9C+0YLQvtCy0LrQsCddO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnT3JkZXJCeS1hc2MnLFxyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGAoTmFtZUJnfmNvbnRhaW5zficke2V4YW1LZXl3b3Jkcy5qb2luKCdcXCd+b3J+TmFtZUJnfmNvbnRhaW5zflxcJycpfScpfmFuZH4oTmFtZUJnfmRvZXNub3Rjb250YWluficke2V4YW1FeGNsdWRlS2V5d29yZHMuam9pbignXFwnfmFuZH5OYW1lQmd+ZG9lc25vdGNvbnRhaW5+XFwnJyl9JylgXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiAoYXdhaXQgcG9zdCh1cmksIGJvZHkpKS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUxlY3R1cmUobGVjdHVyZSkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGxlY3R1cmUpO1xyXG5cclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2xlY3R1cmVzL3VwZGF0ZT9mb3JlaWduS2V5SWQ9JHtsZWN0dXJlLlRyYWluaW5nSWR9YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIElkOiBsZWN0dXJlLklkLFxyXG4gICAgICAgICAgICBUcmFpbmluZ0lkOiBsZWN0dXJlLlRyYWluaW5nSWQsXHJcbiAgICAgICAgICAgIE5hbWVCZzogbGVjdHVyZS5OYW1lQmcsXHJcbiAgICAgICAgICAgIE5hbWVFbjogbGVjdHVyZS5OYW1lRW4sXHJcbiAgICAgICAgICAgIEhhc01hbnVhbE51bWJlck9mU3R1ZHlIb3VyczogbGVjdHVyZS5IYXNNYW51YWxOdW1iZXJPZlN0dWR5SG91cnMsXHJcbiAgICAgICAgICAgIE51bWJlck9mU3R1ZHlIb3VyczogbGVjdHVyZS5OdW1iZXJPZlN0dWR5SG91cnMsXHJcbiAgICAgICAgICAgIElzRXhjbHVkZWRGcm9tQ2VydGlmaWNhdGU6IGxlY3R1cmUuSXNFeGNsdWRlZEZyb21DZXJ0aWZpY2F0ZSxcclxuICAgICAgICAgICAgSGFzSG9tZXdvcms6IGxlY3R1cmUuSGFzSG9tZXdvcmssXHJcbiAgICAgICAgICAgIFJlc291cmNlTWFpbHNTdGF0ZTogbGVjdHVyZS5SZXNvdXJjZU1haWxzU3RhdGUsXHJcbiAgICAgICAgICAgIEhvbWV3b3JrTWFpbHNTdGF0ZTogbGVjdHVyZS5Ib21ld29ya01haWxzU3RhdGUsXHJcbiAgICAgICAgICAgIEp1ZGdlQ29udGVzdElkOiBsZWN0dXJlLkp1ZGdlQ29udGVzdElkLFxyXG4gICAgICAgICAgICBBbHBoYUp1ZGdlQ29udGVzdElkOiBsZWN0dXJlLkFscGhhSnVkZ2VDb250ZXN0SWQsXHJcbiAgICAgICAgICAgIE9yZGVyQnk6IGxlY3R1cmUuT3JkZXJCeSxcclxuICAgICAgICAgICAgRGVzY3JpcHRpb25CZzogbGVjdHVyZS5EZXNjcmlwdGlvbkJnLFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkVuOiBsZWN0dXJlLkRlc2NyaXB0aW9uRW4sXHJcbiAgICAgICAgICAgIERhdGVzSW5mbzogbGVjdHVyZS5EYXRlc0luZm8gfHwgW10sXHJcbiAgICAgICAgICAgIExlY3R1cmVyOiBsZWN0dXJlLkxlY3R1cmVyLFxyXG4gICAgICAgICAgICBMZWN0dXJlVHlwZTogbGVjdHVyZS5MZWN0dXJlVHlwZSxcclxuICAgICAgICAgICAgRXhjbHVkZUZyb21DYWxlbmRhcjogbGVjdHVyZS5FeGNsdWRlRnJvbUNhbGVuZGFyLFxyXG4gICAgICAgICAgICBIYXNMaXZlU3RyZWFtOiBsZWN0dXJlLkhhc0xpdmVTdHJlYW0sXHJcbiAgICAgICAgICAgIEV4YW1QYXNzd29yZDogbGVjdHVyZS5FeGFtUGFzc3dvcmQsXHJcbiAgICAgICAgICAgIERpc2NvcmRDaGFubmVsOiBsZWN0dXJlLkRpc2NvcmRDaGFubmVsLFxyXG4gICAgICAgICAgICBTbGlkb0NvZGU6IGxlY3R1cmUuU2xpZG9Db2RlLFxyXG4gICAgICAgICAgICBDcmVhdGVkT246ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcyMDE5LTA3LTMxVDE3OjM5OjAyLjMxNydcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXJpYWxpemVEYXRlc0luZm8oYm9keSk7XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZUxlY3R1cmUobGVjdHVyZSkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvbGVjdHVyZXMvY3JlYXRlP2ZvcmVpZ25LZXlJZD0ke2xlY3R1cmUuVHJhaW5pbmdJZH1gKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgSWQ6IGxlY3R1cmUuSWQsXHJcbiAgICAgICAgICAgIFRyYWluaW5nSWQ6IGxlY3R1cmUuVHJhaW5pbmdJZCxcclxuICAgICAgICAgICAgTmFtZUJnOiBsZWN0dXJlLk5hbWVCZyxcclxuICAgICAgICAgICAgTmFtZUVuOiBsZWN0dXJlLk5hbWVFbixcclxuICAgICAgICAgICAgSGFzTWFudWFsTnVtYmVyT2ZTdHVkeUhvdXJzOiBsZWN0dXJlLkhhc01hbnVhbE51bWJlck9mU3R1ZHlIb3VycyxcclxuICAgICAgICAgICAgTnVtYmVyT2ZTdHVkeUhvdXJzOiBsZWN0dXJlLk51bWJlck9mU3R1ZHlIb3VycyxcclxuICAgICAgICAgICAgSXNFeGNsdWRlZEZyb21DZXJ0aWZpY2F0ZTogbGVjdHVyZS5Jc0V4Y2x1ZGVkRnJvbUNlcnRpZmljYXRlLFxyXG4gICAgICAgICAgICBIYXNIb21ld29yazogbGVjdHVyZS5IYXNIb21ld29yayxcclxuICAgICAgICAgICAgUmVzb3VyY2VNYWlsc1N0YXRlOiBsZWN0dXJlLlJlc291cmNlTWFpbHNTdGF0ZSxcclxuICAgICAgICAgICAgSG9tZXdvcmtNYWlsc1N0YXRlOiBsZWN0dXJlLkhvbWV3b3JrTWFpbHNTdGF0ZSxcclxuICAgICAgICAgICAgSnVkZ2VDb250ZXN0SWQ6IGxlY3R1cmUuSnVkZ2VDb250ZXN0SWQsXHJcbiAgICAgICAgICAgIEFscGhhSnVkZ2VDb250ZXN0SWQ6IGxlY3R1cmUuQWxwaGFKdWRnZUNvbnRlc3RJZCxcclxuICAgICAgICAgICAgT3JkZXJCeTogbGVjdHVyZS5PcmRlckJ5LFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkJnOiBsZWN0dXJlLkRlc2NyaXB0aW9uQmcsXHJcbiAgICAgICAgICAgIERlc2NyaXB0aW9uRW46IGxlY3R1cmUuRGVzY3JpcHRpb25FbixcclxuICAgICAgICAgICAgRGF0ZXNJbmZvOiBsZWN0dXJlLkRhdGVzSW5mbyB8fCBbXSxcclxuICAgICAgICAgICAgTGVjdHVyZXI6IGxlY3R1cmUuTGVjdHVyZXIsXHJcbiAgICAgICAgICAgIExlY3R1cmVUeXBlOiBsZWN0dXJlLkxlY3R1cmVUeXBlLFxyXG4gICAgICAgICAgICBFeGNsdWRlRnJvbUNhbGVuZGFyOiBsZWN0dXJlLkV4Y2x1ZGVGcm9tQ2FsZW5kYXIsXHJcbiAgICAgICAgICAgIEhhc0xpdmVTdHJlYW06IGxlY3R1cmUuSGFzTGl2ZVN0cmVhbSxcclxuICAgICAgICAgICAgRXhhbVBhc3N3b3JkOiBsZWN0dXJlLkV4YW1QYXNzd29yZCxcclxuICAgICAgICAgICAgRGlzY29yZENoYW5uZWw6IGxlY3R1cmUuRGlzY29yZENoYW5uZWwsXHJcbiAgICAgICAgICAgIFNsaWRvQ29kZTogbGVjdHVyZS5TbGlkb0NvZGUsXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogJycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcnXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgc2VyaWFsaXplRGF0ZXNJbmZvKGJvZHkpO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBkZXN0cm95TGVjdHVyZShsZWN0dXJlKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9sZWN0dXJlcy9kZXN0cm95P2ZvcmVpZ25LZXlJZD0ke2xlY3R1cmUuVHJhaW5pbmdJZH1gKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJ1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIE9iamVjdC5hc3NpZ24oYm9keSwgbGVjdHVyZSk7XHJcbiAgICAgICAgc2VyaWFsaXplRGF0ZXNJbmZvKGJvZHkpO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuICAgICAgICBib2R5LkNyZWF0ZWRPbiA9ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNyc7XHJcbiAgICAgICAgYm9keS5Nb2RpZmllZE9uID0gJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JztcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRMZWN0dXJlRGV0YWlscyh0cmFpbmluZ0lkLCBsZWN0dXJlSWQpIHtcclxuICAgICAgICBjb25zdCB1cmwgPSBpbnRlcm9wSG9zdChgdHJhaW5pbmdzL3RyYWluaW5ncy9nZXRsZWN0dXJlZGV0YWlscz90cmFpbmluZ0lkPSR7dHJhaW5pbmdJZH0mbGVjdHVyZUlkPSR7bGVjdHVyZUlkfWApO1xyXG4gICAgICAgIHJldHVybiBnZXQodXJsKTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBzZXJpYWxpemVEYXRlc0luZm8oYm9keSkge1xyXG4gICAgICAgIGNvbnN0IGRhdGVzSW5mbyA9IGJvZHkuRGF0ZXNJbmZvO1xyXG4gICAgICAgIGRlbGV0ZSBib2R5LkRhdGVzSW5mbztcclxuICAgICAgICBcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGVzSW5mby5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBjb25zdCBkYXRlID0gZGF0ZXNJbmZvW2ldO1xyXG4gICAgICAgICAgICBib2R5W2BEYXRlc0luZm9bJHtpfV0uU3RhcnRgXSA9IGRhdGUuU3RhcnQ7XHJcbiAgICAgICAgICAgIGJvZHlbYERhdGVzSW5mb1ske2l9XS5FbmRgXSA9IGRhdGUuRW5kO1xyXG4gICAgICAgICAgICBib2R5W2BEYXRlc0luZm9bJHtpfV0uRXh0cmFJbmZvcm1hdGlvbmBdID0gZGF0ZS5FeHRyYUluZm9ybWF0aW9uO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGdldEluc3RhbmNlTGVjdHVyZXMsXHJcbiAgICAgICAgdXBkYXRlTGVjdHVyZSxcclxuICAgICAgICBjcmVhdGVMZWN0dXJlLFxyXG4gICAgICAgIGRlc3Ryb3lMZWN0dXJlLFxyXG4gICAgICAgIGdldExlY3R1cmVEZXRhaWxzLFxyXG4gICAgICAgIGdldExlY3R1cmVzRm9yRXhhbXNCeVRyYWluaW5nSWRcclxuICAgIH07XHJcbn0iLCJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KSB7XHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRTZW1pbmFyc0J5RGF0ZShzdGFydERhdGUsIGVuZERhdGUpIHtcclxuICAgICAgICAvLyBEYXRlIGZvcm1hdCB5eXl5LW1tLWRkIGV4YW1wbGU6IDIwMjAtMDMtMjVcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3NlbWluYXJzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJ1N0YXJ0RGF0ZS1hc2MnLFxyXG4gICAgICAgICAgICBwYWdlOiAxLFxyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDAsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiBgU3RhcnREYXRlfmd0ZX5kYXRldGltZScke3N0YXJ0RGF0ZX1UMDAtMDAtMDAnfmFuZH5FbmREYXRlfmx0ZX5kYXRldGltZScke2VuZERhdGV9VDIzLTU5LTU5J2BcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBnZXRTZW1pbmFyc0J5RGF0ZVxyXG4gICAgfTtcclxufSIsImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCwgZ2V0IH0pIHtcclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFNraWxsc0J5SW5zdGFuY2UobmFtZSwgaW5zdGFuY2VJZCkge1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDAsXHJcbiAgICAgICAgICAgIHNvcnQ6ICdPcmRlckJ5LWFzYydcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgYm9keS5maWx0ZXIgPSBgTWVyZ2VkVHJhaW5pbmdzfmNvbnRhaW5zficke25hbWV9J2A7XHJcblxyXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICAgICAgICAgIHBvc3QoaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9mYXN0dHJhY2tpbnN0YW5jZXNraWxscy9yZWFkJyksIGJvZHkpLFxyXG4gICAgICAgICAgICBwb3N0KGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvY291cnNlaW5zdGFuY2Vza2lsbHMvcmVhZCcpLCBib2R5KSxcclxuICAgICAgICBdKTtcclxuICAgICAgICBsZXQgcmVzcG9uc2UgPSBbXTtcclxuICAgICAgICByZXNwb25zZSA9IHJlc3BvbnNlLmNvbmNhdChkYXRhWzBdLkRhdGEuZmlsdGVyKGkgPT4gaS5UcmFpbmluZ3MuZmlsdGVyKHQgPT4gdC5JZCA9PSBpbnN0YW5jZUlkKS5sZW5ndGggPiAwKS5tYXAocyA9PiB7IHMuVHlwZSA9ICdvcGVuJzsgcmV0dXJuIHM7IH0pKTtcclxuICAgICAgICByZXNwb25zZSA9IHJlc3BvbnNlLmNvbmNhdChkYXRhWzFdLkRhdGEuZmlsdGVyKGkgPT4gaS5UcmFpbmluZ3MuZmlsdGVyKHQgPT4gdC5JZCA9PSBpbnN0YW5jZUlkKS5sZW5ndGggPiAwKS5tYXAocyA9PiB7IHMuVHlwZSA9ICdtYWluJzsgcmV0dXJuIHM7IH0pKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVNraWxsKHNraWxsKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy8ke3NraWxsLlR5cGUgPT09ICdtYWluJyA/ICdjb3Vyc2VpbnN0YW5jZXNraWxscycgOiAnZmFzdHRyYWNraW5zdGFuY2Vza2lsbHMnfS91cGRhdGVgKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgSWQ6IHNraWxsLklkLFxyXG4gICAgICAgICAgICBUZXh0Qmc6IHNraWxsLlRleHRCZyxcclxuICAgICAgICAgICAgT3JkZXJCeTogc2tpbGwuT3JkZXJCeSxcclxuICAgICAgICAgICAgTWVyZ2VkVHJhaW5pbmdzOiBza2lsbC5NZXJnZWRUcmFpbmluZ3MsXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JyxcclxuICAgICAgICAgICAgTW9kaWZpZWRPbjogJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3J1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc2tpbGwuVHJhaW5pbmdzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHRyYWluaW5nID0gc2tpbGwuVHJhaW5pbmdzW2ldO1xyXG4gICAgICAgICAgICBib2R5W2BUcmFpbmluZ3NbJHtpfV0uSWRgXSA9IHRyYWluaW5nLklkO1xyXG4gICAgICAgICAgICBib2R5W2BUcmFpbmluZ3NbJHtpfV0uTmFtZWBdID0gdHJhaW5pbmcuTmFtZTtcclxuICAgICAgICAgICAgYm9keVtgVHJhaW5pbmdzWyR7aX1dLk5hbWVCZ2BdID0gdHJhaW5pbmcuTmFtZUJnO1xyXG4gICAgICAgICAgICBib2R5W2BUcmFpbmluZ3NbJHtpfV0uTmFtZUVuYF0gPSB0cmFpbmluZy5OYW1lRW47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgICAgIHJlc3VsdC5EYXRhWzBdLlR5cGUgPSBza2lsbC5UeXBlO1xyXG5cclxuICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVNraWxsKHNraWxsKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy8ke3NraWxsLlR5cGUgPT09ICdtYWluJyA/ICdjb3Vyc2VpbnN0YW5jZXNraWxscycgOiAnZmFzdHRyYWNraW5zdGFuY2Vza2lsbHMnfS9jcmVhdGVgKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJycsXHJcbiAgICAgICAgICAgIGdyb3VwOiAnJyxcclxuICAgICAgICAgICAgZmlsdGVyOiAnJyxcclxuICAgICAgICAgICAgSWQ6IHNraWxsLklkLFxyXG4gICAgICAgICAgICBUZXh0Qmc6IHNraWxsLlRleHRCZyxcclxuICAgICAgICAgICAgT3JkZXJCeTogc2tpbGwuT3JkZXJCeSxcclxuICAgICAgICAgICAgTWVyZ2VkVHJhaW5pbmdzOiBza2lsbC5NZXJnZWRUcmFpbmluZ3MsXHJcbiAgICAgICAgICAgIENyZWF0ZWRPbjogJycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcnXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBza2lsbC5UcmFpbmluZ3MubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgY29uc3QgdHJhaW5pbmcgPSBza2lsbC5UcmFpbmluZ3NbaV07XHJcbiAgICAgICAgICAgIGJvZHlbYFRyYWluaW5nc1ske2l9XS5JZGBdID0gdHJhaW5pbmcuSWQ7XHJcbiAgICAgICAgICAgIGJvZHlbYFRyYWluaW5nc1ske2l9XS5OYW1lYF0gPSB0cmFpbmluZy5OYW1lO1xyXG4gICAgICAgICAgICBib2R5W2BUcmFpbmluZ3NbJHtpfV0uTmFtZUJnYF0gPSB0cmFpbmluZy5OYW1lQmc7XHJcbiAgICAgICAgICAgIGJvZHlbYFRyYWluaW5nc1ske2l9XS5OYW1lRW5gXSA9IHRyYWluaW5nLk5hbWVFbjtcclxuICAgICAgICB9XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICAgICAgcmVzdWx0LkRhdGFbMF0uVHlwZSA9IHNraWxsLlR5cGU7XHJcblxyXG4gICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZGVzdHJveVNraWxsKHNraWxsKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy8ke3NraWxsLlR5cGUgPT09ICdtYWluJyA/ICdjb3Vyc2VpbnN0YW5jZXNraWxscycgOiAnZmFzdHRyYWNraW5zdGFuY2Vza2lsbHMnfS9kZXN0cm95YCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJydcclxuICAgICAgICB9KTtcclxuICAgICAgICBPYmplY3QuYXNzaWduKGJvZHksIHNraWxsKTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNraWxsLlRyYWluaW5ncy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBjb25zdCB0cmFpbmluZyA9IHNraWxsLlRyYWluaW5nc1tpXTtcclxuICAgICAgICAgICAgYm9keVtgVHJhaW5pbmdzWyR7aX1dLklkYF0gPSB0cmFpbmluZy5JZDtcclxuICAgICAgICAgICAgYm9keVtgVHJhaW5pbmdzWyR7aX1dLk5hbWVgXSA9IHRyYWluaW5nLk5hbWU7XHJcbiAgICAgICAgICAgIGJvZHlbYFRyYWluaW5nc1ske2l9XS5OYW1lQmdgXSA9IHRyYWluaW5nLk5hbWVCZztcclxuICAgICAgICAgICAgYm9keVtgVHJhaW5pbmdzWyR7aX1dLk5hbWVFbmBdID0gdHJhaW5pbmcuTmFtZUVuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBkZWxldGUgYm9keS5UcmFpbmluZ3M7XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG4gICAgICAgIGJvZHkuQ3JlYXRlZE9uID0gJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JztcclxuICAgICAgICBib2R5Lk1vZGlmaWVkT24gPSAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHNlYXJjaFNraWxscyhxdWVyeSwgdHlwZSkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvJHt0eXBlID09PSAnbWFpbicgPyAnY291cnNlaW5zdGFuY2Vza2lsbHMnIDogJ2Zhc3R0cmFja2luc3RhbmNlc2tpbGxzJ30vcmVhZGApO1xyXG5cclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDE1LFxyXG4gICAgICAgICAgICBzb3J0OiAnT3JkZXJCeS1hc2MnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGBUZXh0Qmd+Y29udGFpbnN+JyR7cXVlcnl9J2BcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvc3QodXJpLCBib2R5KTtcclxuICAgICAgICBkYXRhLkRhdGEuZm9yRWFjaChzID0+IHMuVHlwZSA9IHR5cGUpO1xyXG5cclxuICAgICAgICByZXR1cm4gZGF0YS5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgZ2V0U2tpbGxzQnlJbnN0YW5jZSxcclxuICAgICAgICB1cGRhdGVTa2lsbCxcclxuICAgICAgICBjcmVhdGVTa2lsbCxcclxuICAgICAgICBkZXN0cm95U2tpbGwsXHJcbiAgICAgICAgc2VhcmNoU2tpbGxzXHJcbiAgICB9O1xyXG59IiwiaW1wb3J0IGV2ZW50c0FwaUZhY3RvcnkgZnJvbSAnLi9ldmVudHMnO1xyXG5pbXBvcnQgbGVjdHVyZXNBcGlGYWN0b3J5IGZyb20gJy4vbGVjdHVyZXMnO1xyXG5pbXBvcnQgc2tpbGxzQXBpRmFjdG9yeSBmcm9tICcuL3NraWxscyc7XHJcbmltcG9ydCBncm91cHNBcGlGYWN0b3J5IGZyb20gJy4vZ3JvdXBzJztcclxuaW1wb3J0IGV4YW1BcGlGYWN0b3J5IGZyb20gJy4vZXhhbXMnO1xyXG5pbXBvcnQgYXNzZXNzbWVudEFwaUZhY3RvcnkgZnJvbSAnLi9hc3Nlc3NtZW50JztcclxuaW1wb3J0IHNlbWluYXJzQXBpRmFjdG9yeSBmcm9tICcuL3NlbWluYXJzJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICh7IGludGVyb3BIb3N0LCBpbnRlcm9wQXBwSWQsIHBhcmFtcywgcG9zdCwgZ2V0LCBpbnRlcm9wUGxhdGZvcm1Ib3N0IH0pIHtcclxuICAgIGNvbnN0IGV2ZW50c0FwaSA9IGV2ZW50c0FwaUZhY3RvcnkoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KTtcclxuICAgIGNvbnN0IGxlY3R1cmVzQXBpID0gbGVjdHVyZXNBcGlGYWN0b3J5KHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSk7XHJcbiAgICBjb25zdCBza2lsbHNBcGkgPSBza2lsbHNBcGlGYWN0b3J5KHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSk7XHJcbiAgICBjb25zdCBncm91cHNBcGkgPSBncm91cHNBcGlGYWN0b3J5KHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSk7XHJcbiAgICBjb25zdCBleGFtc0FwaSA9IGV4YW1BcGlGYWN0b3J5KHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSk7XHJcbiAgICBjb25zdCBhc3Nlc3NtZW50QXBpID0gYXNzZXNzbWVudEFwaUZhY3RvcnkoeyBpbnRlcm9wSG9zdCwgaW50ZXJvcEFwcElkLCBwYXJhbXMsIHBvc3QsIGdldCB9KTtcclxuICAgIGNvbnN0IHNlbWluYXJzQXBpID0gc2VtaW5hcnNBcGlGYWN0b3J5KHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSk7XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gc2VhcmNoQnlOYW1lKGJvZHkpIHtcclxuICAgICAgICBjb25zdCBxdWVyeSA9IGJvZHkucXVlcnkuZmlsdGVyKGYgPT4gZi5sZW5ndGggPiAwKTtcclxuXHJcbiAgICAgICAgY29uc3QgY291cnNlcyA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgICAgICAgYm9keS5tYWluICYmIGdldE1haW5JbnN0YW5jZXMoYm9keS5wYWdlLCBxdWVyeSksXHJcbiAgICAgICAgICAgIGJvZHkub3BlbiAmJiBnZXRPcGVuSW5zdGFuY2VzKGJvZHkucGFnZSwgcXVlcnkpLFxyXG4gICAgICAgICAgICBib2R5LmdlbmVyYWwgJiYgZ2V0R2VuZXJhbEluc3RhbmNlcyhib2R5LnBhZ2UsIHF1ZXJ5KVxyXG4gICAgICAgIF0pO1xyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xyXG4gICAgICAgIGZvciAobGV0IGNvdXJzZSBvZiAoY291cnNlc1swXSB8fCBbXSkpIHtcclxuICAgICAgICAgICAgcmVzdWx0LnB1c2goe1xyXG4gICAgICAgICAgICAgICAgSWQ6IGNvdXJzZS5JZCxcclxuICAgICAgICAgICAgICAgIE5hbWVCZzogY291cnNlLk5hbWVCZyxcclxuICAgICAgICAgICAgICAgIFR5cGU6ICdtYWluJyxcclxuICAgICAgICAgICAgICAgIENvdXJzZUlkOiBjb3Vyc2UuQ291cnNlSWRcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZvciAobGV0IGNvdXJzZSBvZiAoY291cnNlc1sxXSB8fCBbXSkpIHtcclxuICAgICAgICAgICAgcmVzdWx0LnB1c2goe1xyXG4gICAgICAgICAgICAgICAgSWQ6IGNvdXJzZS5JZCxcclxuICAgICAgICAgICAgICAgIE5hbWVCZzogY291cnNlLk5hbWVCZyxcclxuICAgICAgICAgICAgICAgIFR5cGU6ICdvcGVuJyxcclxuICAgICAgICAgICAgICAgIENvdXJzZUlkOiBjb3Vyc2UuQ291cnNlSWRcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZvciAobGV0IGNvdXJzZSBvZiAoY291cnNlc1syXSB8fCBbXSkpIHtcclxuICAgICAgICAgICAgcmVzdWx0LnB1c2goe1xyXG4gICAgICAgICAgICAgICAgSWQ6IGNvdXJzZS5JZCxcclxuICAgICAgICAgICAgICAgIE5hbWVCZzogY291cnNlLk5hbWVCZyxcclxuICAgICAgICAgICAgICAgIFR5cGU6ICdnZW5lcmFsJyxcclxuICAgICAgICAgICAgICAgIENvdXJzZUlkOiBjb3Vyc2UuQ291cnNlSWRcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gc2VhcmNoVHJhaW5pbmdzQnlOYW1lKG5hbWUsIGV4YWN0ID0gZmFsc2UpIHtcclxuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShuYW1lKSA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICBuYW1lID0gW25hbWVdO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3RyYWluaW5ncy9yZWFkJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiA1MCxcclxuICAgICAgICAgICAgZmlsdGVyOiBleGFjdFxyXG4gICAgICAgICAgICAgICAgPyBgTmFtZUJnfmVxficke25hbWUuZmlsdGVyKHMgPT4gcy5sZW5ndGggPiAwKS5qb2luKCdcXCd+b3J+TmFtZUJnfmVxflxcJycpfSdgXHJcbiAgICAgICAgICAgICAgICA6IGBOYW1lQmd+Y29udGFpbnN+JyR7bmFtZS5maWx0ZXIocyA9PiBzLmxlbmd0aCA+IDApLmpvaW4oJ1xcJ35vcn5OYW1lQmd+Y29udGFpbnN+XFwnJyl9J2AsXHJcbiAgICAgICAgICAgIHNvcnQ6ICdTdGFydERhdGUtZGVzYycsXHJcbiAgICAgICAgICAgIHBhZ2U6IDFcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gc2VhcmNoQ291cnNlcyhxdWVyeSkge1xyXG4gICAgICAgIGNvbnN0IHVybCA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvY291cnNlcy9yZWFkJyk7XHJcbiAgICAgICAgY29uc3QgZmlsdGVyID0gYE5hbWV+Y29udGFpbnN+JyR7cXVlcnkuc3BsaXQoJyAnKS5maWx0ZXIocyA9PiBzLmxlbmd0aCA+IDApLmpvaW4oJ1xcJ35hbmR+TmFtZX5jb250YWluc35cXCcnKX0nYDtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMCxcclxuICAgICAgICAgICAgZmlsdGVyLFxyXG4gICAgICAgICAgICBzb3J0OiAnQ3JlYXRlZE9uLWRlc2MnXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IChhd2FpdCBwb3N0KHVybCwgYm9keSkpLkRhdGE7XHJcbiAgICAgICAgcmVzdWx0LmZvckVhY2gociA9PiB7XHJcbiAgICAgICAgICAgIHIuTmFtZUJnID0gci5OYW1lO1xyXG4gICAgICAgICAgICByLk5hbWVFbiA9IHIuTmFtZTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBzZWFyY2hDb3Vyc2VJbnN0YW5jZXNCeUNvdXJzZU5hbWVBbmRJbnN0YW5jZUlkKGNvdXJzZU5hbWVzLCBpbnN0YW5jZUlkcywgZmlsdGVyID0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoY291cnNlTmFtZXMpID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIGNvdXJzZU5hbWVzID0gW2NvdXJzZU5hbWVzXTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IHVybCA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvY291cnNlcy9yZWFkJyk7XHJcbiAgICAgICAgY29uc3QgY291cnNlc0ZpbHRlciA9IGBOYW1lfmNvbnRhaW5zficke2NvdXJzZU5hbWVzLmZpbHRlcihzID0+IHMubGVuZ3RoID4gMCkuam9pbignXFwnfmFuZH5OYW1lfmNvbnRhaW5zflxcJycpfSdgO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGNvdXJzZXNGaWx0ZXIsXHJcbiAgICAgICAgICAgIHNvcnQ6ICdDcmVhdGVkT24tZGVzYydcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gKGF3YWl0IHBvc3QodXJsLCBib2R5KSkuRGF0YTtcclxuICAgICAgICByZXN1bHQuZm9yRWFjaChyID0+IHtcclxuICAgICAgICAgICAgci5OYW1lQmcgPSByLk5hbWU7XHJcbiAgICAgICAgICAgIHIuTmFtZUVuID0gci5OYW1lO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBsZXQgY291cnNlSW5zdGFuY2VzUHJvbWlzZXMgPSBbXTtcclxuICAgICAgICByZXN1bHQuZm9yRWFjaChjID0+IHtcclxuICAgICAgICAgICAgY291cnNlSW5zdGFuY2VzUHJvbWlzZXMucHVzaChnZXRDb3Vyc2VJbnN0YW5jZXMoYy5JZCwgZmlsdGVyKSk7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KGluc3RhbmNlSWRzKSA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICBpbnN0YW5jZUlkcyA9IFtpbnN0YW5jZUlkc107XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgYWxsQ291cnNlSW5zdGFuY2VzID0gKGF3YWl0IFByb21pc2UuYWxsKGNvdXJzZUluc3RhbmNlc1Byb21pc2VzKSkucmVkdWNlKChhLCBjKSA9PiBhLmNvbmNhdChjKSwgW10pO1xyXG4gICAgICAgIGxldCBmaWx0ZXJlZENvdXJzZUluc3RhbmNlcyA9IGluc3RhbmNlSWRzLmxlbmd0aCA9PSAwXHJcbiAgICAgICAgICAgID8gYWxsQ291cnNlSW5zdGFuY2VzXHJcbiAgICAgICAgICAgIDogYWxsQ291cnNlSW5zdGFuY2VzLmZpbHRlcihjaSA9PiBpbnN0YW5jZUlkcy5pbmNsdWRlcyhjaS5JZCkpO1xyXG5cclxuICAgICAgICByZXR1cm4gZmlsdGVyZWRDb3Vyc2VJbnN0YW5jZXM7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0TWFpbkluc3RhbmNlcyhwYWdlLCBxdWVyeSkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdXNlcnNpbmNvdXJzZXMvcmVhZGNvdXJzZWluc3RhbmNlcycpO1xyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9IHF1ZXJ5Lm1hcChlID0+IGBOYW1lQmd+Y29udGFpbnN+JyR7ZX0nYCkuam9pbignfmFuZH4nKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJ0lzQWN0aXZlLWRlc2N+Q3JlYXRlZE9uLWRlc2MnLFxyXG4gICAgICAgICAgICBwYWdlLFxyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMjUsXHJcbiAgICAgICAgICAgIGZpbHRlclxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgICAgIHJldHVybiBkYXRhLkRhdGEubWFwKGUgPT4gKHtcclxuICAgICAgICAgICAgSWQ6IGUuSWQsXHJcbiAgICAgICAgICAgIE5hbWVCZzogZS5OYW1lQmcsXHJcbiAgICAgICAgICAgIENvdXJzZUlkOiBlLkNvdXJzZUlkXHJcbiAgICAgICAgfSkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldE9wZW5JbnN0YW5jZXMocGFnZSwgcXVlcnkpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnL2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy91c2Vyc2luZmFzdHRyYWNrcy9yZWFkZmFzdHRyYWNraW5zdGFuY2VzJyk7XHJcbiAgICAgICAgY29uc3QgZmlsdGVyID0gcXVlcnkubWFwKGUgPT4gYE5hbWVCZ35jb250YWluc34nJHtlfSdgKS5qb2luKCd+YW5kficpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnSXNBY3RpdmUtZGVzY35DcmVhdGVkT24tZGVzYycsXHJcbiAgICAgICAgICAgIHBhZ2UsXHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAyNSxcclxuICAgICAgICAgICAgZmlsdGVyXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICAgICAgcmV0dXJuIGRhdGEuRGF0YS5tYXAoZSA9PiAoe1xyXG4gICAgICAgICAgICBJZDogZS5JZCxcclxuICAgICAgICAgICAgTmFtZUJnOiBlLk5hbWVCZyxcclxuICAgICAgICAgICAgQ291cnNlSWQ6IGUuQ291cnNlSWRcclxuICAgICAgICB9KSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0R2VuZXJhbEluc3RhbmNlcyhwYWdlLCBxdWVyeSkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdXNlcnNpbmdlbmVyYWxjb3Vyc2VpbnN0YW5jZXMvcmVhZGdlbmVyYWxjb3Vyc2VpbnN0YW5jZXMnKTtcclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSBxdWVyeS5tYXAoZSA9PiBgTmFtZUJnfmNvbnRhaW5zficke2V9J2ApLmpvaW4oJ35hbmR+Jyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHNvcnQ6ICdJc0FjdGl2ZS1kZXNjfkNyZWF0ZWRPbi1kZXNjJyxcclxuICAgICAgICAgICAgcGFnZSxcclxuICAgICAgICAgICAgcGFnZVNpemU6IDI1LFxyXG4gICAgICAgICAgICBmaWx0ZXJcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvc3QodXJpLCBib2R5KTtcclxuICAgICAgICByZXR1cm4gZGF0YS5EYXRhLm1hcChlID0+ICh7XHJcbiAgICAgICAgICAgIElkOiBlLklkLFxyXG4gICAgICAgICAgICBOYW1lQmc6IGUuTmFtZUJnLFxyXG4gICAgICAgICAgICBDb3Vyc2VJZDogZS5Db3Vyc2VJZFxyXG4gICAgICAgIH0pKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRDb3Vyc2VEYXRhKGNvdXJzZUlkKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9jb3Vyc2VzL3JlYWQnKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgZmlsdGVyOiBgSWR+ZXF+JyR7Y291cnNlSWR9J2BcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGFbMF07XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0Q291cnNlSW5zdGFuY2VzKGNvdXJzZUlkLCBmaWx0ZXIgPSB1bmRlZmluZWQpIHtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJ1N0YXJ0RGF0ZS1kZXNjJyxcclxuICAgICAgICAgICAgcGFnZVNpemU6IDEwMFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgICAgICAoZmlsdGVyID09IHVuZGVmaW5lZCB8fCBmaWx0ZXIubWFpbiA9PT0gdHJ1ZSlcclxuICAgICAgICAgICAgICAgID8gcG9zdChpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2NvdXJzZWluc3RhbmNlcy9yZWFkP2ZvcmVpZ25LZXlJZD0ke2NvdXJzZUlkfWApLCBib2R5KVxyXG4gICAgICAgICAgICAgICAgOiBQcm9taXNlLnJlc29sdmUodHJ1ZSksXHJcbiAgICAgICAgICAgIChmaWx0ZXIgPT0gdW5kZWZpbmVkIHx8IGZpbHRlci5tYWluID09PSB0cnVlKVxyXG4gICAgICAgICAgICAgICAgPyBwb3N0KGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvZmFzdHRyYWNraW5zdGFuY2VzL3JlYWQ/Zm9yZWlnbktleUlkPSR7Y291cnNlSWR9YCksIGJvZHkpXHJcbiAgICAgICAgICAgICAgICA6IFByb21pc2UucmVzb2x2ZSh0cnVlKSxcclxuICAgICAgICAgICAgKGZpbHRlciA9PSB1bmRlZmluZWQgfHwgZmlsdGVyLmdlbmVyYWwgPT09IHRydWUpXHJcbiAgICAgICAgICAgICAgICA/IHBvc3QoaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9nZW5lcmFsY291cnNlaW5zdGFuY2VzL3JlYWQ/Zm9yZWlnbktleUlkPSR7Y291cnNlSWR9YCksIGJvZHkpXHJcbiAgICAgICAgICAgICAgICA6IFByb21pc2UucmVzb2x2ZSh0cnVlKVxyXG4gICAgICAgIF0pO1xyXG5cclxuICAgICAgICBsZXQgcmVzcG9uc2UgPSBbXTtcclxuXHJcbiAgICAgICAgcmVzcG9uc2UgPSByZXNwb25zZS5jb25jYXQoZGF0YVswXS5EYXRhICE9IHVuZGVmaW5lZCA/IGRhdGFbMF0uRGF0YS5tYXAoYyA9PiB7IGMuSW5zdGFuY2VSZWZUeXBlID0gJ21haW4nOyByZXR1cm4gYzsgfSkgOiBbXSk7XHJcbiAgICAgICAgcmVzcG9uc2UgPSByZXNwb25zZS5jb25jYXQoZGF0YVsxXS5EYXRhICE9IHVuZGVmaW5lZCA/IGRhdGFbMV0uRGF0YS5tYXAoYyA9PiB7IGMuSW5zdGFuY2VSZWZUeXBlID0gJ29wZW4nOyByZXR1cm4gYzsgfSkgOiBbXSk7XHJcbiAgICAgICAgcmVzcG9uc2UgPSByZXNwb25zZS5jb25jYXQoZGF0YVsyXS5EYXRhICE9IHVuZGVmaW5lZCA/IGRhdGFbMl0uRGF0YS5tYXAoYyA9PiB7IGMuSW5zdGFuY2VSZWZUeXBlID0gJ2dlbmVyYWwnOyByZXR1cm4gYzsgfSkgOiBbXSk7XHJcblxyXG4gICAgICAgIHJldHVybiByZXNwb25zZTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRJbnN0YW5jZURhdGEoaW5zdGFuY2VJZCwgY291cnNlSWQsIHR5cGUpIHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBpZiAodHlwZSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGdldEluc3RhbmNlRGF0YUJ5VHlwZShpbnN0YW5jZUlkLCBjb3Vyc2VJZCwgdHlwZSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBxdWVyeVJlc3VsdHMgPSBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICAgICAgICAgICAgICAgICAgZ2V0SW5zdGFuY2VEYXRhQnlUeXBlKGluc3RhbmNlSWQsIGNvdXJzZUlkLCAnbWFpbicpLFxyXG4gICAgICAgICAgICAgICAgICAgIGdldEluc3RhbmNlRGF0YUJ5VHlwZShpbnN0YW5jZUlkLCBjb3Vyc2VJZCwgJ29wZW4nKSxcclxuICAgICAgICAgICAgICAgICAgICBnZXRJbnN0YW5jZURhdGFCeVR5cGUoaW5zdGFuY2VJZCwgY291cnNlSWQsICdnZW5lcmFsJylcclxuICAgICAgICAgICAgICAgIF0pO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHF1ZXJ5UmVzdWx0cy5maWx0ZXIoZSA9PiBlICE9PSB1bmRlZmluZWQpWzBdO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0SW5zdGFuY2VEYXRhQnlUeXBlKGluc3RhbmNlSWQsIGNvdXJzZUlkLCB0eXBlKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gKCgpID0+IHtcclxuICAgICAgICAgICAgc3dpdGNoICh0eXBlKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlICdtYWluJzpcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9jb3Vyc2VpbnN0YW5jZXMvcmVhZD9mb3JlaWduS2V5SWQ9JHtjb3Vyc2VJZH1gKTtcclxuICAgICAgICAgICAgICAgIGNhc2UgJ29wZW4nOlxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2Zhc3R0cmFja2luc3RhbmNlcy9yZWFkP2ZvcmVpZ25LZXlJZD0ke2NvdXJzZUlkfWApO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAnZ2VuZXJhbCc6XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvZ2VuZXJhbGNvdXJzZWluc3RhbmNlcy9yZWFkP2ZvcmVpZ25LZXlJZD0ke2NvdXJzZUlkfWApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSkoKTtcclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgZmlsdGVyOiBgSWR+ZXF+JHtpbnN0YW5jZUlkfWBcclxuICAgICAgICB9KTtcclxuICAgICAgICBjb25zdCBpbnN0YW5jZSA9IChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGFbMF07XHJcbiAgICAgICAgaWYgKGluc3RhbmNlICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgaW5zdGFuY2UuSW5zdGFuY2VSZWZUeXBlID0gdHlwZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGluc3RhbmNlO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEluc3RhbmNlT3ZlcnZpZXcoaW5zdGFuY2VJZHMpIHtcclxuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShpbnN0YW5jZUlkcykgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgaW5zdGFuY2VJZHMgPSBbaW5zdGFuY2VJZHNdO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3RyYWluaW5ncy9yZWFkJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwLFxyXG4gICAgICAgICAgICBmaWx0ZXI6IGBUcmFpbmluZ0lkfmVxfiR7aW5zdGFuY2VJZHMuam9pbignfm9yflRyYWluaW5nSWR+ZXF+Jyl9YFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiB1cGRhdGVDb3Vyc2UoY291cnNlKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9jb3Vyc2VzL3VwZGF0ZScpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnJyxcclxuICAgICAgICAgICAgZ3JvdXA6ICcnLFxyXG4gICAgICAgICAgICBmaWx0ZXI6ICcnLFxyXG4gICAgICAgICAgICBJZDogY291cnNlLklkLFxyXG4gICAgICAgICAgICBOYW1lOiBjb3Vyc2UuTmFtZSxcclxuICAgICAgICAgICAgRGVzY3JpcHRpb25CZzogY291cnNlLkRlc2NyaXB0aW9uQmcsXHJcbiAgICAgICAgICAgIERlc2NyaXB0aW9uRW46IGNvdXJzZS5EZXNjcmlwdGlvbkVuLFxyXG4gICAgICAgICAgICBVcmxOYW1lOiBjb3Vyc2UuVXJsTmFtZSxcclxuICAgICAgICAgICAgSWNvblVybDogY291cnNlLkljb25VcmwsXHJcbiAgICAgICAgICAgIENyZWRpdHM6IGNvdXJzZS5DcmVkaXRzLFxyXG4gICAgICAgICAgICBJc0FjdGl2ZTogY291cnNlLklzQWN0aXZlLFxyXG4gICAgICAgICAgICBJc0hpZGRlbjogY291cnNlLklzSGlkZGVuLFxyXG4gICAgICAgICAgICBPcmRlckJ5OiBjb3Vyc2UuT3JkZXJCeSxcclxuICAgICAgICAgICAgTWVyZ2VkVGFnczogY291cnNlLk1lcmdlZFRhZ3MsXHJcbiAgICAgICAgICAgIENvdXJzZUNhdGVnb3J5SWQ6IGNvdXJzZS5Db3Vyc2VDYXRlZ29yeUlkLFxyXG4gICAgICAgICAgICBDb3Vyc2VEaWZmaWN1bHR5TGV2ZWw6IGNvdXJzZS5Db3Vyc2VEaWZmaWN1bHR5TGV2ZWwsXHJcbiAgICAgICAgICAgIENvdXJzZURpZmZpY3VsdHlMZXZlbERlc2NyaXB0aW9uQmc6IGNvdXJzZS5Db3Vyc2VEaWZmaWN1bHR5TGV2ZWxEZXNjcmlwdGlvbkJnLFxyXG4gICAgICAgICAgICBDb3Vyc2VEaWZmaWN1bHR5TGV2ZWxEZXNjcmlwdGlvbkVuOiBjb3Vyc2UuQ291cnNlRGlmZmljdWx0eUxldmVsRGVzY3JpcHRpb25FbixcclxuICAgICAgICAgICAgQ3JlYXRlZE9uOiBjb3Vyc2UuQ3JlYXRlZE9uLFxyXG4gICAgICAgICAgICBNb2RpZmllZE9uOiBjb3Vyc2UuTW9kaWZpZWRPbiB8fCBjb3Vyc2UuQ3JlYXRlZE9uLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIE9iamVjdC5rZXlzKGJvZHkpLmZvckVhY2goayA9PiB7IGlmIChib2R5W2tdID09PSBudWxsKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB1cGRhdGVJbnN0YW5jZShpbnN0YW5jZSkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoaW5zdGFuY2UuSW5zdGFuY2VSZWZUeXBlKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlICdtYWluJzpcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9jb3Vyc2VpbnN0YW5jZXMvdXBkYXRlP2ZvcmVpZ25LZXlJZD0ke2luc3RhbmNlLkNvdXJzZUlkfWApO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAnb3Blbic6XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvZmFzdHRyYWNraW5zdGFuY2VzL3VwZGF0ZT9mb3JlaWduS2V5SWQ9JHtpbnN0YW5jZS5Db3Vyc2VJZH1gKTtcclxuICAgICAgICAgICAgICAgIGNhc2UgJ2dlbmVyYWwnOlxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL2dlbmVyYWxjb3Vyc2VpbnN0YW5jZXMvdXBkYXRlP2ZvcmVpZ25LZXlJZD0ke2luc3RhbmNlLkNvdXJzZUlkfWApO1xyXG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3RyYWluaW5ncy9mYXN0dHJhY2tpbnN0YW5jZXMvdXBkYXRlP2ZvcmVpZ25LZXlJZD0ke2luc3RhbmNlLkNvdXJzZUlkfWApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSkoKTtcclxuXHJcbiAgICAgICAgY29uc3QgYm9keSA9IE9iamVjdC5hc3NpZ24oe30sIGluc3RhbmNlLCB7XHJcbiAgICAgICAgICAgIHNvcnQ6ICcnLFxyXG4gICAgICAgICAgICBncm91cDogJycsXHJcbiAgICAgICAgICAgIGZpbHRlcjogJycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246IGluc3RhbmNlLk1vZGlmaWVkT24gfHwgaW5zdGFuY2UuQ3JlYXRlZE9uXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGRlbGV0ZSBib2R5Lkluc3RhbmNlUmVmVHlwZTtcclxuICAgICAgICBkZWxldGUgYm9keS5TaGFyZXNMaXZlU3RyZWFtV2l0aFRyYWluaW5ncztcclxuXHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldFN0dWRlbnRzKGluc3RhbmNlSWQsIHR5cGUgPSAnbWFpbicpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSAoKCkgPT4ge1xyXG4gICAgICAgICAgICBzd2l0Y2ggKHR5cGUpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgJ21haW4nOlxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3VzZXJzaW5jb3Vyc2VzL3JlYWQ/Zm9yZWlnbktleUlkPSR7aW5zdGFuY2VJZH1gKTtcclxuICAgICAgICAgICAgICAgIGNhc2UgJ29wZW4nOlxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3VzZXJzaW5mYXN0dHJhY2tzL3JlYWQ/Zm9yZWlnbktleUlkPSR7aW5zdGFuY2VJZH1gKTtcclxuICAgICAgICAgICAgICAgIGNhc2UgJ2dlbmVyYWwnOlxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdChgYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3VzZXJzaW5nZW5lcmFsY291cnNlaW5zdGFuY2VzL3JlYWQ/Zm9yZWlnbktleUlkPSR7aW5zdGFuY2VJZH1gKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKCk7XHJcblxyXG4gICAgICAgIHJldHVybiBhd2FpdCBmZXRjaE5leHQoKTtcclxuXHJcbiAgICAgICAgYXN5bmMgZnVuY3Rpb24gZmV0Y2hOZXh0KHBhZ2UgPSAxKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICAgICAgc29ydDogJ0NyZWF0ZWRPbi1kZXNjJyxcclxuICAgICAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwLFxyXG4gICAgICAgICAgICAgICAgcGFnZVxyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgcG9zdCh1cmksIGJvZHkpO1xyXG5cclxuICAgICAgICAgICAgbGV0IHJlc3VsdCA9IHJlc3BvbnNlLkRhdGE7XHJcblxyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuVG90YWwgPiBwYWdlICogMTAwMCkge1xyXG4gICAgICAgICAgICAgICAgcmVzdWx0ID0gcmVzdWx0LmNvbmNhdChhd2FpdCBmZXRjaE5leHQocGFnZSArIDEpKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldENvdXJzZUV2ZW50cyhpbnN0YW5jZUlkKSB7XHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgICAgICAgZ2V0TWFpbkJ5SWQoaW5zdGFuY2VJZCksXHJcbiAgICAgICAgICAgIGdldE9wZW5CeUlkKGluc3RhbmNlSWQpLFxyXG4gICAgICAgICAgICBnZXRHZW5lcmFsQnlJZChpbnN0YW5jZUlkKSxcclxuICAgICAgICAgICAgZXZlbnRzQXBpLmdldEV2ZW50cyhpbnN0YW5jZUlkKVxyXG4gICAgICAgIF0pO1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgMzsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmIChkYXRhW2ldLlRvdGFsID4gMCkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgSWQ6IGRhdGFbaV0uRGF0YVswXS5JZCxcclxuICAgICAgICAgICAgICAgICAgICBDb3Vyc2VJZDogZGF0YVtpXS5EYXRhWzBdLkNvdXJzZUlkLFxyXG4gICAgICAgICAgICAgICAgICAgIE5hbWVCZzogZGF0YVtpXS5EYXRhWzBdLk5hbWVCZyxcclxuICAgICAgICAgICAgICAgICAgICBFdmVudHM6IGRhdGFbM10sXHJcbiAgICAgICAgICAgICAgICAgICAgSW5zdGFuY2VSZWZUeXBlOiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAwOiAnbWFpbicsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDE6ICdvcGVuJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgMjogJ2dlbmVyYWwnXHJcbiAgICAgICAgICAgICAgICAgICAgfSlbaV1cclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdFcnJvciBmZXRjaGluZyBpbnN0YW5jZSBkYXRhOiBBbGwgc2VhcmNoZXMgcmV0dXJuZWQgMCBtYXRjaGVzJyk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0QW55QnlJZChpbnN0YW5jZUlkKSB7XHJcbiAgICAgICAgaWYoQXJyYXkuaXNBcnJheShpbnN0YW5jZUlkKSAmJiBpbnN0YW5jZUlkLmxlbmd0aCA9PT0gMCl7XHJcbiAgICAgICAgICAgIHJldHVybiBbXTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgICAgICAgZ2V0TWFpbkJ5SWQoaW5zdGFuY2VJZCksXHJcbiAgICAgICAgICAgIGdldE9wZW5CeUlkKGluc3RhbmNlSWQpLFxyXG4gICAgICAgICAgICBnZXRHZW5lcmFsQnlJZChpbnN0YW5jZUlkKVxyXG4gICAgICAgIF0pO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHJlc3VsdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBjb25zdCBpbnN0YW5jZSA9IHJlc3VsdFtpXTtcclxuICAgICAgICAgICAgaWYgKGluc3RhbmNlLlRvdGFsID4gMCkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgdHlwZSA9ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgMDogJ21haW4nLFxyXG4gICAgICAgICAgICAgICAgICAgIDE6ICdvcGVuJyxcclxuICAgICAgICAgICAgICAgICAgICAyOiAnZ2VuZXJhbCdcclxuICAgICAgICAgICAgICAgIH0pW2ldO1xyXG4gICAgICAgICAgICAgICAgaW5zdGFuY2UuRGF0YS5mb3JFYWNoKGkgPT4gaS5JbnN0YW5jZVJlZlR5cGUgPSB0eXBlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc3VsdC5yZWR1Y2UoKHAsIGMpID0+IHAuY29uY2F0KGMuRGF0YSksIFtdKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBnZXRNYWluQnlJZChpbnN0YW5jZUlkKSB7XHJcbiAgICAgICAgY29uc3QgZmlsdGVyID0gKCgpID0+IHtcclxuICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoaW5zdGFuY2VJZCkpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBgSWR+ZXF+JHtpbnN0YW5jZUlkLmpvaW4oJ35vcn5JZH5lcX4nKX1gO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGBJZH5lcX4ke2luc3RhbmNlSWR9YDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKCk7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3RyYWluaW5ncy91c2Vyc2luY291cnNlcy9yZWFkY291cnNlaW5zdGFuY2VzJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwMCxcclxuICAgICAgICAgICAgZmlsdGVyXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0T3BlbkJ5SWQoaW5zdGFuY2VJZCkge1xyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KGluc3RhbmNlSWQpKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gYElkfmVxfiR7aW5zdGFuY2VJZC5qb2luKCd+b3J+SWR+ZXF+Jyl9YDtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBgSWR+ZXF+JHtpbnN0YW5jZUlkfWA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KSgpO1xyXG4gICAgICAgIGNvbnN0IHVyaSA9IGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl90cmFpbmluZ3MvdXNlcnNpbmZhc3R0cmFja3MvcmVhZGZhc3R0cmFja2luc3RhbmNlcycpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwMDAsXHJcbiAgICAgICAgICAgIGZpbHRlclxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGdldEdlbmVyYWxCeUlkKGluc3RhbmNlSWQpIHtcclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSAoKCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShpbnN0YW5jZUlkKSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGBJZH5lcX4ke2luc3RhbmNlSWQuam9pbignfm9yfklkfmVxficpfWA7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gYElkfmVxfiR7aW5zdGFuY2VJZH1gO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSkoKTtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdHJhaW5pbmdzL3VzZXJzaW5nZW5lcmFsY291cnNlaW5zdGFuY2VzL3JlYWRnZW5lcmFsY291cnNlaW5zdGFuY2VzJyk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAwMCxcclxuICAgICAgICAgICAgZmlsdGVyXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0SW5zdGFuY2VQYWdlKGluc3RhbmNlSWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgdHJhaW5pbmdzL3RyYWluaW5ncy9nZXRjb3Vyc2VkZXRhaWxzP2lkPSR7aW5zdGFuY2VJZH1gKTtcclxuICAgICAgICByZXR1cm4gZ2V0KHVyaSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0SW5zdGFuY2VGdWxsUGFnZSh1cmwpIHtcclxuICAgICAgICByZXR1cm4gZ2V0KHVybCk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0VHJhaW5lck5hbWVzKGluc3RhbmNlSWQpIHtcclxuICAgICAgICByZXR1cm4gKGF3YWl0IGZldGNoKGludGVyb3BIb3N0KGBrZW5kb3JlbW90ZWRhdGEvZ2V0dHJhaW5lcnNieXRyYWluaW5nP3RyYWluaW5nSWQ9JHtpbnN0YW5jZUlkfWApLCB7XHJcbiAgICAgICAgICAgICdjcmVkZW50aWFscyc6ICdpbmNsdWRlJyxcclxuICAgICAgICAgICAgJ2hlYWRlcnMnOiB7XHJcbiAgICAgICAgICAgICAgICAnVXNlci1BZ2VudCc6ICdNb3ppbGxhLzUuMCAoV2luZG93cyBOVCAxMC4wOyBXaW42NDsgeDY0OyBydjo5Ni4wKSBHZWNrby8yMDEwMDEwMSBGaXJlZm94Lzk2LjAnLFxyXG4gICAgICAgICAgICAgICAgJ0FjY2VwdCc6ICcqLyonLFxyXG4gICAgICAgICAgICAgICAgJ0FjY2VwdC1MYW5ndWFnZSc6ICdlbi1VUyxlbjtxPTAuNScsXHJcbiAgICAgICAgICAgICAgICAnWC1SZXF1ZXN0ZWQtV2l0aCc6ICdYTUxIdHRwUmVxdWVzdCcsXHJcbiAgICAgICAgICAgICAgICAnUHJhZ21hJzogJ25vLWNhY2hlJyxcclxuICAgICAgICAgICAgICAgICdDYWNoZS1Db250cm9sJzogJ25vLWNhY2hlJyxcclxuICAgICAgICAgICAgICAgICdTZWMtRmV0Y2gtRGVzdCc6ICdlbXB0eScsXHJcbiAgICAgICAgICAgICAgICAnU2VjLUZldGNoLU1vZGUnOiAnbm8tY29ycycsXHJcbiAgICAgICAgICAgICAgICAnU2VjLUZldGNoLVNpdGUnOiAnc2FtZS1vcmlnaW4nXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICdtZXRob2QnOiAnR0VUJyxcclxuICAgICAgICAgICAgJ21vZGUnOiAnY29ycydcclxuICAgICAgICB9KSkuanNvbigpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgLi4uZXZlbnRzQXBpLFxyXG4gICAgICAgIC4uLmxlY3R1cmVzQXBpLFxyXG4gICAgICAgIC4uLnNraWxsc0FwaSxcclxuICAgICAgICAuLi5ncm91cHNBcGksXHJcbiAgICAgICAgLi4uZXhhbXNBcGksXHJcbiAgICAgICAgLi4uYXNzZXNzbWVudEFwaSxcclxuICAgICAgICAuLi5zZW1pbmFyc0FwaSxcclxuICAgICAgICBzZWFyY2hCeU5hbWUsXHJcbiAgICAgICAgc2VhcmNoQ291cnNlcyxcclxuICAgICAgICBnZXRDb3Vyc2VEYXRhLFxyXG4gICAgICAgIGdldENvdXJzZUluc3RhbmNlcyxcclxuICAgICAgICBnZXRJbnN0YW5jZURhdGEsXHJcbiAgICAgICAgZ2V0SW5zdGFuY2VPdmVydmlldyxcclxuICAgICAgICB1cGRhdGVDb3Vyc2UsXHJcbiAgICAgICAgdXBkYXRlSW5zdGFuY2UsXHJcbiAgICAgICAgZ2V0U3R1ZGVudHMsXHJcbiAgICAgICAgZ2V0Q291cnNlRXZlbnRzLFxyXG4gICAgICAgIGdldEFueUJ5SWQsXHJcbiAgICAgICAgZ2V0SW5zdGFuY2VQYWdlLFxyXG4gICAgICAgIGdldEluc3RhbmNlRnVsbFBhZ2UsXHJcbiAgICAgICAgZ2V0VHJhaW5lck5hbWVzLFxyXG4gICAgICAgIHNlYXJjaENvdXJzZUluc3RhbmNlc0J5Q291cnNlTmFtZUFuZEluc3RhbmNlSWQsXHJcbiAgICAgICAgc2VhcmNoVHJhaW5pbmdzQnlOYW1lXHJcbiAgICB9O1xyXG59IiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHsgaW50ZXJvcEhvc3QsIGludGVyb3BBcHBJZCwgcGFyYW1zLCBwb3N0LCBnZXQgfSkge1xyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0VHJhaW5pbmdzQnlUcmFpbmVyKHVzZXJJZCkge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChpbnRlcm9wQXBwSWQoKSA9PT0gJ3NvZnR1bmkuYmcnKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gaW50ZXJvcEhvc3QoYGFkbWluaXN0cmF0aW9uX3VzZXJzL3RyYWluZXJzaW50cmFpbmluZ3MvcmVhZHRyYWluaW5nc29mdHJhaW5lcj90cmFpbmVySWQ9JHt1c2VySWR9YCk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gaW50ZXJvcEhvc3QoYEFkbWluaXN0cmF0aW9uX1VzZXJzL1RyYWluZXJzSW5UcmFpbmluZ3MvUmVhZD9mb3JlaWduS2V5PSR7dXNlcklkfSZmb3JlaWduS2V5SWQ9JHt1c2VySWR9YCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KSgpO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAwLFxyXG4gICAgICAgICAgICBzb3J0OiAnTW9kaWZpZWRPbi1kZXNjJ1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBwb3N0KHVyaSwgYm9keSk7XHJcbiAgICAgICAgcmVzdWx0LkRhdGEuZm9yRWFjaCh0ID0+IHtcclxuICAgICAgICAgICAgdC5EZXNjcmlwdGlvbkJnID0gdC5EZXNjcmlwdGlvbkJnIHx8ICcnO1xyXG4gICAgICAgICAgICB0LkRlc2NyaXB0aW9uRW4gPSB0LkRlc2NyaXB0aW9uRW4gfHwgJyc7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0VHJhaW5lckJ5SWQodXNlcklkKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gKCgpID0+IHtcclxuICAgICAgICAgICAgaWYgKGludGVyb3BBcHBJZCgpID09PSAnc29mdHVuaS5iZycpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdXNlcnMvdHJhaW5lcnNpbnRyYWluaW5ncy9yZWFkJyk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gaW50ZXJvcEhvc3QoJ0FkbWluaXN0cmF0aW9uX1VzZXJzL1RyYWluZXJzL1JlYWQnKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKCk7XHJcbiAgICAgICAgY29uc3QgYm9keSA9IHBhcmFtcyh7XHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiAxMDAsXHJcbiAgICAgICAgICAgIGZpbHRlcjogYFVzZXJJZH5lcX4nJHt1c2VySWR9J2BcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB1cGRhdGVUcmFpbmluZ0J5VHJhaW5lcih0cmFpbmluZykge1xyXG4gICAgICAgIGNvbnN0IHVyaSA9ICgoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChpbnRlcm9wQXBwSWQoKSA9PT0gJ3NvZnR1bmkuYmcnKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3VzZXJzL3RyYWluZXJzaW50cmFpbmluZ3MvVXBkYXRlVHJhaW5lckluVHJhaW5pbmcnKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBpbnRlcm9wSG9zdCgnQWRtaW5pc3RyYXRpb25fVXNlcnMvVHJhaW5lcnNJblRyYWluaW5ncy9VcGRhdGUnKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKCk7XHJcblxyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBUcmFpbmluZ0lkOiB0cmFpbmluZy5UcmFpbmluZ0lkLFxyXG4gICAgICAgICAgICBUcmFpbmluZ05hbWU6IHRyYWluaW5nLlRyYWluaW5nTmFtZSxcclxuICAgICAgICAgICAgVHJhaW5lckZpcnN0TmFtZTogdHJhaW5pbmcuVHJhaW5lckZpcnN0TmFtZSxcclxuICAgICAgICAgICAgVHJhaW5lckxhc3ROYW1lOiB0cmFpbmluZy5UcmFpbmVyTGFzdE5hbWUsXHJcbiAgICAgICAgICAgIFRyYWluZXJJZDogdHJhaW5pbmcuVHJhaW5lcklkLFxyXG4gICAgICAgICAgICBUcmFpbmVyT3JkZXJCeTogdHJhaW5pbmcuVHJhaW5lck9yZGVyQnksXHJcbiAgICAgICAgICAgIElzUHVibGljVHJhaW5lcjogdHJhaW5pbmcuSXNQdWJsaWNUcmFpbmVyLFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkJnOiB0cmFpbmluZy5EZXNjcmlwdGlvbkJnLFxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvbkVuOiB0cmFpbmluZy5EZXNjcmlwdGlvbkVuLFxyXG4gICAgICAgICAgICBUcmFpbmVyUGhvdG9QYXRoOiB0cmFpbmluZy5UcmFpbmVyUGhvdG9QYXRoLFxyXG4gICAgICAgICAgICBDcmVhdGVkT246ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNycsXHJcbiAgICAgICAgICAgIE1vZGlmaWVkT246ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNydcclxuICAgICAgICB9KTtcclxuICAgICAgICBPYmplY3Qua2V5cyhib2R5KS5mb3JFYWNoKGsgPT4geyBpZiAoYm9keVtrXSA9PT0gbnVsbCB8fCBib2R5W2tdID09PSB1bmRlZmluZWQpIHsgYm9keVtrXSA9ICcnOyB9IH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVRyYWluaW5nQnlUcmFpbmVyKHRyYWluaW5nKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEFwcElkKCkgPT09ICdzb2Z0dW5pLmJnJyA/XHJcbiAgICAgICAgICAgIGludGVyb3BIb3N0KGBhZG1pbmlzdHJhdGlvbl91c2Vycy90cmFpbmVyc2ludHJhaW5pbmdzL0FkZFRyYWluZXJUb1RyYWluaW5nP3VzZXJJZD0ke3RyYWluaW5nLlRyYWluZXJJZH1gKSA6XHJcbiAgICAgICAgICAgIGludGVyb3BIb3N0KGBBZG1pbmlzdHJhdGlvbl9Vc2Vycy9UcmFpbmVyc0luVHJhaW5pbmdzL0NyZWF0ZT9mb3JlaWduS2V5PSR7dHJhaW5pbmcuVHJhaW5lcklkfWApO1xyXG5cclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgVHJhaW5pbmdJZDogdHJhaW5pbmcuVHJhaW5pbmdJZCxcclxuICAgICAgICAgICAgVHJhaW5pbmdOYW1lOiB0cmFpbmluZy5UcmFpbmluZ05hbWUsXHJcbiAgICAgICAgICAgIFRyYWluZXJGaXJzdE5hbWU6IHRyYWluaW5nLlRyYWluZXJGaXJzdE5hbWUsXHJcbiAgICAgICAgICAgIFRyYWluZXJMYXN0TmFtZTogdHJhaW5pbmcuVHJhaW5lckxhc3ROYW1lLFxyXG4gICAgICAgICAgICBUcmFpbmVySWQ6IHRyYWluaW5nLlRyYWluZXJJZCxcclxuICAgICAgICAgICAgVHJhaW5lck9yZGVyQnk6IHRyYWluaW5nLlRyYWluZXJPcmRlckJ5LFxyXG4gICAgICAgICAgICBJc1B1YmxpY1RyYWluZXI6IHRyYWluaW5nLklzUHVibGljVHJhaW5lcixcclxuICAgICAgICAgICAgRGVzY3JpcHRpb25CZzogdHJhaW5pbmcuRGVzY3JpcHRpb25CZyxcclxuICAgICAgICAgICAgRGVzY3JpcHRpb25FbjogdHJhaW5pbmcuRGVzY3JpcHRpb25FbixcclxuICAgICAgICAgICAgVHJhaW5lclBob3RvUGF0aDogdHJhaW5pbmcuVHJhaW5lclBob3RvUGF0aCxcclxuICAgICAgICAgICAgQ3JlYXRlZE9uOiAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnLFxyXG4gICAgICAgICAgICBNb2RpZmllZE9uOiAnMjAxOS0wNy0zMVQxNzozOTowMS4zMTcnXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwgfHwgYm9keVtrXSA9PT0gdW5kZWZpbmVkKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBzZWFyY2hVc2VycyhxdWVyeSwgZXhjbHVkZSkge1xyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgICAgICAgc2VhcmNoVXNlcnNCeU5hbWUocXVlcnksIGV4Y2x1ZGUpLFxyXG4gICAgICAgICAgICBzZWFyY2hVc2Vyc0J5VXNlck5hbWUocXVlcnksIGV4Y2x1ZGUpXHJcbiAgICAgICAgXSk7XHJcblxyXG4gICAgICAgIHJldHVybiByZXN1bHRbMF0uY29uY2F0KHJlc3VsdFsxXSk7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZGVzdHJveVRyYWluaW5nT2ZUcmFpbmVyKHRyYWluaW5nKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEFwcElkKCkgPT09ICdzb2Z0dW5pLmJnJyA/XHJcbiAgICAgICAgICAgIGludGVyb3BIb3N0KCdhZG1pbmlzdHJhdGlvbl91c2Vycy90cmFpbmVyc2ludHJhaW5pbmdzL0RlbGV0ZVRyYWluZXJGcm9tVHJhaW5pbmcnKSA6XHJcbiAgICAgICAgICAgIGludGVyb3BIb3N0KCdBZG1pbmlzdHJhdGlvbl9Vc2Vycy9UcmFpbmVyc0luVHJhaW5pbmdzL0Rlc3Ryb3knKTtcclxuXHJcbiAgICAgICAgY29uc3QgYm9keSA9IE9iamVjdC5hc3NpZ24ocGFyYW1zKCksIHRyYWluaW5nKTtcclxuICAgICAgICBib2R5LkNyZWF0ZWRPbiA9ICcyMDE5LTA3LTMxVDE3OjM5OjAxLjMxNyc7XHJcbiAgICAgICAgYm9keS5Nb2RpZmllZE9uID0gJzIwMTktMDctMzFUMTc6Mzk6MDEuMzE3JztcclxuXHJcbiAgICAgICAgT2JqZWN0LmtleXMoYm9keSkuZm9yRWFjaChrID0+IHsgaWYgKGJvZHlba10gPT09IG51bGwgfHwgYm9keVtrXSA9PT0gdW5kZWZpbmVkKSB7IGJvZHlba10gPSAnJzsgfSB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHBvc3QodXJpLCBib2R5KTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBzZWFyY2hVc2Vyc0J5TmFtZShuYW1lLCBleGNsdWRlKSB7XHJcbiAgICAgICAgY29uc3QgdXJpID0gaW50ZXJvcEhvc3QoJ2FkbWluaXN0cmF0aW9uX3VzZXJzL3VzZXJzL3JlYWQnKTtcclxuXHJcbiAgICAgICAgbGV0IGZpbHRlciA9IG5hbWUuaW5jbHVkZXMoJyAnKSA/XHJcbiAgICAgICAgICAgIGAoRmlyc3ROYW1lRW5+ZXF+JyR7bmFtZS5zcGxpdCgnICcpWzBdfSd+YW5kfkxhc3ROYW1lRW5+c3RhcnRzd2l0aH4nJHtuYW1lLnNwbGl0KCcgJylbMV19Jyl+b3J+KEZpcnN0TmFtZUJnfmVxficke25hbWUuc3BsaXQoJyAnKVswXX0nfmFuZH5MYXN0TmFtZUJnfnN0YXJ0c3dpdGh+JyR7bmFtZS5zcGxpdCgnICcpWzFdfScpYCA6XHJcbiAgICAgICAgICAgIGBGaXJzdE5hbWVFbn5jb250YWluc34nJHtuYW1lfSd+b3J+TGFzdE5hbWVFbn5jb250YWluc34nJHtuYW1lfSd+b3J+Rmlyc3ROYW1lQmd+Y29udGFpbnN+JyR7bmFtZX0nfm9yfkxhc3ROYW1lQmd+Y29udGFpbnN+JyR7bmFtZX0nYDtcclxuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShleGNsdWRlKSkge1xyXG4gICAgICAgICAgICBmaWx0ZXIgPSBgKCR7ZmlsdGVyfSl+YW5kfihJZH5uZXF+JyR7ZXhjbHVkZS5qb2luKCdcXCd+YW5kfklkfm5lcX5cXCcnKX0nKWA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBzb3J0OiAnVXNlck5hbWUtYXNjJyxcclxuICAgICAgICAgICAgcGFnZVNpemU6IDUsXHJcbiAgICAgICAgICAgIGZpbHRlclxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gKGF3YWl0IHBvc3QodXJpLCBib2R5KSkuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBzZWFyY2hVc2Vyc0J5VXNlck5hbWUobmFtZSwgZXhjbHVkZSkge1xyXG4gICAgICAgIGlmIChuYW1lLmluY2x1ZGVzKCcgJykpIHtcclxuICAgICAgICAgICAgcmV0dXJuIFtdO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdCgnYWRtaW5pc3RyYXRpb25fdXNlcnMvdXNlcnMvcmVhZCcpO1xyXG5cclxuICAgICAgICBsZXQgZmlsdGVyID0gYFVzZXJOYW1lfmNvbnRhaW5zficke25hbWV9J2A7XHJcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoZXhjbHVkZSkpIHtcclxuICAgICAgICAgICAgZmlsdGVyID0gYCgke2ZpbHRlcn0pfmFuZH4oSWR+bmVxficke2V4Y2x1ZGUuam9pbignXFwnfmFuZH5JZH5uZXF+XFwnJyl9JylgO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCBib2R5ID0gcGFyYW1zKHtcclxuICAgICAgICAgICAgc29ydDogJ1VzZXJOYW1lLWFzYycsXHJcbiAgICAgICAgICAgIHBhZ2VTaXplOiA1LFxyXG4gICAgICAgICAgICBmaWx0ZXJcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChhd2FpdCBwb3N0KHVyaSwgYm9keSkpLkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZ2V0VHJhaW5lcnNCeVRyYWluaW5nKHRyYWluaW5nSWQpIHtcclxuICAgICAgICBjb25zdCB1cmkgPSBpbnRlcm9wSG9zdChgQWRtaW5pc3RyYXRpb25fVHJhaW5pbmdzL1RyYWluaW5nc1dpdGhUcmFpbmVycy9SZWFkP2ZvcmVpZ25LZXk9JHt0cmFpbmluZ0lkfSZmb3JlaWduS2V5SWQ9JHt0cmFpbmluZ0lkfWApO1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBwYXJhbXMoe1xyXG4gICAgICAgICAgICBwYWdlU2l6ZTogMTAsXHJcbiAgICAgICAgICAgIHNvcnQ6ICdPcmRlckJ5LWFzYydcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcG9zdCh1cmksIGJvZHkpO1xyXG4gICAgICAgIHJlc3VsdC5EYXRhLmZvckVhY2godCA9PiB7XHJcbiAgICAgICAgICAgIHQuRGVzY3JpcHRpb25CZyA9IHQuRGVzY3JpcHRpb25CZyB8fCAnJztcclxuICAgICAgICAgICAgdC5EZXNjcmlwdGlvbkVuID0gdC5EZXNjcmlwdGlvbkVuIHx8ICcnO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gcmVzdWx0LkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBnZXRUcmFpbmluZ3NCeVRyYWluZXIsXHJcbiAgICAgICAgZ2V0VHJhaW5lckJ5SWQsXHJcbiAgICAgICAgdXBkYXRlVHJhaW5pbmdCeVRyYWluZXIsXHJcbiAgICAgICAgY3JlYXRlVHJhaW5pbmdCeVRyYWluZXIsXHJcbiAgICAgICAgZGVzdHJveVRyYWluaW5nT2ZUcmFpbmVyLFxyXG4gICAgICAgIHNlYXJjaFVzZXJzLFxyXG4gICAgICAgIGdldFRyYWluZXJzQnlUcmFpbmluZ1xyXG4gICAgfTtcclxufSIsImV4cG9ydCBhc3luYyBmdW5jdGlvbiBwYXJzZUNyb3NzQnJvd3NlckZpbGUoZmlsZURlc2NyaXB0b3IpIHtcclxuICAgIGxldCBibG9iO1xyXG4gICAgbGV0IGZpbGVuYW1lO1xyXG4gICAgaWYgKGZpbGVEZXNjcmlwdG9yLmZpbGVVcmwgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgIGJsb2IgPSBhd2FpdCAoYXdhaXQgZmV0Y2goZmlsZURlc2NyaXB0b3IuZmlsZVVybCkpLmJsb2IoKTtcclxuICAgICAgICBmaWxlbmFtZSA9IGZpbGVEZXNjcmlwdG9yLm5hbWU7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIGJsb2IgPSBmaWxlRGVzY3JpcHRvci5maWxlO1xyXG4gICAgICAgIGZpbGVuYW1lID0gZmlsZURlc2NyaXB0b3IuZmlsZS5uYW1lO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7IGJsb2IsIGZpbGVuYW1lIH07XHJcbn0iLCJpbXBvcnQgZG9tLCB7IEZyYWdtZW50IH0gZnJvbSAnLi4vdXRpbC9qc3gtcmVuZGVyLW1vZC9kb20nO1xyXG5pbXBvcnQgUHJvZ3Jlc3NCYXIgZnJvbSAnLi4vY29tbW9uL1Byb2dyZXNzQmFyJztcclxuXHJcblxyXG5cclxuY29uc3QgaWNvbnMgPSB7XHJcbiAgICBxdWVzdGlvbjogJ2dseXBoaWNvbi1xdWVzdGlvbi1zaWduJyxcclxuICAgIHdhaXQ6ICdnbHlwaGljb24taG91cmdsYXNzJyxcclxuICAgIHdyZW5jaDogJ2dseXBoaWNvbi13cmVuY2gnLFxyXG4gICAgaW1wb3J0OiAnZ2x5cGhpY29uLWltcG9ydCcsXHJcbiAgICBkb3dubG9hZDogJ2dseXBoaWNvbi1kb3dubG9hZC1hbHQnLFxyXG4gICAgY2hhcnQ6ICdnbHlwaGljb24tc2lnbmFsJ1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTW9kYWwoeyBtZXNzYWdlLCBjaGlsZHJlbiwgb25DbG9zZSwgaWNvbiA9ICdxdWVzdGlvbicgfSkge1xyXG4gICAgaWYgKEFycmF5LmlzQXJyYXkobWVzc2FnZSkgPT0gZmFsc2UpIHtcclxuICAgICAgICBtZXNzYWdlID0gW21lc3NhZ2VdO1xyXG4gICAgfVxyXG4gICAgY29uc3QgY29udGVudCA9ICg8ZGl2IGNsYXNzTmFtZT1cInNlcy1tb2RhbC1jb250ZW50XCI+XHJcbiAgICAgICAge2NoaWxkcmVufVxyXG4gICAgPC9kaXY+KTtcclxuXHJcbiAgICBjb25zdCBtb2RhbCA9IChcclxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzZXMtbW9kYWxcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXMtbW9kYWwtd2luZG93XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlcy1tb2RhbC1tZXNzYWdlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2ljb24gJiYgPGkgY2xhc3NOYW1lPXtgZ2x5cGhpY29uICR7aWNvbnNbaWNvbl19IHNlcy1tb2RhbC1pY29uYH0+PC9pPn1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7bWVzc2FnZS5tYXAobSA9PiA8cD57bX08L3A+KX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAge2NvbnRlbnR9XHJcbiAgICAgICAgICAgICAgICB7b25DbG9zZSAhPT0gdW5kZWZpbmVkID9cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlcy1tb2RhbC1jbG9zZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVwiamF2YXNjcmlwdDp2b2lkKDApO1wiIG9uQ2xpY2s9e29uQ2xvc2V9PjxpIGNsYXNzPVwiZ2x5cGhpY29uIGdseXBoaWNvbi1yZW1vdmVcIiBzdHlsZT17eyBjb2xvcjogJ3JlZCcgfX0+PC9pPjwvYT5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj4gOlxyXG4gICAgICAgICAgICAgICAgICAgIG51bGx9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgICk7XHJcblxyXG4gICAgbW9kYWwuX2NvbnRlbnQgPSBjb250ZW50O1xyXG5cclxuICAgIHJldHVybiBtb2RhbDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIE1vZGFsQ29udHJvbHMoeyBjaGlsZHJlbiB9KSB7XHJcbiAgICByZXR1cm4gKDx0YWJsZT5cclxuICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgIHtjaGlsZHJlbn1cclxuICAgICAgICA8L3Rib2R5PlxyXG4gICAgPC90YWJsZT4pO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gTW9kYWxPcHRpb24oeyBpY29uID0gbnVsbCwgb25DbGljaywgY2hpbGRyZW4gfSkge1xyXG4gICAgcmV0dXJuICg8dHIgY2xhc3NOYW1lPVwic2VzLW1vZGFsLWFjdGl2ZVwiIG9uQ2xpY2s9e29uQ2xpY2t9PlxyXG4gICAgICAgIDx0ZD57aWNvbn08L3RkPlxyXG4gICAgICAgIDx0ZD57Y2hpbGRyZW59PC90ZD5cclxuICAgIDwvdHI+KTtcclxufVxyXG5cclxuLyoqXHJcbiAqIFxyXG4gKiBAcGFyYW0ge3N0cmluZ30gbWVzc2FnZSBcclxuICogQHBhcmFtIHtIVE1MRWxlbWVudCB8IEFycmF5PEhUTUxFbGVtZW50Pn0gY2hpbGRyZW4gXHJcbiAqIEBwYXJhbSB7Qm9vbGVhbn0gY2FuQ2xvc2UgXHJcbiAqIEByZXR1cm5zIHtJbnRlcmFjdGl2ZU1vZGFsfVxyXG4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZU1vZGFsKG1lc3NhZ2UsIGNoaWxkcmVuLCBjYW5DbG9zZSA9IHRydWUsIGljb24gPSAncXVlc3Rpb24nKSB7XHJcbiAgICAvKiogQHR5cGUge0ludGVyYWN0aXZlTW9kYWx9ICovXHJcbiAgICBjb25zdCBtb2RhbCA9ICg8TW9kYWwgbWVzc2FnZT17bWVzc2FnZX0gb25DbG9zZT17Y2FuQ2xvc2UgPyBjbG9zZSA6IHVuZGVmaW5lZH0gaWNvbj17aWNvbn0+e2NoaWxkcmVufTwvTW9kYWw+KTtcclxuXHJcbiAgICBpZiAoY2FuQ2xvc2UpIHtcclxuICAgICAgICBtb2RhbC5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIG9uQ2xpY2spO1xyXG4gICAgfVxyXG4gICAgbW9kYWwuY2xvc2UgPSBjbG9zZTtcclxuICAgIG1vZGFsLm9uQ2xvc2UgPSBudWxsO1xyXG5cclxuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQobW9kYWwpO1xyXG4gICAgY29uc3QgZGl2ID0gbW9kYWwuY2hpbGRyZW5bMF07XHJcbiAgICBhZGp1c3RQb3NpdGlvbigpO1xyXG4gICAgY29uc3QgcmVzaXplT2JzZXJ2ZXIgPSBuZXcgUmVzaXplT2JzZXJ2ZXIoYWRqdXN0UG9zaXRpb24pO1xyXG4gICAgcmVzaXplT2JzZXJ2ZXIub2JzZXJ2ZShtb2RhbC5fY29udGVudCk7XHJcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigncmVzaXplJywgYWRqdXN0UG9zaXRpb24pO1xyXG5cclxuICAgIHJldHVybiBtb2RhbDtcclxuXHJcbiAgICBmdW5jdGlvbiBvbkNsaWNrKGUpIHtcclxuICAgICAgICBpZiAoZS50YXJnZXQgPT09IG1vZGFsKSB7XHJcbiAgICAgICAgICAgIGNsb3NlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIGNsb3NlKHByb3BhZ2F0ZSA9IHRydWUpIHtcclxuICAgICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigncmVzaXplJywgYWRqdXN0UG9zaXRpb24pO1xyXG4gICAgICAgIHJlc2l6ZU9ic2VydmVyLmRpc2Nvbm5lY3QoKTtcclxuICAgICAgICBtb2RhbC5yZW1vdmUoKTtcclxuICAgICAgICBpZiAodHlwZW9mIG1vZGFsLm9uQ2xvc2UgPT0gJ2Z1bmN0aW9uJyAmJiBwcm9wYWdhdGUpIHtcclxuICAgICAgICAgICAgbW9kYWwub25DbG9zZSgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBhZGp1c3RQb3NpdGlvbigpIHtcclxuICAgICAgICBjb25zdCBuZXdUb3AgPSAobW9kYWwub2Zmc2V0SGVpZ2h0IC0gZGl2Lm9mZnNldEhlaWdodCkgLyAzO1xyXG4gICAgICAgIGRpdi5zdHlsZVsnbWFyZ2luLXRvcCddID0gbmV3VG9wICsgJ3B4JztcclxuICAgIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIEBwYXJhbSB7c3RyaW5nfSBtZXNzYWdlIFxyXG4gKiBAcGFyYW0ge0hUTUxFbGVtZW50IHwgQXJyYXk8SFRNTEVsZW1lbnQ+fSBjb250ZW50IFxyXG4gKiBAcGFyYW0ge0FycmF5PE9wdGlvbkRlc2NyaXB0b3I+fSBvcHRpb25zIFxyXG4gKiBAcGFyYW0ge0Jvb2xlYW59IGNhbkNsb3NlIFxyXG4gKiBAcmV0dXJucyB7UHJvbWlzZTxib29sZWFuPn1cclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVEaWFsb2cobWVzc2FnZSwgY29udGVudCwgb3B0aW9ucywgY2FuQ2xvc2UgPSB0cnVlLCBpY29uID0gJ3F1ZXN0aW9uJykge1xyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICBjb25zdCBjb250cm9scyA9IDxNb2RhbENvbnRyb2xzPlxyXG4gICAgICAgICAgICB7b3B0aW9ucy5tYXAoY3JlYXRlT3B0aW9uLmJpbmQobnVsbCwgb25Db25maXJtLCBvbkNhbmNlbCkpfVxyXG4gICAgICAgIDwvTW9kYWxDb250cm9scz47XHJcblxyXG4gICAgICAgIGNvbnN0IG1vZGFsID0gY3JlYXRlTW9kYWwobWVzc2FnZSwgW2NvbnRlbnQsIGNvbnRyb2xzXS5mbGF0KDEpLCBjYW5DbG9zZSwgaWNvbik7XHJcblxyXG4gICAgICAgIG1vZGFsLm9uQ2xvc2UgPSAoKSA9PiByZXNvbHZlKGZhbHNlKTtcclxuXHJcbiAgICAgICAgZnVuY3Rpb24gb25Db25maXJtKCkge1xyXG4gICAgICAgICAgICBtb2RhbC5jbG9zZShmYWxzZSk7XHJcbiAgICAgICAgICAgIHJlc29sdmUodHJ1ZSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBmdW5jdGlvbiBvbkNhbmNlbCgpIHtcclxuICAgICAgICAgICAgbW9kYWwuY2xvc2UoZmFsc2UpO1xyXG4gICAgICAgICAgICByZXNvbHZlKGZhbHNlKTtcclxuICAgICAgICB9XHJcbiAgICB9KTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEBwYXJhbSB7RnVuY3Rpb259IG9uQ29uZmlybSBcclxuICogQHBhcmFtIHtGdW5jdGlvbn0gb25DYW5jZWwgXHJcbiAqIEBwYXJhbSB7T3B0aW9uRGVzY3JpcHRvciB8IE9wdGlvbkVudHJ5fSBvcHRpb24gXHJcbiAqIEByZXR1cm5zIHtNb2RhbE9wdGlvbn1cclxuICovXHJcbmZ1bmN0aW9uIGNyZWF0ZU9wdGlvbihvbkNvbmZpcm0sIG9uQ2FuY2VsLCBvcHRpb24sIG9wdGlvbkluZGV4KSB7XHJcbiAgICBjb25zdCB7IGljb24gPSBudWxsLCBsYWJlbCwgcm9sZSwgb25DbGljaywgY29uZmlybUNoZWNrIH0gPSBBcnJheS5pc0FycmF5KG9wdGlvbikgPyB7XHJcbiAgICAgICAgaWNvbjogb3B0aW9uWzBdLFxyXG4gICAgICAgIGxhYmVsOiBvcHRpb25bMV0sXHJcbiAgICAgICAgcm9sZTogb3B0aW9uWzJdLFxyXG4gICAgICAgIG9uQ2xpY2s6IG9wdGlvblsyXVxyXG4gICAgfSA6IG9wdGlvbjtcclxuXHJcbiAgICByZXR1cm4gPE1vZGFsT3B0aW9uIGljb249e2ljb259IG9uQ2xpY2s9e2NhbGxiYWNrfT57bGFiZWx9PC9Nb2RhbE9wdGlvbj47XHJcblxyXG4gICAgZnVuY3Rpb24gY2FsbGJhY2soZXZlbnQpIHtcclxuICAgICAgICBpZiAocm9sZSA9PSAnb2snKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgY29uZmlybUNoZWNrID09ICdmdW5jdGlvbicgJiYgY29uZmlybUNoZWNrKCkgIT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIG9uQ29uZmlybSgpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAocm9sZSA9PSAnY2FuY2VsJykge1xyXG4gICAgICAgICAgICBvbkNhbmNlbCgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBvbkNsaWNrID09ICdmdW5jdGlvbicpIHtcclxuICAgICAgICAgICAgb25DbGljayhldmVudCwgb3B0aW9uSW5kZXgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIEBwYXJhbSB7QXJyYXk8c3RyaW5nPiB8IHN0cmluZ30gbWVzc2FnZXMgXHJcbiAqIEByZXR1cm5zIHt7bmV4dEJhcjogRnVuY3Rpb259ICYgSW50ZXJhY3RpdmVNb2RhbH1cclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVMb2FkaW5nTW9kYWwobWVzc2FnZXMpIHtcclxuICAgIGlmIChBcnJheS5pc0FycmF5KG1lc3NhZ2VzKSA9PSBmYWxzZSkge1xyXG4gICAgICAgIG1lc3NhZ2VzID0gW21lc3NhZ2VzXTtcclxuICAgIH1cclxuICAgIGNvbnN0IGJhcnMgPSBtZXNzYWdlcy5tYXAobSA9PiBQcm9ncmVzc0Jhcig0MDAsIG0sIG9uRmluaXNoKSk7XHJcbiAgICBsZXQgZmluaXNoZWQgPSAwO1xyXG4gICAgbGV0IGN1cnJlbnQgPSAwO1xyXG5cclxuICAgIGNvbnN0IG1vZGFsID0gY3JlYXRlTW9kYWwoYmFycywgbnVsbCwgZmFsc2UsICd3YWl0Jyk7XHJcbiAgICBtb2RhbC5uZXh0QmFyID0gbmV4dEJhcjtcclxuXHJcbiAgICByZXR1cm4gbW9kYWw7XHJcblxyXG4gICAgZnVuY3Rpb24gbmV4dEJhcigpIHtcclxuICAgICAgICBpZiAoY3VycmVudCA8IGJhcnMubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBiYXJzW2N1cnJlbnQrK10ub25Qcm9ncmVzcztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gb25GaW5pc2goKSB7XHJcbiAgICAgICAgZmluaXNoZWQrKztcclxuICAgICAgICBpZiAoZmluaXNoZWQgPT0gYmFycy5sZW5ndGgpIHtcclxuICAgICAgICAgICAgbW9kYWwuY2xvc2UoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcblxyXG4vKipcclxuICogQHR5cGVkZWYge09iamVjdH0gT3B0aW9uRGVzY3JpcHRvclxyXG4gKiBAcHJvcGVydHkge0hUTUxFbGVtZW50fSBbaWNvbj1udWxsXVxyXG4gKiBAcHJvcGVydHkge3N0cmluZ30gbGFiZWxcclxuICogQHByb3BlcnR5IHtcIm9rXCIgfCBcImNhbmNlbFwifSBbcm9sZT1dXHJcbiAqIEBwcm9wZXJ0eSB7RnVuY3Rpb259IFtvbkNsaWNrPV1cclxuICovXHJcblxyXG4vKipcclxuICogQHR5cGVkZWYge1tIVE1MRWxlbWVudCB8IG51bGwsIHN0cmluZywgXCJva1wiIHwgXCJjYW5jZWxcIiB8IHVuZGVmaW5lZCB8IEZ1bmN0aW9uXX0gT3B0aW9uRW50cnlcclxuICovXHJcblxyXG4vKipcclxuICogQHR5cGVkZWYge09iamVjdH0gSW50ZXJhY3RpdmVNb2RhbFxyXG4gKiBAcHJvcGVydHkge0Z1bmN0aW9ufSBjbG9zZVxyXG4gKiBAcHJvcGVydHkgeyhldmVudDogRXZlbnQsIG9wdGlvbkluZGV4OiBudW1iZXIpID0+IHt9fSBbb25DbG9zZT1udWxsXVxyXG4gKi8iLCJpbXBvcnQgZG9tIGZyb20gJy4uL3V0aWwvanN4LXJlbmRlci1tb2QvZG9tJztcclxuXHJcblxyXG4vKipcclxuICogQHBhcmFtIHtudW1iZXJ9IHdpZHRoIFxyXG4gKiBAcGFyYW0ge3N0cmluZ30gbGFiZWwgXHJcbiAqIEByZXR1cm5zIHtQcm9ncmVzc0JhckVsZW1lbnR9XHJcbiAqL1xyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQcm9ncmVzc0Jhcih3aWR0aCwgbGFiZWwsIG9uRmluaXNoKSB7XHJcbiAgICBjb25zdCBwZXJjZW50ID0gPHNwYW4+MCU8L3NwYW4+O1xyXG4gICAgLyoqIEB0eXBlIHtQcm9ncmVzc0JhckVsZW1lbnR9ICovXHJcbiAgICBjb25zdCBiYXIgPSA8c3BhbiBzdHlsZT17eyBwYWRkaW5nOiAnMCAwLjVlbScsIGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snLCB3aWR0aDogd2lkdGggKyAncHgnLCBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZmZhMDAwIDAlLCAjZWVlIDApJyB9fT57cGVyY2VudH17bGFiZWwgPyBgICR7bGFiZWx9YCA6IG51bGx9PC9zcGFuPjtcclxuICAgIGJhci5vblByb2dyZXNzID0gb25Qcm9ncmVzcztcclxuXHJcbiAgICByZXR1cm4gYmFyO1xyXG5cclxuICAgIGZ1bmN0aW9uIG9uUHJvZ3Jlc3MoY29tcGxldGVkLCB0b3RhbCkge1xyXG4gICAgICAgIGNvbnN0IHByb2dyZXNzID0gdG90YWwgPT0gMCA/IDEwMCA6IE1hdGguZmxvb3IoY29tcGxldGVkIC8gdG90YWwgKiAxMDApO1xyXG4gICAgICAgIHBlcmNlbnQudGV4dENvbnRlbnQgPSBwcm9ncmVzcyArICclJztcclxuICAgICAgICBiYXIuc3R5bGUuYmFja2dyb3VuZCA9IGBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICNmZmEwMDAgJHtwcm9ncmVzc30lLCAjZWVlIDApYDtcclxuXHJcbiAgICAgICAgaWYgKCh0b3RhbCA9PSAwIHx8IGNvbXBsZXRlZCA9PSB0b3RhbCkgJiYgdHlwZW9mIG9uRmluaXNoID09ICdmdW5jdGlvbicpICB7XHJcbiAgICAgICAgICAgIG9uRmluaXNoKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG4vKipcclxuICogQHR5cGVkZWYge1Byb2dyZXNzQmFyU3BhbiAmIEhUTUxTcGFuRWxlbWVudH0gUHJvZ3Jlc3NCYXJFbGVtZW50XHJcbiAqIEBwcm9wZXJ0eSB7RnVuY3Rpb259IG9uUHJvZ3Jlc3NcclxuICovXHJcblxyXG4vKipcclxuICogQHR5cGVkZWYge09iamVjdH0gUHJvZ3Jlc3NCYXJTcGFuXHJcbiAqIEBwcm9wZXJ0eSB7RnVuY3Rpb259IG9uUHJvZ3Jlc3NcclxuICovIiwiaW1wb3J0IFNlc0FwaSBmcm9tICcuLi8uLi91dGlsL2FwaS1jb25uZWN0JztcclxuaW1wb3J0IHsgY2xlYXJDYWNoZSwgc3RvcmVzLCB3aXRoQ2FjaGUgfSBmcm9tICcuLi8uLi91dGlsL2RhdGEtY29ubmVjdCc7XHJcbmltcG9ydCBwYXJzZSwgeyB0b0Fzc29jQXJyYXkgfSBmcm9tICcuLi8uLi91dGlsL3BhcnNlJztcclxuaW1wb3J0IHsgZGlzdHJpYnV0ZSwgZXhwb3J0UGF5bWVudHNUb1hsc3gsIGdldFN1YnNpdGUgfSBmcm9tICcuLi8uLi91dGlsL3V0aWwnO1xyXG5cclxuXHJcbi8vVE9ETzogRXh0cmFjdCBpbnRvIFBheW1lbnRzIEJ1c2luZXNzIHNlcnZpY2Ugb24gdGhlIEFQSSBzaWRlXHJcbi8qKlxyXG4gKiBAdHlwZWRlZiB7T2JqZWN0fSBJbnN0YW5jZVJlZmVyZW5jZVxyXG4gKiBAcHJvcGVydHkge251bWJlcn0gSWRcclxuICogQHByb3BlcnR5IHtzdHJpbmd9IE5hbWVCZ1xyXG4gKiBAcHJvcGVydHkge3N0cmluZ30gTmFtZUVuXHJcbiAqL1xyXG4vKipcclxuICogQHBhcmFtIHtBcnJheTxJbnN0YW5jZVJlZmVyZW5jZT59IGl0ZW1zIFxyXG4gKiBAcGFyYW0ge2ltcG9ydCgnLi4vLi4vdXRpbC91dGlsJykuT25Qcm9ncmVzc0Z1bmN0aW9ufSBvbkNoYW5nZSBcclxuICogQHJldHVybnMge1Byb21pc2U8QXJyYXk8e2luc3RhbmNlOiBJbnN0YW5jZVJlZmVyZW5jZSwgcGF5bWVudHM6IEFycmF5PFNVUGF5bWVudD59Pj59XHJcbiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UGF5bWVudHMoaXRlbXMsIG9uQ2hhbmdlKSB7XHJcbiAgICBjb25zdCBpbnN0YW5jZXMgPSBpdGVtcy5yZWR1Y2UodG9Bc3NvY0FycmF5LCB7fSk7XHJcbiAgICBjb25zdCBwcm9kdWN0cyA9IGF3YWl0IGdldFByb2R1Y3RzKGluc3RhbmNlcyk7XHJcbiAgICBjb25zdCBwYWNrYWdlcyA9IGF3YWl0IGdldFBhY2thZ2VzKGluc3RhbmNlcywgcHJvZHVjdHMpO1xyXG5cclxuICAgIC8vIFRoaXMgcGF1c2UgZmFjaWxpdGF0ZXMgdGhlIHByb2dyZXNzIGJhciB1cGRhdGVyXHJcbiAgICBhd2FpdCBuZXcgUHJvbWlzZShyZXNvbHZlID0+IHNldFRpbWVvdXQocmVzb2x2ZSwgMTApKTtcclxuXHJcbiAgICBjb25zdCBwYXltZW50c0J5SW5zdGFuY2VJZCA9IChhd2FpdCBkaXN0cmlidXRlKE9iamVjdC52YWx1ZXMocGFja2FnZXMpLm1hcChjYWNoZWRQYXltZW50cyksIG9uQ2hhbmdlLCAzMDApKVxyXG4gICAgICAgIC5tYXAociA9PiByLkRhdGEpXHJcbiAgICAgICAgLnJlZHVjZSgoYSwgYykgPT4ge1xyXG4gICAgICAgICAgICBjLm1hcChpID0+IHBhcnNlUGF5bWVudChwYWNrYWdlcywgaSwgYSkpO1xyXG4gICAgICAgICAgICByZXR1cm4gYTtcclxuICAgICAgICB9LCB7fSk7XHJcblxyXG4gICAgLy9maWx0ZXIgcGF5bWVudHMgdG8gMSBwZXIgdXNlciBwZXIgbGV2ZWwgaW5zdGFuY2UsIHRvIHJlbW92ZSBleHRyYSBpbnN0YWxsbWVudCBwYXltZW50c1xyXG4gICAgT2JqZWN0LmtleXMocGF5bWVudHNCeUluc3RhbmNlSWQpLmZvckVhY2goayA9PiB7XHJcbiAgICAgICAgcGF5bWVudHNCeUluc3RhbmNlSWRba10gPSBBcnJheS5mcm9tKHBheW1lbnRzQnlJbnN0YW5jZUlkW2tdLnZhbHVlcygpKTtcclxuICAgIH0pXHJcblxyXG4gICAgY29uc3QgcGF5bWVudHMgPSBPYmplY3QuZW50cmllcyhwYXltZW50c0J5SW5zdGFuY2VJZCkubWFwKChbSW5zdGFuY2VJZCwgcGF5bWVudHNdKSA9PiAoeyBpbnN0YW5jZTogaW5zdGFuY2VzW0luc3RhbmNlSWRdLCBwYXltZW50cyB9KSk7XHJcblxyXG4gICAgcmV0dXJuIHBheW1lbnRzO1xyXG59XHJcblxyXG4vKipcclxuICogQHR5cGVkZWYge09iamVjdH0gUHJvZHVjdFZpZXdNb2RlbFxyXG4gKiBAcHJvcGVydHkge251bWJlcn0gSWRcclxuICogQHByb3BlcnR5IHtudW1iZXJ9IEVkdWNhdGlvbmFsRm9ybVxyXG4gKiBAcHJvcGVydHkge251bWJlcn0gTGV2ZWxJbnN0YW5jZUlkXHJcbiAqIEBwcm9wZXJ0eSB7c3RyaW5nfSBOYW1lQmdcclxuICogQHByb3BlcnR5IHtzdHJpbmd9IE5hbWVFblxyXG4gKiBAcHJvcGVydHkge3N0cmluZ30gTmFtZVxyXG4gKi9cclxuLyoqXHJcbiAqIEBwYXJhbSB7T2JqZWN0LjxudW1iZXIsIEluc3RhbmNlUmVmZXJlbmNlPn0gaW5zdGFuY2VzIFxyXG4gKiBAcmV0dXJucyB7UHJvbWlzZTxPYmplY3QuPG51bWJlciwgUHJvZHVjdFZpZXdNb2RlbD4+fVxyXG4gKi9cclxuYXN5bmMgZnVuY3Rpb24gZ2V0UHJvZHVjdHMoaW5zdGFuY2VzKSB7XHJcbiAgICByZXR1cm4gKGF3YWl0IFNlc0FwaS5nZXRQcm9kdWN0c0Zvck1vZHVsZShPYmplY3Qua2V5cyhpbnN0YW5jZXMpKSkuRGF0YVxyXG4gICAgICAgIC5tYXAoZSA9PiAoe1xyXG4gICAgICAgICAgICBJZDogZS5JZCxcclxuICAgICAgICAgICAgRWR1Y2F0aW9uYWxGb3JtOiBlLkVkdWNhdGlvbmFsRm9ybSxcclxuICAgICAgICAgICAgTGV2ZWxJbnN0YW5jZUlkOiBlLkxldmVsSW5zdGFuY2VJZCxcclxuICAgICAgICAgICAgTmFtZUJnOiBpbnN0YW5jZXNbZS5MZXZlbEluc3RhbmNlSWRdLk5hbWVCZyxcclxuICAgICAgICAgICAgTmFtZUVuOiBpbnN0YW5jZXNbZS5MZXZlbEluc3RhbmNlSWRdLk5hbWVFbixcclxuICAgICAgICAgICAgTmFtZTogZS5OYW1lXHJcbiAgICAgICAgfSkpLnJlZHVjZShwYXJzZS50b0Fzc29jQXJyYXksIHt9KTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEB0eXBlZGVmIHtPYmplY3R9IFBhY2thZ2VWaWV3TW9kZWxcclxuICogQHByb3BlcnR5IHtudW1iZXJ9IElkXHJcbiAqIEBwcm9wZXJ0eSB7bnVtYmVyfSBFZHVjYXRpb25hbEZvcm1cclxuICogQHByb3BlcnR5IHtudW1iZXJ9IExldmVsSW5zdGFuY2VJZFxyXG4gKiBAcHJvcGVydHkge3N0cmluZ30gTmFtZUJnXHJcbiAqIEBwcm9wZXJ0eSB7c3RyaW5nfSBOYW1lRW5cclxuICogQHByb3BlcnR5IHtzdHJpbmd9IE5hbWVcclxuICovXHJcbi8qKlxyXG4gKiBAcGFyYW0ge09iamVjdC48bnVtYmVyLCBJbnN0YW5jZVJlZmVyZW5jZT59IGluc3RhbmNlcyBcclxuICogQHBhcmFtIHtPYmplY3QuPG51bWJlciwgUHJvZHVjdFZpZXdNb2RlbD59IHByb2R1Y3RzIFxyXG4gKiBAcmV0dXJucyB7UHJvbWlzZTxPYmplY3QuPG51bWJlciwgUGFja2FnZVZpZXdNb2RlbD4+fVxyXG4gKi9cclxuYXN5bmMgZnVuY3Rpb24gZ2V0UGFja2FnZXMoaW5zdGFuY2VzLCBwcm9kdWN0cykge1xyXG4gICAgcmV0dXJuIChhd2FpdCBTZXNBcGkuZ2V0UGFja2FnZXNGb3JQcm9kdWN0KE9iamVjdC5rZXlzKHByb2R1Y3RzKSkpLkRhdGFcclxuICAgICAgICAubWFwKHAgPT4gKHtcclxuICAgICAgICAgICAgSWQ6IHAuSWQsXHJcbiAgICAgICAgICAgIEVkdWNhdGlvbmFsRm9ybTogcC5FZHVjYXRpb25hbEZvcm0sXHJcbiAgICAgICAgICAgIExldmVsSW5zdGFuY2VJZDogcHJvZHVjdHNbcC5Qcm9kdWN0LklkXS5MZXZlbEluc3RhbmNlSWQsXHJcbiAgICAgICAgICAgIE5hbWVCZzogaW5zdGFuY2VzW3Byb2R1Y3RzW3AuUHJvZHVjdC5JZF0uTGV2ZWxJbnN0YW5jZUlkXS5OYW1lQmcsXHJcbiAgICAgICAgICAgIE5hbWVFbjogaW5zdGFuY2VzW3Byb2R1Y3RzW3AuUHJvZHVjdC5JZF0uTGV2ZWxJbnN0YW5jZUlkXS5OYW1lRW4sXHJcbiAgICAgICAgICAgIE5hbWU6IHAuTmFtZVxyXG4gICAgICAgIH0pKS5yZWR1Y2UocGFyc2UudG9Bc3NvY0FycmF5LCB7fSk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBAcGFyYW0ge09iamVjdC48bnVtYmVyLCBQYWNrYWdlVmlld01vZGVsPn0gcGFja2FnZXMgXHJcbiAqIEBwYXJhbSB7Kn0gcGF5bWVudCBcclxuICogQHBhcmFtIHtPYmplY3QuPG51bWJlciwgW10+fSBhY2N1bXVsYXRvciBcclxuICovXHJcbmZ1bmN0aW9uIHBhcnNlUGF5bWVudChwYWNrYWdlcywgcGF5bWVudCwgYWNjdW11bGF0b3IpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgICAgbGV0IHBhY2thZ2VJZCA9IHBheW1lbnQuUGF5bWVudFBhY2thZ2VzWzBdLklkO1xyXG4gICAgICAgIC8vIENoZWNrIGlmIGFub3RoZXIgcGFja2FnZSB3aXRoIHRoZSBzYW1lIG5hbWUgZXhpc3RzIChpbiBjYXNlIHRoZSBwYWNrYWdlIHdhcyBkZWxldGVkIGFuZCByZWNyZWF0ZWQgZm9yIHNvbWUgcmVhc29uKVxyXG4gICAgICAgIGlmICghcGFja2FnZXNbcGFja2FnZUlkXSkge1xyXG4gICAgICAgICAgICBsZXQgcGFja2FnZXNXaXRoU2FtZU5hbWUgPSBPYmplY3QudmFsdWVzKHBhY2thZ2VzKS5maWx0ZXIocCA9PiBwLk5hbWUgPT09IHBheW1lbnQuUGF5bWVudFBhY2thZ2VzWzBdLk5hbWUpO1xyXG4gICAgICAgICAgICBpZiAocGFja2FnZXNXaXRoU2FtZU5hbWUubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgICAgcGFja2FnZUlkID0gcGFja2FnZXNXaXRoU2FtZU5hbWVbMF0uSWQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICghcGFja2FnZXNbcGFja2FnZUlkXSkge1xyXG4gICAgICAgICAgICAvLyBIYW5kbGUgbWlzc2luZyBwYXltZW50IHBhY2thZ2VcclxuICAgICAgICAgICAgY29uc3QgbW9kdWxlID0gYWNjdW11bGF0b3JbJ21pc3NpbmcnXTtcclxuICAgICAgICAgICAgcGF5bWVudC5FZHVjYXRpb25hbEZvcm0gPSAwO1xyXG4gICAgICAgICAgICBwYXltZW50LkxldmVsSW5zdGFuY2VJZCA9IDA7XHJcbiAgICAgICAgICAgIHBheW1lbnQuTW9kdWxlTmFtZUJnID0gJ21pc3NpbmcnO1xyXG4gICAgICAgICAgICBwYXltZW50Lk1vZHVsZU5hbWVFbiA9ICdtaXNzaW5nJztcclxuICAgICAgICAgICAgaWYgKG1vZHVsZSA9PT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICBhY2N1bXVsYXRvclsnbWlzc2luZyddID0gW3BheW1lbnRdO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgbW9kdWxlLnB1c2gocGF5bWVudCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCBtb2R1bGVJZCA9IHBhY2thZ2VzW3BhY2thZ2VJZF0uTGV2ZWxJbnN0YW5jZUlkO1xyXG4gICAgICAgIGNvbnN0IG1vZHVsZSA9IGFjY3VtdWxhdG9yW21vZHVsZUlkXTtcclxuICAgICAgICBwYXltZW50LkVkdWNhdGlvbmFsRm9ybSA9IHBhY2thZ2VzW3BhY2thZ2VJZF0uRWR1Y2F0aW9uYWxGb3JtO1xyXG4gICAgICAgIHBheW1lbnQuTGV2ZWxJbnN0YW5jZUlkID0gcGFja2FnZXNbcGFja2FnZUlkXS5MZXZlbEluc3RhbmNlSWQ7XHJcbiAgICAgICAgcGF5bWVudC5Nb2R1bGVOYW1lQmcgPSBwYWNrYWdlc1twYWNrYWdlSWRdLk5hbWVCZztcclxuICAgICAgICBwYXltZW50Lk1vZHVsZU5hbWVFbiA9IHBhY2thZ2VzW3BhY2thZ2VJZF0uTmFtZUVuO1xyXG4gICAgICAgIGlmIChtb2R1bGUgPT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICBhY2N1bXVsYXRvclttb2R1bGVJZF0gPSBuZXcgTWFwKFtbcGF5bWVudC5QYWlkRm9yVXNlck5hbWUsIHBheW1lbnRdXSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgaWYobW9kdWxlLmdldChwYXltZW50LlBhaWRGb3JVc2VyTmFtZSkgPT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgbW9kdWxlLnNldChwYXltZW50LlBhaWRGb3JVc2VyTmFtZSwgcGF5bWVudCk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgIGNvbnNvbGUud2FybignVW5hYmxlIHRvIHByb2Nlc3MgcGF5bWVudCcsIHBheW1lbnQpO1xyXG4gICAgfVxyXG59XHJcblxyXG5jb25zdCBwYXltZW50c0NhY2hlID0gW107XHJcblxyXG4vKipcclxuICogXHJcbiAqIEBwYXJhbSB7UGFja2FnZVZpZXdNb2RlbH0gcCBcclxuICogQHJldHVybnMge1Byb21pc2U8U1VSZXNwb25zZTxTVVBheW1lbnQ+Pn1cclxuICovXHJcbmZ1bmN0aW9uIGNhY2hlZFBheW1lbnRzKHApIHtcclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgbmFtZSA9IHAuTmFtZTtcclxuICAgICAgICBjb25zdCBzdG9yZU5hbWUgPSBzdG9yZXMuUEFZTUVOVFMgKyBnZXRTdWJzaXRlKCkgKyBuYW1lO1xyXG4gICAgICAgIHBheW1lbnRzQ2FjaGUucHVzaChzdG9yZU5hbWUpO1xyXG4gICAgICAgIHJldHVybiB3aXRoQ2FjaGUoU2VzQXBpLmdldFBheW1lbnRzRm9yUGFja2FnZSwgc3RvcmVOYW1lLCAxODAwKShuYW1lKTtcclxuICAgIH07XHJcbn1cclxuXHJcbi8vLyBUT0RPIG1heWJlIGFkZCBidXR0b24gdG8gY2xlYXIgYWxsIGNhY2hlXHJcbmV4cG9ydCBmdW5jdGlvbiBjbGVhclBheW1lbnRzQ2FjaGUoKSB7XHJcbiAgICBwYXltZW50c0NhY2hlLmZvckVhY2goYyA9PiBjbGVhckNhY2hlKGMpKTtcclxuICAgIHBheW1lbnRzQ2FjaGUubGVuZ3RoID0gMDtcclxufVxyXG5cclxuLyoqXHJcbiAqIEBwYXJhbSB7QXJyYXk8U1VQYXltZW50Pn0gcGF5bWVudHMgXHJcbiAqIEBwYXJhbSB7c3RyaW5nfSB5ZWFyIFxyXG4gKiBAcGFyYW0ge3N0cmluZ30gbW9udGggXHJcbiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcGFyc2VBbmREb3dubG9hZFJlcG9ydChwYXltZW50cywgeWVhciwgbW9udGgpIHtcclxuICAgIGV4cG9ydFBheW1lbnRzVG9YbHN4KHBhcnNlLnBheW1lbnRzVG9NYXRyaXgocGF5bWVudHMpLCB5ZWFyLCBtb250aCk7XHJcbn0iLCJpbXBvcnQgZG9tLCB7IEZyYWdtZW50IH0gZnJvbSAnLi4vdXRpbC9qc3gtcmVuZGVyLW1vZC9kb20nO1xyXG5pbXBvcnQgeyBjcmVhdGVEaWFsb2cgfSBmcm9tICcuLi9jb21tb24vTW9kYWwnO1xyXG5pbXBvcnQgeyBEb3dubG9hZFByb2dyZXNzQmFyLCBZZXMsIHJlcGxhY2VDb250ZW50cywgc3dhcCB9IGZyb20gJy4uL3V0aWwvdGVtcGxhdGUnO1xyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIERldGFpbHMoeyBzdXJ2ZXksIHN1bW1hcnksIGdldEFkdmFuY2VkU3VtbWFyeSB9KSB7XHJcbiAgICAvLyBjb25zb2xlLmxvZyhzdW1tYXJ5KTtcclxuICAgIGxldCByYXdTdW1tYXJ5ID0gc3VtbWFyeTtcclxuICAgIGxldCBtb2R1bGVCcmVha2Rvd25EaXYgPSA8ZGl2PlxyXG4gICAgICAgIDxhIGNsYXNzTmFtZT1cIm5hdi1iYWNrLWxpbmtcIiBocmVmPVwiamF2YXNjcmlwdDp2b2lkKDApXCIgb25DbGljaz17YXN5bmMgKCkgPT4gYXdhaXQgcmVwbGFjZVN1bW1hcnkoc3VydmV5KX0+TG9hZCBNb2R1bGUvQ291cnNlIEJyZWFrZG93bjwvYT5cclxuICAgIDwvZGl2PjtcclxuXHJcbiAgICBsZXQgc3VtbWFyeVRhYmxlID0gPHRhYmxlIGNsYXNzTmFtZT1cInN1cnZleS10YWJsZVwiPlxyXG4gICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAge3N1bW1hcnkubWFwKFNlY3Rpb24pfVxyXG4gICAgICAgIDwvdGJvZHk+XHJcbiAgICA8L3RhYmxlPjtcclxuICAgIGxldCBkZXRhaWxzQ29udGFpbmVyID0gKDxkaXY+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAge21vZHVsZUJyZWFrZG93bkRpdn1cclxuICAgICAgICAgICAgey8qIDxkaXY+PGEgY2xhc3NOYW1lPVwibmF2LWJhY2stbGlua1wiIGhyZWY9XCJqYXZhc2NyaXB0OnZvaWQoMClcIiBvbkNsaWNrPXthc3luYyAoKSA9PiBhd2FpdCByZXBsYWNlU3VtbWFyeShzdXJ2ZXkpfT5Mb2FkIE1vZHVsZS9Db3Vyc2UgQnJlYWtkb3duPC9hPjwvZGl2PiAqL31cclxuICAgICAgICAgICAgPGEgaWQ9XCJzZXMtc3VydmV5LXJhd1wiIGNsYXNzTmFtZT1cIm5hdi1iYWNrLWxpbmtcIiBocmVmPVwiamF2YXNjcmlwdDp2b2lkKDApXCIgb25DbGljaz17KCkgPT4gY29uc29sZS5sb2coc3VydmV5LCByYXdTdW1tYXJ5KX0+TG9nIFJhdyBEYXRhPC9hPlxyXG4gICAgICAgICAgICA8cD5TdXJ2ZXkgcGFydGljaXBhbnRzOiB7c3VtbWFyeS5wYXJ0aWNpcGFudHN9PC9wPlxyXG4gICAgICAgICAgICB7c3VtbWFyeVRhYmxlfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+KTtcclxuXHJcbiAgICByZXR1cm4gZGV0YWlsc0NvbnRhaW5lcjtcclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiByZXBsYWNlU3VtbWFyeShzdXJ2ZXkpIHtcclxuICAgICAgICBjb25zdCBsb2FkZXIgPSA8RG93bmxvYWRQcm9ncmVzc0JhciBkb3dubG9hZEZ1bmN0aW9uPXsob25Qcm9ncmVzcykgPT4gZ2V0QWR2YW5jZWRTdW1tYXJ5KHN1cnZleSwgb25Qcm9ncmVzcyl9IHJldHVybkZ1bmN0aW9uPXthZnRlckRvd25sb2FkfT48L0Rvd25sb2FkUHJvZ3Jlc3NCYXI+O1xyXG4gICAgICAgIC8vIGxldCBhZHZhbmNlZFN1bW1hcnkgPSBhd2FpdCBnZXRBZHZhbmNlZFN1bW1hcnkoc3VydmV5KTtcclxuICAgICAgICBtb2R1bGVCcmVha2Rvd25EaXYgPSByZXBsYWNlQ29udGVudHMobW9kdWxlQnJlYWtkb3duRGl2LCBsb2FkZXIpO1xyXG4gICAgICAgIGFzeW5jIGZ1bmN0aW9uIGFmdGVyRG93bmxvYWQoYWR2YW5jZWRTdW1tYXJ5KSB7XHJcbiAgICAgICAgICAgIHJhd1N1bW1hcnkgPSBhZHZhbmNlZFN1bW1hcnk7XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGFkdmFuY2VkU3VtbWFyeSk7XHJcbiAgICAgICAgICAgIHN1bW1hcnlUYWJsZS5yZW1vdmVDaGlsZChzdW1tYXJ5VGFibGUuZmlyc3RFbGVtZW50Q2hpbGQpO1xyXG4gICAgICAgICAgICBzdW1tYXJ5VGFibGUuYXBwZW5kQ2hpbGQoKFxyXG4gICAgICAgICAgICAgICAgPEZyYWdtZW50PlxyXG4gICAgICAgICAgICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2FkdmFuY2VkU3VtbWFyeS5tYXAoU2VjdGlvbil9XHJcbiAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgIDwvRnJhZ21lbnQ+XHJcbiAgICAgICAgICAgICkpO1xyXG4gICAgICAgICAgICBzd2FwKG1vZHVsZUJyZWFrZG93bkRpdiwgKDxGcmFnbWVudD48L0ZyYWdtZW50PikpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuXHJcblxyXG5mdW5jdGlvbiBTZWN0aW9uKHNlY3Rpb24pIHtcclxuICAgIGxldCBtZWFuID0gbnVsbDtcclxuICAgIGxldCBzdW1tYXJ5SW5zdGFuY2UgPSBzZWN0aW9uLmV4Y2xTdW1tYXJ5QnlJbnN0YW5jZSA/IHNlY3Rpb24uZXhjbFN1bW1hcnlCeUluc3RhbmNlIDogc2VjdGlvbi5zdW1tYXJ5QnlJbnN0YW5jZTtcclxuICAgIGlmIChzZWN0aW9uLmV4Y2xNZWFuICYmIHNlY3Rpb24uZXhjbE1lYW4gIT0gc2VjdGlvbi5tZWFuKSB7XHJcbiAgICAgICAgbWVhbiA9IDxzcGFuIGNsYXNzTmFtZT1cImF2ZXJhZ2VcIj5BdmVyYWdlOiB7c2VjdGlvbi5leGNsTWVhbn0gPHNwYW4gY2xhc3NOYW1lPVwiYXZlcmFnZS11bnRyYWNrZWRcIj4oe3NlY3Rpb24ubWVhbn0pPC9zcGFuPjwvc3Bhbj47XHJcbiAgICB9IGVsc2UgaWYgKHNlY3Rpb24ubWVhbikge1xyXG4gICAgICAgIG1lYW4gPSA8c3BhbiBjbGFzc05hbWU9XCJhdmVyYWdlXCI+QXZlcmFnZToge3NlY3Rpb24ubWVhbn08L3NwYW4+O1xyXG4gICAgfVxyXG5cclxuICAgIGxldCBicmVha2Rvd25NZWFucyA9IDxGcmFnbWVudD5cclxuICAgICAgICB7c3VtbWFyeUluc3RhbmNlICE9PSB1bmRlZmluZWRcclxuICAgICAgICAgICAgPyBPYmplY3QuZW50cmllcyhzdW1tYXJ5SW5zdGFuY2UpLnNvcnQoKFthS2V5LCBhVmFsdWVdLCBbYktleSwgYlZhbHVlXSkgPT4gYVZhbHVlLmluc3RhbmNlVHlwZT8ubG9jYWxlQ29tcGFyZShiVmFsdWUuaW5zdGFuY2VUeXBlKSkubWFwKChbaUtleSwgaVZhbHVlXSkgPT5cclxuICAgICAgICAgICAgKDxhYmJyIHRpdGxlPXtgJHtpS2V5fVxcblBhcnRpY2lwYW50czogJHtpVmFsdWUuY291bnR9YH0+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhdmVyYWdlXCIgc3R5bGU9e3sgJ2JhY2tncm91bmQtY29sb3InOiBpVmFsdWUuaW5zdGFuY2VUeXBlPy5zdGFydHNXaXRoKCdNb2R1bGUnKSA/ICdwdXJwbGUnIDogaVZhbHVlLmluc3RhbmNlVHlwZT8uc3RhcnRzV2l0aCgnT3BlbicpID8gJ25hdnknIDogJ2RhcmtyZWQnIH19PntpVmFsdWUubWVhbiB8fCAnTi9BJ308L3NwYW4+XHJcbiAgICAgICAgICAgIDwvYWJicj4pKVxyXG4gICAgICAgICAgICA6ICcnfVxyXG4gICAgPC9GcmFnbWVudD5cclxuXHJcbiAgICByZXR1cm4gKDx0cj48dGQ+XHJcbiAgICAgICAgPGgzPntzZWN0aW9uLm5hbWV9e21lYW59e2JyZWFrZG93bk1lYW5zfTwvaDM+XHJcbiAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm5lc3RlZC10YWJsZVwiPjx0Ym9keT5cclxuICAgICAgICAgICAge3NlY3Rpb24ucXVlc3Rpb25zLm1hcChjcmVhdGVRdWVzdGlvbil9XHJcbiAgICAgICAgPC90Ym9keT48L3RhYmxlPlxyXG4gICAgPC90ZD48L3RyPik7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGNyZWF0ZVF1ZXN0aW9uKHF1ZXN0aW9uKSB7XHJcbiAgICBpZiAocXVlc3Rpb24udHlwZSA9PT0gJ2ZyZWUnKSB7XHJcbiAgICAgICAgcmV0dXJuIEZyZWVRdWVzdGlvbihxdWVzdGlvbik7XHJcbiAgICB9IGVsc2UgaWYgKHF1ZXN0aW9uLnR5cGUgPT09ICdjaG9pY2UnKSB7XHJcbiAgICAgICAgcmV0dXJuIENob2ljZVF1ZXN0aW9uKHF1ZXN0aW9uKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIFF1ZXN0aW9uKHF1ZXN0aW9uKTtcclxuICAgIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIEBwYXJhbSB7aW1wb3J0KCcuL3N0YXRzJykuU3VtbWFyaXplZFF1ZXN0aW9ufSBxdWVzdGlvbiBcclxuICogQHJldHVybnMge0RvY3VtZW50RnJhZ21lbnR9XHJcbiAqL1xyXG5mdW5jdGlvbiBGcmVlUXVlc3Rpb24ocXVlc3Rpb24pIHtcclxuICAgIGxldCBzaG93QWR2YW5jZWRCcmVha2Rvd24gPSBxdWVzdGlvbi5pbnN0YW5jZXMgIT09IHVuZGVmaW5lZDtcclxuICAgIHJldHVybiAoPEZyYWdtZW50PlxyXG4gICAgICAgIDx0ciBjbGFzc05hbWU9XCJxdWVzdGlvblwiPjx0ZD57cXVlc3Rpb24ubmFtZX08L3RkPjwvdHI+XHJcbiAgICAgICAgPHRyPjx0ZD5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb21tZW50c1wiPlxyXG4gICAgICAgICAgICAgICAgPGEgY2xhc3NOYW1lPVwiY29tbWVudHNUb2dnbGVcIiBocmVmPVwiamF2YXNjcmlwdDp2b2lkKDApXCIgb25DbGljaz17dG9nZ2xlQ29tbWVudHN9PlNob3cge3F1ZXN0aW9uLmFuc3dlcnMubGVuZ3RofSBjb21tZW50czwvYT5cclxuICAgICAgICAgICAgICAgIHtzaG93QWR2YW5jZWRCcmVha2Rvd25cclxuICAgICAgICAgICAgICAgICAgICA/IHF1ZXN0aW9uLmluc3RhbmNlcy5tYXAoaSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICg8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzZXMtc3ViLWhlYWRpbmdcIj57aS5uYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2kuYW5zd2Vycy5tYXAoYW5zd2VyID0+ICg8ZGl2IGNsYXNzTmFtZT1cImZyZWVUZXh0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YW5zd2VyLnRleHR9IDxhYmJyIHRpdGxlPXthbnN3ZXIucmVsYXRlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAociA9PiAoeyBuYW1lOiByLm5hbWUsIHF1ZXN0aW9uczogci5xdWVzdGlvbnMuZmlsdGVyKHEgPT4gcS50eXBlID09ICdzY2FsZScgJiYgTnVtYmVyLmlzRmluaXRlKHEuZmVlZGJhY2spKSB9KSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuZmlsdGVyKHIgPT4gci5xdWVzdGlvbnMubGVuZ3RoID4gMClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAubWFwKHIgPT4gYCR7ci5uYW1lfVxcbiR7ci5xdWVzdGlvbnNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLm1hcChxID0+IGAgLSAke3EubmFtZS50cmltKCl9IFske3EuZmVlZGJhY2t9XWApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5qb2luKCdcXG4nKX1gKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5qb2luKCdcXG5cXG4nKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGkgb25DbGljaz17KCkgPT4gc2hvd0RldGFpbHMoYW5zd2VyLmluZGV4LCBhbnN3ZXIucmVsYXRlZCl9IGNsYXNzPVwiZ2x5cGhpY29uIGdseXBoaWNvbi1pbmZvLXNpZ25cIj48L2k+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2FiYnI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PikpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PikpXHJcbiAgICAgICAgICAgICAgICAgICAgOiBxdWVzdGlvbi5hbnN3ZXJzLm1hcChhbnN3ZXIgPT4gKDxkaXYgY2xhc3NOYW1lPVwiZnJlZVRleHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Fuc3dlci50ZXh0fSA8YWJiciB0aXRsZT17YW5zd2VyLnJlbGF0ZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAociA9PiAoeyBuYW1lOiByLm5hbWUsIHF1ZXN0aW9uczogci5xdWVzdGlvbnMuZmlsdGVyKHEgPT4gcS50eXBlID09ICdzY2FsZScgJiYgTnVtYmVyLmlzRmluaXRlKHEuZmVlZGJhY2spKSB9KSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5maWx0ZXIociA9PiByLnF1ZXN0aW9ucy5sZW5ndGggPiAwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLm1hcChyID0+IGAke3IubmFtZX1cXG4ke3IucXVlc3Rpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLm1hcChxID0+IGAgLSAke3EubmFtZS50cmltKCl9IFske3EuZmVlZGJhY2t9XWApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmpvaW4oJ1xcbicpfWApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuam9pbignXFxuXFxuJyl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGkgb25DbGljaz17KCkgPT4gc2hvd0RldGFpbHMoYW5zd2VyLmluZGV4LCBhbnN3ZXIucmVsYXRlZCl9IGNsYXNzPVwiZ2x5cGhpY29uIGdseXBoaWNvbi1pbmZvLXNpZ25cIj48L2k+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYWJicj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj4pKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC90ZD48L3RyPlxyXG4gICAgPC9GcmFnbWVudD4pO1xyXG5cclxuICAgIGZ1bmN0aW9uIHRvZ2dsZUNvbW1lbnRzKGUpIHtcclxuICAgICAgICBpZiAoZS50YXJnZXQucGFyZW50Tm9kZS5jbGFzc0xpc3QuY29udGFpbnMoJ2NvbW1lbnRzJykpIHtcclxuICAgICAgICAgICAgZS50YXJnZXQucGFyZW50Tm9kZS5jbGFzc0xpc3QucmVtb3ZlKCdjb21tZW50cycpO1xyXG4gICAgICAgICAgICBlLnRhcmdldC50ZXh0Q29udGVudCA9ICdIaWRlJyArIGUudGFyZ2V0LnRleHRDb250ZW50LnN1YnN0cig0KTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBlLnRhcmdldC5wYXJlbnROb2RlLmNsYXNzTGlzdC5hZGQoJ2NvbW1lbnRzJyk7XHJcbiAgICAgICAgICAgIGUudGFyZ2V0LnRleHRDb250ZW50ID0gJ1Nob3cnICsgZS50YXJnZXQudGV4dENvbnRlbnQuc3Vic3RyKDQpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuZnVuY3Rpb24gQ2hvaWNlUXVlc3Rpb24ocXVlc3Rpb24pIHtcclxuICAgIGxldCBzaG93QWR2YW5jZWRCcmVha2Rvd24gPSBxdWVzdGlvbi5pbnN0YW5jZXMgIT09IHVuZGVmaW5lZDtcclxuICAgIHJldHVybiAoPEZyYWdtZW50PlxyXG4gICAgICAgIDx0ciBjbGFzc05hbWU9XCJxdWVzdGlvblwiPlxyXG4gICAgICAgICAgICA8dGQ+XHJcbiAgICAgICAgICAgICAgICB7cXVlc3Rpb24ubmFtZX1cclxuICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICA8L3RyPlxyXG4gICAgICAgIHtxdWVzdGlvbi5hbnN3ZXJzLm1hcChhbnN3ZXIgPT4gKDx0cj48dGQ+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJhclwiIHN0eWxlPXt7IGJhY2tncm91bmQ6IGBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICNmZmEwMDAgJHthbnN3ZXIuZnJhY3Rpb259JSwgI2VlZSAwKWAgfX0+e2Fuc3dlci5mcmFjdGlvbn0lICh7YW5zd2VyLmNvdW50fSk8L3NwYW4+XHJcbiAgICAgICAgICAgIHtzaG93QWR2YW5jZWRCcmVha2Rvd25cclxuICAgICAgICAgICAgICAgID8gcXVlc3Rpb24uaW5zdGFuY2VzLnNvcnQoKGEsIGIpID0+IGEuaW5zdGFuY2VUeXBlPy5sb2NhbGVDb21wYXJlKGIuaW5zdGFuY2VUeXBlKSkubWFwKGkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBpbnN0YW5jZUFuc3dlciA9IGkuYW5zd2Vycy5maW5kKGEgPT4gYS5uYW1lID09PSBhbnN3ZXIubmFtZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgPz8geyBuYW1lOiBhbnN3ZXIubmFtZSwgdmFsdWU6IGFuc3dlci52YWx1ZSwgY291bnQ6IDAsIGZyYWN0aW9uOiAwIH07XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDxGcmFnbWVudD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGFiYnIgdGl0bGU9e2Ake2kubmFtZX1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJhclwiIHN0eWxlPXt7IGJhY2tncm91bmQ6IGBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICR7aS5pbnN0YW5jZVR5cGU/LnN0YXJ0c1dpdGgoJ01vZHVsZScpID8gJ3JnYmEoMTI4LDAsMTI4LDAuNSknIDogaS5pbnN0YW5jZVR5cGU/LnN0YXJ0c1dpdGgoJ09wZW4nKSA/ICdyZ2JhKDAsMCwxMjgsMC4zNSknIDogJ3JnYmEoMTI4LDAsMCwwLjM1KSd9ICR7aW5zdGFuY2VBbnN3ZXIuZnJhY3Rpb259JSwgI2VlZSAwKWAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2luc3RhbmNlQW5zd2VyLmZyYWN0aW9ufSUgKHtpbnN0YW5jZUFuc3dlci5jb3VudH0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYWJicj5cclxuICAgICAgICAgICAgICAgICAgICA8L0ZyYWdtZW50PlxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIDogJyd9XHJcbiAgICAgICAgICAgIHthbnN3ZXIubmFtZX1cclxuICAgICAgICA8L3RkPjwvdHI+KSl9XHJcbiAgICA8L0ZyYWdtZW50Pik7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIFF1ZXN0aW9uKHF1ZXN0aW9uKSB7XHJcbiAgICBsZXQgc2hvd0FkdmFuY2VkQnJlYWtkb3duID0gcXVlc3Rpb24uc3VtbWFyeUJ5SW5zdGFuY2UgIT09IHVuZGVmaW5lZDtcclxuICAgIHJldHVybiAoPEZyYWdtZW50PlxyXG4gICAgICAgIDx0ciBjbGFzc05hbWU9XCJxdWVzdGlvblwiPlxyXG4gICAgICAgICAgICA8dGQ+XHJcbiAgICAgICAgICAgICAgICB7cXVlc3Rpb24ubmFtZX1cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17cXVlc3Rpb24uc3VtbWFyaXplID8gJ2F2ZXJhZ2UnIDogJ2F2ZXJhZ2UtdW50cmFja2VkJ30+IEF2ZXJhZ2U6IHtxdWVzdGlvbi5tZWFufTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIHtzaG93QWR2YW5jZWRCcmVha2Rvd25cclxuICAgICAgICAgICAgICAgICAgICA/IE9iamVjdC5lbnRyaWVzKHF1ZXN0aW9uLnN1bW1hcnlCeUluc3RhbmNlKS5zb3J0KChbYUtleSwgYVZhbHVlXSwgW2JLZXksIGJWYWx1ZV0pID0+IGFWYWx1ZS5pbnN0YW5jZVR5cGU/LmxvY2FsZUNvbXBhcmUoYlZhbHVlLmluc3RhbmNlVHlwZSkpLm1hcCgoW2lLZXksIGlWYWx1ZV0pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgKDxhYmJyIHRpdGxlPXtgJHtpS2V5fVxcblBhcnRpY2lwYW50czogJHtpVmFsdWUuY291bnR9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImF2ZXJhZ2VcIiBzdHlsZT17eyAnYmFja2dyb3VuZC1jb2xvcic6IGlWYWx1ZS5pbnN0YW5jZVR5cGU/LnN0YXJ0c1dpdGgoJ01vZHVsZScpID8gJ3B1cnBsZScgOiBpVmFsdWUuaW5zdGFuY2VUeXBlPy5zdGFydHNXaXRoKCdPcGVuJykgPyAnbmF2eScgOiAnZGFya3JlZCcgfX0+e2lWYWx1ZS5tZWFuIHx8ICdOL0EnfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2FiYnI+KSlcclxuICAgICAgICAgICAgICAgICAgICA6ICcnfVxyXG4gICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgIDwvdHI+XHJcbiAgICAgICAge3F1ZXN0aW9uLmFuc3dlcnMubWFwKGFuc3dlciA9PiAoPHRyPjx0ZD5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmFyXCIgc3R5bGU9e3sgYmFja2dyb3VuZDogYGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgI2ZmYTAwMCAke2Fuc3dlci5mcmFjdGlvbn0lLCAjZWVlIDApYCB9fT57YW5zd2VyLmZyYWN0aW9ufSUgKHthbnN3ZXIuY291bnR9KTwvc3Bhbj5cclxuICAgICAgICAgICAge3Nob3dBZHZhbmNlZEJyZWFrZG93blxyXG4gICAgICAgICAgICAgICAgPyBxdWVzdGlvbi5pbnN0YW5jZXMubWFwKGkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBpbnN0YW5jZUFuc3dlciA9IGkuYW5zd2Vycy5maW5kKGEgPT4gYS5uYW1lID09PSBhbnN3ZXIubmFtZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgPz8geyBuYW1lOiBhbnN3ZXIubmFtZSwgdmFsdWU6IGFuc3dlci52YWx1ZSwgY291bnQ6IDAsIGZyYWN0aW9uOiAwIH07XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDxGcmFnbWVudD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGFiYnIgdGl0bGU9e2Ake2kubmFtZX1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJhclwiIHN0eWxlPXt7IGJhY2tncm91bmQ6IGBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICR7aS5pbnN0YW5jZVR5cGU/LnN0YXJ0c1dpdGgoJ01vZHVsZScpID8gJ3JnYmEoMTI4LDAsMTI4LDAuNSknIDogaS5pbnN0YW5jZVR5cGU/LnN0YXJ0c1dpdGgoJ09wZW4nKSA/ICdyZ2JhKDAsMCwxMjgsMC4zNSknIDogJ3JnYmEoMTI4LDAsMCwwLjM1KSd9ICR7aW5zdGFuY2VBbnN3ZXIuZnJhY3Rpb259JSwgI2VlZSAwKWAgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2luc3RhbmNlQW5zd2VyLmZyYWN0aW9ufSUgKHtpbnN0YW5jZUFuc3dlci5jb3VudH0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYWJicj5cclxuICAgICAgICAgICAgICAgICAgICA8L0ZyYWdtZW50PlxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIDogJyd9XHJcbiAgICAgICAgICAgIHthbnN3ZXIubmFtZX1cclxuICAgICAgICA8L3RkPjwvdHI+KSl9XHJcbiAgICA8L0ZyYWdtZW50Pik7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHNob3dEZXRhaWxzKGluZGV4LCByZWxhdGVkKSB7XHJcbiAgICBjcmVhdGVEaWFsb2coJ9CU0LXRgtCw0LnQu9C90LAg0L7QsdGA0LDRgtC90LAg0LLRgNGK0LfQutCwINC+0YIg0L/QvtGC0YDQtdCx0LjRgtC10LsgJyArIGluZGV4LCAoPGRpdiBjbGFzc05hbWU9XCJzZXMtc2Nyb2xsXCI+XHJcbiAgICAgICAge3JlbGF0ZWQubWFwKHIgPT4gKDxkaXY+XHJcbiAgICAgICAgICAgIDxoMz57ci5uYW1lfTwvaDM+XHJcbiAgICAgICAgICAgIHtyLnF1ZXN0aW9ucy5tYXAocSA9PiAoPGRpdj5cclxuICAgICAgICAgICAgICAgIDxwIHN0eWxlPXt7IGZvbnRXZWlnaHQ6ICdib2xkJyB9fT57cS5uYW1lfTwvcD5cclxuICAgICAgICAgICAgICAgIDxwIHN0eWxlPXt7ICdiYWNrZ3JvdW5kLWNvbG9yJzogJ3JnYigyMzgsIDIzOCwgMjM4KScgfX0+e3EuZmVlZGJhY2sgPT0gdW5kZWZpbmVkID8gKDxpIGNsYXNzPVwiZ2x5cGhpY29uIGdseXBoaWNvbi1taW51c1wiPjwvaT4pIDogcS5mZWVkYmFja308L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PikpfVxyXG4gICAgICAgIDwvZGl2PikpfVxyXG4gICAgPC9kaXY+KSwgW1s8WWVzIC8+LCAn0J7QsdGA0LDRgtC90L4nLCAnb2snXV0sIHRydWUsIG51bGwpO1xyXG59IiwiaW1wb3J0IGRvbSwgeyBGcmFnbWVudCB9IGZyb20gJy4uL3V0aWwvanN4LXJlbmRlci1tb2QvZG9tJztcclxuaW1wb3J0IHsgRG93bmxvYWRQcm9ncmVzc0JhciwgTG9hZGluZywgcmVwbGFjZUNvbnRlbnRzIH0gZnJvbSAnLi4vdXRpbC90ZW1wbGF0ZSc7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tICcuLi91dGlsL3JvdXRlcic7XHJcbmltcG9ydCBwYXJzZSBmcm9tICcuLi91dGlsL3BhcnNlJztcclxuaW1wb3J0IHsgZ2V0RmluYWxpemVkU3VydmV5c0V4cG9ydCB9IGZyb20gJy4vZGF0YS5qcyc7XHJcbmltcG9ydCB7IG9wZW5GaWxlLCB0b1hsc3hGaWxlIH0gZnJvbSAnLi4vdXRpbC91dGlsJztcclxuXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTdW1tYXJ5KHsgcGFnZSwgcGFnZXMsIHN1cnZleXMsIHBhZ2VTZWxlY3QsIGdldERldGFpbHMsIGdldFN1bW1hcnksIGdldEFkdmFuY2VkU3VtbWFyeSwgZ2V0RmluYWxpemVkU3VydmV5c0V4cG9ydCwgc2VhcmNoSW5wdXQsIHNlYXJjaFF1ZXJ5IH0pIHtcclxuICAgIHNlYXJjaFF1ZXJ5ID0gc2VhcmNoUXVlcnkgPyBgJnNlYXJjaD0ke2VuY29kZVVSSUNvbXBvbmVudChzZWFyY2hRdWVyeSl9YCA6ICcnO1xyXG5cclxuICAgIC8vIGxldCBleHBvcnRBbGxDaGVja2JveCA9ICg8aW5wdXQgaWQ9XCJzZXMtZXhwb3J0LWFsbFwiIHR5cGU9XCJjaGVja2JveFwiIG9uQ2hhbmdlPXt0b2dnbGVFeHBvcnRBbGx9IC8+KTtcclxuICAgIGxldCBkYXRlRnJvbUlucHV0ID0gKDxpbnB1dCBpZD1cInNlcy1kYXRlLWZyb21cIiBjbGFzcz1cInNlcy1kYXRlLWlucHV0IGRhdGUtZnJvbVwiIHBsYWNlaG9sZGVyPVwiWVlZWS1NTS1ERFwiIHBhdHRlcm49XCJcXGR7NH0tXFxkezJ9LVxcZHsyfVwiIC8+KTtcclxuICAgIGxldCBkYXRlVG9JbnB1dCA9ICg8aW5wdXQgaWQ9XCJzZXMtZGF0ZS10b1wiIGNsYXNzPVwic2VzLWRhdGUtaW5wdXQgZGF0ZS10b1wiIHBsYWNlaG9sZGVyPVwiWVlZWS1NTS1ERFwiIHBhdHRlcm49XCJcXGR7NH0tXFxkezJ9LVxcZHsyfVwiIC8+KTtcclxuICAgIGxldCBleHBvcnRzRmluYWxHcmFkZXNEcm9wZG93biA9ICg8ZGl2IGNsYXNzPVwic2VzLWV4cG9ydC1maW5hbC1ncmFkZXMtZHJvcGRvd24gaGlkZGVuXCI+XHJcbiAgICAgICAgPGxhYmVsIGZvcj1cInNlcy1kYXRlLWZyb21cIj5Gcm9tPC9sYWJlbD5cclxuICAgICAgICB7ZGF0ZUZyb21JbnB1dH1cclxuICAgICAgICA8bGFiZWwgZm9yPVwic2VzLWRhdGUtdG9cIj5UbzwvbGFiZWw+XHJcbiAgICAgICAge2RhdGVUb0lucHV0fVxyXG4gICAgICAgIHsvKiB7ZXhwb3J0QWxsQ2hlY2tib3h9ICovfVxyXG4gICAgICAgIHsvKiA8bGFiZWwgZm9yPVwic2VzLWV4cG9ydC1hbGxcIj5FeHBvcnQgQWxsPC9sYWJlbD4gKi99XHJcbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtleHBvcnRGaW5hbFN1cnZleUdyYWRlc30+RXhwb3J0PC9idXR0b24+XHJcbiAgICA8L2Rpdj4pO1xyXG4gICAgbGV0IGV4cG9ydENvbnRyb2xzID0gKDxkaXYgY2xhc3M9XCJzZXMtZXhwb3J0LWNvbnRyb2xzXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInNlcy1leHBvcnRzLWJ0bi1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJzZXMtZXhwb3J0LWZpbmFsLWdyYWRlcy1idG5cIiBvbkNsaWNrPXt0b2dnbGVFeHBvcnRGaW5hbEdyYWRlc0Ryb3Bkb3dufT5FeHBvcnQgRmluYWwgU3VydmV5IEdyYWRlczwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIHtleHBvcnRzRmluYWxHcmFkZXNEcm9wZG93bn1cclxuICAgIDwvZGl2Pik7XHJcblxyXG4gICAgcmV0dXJuICg8RnJhZ21lbnQ+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInNlcy1jb250cm9sc1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwic2VzLXBhZ2VyLWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgICAgICAge3BhZ2UgPiAxICYmIDxMaW5rIHRvPXtwYWdlU2VsZWN0fSBjbGFzc05hbWU9XCJzZXMtcGFnZXItYnV0dG9uXCIgaHJlZj17YC9zZXMvc3VydmV5cz9wYWdlPSR7cGFnZSAtIDF9JHtzZWFyY2hRdWVyeX1gfT4mbHQ7IFByZXY8L0xpbms+fVxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2VzLXBhZ2VyXCI+e3BhZ2V9IG9mIHtwYWdlc308L3NwYW4+XHJcbiAgICAgICAgICAgICAgICB7cGFnZSA8IHBhZ2VzICYmIDxMaW5rIHRvPXtwYWdlU2VsZWN0fSBjbGFzc05hbWU9XCJzZXMtcGFnZXItYnV0dG9uXCIgaHJlZj17YC9zZXMvc3VydmV5cz9wYWdlPSR7cGFnZSArIDF9JHtzZWFyY2hRdWVyeX1gfT5OZXh0ICZndDs8L0xpbms+fVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAge2V4cG9ydENvbnRyb2xzfVxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8dGFibGUgY2xhc3M9XCJkYXRhLXRhYmxlXCI+XHJcbiAgICAgICAgICAgIDx0aGVhZD48dHI+XHJcbiAgICAgICAgICAgICAgICA8dGg+e3NlYXJjaElucHV0fTwvdGg+XHJcbiAgICAgICAgICAgICAgICA8dGg+QWdncmVnYXRlPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aD5BY3RpdmUgRnJvbTwvdGg+XHJcbiAgICAgICAgICAgICAgICA8dGg+RXhwaXJlczwvdGg+XHJcbiAgICAgICAgICAgIDwvdHI+PC90aGVhZD5cclxuICAgICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAgICAge3N1cnZleXMubWFwKGUgPT4gUm93KGUsIGdldERldGFpbHMsIGdldFN1bW1hcnksIGdldEFkdmFuY2VkU3VtbWFyeSkpfVxyXG4gICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgIDwvdGFibGU+XHJcblxyXG4gICAgICAgIHtwYWdlID4gMSAmJiA8TGluayB0bz17cGFnZVNlbGVjdH0gY2xhc3NOYW1lPVwic2VzLXBhZ2VyLWJ1dHRvblwiIGhyZWY9e2Avc2VzL3N1cnZleXM/cGFnZT0ke3BhZ2UgLSAxfSR7c2VhcmNoUXVlcnl9YH0+Jmx0OyBQcmV2PC9MaW5rPn1cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzZXMtcGFnZXJcIj57cGFnZX0gb2Yge3BhZ2VzfTwvc3Bhbj5cclxuICAgICAgICB7cGFnZSA8IHBhZ2VzICYmIDxMaW5rIHRvPXtwYWdlU2VsZWN0fSBjbGFzc05hbWU9XCJzZXMtcGFnZXItYnV0dG9uXCIgaHJlZj17YC9zZXMvc3VydmV5cz9wYWdlPSR7cGFnZSArIDF9JHtzZWFyY2hRdWVyeX1gfT5OZXh0ICZndDs8L0xpbms+fVxyXG4gICAgPC9GcmFnbWVudD4pO1xyXG5cclxuICAgIC8vIGZ1bmN0aW9uIHRvZ2dsZUV4cG9ydEFsbCgpIHtcclxuICAgIC8vICAgICBpZiAoZXhwb3J0QWxsQ2hlY2tib3guY2hlY2tlZCkge1xyXG4gICAgLy8gICAgICAgICBkYXRlRnJvbUlucHV0LmRpc2FibGVkID0gdHJ1ZTtcclxuICAgIC8vICAgICAgICAgZGF0ZVRvSW5wdXQuZGlzYWJsZWQgPSB0cnVlO1xyXG4gICAgLy8gICAgIH0gZWxzZSB7XHJcbiAgICAvLyAgICAgICAgIGRhdGVGcm9tSW5wdXQuZGlzYWJsZWQgPSBmYWxzZTtcclxuICAgIC8vICAgICAgICAgZGF0ZVRvSW5wdXQuZGlzYWJsZWQgPSBmYWxzZTtcclxuICAgIC8vICAgICB9XHJcbiAgICAvLyB9XHJcblxyXG4gICAgZnVuY3Rpb24gdG9nZ2xlRXhwb3J0RmluYWxHcmFkZXNEcm9wZG93bigpIHtcclxuICAgICAgICBleHBvcnRzRmluYWxHcmFkZXNEcm9wZG93bi5jbGFzc0xpc3QudG9nZ2xlKCdoaWRkZW4nKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBleHBvcnRGaW5hbFN1cnZleUdyYWRlcygpIHtcclxuICAgICAgICBjb25zb2xlLmxvZygndHJpZ2dlciBleHBvcnQnKTtcclxuICAgICAgICBsZXQgZGF0ZUZyb21WYWx1ZSA9IGRhdGVGcm9tSW5wdXQudmFsdWU7XHJcbiAgICAgICAgbGV0IGRhdGVUb1ZhbHVlID0gZGF0ZVRvSW5wdXQudmFsdWU7XHJcblxyXG4gICAgICAgIGxldCBiYXNlU3RhcnREYXRlID0gYCR7ZGF0ZUZyb21WYWx1ZX1UMDAtMDAtMDBgO1xyXG4gICAgICAgIGxldCBiYXNlRW5kRGF0ZSA9IGAke2RhdGVUb1ZhbHVlfVQwMC0wMC0wMGA7XHJcblxyXG4gICAgICAgIGxldCBkYXRlRnJvbSA9IERhdGUucGFyc2UoYCR7ZGF0ZUZyb21WYWx1ZX1UMDA6MDA6MDBgKTtcclxuICAgICAgICBsZXQgZGF0ZUZyb21EYXRlID0gbmV3IERhdGUoZGF0ZUZyb20pO1xyXG4gICAgICAgIGxldCBkYXRlVG8gPSBEYXRlLnBhcnNlKGAke2RhdGVUb1ZhbHVlfVQwMDowMDowMGApO1xyXG4gICAgICAgIGxldCBkYXRlVG9EYXRlID0gbmV3IERhdGUoZGF0ZVRvKTtcclxuICAgICAgICBsZXQgZGlmZiA9IE1hdGguYWJzKGRhdGVUbyAtIGRhdGVGcm9tKTtcclxuICAgICAgICBsZXQgZGlmZmVyZW5jZUluRGF5cyA9IE1hdGgucm91bmQoZGlmZiAvICgxMDAwICogMzYwMCAqIDI0KSk7XHJcbiAgICAgICAgbGV0IGxvb3BzID0gZGlmZmVyZW5jZUluRGF5cyAvIDE4MDtcclxuICAgICAgICBsZXQgdG90YWxMb29wcyA9IE1hdGguY2VpbChsb29wcyk7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCB0b3RhbExvb3BzOyBpbmRleCsrKSB7XHJcbiAgICAgICAgICAgIGxldCBzdGFydERhdGUgPSBuZXcgRGF0ZShkYXRlRnJvbSk7XHJcbiAgICAgICAgICAgIGxldCBlbmREYXRlID0gbmV3IERhdGUoZGF0ZUZyb20pO1xyXG4gICAgICAgICAgICBzdGFydERhdGUuc2V0RGF0ZShkYXRlRnJvbURhdGUuZ2V0RGF0ZSgpICsgaW5kZXggKiAxODApO1xyXG4gICAgICAgICAgICAvLyBlbmREYXRlLnNldERhdGUoZGF0ZUZyb21EYXRlLmdldERhdGUoKSArICgoaW5kZXggKyAxKSAqIDE4MCkpO1xyXG5cclxuICAgICAgICAgICAgaWYoaW5kZXggPT09IHRvdGFsTG9vcHMgLSAxKSB7XHJcbiAgICAgICAgICAgICAgICBlbmREYXRlID0gbmV3IERhdGUoZGF0ZVRvKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGVuZERhdGUuc2V0RGF0ZShkYXRlRnJvbURhdGUuZ2V0RGF0ZSgpICsgKChpbmRleCArIDEpICogMTgwKSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGxldCBiYXNlU3RhcnREYXRlU3RyaW5nID0gYCR7c3RhcnREYXRlLmdldEZ1bGxZZWFyKCl9LSR7KHN0YXJ0RGF0ZS5nZXRNb250aCgpICsgMSkudG9TdHJpbmcoKS5wYWRTdGFydCgyLCAnMCcpfS0ke3N0YXJ0RGF0ZS5nZXREYXRlKCkudG9TdHJpbmcoKS5wYWRTdGFydCgyLCAnMCcpfWA7XHJcbiAgICAgICAgICAgIGxldCBiYXNlRW5kRGF0ZVN0cmluZyA9IGAke2VuZERhdGUuZ2V0RnVsbFllYXIoKX0tJHsoZW5kRGF0ZS5nZXRNb250aCgpICsgMSkudG9TdHJpbmcoKS5wYWRTdGFydCgyLCAnMCcpfS0ke2VuZERhdGUuZ2V0RGF0ZSgpLnRvU3RyaW5nKCkucGFkU3RhcnQoMiwgJzAnKX1gO1xyXG4gICAgICAgICAgICBsZXQgc3RhcnREYXRlU3RyaW5nID0gYCR7YmFzZVN0YXJ0RGF0ZVN0cmluZ31UMDAtMDAtMDBgO1xyXG4gICAgICAgICAgICBsZXQgZW5kRGF0ZVN0cmluZyA9IGAke2Jhc2VFbmREYXRlU3RyaW5nfVQwMC0wMC0wMGA7XHJcblxyXG4gICAgICAgICAgICBsZXQgYWZ0ZXJEb3dubG9hZEZ1bmMgPSB1bmRlZmluZWQ7XHJcbiAgICAgICAgICAgIGxldCBleHBvcnRDb21wbGV0ZVByb21pc2UgPSBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgICAgICAgICBhZnRlckRvd25sb2FkRnVuYyA9IGFzeW5jIGZ1bmN0aW9uIChyZXN1bHRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGV4Y2VsRmlsZSA9IHRvWGxzeEZpbGUocmVzdWx0cywgYFN1cnZleXNGaW5hbF8ke2Jhc2VTdGFydERhdGVTdHJpbmd9LSR7YmFzZUVuZERhdGVTdHJpbmd9YCwgJ1N1cnZleXMnKVxyXG4gICAgICAgICAgICAgICAgICAgIG9wZW5GaWxlKGV4Y2VsRmlsZSwgZXhjZWxGaWxlLm5hbWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIGxvYWRlci5yZW1vdmUoKTtcclxuICAgICAgICAgICAgICAgICAgICBhd2FpdCBuZXcgUHJvbWlzZShyID0+IHNldFRpbWVvdXQociwgMjAwMCkpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSlcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IGxvYWRlciA9IDx0ZCBjb2xzcGFuPVwiNFwiPkxvYWRpbmcgc3VtbWFyeSAmaGVsbGlwOyA8TG9hZGluZyBjb2xvcj1cImJsYWNrXCIgLz48RG93bmxvYWRQcm9ncmVzc0JhciBkb3dubG9hZEZ1bmN0aW9uPXsob25Qcm9ncmVzcykgPT4gZ2V0RmluYWxpemVkU3VydmV5c0V4cG9ydChzdGFydERhdGVTdHJpbmcsIGVuZERhdGVTdHJpbmcsIG9uUHJvZ3Jlc3MpfSByZXR1cm5GdW5jdGlvbj17YWZ0ZXJEb3dubG9hZEZ1bmN9PjwvRG93bmxvYWRQcm9ncmVzc0Jhcj48L3RkPjtcclxuICAgICAgICAgICAgZXhwb3J0Q29udHJvbHMuYXBwZW5kQ2hpbGQobG9hZGVyKTtcclxuXHJcbiAgICAgICAgICAgIGF3YWl0IGV4cG9ydENvbXBsZXRlUHJvbWlzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIFJvdyhlbnRyeSwgZ2V0RGV0YWlscywgZ2V0U3VtbWFyeSwgZ2V0QWR2YW5jZWRTdW1tYXJ5KSB7XHJcbiAgICBjb25zdCBmcm9tID0gcGFyc2UuZm9ybWF0RGF0ZShuZXcgRGF0ZShlbnRyeS5BY3RpdmVGcm9tKSk7XHJcbiAgICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpO1xyXG4gICAgY29uc3QgYWN0aXZlVG9EYXRlID0gbmV3IERhdGUoZW50cnkuQWN0aXZlVG8pO1xyXG4gICAgY29uc3QgZGlmZiA9IHBhcnNlLmRhdGVEaWZmKGFjdGl2ZVRvRGF0ZSwgbm93KTtcclxuICAgIGNvbnN0IHRvID0gcGFyc2UuZGF0ZURpZmZUb0RheXMoZGlmZik7XHJcbiAgICBjb25zdCBoYXNBY3RpdmVUb1Bhc3NlZCA9IGFjdGl2ZVRvRGF0ZSA8IG5vdztcclxuICAgIGNvbnN0IHJlY2VudGx5UGFzc2VkID0gZGlmZiA8PSA3ICYmIGRpZmYgPj0gMCAmJiBoYXNBY3RpdmVUb1Bhc3NlZDtcclxuXHJcbiAgICBsZXQgc3VtbWFyaXplZCA9IGZhbHNlO1xyXG4gICAgbGV0IHN1bW1hcnlSb3c7XHJcbiAgICBjb25zdCBzdW1tYXJ5QnRuID0gPGEgY2xhc3NOYW1lPVwic3VtbWFyeS1saW5rXCIgaHJlZj1cImphdmFzY3JpcHQ6dm9pZCgwKVwiIG9uQ2xpY2s9e3RvZ2dsZVN1bW1hcnl9PlZpZXcgU3VtbWFyeTwvYT47XHJcblxyXG4gICAgY29uc3QgZWxlbWVudCA9ICg8dHIgZGF0YS1zdXJ2ZXlpZD17ZW50cnkuSWR9IHRpdGxlPXtyZWNlbnRseVBhc3NlZCA/ICdSZWNlbnRseSBmaW5pc2hlZCcgOiAnJ30gY2xhc3NOYW1lPXtyZWNlbnRseVBhc3NlZCA/ICdoaWdobGlnaHQnIDogJyd9PlxyXG4gICAgICAgIDx0ZD48TGluayB0bz17Z2V0RGV0YWlsc30gY2xhc3NOYW1lPVwic3VydmV5LWxpbmtcIiBocmVmPXtgP2lkPSR7ZW50cnkuSWR9YH0+e2VudHJ5Lk5hbWV9PC9MaW5rPjwvdGQ+XHJcbiAgICAgICAgPHRkPntzdW1tYXJ5QnRufTwvdGQ+XHJcbiAgICAgICAgPHRkPntmcm9tfTwvdGQ+XHJcbiAgICAgICAgPHRkPnt0b308L3RkPlxyXG4gICAgPC90cj4pO1xyXG5cclxuXHJcbiAgICByZXR1cm4gZWxlbWVudDtcclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiB0b2dnbGVTdW1tYXJ5KCkge1xyXG4gICAgICAgIGlmIChzdW1tYXJpemVkKSB7XHJcbiAgICAgICAgICAgIHN1bW1hcml6ZWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgc3VtbWFyeUJ0bi50ZXh0Q29udGVudCA9ICdWaWV3IFN1bW1hcnknO1xyXG4gICAgICAgICAgICBzdW1tYXJ5Um93LnJlbW92ZSgpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHN1bW1hcml6ZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICBzdW1tYXJ5QnRuLnRleHRDb250ZW50ID0gJ0hpZGUgU3VtbWFyeSc7XHJcbiAgICAgICAgICAgIHN1bW1hcnlSb3cgPSBzdW1tYXJ5Um93IHx8IChhd2FpdCBjcmVhdGVTdW1tYXJ5KCkpO1xyXG4gICAgICAgICAgICBjb25zdCB0YWJsZSA9IGVsZW1lbnQucGFyZW50Tm9kZTtcclxuICAgICAgICAgICAgdGFibGUuaW5zZXJ0QmVmb3JlKHN1bW1hcnlSb3csIGVsZW1lbnQubmV4dFNpYmxpbmcpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBjcmVhdGVTdW1tYXJ5KCkge1xyXG4gICAgICAgIC8vIGNvbnN0IGxvYWRlciA9IDx0ZCBjb2xzcGFuPVwiNFwiPkxvYWRpbmcgc3VtbWFyeSAmaGVsbGlwOyA8TG9hZGluZyBjb2xvcj1cImJsYWNrXCIgLz48L3RkPjtcclxuICAgICAgICBjb25zdCBzdW1tYXJ5Um93ID0gKDx0cj48L3RyPik7XHJcbiAgICAgICAgcmVwbGFjZVN1bW1hcnlEYXRhKHN1bW1hcnlSb3cpO1xyXG4gICAgICAgIHJldHVybiBzdW1tYXJ5Um93O1xyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHJlcGxhY2VTdW1tYXJ5RGF0YShzdW1tYXJ5Um93LCB3aXRoTW9kdWxlQnJlYWtkb3duID0gZmFsc2UpIHtcclxuICAgICAgICBsZXQgc3VtbWFyeU1ldGhvZCA9IHdpdGhNb2R1bGVCcmVha2Rvd24gPyBnZXRBZHZhbmNlZFN1bW1hcnkgOiBnZXRTdW1tYXJ5O1xyXG5cclxuICAgICAgICBjb25zdCBsb2FkZXIgPSA8dGQgY29sc3Bhbj1cIjRcIj5Mb2FkaW5nIHN1bW1hcnkgJmhlbGxpcDsgPExvYWRpbmcgY29sb3I9XCJibGFja1wiIC8+PERvd25sb2FkUHJvZ3Jlc3NCYXIgZG93bmxvYWRGdW5jdGlvbj17KG9uUHJvZ3Jlc3MpID0+IHN1bW1hcnlNZXRob2QoZW50cnksIG9uUHJvZ3Jlc3MpfSByZXR1cm5GdW5jdGlvbj17YWZ0ZXJEb3dubG9hZH0+PC9Eb3dubG9hZFByb2dyZXNzQmFyPjwvdGQ+O1xyXG4gICAgICAgIGlmIChzdW1tYXJ5Um93LmZpcnN0RWxlbWVudENoaWxkKSB7XHJcbiAgICAgICAgICAgIHN1bW1hcnlSb3cucmVtb3ZlQ2hpbGQoc3VtbWFyeVJvdy5maXJzdEVsZW1lbnRDaGlsZCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHN1bW1hcnlSb3cuYXBwZW5kQ2hpbGQobG9hZGVyKTtcclxuXHJcbiAgICAgICAgYXN5bmMgZnVuY3Rpb24gYWZ0ZXJEb3dubG9hZChzdW1tYXJ5KSB7XHJcbiAgICAgICAgICAgIGxldCBsZWN0dXJlckNvdW50ID0gMDtcclxuICAgICAgICAgICAgbGV0IGxlY3R1cmVyU3VtID0gMDtcclxuICAgICAgICAgICAgbGV0IG51bWJlck9mTGVjdHVyZXJzID0gMDtcclxuICAgICAgICAgICAgbGV0IGxlY3R1cmVyU3VtbWFyeUluc3RhbmNlID0gdW5kZWZpbmVkO1xyXG4gICAgICAgICAgICBsZXQgaW5jbHVkZWQgPSBzdW1tYXJ5LmZpbHRlcihzID0+IHMuc3VtbWFyaXplKTtcclxuICAgICAgICAgICAgaWYgKGluY2x1ZGVkLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICBpbmNsdWRlZCA9IHN1bW1hcnk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHN1bW1hcnkpO1xyXG4gICAgICAgICAgICBjb25zdCBjb250ZW50ID0gKDx0ZCBjb2xzcGFuPVwiNFwiPlxyXG4gICAgICAgICAgICAgICAge3dpdGhNb2R1bGVCcmVha2Rvd24gPT0gdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgID8gJydcclxuICAgICAgICAgICAgICAgICAgICA6IDxkaXY+PGEgY2xhc3NOYW1lPVwic3VtbWFyeS1saW5rXCIgaHJlZj1cImphdmFzY3JpcHQ6dm9pZCgwKVwiIG9uQ2xpY2s9eygpID0+IHJlcGxhY2VTdW1tYXJ5RGF0YShzdW1tYXJ5Um93LCB0cnVlKX0+TG9hZCBNb2R1bGUgQnJlYWtkb3duPC9hPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAge2luY2x1ZGVkLm1hcChzZWN0aW9uID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgcmVzdWx0ID0gbnVsbDtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgc3VtbWFyeUluc3RhbmNlID0gc2VjdGlvbi5leGNsU3VtbWFyeUJ5SW5zdGFuY2UgPyBzZWN0aW9uLmV4Y2xTdW1tYXJ5QnlJbnN0YW5jZSA6IHNlY3Rpb24uc3VtbWFyeUJ5SW5zdGFuY2U7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChzZWN0aW9uLmxlY3R1cmVyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxlY3R1cmVyQ291bnQgKz0gc2VjdGlvbi5leGNsQ291bnQgfHwgc2VjdGlvbi5jb3VudDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGVjdHVyZXJTdW0gKz0gKHNlY3Rpb24uZXhjbENvdW50ICogc2VjdGlvbi5leGNsTWVhbikgfHwgKHNlY3Rpb24uY291bnQgKiBzZWN0aW9uLm1lYW4pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZWN0aW9uLm5hbWUgPSBzZWN0aW9uLm5hbWUuc3BsaXQoJyAtICcpWzBdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBudW1iZXJPZkxlY3R1cmVycysrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAod2l0aE1vZHVsZUJyZWFrZG93bikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGxlY3R1cmVyU3VtbWFyeUluc3RhbmNlID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlY3R1cmVyU3VtbWFyeUluc3RhbmNlID0ge307XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgT2JqZWN0LmtleXMoc3VtbWFyeUluc3RhbmNlKS5mb3JFYWNoKGsgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChsZWN0dXJlclN1bW1hcnlJbnN0YW5jZVtrXSA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGVjdHVyZXJTdW1tYXJ5SW5zdGFuY2Vba10gPSB7IGxlY3R1cmVyc0F2ZzogMCwgbGVjdHVyZXJzQ291bnQ6IDAgfTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlY3R1cmVyU3VtbWFyeUluc3RhbmNlW2tdLmxlY3R1cmVyc0F2ZyArPSBzdW1tYXJ5SW5zdGFuY2Vba10uYXZnO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlY3R1cmVyU3VtbWFyeUluc3RhbmNlW2tdLmxlY3R1cmVyc0NvdW50ICs9IHN1bW1hcnlJbnN0YW5jZVtrXS5jb3VudDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZWN0dXJlclN1bW1hcnlJbnN0YW5jZVtrXS5pbnN0YW5jZVR5cGUgPSBzdW1tYXJ5SW5zdGFuY2Vba10uaW5zdGFuY2VUeXBlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHJlc3VsdCA9IDxkaXYgY2xhc3NOYW1lPVwic2VzLXN1cnZleVwiPntzZWN0aW9uLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxhYmJyIHRpdGxlPVwiVG90YWxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImF2ZXJhZ2VcIj57c2VjdGlvbi5leGNsTWVhbiB8fCBzZWN0aW9uLm1lYW4gfHwgJ04vQSd9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2FiYnI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtzdW1tYXJ5SW5zdGFuY2UgIT09IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBPYmplY3QuZW50cmllcyhzdW1tYXJ5SW5zdGFuY2UpLnNvcnQoKFthS2V5LCBhVmFsdWVdLCBbYktleSwgYlZhbHVlXSkgPT4gKGFWYWx1ZS5pbnN0YW5jZVR5cGUgPz8gJycpLmxvY2FsZUNvbXBhcmUoYlZhbHVlLmluc3RhbmNlVHlwZSA/PyAnJykpLm1hcCgoW2lLZXksIGlWYWx1ZV0pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoPGFiYnIgdGl0bGU9e2Ake2lLZXl9XFxuUGFydGljaXBhbnRzOiAke2lWYWx1ZS5jb3VudH1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhdmVyYWdlXCIgc3R5bGU9e3sgJ2JhY2tncm91bmQtY29sb3InOiBpVmFsdWUuaW5zdGFuY2VUeXBlPy5zdGFydHNXaXRoKCdNb2R1bGUnKSA/ICdwdXJwbGUnIDogaVZhbHVlLmluc3RhbmNlVHlwZT8uc3RhcnRzV2l0aCgnT3BlbicpID8gJ25hdnknIDogJ2RhcmtyZWQnIH19PntpVmFsdWUubWVhbiB8fCAnTi9BJ308L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2FiYnI+KSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJyd9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+O1xyXG5cclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICB7bGVjdHVyZXJDb3VudCA+IDAgJiYgPGRpdiBjbGFzc05hbWU9XCJzZXMtc3VydmV5XCI+TGVjdHVyZXIgYXZlcmFnZVxyXG4gICAgICAgICAgICAgICAgICAgIDxhYmJyIHRpdGxlPVwiVG90YWxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYXZlcmFnZVwiPntOdW1iZXIoKGxlY3R1cmVyU3VtIC8gbGVjdHVyZXJDb3VudCkudG9GaXhlZCgyKSl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvYWJicj5cclxuICAgICAgICAgICAgICAgICAgICB7bGVjdHVyZXJTdW1tYXJ5SW5zdGFuY2UgIT09IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IE9iamVjdC5lbnRyaWVzKGxlY3R1cmVyU3VtbWFyeUluc3RhbmNlKS5zb3J0KChbYUtleSwgYVZhbHVlXSwgW2JLZXksIGJWYWx1ZV0pID0+IChhVmFsdWUuaW5zdGFuY2VUeXBlID8/ICcnKS5sb2NhbGVDb21wYXJlKGJWYWx1ZS5pbnN0YW5jZVR5cGUgPz8gJycpKS5tYXAoKFtpS2V5LCBpVmFsdWVdKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAoPGFiYnIgdGl0bGU9e2Ake2lLZXl9XFxuJHtpVmFsdWUubGVjdHVyZXJzQ291bnR9IHZvdGVzIG92ZXIgJHtudW1iZXJPZkxlY3R1cmVyc30gcXVlc3Rpb25zYH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhdmVyYWdlXCIgc3R5bGU9e3sgJ2JhY2tncm91bmQtY29sb3InOiBpVmFsdWUuaW5zdGFuY2VUeXBlPy5zdGFydHNXaXRoKCdNb2R1bGUnKSA/ICdwdXJwbGUnIDogaVZhbHVlLmluc3RhbmNlVHlwZT8uc3RhcnRzV2l0aCgnT3BlbicpID8gJ25hdnknIDogJ2RhcmtyZWQnIH19PntOdW1iZXIoKGlWYWx1ZS5sZWN0dXJlcnNBdmcgLyBpVmFsdWUubGVjdHVyZXJzQ291bnQpLnRvRml4ZWQoMikpIHx8ICdOL0EnfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9hYmJyPikpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJyd9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj59XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlcy1zdXJ2ZXlcIj5QYXJ0aWNpcGFudHM6IHtzdW1tYXJ5LnBhcnRpY2lwYW50c308L2Rpdj5cclxuICAgICAgICAgICAgPC90ZD4pO1xyXG5cclxuICAgICAgICAgICAgbG9hZGVyLnJlbW92ZSgpO1xyXG4gICAgICAgICAgICBzdW1tYXJ5Um93LmFwcGVuZENoaWxkKGNvbnRlbnQpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iLCIvLy8gPHJlZmVyZW5jZSBwYXRoPVwiLi4vdXRpbC9hcGkuZC50c1wiIC8+XHJcbmltcG9ydCB7IHdpdGhDYWNoZSwgc3RvcmVzLCBjbGVhckNhY2hlIH0gZnJvbSAnLi4vdXRpbC9kYXRhLWNvbm5lY3QnO1xyXG5pbXBvcnQgc3RhdHMgZnJvbSAnLi9zdGF0cyc7XHJcbmltcG9ydCB7IGRpc3RyaWJ1dGUsIGdldFN1YnNpdGUgfSBmcm9tICcuLi91dGlsL3V0aWwnO1xyXG5pbXBvcnQgeyBnZXRQYXltZW50cyB9IGZyb20gJy4uL3BheW1lbnRzL2RhdGEvcGF5bWVudHMnO1xyXG5cclxuXHJcbi8qKlxyXG4gKiBAcGFyYW0ge1NVQVBJfSBhcGkgXHJcbiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U3VydmV5cyhhcGksIHBhZ2UsIHF1ZXJ5KSB7XHJcbiAgICByZXR1cm4gd2l0aENhY2hlKGFwaS5nZXRTdXJ2ZXlzLCBzdG9yZXMuU1VSVkVZUyArIGdldFN1YnNpdGUoKSArIHF1ZXJ5ICsgcGFnZSwgMzYwMCkocGFnZSwgcXVlcnkpO1xyXG59XHJcblxyXG4vKipcclxuICogQHBhcmFtIHtTVUFQSX0gYXBpIFxyXG4gKi9cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFsbFN1cnZleXMoYXBpLCBwYWdlLCBxdWVyeSwgc3RhcnREYXRlLCBlbmREYXRlLCBwYWdlU2l6ZSkge1xyXG4gICAgcmV0dXJuIHdpdGhDYWNoZShhcGkuZ2V0U3VydmV5c0J5TmFtZUFuZFN0YXJ0QW5kRW5kRGF0ZSwgc3RvcmVzLlNVUlZFWVNfQUxMICsgZ2V0U3Vic2l0ZSgpICsgcXVlcnkgKyAnXycgKyBzdGFydERhdGUgKyAnXycgKyBlbmREYXRlLCAzNjAwKShwYWdlLCBxdWVyeSwgc3RhcnREYXRlLCBlbmREYXRlLCBwYWdlU2l6ZSk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBAcGFyYW0ge1NVQVBJfSBhcGkgXHJcbiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U3VydmV5QnlJZChhcGksIHN1cnZleUlkKSB7XHJcbiAgICByZXR1cm4gd2l0aENhY2hlKGFwaS5nZXRTdXJ2ZXlCeUlkLCBzdG9yZXMuU1VSVkVZICsgZ2V0U3Vic2l0ZSgpICsgc3VydmV5SWQsIDM2MDApKHN1cnZleUlkKTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEBwYXJhbSB7U1VBUEl9IGFwaSBcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTdXJ2ZXlBbnN3ZXJzQnlTdXJ2ZXlJZChhcGksIHN1cnZleUlkKSB7XHJcbiAgICByZXR1cm4gd2l0aENhY2hlKGFwaS5nZXRTdXJ2ZXlBbnN3ZXJzLCBzdG9yZXMuU1VSVkVZICsgZ2V0U3Vic2l0ZSgpICsgc3VydmV5SWQgKyAnX0FOU1dFUlMnLCA2MDApKHN1cnZleUlkKTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEBwYXJhbSB7U1VBUEl9IGFwaSBcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTdXJ2ZXlTZWN0aW9ucyhhcGksIHN1cnZleUlkLCBzZWN0aW9uSWRzKSB7XHJcbiAgICByZXR1cm4gd2l0aENhY2hlKGFwaS5nZXRTdXJ2ZXlTZWN0aW9uc0J5SWQsIHN0b3Jlcy5TVVJWRVkgKyBnZXRTdWJzaXRlKCkgKyBzdXJ2ZXlJZCArICdfU0VDVElPTlMnLCAzNjAwKShzZWN0aW9uSWRzKTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEBwYXJhbSB7U1VBUEl9IGFwaSBcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTdW1tYXJ5KGFwaSwgc3VydmV5KSB7XHJcbiAgICBjb25zdCBhbnN3ZXJzID0gKGF3YWl0IGdldFN1cnZleUFuc3dlcnNCeVN1cnZleUlkKGFwaSwgc3VydmV5LklkKSkuRGF0YTtcclxuICAgIGNvbnN0IHNlY3Rpb25zID0gc3VydmV5LlNlY3Rpb25zLmxlbmd0aCA+IDAgPyAoYXdhaXQgZ2V0U3VydmV5U2VjdGlvbnMoYXBpLCBzdXJ2ZXkuSWQsIHN1cnZleS5TZWN0aW9ucy5tYXAocyA9PiBzLklkKSkpLkRhdGEgOiBbXTtcclxuICAgIHJldHVybiBzdGF0cy5zdW1tYXJpemUoc2VjdGlvbnMsIGFuc3dlcnMpO1xyXG59XHJcblxyXG4vKipcclxuICogQHBhcmFtIHtTVUFQSX0gYXBpIFxyXG4gKi9cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFkdmFuY2VkU3VtbWFyeShhcGksIHN1cnZleSwgb25Qcm9ncmVzcyA9IHVuZGVmaW5lZCkge1xyXG4gICAgY29uc3QgYW5zd2VycyA9IChhd2FpdCBnZXRTdXJ2ZXlBbnN3ZXJzQnlTdXJ2ZXlJZChhcGksIHN1cnZleS5JZCkpLkRhdGE7XHJcbiAgICBjb25zdCBzZWN0aW9ucyA9IHN1cnZleS5TZWN0aW9ucy5sZW5ndGggPiAwID8gKGF3YWl0IGdldFN1cnZleVNlY3Rpb25zKGFwaSwgc3VydmV5LklkLCBzdXJ2ZXkuU2VjdGlvbnMubWFwKHMgPT4gcy5JZCkpKS5EYXRhIDogW107XHJcblxyXG4gICAgLy9UT0RPOiBzd2l0Y2ggdG8gZ2V0dGluZyBjb3Vyc2UgaW5zdGFuY2UgZnJvbSBzdXJ2ZXkgcHJvcGVydHksIHdoZW4gaXQncyBjb3JyZWN0bHkgYWRkZWQgdG8gc3VydmV5IGFuZCB1c2UgZ2V0dGluZyBieSBuYW1lIGFzIGEgZmFsbGJhY2tcclxuICAgIGxldCBzdXJ2ZXlDb3Vyc2VJbnN0YW5jZU5hbWUgPSBzdXJ2ZXkuTmFtZS5zdWJzdHJpbmcoMCwgc3VydmV5Lk5hbWUubGFzdEluZGV4T2YoJyAtICcpKS50cmltKCk7XHJcblxyXG4gICAgbGV0IGFwcE5hbWUgPSBnZXRTdWJzaXRlKCk7XHJcbiAgICAvLyBDYWNoZSBtb2R1bGVzIGZvciAyIGhvdXJzLCB0aGUgYWN0dWFsIG1vZHVsZXMgd2lsbCBwcm9iYWJseSBub3QgYmUgdXBkYXRlZCB2ZXJ5IG9mdGVuXHJcbiAgICBsZXQgbW9kdWxlcyA9IGF3YWl0ICh3aXRoQ2FjaGUoYXBpLmdldE1vZHVsZXMsIGAke3N0b3Jlcy5NT0RVTEVTfS0ke2FwcE5hbWV9YCwgNzIwMCkoKSk7XHJcbiAgICBsZXQgbW9kdWxlSW5zdGFuY2VzID0gKGF3YWl0IGRpc3RyaWJ1dGUoXHJcbiAgICAgICAgbW9kdWxlcy5tYXAoeCA9PiAoKSA9PiB3aXRoQ2FjaGUoYXBpLmdldEluc3RhbmNlc0luTW9kdWxlLCBgJHtzdG9yZXMuTU9EVUxFX0lOU1RBTkNFU30tJHthcHBOYW1lfS0ke3guSWR9YCwgNzIwMCkoeC5JZCkpLFxyXG4gICAgICAgIG9uUHJvZ3Jlc3MsXHJcbiAgICAgICAgMzAwKSlcclxuICAgICAgICAuZmxhdE1hcChtID0+IG0uRGF0YSk7XHJcblxyXG4gICAgbGV0IG1vZHVsZUluc3RhbmNlc1doaWNoQ29udGFpblN1cnZleUNvdXJzZSA9IG1vZHVsZUluc3RhbmNlcy5yZWR1Y2UoKGEsIGMpID0+IHtcclxuICAgICAgICBpZiAoYy5Db3Vyc2VJbnN0YW5jZXMuc29tZSh4ID0+IHN1cnZleUNvdXJzZUluc3RhbmNlTmFtZS5pbmNsdWRlcyh4LnRyaW0oKSkpKSB7XHJcbiAgICAgICAgICAgIGEucHVzaChjKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGE7XHJcbiAgICB9LCBbXSk7XHJcblxyXG4gICAgLy8gTW9kdWxlIEluc3RhbmNlIHBheW1lbnRzXHJcbiAgICBsZXQgbW9kdWxlSW5zdGFuY2VQYXltZW50c0tleVZhbHVlQ29sbGVjdGlvbiA9IFtdO1xyXG4gICAgaWYgKG1vZHVsZUluc3RhbmNlc1doaWNoQ29udGFpblN1cnZleUNvdXJzZS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgbGV0IG1vZHVsZUluc3RhbmNlUGF5bWVudHMgPSBhd2FpdCBnZXRQYXltZW50cyhtb2R1bGVJbnN0YW5jZXNXaGljaENvbnRhaW5TdXJ2ZXlDb3Vyc2UpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKG1vZHVsZUluc3RhbmNlUGF5bWVudHMpO1xyXG5cclxuICAgICAgICBtb2R1bGVJbnN0YW5jZVBheW1lbnRzS2V5VmFsdWVDb2xsZWN0aW9uID0gbW9kdWxlSW5zdGFuY2VQYXltZW50cy5mbGF0TWFwKHggPT4geC5wYXltZW50cykubWFwKHggPT4ge1xyXG4gICAgICAgICAgICB4Lkluc3RhbmNlVHlwZSA9ICdNb2R1bGUnO1xyXG4gICAgICAgICAgICB4Lkluc3RhbmNlTmFtZSA9IHguTW9kdWxlTmFtZUJnO1xyXG4gICAgICAgICAgICB4Lkluc3RhbmNlSWQgPSB4LkxldmVsSW5zdGFuY2VJZDtcclxuICAgICAgICAgICAgcmV0dXJuIFt4LlBhaWRGb3JVc2VyTmFtZSwgeF07XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gQ291cnNlIEluc3RhbmNlIFBheW1lbnRzXHJcbiAgICBsZXQgdHJhaW5pbmdzID0gKGF3YWl0IGFwaS5zZWFyY2hUcmFpbmluZ3NCeU5hbWUoc3VydmV5Q291cnNlSW5zdGFuY2VOYW1lKSk7XHJcbiAgICBsZXQgY291cnNlSW5zdGFuY2VQYXltZW50c0tleVZhbHVlQ29sbGVjdGlvbiA9IFtdO1xyXG4gICAgaWYgKHRyYWluaW5ncy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgbGV0IHRyYWluaW5nID0gdHJhaW5pbmdzWzBdO1xyXG5cclxuICAgICAgICAvL1RPRE86IEV4dHJhY3QgYSBwYXltZW50cyBidXNpbmVzcyBzZXJ2aWNlIHRvIHJldXNlIGl0XHJcbiAgICAgICAgbGV0IGNvdXJzZUluc3RhbmNlUHJvZHVjdHMgPSAoYXdhaXQgYXBpLmdldFByb2R1Y3RzRm9yQ291cnNlKHRyYWluaW5nLlRyYWluaW5nSWQpKS5EYXRhO1xyXG4gICAgICAgIGxldCBjb3Vyc2VJbnN0YW5jZVBhY2thZ2VzID0gW107XHJcbiAgICAgICAgaWYgKGNvdXJzZUluc3RhbmNlUHJvZHVjdHMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICBjb3Vyc2VJbnN0YW5jZVBhY2thZ2VzID0gKGF3YWl0IGFwaS5nZXRQYWNrYWdlc0ZvclByb2R1Y3QoY291cnNlSW5zdGFuY2VQcm9kdWN0cy5tYXAoeCA9PiB4LklkKSkpLkRhdGE7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgcGF5bWVudHNCeUluc3RhbmNlSWQgPSBbXTtcclxuICAgICAgICBpZiAoY291cnNlSW5zdGFuY2VQYWNrYWdlcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIHBheW1lbnRzQnlJbnN0YW5jZUlkID0gKGF3YWl0IGRpc3RyaWJ1dGUoY291cnNlSW5zdGFuY2VQYWNrYWdlcy5tYXAoeCA9PiBjYWNoZWRQYXltZW50cyh4LCBhcGkpKSwgdW5kZWZpbmVkLCAzMDApKS5mbGF0TWFwKHggPT4geC5EYXRhKTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2cocGF5bWVudHNCeUluc3RhbmNlSWQpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY291cnNlSW5zdGFuY2VQYXltZW50c0tleVZhbHVlQ29sbGVjdGlvbiA9IHBheW1lbnRzQnlJbnN0YW5jZUlkLm1hcCh4ID0+IHtcclxuICAgICAgICAgICAgeC5JbnN0YW5jZVR5cGUgPSAnT3BlbiBDb3Vyc2UnO1xyXG4gICAgICAgICAgICB4Lkluc3RhbmNlTmFtZSA9IHRyYWluaW5nLk5hbWVCZztcclxuICAgICAgICAgICAgeC5JbnN0YW5jZUlkID0gdHJhaW5pbmcuVHJhaW5pbmdJZDtcclxuICAgICAgICAgICAgcmV0dXJuIFt4LlBhaWRGb3JVc2VyTmFtZSwgeF07XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gR3JvdXAgTW9kdWxlIEluc3RhbmNlIGFuZCBDb3Vyc2UgSW5zdGFuY2UgcGF5bWVudHMgdG8gY2hlY2sgdXNlcnMgYWdhaW5zdCB0aGVtXHJcbiAgICBsZXQgYWxsUGF5bWVudHNLZXlWYWx1ZUNvbGxlY3Rpb24gPSBtb2R1bGVJbnN0YW5jZVBheW1lbnRzS2V5VmFsdWVDb2xsZWN0aW9uLmNvbmNhdChjb3Vyc2VJbnN0YW5jZVBheW1lbnRzS2V5VmFsdWVDb2xsZWN0aW9uKTtcclxuICAgIGxldCBwYXltZW50c01hcCA9IG5ldyBNYXAoYWxsUGF5bWVudHNLZXlWYWx1ZUNvbGxlY3Rpb24pO1xyXG5cclxuICAgIC8vRGVjb3JhdGUgcGF5bWVudHMgd2l0aCBpbmZvIGFib3V0IG1vZHVsZS9jb3Vyc2VcclxuICAgIGFuc3dlcnMuZm9yRWFjaChhID0+IHtcclxuICAgICAgICBsZXQgcGF5bWVudCA9IHBheW1lbnRzTWFwLmdldChhLlVzZXJOYW1lKTtcclxuICAgICAgICBpZiAocGF5bWVudCAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgYS5JbnN0YW5jZVR5cGUgPSBwYXltZW50Lkluc3RhbmNlVHlwZTtcclxuICAgICAgICAgICAgYS5JbnN0YW5jZU5hbWUgPSBwYXltZW50Lkluc3RhbmNlTmFtZTtcclxuICAgICAgICAgICAgYS5JbnN0YW5jZUlkID0gcGF5bWVudC5JbnN0YW5jZUlkO1xyXG4gICAgICAgIH1cclxuICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHN0YXRzLnN1bW1hcml6ZShzZWN0aW9ucywgYW5zd2VycywgdHJ1ZSk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBAcGFyYW0ge1NVQVBJfSBhcGkgXHJcbiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RmluYWxpemVkU3VydmV5c0V4cG9ydChhcGksIHN0YXJ0RGF0ZSwgZW5kRGF0ZSwgb25Qcm9ncmVzcyA9IHVuZGVmaW5lZCkge1xyXG4gICAgY29uc3Qgc3VydmV5c1JlcXVlc3QgPSBhd2FpdCBnZXRBbGxTdXJ2ZXlzKGFwaSwgMSwgJ9GE0LjQvdCw0LvQvdCwJywgc3RhcnREYXRlLCBlbmREYXRlLCAxMDAwMCk7XHJcbiAgICBjb25zdCBzdXJ2ZXlzID0gc3VydmV5c1JlcXVlc3QuRGF0YTtcclxuICAgIGNvbnNvbGUubG9nKHN1cnZleXMpO1xyXG4gICAgbGV0IHN1cnZleUFuc3dlcnMgPSAoYXdhaXQgZGlzdHJpYnV0ZShzdXJ2ZXlzLm1hcCh4ID0+ICgpID0+IGdldFN1cnZleUFuc3dlcnNCeVN1cnZleUlkKGFwaSwgeC5JZCkudGhlbihkID0+ICh7IFN1cnZleUlkOiB4LklkLCBEYXRhOiBkLkRhdGEgfSkpKSwgb25Qcm9ncmVzcywgMzAwKSlcclxuICAgICAgICAucmVkdWNlKChhLCBjKSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBkYXRhID0gYy5EYXRhO1xyXG4gICAgICAgICAgICBhW2MuU3VydmV5SWRdID0gZGF0YTtcclxuICAgICAgICAgICAgcmV0dXJuIGE7XHJcbiAgICAgICAgfSwge30pO1xyXG5cclxuICAgIGNvbnNvbGUubG9nKHN1cnZleUFuc3dlcnMpO1xyXG5cclxuICAgIGxldCBzdXJ2ZXlTZWN0aW9ucyA9IChhd2FpdCBkaXN0cmlidXRlKHN1cnZleXMubWFwKHggPT4gKCkgPT4gKHguU2VjdGlvbnMubGVuZ3RoID4gMFxyXG4gICAgICAgID8gZ2V0U3VydmV5U2VjdGlvbnMoYXBpLCB4LklkLCB4LlNlY3Rpb25zLm1hcChzID0+IHMuSWQpKS50aGVuKGQgPT4gKHsgU3VydmV5SWQ6IHguSWQsIERhdGE6IGQuRGF0YSB9KSlcclxuICAgICAgICA6IFByb21pc2UucmVzb2x2ZShbXSkpKSwgb25Qcm9ncmVzcywgMzAwKSlcclxuICAgICAgICAucmVkdWNlKChhLCBjKSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBkYXRhID0gYy5EYXRhO1xyXG4gICAgICAgICAgICBhW2MuU3VydmV5SWRdID0gZGF0YTtcclxuICAgICAgICAgICAgcmV0dXJuIGE7XHJcbiAgICAgICAgfSwge30pO1xyXG5cclxuICAgIGNvbnNvbGUubG9nKHN1cnZleVNlY3Rpb25zKTtcclxuICAgIGxldCByZXN1bHRzID0gW1xyXG4gICAgICAgIFsnU3VydmV5IE5hbWUnLCAnQWN0aXZlIEZyb20nLCAnQXZlcmFnZSBHcmFkZSddXHJcbiAgICBdO1xyXG4gICAgbGV0IHRvdGFsU3VtbWFyaXplID0gW107XHJcbiAgICBmb3IgKGNvbnN0IHN1cnZleSBvZiBzdXJ2ZXlzKSB7XHJcbiAgICAgICAgbGV0IGtleSA9IHN1cnZleS5JZDtcclxuICAgICAgICAvLyBjb25zdCBhbnN3ZXJzID0gKGF3YWl0IGdldFN1cnZleUFuc3dlcnNCeVN1cnZleUlkKGFwaSwgc3VydmV5LklkKSkuRGF0YTtcclxuICAgICAgICAvLyBjb25zdCBzZWN0aW9ucyA9IHN1cnZleS5TZWN0aW9ucy5sZW5ndGggPiAwID8gKGF3YWl0IGdldFN1cnZleVNlY3Rpb25zKGFwaSwgc3VydmV5LklkLCBzdXJ2ZXkuU2VjdGlvbnMubWFwKHMgPT4gcy5JZCkpKS5EYXRhIDogW107XHJcbiAgICAgICAgbGV0IHJlc3VsdCA9IHN0YXRzLnN1bW1hcml6ZShzdXJ2ZXlTZWN0aW9uc1trZXldLCBzdXJ2ZXlBbnN3ZXJzW2tleV0pO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKHJlc3VsdCk7XHJcbiAgICAgICAgdG90YWxTdW1tYXJpemUucHVzaChyZXN1bHQpO1xyXG5cclxuICAgICAgICAvLyBsZXQgc3VtbWFyaXplZENvdXJzZVNlY3Rpb24gPSByZXN1bHQuZmluZCh4ID0+IHgubmFtZS5zdGFydHNXaXRoKCfQktGK0L/RgNC+0YHQuCDQt9CwINC60YPRgNGB0LAgLScpKTtcclxuICAgICAgICBsZXQgYWxsUXVlc3Rpb25zID0gcmVzdWx0LmZsYXRNYXAoeCA9PiB4LnF1ZXN0aW9ucyk7XHJcbiAgICAgICAgbGV0IHN1bW1hcml6ZWRHcmFkZSA9IFtzdXJ2ZXkuTmFtZSwgJ04vQScsICdOL0EnXTtcclxuICAgICAgICBsZXQgc3VtbWFyaXplZEdyYWRlUXVlc3Rpb24gPSBhbGxRdWVzdGlvbnMuZmluZCh4ID0+XHJcbiAgICAgICAgICAgICh4Lm5hbWUuaW5jbHVkZXMoJ9Ca0LDQuiDQvtGG0LXQvdGP0LLQsNGC0LUg0LrQsNGH0LXRgdGC0LLQvtGC0L4g0L3QsCDQutGD0YDRgdCwPycpIHx8XHJcbiAgICAgICAgICAgICAgICB4Lm5hbWUuaW5jbHVkZXMoJ9Ca0LDQutCy0LAg0LUg0L7RhtC10L3QutCw0YLQsCDQktC4INC30LAg0LrRg9GA0YHQsCDQutCw0YLQviDRhtGP0LvQvj8nKSB8fFxyXG4gICAgICAgICAgICAgICAgeC5uYW1lLmluY2x1ZGVzKCfQmtCw0LrQstCwINC1INGG0Y/Qu9C+0YHRgtC90LDRgtCwINCS0Lgg0L7RhtC10L3QutCwINC30LAg0LrRg9GA0YHQsD8nKSB8fFxyXG4gICAgICAgICAgICAgICAgeC5uYW1lLmluY2x1ZGVzKCfQmtCw0LrQstCwINC1INC+0YbQtdC90LrQsNGC0LAg0JLQuCDQt9CwINC/0YDQvtCy0LXQttC00LDQvdC10YLQviDQvdCwINC30LDQvdGP0YLQuNGP0YLQsD8nKSkgJiZcclxuICAgICAgICAgICAgeC50eXBlID09PSAnc2NhbGUnKTtcclxuICAgICAgICBpZiAoc3VtbWFyaXplZEdyYWRlUXVlc3Rpb24pIHtcclxuICAgICAgICAgICAgc3VtbWFyaXplZEdyYWRlID0gW3N1cnZleS5OYW1lLCBzdXJ2ZXkuQWN0aXZlRnJvbSwgc3VtbWFyaXplZEdyYWRlUXVlc3Rpb24ubWVhbixdO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmVzdWx0cy5wdXNoKHN1bW1hcml6ZWRHcmFkZSk7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc29sZS5sb2cocmVzdWx0cylcclxuICAgIHJldHVybiByZXN1bHRzO1xyXG59XHJcblxyXG4vKipcclxuICogXHJcbiAqIEBwYXJhbSB7U1VQYWNrYWdlfSBwIFxyXG4gKiBAcGFyYW0ge1NVQVBJfSBhcGlcclxuICogQHJldHVybnMge1Byb21pc2U8U1VSZXNwb25zZTxTVVBheW1lbnQ+Pn1cclxuICovXHJcbmZ1bmN0aW9uIGNhY2hlZFBheW1lbnRzKHAsIGFwaSkge1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgICBjb25zdCBuYW1lID0gcC5OYW1lO1xyXG4gICAgICAgIGNvbnN0IHN0b3JlTmFtZSA9IHN0b3Jlcy5QQVlNRU5UUyArIGdldFN1YnNpdGUoKSArIG5hbWU7XHJcbiAgICAgICAgcmV0dXJuIHdpdGhDYWNoZShhcGkuZ2V0UGF5bWVudHNGb3JQYWNrYWdlLCBzdG9yZU5hbWUsIDE4MDApKG5hbWUpO1xyXG4gICAgfTtcclxufSIsImltcG9ydCB7IGdldFN1YnNpdGUgfSBmcm9tICcuLi91dGlsL3V0aWwnO1xyXG5cclxuY29uc3Qgc3VtbWFyaXphYmxlID0ge1xyXG4gICAgJ3Byb2dyYW1taW5nJzoge1xyXG4gICAgICAgIHRlbXBsYXRlczogbmV3IFNldChbMTY1LCAxNjQsIDE0MywgMTQyLCAxNDEsIDE0MCwgMTM3LCAxMzQsIDEzMSwgMTMwLCAxMjksIDEyNywgMTI2LCAxMjVdKSxcclxuICAgICAgICBxdWVzdGlvbnM6IG5ldyBTZXQoW1xyXG4gICAgICAgICAgICAn0JrQsNC6INC+0YbQtdC90Y/QstCw0YLQtSDQutCw0YfQtdGB0YLQstC+0YLQviDQvdCwINC60YPRgNGB0LAg0LTQviDQvNC+0LzQtdC90YLQsD8nLFxyXG4gICAgICAgICAgICAn0JrQsNC6INC+0YbQtdC90Y/QstCw0YLQtSDQutCw0YfQtdGB0YLQstC+0YLQviDQvdCwINC60YPRgNGB0LA/J1xyXG4gICAgICAgIF0pLFxyXG4gICAgICAgIGxlY3R1cmVyOiBuZXcgU2V0KFsxMzYsIDEzMF0pXHJcbiAgICB9LFxyXG4gICAgJ2RpZ2l0YWwnOiB7XHJcbiAgICAgICAgdGVtcGxhdGVzOiBuZXcgU2V0KFs2MSwgNjAsIDQ3LCA0NiwgNDUsIDQ0LCA0MywgNDIsIDM5LCAzNiwgMzUsIDM0LCAzMiwgMzEsIDMwLCAyOCwgMjddKSxcclxuICAgICAgICBxdWVzdGlvbnM6IG5ldyBTZXQoW1xyXG4gICAgICAgICAgICAn0JrQsNC6INC+0YbQtdC90Y/QstCw0YLQtSDQutCw0YfQtdGB0YLQstC+0YLQviDQvdCwINC60YPRgNGB0LAg0LTQviDQvNC+0LzQtdC90YLQsD8nLFxyXG4gICAgICAgICAgICAn0JrQsNC6INC+0YbQtdC90Y/QstCw0YLQtSDQutCw0YfQtdGB0YLQstC+0YLQviDQvdCwINC60YPRgNGB0LA/JyxcclxuICAgICAgICAgICAgJ1doYXQgaXMgeW91ciBvdmVyYWxsIGdyYWRlIGZvciB0aGUgY291cnNlPydcclxuICAgICAgICBdKSxcclxuICAgICAgICBsZWN0dXJlcjogbmV3IFNldChbMzUsIDMxLCAyOF0pXHJcbiAgICB9LFxyXG4gICAgJ2NyZWF0aXZlJzoge1xyXG4gICAgICAgIHRlbXBsYXRlczogbmV3IFNldChbNDIsIDQxLCAzNywgMzYsIDM0LCAzMSwgMjgsIDI3LCAyNiwgMjQsIDIzLCAyMl0pLFxyXG4gICAgICAgIHF1ZXN0aW9uczogbmV3IFNldChbXHJcbiAgICAgICAgICAgICfQmtCw0Log0L7RhtC10L3Rj9Cy0LDRgtC1INC60LDRh9C10YHRgtCy0L7RgtC+INC90LAg0LrRg9GA0YHQsCDQtNC+INC80L7QvNC10L3RgtCwPycsXHJcbiAgICAgICAgICAgICfQmtCw0Log0L7RhtC10L3Rj9Cy0LDRgtC1INC60LDRh9C10YHRgtCy0L7RgtC+INC90LAg0LrRg9GA0YHQsD8nXHJcbiAgICAgICAgXSksXHJcbiAgICAgICAgbGVjdHVyZXI6IG5ldyBTZXQoWzI3LCAyM10pXHJcbiAgICB9LFxyXG4gICAgJ2FpJzoge1xyXG4gICAgICAgIHRlbXBsYXRlczogbmV3IFNldChbNjEsIDYwLCA0NywgNDYsIDQ0LCA0MywgNDIsIDM5LCAzNiwgMzUsIDM0LCAzMiwgMzEsIDMwLCAyOCwgMjddKSxcclxuICAgICAgICBxdWVzdGlvbnM6IG5ldyBTZXQoW1xyXG4gICAgICAgICAgICAn0JrQsNC6INC+0YbQtdC90Y/QstCw0YLQtSDQutCw0YfQtdGB0YLQstC+0YLQviDQvdCwINC60YPRgNGB0LAg0LTQviDQvNC+0LzQtdC90YLQsD8nLFxyXG4gICAgICAgICAgICAn0JrQsNC6INC+0YbQtdC90Y/QstCw0YLQtSDQutCw0YfQtdGB0YLQstC+0YLQviDQvdCwINC60YPRgNGB0LA/JyxcclxuICAgICAgICAgICAgJ1doYXQgaXMgeW91ciBvdmVyYWxsIGdyYWRlIGZvciB0aGUgY291cnNlPydcclxuICAgICAgICBdKSxcclxuICAgICAgICBsZWN0dXJlcjogbmV3IFNldChbMzUsIDMxLCAyOF0pXHJcbiAgICB9LFxyXG4gICAgJ2RldmRpZ2l0YWwnOiB7XHJcbiAgICAgICAgdGVtcGxhdGVzOiBuZXcgU2V0KFs2MSwgNjAsIDQ3LCA0NiwgNDUsIDQ0LCA0MywgNDIsIDM5LCAzNiwgMzUsIDM0LCAzMiwgMzEsIDMwLCAyOCwgMjddKSxcclxuICAgICAgICBxdWVzdGlvbnM6IG5ldyBTZXQoW1xyXG4gICAgICAgICAgICAn0JrQsNC6INC+0YbQtdC90Y/QstCw0YLQtSDQutCw0YfQtdGB0YLQstC+0YLQviDQvdCwINC60YPRgNGB0LAg0LTQviDQvNC+0LzQtdC90YLQsD8nLFxyXG4gICAgICAgICAgICAn0JrQsNC6INC+0YbQtdC90Y/QstCw0YLQtSDQutCw0YfQtdGB0YLQstC+0YLQviDQvdCwINC60YPRgNGB0LA/JyxcclxuICAgICAgICAgICAgJ1doYXQgaXMgeW91ciBvdmVyYWxsIGdyYWRlIGZvciB0aGUgY291cnNlPydcclxuICAgICAgICBdKSxcclxuICAgICAgICBsZWN0dXJlcjogbmV3IFNldChbMzUsIDMxLCAyOF0pXHJcbiAgICB9LFxyXG4gICAgJ2RldnNvZnR1bmknOiB7XHJcbiAgICAgICAgdGVtcGxhdGVzOiBuZXcgU2V0KFsxNjUsIDE2NCwgMTQzLCAxNDIsIDE0MSwgMTQwLCAxMzcsIDEzNCwgMTMxLCAxMzAsIDEyOSwgMTI3LCAxMjYsIDEyNV0pLFxyXG4gICAgICAgIHF1ZXN0aW9uczogbmV3IFNldChbXHJcbiAgICAgICAgICAgICfQmtCw0Log0L7RhtC10L3Rj9Cy0LDRgtC1INC60LDRh9C10YHRgtCy0L7RgtC+INC90LAg0LrRg9GA0YHQsCDQtNC+INC80L7QvNC10L3RgtCwPycsXHJcbiAgICAgICAgICAgICfQmtCw0Log0L7RhtC10L3Rj9Cy0LDRgtC1INC60LDRh9C10YHRgtCy0L7RgtC+INC90LAg0LrRg9GA0YHQsD8nXHJcbiAgICAgICAgXSksXHJcbiAgICAgICAgbGVjdHVyZXI6IG5ldyBTZXQoWzEzNiwgMTMwXSlcclxuICAgIH0sXHJcbiAgICAnZmluYW5jZWFjYWRlbXknOiB7XHJcbiAgICAgICAgdGVtcGxhdGVzOiBuZXcgU2V0KFs2MSwgNjAsIDQ3LCA0NiwgNDQsIDQzLCA0MiwgMzksIDM2LCAzNSwgMzQsIDMyLCAzMSwgMzAsIDI4LCAyN10pLFxyXG4gICAgICAgIHF1ZXN0aW9uczogbmV3IFNldChbXHJcbiAgICAgICAgICAgICfQmtCw0Log0L7RhtC10L3Rj9Cy0LDRgtC1INC60LDRh9C10YHRgtCy0L7RgtC+INC90LAg0LrRg9GA0YHQsCDQtNC+INC80L7QvNC10L3RgtCwPycsXHJcbiAgICAgICAgICAgICfQmtCw0Log0L7RhtC10L3Rj9Cy0LDRgtC1INC60LDRh9C10YHRgtCy0L7RgtC+INC90LAg0LrRg9GA0YHQsD8nLFxyXG4gICAgICAgICAgICAnV2hhdCBpcyB5b3VyIG92ZXJhbGwgZ3JhZGUgZm9yIHRoZSBjb3Vyc2U/J1xyXG4gICAgICAgIF0pLFxyXG4gICAgICAgIGxlY3R1cmVyOiBuZXcgU2V0KFszNSwgMzEsIDI4XSlcclxuICAgIH0sXHJcbn07XHJcblxyXG4vKipcclxuICogQHR5cGVkZWYge09iamVjdH0gU3VydmV5QW5zd2VyXHJcbiAqIEBwcm9wZXJ0eSB7bnVtYmVyfSBJZFxyXG4gKiBAcHJvcGVydHkge251bWJlcn0gU3VydmV5SWRcclxuICogQHByb3BlcnR5IHtzdHJpbmd9IFNlY3Rpb25cclxuICogQHByb3BlcnR5IHtzdHJpbmd9IFF1ZXN0aW9uXHJcbiAqIEBwcm9wZXJ0eSB7c3RyaW5nIHwgbnVsbH0gQW5zd2VyIFxyXG4gKiBAcHJvcGVydHkge3N0cmluZyB8IG51bGx9IEZyZWVUZXh0IFxyXG4gKi9cclxuXHJcblxyXG4vKipcclxuICogQHBhcmFtIHtBcnJheTxTdXJ2ZXlBbnN3ZXI+fSBhbnN3ZXJzIFxyXG4gKi9cclxuZnVuY3Rpb24gc3VtbWFyaXplKHNlY3Rpb25EYXRhLCBhbnN3ZXJzLCBicmVha2Rvd25CeU1vZHVsZSA9IGZhbHNlKSB7XHJcbiAgICBjb25zdCBzdW1tYXJ5ID0gYW5zd2Vycy5yZWR1Y2UoXHJcbiAgICAgICAgYnJlYWtkb3duQnlNb2R1bGUgPyB0b1NlY3Rpb25zV2l0aE1vZHVsZUJyZWFrZG93biA6IHRvU2VjdGlvbnMsXHJcbiAgICAgICAgeyBzZWN0aW9uczoge30sIHZvdGVzOiBuZXcgU2V0KCkgfSk7XHJcblxyXG4gICAgY29uc3QgcmVzdWx0ID0gT2JqZWN0XHJcbiAgICAgICAgLmVudHJpZXMoc3VtbWFyeS5zZWN0aW9ucylcclxuICAgICAgICAubWFwKGJyZWFrZG93bkJ5TW9kdWxlID8gc3VtbWFyaXplU2VjdGlvbldpdGhNb2R1bGVCcmVha2Rvd24gOiBzdW1tYXJpemVTZWN0aW9uKVxyXG4gICAgICAgIC5tYXAocyA9PiBzZWN0aW9uVG9UZW1wbGF0ZShzLCBzZWN0aW9uRGF0YSkpO1xyXG5cclxuICAgIHJlc3VsdC5wYXJ0aWNpcGFudHMgPSBzdW1tYXJ5LnZvdGVzLnNpemU7XHJcblxyXG4gICAgaWYgKGJyZWFrZG93bkJ5TW9kdWxlKSB7XHJcbiAgICAgICAgY3JlYXRlSW5kZXhXaXRoTW9kdWxlQnJlYWtkb3duKHJlc3VsdCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNyZWF0ZUluZGV4KHJlc3VsdCk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIHJldHVybiByZXN1bHQ7XHJcbn1cclxuXHJcbi8vIEJhc2Ugc3VtbWFyaXplXHJcbi8qKlxyXG4gKiBAcGFyYW0ge09iamVjdH0gcmVzdWx0IFxyXG4gKiBAcGFyYW0ge1N1cnZleUFuc3dlcn0gYW5zd2VyIFxyXG4gKi9cclxuZnVuY3Rpb24gdG9TZWN0aW9ucyhyZXN1bHQsIGFuc3dlcikge1xyXG4gICAgcmVzdWx0LnZvdGVzLmFkZChhbnN3ZXIuVXNlck5hbWUgfHwgYW5zd2VyLlBhcnRpY2lwYXRpb25LZXkpO1xyXG4gICAgY29uc3Qgc2VjdGlvbiA9IGdldE9yQ3JlYXRlKHJlc3VsdC5zZWN0aW9ucywgYW5zd2VyLlNlY3Rpb24pO1xyXG4gICAgY29uc3QgcXVlc3Rpb24gPSBnZXRPckNyZWF0ZShzZWN0aW9uLCBhbnN3ZXIuUXVlc3Rpb24sIHsgY2hvaWNlczogW10sIGNvbW1lbnRzOiBbXSB9KTtcclxuXHJcbiAgICBpZiAoYW5zd2VyLkFuc3dlcikgeyAgICAvLyBhZGQgbnVtZXJpYyBncmFkZVxyXG4gICAgICAgIHF1ZXN0aW9uLmNob2ljZXMucHVzaCh7XHJcbiAgICAgICAgICAgIGluZGV4OiBhbnN3ZXIuVXNlck5hbWUgfHwgYW5zd2VyLlBhcnRpY2lwYXRpb25LZXksXHJcbiAgICAgICAgICAgIGNob2ljZTogYW5zd2VyLkFuc3dlclxyXG4gICAgICAgIH0pO1xyXG4gICAgfSBlbHNlIHsgICAgICAgICAgICAgICAgLy8gYWRkIGZyZWUgdGV4dCBhbnN3ZXJcclxuICAgICAgICBxdWVzdGlvbi5jb21tZW50cy5wdXNoKHtcclxuICAgICAgICAgICAgaW5kZXg6IGFuc3dlci5Vc2VyTmFtZSB8fCBhbnN3ZXIuUGFydGljaXBhdGlvbktleSxcclxuICAgICAgICAgICAgdGV4dDogYW5zd2VyLkZyZWVUZXh0XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxufVxyXG5cclxuZnVuY3Rpb24gc3VtbWFyaXplU2VjdGlvbihbc2VjdGlvbk5hbWUsIHF1ZXN0aW9uc10pIHtcclxuICAgIGNvbnN0IHJlc3VsdCA9IHtcclxuICAgICAgICBuYW1lOiBzZWN0aW9uTmFtZSxcclxuICAgIH07XHJcblxyXG4gICAgcmVzdWx0LnF1ZXN0aW9ucyA9IE9iamVjdC5lbnRyaWVzKHF1ZXN0aW9ucykubWFwKHN1bW1hcml6ZVF1ZXN0aW9uKTtcclxuXHJcbiAgICBjb25zdCBncmFkZXMgPSByZXN1bHQucXVlc3Rpb25zXHJcbiAgICAgICAgLmZpbHRlcihxID0+IHEudHlwZSA9PSAnc2NhbGUnKVxyXG4gICAgICAgIC5yZWR1Y2UoKGMsIHEpID0+IE9iamVjdC5hc3NpZ24oYywge1xyXG4gICAgICAgICAgICBjb3VudDogYy5jb3VudCArIHEuY291bnQsXHJcbiAgICAgICAgICAgIGF2ZzogYy5hdmcgKyBxLm1lYW4gKiBxLmNvdW50XHJcbiAgICAgICAgfSwgcS5zdW1tYXJpemUgPyB7XHJcbiAgICAgICAgICAgIGV4Y2xDb3VudDogYy5leGNsQ291bnQgKyBxLmNvdW50LFxyXG4gICAgICAgICAgICBleGNsQXZnOiBjLmV4Y2xBdmcgKyBxLm1lYW4gKiBxLmNvdW50XHJcbiAgICAgICAgfSA6IHt9KSwgeyBjb3VudDogMCwgYXZnOiAwLCBleGNsQ291bnQ6IDAsIGV4Y2xBdmc6IDAgfSk7XHJcblxyXG4gICAgaWYgKGdyYWRlcy5leGNsQ291bnQgPiAwKSB7XHJcbiAgICAgICAgcmVzdWx0LmV4Y2xDb3VudCA9IGdyYWRlcy5leGNsQ291bnQ7XHJcbiAgICAgICAgcmVzdWx0LmV4Y2xNZWFuID0gTnVtYmVyKChncmFkZXMuZXhjbEF2ZyAvIGdyYWRlcy5leGNsQ291bnQpLnRvRml4ZWQoMikpO1xyXG4gICAgfVxyXG4gICAgaWYgKGdyYWRlcy5jb3VudCA+IDApIHtcclxuICAgICAgICByZXN1bHQuY291bnQgPSBncmFkZXMuY291bnQ7XHJcbiAgICAgICAgcmVzdWx0Lm1lYW4gPSBOdW1iZXIoKGdyYWRlcy5hdmcgLyBncmFkZXMuY291bnQpLnRvRml4ZWQoMikpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiByZXN1bHQ7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHN1bW1hcml6ZVF1ZXN0aW9uKFtxdWVzdGlvbk5hbWUsIHF1ZXN0aW9uXSkge1xyXG4gICAgY29uc3QgcmVzdWx0ID0ge1xyXG4gICAgICAgIG5hbWU6IHF1ZXN0aW9uTmFtZSxcclxuICAgICAgICBzdW1tYXJpemU6IHN1bW1hcml6YWJsZVtnZXRTdWJzaXRlKCldLnF1ZXN0aW9ucy5oYXMocXVlc3Rpb25OYW1lKSxcclxuICAgICAgICBhbnN3ZXJzOiBbXVxyXG4gICAgfTtcclxuICAgIGlmIChxdWVzdGlvbi5jb21tZW50cy5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgIHNjYWxlUXVlc3Rpb24ocXVlc3Rpb24sIHJlc3VsdCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJlc3VsdC5hbnN3ZXJzID0gcXVlc3Rpb24uY29tbWVudHM7XHJcbiAgICAgICAgcmVzdWx0LnR5cGUgPSAnZnJlZSc7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxufVxyXG5cclxuLyoqXHJcbiAqIEBwYXJhbSB7QXJyYXk8U3VtbWFyaXplZFNlY3Rpb24+fSBzdW1tYXJ5IFxyXG4gKi9cclxuZnVuY3Rpb24gY3JlYXRlSW5kZXgoc3VtbWFyeSkge1xyXG4gICAgZm9yIChjb25zdCBzZWN0aW9uIG9mIHN1bW1hcnkpIHtcclxuICAgICAgICBmb3IgKGNvbnN0IHF1ZXN0aW9uIG9mIHNlY3Rpb24ucXVlc3Rpb25zLmZpbHRlcihxID0+IHEudHlwZSA9PSAnZnJlZScpKSB7XHJcbiAgICAgICAgICAgIGZvciAoY29uc3QgYW5zd2VyIG9mIHF1ZXN0aW9uLmFuc3dlcnMpIHtcclxuICAgICAgICAgICAgICAgIGFuc3dlci5yZWxhdGVkID0gc3VtbWFyeS5tYXAocyA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU6IHMubmFtZSxcclxuICAgICAgICAgICAgICAgICAgICBxdWVzdGlvbnM6IHMucXVlc3Rpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAocSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogcS5uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogcS50eXBlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmVlZGJhY2s6IHEuaW5kZXg/LlthbnN3ZXIuaW5kZXhdIHx8IHEuYW5zd2Vycy5maWx0ZXIoYSA9PiBhLmluZGV4ID09IGFuc3dlci5pbmRleClbMF0/LnRleHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICAgICAgICB9KSkuZmlsdGVyKHMgPT4gcy5xdWVzdGlvbnMubGVuZ3RoID4gMCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbi8vU3VtbWFyaXplIHdpdGggTW9kdWxlIGJyZWFrZG93bnNcclxuLyoqXHJcbiAqIEBwYXJhbSB7T2JqZWN0fSByZXN1bHQgXHJcbiAqIEBwYXJhbSB7U3VydmV5QW5zd2VyfSBhbnN3ZXIgXHJcbiAqL1xyXG5mdW5jdGlvbiB0b1NlY3Rpb25zV2l0aE1vZHVsZUJyZWFrZG93bihyZXN1bHQsIGFuc3dlcikge1xyXG4gICAgcmVzdWx0LnZvdGVzLmFkZChhbnN3ZXIuVXNlck5hbWUgfHwgYW5zd2VyLlBhcnRpY2lwYXRpb25LZXkpO1xyXG4gICAgY29uc3Qgc2VjdGlvbiA9IGdldE9yQ3JlYXRlKHJlc3VsdC5zZWN0aW9ucywgYW5zd2VyLlNlY3Rpb24pO1xyXG4gICAgY29uc3QgcXVlc3Rpb24gPSBnZXRPckNyZWF0ZShzZWN0aW9uLCBhbnN3ZXIuUXVlc3Rpb24pO1xyXG4gICAgbGV0IGluc3RhbmNlTmFtZSA9IGFuc3dlci5JbnN0YW5jZU5hbWUgPyBgJHthbnN3ZXIuSW5zdGFuY2VUeXBlfTogJHthbnN3ZXIuSW5zdGFuY2VOYW1lfWAgOiAnTi9BJztcclxuICAgIGNvbnN0IGluc3RhbmNlID0gZ2V0T3JDcmVhdGUocXVlc3Rpb24sIGluc3RhbmNlTmFtZSwgeyBjaG9pY2VzOiBbXSwgY29tbWVudHM6IFtdLCBpbnN0YW5jZVR5cGU6IGFuc3dlci5JbnN0YW5jZVR5cGUgfSlcclxuXHJcbiAgICBpZiAoYW5zd2VyLkFuc3dlcikgeyAgICAvLyBhZGQgbnVtZXJpYyBncmFkZVxyXG4gICAgICAgIGluc3RhbmNlLmNob2ljZXMucHVzaCh7XHJcbiAgICAgICAgICAgIGluZGV4OiBhbnN3ZXIuVXNlck5hbWUgfHwgYW5zd2VyLlBhcnRpY2lwYXRpb25LZXksXHJcbiAgICAgICAgICAgIGNob2ljZTogYW5zd2VyLkFuc3dlclxyXG4gICAgICAgIH0pO1xyXG4gICAgfSBlbHNlIHsgICAgICAgICAgICAgICAgLy8gYWRkIGZyZWUgdGV4dCBhbnN3ZXJcclxuICAgICAgICBpbnN0YW5jZS5jb21tZW50cy5wdXNoKHtcclxuICAgICAgICAgICAgaW5kZXg6IGFuc3dlci5Vc2VyTmFtZSB8fCBhbnN3ZXIuUGFydGljaXBhdGlvbktleSxcclxuICAgICAgICAgICAgdGV4dDogYW5zd2VyLkZyZWVUZXh0XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxufVxyXG5cclxuZnVuY3Rpb24gc3VtbWFyaXplU2VjdGlvbldpdGhNb2R1bGVCcmVha2Rvd24oW3NlY3Rpb25OYW1lLCBxdWVzdGlvbnNdKSB7XHJcbiAgICBjb25zdCByZXN1bHQgPSB7XHJcbiAgICAgICAgbmFtZTogc2VjdGlvbk5hbWUsXHJcbiAgICB9O1xyXG5cclxuICAgIHJlc3VsdC5xdWVzdGlvbnMgPSBPYmplY3QuZW50cmllcyhxdWVzdGlvbnMpLm1hcChzdW1tYXJpemVRdWVzdGlvbldpdGhNb2R1bGVCcmVha2Rvd24pO1xyXG4gICAgY29uc3QgZ3JhZGVzID0gcmVzdWx0LnF1ZXN0aW9uc1xyXG4gICAgICAgIC5maWx0ZXIocSA9PiBxLnR5cGUgPT0gJ3NjYWxlJylcclxuICAgICAgICAucmVkdWNlKChjLCBxKSA9PiB7XHJcbiAgICAgICAgICAgIGMuY291bnQgKz0gcS5jb3VudDtcclxuICAgICAgICAgICAgYy5hdmcgKz0gcS5tZWFuICogcS5jb3VudDtcclxuICAgICAgICAgICAgYy5xdWVzdGlvbnNDb3VudCsrO1xyXG5cclxuICAgICAgICAgICAgLy8gQnJlYWtkb3duIHN1bW1hcnkgb2YgdGhlIHNlY3Rpb24sIGdyb3VwZWQgYnkgdGhlIHVzZXIncyBtb2R1bGUvY291cnNlXHJcbiAgICAgICAgICAgIE9iamVjdC5lbnRyaWVzKHEuc3VtbWFyeUJ5SW5zdGFuY2UpLmZvckVhY2goKFtpbnN0YW5jZU5hbWUsIGluc3RhbmNlXSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKCFjLnN1bW1hcnlCeUluc3RhbmNlW2luc3RhbmNlTmFtZV0pIHtcclxuICAgICAgICAgICAgICAgICAgICBjLnN1bW1hcnlCeUluc3RhbmNlW2luc3RhbmNlTmFtZV0gPSB7IGNvdW50OiAwLCBhdmc6IDAsIGluc3RhbmNlVHlwZTogaW5zdGFuY2UuaW5zdGFuY2VUeXBlIH07XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgYy5zdW1tYXJ5QnlJbnN0YW5jZVtpbnN0YW5jZU5hbWVdLmNvdW50ICs9IGluc3RhbmNlLmNvdW50O1xyXG4gICAgICAgICAgICAgICAgYy5zdW1tYXJ5QnlJbnN0YW5jZVtpbnN0YW5jZU5hbWVdLmF2ZyArPSBpbnN0YW5jZS5hdmc7XHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgaWYgKHEuc3VtbWFyaXplKSB7XHJcbiAgICAgICAgICAgICAgICBjLmV4Y2xDb3VudCArPSBxLmNvdW50O1xyXG4gICAgICAgICAgICAgICAgYy5leGNsQXZnICs9IHEubWVhbiAqIHEuY291bnQ7XHJcblxyXG4gICAgICAgICAgICAgICAgLy8gQnJlYWtkb3duIHN1bW1hcnkgb2YgdGhlIHNlY3Rpb24sIGdyb3VwZWQgYnkgdGhlIHVzZXIncyBtb2R1bGUvY291cnNlXHJcbiAgICAgICAgICAgICAgICBPYmplY3QuZW50cmllcyhxLnN1bW1hcnlCeUluc3RhbmNlKS5mb3JFYWNoKChbaW5zdGFuY2VOYW1lLCBpbnN0YW5jZV0pID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoIWMuZXhjbFN1bW1hcnlCeUluc3RhbmNlW2luc3RhbmNlTmFtZV0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYy5leGNsU3VtbWFyeUJ5SW5zdGFuY2VbaW5zdGFuY2VOYW1lXSA9IHsgY291bnQ6IDAsIGF2ZzogMCwgaW5zdGFuY2VUeXBlOiBpbnN0YW5jZS5pbnN0YW5jZVR5cGUgfTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGMuZXhjbFN1bW1hcnlCeUluc3RhbmNlW2luc3RhbmNlTmFtZV0uY291bnQgKz0gaW5zdGFuY2UuY291bnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgYy5leGNsU3VtbWFyeUJ5SW5zdGFuY2VbaW5zdGFuY2VOYW1lXS5hdmcgKz0gaW5zdGFuY2UuYXZnO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHJldHVybiBjO1xyXG4gICAgICAgIH0sIHsgY291bnQ6IDAsIGF2ZzogMCwgcXVlc3Rpb25zQ291bnQ6IDAsIHN1bW1hcnlCeUluc3RhbmNlOiB7fSwgZXhjbENvdW50OiAwLCBleGNsQXZnOiAwLCBleGNsU3VtbWFyeUJ5SW5zdGFuY2U6IHt9IH0pO1xyXG5cclxuICAgIGlmIChncmFkZXMuZXhjbENvdW50ID4gMCkge1xyXG4gICAgICAgIHJlc3VsdC5leGNsQ291bnQgPSBncmFkZXMuZXhjbENvdW50O1xyXG4gICAgICAgIHJlc3VsdC5leGNsTWVhbiA9IE51bWJlcigoZ3JhZGVzLmV4Y2xBdmcgLyBncmFkZXMuZXhjbENvdW50KS50b0ZpeGVkKDIpKTtcclxuICAgICAgICByZXN1bHQuZXhjbFN1bW1hcnlCeUluc3RhbmNlID0gZ3JhZGVzLmV4Y2xTdW1tYXJ5QnlJbnN0YW5jZTtcclxuICAgICAgICBPYmplY3Qua2V5cyhyZXN1bHQuZXhjbFN1bW1hcnlCeUluc3RhbmNlKVxyXG4gICAgICAgICAgICAuZm9yRWFjaChrZXkgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmVzdWx0LmV4Y2xTdW1tYXJ5QnlJbnN0YW5jZVtrZXldLm1lYW4gPSBOdW1iZXIoKHJlc3VsdC5leGNsU3VtbWFyeUJ5SW5zdGFuY2Vba2V5XS5hdmcgLyByZXN1bHQuZXhjbFN1bW1hcnlCeUluc3RhbmNlW2tleV0uY291bnQpLnRvRml4ZWQoMikpO1xyXG4gICAgICAgICAgICAgICAgcmVzdWx0LmV4Y2xTdW1tYXJ5QnlJbnN0YW5jZVtrZXldLmF2ZyA9IHJlc3VsdC5leGNsU3VtbWFyeUJ5SW5zdGFuY2Vba2V5XS5hdmcgLyBncmFkZXMucXVlc3Rpb25zQ291bnQ7XHJcbiAgICAgICAgICAgICAgICByZXN1bHQuZXhjbFN1bW1hcnlCeUluc3RhbmNlW2tleV0uY291bnQgPSByZXN1bHQuZXhjbFN1bW1hcnlCeUluc3RhbmNlW2tleV0uY291bnQgLyBncmFkZXMucXVlc3Rpb25zQ291bnQ7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgaWYgKGdyYWRlcy5jb3VudCA+IDApIHtcclxuICAgICAgICByZXN1bHQuY291bnQgPSBncmFkZXMuY291bnQ7XHJcbiAgICAgICAgcmVzdWx0Lm1lYW4gPSBOdW1iZXIoKGdyYWRlcy5hdmcgLyBncmFkZXMuY291bnQpLnRvRml4ZWQoMikpO1xyXG4gICAgICAgIHJlc3VsdC5zdW1tYXJ5QnlJbnN0YW5jZSA9IGdyYWRlcy5zdW1tYXJ5QnlJbnN0YW5jZTtcclxuICAgICAgICBPYmplY3Qua2V5cyhyZXN1bHQuc3VtbWFyeUJ5SW5zdGFuY2UpXHJcbiAgICAgICAgICAgIC5mb3JFYWNoKGtleSA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXN1bHQuc3VtbWFyeUJ5SW5zdGFuY2Vba2V5XS5tZWFuID0gTnVtYmVyKChyZXN1bHQuc3VtbWFyeUJ5SW5zdGFuY2Vba2V5XS5hdmcgLyByZXN1bHQuc3VtbWFyeUJ5SW5zdGFuY2Vba2V5XS5jb3VudCkudG9GaXhlZCgyKSk7XHJcbiAgICAgICAgICAgICAgICByZXN1bHQuc3VtbWFyeUJ5SW5zdGFuY2Vba2V5XS5hdmcgPSByZXN1bHQuc3VtbWFyeUJ5SW5zdGFuY2Vba2V5XS5hdmcgLyBncmFkZXMucXVlc3Rpb25zQ291bnQ7XHJcbiAgICAgICAgICAgICAgICByZXN1bHQuc3VtbWFyeUJ5SW5zdGFuY2Vba2V5XS5jb3VudCA9IHJlc3VsdC5zdW1tYXJ5QnlJbnN0YW5jZVtrZXldLmNvdW50IC8gZ3JhZGVzLnF1ZXN0aW9uc0NvdW50O1xyXG4gICAgICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gcmVzdWx0O1xyXG59XHJcblxyXG5mdW5jdGlvbiBzdW1tYXJpemVRdWVzdGlvbldpdGhNb2R1bGVCcmVha2Rvd24oW3F1ZXN0aW9uTmFtZSwgaW5zdGFuY2VzXSkge1xyXG4gICAgY29uc3QgcmVzdWx0ID0ge1xyXG4gICAgICAgIG5hbWU6IHF1ZXN0aW9uTmFtZSxcclxuICAgICAgICBzdW1tYXJpemU6IHN1bW1hcml6YWJsZVtnZXRTdWJzaXRlKCldLnF1ZXN0aW9ucy5oYXMocXVlc3Rpb25OYW1lKSxcclxuICAgICAgICBhbnN3ZXJzOiBuZXcgTWFwKClcclxuICAgIH07XHJcblxyXG4gICAgcmVzdWx0Lmluc3RhbmNlcyA9IE9iamVjdC5lbnRyaWVzKGluc3RhbmNlcykubWFwKHN1bW1hcml6ZUluc3RhbmNlKTtcclxuXHJcbiAgICBjb25zdCBncmFkZXMgPSByZXN1bHQuaW5zdGFuY2VzXHJcbiAgICAgICAgLmZpbHRlcihpID0+IGkudHlwZSA9PSAnc2NhbGUnIHx8IGkudHlwZSA9PSAnY2hvaWNlJylcclxuICAgICAgICAucmVkdWNlKChjLCBpKSA9PiB7XHJcbiAgICAgICAgICAgIC8vVG90YWwgc3VtbWFyeSBmb3IgcXVlc3Rpb25cclxuICAgICAgICAgICAgYy5jb3VudCArPSBpLmNvdW50O1xyXG4gICAgICAgICAgICBjLmF2ZyArPSBpLm1lYW4gKiBpLmNvdW50O1xyXG5cclxuICAgICAgICAgICAgLy8gQnJlYWtkb3duIHN1bW1hcnkgb2YgdGhlIHF1ZXN0aW9uLCBncm91cGVkIGJ5IHRoZSB1c2VyJ3MgbW9kdWxlL2NvdXJzZVxyXG4gICAgICAgICAgICBpZiAoIWMuc3VtbWFyeUJ5SW5zdGFuY2VbaS5uYW1lXSkge1xyXG4gICAgICAgICAgICAgICAgYy5zdW1tYXJ5QnlJbnN0YW5jZVtpLm5hbWVdID0geyBjb3VudDogMCwgYXZnOiAwLCBpbnN0YW5jZVR5cGU6IGkuaW5zdGFuY2VUeXBlIH07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYy5zdW1tYXJ5QnlJbnN0YW5jZVtpLm5hbWVdLmNvdW50ICs9IGkuY291bnQ7XHJcbiAgICAgICAgICAgIGMuc3VtbWFyeUJ5SW5zdGFuY2VbaS5uYW1lXS5hdmcgKz0gaS5tZWFuICogaS5jb3VudDtcclxuXHJcbiAgICAgICAgICAgIC8vIGFnZ3JlZ2F0ZSBhbGwgaW5zdGFuY2UgYW5zd2VycyBpbnRvIHF1ZXN0aW9uIGFuc3dlcnNcclxuICAgICAgICAgICAgaS5hbnN3ZXJzLmZvckVhY2goYSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAocmVzdWx0LmFuc3dlcnMuaGFzKGEubmFtZSkpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgY3VycmVudEFuc3dlciA9IHJlc3VsdC5hbnN3ZXJzLmdldChhLm5hbWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbnRBbnN3ZXIuY291bnQgKz0gYS5jb3VudDtcclxuICAgICAgICAgICAgICAgICAgICBjdXJyZW50QW5zd2VyLmZyYWN0aW9uID0gdW5kZWZpbmVkO1xyXG4gICAgICAgICAgICAgICAgICAgIHJlc3VsdC5hbnN3ZXJzLnNldChhLm5hbWUsIGN1cnJlbnRBbnN3ZXIpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICByZXN1bHQuYW5zd2Vycy5zZXQoYS5uYW1lLCBPYmplY3QuYXNzaWduKHt9LCBhKSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pXHJcblxyXG4gICAgICAgICAgICByZXR1cm4gYztcclxuICAgICAgICB9LCB7IGNvdW50OiAwLCBhdmc6IDAsIHN1bW1hcnlCeUluc3RhbmNlOiB7fSB9KTtcclxuXHJcbiAgICAvLyBSZWNhbGN1bGF0ZSBmcmFjdGlvbnMgZm9yIGVhY2ggYW5zd2VyXHJcbiAgICByZXN1bHQuYW5zd2VycyA9IFsuLi5yZXN1bHQuYW5zd2Vycy52YWx1ZXMoKV07XHJcbiAgICBsZXQgdG90YWxBbnN3ZXJzQ291bnQgPSByZXN1bHQuYW5zd2Vycy5yZWR1Y2UoKGEsIGMpID0+IGEgKyBjLmNvdW50LCAwKTtcclxuICAgIHJlc3VsdC5hbnN3ZXJzLmZvckVhY2goYSA9PiBhLmZyYWN0aW9uID0gTWF0aC5yb3VuZChhLmNvdW50IC8gdG90YWxBbnN3ZXJzQ291bnQgKiAxMDApKTtcclxuXHJcbiAgICByZXN1bHQudHlwZSA9IHJlc3VsdC5pbnN0YW5jZXNbMF0udHlwZTtcclxuXHJcbiAgICBpZiAocmVzdWx0LnR5cGUgPT0gJ3NjYWxlJyAmJiBncmFkZXMuY291bnQgPiAwKSB7XHJcbiAgICAgICAgcmVzdWx0LmNvdW50ID0gZ3JhZGVzLmNvdW50O1xyXG4gICAgICAgIHJlc3VsdC5tZWFuID0gTnVtYmVyKChncmFkZXMuYXZnIC8gZ3JhZGVzLmNvdW50KS50b0ZpeGVkKDIpKTtcclxuICAgICAgICByZXN1bHQuc3VtbWFyeUJ5SW5zdGFuY2UgPSBncmFkZXMuc3VtbWFyeUJ5SW5zdGFuY2U7XHJcbiAgICAgICAgT2JqZWN0LmtleXMocmVzdWx0LnN1bW1hcnlCeUluc3RhbmNlKVxyXG4gICAgICAgICAgICAuZm9yRWFjaChrZXkgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmVzdWx0LnN1bW1hcnlCeUluc3RhbmNlW2tleV0ubWVhbiA9IE51bWJlcigocmVzdWx0LnN1bW1hcnlCeUluc3RhbmNlW2tleV0uYXZnIC8gcmVzdWx0LnN1bW1hcnlCeUluc3RhbmNlW2tleV0uY291bnQpLnRvRml4ZWQoMikpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAvLyByZXN1bHQudHlwZSA9ICdzY2FsZSc7XHJcbiAgICB9IGVsc2UgaWYgKHJlc3VsdC50eXBlID09PSAnZnJlZScpIHtcclxuICAgICAgICByZXN1bHQuYW5zd2VycyA9IHJlc3VsdC5pbnN0YW5jZXMuZmlsdGVyKGkgPT4gaS50eXBlID09IHJlc3VsdC50eXBlKS5mbGF0TWFwKGkgPT4gaS5hbnN3ZXJzKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gcmVzdWx0O1xyXG59XHJcblxyXG5mdW5jdGlvbiBzdW1tYXJpemVJbnN0YW5jZShbaW5zdGFuY2VOYW1lLCBpbnN0YW5jZV0pIHtcclxuICAgIGNvbnN0IHJlc3VsdCA9IHtcclxuICAgICAgICBuYW1lOiBpbnN0YW5jZU5hbWUsXHJcbiAgICAgICAgYW5zd2VyczogW11cclxuICAgIH07XHJcbiAgICBpZiAoaW5zdGFuY2UuY29tbWVudHMubGVuZ3RoID09IDApIHtcclxuICAgICAgICBzY2FsZVF1ZXN0aW9uKGluc3RhbmNlLCByZXN1bHQpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICByZXN1bHQuYW5zd2VycyA9IGluc3RhbmNlLmNvbW1lbnRzO1xyXG4gICAgICAgIHJlc3VsdC50eXBlID0gJ2ZyZWUnO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiByZXN1bHQ7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBAcGFyYW0ge0FycmF5PFN1bW1hcml6ZWRTZWN0aW9uPn0gc3VtbWFyeSBcclxuICovXHJcbmZ1bmN0aW9uIGNyZWF0ZUluZGV4V2l0aE1vZHVsZUJyZWFrZG93bihzdW1tYXJ5KSB7XHJcbiAgICBmb3IgKGNvbnN0IHNlY3Rpb24gb2Ygc3VtbWFyeSkge1xyXG4gICAgICAgIGZvciAoY29uc3QgcXVlc3Rpb24gb2Ygc2VjdGlvbi5xdWVzdGlvbnMpIHtcclxuICAgICAgICAgICAgZm9yIChjb25zdCBpbnN0YW5jZSBvZiBxdWVzdGlvbi5pbnN0YW5jZXMuZmlsdGVyKHEgPT4gcS50eXBlID09ICdmcmVlJyB8fCBxLnR5cGUgPT0gJ2Nob2ljZScpKSB7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGFuc3dlciBvZiBpbnN0YW5jZS5hbnN3ZXJzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYW5zd2VyLnJlbGF0ZWQgPSBzdW1tYXJ5Lm1hcChzID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IHMubmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25zOiBzLnF1ZXN0aW9ucy5tYXAocSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogcS5uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogcS50eXBlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmVlZGJhY2s6IHEuaW5zdGFuY2VzPy5maW5kKHggPT4geC5uYW1lID09PSBpbnN0YW5jZS5uYW1lKT8uaW5kZXg/LlthbnN3ZXIuaW5kZXhdXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfHwgcS5pbnN0YW5jZXM/LmZpbmQoeCA9PiB4Lm5hbWUgPT09IGluc3RhbmNlLm5hbWUpPy5hbnN3ZXJzLmZpbHRlcihhID0+IGEuaW5kZXggPT0gYW5zd2VyLmluZGV4KVswXT8udGV4dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KSlcclxuICAgICAgICAgICAgICAgICAgICB9KSkuZmlsdGVyKHMgPT4gcy5xdWVzdGlvbnMubGVuZ3RoID4gMCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbi8vU2hhcmVkIG1ldGhvZHNcclxuZnVuY3Rpb24gc2NhbGVRdWVzdGlvbihxdWVzdGlvbiwgb3V0cHV0KSB7XHJcbiAgICBjb25zdCBxdWVzdGlvbkluZGV4ID0ge307XHJcbiAgICBvdXRwdXQuY291bnQgPSBxdWVzdGlvbi5jaG9pY2VzLmxlbmd0aDtcclxuICAgIGNvbnN0IGNob2ljZUdyb3VwcyA9IE9iamVjdC5lbnRyaWVzKHF1ZXN0aW9uLmNob2ljZXNcclxuICAgICAgICAucmVkdWNlKChhY2MsIHsgaW5kZXgsIGNob2ljZSB9KSA9PiB7XHJcbiAgICAgICAgICAgIGFjY1tjaG9pY2VdID0gKGFjY1tjaG9pY2VdIHx8IDApICsgMTtcclxuICAgICAgICAgICAgbGV0IHZhbCA9IHBhcnNlSW50KGNob2ljZSk7XHJcbiAgICAgICAgICAgIGlmIChOdW1iZXIuaXNOYU4odmFsKSkge1xyXG4gICAgICAgICAgICAgICAgdmFsID0gY2hvaWNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHF1ZXN0aW9uSW5kZXhbaW5kZXhdID0gdmFsO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuIGFjYztcclxuICAgICAgICB9LCB7fSkpXHJcbiAgICAgICAgLm1hcCgoW2Nob2ljZSwgY291bnRdKSA9PiAoe1xyXG4gICAgICAgICAgICBuYW1lOiBjaG9pY2UsXHJcbiAgICAgICAgICAgIHZhbHVlOiBwYXJzZUludChjaG9pY2UpLFxyXG4gICAgICAgICAgICBjb3VudCxcclxuICAgICAgICAgICAgZnJhY3Rpb246IE1hdGgucm91bmQoY291bnQgLyBvdXRwdXQuY291bnQgKiAxMDApLFxyXG4gICAgICAgICAgICBvcmlnaW5hbFZhbHVlOiBjaG9pY2VcclxuICAgICAgICB9KSk7XHJcblxyXG4gICAgaWYgKChjaG9pY2VHcm91cHMuZmlsdGVyKGMgPT4gTnVtYmVyLmlzTmFOKGMudmFsdWUpID09IGZhbHNlKS5sZW5ndGggKiAyKSA+PSBjaG9pY2VHcm91cHMubGVuZ3RoKSB7XHJcbiAgICAgICAgY2hvaWNlR3JvdXBzLnNvcnQoKGEsIGIpID0+IE51bWJlci5pc05hTihhLnZhbHVlKSA/IDEgOiBiLnZhbHVlIC0gYS52YWx1ZSk7XHJcbiAgICAgICAgY29uc3QgbnVtZXJpY0Nob2ljZXMgPSBjaG9pY2VHcm91cHMuZmlsdGVyKGMgPT4gTnVtYmVyLmlzTmFOKGMudmFsdWUpID09IGZhbHNlKTtcclxuICAgICAgICBjb25zdCBudW1lcmljQ291bnQgPSBudW1lcmljQ2hvaWNlcy5yZWR1Y2UoKGFjYywgYykgPT4gYWNjICsgYy5jb3VudCwgMCk7XHJcbiAgICAgICAgb3V0cHV0Lm1lYW4gPSBOdW1iZXIoKG51bWVyaWNDaG9pY2VzLnJlZHVjZSgoYWNjLCBjKSA9PiBhY2MgKyBjLnZhbHVlICogYy5jb3VudCwgMCkgLyBudW1lcmljQ291bnQpLnRvRml4ZWQoMikpO1xyXG4gICAgICAgIG91dHB1dC50eXBlID0gJ3NjYWxlJztcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgY2hvaWNlR3JvdXBzLnNvcnQoKGEsIGIpID0+IGIuY291bnQgLSBhLmNvdW50KTtcclxuICAgICAgICBjaG9pY2VHcm91cHMuZm9yRWFjaCh4ID0+IHgudmFsdWUgPSBOdW1iZXIuaXNOYU4oeC52YWx1ZSkgPyB4Lm9yaWdpbmFsVmFsdWUgOiB4LnZhbHVlKVxyXG4gICAgICAgIG91dHB1dC50eXBlID0gJ2Nob2ljZSc7XHJcbiAgICB9XHJcblxyXG4gICAgb3V0cHV0LmluZGV4ID0gcXVlc3Rpb25JbmRleDtcclxuICAgIG91dHB1dC5hbnN3ZXJzID0gY2hvaWNlR3JvdXBzO1xyXG4gICAgaWYgKHF1ZXN0aW9uLmluc3RhbmNlVHlwZSkge1xyXG4gICAgICAgIG91dHB1dC5pbnN0YW5jZVR5cGUgPSBxdWVzdGlvbi5pbnN0YW5jZVR5cGU7XHJcbiAgICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGdldE9yQ3JlYXRlKGNvbGxlY3Rpb24sIGtleSwgaW5pdGlhbCA9IHt9KSB7XHJcbiAgICBpZiAoIWNvbGxlY3Rpb25ba2V5XSkge1xyXG4gICAgICAgIGNvbGxlY3Rpb25ba2V5XSA9IGluaXRpYWw7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gY29sbGVjdGlvbltrZXldO1xyXG59XHJcblxyXG5mdW5jdGlvbiBzZWN0aW9uVG9UZW1wbGF0ZShzZWN0aW9uLCBzZWN0aW9uRGF0YSkge1xyXG4gICAgc2VjdGlvbi5UZW1wbGF0ZUlkID0gKHNlY3Rpb25EYXRhLmZpbmQocyA9PiBzLk5hbWUgPT0gc2VjdGlvbi5uYW1lKSB8fCB7IFN1cnZleVNlY3Rpb25UZW1wbGF0ZUlkOiB1bmRlZmluZWQgfSkuU3VydmV5U2VjdGlvblRlbXBsYXRlSWQ7XHJcbiAgICBzZWN0aW9uLnN1bW1hcml6ZSA9IHN1bW1hcml6YWJsZVtnZXRTdWJzaXRlKCldLnRlbXBsYXRlcy5oYXMoc2VjdGlvbi5UZW1wbGF0ZUlkKTtcclxuICAgIHNlY3Rpb24ubGVjdHVyZXIgPSBzdW1tYXJpemFibGVbZ2V0U3Vic2l0ZSgpXS5sZWN0dXJlci5oYXMoc2VjdGlvbi5UZW1wbGF0ZUlkKTtcclxuXHJcbiAgICByZXR1cm4gc2VjdGlvbjtcclxufVxyXG5cclxuLyoqXHJcbiAqIEB0eXBlZGVmIHtPYmplY3R9IFN1bW1hcml6ZWRTZWN0aW9uXHJcbiAqIEBwcm9wZXJ0eSB7bnVtYmVyfSBUZW1wbGF0ZUlkXHJcbiAqIEBwcm9wZXJ0eSB7c3RyaW5nfSBuYW1lXHJcbiAqIEBwcm9wZXJ0eSB7bnVtYmVyfSBjb3VudFxyXG4gKiBAcHJvcGVydHkge251bWJlcn0gbWVhblxyXG4gKiBAcHJvcGVydHkge2Jvb2xlYW59IGxlY3R1cmVyXHJcbiAqIEBwcm9wZXJ0eSB7Ym9vbGVhbn0gc3VtbWFyaXplXHJcbiAqIEBwcm9wZXJ0eSB7QXJyYXk8U3VtbWFyaXplZFF1ZXN0aW9uPn0gcXVlc3Rpb25zXHJcbiAqL1xyXG5cclxuLyoqXHJcbiAqIEB0eXBlZGVmIHtPYmplY3R9IFN1bW1hcml6ZWRRdWVzdGlvblxyXG4gKiBAcHJvcGVydHkge3N0cmluZ30gbmFtZVxyXG4gKiBAcHJvcGVydHkge3N0cmluZ30gdHlwZVxyXG4gKiBAcHJvcGVydHkge251bWJlcn0gY291bnRcclxuICogQHByb3BlcnR5IHtudW1iZXJ9IG1lYW5cclxuICogQHByb3BlcnR5IHtib29sZWFufSBzdW1tYXJpemVcclxuICogQHByb3BlcnR5IHtPYmplY3QuPHN0cmluZywgc3RyaW5nPj99IGluZGV4XHJcbiAqIEBwcm9wZXJ0eSB7QXJyYXk8U2NhbGVBbnN3ZXJ8RnJlZUFuc3dlcj59IGFuc3dlcnNcclxuICovXHJcblxyXG4vKipcclxuICogQHR5cGVkZWYge09iamVjdH0gU2NhbGVBbnN3ZXJcclxuICogQHByb3BlcnR5IHtzdHJpbmd9IG5hbWVcclxuICogQHByb3BlcnR5IHtudW1iZXJ9IHZhbHVlXHJcbiAqIEBwcm9wZXJ0eSB7bnVtYmVyfSBjb3VudFxyXG4gKiBAcHJvcGVydHkge251bWJlcn0gZnJhY3Rpb25cclxuICovXHJcblxyXG4vKipcclxuICogQHR5cGVkZWYge09iamVjdH0gRnJlZUFuc3dlclxyXG4gKiBAcHJvcGVydHkge3N0cmluZ30gaW5kZXhcclxuICogQHByb3BlcnR5IHtzdHJpbmd9IHRleHRcclxuICogQHByb3BlcnR5IHtBcnJheTx7bmFtZTogc3RyaW5nLCBxdWVzdGlvbnM6IEFycmF5PFJlbGF0ZWRNb2RlbD59Pj99IHJlbGF0ZWRcclxuICovXHJcblxyXG4vKipcclxuICogQHR5cGVkZWYge09iamVjdH0gUmVsYXRlZE1vZGVsXHJcbiAqIEBwcm9wZXJ0eSB7c3RyaW5nfSBuYW1lXHJcbiAqIEBwcm9wZXJ0eSB7c3RyaW5nfSB0eXBlXHJcbiAqIEBwcm9wZXJ0eSB7c3RyaW5nfSBmZWVkYmFja1xyXG4gKi9cclxuXHJcbmV4cG9ydCBkZWZhdWx0IHtcclxuICAgIHN1bW1hcml6ZVxyXG59O1xyXG4iLCIvLy8gPHJlZmVyZW5jZSBwYXRoPVwiLi9hcGkuZC50c1wiIC8+XHJcblxyXG5pbXBvcnQgeyB1dWlkIH0gZnJvbSAnLi9wYXJzZSc7XHJcbmltcG9ydCBiaW5kU2l0ZUFwaSBmcm9tICcuLi9hcGkvYXBpLWluZGV4JztcclxuaW1wb3J0IEFXTiBmcm9tICcuLi8uLi9ub2RlX21vZHVsZXMvYXdlc29tZS1ub3RpZmljYXRpb25zL3NyYy9pbmRleC5qcyc7XHJcblxyXG5jb25zdCBkaXNwYXRjaGVyID0ge307XHJcblxyXG5sZXQgYmdQb3J0O1xyXG5zdGFydFNlc0FwaVBvcnQoKTtcclxuXHJcbmZ1bmN0aW9uIHN0YXJ0U2VzQXBpUG9ydCgpIHtcclxuICAgIGJnUG9ydCA9IGJyb3dzZXIucnVudGltZS5jb25uZWN0KHsgbmFtZTogJ3Nlcy1hcGktcG9ydCcgfSk7XHJcbiAgICBiZ1BvcnQub25NZXNzYWdlLmFkZExpc3RlbmVyKG9uTWVzc2FnZSk7XHJcbiAgICBiZ1BvcnQub25EaXNjb25uZWN0LmFkZExpc3RlbmVyKCgpID0+IHtcclxuICAgICAgICBzdGFydFNlc0FwaVBvcnQoKTtcclxuICAgIH0pO1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXREYXRhKHR5cGUsIHBhcmFtcykge1xyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICBjb25zdCBfdXVpZCA9IHV1aWQoKTtcclxuICAgICAgICBiZ1BvcnQucG9zdE1lc3NhZ2Uoe1xyXG4gICAgICAgICAgICBfdXVpZCxcclxuICAgICAgICAgICAgYXBwTmFtZTogaW50ZXJvcEFwcE5hbWUoKSxcclxuICAgICAgICAgICAgdHlwZSxcclxuICAgICAgICAgICAgcGFyYW1zXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGRpc3BhdGNoZXJbX3V1aWRdID0geyByZXNvbHZlLCByZWplY3QsIHR5cGUgfTtcclxuICAgIH0pO1xyXG59XHJcblxyXG5mdW5jdGlvbiBvbk1lc3NhZ2UobSkge1xyXG4gICAgY29uc3QgdXVpZCA9IG0uX3V1aWQ7XHJcbiAgICBpZiAobS5fcmVqZWN0ZWQpIHtcclxuICAgICAgICBjb25zb2xlLmluZm8oJ09wZXJhdGlvbiByZWplY3Q6JywgZGlzcGF0Y2hlclt1dWlkXS50eXBlKTtcclxuICAgICAgICBjb25zdCBlcnJvciA9IG5ldyBFcnJvcihtLl9lcnJvcik7XHJcbiAgICAgICAgbGV0IG5vdGlmaWVyID0gbmV3IEFXTigpO1xyXG4gICAgICAgIG5vdGlmaWVyLmFsZXJ0KGAke20uX2Vycm9yfWAsIHtkdXJhdGlvbnM6IHthbGVydDogMTAwMDB9fSk7XHJcbiAgICAgICAgLy9tYXliZSB1cGRhdGUgdG8gc2hvdyBvbmx5IGluIGRlYnVnIG1vZGUsIHByb3ZpZGluZyBtb3JlIGRldGFpbGVkIGVycm9yIGluZm9ybWF0aW9uIHVzaW5nIHRoZSBfbWV0YSBwcm9wZXJ0eVxyXG4gICAgICAgIGNvbnNvbGUuZGlyKGVycm9yKTtcclxuXHJcbiAgICAgICAgZXJyb3IuX21ldGEgPSBtLl9tZXRhO1xyXG4gICAgICAgIGRpc3BhdGNoZXJbdXVpZF0ucmVqZWN0KGVycm9yKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgZGlzcGF0Y2hlclt1dWlkXS5yZXNvbHZlKG0uZGF0YSk7XHJcbiAgICB9XHJcbiAgICBkZWxldGUgZGlzcGF0Y2hlclt1dWlkXTtcclxufVxyXG5cclxuZnVuY3Rpb24gaW50ZXJvcEFwcE5hbWUoKSB7XHJcbiAgICBzd2l0Y2ggKHdpbmRvdy5sb2NhdGlvbi5ob3N0LnNsaWNlKDAsIDcpKSB7XHJcbiAgICAgICAgY2FzZSAnZGlnaXRhbCc6XHJcbiAgICAgICAgICAgIHJldHVybiAnZGlnaXRhbCc7XHJcbiAgICAgICAgY2FzZSAnY3JlYXRpdic6XHJcbiAgICAgICAgICAgIHJldHVybiAnY3JlYXRpdmUnO1xyXG4gICAgICAgIGNhc2UgJ2FpLnNvZnQnOlxyXG4gICAgICAgICAgICByZXR1cm4gJ2FpJztcclxuICAgICAgICBjYXNlICdmaW5hbmNlJzpcclxuICAgICAgICAgICAgcmV0dXJuICdmaW5hbmNlYWNhZGVteSc7XHJcbiAgICAgICAgY2FzZSAnZGV2LmRpZyc6XHJcbiAgICAgICAgICAgIHJldHVybiAnZGV2ZGlnaXRhbCc7XHJcbiAgICAgICAgY2FzZSAnZGV2LnNvZic6XHJcbiAgICAgICAgICAgIHJldHVybiAnZGV2c29mdHVuaSc7XHJcbiAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgcmV0dXJuICdwcm9ncmFtbWluZyc7XHJcbiAgICB9XHJcbn1cclxuXHJcbi8qKiBAdHlwZSB7U1VBUEl9ICovXHJcbmNvbnN0IGFjdGlvbnMgPSBiaW5kU2l0ZUFwaShudWxsKVxyXG4gICAgLm1hcChhID0+ICh7XHJcbiAgICAgICAgbmFtZTogYSxcclxuICAgICAgICBmdW5jOiAoLi4ucGFyYW1zKSA9PiBnZXREYXRhKGEsIHBhcmFtcylcclxuICAgIH0pKVxyXG4gICAgLnJlZHVjZSgocCwgYykgPT4ge1xyXG4gICAgICAgIHBbYy5uYW1lXSA9IGMuZnVuYztcclxuICAgICAgICByZXR1cm4gcDtcclxuICAgIH0sIHt9KTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGFjdGlvbnM7XHJcbiIsImltcG9ydCBhcGlDb25uZWN0IGZyb20gJy4vYXBpLWNvbm5lY3QnO1xyXG5cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgQ29tbW9uIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QmxvZ0J5VXJsKGJsb2dVcmwpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEJsb2dCeVVybChibG9nVXJsKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEhhbGxzKCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0SGFsbHMoKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUhhbGwoaGFsbCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QudXBkYXRlSGFsbChoYWxsKTtcclxufVxyXG5cclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcbi8vICMjIyBNb2R1bGUgRGF0YVxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNb2R1bGVzSW5Qcm9mZXNzaW9uKHByb2Zlc3Npb25JZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0TW9kdWxlc0luUHJvZmVzc2lvbihwcm9mZXNzaW9uSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TW9kdWxlcygpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldE1vZHVsZXMoKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEluc3RhbmNlc0luTW9kdWxlKG1vZHVsZUlkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRJbnN0YW5jZXNJbk1vZHVsZShtb2R1bGVJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZWFyY2hNb2R1bGVzKHF1ZXJ5KSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5zZWFyY2hNb2R1bGVzKHF1ZXJ5KTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEluc3RhbmNlSW5Nb2R1bGUobW9kdWxlSWQsIG1vZHVsZUluc3RhbmNlSWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEluc3RhbmNlSW5Nb2R1bGUobW9kdWxlSWQsIG1vZHVsZUluc3RhbmNlSWQpO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIFBheW1lbnRzIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UGF5bWVudHNGb3JQYWNrYWdlKHBhY2thZ2VOYW1lKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRQYXltZW50c0ZvclBhY2thZ2UocGFja2FnZU5hbWUpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UGFja2FnZXNGb3JQcm9kdWN0KHByb2R1Y3RJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0UGFja2FnZXNGb3JQcm9kdWN0KHByb2R1Y3RJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRQcm9kdWN0c0Zvck1vZHVsZShtb2R1bGVJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0UHJvZHVjdHNGb3JNb2R1bGUobW9kdWxlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UHJvZHVjdHNGb3JDb3Vyc2UoaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0UHJvZHVjdHNGb3JDb3Vyc2UoaW5zdGFuY2VJZCk7XHJcbn1cclxuXHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIFBheW1lbnRzIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q29udGVzdENvbXBldGVSZXN1bHRzKGNvbnRlc3RJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0Q29udGVzdENvbXBldGVSZXN1bHRzKGNvbnRlc3RJZCk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgUXVpeiBEYXRhXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVF1aXpJbnN0YW5jZShwYXlsb2FkKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5jcmVhdGVRdWl6SW5zdGFuY2UocGF5bG9hZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhZGRRdWl6UXVlc3Rpb24ocXVpeklkLCBjb250ZW50KSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5hZGRRdWVzdGlvbihxdWl6SWQsIGNvbnRlbnQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYWRkUXVpelF1ZXN0aW9uQW5zd2VyKHF1ZXN0aW9uSWQsIGFuc3dlciwgaXNDb3JyZWN0KSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5hZGRBbnN3ZXIocXVlc3Rpb25JZCwgYW5zd2VyLCBpc0NvcnJlY3QpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWxsUXVpemVzQnlOYW1lKGNvbnRhaW5pbmdOYW1lLCBwYWdlU2l6ZSwgcGFnZSkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0QWxsUXVpemVzQnlOYW1lKGNvbnRhaW5pbmdOYW1lLCBwYWdlU2l6ZSwgcGFnZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRRdWVzdGlvbnNCeUlkKHF1aXpJZCwgcGFnZVNpemUsIHBhZ2UpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldFF1ZXN0aW9uc0J5SWQocXVpeklkLCBwYWdlU2l6ZSwgcGFnZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBbnN3ZXJzQnlRdWVzdGlvbklkKHF1ZXN0aW9uSWQsIHBhZ2VTaXplLCBwYWdlKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXRBbnN3ZXJzQnlRdWVzdGlvbklkKHF1ZXN0aW9uSWQsIHBhZ2VTaXplLCBwYWdlKTtcclxufVxyXG5cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgU3VydmV5IERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U3VydmV5cyhwYWdlLCBxdWVyeSwgcGFnZVNpemUpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldFN1cnZleXMocGFnZSwgcXVlcnksIHBhZ2VTaXplKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFN1cnZleXNCeU5hbWVBbmRTdGFydEFuZEVuZERhdGUocGFnZSwgbmFtZSwgc3RhcnREYXRlLCBlbmREYXRlLCBwYWdlU2l6ZSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0U3VydmV5c0J5TmFtZUFuZFN0YXJ0QW5kRW5kRGF0ZShwYWdlLCBuYW1lLCBzdGFydERhdGUsIGVuZERhdGUsIHBhZ2VTaXplKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFN1cnZleUJ5SWQoc3VydmV5SWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldFN1cnZleUJ5SWQoc3VydmV5SWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U3VydmV5QW5zd2VycyhzdXJ2ZXlJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0U3VydmV5QW5zd2VycyhzdXJ2ZXlJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTdXJ2ZXlUZW1wbGF0ZXMoKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRTdXJ2ZXlUZW1wbGF0ZXMoKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFN1cnZleVF1ZXN0aW9uc0J5VGVtcGxhdGVJZCh0ZW1wbGF0ZUlkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRTdXJ2ZXlRdWVzdGlvbnNCeVRlbXBsYXRlSWQodGVtcGxhdGVJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTdXJ2ZXlTZWN0aW9uc0J5VGVtcGxhdGVJZCh0ZW1wbGF0ZUlkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRTdXJ2ZXlTZWN0aW9uc0J5VGVtcGxhdGVJZCh0ZW1wbGF0ZUlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFN1cnZleVNlY3Rpb25zQnlJZChzZWN0aW9uSWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldFN1cnZleVNlY3Rpb25zQnlJZChzZWN0aW9uSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmluZFN1cnZleUJ5VHJhaW5pbmcobmFtZUJnKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5maW5kU3VydmV5QnlUcmFpbmluZyhuYW1lQmcpO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIFVzZXIgRGF0YVxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRUcmFpbmluZ3NCeVRyYWluZXIodXNlcklkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRUcmFpbmluZ3NCeVRyYWluZXIodXNlcklkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRyYWluZXJCeUlkKHVzZXJJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0VHJhaW5lckJ5SWQodXNlcklkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVRyYWluaW5nQnlUcmFpbmVyKHRyYWluaW5nKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC51cGRhdGVUcmFpbmluZ0J5VHJhaW5lcih0cmFpbmluZyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVUcmFpbmluZ0J5VHJhaW5lcih0cmFpbmluZykge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuY3JlYXRlVHJhaW5pbmdCeVRyYWluZXIodHJhaW5pbmcpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVzdHJveVRyYWluaW5nT2ZUcmFpbmVyKHRyYWluaW5nKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5kZXN0cm95VHJhaW5pbmdPZlRyYWluZXIodHJhaW5pbmcpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2VhcmNoVXNlcnMocXVlcnksIGV4Y2x1ZGUpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LnNlYXJjaFVzZXJzKHF1ZXJ5LCBleGNsdWRlKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRyYWluZXJzQnlUcmFpbmluZyh0cmFpbmluZ0lkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRUcmFpbmVyc0J5VHJhaW5pbmcodHJhaW5pbmdJZCk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgQ291cnNlIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2VhcmNoQnlOYW1lKGJvZHkpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LnNlYXJjaEJ5TmFtZShib2R5KTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNlYXJjaENvdXJzZXMocXVlcnkpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LnNlYXJjaENvdXJzZXMocXVlcnkpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q291cnNlRGF0YShjb3Vyc2VJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0Q291cnNlRGF0YShjb3Vyc2VJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb3Vyc2VJbnN0YW5jZXMoY291cnNlSWQsIGZpbHRlciA9IHVuZGVmaW5lZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0Q291cnNlSW5zdGFuY2VzKGNvdXJzZUlkLCBmaWx0ZXIgPSB1bmRlZmluZWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SW5zdGFuY2VEYXRhKGluc3RhbmNlSWQsIGNvdXJzZUlkLCB0eXBlKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRJbnN0YW5jZURhdGEoaW5zdGFuY2VJZCwgY291cnNlSWQsIHR5cGUpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlQ291cnNlKGNvdXJzZSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QudXBkYXRlQ291cnNlKGNvdXJzZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGRhdGVJbnN0YW5jZShpbnN0YW5jZSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QudXBkYXRlSW5zdGFuY2UoaW5zdGFuY2UpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U3R1ZGVudHMoaW5zdGFuY2VJZCwgdHlwZSA9ICdtYWluJykge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0U3R1ZGVudHMoaW5zdGFuY2VJZCwgdHlwZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb3Vyc2VFdmVudHMoaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0Q291cnNlRXZlbnRzKGluc3RhbmNlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QW55QnlJZChpbnN0YW5jZUlkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRBbnlCeUlkKGluc3RhbmNlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SW5zdGFuY2VQYWdlKGluc3RhbmNlSWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEluc3RhbmNlUGFnZShpbnN0YW5jZUlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEluc3RhbmNlRnVsbFBhZ2UodXJsKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRJbnN0YW5jZUZ1bGxQYWdlKHVybCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRUcmFpbmVyTmFtZXMoaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0VHJhaW5lck5hbWVzKGluc3RhbmNlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2VhcmNoQ291cnNlSW5zdGFuY2VzQnlDb3Vyc2VOYW1lQW5kSW5zdGFuY2VJZChjb3Vyc2VOYW1lLCBpbnN0YW5jZUlkLCBmaWx0ZXIgPSB1bmRlZmluZWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LnNlYXJjaENvdXJzZUluc3RhbmNlc0J5Q291cnNlTmFtZUFuZEluc3RhbmNlSWQoY291cnNlTmFtZSwgaW5zdGFuY2VJZCwgZmlsdGVyID0gdW5kZWZpbmVkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNlYXJjaFRyYWluaW5nc0J5TmFtZShuYW1lLCBleGFjdCA9IGZhbHNlKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5zZWFyY2hUcmFpbmluZ3NCeU5hbWUobmFtZSwgZXhhY3QpO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIEV4YW0gRGF0YVxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRFeGFtc0J5Q291cnNlKG5hbWVCZywgaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0RXhhbXNCeUNvdXJzZShuYW1lQmcsIGluc3RhbmNlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RXhhbXNCeU5hbWUocXVlcnkpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEV4YW1zQnlOYW1lKHF1ZXJ5KTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEV4YW1Hcm91cHNCeUV4YW1JZChleGFtSWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEV4YW1Hcm91cHNCeUV4YW1JZChleGFtSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RW5yb2xsZWRCeUdyb3VwSWQoZXhhbUdyb3VwSWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEVucm9sbGVkQnlHcm91cElkKGV4YW1Hcm91cElkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZUV4YW0oZXhhbSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuY3JlYXRlRXhhbShleGFtKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUV4YW0oZXhhbSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QudXBkYXRlRXhhbShleGFtKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZUV4YW1Hcm91cChncm91cCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuY3JlYXRlRXhhbUdyb3VwKGdyb3VwKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUV4YW1Hcm91cChncm91cCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QudXBkYXRlRXhhbUdyb3VwKGdyb3VwKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlc3Ryb3lFeGFtR3JvdXAoZ3JvdXApIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmRlc3Ryb3lFeGFtR3JvdXAoZ3JvdXApO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIEV2ZW50IERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RXZlbnRzKGluc3RhbmNlSWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEV2ZW50cyhpbnN0YW5jZUlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUV2ZW50KGV2ZW50KSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC51cGRhdGVFdmVudChldmVudCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVFdmVudChldmVudCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuY3JlYXRlRXZlbnQoZXZlbnQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVzdHJveUV2ZW50KGV2ZW50KSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5kZXN0cm95RXZlbnQoZXZlbnQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RXZlbnRzQnlEYXRlKHN0YXJ0RGF0ZSwgZW5kRGF0ZSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0RXZlbnRzQnlEYXRlKHN0YXJ0RGF0ZSwgZW5kRGF0ZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRFdmVudHNCeUlkKGV2ZW50SWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEV2ZW50c0J5SWQoZXZlbnRJZCk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgR3JvdXAgRGF0YVxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRJbnNhbmNlR3JvdXBzKGluc3RhbmNlSWQpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmdldEluc2FuY2VHcm91cHMoaW5zdGFuY2VJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRHcm91cEJ5SWQoZ3JvdXBJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0R3JvdXBCeUlkKGdyb3VwSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlVHJhaW5pbmdHcm91cChncm91cCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuY3JlYXRlVHJhaW5pbmdHcm91cChncm91cCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXN0cm95R3JvdXAoZ3JvdXApIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmRlc3Ryb3lHcm91cChncm91cCk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgTGVjdHVyZSBEYXRhXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEluc3RhbmNlTGVjdHVyZXMoaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuZ2V0SW5zdGFuY2VMZWN0dXJlcyhpbnN0YW5jZUlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUxlY3R1cmUobGVjdHVyZSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QudXBkYXRlTGVjdHVyZShsZWN0dXJlKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZUxlY3R1cmUobGVjdHVyZSkge1xyXG4gICAgcmV0dXJuIGFwaUNvbm5lY3QuY3JlYXRlTGVjdHVyZShsZWN0dXJlKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlc3Ryb3lMZWN0dXJlKGxlY3R1cmUpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmRlc3Ryb3lMZWN0dXJlKGxlY3R1cmUpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TGVjdHVyZURldGFpbHModHJhaW5pbmdJZCwgbGVjdHVyZUlkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRMZWN0dXJlRGV0YWlscyh0cmFpbmluZ0lkLCBsZWN0dXJlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TGVjdHVyZXNGb3JFeGFtc0J5VHJhaW5pbmdJZCh0cmFpbmluZ0lkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRMZWN0dXJlc0ZvckV4YW1zQnlUcmFpbmluZ0lkKHRyYWluaW5nSWQpO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIFNraWxsIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2tpbGxzQnlJbnN0YW5jZShuYW1lLCBpbnN0YW5jZUlkKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5nZXRTa2lsbHNCeUluc3RhbmNlKG5hbWUsIGluc3RhbmNlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlU2tpbGwoc2tpbGwpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LnVwZGF0ZVNraWxsKHNraWxsKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVNraWxsKHNraWxsKSB7XHJcbiAgICByZXR1cm4gYXBpQ29ubmVjdC5jcmVhdGVTa2lsbChza2lsbCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXN0cm95U2tpbGwoc2tpbGwpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LmRlc3Ryb3lTa2lsbChza2lsbCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZWFyY2hTa2lsbHMocXVlcnksIHR5cGUpIHtcclxuICAgIHJldHVybiBhcGlDb25uZWN0LnNlYXJjaFNraWxscyhxdWVyeSwgdHlwZSk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgU3RyZWFtIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SW5zdGFuY2VDb25maWcoaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0SW5zdGFuY2VDb25maWcoaW5zdGFuY2VJZCk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgQ1BFIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QXBwbGljYXRpb25zQnlJbnN0YW5jZUlkKGluc3RhbmNlSWQpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldEFwcGxpY2F0aW9uc0J5SW5zdGFuY2VJZChpbnN0YW5jZUlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFwcGxpY2F0aW9ucyhxdWVyeSwgcGFnZSkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0QXBwbGljYXRpb25zKHF1ZXJ5LCBwYWdlKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFwcFppcChpZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0QXBwWmlwKGlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFwcFN0YXR1cyhpZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0QXBwU3RhdHVzKGlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFwcFN0YXR1c0J5SW5zdGFuY2VJZChpZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0QXBwU3RhdHVzQnlJbnN0YW5jZUlkKGlkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVN0YXR1cyhzdGF0dXMpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmNyZWF0ZVN0YXR1cyhzdGF0dXMpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlU3RhdHVzKHN0YXR1cykge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QudXBkYXRlU3RhdHVzKHN0YXR1cyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXN0cm95U3RhdHVzKHN0YXR1cykge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZGVzdHJveVN0YXR1cyhzdGF0dXMpO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIE5BVkVUIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRDdXJyZW50Q291cnNlcygpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldE5hdmV0Q3VycmVudENvdXJzZXMoKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE5hdmV0Q2xvc2VkQ291cnNlcygpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldE5hdmV0Q2xvc2VkQ291cnNlcygpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRBcmNoaXZlZENvdXJzZXMoKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXROYXZldEFyY2hpdmVkQ291cnNlcygpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRDb3Vyc2VJbmZvKGlkLCB0eXBlKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXROYXZldENvdXJzZUluZm8oaWQsIHR5cGUpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRTdHVkZW50cyhpZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0TmF2ZXRTdHVkZW50cyhpZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXROYXZldFN0dWRlbnRJbmZvKGNsaWVudElkKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXROYXZldFN0dWRlbnRJbmZvKGNsaWVudElkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE5hdmV0RXhpc3RpbmdGaWxlcyhjb3Vyc2VJZCwgaWQpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldE5hdmV0RXhpc3RpbmdGaWxlcyhjb3Vyc2VJZCwgaWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBsb2FkTWVkaWNhbChjb3Vyc2VJZCwgaWQsIGZpbGVEZXNjcmlwdG9yKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC51cGxvYWRNZWRpY2FsKGNvdXJzZUlkLCBpZCwgZmlsZURlc2NyaXB0b3IpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBsb2FkRGlwbG9tYShjb3Vyc2VJZCwgaWQsIGZpbGVEZXNjcmlwdG9yLCByZWdfbm8sIHBybl9ubywgZG9jX2RhdGUpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LnVwbG9hZERpcGxvbWEoY291cnNlSWQsIGlkLCBmaWxlRGVzY3JpcHRvciwgcmVnX25vLCBwcm5fbm8sIGRvY19kYXRlKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG9wZW5OYXZldEZpbGUoaWQpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0Lm9wZW5OYXZldEZpbGUoaWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVsZXRlTmF2ZXRGaWxlKGlkKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5kZWxldGVOYXZldEZpbGUoaWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0R3JhZHVhdGVJbmZvKGlkKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXRHcmFkdWF0ZUluZm8oaWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TmF2ZXRDZXJ0aWZpY2F0ZShpZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0TmF2ZXRDZXJ0aWZpY2F0ZShpZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBvcGVuTmF2ZXRDZXJ0aWZpY2F0ZShpZCwgcGFnZSkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3Qub3Blbk5hdmV0Q2VydGlmaWNhdGUoaWQsIHBhZ2UpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBsb2FkTmF2ZXRDZXJ0aWZpY2F0ZShtZXRhLCBmaWxlRGVzY3JpcHRvcnMpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LnVwbG9hZE5hdmV0Q2VydGlmaWNhdGUobWV0YSwgZmlsZURlc2NyaXB0b3JzKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZU5hdmV0U3R1ZGVudChpZCwgc3R1ZGVudCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QudXBkYXRlTmF2ZXRTdHVkZW50KGlkLCBzdHVkZW50KTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZURvY3VtZW50KHN0dWRlbnRJZCwgY2xpZW50SWQsIGRhdGEpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmNyZWF0ZURvY3VtZW50KHN0dWRlbnRJZCwgY2xpZW50SWQsIGRhdGEpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RXh0cmFDb3Vyc2VJbmZvKGlkKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXRFeHRyYUNvdXJzZUluZm8oaWQpO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIEdlbmVyaWMgRGF0YSBTdG9yZVxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTdG9yZVNldHRpbmdzKHN0b3JlSWQpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldFN0b3JlU2V0dGluZ3Moc3RvcmVJZCk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgVGVtcGxhdGVzIERhdGFcclxuLy8gIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VGVtcGxhdGVTdG9yZVNldHRpbmdzKCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0VGVtcGxhdGVTdG9yZVNldHRpbmdzKCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRUZW1wbGF0ZXMoKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXRUZW1wbGF0ZXMoKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRlbXBsYXRlQnlOYW1lKG5hbWUpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldFRlbXBsYXRlQnlOYW1lKG5hbWUpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VGVtcGxhdGVCeUluc3RhbmNlSWQoaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0VGVtcGxhdGVCeUluc3RhbmNlSWQoaW5zdGFuY2VJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzYXZlVGVtcGxhdGUodGVtcGxhdGUpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LnNhdmVUZW1wbGF0ZSh0ZW1wbGF0ZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWxldGVUZW1wbGF0ZSh0ZW1wbGF0ZSkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZGVsZXRlVGVtcGxhdGUodGVtcGxhdGUpO1xyXG59XHJcblxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuLy8gIyMjIEFzc2Vzc21lbnQgRGF0YVxyXG4vLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRIb21ld29ya1Jlc3VsdHMoaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0SG9tZXdvcmtSZXN1bHRzKGluc3RhbmNlSWQpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UHJvdG9jb2woaW5zdGFuY2VJZCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZ2V0UHJvdG9jb2woaW5zdGFuY2VJZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGxvYWRFeGFtUmVzdWx0cyhleGFtTmFtZSwgZXhhbUlkLCBjb21ibywgZmlsZURlc2NyaXB0b3IpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LnVwbG9hZEV4YW1SZXN1bHRzKGV4YW1OYW1lLCBleGFtSWQsIGNvbWJvLCBmaWxlRGVzY3JpcHRvcik7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb25maWdzKGV4YW1JZHMpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldENvbmZpZ3MoZXhhbUlkcyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb25maWdCeUV4YW1JZChleGFtSWQpIHtcclxuICAgIHJldHVybiBhd2FpdCBhcGlDb25uZWN0LmdldENvbmZpZ0J5RXhhbUlkKGV4YW1JZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzYXZlQ29uZmlnKGNvbmZpZykge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3Quc2F2ZUNvbmZpZyhjb25maWcpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVsZXRlQ29uZmlnKGNvbmZpZykge1xyXG4gICAgcmV0dXJuIGF3YWl0IGFwaUNvbm5lY3QuZGVsZXRlQ29uZmlnKGNvbmZpZyk7XHJcbn1cclxuXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4vLyAjIyMgU2VtaW5hciBEYXRhXHJcbi8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2VtaW5hcnNCeURhdGUoc3RhcnREYXRlLCBlbmREYXRlKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgYXBpQ29ubmVjdC5nZXRTZW1pbmFyc0J5RGF0ZShzdGFydERhdGUsIGVuZERhdGUpO1xyXG59IiwiZXhwb3J0IGNsYXNzIENvbnRlbnRUeXBlIHtcclxuICAgIC8vIFByaXZhdGUgRmllbGRzXHJcbiAgICBzdGF0aWMgI19VcmxGb3JtRW5jb2RlZCA9ICdhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWQ7IGNoYXJzZXQ9VVRGLTgnO1xyXG4gICAgc3RhdGljICNfQXBwbGljdGlvbkpzb24gPSAnYXBwbGljYXRpb24vanNvbic7XHJcblxyXG4gICAgLy8gQWNjZXNzb3JzIGZvciBcImdldFwiIGZ1bmN0aW9ucyBvbmx5IChubyBcInNldFwiIGZ1bmN0aW9ucylcclxuICAgIHN0YXRpYyBnZXQgVXJsRm9ybUVuY29kZWQoKSB7IHJldHVybiB0aGlzLiNfVXJsRm9ybUVuY29kZWQ7IH1cclxuICAgIHN0YXRpYyBnZXQgQXBwbGljYXRpb25Kc29uKCkgeyByZXR1cm4gdGhpcy4jX0FwcGxpY3Rpb25Kc29uOyB9XHJcbn0iLCJpbXBvcnQgeyB1dWlkIH0gZnJvbSAnLi9wYXJzZSc7XHJcblxyXG5jb25zdCBkaXNwYXRjaCA9IHt9O1xyXG5cclxuY29uc3Qgc3RvcmVzID0ge1xyXG4gICAgTUFJTl9NT0RVTEVTOiAnU1RPUkVfTUFJTl9NT0RVTEVTJyxcclxuICAgIE1PRFVMRVM6ICdTVE9SRV9NT0RVTEVTJyxcclxuICAgIE1PRFVMRV9JTlNUQU5DRVM6ICdTVE9SRV9NT0RVTEVfSU5TVEFOQ0VTJyxcclxuICAgIFBBWU1FTlRTOiAnU1RPUkVfUEFZTUVOVFMnLFxyXG4gICAgVFJBSU5JTkdfSEFMTFM6ICdUUkFJTklOR19IQUxMUycsXHJcbiAgICBDT1VSU0VfSU5GTzogJ0NPVVJTRV9JTkZPJyxcclxuICAgIFNUUkVBTV9DT05GSUc6ICdTVFJFQU1fQ09ORklHJyxcclxuICAgIFNVUlZFWVM6ICdTVVJWRVlTJyxcclxuICAgIFNVUlZFWVNfQUxMOiAnU1VSVkVZU19BTEwnLFxyXG4gICAgU1VSVkVZOiAnU1VSVkVZX0lEXycsXHJcbiAgICBURU1QTEFURV9DT05GSUc6ICdURU1QTEFURV9DT05GSUcnLFxyXG4gICAgU1RBVElTVElDU19DT05GSUc6ICdTVEFUSVNUSUNTX0NPTkZJRydcclxufTtcclxuXHJcbmNvbnN0IGJnUG9ydCA9IGJyb3dzZXIucnVudGltZS5jb25uZWN0KHtcclxuICAgIG5hbWU6ICdzZXMtZGF0YS1wb3J0J1xyXG59KTtcclxuXHJcbmJnUG9ydC5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIob25NZXNzYWdlKTtcclxuXHJcbi8qKlxyXG4gKiBDcmVhdGUgZnVuY3Rpb24gd2l0aCBjYWNoZWQgcmVzcG9uc2VcclxuICogQHBhcmFtIHtGdW5jdGlvbn0gZnVuYyBGdW5jdGlvbiBjYWxsIHRvIGNhY2hlXHJcbiAqIEBwYXJhbSB7U3ltYm9sfSBzdG9yZUlkIFN0b3JlIGlkZW50aWZpZXJcclxuICogQHBhcmFtIHtOdW1iZXI9fSBtYXhBZ2UgQ2FjaGUgYWdlIHRocmVzaG9sZCwgaW4gc2Vjb25kcy4gSWYgb21pdHRlZCwgdGhlIGNhY2hlIGlzIGNvbnNpZGVyZWQgbm9uLWV4cGlyaW5nIChyZXNldHMgb24gcmVpbnN0YWxsaW5nL3VwZGF0aW5nIGV4dGVuc2lvbilcclxuICovXHJcbmZ1bmN0aW9uIHdpdGhDYWNoZShmdW5jLCBzdG9yZUlkLCBtYXhBZ2UpIHtcclxuXHJcbiAgICByZXR1cm4gZnVuY3Rpb24gKC4uLnBhcmFtcykge1xyXG4gICAgICAgIGNvbnN0IGNhbGxiYWNrcyA9IHt9O1xyXG5cclxuICAgICAgICBjb25zdCBwcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgICAgICBjYWxsYmFja3MucmVzb2x2ZSA9IHJlc29sdmU7XHJcbiAgICAgICAgICAgIGNhbGxiYWNrcy5yZWplY3QgPSByZWplY3Q7XHJcblxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBleGVjdXRvcigpO1xyXG4gICAgICAgIHJldHVybiBwcm9taXNlO1xyXG5cclxuICAgICAgICBhc3luYyBmdW5jdGlvbiBleGVjdXRvcigpIHtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGxldCByYXdDYWNoZSA9IGF3YWl0IGdldERhdGEoc3RvcmVJZCk7XHJcbiAgICAgICAgICAgICAgICBpZiAocmF3Q2FjaGUuZGF0YSAhPT0gdW5kZWZpbmVkICYmIGlzRnJlc2gocmF3Q2FjaGUud2hlbiwgbWF4QWdlKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHByb21pc2UuX2NhY2hlSGl0ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICBjYWxsYmFja3MucmVzb2x2ZShyYXdDYWNoZS5kYXRhKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBhd2FpdCBmdW5jKC4uLnBhcmFtcyk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0RGF0YShzdG9yZUlkLCB2YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2tzLnJlc29sdmUodmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgICAgIGNhbGxiYWNrcy5yZWplY3QoZXJyKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH07XHJcbn07XHJcblxyXG5mdW5jdGlvbiBpc0ZyZXNoKGNyZWF0aW9uRGF0ZSwgbWF4QWdlKSB7XHJcbiAgICBpZiAobWF4QWdlID09PSB1bmRlZmluZWQpIHtcclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH0gZWxzZSBpZiAoKERhdGUubm93KCkgLSBjcmVhdGlvbkRhdGUpIC8gMTAwMCA8PSBtYXhBZ2UpIHtcclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBjbGVhckNhY2hlKG5hbWUpIHtcclxuICAgIGJnUG9ydC5wb3N0TWVzc2FnZSh7XHJcbiAgICAgICAgY2xlYXI6IG5hbWVcclxuICAgIH0pO1xyXG59XHJcblxyXG4vKipcclxuICogUmV0cmlldmUgZGF0YSBmcm9tIHRoZSBiYWNrZ3JvdW5kIHN0b3JlXHJcbiAqIEBwYXJhbSB7U3RyaW5nfSBuYW1lIEl0ZW0gbmFtZVxyXG4gKi9cclxuZnVuY3Rpb24gZ2V0RGF0YShuYW1lKSB7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UocmVzb2x2ZSA9PiB7XHJcbiAgICAgICAgY29uc3QgX3V1aWQgPSB1dWlkKCk7XHJcbiAgICAgICAgYmdQb3J0LnBvc3RNZXNzYWdlKHtcclxuICAgICAgICAgICAgX3V1aWQsXHJcbiAgICAgICAgICAgIGdldDogbmFtZVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBkaXNwYXRjaFtfdXVpZF0gPSByZXNvbHZlO1xyXG4gICAgfSk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBTYXZlIGRhdGEgaW4gdGhlIGJhY2tncm91bmQgc3RvcmVcclxuICogQHBhcmFtIHtTdHJpbmd9IG5hbWUgSXRlbSBuYW1lXHJcbiAqIEBwYXJhbSB7Kn0gZGF0YSBEYXRhIHRvIHNhdmUgaW4gdGhlIHN0b3JlXHJcbiAqL1xyXG5mdW5jdGlvbiBzZXREYXRhKG5hbWUsIGRhdGEpIHtcclxuICAgIGJnUG9ydC5wb3N0TWVzc2FnZSh7XHJcbiAgICAgICAgc2V0OiBuYW1lLFxyXG4gICAgICAgIGRhdGFcclxuICAgIH0pO1xyXG59XHJcblxyXG5mdW5jdGlvbiBvbk1lc3NhZ2UobSkge1xyXG4gICAgY29uc3QgdXVpZCA9IG0uX3V1aWQ7XHJcbiAgICBkZWxldGUgbS5fdXVpZDtcclxuICAgIGRpc3BhdGNoW3V1aWRdKG0pO1xyXG4gICAgZGVsZXRlIGRpc3BhdGNoW3V1aWRdO1xyXG59XHJcblxyXG5cclxuZXhwb3J0IHtcclxuICAgIHN0b3JlcyxcclxuICAgIHdpdGhDYWNoZSxcclxuICAgIGNsZWFyQ2FjaGUsXHJcbiAgICBnZXREYXRhLFxyXG4gICAgc2V0RGF0YVxyXG59OyIsImltcG9ydCB7IGlzU1ZHLCBjcmVhdGVGcmFnbWVudEZyb20sIEVWRU5UX0xJU1RFTkVSUyB9IGZyb20gJy4vdXRpbHMnO1xyXG5cclxuLyoqXHJcbiAqIFRoZSB0YWcgbmFtZSBhbmQgY3JlYXRlIGFuIGh0bWwgdG9nZXRoZXIgd2l0aCB0aGUgYXR0cmlidXRlc1xyXG4gKlxyXG4gKiBAcGFyYW0gIHtTdHJpbmd9IHRhZ05hbWUgbmFtZSBhcyBzdHJpbmcsIGUuZy4gJ2RpdicsICdzcGFuJywgJ3N2ZydcclxuICogQHBhcmFtICB7T2JqZWN0fSBhdHRycyBodG1sIGF0dHJpYnV0ZXMgZS5nLiBkYXRhLSwgd2lkdGgsIHNyY1xyXG4gKiBAcGFyYW0gIHtBcnJheX0gY2hpbGRyZW4gaHRtbCBub2RlcyBmcm9tIGluc2lkZSBkZSBlbGVtZW50c1xyXG4gKiBAcmV0dXJuIHtIVE1MRWxlbWVudHxTVkdFbGVtZW50fSBodG1sIG5vZGUgd2l0aCBhdHRyc1xyXG4gKi9cclxuZnVuY3Rpb24gY3JlYXRlRWxlbWVudHModGFnTmFtZSwgYXR0cnMsIGNoaWxkcmVuKSB7XHJcbiAgICBjb25zdCBlbGVtZW50ID0gaXNTVkcodGFnTmFtZSlcclxuICAgICAgICA/IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnROUygnaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnLCB0YWdOYW1lKVxyXG4gICAgICAgIDogZG9jdW1lbnQuY3JlYXRlRWxlbWVudCh0YWdOYW1lKTtcclxuXHJcbiAgICAvLyBvbmUgb3IgbXVsdGlwbGUgd2lsbCBiZSBldmFsdWF0ZWQgdG8gYXBwZW5kIGFzIHN0cmluZyBvciBIVE1MRWxlbWVudFxyXG4gICAgY29uc3QgZnJhZ21lbnQgPSBjcmVhdGVGcmFnbWVudEZyb20oY2hpbGRyZW4pO1xyXG4gICAgZWxlbWVudC5hcHBlbmRDaGlsZChmcmFnbWVudCk7XHJcblxyXG4gICAgT2JqZWN0LmtleXMoYXR0cnMgfHwge30pLmZvckVhY2gocHJvcCA9PiB7XHJcbiAgICAgICAgaWYgKHByb3AgPT09ICdzdHlsZScpIHtcclxuICAgICAgICAgICAgLy8gZS5nLiBvcmlnaW46IDxlbGVtZW50IHN0eWxlPXt7IHByb3A6IHZhbHVlIH19IC8+XHJcbiAgICAgICAgICAgIE9iamVjdC5hc3NpZ24oZWxlbWVudC5zdHlsZSwgYXR0cnNbcHJvcF0pO1xyXG4gICAgICAgIH0gZWxzZSBpZiAocHJvcCA9PT0gJ3JlZicgJiYgdHlwZW9mIGF0dHJzLnJlZiA9PT0gJ2Z1bmN0aW9uJykge1xyXG4gICAgICAgICAgICBhdHRycy5yZWYoZWxlbWVudCwgYXR0cnMpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAocHJvcCA9PT0gJ2NsYXNzTmFtZScpIHtcclxuICAgICAgICAgICAgZWxlbWVudC5zZXRBdHRyaWJ1dGUoJ2NsYXNzJywgYXR0cnNbcHJvcF0pO1xyXG4gICAgICAgIH0gZWxzZSBpZiAocHJvcCA9PT0gJ3hsaW5rSHJlZicpIHtcclxuICAgICAgICAgICAgZWxlbWVudC5zZXRBdHRyaWJ1dGVOUygnaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluaycsICd4bGluazpocmVmJywgYXR0cnNbcHJvcF0pO1xyXG4gICAgICAgIH0gZWxzZSBpZiAocHJvcCA9PT0gJ2Rhbmdlcm91c2x5U2V0SW5uZXJIVE1MJykge1xyXG4gICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tdW5kZXJzY29yZS1kYW5nbGVcclxuICAgICAgICAgICAgZWxlbWVudC5pbm5lckhUTUwgPSBhdHRyc1twcm9wXS5fX2h0bWw7XHJcbiAgICAgICAgfSBlbHNlIGlmIChwcm9wIGluIEVWRU5UX0xJU1RFTkVSUykge1xyXG4gICAgICAgICAgICBlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoRVZFTlRfTElTVEVORVJTW3Byb3BdLCBhdHRyc1twcm9wXSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgLy8gYW55IG90aGVyIHByb3Agd2lsbCBiZSBzZXQgYXMgYXR0cmlidXRlXHJcbiAgICAgICAgICAgIGVsZW1lbnQuc2V0QXR0cmlidXRlKHByb3AsIGF0dHJzW3Byb3BdKTtcclxuICAgICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gZWxlbWVudDtcclxufVxyXG5cclxuLyoqXHJcbiAqIFRoZSBKU1hUYWcgd2lsbCBiZSB1bndyYXBwZWQgcmV0dXJuaW5nIHRoZSBodG1sXHJcbiAqXHJcbiAqIEBwYXJhbSAge0Z1bmN0aW9ufSBKU1hUYWcgbmFtZSBhcyBzdHJpbmcsIGUuZy4gJ2RpdicsICdzcGFuJywgJ3N2ZydcclxuICogQHBhcmFtICB7T2JqZWN0fSBlbGVtZW50UHJvcHMgY3VzdG9tIGpzeCBhdHRyaWJ1dGVzIGUuZy4gZm4sIHN0cmluZ3NcclxuICogQHBhcmFtICB7QXJyYXl9IGNoaWxkcmVuIGh0bWwgbm9kZXMgZnJvbSBpbnNpZGUgZGUgZWxlbWVudHNcclxuICpcclxuICogQHJldHVybiB7RnVuY3Rpb259IHJldHVybnMgZGUgJ2RvbScgKGZuKSBleGVjdXRlZCwgbGVhdmluZyB0aGUgSFRNTEVsZW1lbnRcclxuICpcclxuICogSlNYVGFnOiAgZnVuY3Rpb24gQ29tcChwcm9wcykge1xyXG4gKiAgIHJldHVybiBkb20oXCJzcGFuXCIsIG51bGwsIHByb3BzLm51bSk7XHJcbiAqIH1cclxuICovXHJcbmZ1bmN0aW9uIGNvbXBvc2VUb0Z1bmN0aW9uKEpTWFRhZywgZWxlbWVudFByb3BzLCBjaGlsZHJlbikge1xyXG4gICAgY29uc3QgcHJvcHMgPSBPYmplY3QuYXNzaWduKHt9LCBKU1hUYWcuZGVmYXVsdFByb3BzIHx8IHt9LCBlbGVtZW50UHJvcHMsIHsgY2hpbGRyZW4gfSk7XHJcbiAgICBjb25zdCBicmlkZ2UgPSAoSlNYVGFnLnByb3RvdHlwZSAmJiBKU1hUYWcucHJvdG90eXBlLnJlbmRlcikgPyBuZXcgSlNYVGFnKHByb3BzKS5yZW5kZXIgOiBKU1hUYWc7XHJcbiAgICBjb25zdCByZXN1bHQgPSBicmlkZ2UocHJvcHMpO1xyXG5cclxuICAgIHN3aXRjaCAocmVzdWx0KSB7XHJcbiAgICAgICAgY2FzZSAnRlJBR01FTlQnOlxyXG4gICAgICAgICAgICByZXR1cm4gY3JlYXRlRnJhZ21lbnRGcm9tKGNoaWxkcmVuKTtcclxuXHJcbiAgICAgICAgLy8gUG9ydGFscyBhcmUgdXNlZnVsIHRvIHJlbmRlciBtb2RhbHNcclxuICAgICAgICAvLyBhbGxvdyByZW5kZXIgb24gYSBkaWZmZXJlbnQgZWxlbWVudCB0aGFuIHRoZSBwYXJlbnQgb2YgdGhlIGNoYWluXHJcbiAgICAgICAgLy8gYW5kIGxlYXZlIGEgY29tbWVudCBpbnN0ZWFkXHJcbiAgICAgICAgY2FzZSAnUE9SVEFMJzpcclxuICAgICAgICAgICAgYnJpZGdlLnRhcmdldC5hcHBlbmRDaGlsZChjcmVhdGVGcmFnbWVudEZyb20oY2hpbGRyZW4pKTtcclxuICAgICAgICAgICAgcmV0dXJuIGRvY3VtZW50LmNyZWF0ZUNvbW1lbnQoJ1BvcnRhbCBVc2VkJyk7XHJcbiAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgIH1cclxufVxyXG5cclxuZnVuY3Rpb24gZG9tKGVsZW1lbnQsIGF0dHJzLCAuLi5jaGlsZHJlbikge1xyXG4gICAgLy8gQ3VzdG9tIENvbXBvbmVudHMgd2lsbCBiZSBmdW5jdGlvbnNcclxuICAgIGlmICh0eXBlb2YgZWxlbWVudCA9PT0gJ2Z1bmN0aW9uJykge1xyXG4gICAgICAgIGlmIChlbGVtZW50Lmhhc093blByb3BlcnR5KCdwcm9wVHlwZXMnKSkge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBwcm9wIG9mIGVsZW1lbnQucHJvcFR5cGVzKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoYXR0cnMuaGFzT3duUHJvcGVydHkocHJvcCkgPT09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihgSlNYIEVycm9yOiBNaXNzaW5nIHByb3BlcnR5ICcke3Byb3B9JyBmcm9tICcke2VsZW1lbnQubmFtZX0nIGludm9jYXRpb25gKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAvLyBlLmcuIGNvbnN0IEN1c3RvbVRhZyA9ICh7IHcgfSkgPT4gPHNwYW4gd2lkdGg9e3d9IC8+XHJcbiAgICAgICAgLy8gd2lsbCBiZSB1c2VkXHJcbiAgICAgICAgLy8gZS5nLiA8Q3VzdG9tVGFnIHc9ezF9IC8+XHJcbiAgICAgICAgLy8gYmVjb21lczogQ3VzdG9tVGFnKHsgdzogMX0pXHJcbiAgICAgICAgcmV0dXJuIGNvbXBvc2VUb0Z1bmN0aW9uKGVsZW1lbnQsIGF0dHJzLCBjaGlsZHJlbik7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gcmVndWxhciBodG1sIGNvbXBvbmVudHMgd2lsbCBiZSBzdHJpbmdzIHRvIGNyZWF0ZSB0aGUgZWxlbWVudHNcclxuICAgIC8vIHRoaXMgaXMgaGFuZGxlZCBieSB0aGUgYmFiZWwgcGx1Z2luc1xyXG4gICAgaWYgKHR5cGVvZiBlbGVtZW50ID09PSAnc3RyaW5nJykge1xyXG4gICAgICAgIHJldHVybiBjcmVhdGVFbGVtZW50cyhlbGVtZW50LCBhdHRycywgY2hpbGRyZW4pO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBjb25zb2xlLmVycm9yKGBqc3gtcmVuZGVyIGRvZXMgbm90IGhhbmRsZSAke3R5cGVvZiB0YWd9YCk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGRvbTtcclxuZXhwb3J0IGNvbnN0IEZyYWdtZW50ID0gKCkgPT4gJ0ZSQUdNRU5UJztcclxuZXhwb3J0IGNvbnN0IHBvcnRhbENyZWF0b3IgPSBub2RlID0+IHtcclxuICAgIGZ1bmN0aW9uIFBvcnRhbCgpIHtcclxuICAgICAgICByZXR1cm4gJ1BPUlRBTCc7XHJcbiAgICB9XHJcblxyXG4gICAgUG9ydGFsLnRhcmdldCA9IGRvY3VtZW50LmJvZHk7XHJcblxyXG4gICAgaWYgKG5vZGUgJiYgbm9kZS5ub2RlVHlwZSA9PT0gTm9kZS5FTEVNRU5UX05PREUpIHtcclxuICAgICAgICBQb3J0YWwudGFyZ2V0ID0gbm9kZTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gUG9ydGFsO1xyXG59O1xyXG4iLCJleHBvcnQgZnVuY3Rpb24gaXNTVkcoZWxlbWVudCkge1xyXG4gICAgY29uc3QgcGF0dCA9IG5ldyBSZWdFeHAoYF4ke2VsZW1lbnR9JGAsICdpJyk7XHJcbiAgICBjb25zdCBTVkdUYWdzID0gWydwYXRoJywgJ3N2ZycsICd1c2UnLCAnZyddO1xyXG5cclxuICAgIHJldHVybiBTVkdUYWdzLnNvbWUodGFnID0+IHBhdHQudGVzdCh0YWcpKTtcclxufVxyXG5cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVGcmFnbWVudEZyb20oY2hpbGRyZW4pIHtcclxuICAgIC8vIGZyYWdtZW50cyB3aWxsIGhlbHAgbGF0ZXIgdG8gYXBwZW5kIG11bHRpcGxlIGNoaWxkcmVuIHRvIHRoZSBpbml0aWFsIG5vZGVcclxuICAgIGNvbnN0IGZyYWdtZW50ID0gZG9jdW1lbnQuY3JlYXRlRG9jdW1lbnRGcmFnbWVudCgpO1xyXG5cclxuICAgIGZ1bmN0aW9uIHByb2Nlc3NET01Ob2RlcyhjaGlsZCkge1xyXG4gICAgICAgIGlmIChcclxuICAgICAgICAgICAgY2hpbGQgaW5zdGFuY2VvZiBIVE1MRWxlbWVudCB8fFxyXG4gICAgICAgICAgICBjaGlsZCBpbnN0YW5jZW9mIFNWR0VsZW1lbnQgfHxcclxuICAgICAgICAgICAgY2hpbGQgaW5zdGFuY2VvZiBDb21tZW50IHx8XHJcbiAgICAgICAgICAgIGNoaWxkIGluc3RhbmNlb2YgRG9jdW1lbnRGcmFnbWVudFxyXG4gICAgICAgICkge1xyXG4gICAgICAgICAgICBmcmFnbWVudC5hcHBlbmRDaGlsZChjaGlsZCk7XHJcbiAgICAgICAgfSBlbHNlIGlmICh0eXBlb2YgY2hpbGQgPT09ICdzdHJpbmcnIHx8IHR5cGVvZiBjaGlsZCA9PT0gJ251bWJlcicpIHtcclxuICAgICAgICAgICAgY29uc3QgdGV4dG5vZGUgPSBkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZShjaGlsZCk7XHJcbiAgICAgICAgICAgIGZyYWdtZW50LmFwcGVuZENoaWxkKHRleHRub2RlKTtcclxuICAgICAgICB9IGVsc2UgaWYgKGNoaWxkIGluc3RhbmNlb2YgQXJyYXkpIHtcclxuICAgICAgICAgICAgY2hpbGQuZm9yRWFjaChwcm9jZXNzRE9NTm9kZXMpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoY2hpbGQgPT09IGZhbHNlIHx8IGNoaWxkID09PSBudWxsKSB7XHJcbiAgICAgICAgICAgIC8vIGV4cHJlc3Npb24gZXZhbHVhdGVkIGFzIGZhbHNlIGUuZy4ge2ZhbHNlICYmIDxFbGVtIC8+fVxyXG4gICAgICAgICAgICAvLyBleHByZXNzaW9uIGV2YWx1YXRlZCBhcyBmYWxzZSBlLmcuIHtudWxsICYmIDxFbGVtIC8+fVxyXG4gICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIGNoaWxkID09PSAnZnVuY3Rpb24nKSB7XHJcblxyXG4gICAgICAgIH0gZWxzZSBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdkZXZlbG9wbWVudCcpIHtcclxuICAgICAgICAgICAgLy8gbGF0ZXIgb3RoZXIgdGhpbmdzIGNvdWxkIG5vdCBiZSBIVE1MRWxlbWVudCBub3Igc3RyaW5nc1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhjaGlsZCwgJ2lzIG5vdCBhcHBlbmRhYmxlJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGNoaWxkcmVuLmZvckVhY2gocHJvY2Vzc0RPTU5vZGVzKTtcclxuXHJcbiAgICByZXR1cm4gZnJhZ21lbnQ7XHJcbn1cclxuXHJcbi8vIE1hcCBmcm9tIEpTWCBwcm9wZXJ0eSAoZS5nLiBvbkNsaWNrKSB0byBldmVudCBuYW1lIChlLmcuICdjbGljaycpLlxyXG5leHBvcnQgY29uc3QgRVZFTlRfTElTVEVORVJTID0ge1xyXG4gICAgLy8gQ2xpcGJvYXJkIEV2ZW50c1xyXG4gICAgb25Db3B5OiAnY29weScsXHJcbiAgICBvbkN1dDogJ2N1dCcsXHJcbiAgICBvblBhc3RlOiAncGFzdGUnLFxyXG5cclxuICAgIC8vIENvbXBvc2l0aW9uIEV2ZW50c1xyXG4gICAgb25Db21wb3NpdGlvbkVuZDogJ2NvbXBvc2l0aW9uZW5kJyxcclxuICAgIG9uQ29tcG9zaXRpb25TdGFydDogJ2NvbXBvc2l0aW9uc3RhcnQnLFxyXG4gICAgb25Db21wb3NpdGlvblVwZGF0ZTogJ2NvbXBvc2l0aW9udXBkYXRlJyxcclxuXHJcbiAgICAvLyBGb2N1cyBFdmVudHNcclxuICAgIG9uRm9jdXM6ICdmb2N1cycsXHJcbiAgICBvbkJsdXI6ICdibHVyJyxcclxuXHJcbiAgICAvLyBGb3JtIEV2ZW50c1xyXG4gICAgb25DaGFuZ2U6ICdjaGFuZ2UnLFxyXG4gICAgb25CZWZvcmVJbnB1dDogJ2JlZm9yZWlucHV0JyxcclxuICAgIG9uSW5wdXQ6ICdpbnB1dCcsXHJcbiAgICBvblJlc2V0OiAncmVzZXQnLFxyXG4gICAgb25TdWJtaXQ6ICdzdWJtaXQnLFxyXG4gICAgb25JbnZhbGlkOiAnaW52YWxpZCcsXHJcblxyXG4gICAgLy8gSW1hZ2UgRXZlbnRzXHJcbiAgICBvbkxvYWQ6ICdsb2FkJyxcclxuICAgIG9uRXJyb3I6ICdlcnJvcicsXHJcblxyXG4gICAgLy8gS2V5Ym9hcmQgRXZlbnRzXHJcbiAgICBvbktleURvd246ICdrZXlkb3duJyxcclxuICAgIG9uS2V5UHJlc3M6ICdrZXlwcmVzcycsXHJcbiAgICBvbktleVVwOiAna2V5dXAnLFxyXG5cclxuICAgIC8vIE1lZGlhIEV2ZW50c1xyXG4gICAgb25BYm9ydDogJ2Fib3J0JyxcclxuICAgIG9uQ2FuUGxheTogJ2NhbnBsYXknLFxyXG4gICAgb25DYW5QbGF5VGhyb3VnaDogJ2NhbnBsYXl0aHJvdWdoJyxcclxuICAgIG9uRHVyYXRpb25DaGFuZ2U6ICdkdXJhdGlvbmNoYW5nZScsXHJcbiAgICBvbkVtcHRpZWQ6ICdlbXB0aWVkJyxcclxuICAgIG9uRW5jcnlwdGVkOiAnZW5jcnlwdGVkJyxcclxuICAgIG9uRW5kZWQ6ICdlbmRlZCcsXHJcbiAgICBvbkxvYWRlZERhdGE6ICdsb2FkZWRkYXRhJyxcclxuICAgIG9uTG9hZGVkTWV0YWRhdGE6ICdsb2FkZWRtZXRhZGF0YScsXHJcbiAgICBvbkxvYWRTdGFydDogJ2xvYWRzdGFydCcsXHJcbiAgICBvblBhdXNlOiAncGF1c2UnLFxyXG4gICAgb25QbGF5OiAncGxheScsXHJcbiAgICBvblBsYXlpbmc6ICdwbGF5aW5nJyxcclxuICAgIG9uUHJvZ3Jlc3M6ICdwcm9ncmVzcycsXHJcbiAgICBvblJhdGVDaGFuZ2U6ICdyYXRlY2hhbmdlJyxcclxuICAgIG9uU2Vla2VkOiAnc2Vla2VkJyxcclxuICAgIG9uU2Vla2luZzogJ3NlZWtpbmcnLFxyXG4gICAgb25TdGFsbGVkOiAnc3RhbGxlZCcsXHJcbiAgICBvblN1c3BlbmQ6ICdzdXNwZW5kJyxcclxuICAgIG9uVGltZVVwZGF0ZTogJ3RpbWV1cGRhdGUnLFxyXG4gICAgb25Wb2x1bWVDaGFuZ2U6ICd2b2x1bWVjaGFuZ2UnLFxyXG4gICAgb25XYWl0aW5nOiAnd2FpdGluZycsXHJcblxyXG4gICAgLy8gTW91c2VFdmVudHNcclxuICAgIG9uQ2xpY2s6ICdjbGljaycsXHJcbiAgICBvbkNvbnRleHRNZW51OiAnY29udGV4dG1lbnUnLFxyXG4gICAgb25Eb3VibGVDbGljazogJ2RvdWJsZWNsaWNrJyxcclxuICAgIG9uRHJhZzogJ2RyYWcnLFxyXG4gICAgb25EcmFnRW5kOiAnZHJhZ2VuZCcsXHJcbiAgICBvbkRyYWdFbnRlcjogJ2RyYWdlbnRlcicsXHJcbiAgICBvbkRyYWdFeGl0OiAnZHJhZ2V4aXQnLFxyXG4gICAgb25EcmFnTGVhdmU6ICdkcmFnbGVhdmUnLFxyXG4gICAgb25EcmFnT3ZlcjogJ2RyYWdvdmVyJyxcclxuICAgIG9uRHJhZ1N0YXJ0OiAnZHJhZ3N0YXJ0JyxcclxuICAgIG9uRHJvcDogJ2Ryb3AnLFxyXG4gICAgb25Nb3VzZURvd246ICdtb3VzZWRvd24nLFxyXG4gICAgb25Nb3VzZUVudGVyOiAnbW91c2VlbnRlcicsXHJcbiAgICBvbk1vdXNlTGVhdmU6ICdtb3VzZWxlYXZlJyxcclxuICAgIG9uTW91c2VNb3ZlOiAnbW91c2Vtb3ZlJyxcclxuICAgIG9uTW91c2VPdXQ6ICdtb3VzZW91dCcsXHJcbiAgICBvbk1vdXNlT3ZlcjogJ21vdXNlb3ZlcicsXHJcbiAgICBvbk1vdXNlVXA6ICdtb3VzZXVwJyxcclxuXHJcbiAgICAvLyBTZWxlY3Rpb24gRXZlbnRzXHJcbiAgICBvblNlbGVjdDogJ3NlbGVjdCcsXHJcblxyXG4gICAgLy8gVG91Y2ggRXZlbnRzXHJcbiAgICBvblRvdWNoQ2FuY2VsOiAndG91Y2hjYW5jZWwnLFxyXG4gICAgb25Ub3VjaEVuZDogJ3RvdWNoZW5kJyxcclxuICAgIG9uVG91Y2hNb3ZlOiAndG91Y2htb3ZlJyxcclxuICAgIG9uVG91Y2hTdGFydDogJ3RvdWNoc3RhcnQnLFxyXG5cclxuICAgIC8vIFBvaW50ZXIgRXZlbnRzXHJcbiAgICBvblBvaW50ZXJEb3duOiAncG9pbnRlcmRvd24nLFxyXG4gICAgb25Qb2ludGVyTW92ZTogJ3BvaW50ZXJtb3ZlJyxcclxuICAgIG9uUG9pbnRlclVwOiAncG9pbnRlcnVwJyxcclxuICAgIG9uUG9pbnRlckNhbmNlbDogJ3BvaW50ZXJjYW5jZWwnLFxyXG4gICAgb25Qb2ludGVyRW50ZXI6ICdwb2ludGVyZW50ZXInLFxyXG4gICAgb25Qb2ludGVyTGVhdmU6ICdwb2ludGVybGVhdmUnLFxyXG4gICAgb25Qb2ludGVyT3ZlcjogJ3BvaW50ZXJvdmVyJyxcclxuICAgIG9uUG9pbnRlck91dDogJ3BvaW50ZXJvdXQnLFxyXG5cclxuICAgIC8vIFVJIEV2ZW50c1xyXG4gICAgb25TY3JvbGw6ICdzY3JvbGwnLFxyXG5cclxuICAgIC8vIFdoZWVsIEV2ZW50c1xyXG4gICAgb25XaGVlbDogJ3doZWVsJyxcclxuXHJcbiAgICAvLyBBbmltYXRpb24gRXZlbnRzXHJcbiAgICBvbkFuaW1hdGlvblN0YXJ0OiAnYW5pbWF0aW9uc3RhcnQnLFxyXG4gICAgb25BbmltYXRpb25FbmQ6ICdhbmltYXRpb25lbmQnLFxyXG4gICAgb25BbmltYXRpb25JdGVyYXRpb246ICdhbmltYXRpb25pdGVyYXRpb24nLFxyXG5cclxuICAgIC8vIFRyYW5zaXRpb24gRXZlbnRzXHJcbiAgICBvblRyYW5zaXRpb25FbmQ6ICd0cmFuc2l0aW9uZW5kJyxcclxufTsiLCJmdW5jdGlvbiBxdWVyeVN0cmluZyhxdWVyeSkge1xyXG4gICAgaWYgKCFxdWVyeSkge1xyXG4gICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHF1ZXJ5XHJcbiAgICAgICAgLnNwbGl0KCc/JylbMV1cclxuICAgICAgICAuc3BsaXQoJyYnKVxyXG4gICAgICAgIC5tYXAoYSA9PiBhLnNwbGl0KCc9JykpXHJcbiAgICAgICAgLnJlZHVjZSgoYSwgYykgPT4ge1xyXG4gICAgICAgICAgICBhW2NbMF1dID0gY1sxXTtcclxuICAgICAgICAgICAgcmV0dXJuIGE7XHJcbiAgICAgICAgfSwge30pO1xyXG59XHJcblxyXG4vKipcclxuICogQ2FsY3VsYXRlIG51bWJlciBvZiBkYXlzIHBhc3NpbmcgYmV0d2VlbiB0d28gZGF0ZXNcclxuICogQHBhcmFtIHtEYXRlfSBhIFN0YXJ0aW5nIGRhdGVcclxuICogQHBhcmFtIHtEYXRlfSBiIEVuZGluZyBkYXRlXHJcbiAqIEByZXR1cm5zIHtudW1iZXJ9IE51bWJlciBvZiBkYXlzXHJcbiAqL1xyXG5mdW5jdGlvbiBkYXRlRGlmZihhLCBiKSB7XHJcbiAgICBpZiAoYS5nZXRGdWxsWWVhcigpID09IGIuZ2V0RnVsbFllYXIoKSAmJlxyXG4gICAgICAgIGEuZ2V0TW9udGgoKSA9PSBiLmdldE1vbnRoKCkgJiZcclxuICAgICAgICBhLmdldERhdGUoKSA9PSBiLmdldERhdGUoKSkge1xyXG4gICAgICAgIHJldHVybiAwO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gKGIgLSBhKSA+IDAgPyBNYXRoLmNlaWwoKGIgLSBhKSAvIDg2NDAwMDAwKSA6IE1hdGguZmxvb3IoKGIgLSBhKSAvIDg2NDAwMDAwKTtcclxuICAgIH1cclxufVxyXG5cclxuZnVuY3Rpb24gZGF0ZURpZmZUb0RheXMoZGF5cykge1xyXG4gICAgaWYgKGRheXMgPT0gMCkge1xyXG4gICAgICAgIHJldHVybiAnVG9kYXknO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICBpZiAoZGF5cyA8PSAwKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBgSW4gJHstZGF5c30gZGF5JHtkYXlzID09IC0xID8gJycgOiAncyd9YDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gYCR7ZGF5c30gZGF5JHtkYXlzID09IDEgPyAnJyA6ICdzJ30gYWdvYDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBJcyB0aGUgZGF0ZSBpbiB0aGUgbGFzdCBkYXkgb2YgYSBtb250aFxyXG4gKiBAcGFyYW0ge0RhdGV9IGRhdGVcclxuICogQHJldHVybnMge2Jvb2xlYW59XHJcbiAqL1xyXG5mdW5jdGlvbiBpc0xhc3REYXkoZGF0ZSkge1xyXG4gICAgY29uc3QgbmV4dERheSA9IG5ldyBEYXRlKGRhdGUpO1xyXG4gICAgbmV4dERheS5zZXREYXRlKG5leHREYXkuZ2V0RGF0ZSgpICsgMSk7XHJcbiAgICByZXR1cm4gKGRhdGUuZ2V0TW9udGgoKSAhPSBuZXh0RGF5LmdldE1vbnRoKCkpO1xyXG59XHJcblxyXG4vKipcclxuICogSXMgdGhlIGRhdGUgaW4gdGhlIGxhc3Qgd2VlayBvZiBhIG1vbnRoXHJcbiAqIEBwYXJhbSB7RGF0ZX0gZGF0ZVxyXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cclxuICovXHJcbmZ1bmN0aW9uIGlzTGFzdFdlZWsoZGF0ZSkge1xyXG4gICAgY29uc3QgbmV4dFdlZWsgPSBuZXcgRGF0ZShkYXRlKTtcclxuICAgIG5leHRXZWVrLnNldERhdGUobmV4dFdlZWsuZ2V0RGF0ZSgpICsgNyk7XHJcbiAgICByZXR1cm4gKGRhdGUuZ2V0TW9udGgoKSAhPSBuZXh0V2Vlay5nZXRNb250aCgpKTtcclxufVxyXG5cclxuZnVuY3Rpb24gZm9ybWF0RGF0ZShkYXRlKSB7XHJcbiAgICBjb25zdCBhc1N0cmluZyA9IGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKCdlbi1VUycsIHtcclxuICAgICAgICBtb250aDogJ3Nob3J0JyxcclxuICAgICAgICB5ZWFyOiAnbnVtZXJpYydcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIGAke2RhdGUuZ2V0RGF0ZSgpfSAke2FzU3RyaW5nfWA7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZvcm1hdFRpbWUoZGF0ZSkge1xyXG4gICAgcmV0dXJuIGRhdGUudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1VUycsIHtcclxuICAgICAgICBob3VyOiAnbnVtZXJpYycsXHJcbiAgICAgICAgbWludXRlOiAnbnVtZXJpYycsXHJcbiAgICAgICAgLy8gaG91cjEyOiBmYWxzZSxcclxuICAgICAgICBob3VyQ3ljbGU6ICdoMjMnXHJcbiAgICB9KTtcclxufVxyXG5cclxuZnVuY3Rpb24gZm9ybWF0TG9jYWxlRGF0ZShkYXRlKSB7XHJcbiAgICBjb25zdCBkYXkgPSBkYXRlLmdldERhdGUoKTtcclxuICAgIGNvbnN0IG1vbnRoID0gW1xyXG4gICAgICAgICfRj9C90YPQsNGA0LgnLFxyXG4gICAgICAgICfRhNC10LLRgNGD0LDRgNC4JyxcclxuICAgICAgICAn0LzQsNGA0YInLFxyXG4gICAgICAgICfQsNC/0YDQuNC7JyxcclxuICAgICAgICAn0LzQsNC5JyxcclxuICAgICAgICAn0Y7QvdC4JyxcclxuICAgICAgICAn0Y7Qu9C4JyxcclxuICAgICAgICAn0LDQstCz0YPRgdGCJyxcclxuICAgICAgICAn0YHQtdC/0YLQtdC80LLRgNC4JyxcclxuICAgICAgICAn0L7QutGC0L7QvNCy0YDQuCcsXHJcbiAgICAgICAgJ9C90L7QtdC80LLRgNC4JyxcclxuICAgICAgICAn0LTQtdC60LXQvNCy0YDQuCdcclxuICAgIF1bZGF0ZS5nZXRNb250aCgpXTtcclxuICAgIHJldHVybiBgJHtkYXl9ICR7bW9udGh9YDtcclxufVxyXG5cclxuZnVuY3Rpb24gZm9ybWF0TG9jYWxlV2Vla2RheShkYXksIGdldEFkaikge1xyXG4gICAgY29uc3Qgd2Vla2RheSA9IFtcclxuICAgICAgICAn0L3QtdC00LXQu9GPJyxcclxuICAgICAgICAn0L/QvtC90LXQtNC10LvQvdC40LonLFxyXG4gICAgICAgICfQstGC0L7RgNC90LjQuicsXHJcbiAgICAgICAgJ9GB0YDRj9C00LAnLFxyXG4gICAgICAgICfRh9C10YLQstGK0YDRgtGK0LonLFxyXG4gICAgICAgICfQv9C10YLRitC6JyxcclxuICAgICAgICAn0YHRitCx0L7RgtCwJyxcclxuICAgIF1bZGF5XTtcclxuICAgIGlmIChnZXRBZGopIHtcclxuICAgICAgICByZXR1cm4gW3dlZWtkYXksIFtcclxuICAgICAgICAgICAgJ9Cy0YHRj9C60LAnLFxyXG4gICAgICAgICAgICAn0LLRgdC10LrQuCcsXHJcbiAgICAgICAgICAgICfQstGB0LXQutC4JyxcclxuICAgICAgICAgICAgJ9Cy0YHRj9C60LAnLFxyXG4gICAgICAgICAgICAn0LLRgdC10LrQuCcsXHJcbiAgICAgICAgICAgICfQstGB0LXQutC4JyxcclxuICAgICAgICAgICAgJ9Cy0YHRj9C60LAnLFxyXG4gICAgICAgIF1bZGF5XV07XHJcbiAgICB9XHJcbiAgICByZXR1cm4gd2Vla2RheTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEdldCBhIG5ldyBkYXRlIG9mZnNldCBieSB0aGUgc3BlY2lmaWVkIG51bWJlciBvZiBkYXlzXHJcbiAqIEBwYXJhbSB7RGF0ZX0gZGF0ZSBCYXNlIGRhdGVcclxuICogQHBhcmFtIHtudW1iZXJ9IGRheXMgSG93IG1hbnkgZGF5cyB0byBvZmZzZXRcclxuICogQHJldHVybnMge0RhdGV9XHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gZ2V0T2Zmc2V0QnlEYXlzKGRhdGUsIGRheXMpIHtcclxuICAgIGNvbnN0IHJlc3VsdCA9IG5ldyBEYXRlKGRhdGUpO1xyXG4gICAgcmVzdWx0LnNldFVUQ0RhdGUocmVzdWx0LmdldFVUQ0RhdGUoKSArIGRheXMpO1xyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxufVxyXG5cclxuLyoqXHJcbiAqIE9mZnNldCB0aGUgZ2l2ZW4gZGF0ZSBpbiBwbGFjZSBieSB0aGUgc3BlY2lmaWVkIG51bWJlciBvZiBkYXlzXHJcbiAqIEBwYXJhbSB7RGF0ZX0gZGF0ZSBCYXNlIGRhdGVcclxuICogQHBhcmFtIHtudW1iZXJ9IGRheXMgSG93IG1hbnkgZGF5cyB0byBvZmZzZXRcclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBvZmZzZXRCeURheXMoZGF0ZSwgZGF5cykge1xyXG4gICAgZGF0ZS5zZXRVVENEYXRlKGRhdGUuZ2V0VVRDRGF0ZSgpICsgZGF5cyk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBDcmVhdGUgZGF0ZSBpbmRleCBhcyBzdHJpbmdcclxuICogQHBhcmFtIHtEYXRlfHN0cmluZ30gZGF0ZSBCYXNlIGRhdGVcclxuICogQHJldHVybnMge3N0cmluZ31cclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXREYXRlSW5kZXgoZGF0ZSkge1xyXG4gICAgaWYgKHR5cGVvZiBkYXRlID09ICdzdHJpbmcnKSB7XHJcbiAgICAgICAgZGF0ZSA9IG5ldyBEYXRlKGRhdGUpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGRhdGUudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHByZXR0eUpTT04ob2JqKSB7XHJcbiAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkob2JqLCBudWxsLCAyKS5yZXBsYWNlKC8gL2dtaSwgJyZuYnNwOycpLnJlcGxhY2UoL1xcbi9nbWksICc8YnI+Jyk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGdldE1vbmRheShkYXRlKSB7XHJcbiAgICBjb25zdCBtb25kYXkgPSBuZXcgRGF0ZShgJHtkYXRlLmdldEZ1bGxZZWFyKCl9LSR7ZGF0ZS5nZXRNb250aCgpICsgMX0tJHtkYXRlLmdldERhdGUoKX0gMTI6MDA6MDBgKTtcclxuICAgIG1vbmRheS5zZXREYXRlKG1vbmRheS5nZXREYXRlKCkgLSAoKG1vbmRheS5nZXREYXkoKSArIDYpICUgNykpO1xyXG4gICAgcmV0dXJuIG1vbmRheTtcclxufVxyXG5cclxuZnVuY3Rpb24gZ2V0U3VuZGF5KGRhdGUpIHtcclxuICAgIGNvbnN0IHN1bmRheSA9IG5ldyBEYXRlKGAke2RhdGUuZ2V0RnVsbFllYXIoKX0tJHtkYXRlLmdldE1vbnRoKCkgKyAxfS0ke2RhdGUuZ2V0RGF0ZSgpfSAyMzo1OTo1OWApO1xyXG4gICAgc3VuZGF5LnNldERhdGUoc3VuZGF5LmdldERhdGUoKSArICgoNyAtIHN1bmRheS5nZXREYXkoKSkgJSA3KSk7XHJcbiAgICByZXR1cm4gc3VuZGF5O1xyXG59XHJcblxyXG5jb25zdCBtb250aE5hbWUgPSB7XHJcbiAgICAxOiAnSmFudWFyeScsXHJcbiAgICAyOiAnRmVicnVhcnknLFxyXG4gICAgMzogJ01hcmNoJyxcclxuICAgIDQ6ICdBcHJpbCcsXHJcbiAgICA1OiAnTWF5JyxcclxuICAgIDY6ICdKdW5lJyxcclxuICAgIDc6ICdKdWx5JyxcclxuICAgIDg6ICdBdWd1c3QnLFxyXG4gICAgOTogJ1NlcHRlbWJlcicsXHJcbiAgICAxMDogJ09jdG9iZXInLFxyXG4gICAgMTE6ICdOb3ZlbWJlcicsXHJcbiAgICAxMjogJ0RlY2VtYmVyJyxcclxufTtcclxuXHJcblxyXG5jb25zdCBsb2NhbGVNb250aE5hbWUgPSB7XHJcbiAgICAxOiAn0Y/QvdGD0LDRgNC4JyxcclxuICAgIDI6ICfRhNC10LLRgNGD0LDRgNC4JyxcclxuICAgIDM6ICfQvNCw0YDRgicsXHJcbiAgICA0OiAn0LDQv9GA0LjQuycsXHJcbiAgICA1OiAn0LzQsNC5JyxcclxuICAgIDY6ICfRjtC90LgnLFxyXG4gICAgNzogJ9GO0LvQuCcsXHJcbiAgICA4OiAn0LDQstCz0YPRgdGCJyxcclxuICAgIDk6ICfRgdC10L/RgtC10LzQstGA0LgnLFxyXG4gICAgMTA6ICfQvtC60YLQvtC80LLRgNC4JyxcclxuICAgIDExOiAn0L3QvtC10LzQstGA0LgnLFxyXG4gICAgMTI6ICfQtNC10LrQtdC80LLRgNC4JyxcclxufTtcclxuXHJcbmZ1bmN0aW9uIHRvQXNzb2NBcnJheShwLCBjLCBpLCBhKSB7XHJcbiAgICBwW2MuSWRdID0gYztcclxuICAgIHJldHVybiBwO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdG9DdXN0b21Bc3NvY0FycmF5KGluZGV4TmFtZSwgb3ZlcndyaXRlID0gZmFsc2UpIHtcclxuICAgIHJldHVybiAocCwgYywgaSwgYSkgPT4ge1xyXG4gICAgICAgIGlmIChwW2NbaW5kZXhOYW1lXV0gIT09IHVuZGVmaW5lZCAmJiBvdmVyd3JpdGUgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkocFtjW2luZGV4TmFtZV1dKSkge1xyXG4gICAgICAgICAgICAgICAgcFtjW2luZGV4TmFtZV1dLnB1c2goYyk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBwW2NbaW5kZXhOYW1lXV0gPSBbcFtjW2luZGV4TmFtZV1dLCBjXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHBbY1tpbmRleE5hbWVdXSA9IGM7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBwO1xyXG4gICAgfTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEBwYXJhbSB7QXJyYXk8U1VQYXltZW50Pn0gZGF0YSBcclxuICogQHJldHVybnMge0FycmF5PFBheW1lbnRWaWV3TW9kZWw+fVxyXG4gKi9cclxuZnVuY3Rpb24gcGF5bWVudHNUb01hdHJpeChkYXRhKSB7XHJcbiAgICBjb25zdCB0ZW1wbGF0ZSA9IFtcclxuICAgICAgICAnSWQnLFxyXG4gICAgICAgICdQYXltZW50TnVtYmVyJyxcclxuICAgICAgICAnTW9kdWxlTmFtZUVuJyxcclxuICAgICAgICAnUGF5bWVudFBhY2thZ2VzQXNTdHJpbmcnLFxyXG4gICAgICAgICdQYWlkRm9yVXNlck5hbWUnLFxyXG4gICAgICAgICdQcmljZScsXHJcbiAgICAgICAgJ0VkdWNhdGlvbmFsRm9ybScsXHJcbiAgICAgICAgJ1BheW1lbnREYXRlVGltZSdcclxuICAgIF07XHJcbiAgICBjb25zdCBwYXJzZWQgPSBkYXRhLm1hcChlID0+IHtcclxuICAgICAgICBlLkVkdWNhdGlvbmFsRm9ybSA9IGUuRWR1Y2F0aW9uYWxGb3JtID09IDEgPyAnb25saW5lJyA6ICdvbnNpdGUnO1xyXG4gICAgICAgIGNvbnN0IGVudHJ5ID0gW107XHJcbiAgICAgICAgZm9yIChsZXQgcHJvcCBvZiB0ZW1wbGF0ZSkge1xyXG4gICAgICAgICAgICBpZiAocHJvcCA9PT0gJ1BheW1lbnREYXRlVGltZScpIHtcclxuICAgICAgICAgICAgICAgIGVudHJ5LnB1c2gobmV3IERhdGUoZVtwcm9wXSkpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgZW50cnkucHVzaChlW3Byb3BdKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gZW50cnk7XHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gW3RlbXBsYXRlLCAuLi5wYXJzZWRdO1xyXG59XHJcblxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHV1aWQoKSB7XHJcbiAgICByZXR1cm4gJ3h4eHh4eHh4LXh4eHgtNHh4eC15eHh4LXh4eHh4eHh4eHh4eCcucmVwbGFjZSgvW3h5XS9nLCBmdW5jdGlvbiAoYykge1xyXG4gICAgICAgIGxldCByID0gTWF0aC5yYW5kb20oKSAqIDE2IHwgMCxcclxuICAgICAgICAgICAgdiA9IGMgPT0gJ3gnID8gciA6IChyICYgMHgzIHwgMHg4KTtcclxuICAgICAgICByZXR1cm4gdi50b1N0cmluZygxNik7XHJcbiAgICB9KTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZURhdGVUaW1lKGRhdGV0aW1lKSB7XHJcbiAgICBpZiAoIWRhdGV0aW1lKSB7XHJcbiAgICAgICAgcmV0dXJuICcnO1xyXG4gICAgfSBlbHNlIGlmIChkYXRldGltZS50b1N0cmluZygpLmluY2x1ZGVzKCdEYXRlKCcpKSB7XHJcbiAgICAgICAgY29uc3QgbWF0Y2ggPSAvRGF0ZVxcKCguKylcXCkvLmV4ZWMoZGF0ZXRpbWUpO1xyXG4gICAgICAgIGlmIChtYXRjaCAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICBjb25zdCBkID0gbmV3IERhdGUoTnVtYmVyKG1hdGNoWzFdKSk7XHJcbiAgICAgICAgICAgIHJldHVybiBgJHsoJzAwMDAnICsgZC5nZXRGdWxsWWVhcigpKS5zbGljZSgtNCl9LSR7cHQoZC5nZXRNb250aCgpICsgMSl9LSR7cHQoZC5nZXREYXRlKCkpfVQke3B0KGQuZ2V0SG91cnMoKSl9OiR7cHQoZC5nZXRNaW51dGVzKCkpfWA7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIGRhdGV0aW1lO1xyXG4gICAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIGRhdGV0aW1lO1xyXG4gICAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBwdChzKSB7XHJcbiAgICByZXR1cm4gYDAke3N9YC5zbGljZSgtMik7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGh0bWxUb1RleHQoaHRtbCkge1xyXG4gICAgY29uc3QgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgICBkaXYuaW5uZXJIVE1MID0gaHRtbDtcclxuXHJcbiAgICByZXR1cm4gZGl2LnRleHRDb250ZW50O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaW5zdGFuY2VNZXRhRnJvbUhyZWYoaHJlZikge1xyXG4gICAgY29uc3QgaW5zdGFuY2VNZXRhID0gcXVlcnlTdHJpbmcoaHJlZik7XHJcbiAgICBpbnN0YW5jZU1ldGEuSW5zdGFuY2VSZWZUeXBlID0gKCgpID0+IHtcclxuICAgICAgICBzd2l0Y2ggKGluc3RhbmNlTWV0YS50eXBlKSB7XHJcbiAgICAgICAgICAgIGNhc2UgJ2NvdXJzZSc6IHJldHVybiAnbWFpbic7XHJcbiAgICAgICAgICAgIGNhc2UgJ2Zhc3QtdHJhY2snOiByZXR1cm4gJ29wZW4nO1xyXG4gICAgICAgICAgICBjYXNlICdnZW5lcmFsLWNvdXJzZS1pbnN0YW5jZSc6IHJldHVybiAnZ2VuZXJhbCc7XHJcbiAgICAgICAgfVxyXG4gICAgfSkoKTtcclxuXHJcbiAgICByZXR1cm4gaW5zdGFuY2VNZXRhO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaGFzVmFsdWUodmFsdWUpIHtcclxuICAgIHJldHVybiAodmFsdWUgIT09IG51bGwgJiYgdmFsdWUgIT09IHVuZGVmaW5lZCAmJiB2YWx1ZSAhPT0gJycpO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdmFsdWVPckVtcHR5KHZhbHVlLCBhbHQgPSAnJykge1xyXG4gICAgaWYgKHZhbHVlID09PSBudWxsIHx8IHZhbHVlID09PSB1bmRlZmluZWQgfHwgdmFsdWUgPT09ICcnKSB7XHJcbiAgICAgICAgcmV0dXJuIGFsdDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gc3VtQXJyYXlNYXgoYXJyKSB7XHJcbiAgICBpZiAoYXJyWzBdLmxlbmd0aCA9PSAwICYmIGFyclsxXS5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG5cclxuICAgIGxldCByZXN1bHQgPSAwO1xyXG5cclxuICAgIGlmIChhcnJbMF0ubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIHJlc3VsdCArPSBNYXRoLm1heCguLi5hcnJbMF0pO1xyXG4gICAgfVxyXG4gICAgaWYgKGFyclsxXS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgcmVzdWx0ICs9IE1hdGgubWF4KC4uLmFyclsxXSk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQge1xyXG4gICAgcXVlcnlTdHJpbmcsXHJcbiAgICBkYXRlRGlmZixcclxuICAgIGRhdGVEaWZmVG9EYXlzLFxyXG4gICAgaXNMYXN0RGF5LFxyXG4gICAgaXNMYXN0V2VlayxcclxuICAgIGZvcm1hdERhdGUsXHJcbiAgICBmb3JtYXRUaW1lLFxyXG4gICAgZm9ybWF0TG9jYWxlRGF0ZSxcclxuICAgIGZvcm1hdExvY2FsZVdlZWtkYXksXHJcbiAgICBwcmV0dHlKU09OLFxyXG4gICAgZ2V0TW9uZGF5LFxyXG4gICAgZ2V0U3VuZGF5LFxyXG4gICAgbW9udGhOYW1lLFxyXG4gICAgbG9jYWxlTW9udGhOYW1lLFxyXG4gICAgdG9Bc3NvY0FycmF5LFxyXG4gICAgcGF5bWVudHNUb01hdHJpeCxcclxuICAgIGh0bWxUb1RleHRcclxufTtcclxuXHJcblxyXG5leHBvcnQge1xyXG4gICAgcXVlcnlTdHJpbmcsXHJcbiAgICBkYXRlRGlmZixcclxuICAgIGRhdGVEaWZmVG9EYXlzLFxyXG4gICAgaXNMYXN0RGF5LFxyXG4gICAgaXNMYXN0V2VlayxcclxuICAgIGZvcm1hdERhdGUsXHJcbiAgICBmb3JtYXRUaW1lLFxyXG4gICAgZm9ybWF0TG9jYWxlRGF0ZSxcclxuICAgIGZvcm1hdExvY2FsZVdlZWtkYXksXHJcbiAgICBwcmV0dHlKU09OLFxyXG4gICAgZ2V0TW9uZGF5LFxyXG4gICAgZ2V0U3VuZGF5LFxyXG4gICAgbW9udGhOYW1lLFxyXG4gICAgbG9jYWxlTW9udGhOYW1lLFxyXG4gICAgdG9Bc3NvY0FycmF5LFxyXG4gICAgcGF5bWVudHNUb01hdHJpeCxcclxuICAgIGh0bWxUb1RleHRcclxufTsiLCJpbXBvcnQgcGFyc2UgZnJvbSAnLi9wYXJzZSc7XHJcblxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIExpbmsoeyBocmVmLCB0bywgbmF2LCBwYXJ0aWFsLCByZXEsIGNoaWxkcmVuLCAuLi5wcm9wcyB9KSB7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IGVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XHJcbiAgICAgICAgaWYgKGhyZWYgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICBlbGVtZW50LnNldEF0dHJpYnV0ZSgnaHJlZicsIGhyZWYpO1xyXG4gICAgICAgICAgICBlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGUpID0+IGhhbmRsZXIoZSwgZWxlbWVudCkpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBmb3IgKGxldCBwcm9wIG9mIE9iamVjdC5rZXlzKHByb3BzKSkge1xyXG4gICAgICAgICAgICBlbGVtZW50W3Byb3BdID0gcHJvcHNbcHJvcF07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChuYXYpIHtcclxuICAgICAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QuYWRkKCdzZXMtbmF2Jyk7XHJcbiAgICAgICAgICAgIGNvbnN0IGhyZWZUb2tlbnMgPSBwYXJzZS5xdWVyeVN0cmluZyhlbGVtZW50LmhyZWYpO1xyXG4gICAgICAgICAgICBjb25zdCBtYXRjaGVyID0gKG5hdikgPT4gbWF0Y2hSb3V0ZShocmVmVG9rZW5zLCBuYXYpO1xyXG4gICAgICAgICAgICBlbGVtZW50LmNoZWNrQWN0aXZlTmF2ID0gKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHdpbmRvdy5sb2NhdGlvbi5zZWFyY2guc3BsaXQoJz8nKVsxXSA9PT0gZWxlbWVudC5ocmVmLnNwbGl0KCc/JylbMV0pIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZWxlbWVudC5jbGFzc0xpc3QuYWRkKCdhY3RpdmUnKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAocGFydGlhbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChhY3RpdmVOYXYuc29tZShtYXRjaGVyKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVxID09PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBlbGVtZW50LmNsYXNzTGlzdC5hZGQoJ2FjdGl2ZScpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGFjdGl2ZU5hdi5zb21lKG5hdiA9PiBtYXRjaFJvdXRlKHJlcSwgbmF2KSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBlbGVtZW50LmNsYXNzTGlzdC5hZGQoJ2FjdGl2ZScpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdhY3RpdmUnKTtcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgZWxlbWVudC5jaGVja0FjdGl2ZU5hdigpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBhcHBlbmRBbGwoY2hpbGRyZW4sIGVsZW1lbnQpO1xyXG5cclxuICAgICAgICByZXR1cm4gZWxlbWVudDtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyLm1lc3NhZ2UpO1xyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIGhhbmRsZXIoZSwgZWxlbWVudCkge1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICBjb25zdCB0aXRsZSA9IGRvY3VtZW50LnRpdGxlO1xyXG4gICAgICAgIHdpbmRvdy5oaXN0b3J5LnB1c2hTdGF0ZSh7fSwgdGl0bGUsIGhyZWYpO1xyXG5cclxuICAgICAgICBpZiAodG8gIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICBpZiAobmF2KSB7XHJcbiAgICAgICAgICAgICAgICBjaGVja0FjdGl2ZU5hdigpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRvKCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdHJpZ2dlcigpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBhcHBlbmRBbGwoY2hpbGRyZW4sIGVsZW1lbnQpIHtcclxuICAgICAgICBmb3IgKGxldCBjaGlsZCBvZiBjaGlsZHJlbikge1xyXG4gICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShjaGlsZCkpIHtcclxuICAgICAgICAgICAgICAgIGFwcGVuZEFsbChjaGlsZCwgZWxlbWVudCk7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIGNoaWxkID09PSAnc3RyaW5nJyB8fCB0eXBlb2YgY2hpbGQgPT09ICdudW1iZXInKSB7XHJcbiAgICAgICAgICAgICAgICBlbGVtZW50LmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKGNoaWxkKSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBlbGVtZW50LmFwcGVuZENoaWxkKGNoaWxkKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHJlZGlyZWN0KGhyZWYpIHtcclxuICAgIGNvbnN0IHRpdGxlID0gZG9jdW1lbnQudGl0bGU7XHJcbiAgICB3aW5kb3cuaGlzdG9yeS5wdXNoU3RhdGUoe30sIHRpdGxlLCBocmVmKTtcclxuICAgIHRyaWdnZXIoKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGJhY2soKSB7XHJcbiAgICB3aW5kb3cuaGlzdG9yeS5iYWNrKCk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBjaGVja0FjdGl2ZU5hdigpIHtcclxuICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJy5zZXMtbmF2JykuZm9yRWFjaChlID0+IGUuY2hlY2tBY3RpdmVOYXYoKSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGxpbmsoY2FsbGJhY2ssIHRpdGxlKSB7XHJcbiAgICByZXR1cm4gZnVuY3Rpb24gKGVsZW1lbnQpIHtcclxuICAgICAgICBlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgZSA9PiB7XHJcbiAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgdGl0bGUgPSB0aXRsZSB8fCBkb2N1bWVudC50aXRsZTtcclxuICAgICAgICAgICAgd2luZG93Lmhpc3RvcnkucHVzaFN0YXRlKHt9LCB0aXRsZSwgZS50YXJnZXQuaHJlZik7XHJcblxyXG4gICAgICAgICAgICBjYWxsYmFjayhlKTtcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcbn1cclxuXHJcblxyXG53aW5kb3cub25wb3BzdGF0ZSA9IGZ1bmN0aW9uIChlKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIHRyaWdnZXIoKTtcclxuICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKCdSb3V0aW5nIGhhbmRsZXIgZXJyb3I6Jyk7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihlLm1lc3NhZ2UpO1xyXG4gICAgfVxyXG59O1xyXG5cclxuLy8gbXVzdCBoYXZlIGEgc3RhdGljIGluc3RhbmNlIGF2YWlsYWJsZSAtIHN0YXJ0aW5nIHdpdGggdG9wIGxldmVsIG9uIGZpcnN0IGNhbGwgdG8gcmVnaXN0ZXIsIHJlcGxhY2VkIGJ5IGFjdGl2ZSByb3V0ZSB1cG9uIGxvYWQvbmF2aWdhdGlvblxyXG4vLyBzdWJzZXF1ZW50IGNhbGxzIHRvIHJlZ2lzdGVyIGFkZCB0aGUgcm91dGVzIHRvIHRoZSBhY3RpdmUgcm91dGVyXHJcbi8qKlxyXG4gKiBAdHlwZWRlZiB7T2JqZWN0fSBSb3V0ZVxyXG4gKiBAcHJvcGVydHkge3tuYW1lOiBzdHJpbmd9fSBtYXRjaCAtIE5hbWUgb2YgcXVlcnkgcGFyYW1ldGVyIGFuZCBpdHMgdmFsdWVcclxuICogQHByb3BlcnR5IHtGdW5jdGlvbn0gaGFuZGxlciAtIENhbGxiYWNrIHRvIGJlIGV4ZWN1dGVkIG9uIG1hdGNoLiBFeHBlY3RlZCB0byByZW5kZXIgY29udGVudFxyXG4gKiBAcHJvcGVydHkgeyo9fSBjb250ZXh0IC0gT3B0aW9uYWwgb2JqZWN0IHRoYXQgd2lsbCBiZSBwYXNzZWQgdG8gaGFuZGxlclxyXG4gKiBAcHJvcGVydHkge1JvdXRlW109fSByb3V0ZXMgLSBOZXN0ZWQgcm91dGVzXHJcbiAqL1xyXG5cclxuLyoqIEB0eXBlIHtudW1iZXJ9IC0gRGVidWcgY291bnRlciAqL1xyXG5cclxuLyoqIEB0eXBlIHtSb3V0ZVtdfSAqL1xyXG5jb25zdCByb3V0ZXMgPSBbXTtcclxuLyoqIEB0eXBlIHtSb3V0ZX0gKi9cclxubGV0IGFjdGl2ZVJvdXRlID0gbnVsbDtcclxubGV0IGFjdGl2ZU5hdiA9IFtdO1xyXG5cclxuLyoqXHJcbiAqIEFkZCBuZXN0ZWQgcm91dGVzIHRvIGN1cnJlbnRseSBhY3RpdmUgcm91dGUuIElmIGZpcnN0IGNhbGwsIHRvcCBsZXZlbCByb3V0ZXMgYXJlIGRlZmluZWRcclxuICogQHBhcmFtIHtSb3V0ZVtdfSBvcHRpb25zIC0gTGlzdCBvZiByb3V0ZXNcclxuICogQHBhcmFtIHsqPX0gY29udGV4dCAtIE9wdGlvbmFsIG9iamVjdCB0aGF0IHdpbGwgYmUgcGFzc2VkIHRvIGhhbmRsZXJzXHJcbiAqL1xyXG5mdW5jdGlvbiByZWdpc3RlcihvcHRpb25zLCBjb250ZXh0KSB7XHJcbiAgICBsZXQgY3VycmVudFJvdXRlcyA9IHJvdXRlcztcclxuICAgIGlmIChhY3RpdmVSb3V0ZSAhPT0gbnVsbCkge1xyXG4gICAgICAgIGFjdGl2ZVJvdXRlLnJvdXRlcyA9IGFjdGl2ZVJvdXRlLnJvdXRlcyB8fCBbXTtcclxuICAgICAgICBjdXJyZW50Um91dGVzID0gYWN0aXZlUm91dGUucm91dGVzO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IG5ld1JvdXRlcyA9IFtdO1xyXG4gICAgZm9yIChsZXQgcm91dGUgb2Ygb3B0aW9ucykge1xyXG4gICAgICAgIHJvdXRlID0gT2JqZWN0LmFzc2lnbihyb3V0ZSwgeyBjb250ZXh0IH0pO1xyXG4gICAgICAgIGNvbnN0IHJvdXRlSWQgPSBjdXJyZW50Um91dGVzLnJlZHVjZSgocCwgYywgaSkgPT4gbWF0Y2hSb3V0ZShyb3V0ZS5tYXRjaCwgYy5tYXRjaCkgPyBpIDogcCwgdW5kZWZpbmVkKTtcclxuICAgICAgICBpZiAocm91dGVJZCAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIGN1cnJlbnRSb3V0ZXNbcm91dGVJZF0gPSByb3V0ZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBuZXdSb3V0ZXMucHVzaChyb3V0ZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgbmV3Um91dGVzLmZvckVhY2gociA9PiBjdXJyZW50Um91dGVzLnB1c2gocikpO1xyXG5cclxuICAgIHRyaWdnZXIoY3VycmVudFJvdXRlcyk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBSdW4gYSBjaGVjayBhZ2FpbnN0IHRoZSByb3V0aW5nIGxpc3QgYW5kIGV4ZWN1dGUgbWF0Y2hpbmcgaGFuZGxlcnNcclxuICogQHBhcmFtIHtSb3V0ZVtdPX0gY3VycmVudFJvdXRlcyAtIEN1cnJlbnRseSBhY3RpdmUgcm91dGluZyBsaXN0XHJcbiAqL1xyXG5mdW5jdGlvbiB0cmlnZ2VyKGN1cnJlbnRSb3V0ZXMpIHtcclxuICAgIGlmIChjdXJyZW50Um91dGVzID09PSB1bmRlZmluZWQgfHwgY3VycmVudFJvdXRlcyA9PT0gcm91dGVzKSB7XHJcbiAgICAgICAgY3VycmVudFJvdXRlcyA9IHJvdXRlcztcclxuICAgICAgICBhY3RpdmVOYXYgPSBbXTtcclxuICAgIH1cclxuICAgIC8qKiBAdHlwZSB7T2JqZWN0LjxzdHJpbmcsIHN0cmluZz4/fSAqL1xyXG4gICAgY29uc3QgcXVlcnkgPSBwYXJzZS5xdWVyeVN0cmluZyhkb2N1bWVudC5sb2NhdGlvbi5zZWFyY2gpO1xyXG5cclxuICAgIGZvciAobGV0IHJvdXRlIG9mIGN1cnJlbnRSb3V0ZXMpIHtcclxuICAgICAgICBpZiAobWF0Y2hSb3V0ZShxdWVyeSwgcm91dGUubWF0Y2gpKSB7XHJcbiAgICAgICAgICAgIGFjdGl2ZVJvdXRlID0gcm91dGU7XHJcbiAgICAgICAgICAgIGFjdGl2ZU5hdi5wdXNoKGFjdGl2ZVJvdXRlLm1hdGNoKTtcclxuICAgICAgICAgICAgY2hlY2tBY3RpdmVOYXYoKTtcclxuICAgICAgICAgICAgcmV0dXJuIHJvdXRlLmhhbmRsZXIocXVlcnksIHJvdXRlLmNvbnRleHQpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIENoZWNrIGlmIGEgZ2l2ZW4gcXVlcnkgb2JqZWN0IG1hdGNoZXMgYSBnaXZlbiByb3V0ZSBwYXR0ZXJuXHJcbiAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsIHN0cmluZz4/fSBxdWVyeSAtIFF1ZXJ5IHBhcmFtZXRlcnNcclxuICogQHBhcmFtIHt7bmFtZTogc3RyaW5nfX0gbWF0Y2ggLSBQYXJhbWV0ZXIgbmFtZSBhbmQgdmFsdWUgdGhhdCBtdXN0IG1hdGNoXHJcbiAqIEByZXR1cm5zIHtib29sZWFufVxyXG4gKi9cclxuZnVuY3Rpb24gbWF0Y2hSb3V0ZShxdWVyeSwgbWF0Y2gpIHtcclxuICAgIGlmIChtYXRjaCA9PT0gcXVlcnkpIHtcclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH0gZWxzZSBpZiAocXVlcnkpIHtcclxuICAgICAgICBpZiAodHlwZW9mIG1hdGNoID09PSAnc3RyaW5nJyAmJiBxdWVyeS5oYXNPd25Qcm9wZXJ0eShtYXRjaCkpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgbmFtZSBpbiBtYXRjaCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHF1ZXJ5W25hbWVdID09PSBtYXRjaFtuYW1lXSkgeyByZXR1cm4gdHJ1ZTsgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIE5vIG1hdGNoXHJcbiAgICByZXR1cm4gZmFsc2U7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IHtcclxuICAgIGxpbmssXHJcbiAgICByZWdpc3RlclxyXG59OyIsImltcG9ydCB7IHV1aWQgfSBmcm9tICcuL3BhcnNlJztcclxuaW1wb3J0IGRvbSwgeyBGcmFnbWVudCB9IGZyb20gJy4uL3V0aWwvanN4LXJlbmRlci1tb2QvZG9tJztcclxuXHJcbi8qKlxyXG4gKiBcclxuICogQHBhcmFtIHsqfSB0eXBlIFxyXG4gKiBAcGFyYW0geyp9IGNvbnRlbnQgXHJcbiAqIEBwYXJhbSB7Kn0gYXR0cmlidXRlcyBcclxuICogQHBhcmFtIHt7Zm9yY2VUeXBlOiAnVGV4dCcgfCAnSFRNTCd9fSBvcHRpb25zIFxyXG4gKiBAcmV0dXJucyBcclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBlbGVtZW50KHR5cGUsIGNvbnRlbnQsIGF0dHJpYnV0ZXMsIG9wdGlvbnMgPSB1bmRlZmluZWQpIHtcclxuICAgIGNvbnN0IHJlc3VsdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQodHlwZSk7XHJcblxyXG4gICAgaWYgKGF0dHJpYnV0ZXMpIHtcclxuICAgICAgICBmb3IgKGxldCBhdHRyIG9mIE9iamVjdC5rZXlzKGF0dHJpYnV0ZXMpKSB7XHJcbiAgICAgICAgICAgIHJlc3VsdFthdHRyXSA9IGF0dHJpYnV0ZXNbYXR0cl07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHJlc3VsdC5hcHBlbmQgPSBhcHBlbmQuYmluZChyZXN1bHQpO1xyXG5cclxuICAgIHJlc3VsdC5hcHBlbmRUbyA9IChwYXJlbnQpID0+IHtcclxuICAgICAgICBwYXJlbnQuYXBwZW5kKHJlc3VsdCk7XHJcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgIH07XHJcblxyXG4gICAgaWYgKGNvbnRlbnQgIT09IHVuZGVmaW5lZCAmJiBjb250ZW50ICE9PSBudWxsKSB7XHJcbiAgICAgICAgcmVzdWx0LmFwcGVuZChjb250ZW50LCBvcHRpb25zKTtcclxuICAgIH1cclxuICAgIHJldHVybiByZXN1bHQ7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGFwcGVuZChjaGlsZCwgb3B0aW9ucyA9IHVuZGVmaW5lZCkge1xyXG4gICAgaWYgKHR5cGVvZiAoY2hpbGQpID09PSAnc3RyaW5nJyB8fCB0eXBlb2YgKGNoaWxkKSA9PT0gJ251bWJlcicpIHtcclxuICAgICAgICBpZiAob3B0aW9ucz8uZm9yY2VUeXBlICE9ICdUZXh0JyAmJiAob3B0aW9ucz8uZm9yY2VUeXBlID09PSAnSFRNTCcgfHwgY2hpbGQudG9TdHJpbmcoKS50cmltKClbMF0gPT09ICc8JykpIHtcclxuICAgICAgICAgICAgdGhpcy5pbm5lckhUTUwgPSBjaGlsZDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBjaGlsZCA9IGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKGNoaWxkKTtcclxuICAgICAgICAgICAgdGhpcy5hcHBlbmRDaGlsZChjaGlsZCk7XHJcbiAgICAgICAgfVxyXG4gICAgfSBlbHNlIGlmIChBcnJheS5pc0FycmF5KGNoaWxkKSkge1xyXG4gICAgICAgIGZvciAobGV0IG5vZGUgb2YgY2hpbGQpIHtcclxuICAgICAgICAgICAgYXBwZW5kLmNhbGwodGhpcywgbm9kZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICB0aGlzLmFwcGVuZENoaWxkKGNoaWxkKTtcclxuICAgIH1cclxuICAgIHJldHVybiB0aGlzO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gcmVwbGFjZUNvbnRlbnRzKG5vZGUsIG5ld0NvbnRlbnRzKSB7XHJcbiAgICBjb25zdCBjTm9kZSA9IG5vZGUuY2xvbmVOb2RlKGZhbHNlKTtcclxuICAgIGFwcGVuZC5jYWxsKGNOb2RlLCBuZXdDb250ZW50cyk7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIG5vZGUucGFyZW50Tm9kZS5yZXBsYWNlQ2hpbGQoY05vZGUsIG5vZGUpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgY29uc29sZS5pbmZvKCdOb2RlIGhhcyBubyBwYXJlbnQgb3IgYW5vdGhlciBwcm9ibGVtIG9jY3VyZWQnKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gY05vZGU7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBzd2FwKG9sZE5vZGUsIG5ld05vZGUpIHtcclxuICAgIG9sZE5vZGUucGFyZW50Tm9kZS5yZXBsYWNlQ2hpbGQobmV3Tm9kZSwgb2xkTm9kZSk7XHJcbiAgICByZXR1cm4gbmV3Tm9kZTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFNwaW5uZXIoeyBpZCB9KSB7XHJcbiAgICBjb25zdCBub2RlID0gZWxlbWVudCgnZGl2JywgW1xyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAnc2stY3ViZSBzay1jdWJlMScgfSksXHJcbiAgICAgICAgZWxlbWVudCgnZGl2JywgbnVsbCwgeyBjbGFzc0xpc3Q6ICdzay1jdWJlIHNrLWN1YmUyJyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3NrLWN1YmUgc2stY3ViZTMnIH0pLFxyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAnc2stY3ViZSBzay1jdWJlNCcgfSksXHJcbiAgICAgICAgZWxlbWVudCgnZGl2JywgbnVsbCwgeyBjbGFzc0xpc3Q6ICdzay1jdWJlIHNrLWN1YmU1JyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3NrLWN1YmUgc2stY3ViZTYnIH0pLFxyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAnc2stY3ViZSBzay1jdWJlNycgfSksXHJcbiAgICAgICAgZWxlbWVudCgnZGl2JywgbnVsbCwgeyBjbGFzc0xpc3Q6ICdzay1jdWJlIHNrLWN1YmU4JyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3NrLWN1YmUgc2stY3ViZTknIH0pLFxyXG4gICAgXSwgeyBjbGFzc0xpc3Q6ICdzay1jdWJlLWdyaWQnIH0pO1xyXG4gICAgaWYgKGlkKSB7XHJcbiAgICAgICAgbm9kZS5zZXRBdHRyaWJ1dGUoJ2lkJywgaWQpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBub2RlO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gTG9hZGluZyh7IGlkLCBjb2xvciA9ICd3aGl0ZScgfSkge1xyXG4gICAgY29uc3Qgbm9kZSA9IGVsZW1lbnQoJ2RpdicsIFtcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3JlY3QxJyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3JlY3QyJyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3JlY3QzJyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3JlY3Q0JyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3JlY3Q1JyB9KSxcclxuICAgIF0sIHsgY2xhc3NMaXN0OiBnZXRDbGFzcygpIH0pO1xyXG4gICAgaWYgKGlkKSB7XHJcbiAgICAgICAgbm9kZS5zZXRBdHRyaWJ1dGUoJ2lkJywgaWQpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBub2RlO1xyXG5cclxuXHJcbiAgICBmdW5jdGlvbiBnZXRDbGFzcygpIHtcclxuICAgICAgICByZXR1cm4gYHNwaW5uZXIgJHtjb2xvcn1gO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gUmVtb3RlKHsgc3JjLCBwYXJzZSwgY29tcG9uZW50LCBjb2xvciA9ICd3aGl0ZScsIG9uUmVhZHksIG9uRXJyb3IgfSkge1xyXG4gICAgY29uc3QgaWQgPSB1dWlkKCk7XHJcbiAgICByZXNvbHZlKCk7XHJcblxyXG4gICAgY29uc3QgbG9hZGVyID0gTG9hZGluZyh7IGlkLCBjb2xvciB9KTtcclxuXHJcbiAgICByZXR1cm4gbG9hZGVyO1xyXG5cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiByZXNvbHZlKCkge1xyXG4gICAgICAgIGxldCBkYXRhID0gYXdhaXQgKGFzeW5jICgpID0+IHtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBhd2FpdCAoc3JjIGluc3RhbmNlb2YgUHJvbWlzZSkgPyBzcmMgOiBzcmMoKTtcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKG9uRXJyb3IpIHtcclxuICAgICAgICAgICAgICAgICAgICBvbkVycm9yKGUsIGxvYWRlcik7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNvbnN0IHJldHJ5QnRuID0gZWxlbWVudCgnYnV0dG9uJywgW1xyXG4gICAgICAgICAgICAgICAgICAgIGVsZW1lbnQoJ2knLCBudWxsLCB7IGNsYXNzTmFtZTogJ2dseXBoaWNvbiBnbHlwaGljb24tcmVwZWF0JyB9KSxcclxuICAgICAgICAgICAgICAgICAgICAnUmV0cnknXHJcbiAgICAgICAgICAgICAgICBdLCB7IHN0eWxlOiAnYmFja2dyb3VuZC1jb2xvcjogZ3JlZW4nIH0pO1xyXG4gICAgICAgICAgICAgICAgcmV0cnlCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVwbGFjZVNlbGYoUmVtb3RlKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3JjLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXJzZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29tcG9uZW50LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvclxyXG4gICAgICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGVsZW1lbnQoJ2RpdicsIFtcclxuICAgICAgICAgICAgICAgICAgICBlbGVtZW50KCdpJywgbnVsbCwgeyBjbGFzc05hbWU6ICdnbHlwaGljb24gZ2x5cGhpY29uLXJlbW92ZScsIHN0eWxlOiAnY29sb3I6IHJlZCcgfSksXHJcbiAgICAgICAgICAgICAgICAgICAgZS5tZXNzYWdlLFxyXG4gICAgICAgICAgICAgICAgICAgIHJldHJ5QnRuXHJcbiAgICAgICAgICAgICAgICBdLCB7IGlkOiBpZCB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKCk7XHJcblxyXG4gICAgICAgIGlmIChwYXJzZSkge1xyXG4gICAgICAgICAgICBkYXRhID0gcGFyc2UoZGF0YSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXBsYWNlU2VsZihkYXRhKTtcclxuXHJcbiAgICAgICAgZnVuY3Rpb24gcmVwbGFjZVNlbGYoZGF0YSkge1xyXG4gICAgICAgICAgICAvL2NvbnN0IGxvYWRlciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKTtcclxuICAgICAgICAgICAgY29uc3QgcGFyZW50ID0gbG9hZGVyLnBhcmVudE5vZGU7XHJcblxyXG4gICAgICAgICAgICBpZiAoY29tcG9uZW50KSB7XHJcbiAgICAgICAgICAgICAgICBwYXJlbnQuaW5zZXJ0QmVmb3JlKGNvbXBvbmVudChkYXRhKSwgbG9hZGVyKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGFwcGVuZChkYXRhKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvL2F3YWl0IG5ldyBQcm9taXNlKHJlc29sdmUgPT4gc2V0VGltZW91dCgxMCwgcmVzb2x2ZSkpO1xyXG4gICAgICAgICAgICAvL2NvbnNvbGUubG9nKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKSk7XHJcbiAgICAgICAgICAgIGxvYWRlci5yZW1vdmUoKTtcclxuICAgICAgICAgICAgaWYgKG9uUmVhZHkpIHtcclxuICAgICAgICAgICAgICAgIG9uUmVhZHkoKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgZnVuY3Rpb24gYXBwZW5kKGNoaWxkKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIChjaGlsZCkgPT09ICdzdHJpbmcnIHx8IHR5cGVvZiAoY2hpbGQpID09PSAnbnVtYmVyJykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChjaGlsZC50b1N0cmluZygpLnRyaW0oKVswXSA9PT0gJzwnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGZyYWdtZW50ID0gZWxlbWVudCgnZGl2JywgY2hpbGQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmcmFnbWVudC5jaGlsZE5vZGVzLmZvckVhY2gobiA9PiBwYXJlbnQuaW5zZXJ0QmVmb3JlKG4uY2xvbmVOb2RlKHRydWUpLCBsb2FkZXIpKTtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXJlbnQuaW5zZXJ0QmVmb3JlKGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKGNoaWxkKSwgbG9hZGVyKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkoY2hpbGQpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgbm9kZSBvZiBjaGlsZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBhcHBlbmQobm9kZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBwYXJlbnQuaW5zZXJ0QmVmb3JlKGNoaWxkLCBsb2FkZXIpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gWWVzKCkge1xyXG4gICAgY29uc3QgZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdpJyk7XHJcbiAgICBlbC5jbGFzc05hbWUgPSAnZ2x5cGhpY29uIGdseXBoaWNvbi1vayc7XHJcbiAgICBlbC5zdHlsZS5jb2xvciA9ICdncmVlbic7XHJcbiAgICByZXR1cm4gZWw7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBObygpIHtcclxuICAgIGNvbnN0IGVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaScpO1xyXG4gICAgZWwuY2xhc3NOYW1lID0gJ2dseXBoaWNvbiBnbHlwaGljb24tcmVtb3ZlJztcclxuICAgIGVsLnN0eWxlLmNvbG9yID0gJ3JlZCc7XHJcbiAgICByZXR1cm4gZWw7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBRdWVzdGlvbihbdGl0bGUsIGFuc3dlcnNdKSB7XHJcbiAgICByZXR1cm4gZWxlbWVudCgnZGl2JywgW1xyXG4gICAgICAgIGVsZW1lbnQoJ2gyJywgdGl0bGUpLFxyXG4gICAgICAgIGVsZW1lbnQoJ3VsJywgT2JqZWN0LmVudHJpZXMoYW5zd2VycykubWFwKChbYSwgaXNDb3JyZWN0XSkgPT4gZWxlbWVudCgnbGknLCBhLCB7IGNsYXNzTGlzdDogaXNDb3JyZWN0ID8gJ2NvcnJlY3QtYW5zd2VyJyA6ICdub25lJyB9LCB0cnVlKSkpXHJcbiAgICBdLCB7IGNsYXNzTGlzdDogJ3F1ZXN0aW9uLWNvbnRhaW5lcicgfSk7XHJcbn07XHJcblxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIEFsZXJ0KCkge1xyXG4gICAgY29uc3QgZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdpJyk7XHJcbiAgICBlbC5jbGFzc05hbWUgPSAnZ2x5cGhpY29uIGdseXBoaWNvbi13YXJuaW5nLXNpZ24nO1xyXG4gICAgZWwuc3R5bGUuY29sb3IgPSAnb3JhbmdlJztcclxuICAgIHJldHVybiBlbDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIENvbnRhaW5lcih7IGNoaWxkcmVuLCBjbGFzc05hbWUgfSkge1xyXG4gICAgY29uc3Qgc2VjdGlvbiA9IGVsZW1lbnQoJ3NlY3Rpb24nLCBjaGlsZHJlbiwge1xyXG4gICAgICAgIGNsYXNzTmFtZTogY2xhc3NOYW1lID8gJ2V2ZW50LWNvbnRhaW5lcicgOiAnY29udGFpbmVyJ1xyXG4gICAgfSk7XHJcbiAgICBjb25zdCBlbCA9IGVsZW1lbnQoJ2RpdicsIHNlY3Rpb24sIHtcclxuICAgICAgICBjbGFzc05hbWU6IGNsYXNzTmFtZSA/IGNsYXNzTmFtZSA6ICdjb250YWluZXIgYWRtaW5pc3RyYXRpb24tY29udGFpbmVyIHNlcy1jb250YWluZXInXHJcbiAgICB9KTtcclxuICAgIHJldHVybiBlbDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHBvcHVwVGFibGUoZGF0YSkge1xyXG4gICAgbGV0IGh0bWwgPSBgXHJcbiAgICAgICAgPHN0eWxlPlxyXG4gICAgICAgICAgICB0YWJsZSB7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRyLCB0ZCwgdGgge1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgYmxhY2s7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAwLjI1ZW0gMC41ZW07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICA8L3N0eWxlPlxyXG4gICAgICAgIGA7XHJcbiAgICBodG1sICs9ICc8dGFibGU+PHRoZWFkPjx0cj4nO1xyXG4gICAgZm9yIChsZXQgY29sIG9mIGRhdGFbMF0pIHtcclxuICAgICAgICBodG1sICs9IGA8dGg+JHtjb2x9PC90aD5gO1xyXG4gICAgfVxyXG4gICAgaHRtbCArPSAnPC90cj48L3RoZWFkPjx0Ym9keT4nO1xyXG4gICAgZm9yIChsZXQgcm93ID0gMTsgcm93IDwgZGF0YS5sZW5ndGg7IHJvdysrKSB7XHJcbiAgICAgICAgaHRtbCArPSAnPHRyPic7XHJcbiAgICAgICAgZm9yIChsZXQgY29sIG9mIGRhdGFbcm93XSkge1xyXG4gICAgICAgICAgICBodG1sICs9IGA8dGQ+JHtjb2x9PC90ZD5gO1xyXG4gICAgICAgIH1cclxuICAgICAgICBodG1sICs9ICc8L3RyPic7XHJcbiAgICB9XHJcbiAgICBodG1sICs9ICc8L3Rib2R5PjwvdGFibGU+JztcclxuICAgIHJldHVybiBodG1sO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0RWRpdG9yRGVjb3JhdGlvbihlbGVtZW50KSB7XHJcbiAgICBmdW5jdGlvbiBlbmFibGUoKSB7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QuYWRkKCdlbmFibGVkJyk7XHJcbiAgICB9XHJcbiAgICBmdW5jdGlvbiBkaXNhYmxlKCkge1xyXG4gICAgICAgIGVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnZW5hYmxlZCcpO1xyXG4gICAgfVxyXG4gICAgZnVuY3Rpb24gd29ya2luZygpIHtcclxuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ2VuYWJsZWQnKTtcclxuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5hZGQoJ3dvcmtpbmcnKTtcclxuICAgIH1cclxuICAgIGZ1bmN0aW9uIHVwZGF0ZWQoKSB7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCd3b3JraW5nJyk7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QuYWRkKCd1cGRhdGVkJyk7XHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ3VwZGF0ZWQnKSwgMzAwMCk7XHJcbiAgICB9XHJcbiAgICBmdW5jdGlvbiBmYWlsdXJlKCkge1xyXG4gICAgICAgIGVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnd29ya2luZycpO1xyXG4gICAgICAgIGVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnZmFpbGVkJyk7XHJcbiAgICB9XHJcbiAgICBmdW5jdGlvbiBfY2xlYXIoKSB7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdlbmFibGVkJyk7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCd3b3JraW5nJyk7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCd1cGRhdGVkJyk7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdmYWlsZWQnKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGVuYWJsZSxcclxuICAgICAgICBkaXNhYmxlLFxyXG4gICAgICAgIHdvcmtpbmcsXHJcbiAgICAgICAgdXBkYXRlZCxcclxuICAgICAgICBmYWlsdXJlLFxyXG4gICAgICAgIF9jbGVhclxyXG4gICAgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGFwcGx5QmVnaW5SZXF1ZXN0KGVsZW1lbnQpIHtcclxuICAgIGVsZW1lbnQuY2hpbGROb2Rlcy5mb3JFYWNoKGMgPT4gYy5jaGlsZE5vZGVzLmZvckVhY2gobiA9PiBuLmRpc2FibGVkID0gdHJ1ZSkpO1xyXG4gICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdlbmFibGVkJyk7XHJcbiAgICBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ2ZhaWxlZCcpO1xyXG4gICAgZWxlbWVudC5jbGFzc0xpc3QuYWRkKCd3b3JraW5nJyk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBhcHBseVJlcXVlc3RTdWNjZXNzKGVsZW1lbnQpIHtcclxuICAgIGVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnd29ya2luZycpO1xyXG4gICAgZWxlbWVudC5jbGFzc0xpc3QuYWRkKCd1cGRhdGVkJyk7XHJcbiAgICBzZXRUaW1lb3V0KCgpID0+IGVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgndXBkYXRlZCcpLCAzMDAwKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGFwcGx5UmVxdWVzdEVycm9yKHJlZkVsZW1lbnQsIGVycm9yQ29udGFpbmVyLCBmaWVsZHMpIHtcclxuICAgIHJlZkVsZW1lbnQuY2hpbGROb2Rlcy5mb3JFYWNoKGMgPT4gYy5jaGlsZE5vZGVzLmZvckVhY2gobiA9PiBuLmRpc2FibGVkID0gZmFsc2UpKTtcclxuICAgIHJlZkVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnd29ya2luZycpO1xyXG4gICAgcmVmRWxlbWVudC5jbGFzc0xpc3QuYWRkKCdmYWlsZWQnKTtcclxuICAgIGNvbnNvbGUud2FybihlcnJvckNvbnRhaW5lcik7XHJcbiAgICBpZiAoZXJyb3JDb250YWluZXIubWVzc2FnZSAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgYWxlcnQoZXJyb3JDb250YWluZXIubWVzc2FnZSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIGZvciAobGV0IGVycm9yIG9mIE9iamVjdC5rZXlzKGVycm9yQ29udGFpbmVyKSkge1xyXG4gICAgICAgICAgICBpZiAoZXJyb3IubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgIGFsZXJ0KGVycm9yQ29udGFpbmVyW2Vycm9yXS5lcnJvcnMuam9pbignXFxuJykpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgZmllbGQgPSBmaWVsZHNbZXJyb3JdO1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgbWVzc2FnZSBvZiBlcnJvckNvbnRhaW5lcltlcnJvcl0uZXJyb3JzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZmllbGQuYXBwZW5kQ2hpbGQoZWxlbWVudCgncCcsIG1lc3NhZ2UpKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUNoZWNrYm94KG5hbWUsIGRhdGEsIHRleHQsIG9uQ2hhbmdlLCBkZWZhdWx0VmFsdWUgPSBmYWxzZSkge1xyXG4gICAgY29uc3QgaWQgPSAnc2VzLScgKyBuYW1lO1xyXG4gICAgbGV0IHZhbHVlID0gcmVhZFByZXZJbnB1dCgpO1xyXG4gICAgZGF0YVtuYW1lXSA9IHZhbHVlO1xyXG4gICAgbGV0IGVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdpbnB1dCcpO1xyXG4gICAgZWxlbWVudC50eXBlID0gJ2NoZWNrYm94JztcclxuICAgIGVsZW1lbnQuaWQgPSBpZDtcclxuICAgIGVsZW1lbnQubmFtZSA9IG5hbWU7XHJcbiAgICBsZXQgbGFiZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsYWJlbCcpO1xyXG4gICAgbGFiZWwuaHRtbEZvciA9IGlkO1xyXG4gICAgbGFiZWwudGV4dENvbnRlbnQgPSB0ZXh0O1xyXG5cclxuICAgIC8qXHJcbiAgICBsZXQgZWxlbWVudCA9IDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBjbGFzc05hbWU9XCJzZXMtY2hlY2tcIiBpZD17aWR9IG5hbWU9e25hbWV9IC8+O1xyXG4gICAgbGV0IGxhYmVsID0gPGxhYmVsIGZvcj17aWR9Pnt0ZXh0fTwvbGFiZWw+O1xyXG4gICAgKi9cclxuICAgIGVsZW1lbnQuY2hlY2tlZCA9IHZhbHVlO1xyXG4gICAgZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCB0b2dnbGUpO1xyXG5cclxuICAgIGZ1bmN0aW9uIHJlYWRQcmV2SW5wdXQoKSB7XHJcbiAgICAgICAgbGV0IHByZXZJbnB1dCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKTtcclxuICAgICAgICBpZiAocHJldklucHV0KSB7XHJcbiAgICAgICAgICAgIHJldHVybiBwcmV2SW5wdXQuY2hlY2tlZDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gZGVmYXVsdFZhbHVlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiB0b2dnbGUoZSkge1xyXG4gICAgICAgIHZhbHVlID0gZS50YXJnZXQuY2hlY2tlZDtcclxuICAgICAgICBkYXRhW25hbWVdID0gdmFsdWU7XHJcbiAgICAgICAgcmVkcmF3KCk7XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gcmVkcmF3KCkge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlKCk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVyci5tZXNzYWdlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgY2hlY2tib3ggPSB7XHJcbiAgICAgICAgZWxlbWVudCxcclxuICAgICAgICBsYWJlbFxyXG4gICAgfTtcclxuXHJcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoY2hlY2tib3gsICd2YWx1ZScsIHtcclxuICAgICAgICBnZXQ6ICgpID0+IHZhbHVlLFxyXG4gICAgICAgIHNldDogKG5ld1ZhbHVlKSA9PiB7XHJcbiAgICAgICAgICAgIHZhbHVlID0gbmV3VmFsdWU7XHJcbiAgICAgICAgICAgIGVsZW1lbnQuY2hlY2tlZCA9IHZhbHVlO1xyXG4gICAgICAgICAgICBkYXRhW25hbWVdID0gdmFsdWU7XHJcbiAgICAgICAgICAgIHJlZHJhdygpO1xyXG4gICAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiBjaGVja2JveDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHRhYmxlKGRhdGEsIGxheW91dCkge1xyXG4gICAgY29uc3QgdGhlYWQgPSBlbGVtZW50KCd0aGVhZCcsIGVsZW1lbnQoJ3RyJywgbGF5b3V0Lm1hcChoID0+IGVsZW1lbnQoJ3RoJywgaC5sYWJlbCkpKSk7XHJcbiAgICBjb25zdCB0Ym9keSA9IGVsZW1lbnQoJ3Rib2R5JywgZGF0YS5tYXAociA9PiBlbGVtZW50KCd0cicsIGxheW91dC5tYXAoaCA9PiBlbGVtZW50KCd0ZCcsIHJbaC5uYW1lXSkpKSkpO1xyXG5cclxuICAgIGNvbnN0IHRhYmxlID0gZWxlbWVudCgndGFibGUnLCBbdGhlYWQsIHRib2R5XSk7XHJcbiAgICB0YWJsZS50aGVhZCA9IHRoZWFkO1xyXG4gICAgdGFibGUudGJvZHkgPSB0Ym9keTtcclxuXHJcbiAgICByZXR1cm4gdGFibGU7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBBdXRvY29tcGxldGUoeyB2YWx1ZXMsIGN1cnJlbnQgfSkge1xyXG4gICAgbGV0IGF1dG9jb21wbGV0ZSA9IGVsZW1lbnQoJ2RpdicsIFtcclxuICAgICAgICBlbGVtZW50KCdpbnB1dCcsIHVuZGVmaW5lZCwgeyBjbGFzc05hbWU6ICdzZXMtc2VhcmNoLWF1dG9jb21wbGV0ZS1pbnB1dCcgfSksXHJcbiAgICAgICAgZWxlbWVudCgnZGl2JywgZWxlbWVudCgndWwnKSwgeyBjbGFzc05hbWU6ICdzZXMtc2VhcmNoLWF1dG9jb21wbGV0ZS1zdWdnZXN0aW9ucycgfSlcclxuICAgIF0sIHsgY2xhc3NOYW1lOiAnc2VzLXNlYXJjaC1hdXRvY29tcGxldGUtY29udGFpbmVyJyB9KTtcclxuXHJcbiAgICBjb25zdCBzdWdnZXN0aW9uc0NvbnRhaW5lciA9IGF1dG9jb21wbGV0ZS5xdWVyeVNlbGVjdG9yKCcuc2VzLXNlYXJjaC1hdXRvY29tcGxldGUtc3VnZ2VzdGlvbnMnKTtcclxuICAgIGNvbnN0IGlucHV0ID0gYXV0b2NvbXBsZXRlLnF1ZXJ5U2VsZWN0b3IoJy5zZXMtc2VhcmNoLWF1dG9jb21wbGV0ZS1pbnB1dCcpO1xyXG4gICAgbGV0IHNlbGVjdGVkSW5kZXggPSB1bmRlZmluZWQ7XHJcblxyXG4gICAgaWYgKGN1cnJlbnQgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgaW5wdXQudmFsdWUgPSBjdXJyZW50O1xyXG4gICAgfVxyXG5cclxuICAgIGF1dG9jb21wbGV0ZS5nZXRWYWx1ZSA9IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICByZXR1cm4gaW5wdXQudmFsdWU7XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gc2VhcmNoSGFuZGxlcihlKSB7XHJcbiAgICAgICAgY29uc3QgaW5wdXRWYWwgPSBlLmN1cnJlbnRUYXJnZXQudmFsdWU7XHJcbiAgICAgICAgbGV0IHJlc3VsdHMgPSB2YWx1ZXM7XHJcbiAgICAgICAgaWYgKGlucHV0VmFsLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgcmVzdWx0cyA9IHZhbHVlcy5maWx0ZXIoeCA9PiB4LnRvTG93ZXJDYXNlKCkuaW5kZXhPZihpbnB1dFZhbC50b0xvd2VyQ2FzZSgpKSA+IC0xKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgc2hvd1N1Z2dlc3Rpb25zKHJlc3VsdHMsIGlucHV0VmFsKTtcclxuICAgICAgICBpZiAoZS5rZXlDb2RlID09PSAzOCB8fCBlLmtleUNvZGUgPT09IDQwIHx8IGUua2V5Q29kZSA9PT0gMTMpIHtcclxuICAgICAgICAgICAgc2Nyb2xsUmVzdWx0cyhlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gc2hvd1N1Z2dlc3Rpb25zKHJlc3VsdHMsIGlucHV0VmFsKSB7XHJcbiAgICAgICAgbGV0IHN1Z2dlc3Rpb25zID0gc3VnZ2VzdGlvbnNDb250YWluZXIucXVlcnlTZWxlY3RvcigndWwnKTtcclxuICAgICAgICByZXBsYWNlQ29udGVudHMoc3VnZ2VzdGlvbnMsICcnKTtcclxuICAgICAgICBzdWdnZXN0aW9ucyA9IHN1Z2dlc3Rpb25zQ29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoJ3VsJyk7O1xyXG5cclxuICAgICAgICBpZiAocmVzdWx0cy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcmVzdWx0cy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgbGV0IGl0ZW0gPSByZXN1bHRzW2ldO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgbWF0Y2ggPSBpdGVtLm1hdGNoKG5ldyBSZWdFeHAoaW5wdXRWYWwsICdpJykpO1xyXG4gICAgICAgICAgICAgICAgaXRlbSA9IGl0ZW0ucmVwbGFjZShtYXRjaFswXSwgYDxzdHJvbmc+JHttYXRjaFswXX08L3N0cm9uZz5gKTtcclxuICAgICAgICAgICAgICAgIGxldCBuZXdMaSA9IGVsZW1lbnQoJ2xpJywgaXRlbSwgdW5kZWZpbmVkLCB7IGZvcmNlVHlwZTogXCJIVE1MXCIgfSk7XHJcbiAgICAgICAgICAgICAgICBzdWdnZXN0aW9ucy5hcHBlbmRDaGlsZChuZXdMaSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgc3VnZ2VzdGlvbnMuY2xhc3NMaXN0LmFkZCgnaGFzLXN1Z2dlc3Rpb25zJyk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgc3VnZ2VzdGlvbnMuY2xhc3NMaXN0LnJlbW92ZSgnaGFzLXN1Z2dlc3Rpb25zJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIHVzZVN1Z2dlc3Rpb24oZSkge1xyXG4gICAgICAgIGlucHV0LnZhbHVlID0gZS50YXJnZXQudGV4dENvbnRlbnQ7XHJcbiAgICAgICAgaW5wdXQuZm9jdXMoKTtcclxuICAgICAgICBsZXQgc3VnZ2VzdGlvbnMgPSBzdWdnZXN0aW9uc0NvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCd1bCcpO1xyXG4gICAgICAgIHJlcGxhY2VDb250ZW50cyhzdWdnZXN0aW9ucywgJycpO1xyXG4gICAgICAgIHN1Z2dlc3Rpb25zID0gc3VnZ2VzdGlvbnNDb250YWluZXIucXVlcnlTZWxlY3RvcigndWwnKTtcclxuICAgICAgICBzdWdnZXN0aW9ucy5jbGFzc0xpc3QucmVtb3ZlKCdoYXMtc3VnZ2VzdGlvbnMnKTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBzY3JvbGxSZXN1bHRzKGUpIHtcclxuICAgICAgICBsZXQgYWxsU3VnZ2VzdGlvbnMgPSBbLi4uc3VnZ2VzdGlvbnNDb250YWluZXIucXVlcnlTZWxlY3RvckFsbCgndWwgbGknKV07XHJcbiAgICAgICAgbGV0IG9sZEluZGV4ID0gdW5kZWZpbmVkO1xyXG4gICAgICAgIGxldCBpbmRleENoYW5nZSA9IDE7XHJcblxyXG4gICAgICAgIC8vIGVudGVyXHJcbiAgICAgICAgaWYgKGUua2V5Q29kZSA9PT0gMTMpIHtcclxuICAgICAgICAgICAgaW5wdXQudmFsdWUgPSBhbGxTdWdnZXN0aW9uc1tzZWxlY3RlZEluZGV4XS50ZXh0Q29udGVudDtcclxuICAgICAgICAgICAgc2VsZWN0ZWRJbmRleCA9IHVuZGVmaW5lZDtcclxuICAgICAgICAgICAgbGV0IHN1Z2dlc3Rpb25zID0gc3VnZ2VzdGlvbnNDb250YWluZXIucXVlcnlTZWxlY3RvcigndWwnKTtcclxuICAgICAgICAgICAgc3VnZ2VzdGlvbnMuY2xhc3NMaXN0LnJlbW92ZSgnaGFzLXN1Z2dlc3Rpb25zJyk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChlLmtleUNvZGUgPT09IDQwKSB7XHJcbiAgICAgICAgICAgIC8vIGRvd24gYXJyb3dcclxuICAgICAgICAgICAgaW5kZXhDaGFuZ2UgPSAxO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoZS5rZXlDb2RlID09PSAzOCkge1xyXG4gICAgICAgICAgICAvLyB1cCBhcnJvd1xyXG4gICAgICAgICAgICBpbmRleENoYW5nZSA9IC0xO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHNlbGVjdGVkSW5kZXggPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIHNlbGVjdGVkSW5kZXggPSBpbmRleENoYW5nZSA9PT0gMSA/IDAgOiBhbGxTdWdnZXN0aW9ucy5sZW5ndGggLSAxO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIG9sZEluZGV4ID0gc2VsZWN0ZWRJbmRleDtcclxuICAgICAgICAgICAgc2VsZWN0ZWRJbmRleCA9ICgoc2VsZWN0ZWRJbmRleCArIGluZGV4Q2hhbmdlKSArIGFsbFN1Z2dlc3Rpb25zLmxlbmd0aCkgJSBhbGxTdWdnZXN0aW9ucy5sZW5ndGg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAob2xkSW5kZXggIT09IHVuZGVmaW5lZCAmJiBvbGRJbmRleCA8IGFsbFN1Z2dlc3Rpb25zLmxlbmd0aCkge1xyXG4gICAgICAgICAgICBhbGxTdWdnZXN0aW9uc1tvbGRJbmRleF0uY2xhc3NMaXN0LnJlbW92ZSgnc2VsZWN0ZWQnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGFsbFN1Z2dlc3Rpb25zW3NlbGVjdGVkSW5kZXhdLmNsYXNzTGlzdC5hZGQoJ3NlbGVjdGVkJyk7XHJcbiAgICB9XHJcblxyXG4gICAgaW5wdXQuYWRkRXZlbnRMaXN0ZW5lcigna2V5dXAnLCBzZWFyY2hIYW5kbGVyKTtcclxuICAgIHN1Z2dlc3Rpb25zQ29udGFpbmVyLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgdXNlU3VnZ2VzdGlvbik7XHJcbiAgICByZXR1cm4gYXV0b2NvbXBsZXRlO1xyXG59XHJcblxyXG4vKipcclxuICogQ3JlYXRlcyBhIHNwYW4gZWxlbWVudCB0aGF0IHJlcHJlc2VudHMgYSBkb3dubG9hZCBwcm9ncmVzcyBiYXJcclxuICogQHBhcmFtIHsge2Rvd25sb2FkRnVuY3Rpb246IChvblByb2dyZXNzOiBpbXBvcnQoJy4vdXRpbC5qcycpLk9uUHJvZ3Jlc3NGdW5jdGlvbiksIHJldHVybkZ1bmN0aW9uOiBmdW5jdGlvbn0gfSBzZXR0aW5ncyBDb250YWlucyB0aGUgZnVuY3Rpb24gdGhhdCB3aWxsIGRvd25sb2FkIHRoZSByZXNvdXJjZXMsIHdoaWNoIHdpbGwgYmUgY2FsbGVkIHdpdGggb25Qcm9ncmVzc1xyXG4gKiBhbmQgdGhlIHJldHVybkZ1bmN0aW9uIHdoaWNoIHdpbGwgYmUgY2FsbGVkIHdpdGggdGhlIHJlc3VsdHMgYWZ0ZXIgdGhlIGRvd25sb2FkIGZpbmlzaGVzXHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gRG93bmxvYWRQcm9ncmVzc0Jhcih7IGRvd25sb2FkRnVuY3Rpb24sIHJldHVybkZ1bmN0aW9uIH0pIHtcclxuICAgIGNvbnN0IHBlcmNlbnQgPSA8c3Bhbj4wJTwvc3Bhbj47XHJcbiAgICBjb25zdCBiYXIgPSA8c3BhbiBzdHlsZT17eyBwYWRkaW5nOiAnMCAwLjVlbScsIGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snLCB3aWR0aDogJzI1JScsIGJhY2tncm91bmQ6ICdsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICNmZmEwMDAgMCUsICNlZWUgMCknIH19PntwZXJjZW50fSDQodCy0LDQu9GP0L3QtTwvc3Bhbj47XHJcbiAgICBkb3dubG9hZEZ1bmN0aW9uKG9uUHJvZ3Jlc3MpLnRoZW4oZGF0YSA9PiB7XHJcbiAgICAgICAgaWYgKHJldHVybkZ1bmN0aW9uKSB7XHJcbiAgICAgICAgICAgIHJldHVybkZ1bmN0aW9uKGRhdGEpXHJcbiAgICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIGJhcjtcclxuXHJcbiAgICBmdW5jdGlvbiBvblByb2dyZXNzKGNvbXBsZXRlZCwgdG90YWwsIHJlc3BvbnNlLCBpbmRleCkge1xyXG4gICAgICAgIGNvbnN0IHByb2dyZXNzID0gTWF0aC5mbG9vcihjb21wbGV0ZWQgLyB0b3RhbCAqIDEwMCk7XHJcbiAgICAgICAgcGVyY2VudC50ZXh0Q29udGVudCA9IHByb2dyZXNzICsgJyUnO1xyXG4gICAgICAgIGJhci5zdHlsZS5iYWNrZ3JvdW5kID0gYGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgI2ZmYTAwMCAke3Byb2dyZXNzfSUsICNlZWUgMClgO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCB7XHJcbiAgICBlbGVtZW50XHJcbn07IiwiLyogZ2xvYmFscyB4bHN4LCBKU1ppcCAqL1xyXG5cclxuaW1wb3J0IHBhcnNlIGZyb20gJy4vcGFyc2UnO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGltcG9ydFF1aXpGcm9tWGxzeChibG9iKSB7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XHJcbiAgICAgICAgcmVhZGVyLm9ubG9hZCA9IGZ1bmN0aW9uIChlKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGZpbGVEYXRhID0gZS50YXJnZXQucmVzdWx0O1xyXG4gICAgICAgICAgICBjb25zdCB3YiA9IHhsc3gucmVhZChmaWxlRGF0YSwge1xyXG4gICAgICAgICAgICAgICAgdHlwZTogJ2JpbmFyeSdcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIGNvbnN0IGZpcnN0U2hlZXQgPSB3Yi5TaGVldHNbd2IuU2hlZXROYW1lc1swXV07XHJcbiAgICAgICAgICAgIGNvbnN0IGFwaURhdGEgPSB4bHN4LnV0aWxzXHJcbiAgICAgICAgICAgICAgICAuc2hlZXRfdG9fanNvbihmaXJzdFNoZWV0LCB7IGhlYWRlcjogMSB9KVxyXG4gICAgICAgICAgICAgICAgLnNsaWNlKDEpIC8vIHJlbW92ZSBmaXJzdCByb3dcclxuICAgICAgICAgICAgICAgIC5yZWR1Y2UoKGRhdGEsIGN1cnJlbnRSb3cpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoY3VycmVudFJvdy5sZW5ndGggIT09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY29ycmVjdEFuc3dlckluZGV4ID0gY3VycmVudFJvdy5wb3AoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcXVlc3Rpb24gPSBjdXJyZW50Um93WzBdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBhbGxBbnN3ZXJzID0gY3VycmVudFJvdy5zbGljZSgxKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY29ycmVjdEFuc3dlciA9IGN1cnJlbnRSb3dbY29ycmVjdEFuc3dlckluZGV4XTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGFbcXVlc3Rpb25dID0gYWxsQW5zd2Vycy5yZWR1Y2UoKGFuc3dlcnMsIGEpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChhICE9IHVuZGVmaW5lZCAmJiBhLnRvU3RyaW5nKCkudHJpbSgpICE9PSAnJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcnNbYV0gPSBhID09PSBjb3JyZWN0QW5zd2VyO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBhbnN3ZXJzO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LCB7fSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZGF0YTtcclxuICAgICAgICAgICAgICAgIH0sIHt9KTtcclxuXHJcbiAgICAgICAgICAgIHJlc29sdmUoYXBpRGF0YSk7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgcmVhZGVyLnJlYWRBc0JpbmFyeVN0cmluZyhibG9iKTtcclxuICAgIH0pO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaW1wb3J0RnJvbVhsc3goYmxvYiwgdXNlQ2VsbERhdGVzID0gZmFsc2UpIHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcclxuICAgICAgICByZWFkZXIub25sb2FkID0gZnVuY3Rpb24gKGUpIHtcclxuICAgICAgICAgICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LnJlc3VsdDtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHdiID0geGxzeC5yZWFkKGZpbGUsIHtcclxuICAgICAgICAgICAgICAgICAgICB0eXBlOiAnYmluYXJ5JyxcclxuICAgICAgICAgICAgICAgICAgICBjZWxsRGF0ZXM6IHVzZUNlbGxEYXRlc1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBmaXJzdFNoZWV0ID0gd2IuU2hlZXRzW3diLlNoZWV0TmFtZXNbMF1dO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgZGF0YSA9IHhsc3gudXRpbHMuc2hlZXRfdG9fanNvbihmaXJzdFNoZWV0LCB7IGhlYWRlcjogMSB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICByZXNvbHZlKGRhdGEpO1xyXG4gICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdFcnJvciBwYXJzaW5nIFhMU1ggZmlsZSwgbWFrZSBzdXJlIHRoZSBsaWJyYXJ5IGlzIGxvYWRlZCcpO1xyXG4gICAgICAgICAgICAgICAgcmVqZWN0KGVycik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgICAgIHJlYWRlci5vbmVycm9yID0gZnVuY3Rpb24gKGUpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ0Vycm9yIHJlYWRpbmcgZmlsZScpO1xyXG4gICAgICAgICAgICByZWplY3QoZSk7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgcmVhZGVyLnJlYWRBc0JpbmFyeVN0cmluZyhibG9iKTtcclxuICAgIH0pO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdG9YbHN4RmlsZSh0YWJsZSwgbmFtZSA9ICdPdXRwdXQnLCB3c19uYW1lKSB7XHJcbiAgICBpZiAod3NfbmFtZSA9PT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgd3NfbmFtZSA9IG5hbWUuc2xpY2UoMCwgMzEpO1xyXG4gICAgfVxyXG4gICAgY29uc3Qgd2IgPSB4bHN4LnV0aWxzLmJvb2tfbmV3KCksIHdzID0geGxzeC51dGlscy5hb2FfdG9fc2hlZXQodGFibGUpO1xyXG4gICAgLy8gd2IuV29ya2Jvb2sgPSB7IFZpZXdzOiBbJ1dpbmRvdzInXSB9O1xyXG4gICAgeGxzeC51dGlscy5ib29rX2FwcGVuZF9zaGVldCh3Yiwgd3MsIHdzX25hbWUpO1xyXG4gICAgY29uc3QgZGF0YSA9IHhsc3gud3JpdGUod2IsIHtcclxuICAgICAgICB0eXBlOiAnYXJyYXknLFxyXG4gICAgICAgIGJvb2tUeXBlOiAneGxzeCdcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IGZpbGUgPSBuZXcgRmlsZShbZGF0YV0sIG5hbWUgKyAnLnhsc3gnLCB7IHR5cGU6ICdhcHBsaWNhdGlvbi92bmQub3BlbnhtbGZvcm1hdHMtb2ZmaWNlZG9jdW1lbnQuc3ByZWFkc2hlZXRtbC5zaGVldCcgfSk7XHJcblxyXG4gICAgcmV0dXJuIGZpbGU7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiB0b0xlZ2FjeVhsc0ZpbGUodGFibGUsIG5hbWUgPSAnT3V0cHV0Jywgd3NfbmFtZSkge1xyXG4gICAgaWYgKHdzX25hbWUgPT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgIHdzX25hbWUgPSBuYW1lLnNsaWNlKDAsIDMxKTtcclxuICAgIH1cclxuICAgIGNvbnN0IHdiID0geGxzeC51dGlscy5ib29rX25ldygpLCB3cyA9IHhsc3gudXRpbHMuYW9hX3RvX3NoZWV0KHRhYmxlKTtcclxuICAgIHdiLldvcmtib29rID0geyBWaWV3czogWydXaW5kb3cyJ10gfTtcclxuICAgIHhsc3gudXRpbHMuYm9va19hcHBlbmRfc2hlZXQod2IsIHdzLCB3c19uYW1lKTtcclxuICAgIGNvbnN0IGRhdGEgPSB4bHN4LndyaXRlKHdiLCB7XHJcbiAgICAgICAgdHlwZTogJ2FycmF5JyxcclxuICAgICAgICBib29rVHlwZTogJ2JpZmY4J1xyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgZmlsZSA9IG5ldyBGaWxlKFtkYXRhXSwgbmFtZSArICcueGxzJywgeyB0eXBlOiAnYXBwbGljYXRpb24vdm5kLm1zLWV4Y2VsJyB9KTtcclxuXHJcbiAgICByZXR1cm4gZmlsZTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGV4cG9ydFRvWGxzeCh0YWJsZSwgbmFtZSA9ICdPdXRwdXQnLCB3c19uYW1lKSB7XHJcbiAgICBjb25zdCBmaWxlbmFtZSA9IGAke25hbWV9Lnhsc3hgO1xyXG4gICAgaWYgKHdzX25hbWUgPT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgIHdzX25hbWUgPSBuYW1lLnNsaWNlKDAsIDMxKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBTaGVldCBuYW1lIGNhbm5vdCBjb250YWluOiBcXCAvID8gKiBbIF1cclxuICAgIGNvbnN0IHNoZWV0UmVnZXggPSAvW1xcW1xcXVxcXFxcXC9cXCpdL2dpO1xyXG4gICAgaWYgKHNoZWV0UmVnZXgudGVzdCh3c19uYW1lKSkge1xyXG4gICAgICAgIHdzX25hbWUgPSB3c19uYW1lLnJlcGxhY2Uoc2hlZXRSZWdleCwgJy0nKTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCB3YiA9IHhsc3gudXRpbHMuYm9va19uZXcoKSwgd3MgPSB4bHN4LnV0aWxzLmFvYV90b19zaGVldCh0YWJsZSk7XHJcbiAgICB4bHN4LnV0aWxzLmJvb2tfYXBwZW5kX3NoZWV0KHdiLCB3cywgd3NfbmFtZSk7XHJcbiAgICB4bHN4LndyaXRlRmlsZSh3YiwgZmlsZW5hbWUpO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZXhwb3J0UGF5bWVudHNUb1hsc3goZGF0YSwgeWVhciwgbW9udGgpIHtcclxuICAgIGNvbnN0IGZpbGVuYW1lID0gYFBheW1lbnRzLSR7cGFyc2UubW9udGhOYW1lW21vbnRoXX0tJHt5ZWFyfS54bHN4YDtcclxuICAgIGNvbnN0IHdzX25hbWUgPSBgUGF5bWVudHMgJHtwYXJzZS5tb250aE5hbWVbbW9udGhdfSAke3llYXJ9YDtcclxuICAgIGNvbnN0IHdiID0geGxzeC51dGlscy5ib29rX25ldygpLCB3cyA9IHhsc3gudXRpbHMuYW9hX3RvX3NoZWV0KGRhdGEpO1xyXG4gICAgeGxzeC51dGlscy5ib29rX2FwcGVuZF9zaGVldCh3Yiwgd3MsIHdzX25hbWUpO1xyXG4gICAgeGxzeC53cml0ZUZpbGUod2IsIGZpbGVuYW1lKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGV4cG9ydFRvSnNvbihkYXRhLCBuYW1lID0gJ091dHB1dCcpIHtcclxuICAgIGNvbnN0IGJsb2IgPSBuZXcgQmxvYihbZGF0YV0sIHsgdHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nIH0pO1xyXG4gICAgaWYgKHdpbmRvdy5uYXZpZ2F0b3IubXNTYXZlT3JPcGVuQmxvYikge1xyXG4gICAgICAgIHdpbmRvdy5uYXZpZ2F0b3IubXNTYXZlQmxvYihibG9iLCBuYW1lICsgJy5qc29uJyk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIHZhciBlbGVtID0gd2luZG93LmRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcclxuICAgICAgICBlbGVtLmhyZWYgPSB3aW5kb3cuVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTtcclxuICAgICAgICBlbGVtLmRvd25sb2FkID0gbmFtZSArICcuanNvbic7XHJcbiAgICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChlbGVtKTtcclxuICAgICAgICBlbGVtLmNsaWNrKCk7XHJcbiAgICAgICAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChlbGVtKTtcclxuICAgIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIEBwYXJhbSB7e2ZvbGRlcjogc3RyaW5nLCBmaWxlczogRmlsZVtdfVtdfSBmaWxlcyBcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB6aXBGaWxlcyhmaWxlcykge1xyXG4gICAgY29uc3QgemlwID0gbmV3IEpTWmlwKCk7XHJcbiAgICBmb3IgKGxldCBlbnRyeSBvZiBmaWxlcykge1xyXG4gICAgICAgIGNvbnN0IGN1cnJlbnQgPSB6aXAuZm9sZGVyKGVudHJ5LmZvbGRlcik7XHJcbiAgICAgICAgY3VycmVudC5maWxlKGVudHJ5LmZpbGVzLnBob3RvLm5hbWUsIGF3YWl0IGJsb2JUb0Jhc2U2NChlbnRyeS5maWxlcy5waG90by5maWxlKSwgeyBiYXNlNjQ6IHRydWUgfSk7XHJcbiAgICAgICAgY3VycmVudC5maWxlKGVudHJ5LmZpbGVzLm1lZGljYWwubmFtZSwgYXdhaXQgYmxvYlRvQmFzZTY0KGVudHJ5LmZpbGVzLm1lZGljYWwuZmlsZSksIHsgYmFzZTY0OiB0cnVlIH0pO1xyXG4gICAgICAgIGN1cnJlbnQuZmlsZShlbnRyeS5maWxlcy5kaXBsb21hLm5hbWUsIGF3YWl0IGJsb2JUb0Jhc2U2NChlbnRyeS5maWxlcy5kaXBsb21hLmZpbGUpLCB7IGJhc2U2NDogdHJ1ZSB9KTtcclxuICAgIH1cclxuICAgIHJldHVybiB6aXAuZ2VuZXJhdGVBc3luYyh7IHR5cGU6ICdibG9iJyB9KTtcclxuXHJcbiAgICBmdW5jdGlvbiBibG9iVG9CYXNlNjQoYmxvYikge1xyXG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShyZXNvbHZlID0+IHtcclxuICAgICAgICAgICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcclxuICAgICAgICAgICAgcmVhZGVyLm9ubG9hZCA9IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGRhdGFVcmwgPSByZWFkZXIucmVzdWx0O1xyXG4gICAgICAgICAgICAgICAgY29uc3QgYmFzZTY0ID0gZGF0YVVybC5zcGxpdCgnLCcpWzFdO1xyXG4gICAgICAgICAgICAgICAgcmVzb2x2ZShiYXNlNjQpO1xyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICByZWFkZXIucmVhZEFzRGF0YVVSTChibG9iKTtcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcbn1cclxuXHJcbmNvbnN0IG1pbWVzID0ge1xyXG4gICAgJ2JtcCc6ICdpbWFnZS9ibXAnLFxyXG4gICAgJ2dpZic6ICdpbWFnZS9naWYnLFxyXG4gICAgJ2pwZWcnOiAnaW1hZ2UvanBlZycsXHJcbiAgICAnanBnJzogJ2ltYWdlL2pwZWcnLFxyXG4gICAgJ3BuZyc6ICdpbWFnZS9wbmcnLFxyXG4gICAgJ3BkZic6ICdhcHBsaWNhdGlvbi9wZGYnLFxyXG4gICAgJ3RpZic6ICdpbWFnZS90aWZmJyxcclxuICAgICd0aWZmJzogJ2ltYWdlL3RpZmYnLFxyXG4gICAgJ3dlYnAnOiAnaW1hZ2Uvd2VicCcsXHJcbiAgICAnemlwJzogJ2FwcGxpY2F0aW9uL3ppcCcsXHJcbiAgICAnN3onOiAnYXBwbGljYXRpb24veC03ei1jb21wcmVzc2VkJyxcclxuICAgICd0YXInOiAnYXBwbGljYXRpb24veC10YXInLFxyXG4gICAgJ3Jhcic6ICdhcHBsaWNhdGlvbi92bmQucmFyJ1xyXG59O1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGdldE1pbWUoZXh0ZW5zaW9uKSB7XHJcbiAgICBleHRlbnNpb24gPSBleHRlbnNpb24udG9Mb2NhbGVMb3dlckNhc2UoKTtcclxuICAgIHJldHVybiBtaW1lc1tleHRlbnNpb25dIHx8ICdhcHBsaWNhdGlvbi9vY3RldC1zdHJlYW0nO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gb3BlbkZpbGUoZmlsZSwgbmFtZSA9ICdvdXRwdXQudHh0Jykge1xyXG4gICAgdHJ5IHtcclxuICAgICAgICB2YXIgZWxlbSA9IHdpbmRvdy5kb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XHJcbiAgICAgICAgZWxlbS50YXJnZXQgPSAnX2JsYW5rJztcclxuICAgICAgICBlbGVtLmRvd25sb2FkID0gbmFtZTtcclxuICAgICAgICBjb25zdCBocmVmID0gd2luZG93LlVSTC5jcmVhdGVPYmplY3RVUkwoZmlsZSk7XHJcbiAgICAgICAgZWxlbS5ocmVmID0gaHJlZjtcclxuICAgICAgICBlbGVtLmNsaWNrKCk7XHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiBVUkwucmV2b2tlT2JqZWN0VVJMKGhyZWYpLCA2MDAwMCk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBkb3dubG9hZChibG9iLCBuYW1lID0gJ291dHB1dC50eHQnKSB7XHJcbiAgICBpZiAod2luZG93Lm5hdmlnYXRvci5tc1NhdmVPck9wZW5CbG9iKSB7XHJcbiAgICAgICAgd2luZG93Lm5hdmlnYXRvci5tc1NhdmVCbG9iKGJsb2IsIG5hbWUpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICB2YXIgZWxlbSA9IHdpbmRvdy5kb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XHJcbiAgICAgICAgZWxlbS50YXJnZXQgPSAnX2JsYW5rJztcclxuICAgICAgICBjb25zdCBocmVmID0gd2luZG93LlVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYik7XHJcbiAgICAgICAgZWxlbS5ocmVmID0gaHJlZjtcclxuICAgICAgICBlbGVtLmRvd25sb2FkID0gbmFtZTtcclxuICAgICAgICBlbGVtLmNsaWNrKCk7XHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiBVUkwucmV2b2tlT2JqZWN0VVJMKGhyZWYpLCA2MDAwMCk7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcm9zc0Jyb3dzZXJGaWxlVXBsb2FkKGFwaUNhbGwsIGZpbGUpIHtcclxuICAgIGlmICghIXdpbmRvdy5jaHJvbWUpIHtcclxuICAgICAgICBjb25zdCBmaWxlVXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChmaWxlKTtcclxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBhcGlDYWxsKHsgZmlsZVVybCwgbmFtZTogZmlsZS5uYW1lIH0pO1xyXG4gICAgICAgIFVSTC5yZXZva2VPYmplY3RVUkwoZmlsZVVybCk7XHJcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIGF3YWl0IGFwaUNhbGwoeyBmaWxlIH0pO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0U3Vic2l0ZSgpIHtcclxuICAgIHN3aXRjaCAod2luZG93LmxvY2F0aW9uLmhvc3Quc3Vic3RyKDAsIDcpKSB7XHJcbiAgICAgICAgY2FzZSAnZGlnaXRhbCc6XHJcbiAgICAgICAgICAgIHJldHVybiAnZGlnaXRhbCc7XHJcbiAgICAgICAgY2FzZSAnY3JlYXRpdic6XHJcbiAgICAgICAgICAgIHJldHVybiAnY3JlYXRpdmUnO1xyXG4gICAgICAgIGNhc2UgJ3BsYXRmb3InOlxyXG4gICAgICAgICAgICByZXR1cm4gJ3BsYXRmb3JtJztcclxuICAgICAgICBjYXNlICdhaS5zb2Z0JzpcclxuICAgICAgICAgICAgcmV0dXJuICdhaSc7XHJcbiAgICAgICAgY2FzZSAnZmluYW5jZSc6XHJcbiAgICAgICAgICAgIHJldHVybiAnZmluYW5jZWFjYWRlbXknO1xyXG4gICAgICAgIGNhc2UgJ2Rldi5kaWcnOlxyXG4gICAgICAgICAgICByZXR1cm4gJ2RldmRpZ2l0YWwnO1xyXG4gICAgICAgIGNhc2UgJ2Rldi5zb2YnOlxyXG4gICAgICAgICAgICByZXR1cm4gJ2RldnNvZnR1bmknO1xyXG4gICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgIHJldHVybiAncHJvZ3JhbW1pbmcnO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaGFzQ1BPQWNjZXNzKCkge1xyXG4gICAgcmV0dXJuIFsnZGlnaXRhbCcsICdjcmVhdGl2ZScsICdwcm9ncmFtbWluZycsICdkZXZkaWdpdGFsJywgJ2RldnNvZnR1bmknXS5pbmNsdWRlcyhnZXRTdWJzaXRlKCkpO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaXNBZG1pbigpIHtcclxuICAgIGNvbnN0IGUgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCdhW2hyZWY9XCIvYWRtaW5pc3RyYXRpb24vbmF2aWdhdGlvblwiIGldJyk7XHJcbiAgICBpZiAoZS5sZW5ndGggPiAwKSB7IHJldHVybiB0cnVlOyB9XHJcbiAgICBlbHNlIHsgcmV0dXJuIGZhbHNlOyB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBzZXJpYWxpemVDYWxscyhmbkFycmF5LCBkZWxheSkge1xyXG4gICAgY29uc3QgY2FsbEFycmF5ID0gW107XHJcblxyXG4gICAgaWYgKGRlbGF5ICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGZuQXJyYXkubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgY29uc3QgaGFuZGxlciA9IChyZXMsIHJlaikgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0VGltZW91dChhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZm5BcnJheVtpXSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXMocmVzdWx0KTtcclxuICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVqKGVycik7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSwgaSAqIGRlbGF5KTtcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgY29uc3QgcHIgPSBuZXcgUHJvbWlzZShoYW5kbGVyKTtcclxuXHJcbiAgICAgICAgICAgIGNhbGxBcnJheS5wdXNoKHByKTtcclxuICAgICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZm5BcnJheS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBjb25zdCBoYW5kbGVyID0gKHJlcywgcmVqKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoaSA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICBjYWxsQXJyYXlbaSAtIDFdLmZpbmFsbHkoYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZm5BcnJheVtpXSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzKHJlc3VsdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVqKGVycik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZm5BcnJheVtpXSgpLnRoZW4ocmVzKS5jYXRjaChyZWopO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBjb25zdCBwciA9IG5ldyBQcm9taXNlKGhhbmRsZXIpO1xyXG5cclxuICAgICAgICAgICAgY2FsbEFycmF5LnB1c2gocHIpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gY2FsbEFycmF5O1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gd2l0aFByb2dyZXNzKGNhbGxBcnJheSwgb25DaGFuZ2UsIGRlbGF5ID0gMTApIHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgLy8gRmFpbHNhdmUgZm9yIGVtcHR5IGNhbGxBcnJheVxyXG4gICAgICAgIGlmIChjYWxsQXJyYXkubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgb25DaGFuZ2UodW5kZWZpbmVkLCAwLCAxLCAxKTtcclxuICAgICAgICAgICAgcmVzb2x2ZShbXSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgcmVzb2x2ZWQgPSAwO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gW107XHJcbiAgICAgICAgY2FsbE5leHQoMCk7XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIGNhbGxOZXh0KGkpIHtcclxuICAgICAgICAgICAgaWYgKGkgPj0gY2FsbEFycmF5Lmxlbmd0aCkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY2FsbEFycmF5W2ldXHJcbiAgICAgICAgICAgICAgICAgICAgLnRoZW4ocmVzID0+IG9uUmVzb2x2ZShyZXMsIGkpKVxyXG4gICAgICAgICAgICAgICAgICAgIC5jYXRjaChvbkVycm9yKTtcclxuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4gY2FsbE5leHQoaSArIDEpLCBkZWxheSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIG9uUmVzb2x2ZShyZXMsIGluZGV4KSB7XHJcbiAgICAgICAgICAgIHJlc29sdmVkKys7XHJcbiAgICAgICAgICAgIGlmIChvbkNoYW5nZSkge1xyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2UocmVzLCBpbmRleCwgcmVzb2x2ZWQsIGNhbGxBcnJheS5sZW5ndGgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJlc3BvbnNlW2luZGV4XSA9IHJlcztcclxuICAgICAgICAgICAgaWYgKHJlc29sdmVkID09PSBjYWxsQXJyYXkubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgICAgICByZXNvbHZlKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZnVuY3Rpb24gb25FcnJvcihlKSB7XHJcbiAgICAgICAgICAgIHJlamVjdChlKTtcclxuICAgICAgICB9XHJcbiAgICB9KTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEB0eXBlZGVmIHsoY29tcGxldGVkOiBudW1iZXIsIHRvdGFsOiBudW1iZXIsIHJlc3BvbnNlLCBpbmRleDogbnVtYmVyKSA9PiB2b2lkfSBPblByb2dyZXNzRnVuY3Rpb25cclxuICovXHJcblxyXG4vKipcclxuICogQHR5cGVkZWYgeygpID0+IFByb21pc2V9IEFzeW5jRnVuY3Rpb25cclxuICovXHJcblxyXG4vKipcclxuICogSW5pdGlhdGUgcmVtb3RlIGNhbGxzIGF0IGludGVydmFsc1xyXG4gKiBAcGFyYW0ge0FycmF5PEFzeW5jRnVuY3Rpb24+fSBmbkFycmF5IFxyXG4gKiBAcGFyYW0ge09uUHJvZ3Jlc3NGdW5jdGlvbn0gb25Qcm9ncmVzcyBcclxuICogQHBhcmFtIHtudW1iZXJ9IFtkZWxheT0xMF1cclxuICogQHJldHVybnMgXHJcbiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGlzdHJpYnV0ZShmbkFycmF5LCBvblByb2dyZXNzLCBkZWxheSA9IDEwKSB7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHRvdGFsID0gZm5BcnJheS5sZW5ndGg7XHJcbiAgICAgICAgbGV0IGNvbXBsZXRlZCA9IDA7XHJcbiAgICAgICAgbGV0IHJlc29sdmVkID0gMDtcclxuXHJcbiAgICAgICAgLy8gRmFpbHNhdmUgZm9yIGVtcHR5IGZuQXJyYXlcclxuICAgICAgICBpZiAodG90YWwgPT0gMCkge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIG9uUHJvZ3Jlc3MgPT0gJ2Z1bmN0aW9uJykge1xyXG4gICAgICAgICAgICAgICAgb25Qcm9ncmVzcyh1bmRlZmluZWQsIDAsIDEsIDEpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJlc29sdmUoW10pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgY2FsbHMgPSBmbkFycmF5Lm1hcCgoZm4sIGkpID0+IHtcclxuICAgICAgICAgICAgY29uc3QgY2FsbCA9IHtcclxuICAgICAgICAgICAgICAgIGZuLFxyXG4gICAgICAgICAgICAgICAgc2VudDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICBjYW5jZWxsZWQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2U6IHVuZGVmaW5lZCxcclxuICAgICAgICAgICAgICAgIHRpbWVyOiBudWxsLFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBjYWxsLm9uQ2FsbCA9IG9uQ2FsbC5iaW5kKGNhbGwsIGkpO1xyXG4gICAgICAgICAgICBjYWxsLmNhbmNlbCA9IG9uQ2FuY2VsLmJpbmQoY2FsbCk7XHJcbiAgICAgICAgICAgIGNhbGwudGltZXIgPSBzZXRUaW1lb3V0KGNhbGwub25DYWxsLCBpICogZGVsYXkpO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuIGNhbGw7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgY2FsbHMuZm9yRWFjaCgoYywgaSkgPT4gYy5uZXh0ID0gY2FsbHNbaSArIDFdKTtcclxuXHJcbiAgICAgICAgYXN5bmMgZnVuY3Rpb24gb25DYWxsKGkpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuc2VudCA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgY2xlYXJUaW1lb3V0KHRoaXMudGltZXIpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNhbmNlbGxlZCA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zZW50ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcHJvbWlzZSA9IHRoaXMuZm4oKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnJlc3BvbnNlID0gYXdhaXQgcHJvbWlzZTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocHJvbWlzZS5fY2FjaGVIaXQgJiYgdGhpcy5uZXh0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubmV4dC5vbkNhbGwoKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZWQrKztcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5jYW5jZWxsZWQgPT0gZmFsc2UgJiYgcmVzb2x2ZWQgPT09IHRvdGFsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUoY2FsbHMubWFwKGMgPT4gYy5yZXNwb25zZSkpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICAgICAgICAgIG9uRXJyb3IoZXJyKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjb21wbGV0ZWQrKztcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBvblByb2dyZXNzID09ICdmdW5jdGlvbicpIHtcclxuICAgICAgICAgICAgICAgIG9uUHJvZ3Jlc3MoY29tcGxldGVkLCB0b3RhbCwgdGhpcy5yZXNwb25zZSwgaSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIG9uQ2FuY2VsKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jYW5jZWxsZWQgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY2FuY2VsbGVkID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLnNlbnQgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICBjbGVhclRpbWVvdXQodGhpcy50aW1lcik7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5vbkNhbGwoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZnVuY3Rpb24gb25FcnJvcihlKSB7XHJcbiAgICAgICAgICAgIGNhbGxzLmZvckVhY2goYyA9PiBjLmNhbmNlbCgpKTtcclxuICAgICAgICAgICAgaWYgKGUgaW5zdGFuY2VvZiBFcnJvcikge1xyXG4gICAgICAgICAgICAgICAgZS5fcmVzcG9uc2VzID0gY2FsbHMubWFwKGMgPT4gYy5yZXNwb25zZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmVqZWN0KGUpO1xyXG4gICAgICAgIH1cclxuICAgIH0pO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gYXNzZXJ0VGVtcGxhdGUodGVtcGxhdGUsIHRhcmdldCwgYm90dG9tID0gZmFsc2UpIHtcclxuICAgIGlmICh0ZW1wbGF0ZS5EYXRhICE9PSB1bmRlZmluZWQgJiYgdGVtcGxhdGUuVG90YWwgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgIHRlbXBsYXRlID0gdGVtcGxhdGUuRGF0YTtcclxuICAgICAgICB0YXJnZXQgPSB0YXJnZXQuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoQXJyYXkuaXNBcnJheSh0ZW1wbGF0ZSkpIHtcclxuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheSh0YXJnZXQpKSB7XHJcbiAgICAgICAgICAgIGlmIChib3R0b20pIHtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGFzc2VydFRlbXBsYXRlKHRlbXBsYXRlWzBdLCB0YXJnZXRbMF0sIHRydWUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignVGFyZ2V0IHR5cGUgbWlzbWF0Y2gnKTtcclxuICAgICAgICB9XHJcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiB0ZW1wbGF0ZSA9PT0gJ29iamVjdCcpIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRhcmdldCA9PT0gJ29iamVjdCcpIHtcclxuICAgICAgICAgICAgY29uc3QgbW9kZWwgPSBPYmplY3Qua2V5cyh0ZW1wbGF0ZSk7XHJcbiAgICAgICAgICAgIGZvciAobGV0IHByb3Agb2YgbW9kZWwpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0YXJnZXQuaGFzT3duUHJvcGVydHkocHJvcCkgPT09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignTWlzc2luZyBwcm9wZXJ0eSBvbiB0YXJnZXQ6ICcgKyBwcm9wKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1RhcmdldCB0eXBlIG1pc21hdGNoJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfSBlbHNlIGlmICh0eXBlb2YgdGVtcGxhdGUgIT09IHR5cGVvZiB0YXJnZXQpIHtcclxuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdUYXJnZXQgdHlwZSBtaXNtYXRjaCcpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGdldExvY2FsZSgpIHtcclxuICAgIHJldHVybiAnYmcnO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlVGhyb3R0bGVkRXhlY3V0b3IoY2FsbGJhY2ssIGRlbGF5KSB7XHJcbiAgICBsZXQgdGltZXIgPSBudWxsO1xyXG5cclxuICAgIHJldHVybiBmdW5jdGlvbiAoLi4ucGFyYW1zKSB7XHJcbiAgICAgICAgY2xlYXIoKTtcclxuICAgICAgICB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICBjbGVhcigpO1xyXG4gICAgICAgICAgICBjYWxsYmFjayguLi5wYXJhbXMpO1xyXG4gICAgICAgIH0sIGRlbGF5KTtcclxuICAgIH07XHJcblxyXG4gICAgZnVuY3Rpb24gY2xlYXIoKSB7XHJcbiAgICAgICAgaWYgKHRpbWVyICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aW1lcik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaWNvbkFzc2V0KG5hbWUpIHtcclxuICAgIHJldHVybiBicm93c2VyLnJ1bnRpbWUuZ2V0VVJMKGBpY29ucy8ke25hbWV9LnBuZ2ApO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZXNjYXBlSFRNTChzdHIpIHtcclxuICAgIHJldHVybiBzdHIucmVwbGFjZSgvWyY8Pl0vZyxcclxuICAgICAgICB0YWcgPT4gKHtcclxuICAgICAgICAgICAgJyYnOiAnJmFtcDsnLFxyXG4gICAgICAgICAgICAnPCc6ICcmbHQ7JyxcclxuICAgICAgICAgICAgJz4nOiAnJmd0OydcclxuICAgICAgICB9W3RhZ10pKVxyXG59O1xyXG5cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRGdW5kYW1lbnRhbExldmVsSWRzKGFwcG5hbWUpIHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgJ3Byb2dyYW1taW5nJzogW1xyXG4gICAgICAgICAgICAxOSxcclxuICAgICAgICAgICAgNDQsXHJcbiAgICAgICAgICAgIDU3LFxyXG4gICAgICAgICAgICA3MCxcclxuICAgICAgICAgICAgMTA2XHJcbiAgICAgICAgXSxcclxuICAgICAgICAnZGlnaXRhbCc6IFtcclxuICAgICAgICAgICAgNixcclxuICAgICAgICAgICAgNyxcclxuICAgICAgICAgICAgOCxcclxuICAgICAgICAgICAgMjMsXHJcbiAgICAgICAgICAgIDI0LFxyXG4gICAgICAgICAgICAyNSxcclxuICAgICAgICAgICAgMjcsXHJcbiAgICAgICAgICAgIDMzLFxyXG4gICAgICAgICAgICAzNSxcclxuICAgICAgICAgICAgNDBcclxuICAgICAgICBdLFxyXG4gICAgICAgICdjcmVhdGl2ZSc6IFtcclxuICAgICAgICAgICAgMjMsXHJcbiAgICAgICAgICAgIDI0LFxyXG4gICAgICAgICAgICA0MixcclxuICAgICAgICAgICAgNTJcclxuICAgICAgICBdXHJcbiAgICB9W2FwcG5hbWVdO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0UHJvZmVzc2lvbkluc3RhbmNlSWRzKGFwcG5hbWUpIHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgLy8gQ29tbWVudGVkIGFyZSBmb3IgUUFcclxuICAgICAgICAncHJvZ3JhbW1pbmcnOiBbXHJcbiAgICAgICAgICAgIDEwMDcsXHJcbiAgICAgICAgICAgIDEwMDksXHJcbiAgICAgICAgICAgIDEwMTAsXHJcbiAgICAgICAgICAgIDEwMTEsXHJcbiAgICAgICAgICAgIDEwMTIsXHJcbiAgICAgICAgICAgIDEwMTMsXHJcbiAgICAgICAgICAgIDEwMTQsXHJcbiAgICAgICAgICAgIDEwMTUsXHJcbiAgICAgICAgICAgIDEwMTYsXHJcbiAgICAgICAgICAgIDEwMTcsXHJcbiAgICAgICAgICAgIDEwMTgsXHJcbiAgICAgICAgICAgIDEwMjAsXHJcbiAgICAgICAgICAgIDEwMjIsXHJcbiAgICAgICAgICAgIDEwMjMsXHJcbiAgICAgICAgICAgIDEwMjQsXHJcbiAgICAgICAgICAgIDEwMjUsXHJcbiAgICAgICAgICAgIDEwMjYsXHJcbiAgICAgICAgICAgIC8vIDEwMjgsXHJcbiAgICAgICAgICAgIDEwMjksXHJcbiAgICAgICAgICAgIDEwMzAsXHJcbiAgICAgICAgICAgIDEwMzEsXHJcbiAgICAgICAgICAgIDEwMzIsXHJcbiAgICAgICAgICAgIDEwMzMsXHJcbiAgICAgICAgICAgIDEwMzQsXHJcbiAgICAgICAgICAgIDEwMzUsXHJcbiAgICAgICAgICAgIDEwMzYsXHJcbiAgICAgICAgICAgIDEwMzcsXHJcbiAgICAgICAgICAgIDEwMzgsXHJcbiAgICAgICAgICAgIDEwMzksXHJcbiAgICAgICAgICAgIDEwNDAsXHJcbiAgICAgICAgICAgIDEwNDEsXHJcbiAgICAgICAgICAgIDEwNDIsXHJcbiAgICAgICAgICAgIDEwNDMsXHJcbiAgICAgICAgICAgIDEwNDQsXHJcbiAgICAgICAgICAgIDEwNDUsXHJcbiAgICAgICAgICAgIDEwNDYsXHJcbiAgICAgICAgICAgIDEwNDcsXHJcbiAgICAgICAgICAgIDEwNDgsXHJcbiAgICAgICAgICAgIDEwNDksXHJcbiAgICAgICAgICAgIDEwNTAsXHJcbiAgICAgICAgICAgIDEwNTEsXHJcbiAgICAgICAgICAgIDEwNTIsXHJcbiAgICAgICAgICAgIDEwNTMsXHJcbiAgICAgICAgICAgIDEwNTQsXHJcbiAgICAgICAgICAgIDEwNTUsXHJcbiAgICAgICAgICAgIDEwNTYsXHJcbiAgICAgICAgICAgIDEwNTcsXHJcbiAgICAgICAgICAgIDEwNTgsXHJcbiAgICAgICAgICAgIDEwNTksXHJcbiAgICAgICAgICAgIDEwNjAsXHJcbiAgICAgICAgICAgIDEwNjEsXHJcbiAgICAgICAgICAgIDEwNjIsXHJcbiAgICAgICAgICAgIDEwNjMsXHJcbiAgICAgICAgICAgIDEwNjQsXHJcbiAgICAgICAgICAgIDEwNjUsXHJcbiAgICAgICAgICAgIDEwNjYsXHJcbiAgICAgICAgICAgIC8vIDEwNjcsXHJcbiAgICAgICAgICAgIC8vIDEwNjgsXHJcbiAgICAgICAgICAgIC8vIDEwNjksXHJcbiAgICAgICAgICAgIDEwNzAsXHJcbiAgICAgICAgICAgIDEwNzEsXHJcbiAgICAgICAgICAgIDEwNzIsXHJcbiAgICAgICAgICAgIDEwNzMsXHJcbiAgICAgICAgICAgIDEwNzQsXHJcbiAgICAgICAgICAgIDEwNzUsXHJcbiAgICAgICAgICAgIDEwNzYsXHJcbiAgICAgICAgICAgIDEwNzcsXHJcbiAgICAgICAgICAgIDEwNzhcclxuICAgICAgICBdLFxyXG4gICAgICAgICdkaWdpdGFsJzogW1xyXG4gICAgICAgICAgICAxLFxyXG4gICAgICAgICAgICAzLFxyXG4gICAgICAgICAgICA0LFxyXG4gICAgICAgICAgICA1LFxyXG4gICAgICAgICAgICA2LFxyXG4gICAgICAgICAgICA3LFxyXG4gICAgICAgICAgICA4LFxyXG4gICAgICAgICAgICA5XHJcbiAgICAgICAgXSxcclxuICAgICAgICAnY3JlYXRpdmUnOiBbXHJcbiAgICAgICAgICAgIDEsXHJcbiAgICAgICAgICAgIDMsXHJcbiAgICAgICAgICAgIDQsXHJcbiAgICAgICAgICAgIDVcclxuICAgICAgICBdLFxyXG4gICAgICAgICdkZXZkaWdpdGFsJzogW1xyXG4gICAgICAgICAgICAxLFxyXG4gICAgICAgICAgICAzLFxyXG4gICAgICAgICAgICA0LFxyXG4gICAgICAgICAgICA1LFxyXG4gICAgICAgICAgICA2LFxyXG4gICAgICAgICAgICA3LFxyXG4gICAgICAgICAgICA4LFxyXG4gICAgICAgICAgICA5XHJcbiAgICAgICAgXSxcclxuICAgICAgICAnYWknOltdXHJcbiAgICB9W2FwcG5hbWVdO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0RXhjbHVkZWRNb2R1bGVzKGFwcG5hbWUpIHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgJ3Byb2dyYW1taW5nJzogW1xyXG4gICAgICAgICAgICAyXHJcbiAgICAgICAgXVxyXG4gICAgfVthcHBuYW1lXTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGdldEV4Y2x1ZGVkTW9kdWxlSW5zdGFuY2VzKGFwcG5hbWUpIHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgJ2RpZ2l0YWwnOiBbXHJcbiAgICAgICAgICAgIDUsXHJcbiAgICAgICAgICAgIDUwXHJcbiAgICAgICAgXSxcclxuICAgICAgICAnY3JlYXRpdmUnOiBbXHJcbiAgICAgICAgICAgIDEsXHJcbiAgICAgICAgICAgIDE0LFxyXG4gICAgICAgICAgICAyOCxcclxuICAgICAgICAgICAgNDZcclxuICAgICAgICBdLFxyXG4gICAgICAgICdkZXZkaWdpdGFsJzogW1xyXG4gICAgICAgICAgICA1LFxyXG4gICAgICAgICAgICA1MFxyXG4gICAgICAgIF0sXHJcbiAgICB9W2FwcG5hbWVdO1xyXG59XHJcblxyXG4vKipcclxuICogQGRlc2NyaXB0aW9uIFJvdW5kcyB1cCBhIG51bWJlciB1cCB0byBzcGVjaWZpZWQgbnVtYmVyIG9mIGRlY2ltYWwgcGxhY2VzIHVzaW5nIGEgc3BlY2lmaWVkIG51bWJlciBvZiBkZWNpbWFsIHBsYWNlcyBhcyBwcmVjaXNpb24uXHJcbiAqIFRoaXMgYWxsb3dzIGNvcnJlY3Qgcm91bmRpbmcgb2YgcHJvYmxlbWF0aWMgZmxvYXRpbmcgcG9pbnQgbnVtYmVycyBsaWtlIFwiNTUuMDAwMDAwMDAwMDAwMDFcIiBvciBcIjAuNDYwMDAwMDAwMDAwMDAxXCJcclxuICogQHBhcmFtIHtOdW1iZXJ9IG51bWJlciBUaGUgbnVtYmVyIHRvIHJvdW5kIHVwXHJcbiAqIEBwYXJhbSB7TnVtYmVyfSBkZWNpbWFsUGxhY2VzVG9Sb3VuZFRvIFRoZSBudW1iZXIgb2YgZGVjaW1hbCBwbGFjZXMgdG8gcm91bmQgdG9cclxuICogQHBhcmFtIHtOdW1iZXJ9IGRlY2ltYWxQbGFjZXNQcmVjaXNpb24gVGhlIG51bWJlciBvZiBkZWNpbWFsIHBsYWNlcyB0aGF0IHNob3VsZCBiZSBjb25zaWRlcmVkIGZvciB0aGUgcm91bmRpbmcuIFNob3VsZCBiZSBsYXJnZXIgdGhhbiBkZWNpbWFsUGxhY2VzVG9Sb3VuZFRvXHJcbiAqIEByZXR1cm5zIFRoZSByb3VuZGVkIG51bWJlclxyXG4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIHJvdW5kVXBXaXRoUHJlY2lzaW9uKG51bWJlciwgZGVjaW1hbFBsYWNlc1RvUm91bmRUbywgZGVjaW1hbFBsYWNlc1ByZWNpc2lvbikge1xyXG4gICAgaWYgKGRlY2ltYWxQbGFjZXNQcmVjaXNpb24gPD0gZGVjaW1hbFBsYWNlc1RvUm91bmRUbykge1xyXG4gICAgICAgIHRocm93IG5ldyBSYW5nZUVycm9yKCdkZWNpbWFsUGxhY2VzUHJlY2lzaW9uIHNob3VsZCBiZSBsYXJnZXIgdGhhbiBkZWNpbWFsUGxhY2VzVG9Sb3VuZFRvJyk7XHJcbiAgICB9XHJcblxyXG4gICAgbGV0IHByZWNpc2lvblZhbHVlID0gMTAgKiogZGVjaW1hbFBsYWNlc1ByZWNpc2lvbjtcclxuICAgIGxldCByb3VuZGluZ1ZhbHVlID0gMTAgKiogZGVjaW1hbFBsYWNlc1RvUm91bmRUbztcclxuICAgIGxldCByb3VuZGluZ1ZhbHVlQmlnSW50ID0gQmlnSW50KHJvdW5kaW5nVmFsdWUpO1xyXG4gICAgbGV0IHByZWNpc2lvbkRpZmZlcmVuY2VWYWx1ZSA9IEJpZ0ludChwcmVjaXNpb25WYWx1ZSAvIHJvdW5kaW5nVmFsdWUpO1xyXG5cclxuICAgIGxldCBiaWdJbnQgPSBCaWdJbnQoTWF0aC50cnVuYyhudW1iZXIgKiBwcmVjaXNpb25WYWx1ZSkpO1xyXG4gICAgbGV0IHJvdW5kZWRQbGFjZXNOdW1iZXJQYXJ0ID0gYmlnSW50IC8gcHJlY2lzaW9uRGlmZmVyZW5jZVZhbHVlO1xyXG5cclxuICAgIGxldCBwcmVjaXNpb25EaWZmZXJlbmNlTGVmdG92ZXIgPSBiaWdJbnQgJSBwcmVjaXNpb25EaWZmZXJlbmNlVmFsdWU7XHJcbiAgICByb3VuZGVkUGxhY2VzTnVtYmVyUGFydCArPSBwcmVjaXNpb25EaWZmZXJlbmNlTGVmdG92ZXIgPiAwID8gMW4gOiAwbjtcclxuXHJcbiAgICBsZXQgbnVtYmVyUGFydCA9IHJvdW5kZWRQbGFjZXNOdW1iZXJQYXJ0IC8gcm91bmRpbmdWYWx1ZUJpZ0ludDtcclxuICAgIGxldCBkZWNpbWFsUGFydCA9IHJvdW5kZWRQbGFjZXNOdW1iZXJQYXJ0ICUgcm91bmRpbmdWYWx1ZUJpZ0ludDtcclxuXHJcbiAgICBsZXQgcm91bmRlZE51bSA9IE51bWJlcihgJHtudW1iZXJQYXJ0fS4ke2RlY2ltYWxQYXJ0LnRvU3RyaW5nKCkucGFkU3RhcnQoZGVjaW1hbFBsYWNlc1RvUm91bmRUbywgJzAnKX1gKTtcclxuICAgIHJldHVybiByb3VuZGVkTnVtO1xyXG59IiwiIWZ1bmN0aW9uKHUsRCl7XCJvYmplY3RcIj09dHlwZW9mIGV4cG9ydHMmJlwidW5kZWZpbmVkXCIhPXR5cGVvZiBtb2R1bGU/bW9kdWxlLmV4cG9ydHM9RCgpOlwiZnVuY3Rpb25cIj09dHlwZW9mIGRlZmluZSYmZGVmaW5lLmFtZD9kZWZpbmUoRCk6dS5KU09ONT1EKCl9KHRoaXMsZnVuY3Rpb24oKXtcInVzZSBzdHJpY3RcIjtmdW5jdGlvbiB1KHUsRCl7cmV0dXJuIHUoRD17ZXhwb3J0czp7fX0sRC5leHBvcnRzKSxELmV4cG9ydHN9dmFyIEQ9dShmdW5jdGlvbih1KXt2YXIgRD11LmV4cG9ydHM9XCJ1bmRlZmluZWRcIiE9dHlwZW9mIHdpbmRvdyYmd2luZG93Lk1hdGg9PU1hdGg/d2luZG93OlwidW5kZWZpbmVkXCIhPXR5cGVvZiBzZWxmJiZzZWxmLk1hdGg9PU1hdGg/c2VsZjpGdW5jdGlvbihcInJldHVybiB0aGlzXCIpKCk7XCJudW1iZXJcIj09dHlwZW9mIF9fZyYmKF9fZz1EKX0pLGU9dShmdW5jdGlvbih1KXt2YXIgRD11LmV4cG9ydHM9e3ZlcnNpb246XCIyLjYuNVwifTtcIm51bWJlclwiPT10eXBlb2YgX19lJiYoX19lPUQpfSksdD0oZS52ZXJzaW9uLGZ1bmN0aW9uKHUpe3JldHVyblwib2JqZWN0XCI9PXR5cGVvZiB1P251bGwhPT11OlwiZnVuY3Rpb25cIj09dHlwZW9mIHV9KSxyPWZ1bmN0aW9uKHUpe2lmKCF0KHUpKXRocm93IFR5cGVFcnJvcih1K1wiIGlzIG5vdCBhbiBvYmplY3QhXCIpO3JldHVybiB1fSxGPWZ1bmN0aW9uKHUpe3RyeXtyZXR1cm4hIXUoKX1jYXRjaCh1KXtyZXR1cm4hMH19LG49IUYoZnVuY3Rpb24oKXtyZXR1cm4gNyE9T2JqZWN0LmRlZmluZVByb3BlcnR5KHt9LFwiYVwiLHtnZXQ6ZnVuY3Rpb24oKXtyZXR1cm4gN319KS5hfSksQz1ELmRvY3VtZW50LEE9dChDKSYmdChDLmNyZWF0ZUVsZW1lbnQpLGk9IW4mJiFGKGZ1bmN0aW9uKCl7cmV0dXJuIDchPU9iamVjdC5kZWZpbmVQcm9wZXJ0eSgodT1cImRpdlwiLEE/Qy5jcmVhdGVFbGVtZW50KHUpOnt9KSxcImFcIix7Z2V0OmZ1bmN0aW9uKCl7cmV0dXJuIDd9fSkuYTt2YXIgdX0pLEU9T2JqZWN0LmRlZmluZVByb3BlcnR5LG89e2Y6bj9PYmplY3QuZGVmaW5lUHJvcGVydHk6ZnVuY3Rpb24odSxELGUpe2lmKHIodSksRD1mdW5jdGlvbih1LEQpe2lmKCF0KHUpKXJldHVybiB1O3ZhciBlLHI7aWYoRCYmXCJmdW5jdGlvblwiPT10eXBlb2YoZT11LnRvU3RyaW5nKSYmIXQocj1lLmNhbGwodSkpKXJldHVybiByO2lmKFwiZnVuY3Rpb25cIj09dHlwZW9mKGU9dS52YWx1ZU9mKSYmIXQocj1lLmNhbGwodSkpKXJldHVybiByO2lmKCFEJiZcImZ1bmN0aW9uXCI9PXR5cGVvZihlPXUudG9TdHJpbmcpJiYhdChyPWUuY2FsbCh1KSkpcmV0dXJuIHI7dGhyb3cgVHlwZUVycm9yKFwiQ2FuJ3QgY29udmVydCBvYmplY3QgdG8gcHJpbWl0aXZlIHZhbHVlXCIpfShELCEwKSxyKGUpLGkpdHJ5e3JldHVybiBFKHUsRCxlKX1jYXRjaCh1KXt9aWYoXCJnZXRcImluIGV8fFwic2V0XCJpbiBlKXRocm93IFR5cGVFcnJvcihcIkFjY2Vzc29ycyBub3Qgc3VwcG9ydGVkIVwiKTtyZXR1cm5cInZhbHVlXCJpbiBlJiYodVtEXT1lLnZhbHVlKSx1fX0sYT1uP2Z1bmN0aW9uKHUsRCxlKXtyZXR1cm4gby5mKHUsRCxmdW5jdGlvbih1LEQpe3JldHVybntlbnVtZXJhYmxlOiEoMSZ1KSxjb25maWd1cmFibGU6ISgyJnUpLHdyaXRhYmxlOiEoNCZ1KSx2YWx1ZTpEfX0oMSxlKSl9OmZ1bmN0aW9uKHUsRCxlKXtyZXR1cm4gdVtEXT1lLHV9LGM9e30uaGFzT3duUHJvcGVydHksQj1mdW5jdGlvbih1LEQpe3JldHVybiBjLmNhbGwodSxEKX0scz0wLGY9TWF0aC5yYW5kb20oKSxsPXUoZnVuY3Rpb24odSl7dmFyIHQ9RFtcIl9fY29yZS1qc19zaGFyZWRfX1wiXXx8KERbXCJfX2NvcmUtanNfc2hhcmVkX19cIl09e30pOyh1LmV4cG9ydHM9ZnVuY3Rpb24odSxEKXtyZXR1cm4gdFt1XXx8KHRbdV09dm9pZCAwIT09RD9EOnt9KX0pKFwidmVyc2lvbnNcIixbXSkucHVzaCh7dmVyc2lvbjplLnZlcnNpb24sbW9kZTpcImdsb2JhbFwiLGNvcHlyaWdodDpcIsKpIDIwMTkgRGVuaXMgUHVzaGthcmV2ICh6bG9pcm9jay5ydSlcIn0pfSkoXCJuYXRpdmUtZnVuY3Rpb24tdG8tc3RyaW5nXCIsRnVuY3Rpb24udG9TdHJpbmcpLGQ9dShmdW5jdGlvbih1KXt2YXIgdCxyPVwiU3ltYm9sKFwiLmNvbmNhdCh2b2lkIDA9PT0odD1cInNyY1wiKT9cIlwiOnQsXCIpX1wiLCgrK3MrZikudG9TdHJpbmcoMzYpKSxGPShcIlwiK2wpLnNwbGl0KFwidG9TdHJpbmdcIik7ZS5pbnNwZWN0U291cmNlPWZ1bmN0aW9uKHUpe3JldHVybiBsLmNhbGwodSl9LCh1LmV4cG9ydHM9ZnVuY3Rpb24odSxlLHQsbil7dmFyIEM9XCJmdW5jdGlvblwiPT10eXBlb2YgdDtDJiYoQih0LFwibmFtZVwiKXx8YSh0LFwibmFtZVwiLGUpKSx1W2VdIT09dCYmKEMmJihCKHQscil8fGEodCxyLHVbZV0/XCJcIit1W2VdOkYuam9pbihTdHJpbmcoZSkpKSksdT09PUQ/dVtlXT10Om4/dVtlXT91W2VdPXQ6YSh1LGUsdCk6KGRlbGV0ZSB1W2VdLGEodSxlLHQpKSl9KShGdW5jdGlvbi5wcm90b3R5cGUsXCJ0b1N0cmluZ1wiLGZ1bmN0aW9uKCl7cmV0dXJuXCJmdW5jdGlvblwiPT10eXBlb2YgdGhpcyYmdGhpc1tyXXx8bC5jYWxsKHRoaXMpfSl9KSx2PWZ1bmN0aW9uKHUsRCxlKXtpZihmdW5jdGlvbih1KXtpZihcImZ1bmN0aW9uXCIhPXR5cGVvZiB1KXRocm93IFR5cGVFcnJvcih1K1wiIGlzIG5vdCBhIGZ1bmN0aW9uIVwiKX0odSksdm9pZCAwPT09RClyZXR1cm4gdTtzd2l0Y2goZSl7Y2FzZSAxOnJldHVybiBmdW5jdGlvbihlKXtyZXR1cm4gdS5jYWxsKEQsZSl9O2Nhc2UgMjpyZXR1cm4gZnVuY3Rpb24oZSx0KXtyZXR1cm4gdS5jYWxsKEQsZSx0KX07Y2FzZSAzOnJldHVybiBmdW5jdGlvbihlLHQscil7cmV0dXJuIHUuY2FsbChELGUsdCxyKX19cmV0dXJuIGZ1bmN0aW9uKCl7cmV0dXJuIHUuYXBwbHkoRCxhcmd1bWVudHMpfX0scD1mdW5jdGlvbih1LHQscil7dmFyIEYsbixDLEEsaT11JnAuRixFPXUmcC5HLG89dSZwLlMsYz11JnAuUCxCPXUmcC5CLHM9RT9EOm8/RFt0XXx8KERbdF09e30pOihEW3RdfHx7fSkucHJvdG90eXBlLGY9RT9lOmVbdF18fChlW3RdPXt9KSxsPWYucHJvdG90eXBlfHwoZi5wcm90b3R5cGU9e30pO2ZvcihGIGluIEUmJihyPXQpLHIpQz0oKG49IWkmJnMmJnZvaWQgMCE9PXNbRl0pP3M6cilbRl0sQT1CJiZuP3YoQyxEKTpjJiZcImZ1bmN0aW9uXCI9PXR5cGVvZiBDP3YoRnVuY3Rpb24uY2FsbCxDKTpDLHMmJmQocyxGLEMsdSZwLlUpLGZbRl0hPUMmJmEoZixGLEEpLGMmJmxbRl0hPUMmJihsW0ZdPUMpfTtELmNvcmU9ZSxwLkY9MSxwLkc9MixwLlM9NCxwLlA9OCxwLkI9MTYscC5XPTMyLHAuVT02NCxwLlI9MTI4O3ZhciBoLG09cCxnPU1hdGguY2VpbCx5PU1hdGguZmxvb3Isdz1mdW5jdGlvbih1KXtyZXR1cm4gaXNOYU4odT0rdSk/MDoodT4wP3k6ZykodSl9LFM9KGg9ITEsZnVuY3Rpb24odSxEKXt2YXIgZSx0LHI9U3RyaW5nKGZ1bmN0aW9uKHUpe2lmKG51bGw9PXUpdGhyb3cgVHlwZUVycm9yKFwiQ2FuJ3QgY2FsbCBtZXRob2Qgb24gIFwiK3UpO3JldHVybiB1fSh1KSksRj13KEQpLG49ci5sZW5ndGg7cmV0dXJuIEY8MHx8Rj49bj9oP1wiXCI6dm9pZCAwOihlPXIuY2hhckNvZGVBdChGKSk8NTUyOTZ8fGU+NTYzMTl8fEYrMT09PW58fCh0PXIuY2hhckNvZGVBdChGKzEpKTw1NjMyMHx8dD41NzM0Mz9oP3IuY2hhckF0KEYpOmU6aD9yLnNsaWNlKEYsRisyKTp0LTU2MzIwKyhlLTU1Mjk2PDwxMCkrNjU1MzZ9KTttKG0uUCxcIlN0cmluZ1wiLHtjb2RlUG9pbnRBdDpmdW5jdGlvbih1KXtyZXR1cm4gUyh0aGlzLHUpfX0pO2UuU3RyaW5nLmNvZGVQb2ludEF0O3ZhciBiPU1hdGgubWF4LHg9TWF0aC5taW4sTj1TdHJpbmcuZnJvbUNoYXJDb2RlLFA9U3RyaW5nLmZyb21Db2RlUG9pbnQ7bShtLlMrbS5GKighIVAmJjEhPVAubGVuZ3RoKSxcIlN0cmluZ1wiLHtmcm9tQ29kZVBvaW50OmZ1bmN0aW9uKHUpe2Zvcih2YXIgRCxlLHQscj1hcmd1bWVudHMsRj1bXSxuPWFyZ3VtZW50cy5sZW5ndGgsQz0wO24+Qzspe2lmKEQ9K3JbQysrXSx0PTExMTQxMTEsKChlPXcoZT1EKSk8MD9iKGUrdCwwKTp4KGUsdCkpIT09RCl0aHJvdyBSYW5nZUVycm9yKEQrXCIgaXMgbm90IGEgdmFsaWQgY29kZSBwb2ludFwiKTtGLnB1c2goRDw2NTUzNj9OKEQpOk4oNTUyOTYrKChELT02NTUzNik+PjEwKSxEJTEwMjQrNTYzMjApKX1yZXR1cm4gRi5qb2luKFwiXCIpfX0pO2UuU3RyaW5nLmZyb21Db2RlUG9pbnQ7dmFyIF8sSSxPLGosVixKLE0sayxMLFQseixILCQsUixHPXtTcGFjZV9TZXBhcmF0b3I6L1tcXHUxNjgwXFx1MjAwMC1cXHUyMDBBXFx1MjAyRlxcdTIwNUZcXHUzMDAwXS8sSURfU3RhcnQ6L1tcXHhBQVxceEI1XFx4QkFcXHhDMC1cXHhENlxceEQ4LVxceEY2XFx4RjgtXFx1MDJDMVxcdTAyQzYtXFx1MDJEMVxcdTAyRTAtXFx1MDJFNFxcdTAyRUNcXHUwMkVFXFx1MDM3MC1cXHUwMzc0XFx1MDM3NlxcdTAzNzdcXHUwMzdBLVxcdTAzN0RcXHUwMzdGXFx1MDM4NlxcdTAzODgtXFx1MDM4QVxcdTAzOENcXHUwMzhFLVxcdTAzQTFcXHUwM0EzLVxcdTAzRjVcXHUwM0Y3LVxcdTA0ODFcXHUwNDhBLVxcdTA1MkZcXHUwNTMxLVxcdTA1NTZcXHUwNTU5XFx1MDU2MS1cXHUwNTg3XFx1MDVEMC1cXHUwNUVBXFx1MDVGMC1cXHUwNUYyXFx1MDYyMC1cXHUwNjRBXFx1MDY2RVxcdTA2NkZcXHUwNjcxLVxcdTA2RDNcXHUwNkQ1XFx1MDZFNVxcdTA2RTZcXHUwNkVFXFx1MDZFRlxcdTA2RkEtXFx1MDZGQ1xcdTA2RkZcXHUwNzEwXFx1MDcxMi1cXHUwNzJGXFx1MDc0RC1cXHUwN0E1XFx1MDdCMVxcdTA3Q0EtXFx1MDdFQVxcdTA3RjRcXHUwN0Y1XFx1MDdGQVxcdTA4MDAtXFx1MDgxNVxcdTA4MUFcXHUwODI0XFx1MDgyOFxcdTA4NDAtXFx1MDg1OFxcdTA4NjAtXFx1MDg2QVxcdTA4QTAtXFx1MDhCNFxcdTA4QjYtXFx1MDhCRFxcdTA5MDQtXFx1MDkzOVxcdTA5M0RcXHUwOTUwXFx1MDk1OC1cXHUwOTYxXFx1MDk3MS1cXHUwOTgwXFx1MDk4NS1cXHUwOThDXFx1MDk4RlxcdTA5OTBcXHUwOTkzLVxcdTA5QThcXHUwOUFBLVxcdTA5QjBcXHUwOUIyXFx1MDlCNi1cXHUwOUI5XFx1MDlCRFxcdTA5Q0VcXHUwOURDXFx1MDlERFxcdTA5REYtXFx1MDlFMVxcdTA5RjBcXHUwOUYxXFx1MDlGQ1xcdTBBMDUtXFx1MEEwQVxcdTBBMEZcXHUwQTEwXFx1MEExMy1cXHUwQTI4XFx1MEEyQS1cXHUwQTMwXFx1MEEzMlxcdTBBMzNcXHUwQTM1XFx1MEEzNlxcdTBBMzhcXHUwQTM5XFx1MEE1OS1cXHUwQTVDXFx1MEE1RVxcdTBBNzItXFx1MEE3NFxcdTBBODUtXFx1MEE4RFxcdTBBOEYtXFx1MEE5MVxcdTBBOTMtXFx1MEFBOFxcdTBBQUEtXFx1MEFCMFxcdTBBQjJcXHUwQUIzXFx1MEFCNS1cXHUwQUI5XFx1MEFCRFxcdTBBRDBcXHUwQUUwXFx1MEFFMVxcdTBBRjlcXHUwQjA1LVxcdTBCMENcXHUwQjBGXFx1MEIxMFxcdTBCMTMtXFx1MEIyOFxcdTBCMkEtXFx1MEIzMFxcdTBCMzJcXHUwQjMzXFx1MEIzNS1cXHUwQjM5XFx1MEIzRFxcdTBCNUNcXHUwQjVEXFx1MEI1Ri1cXHUwQjYxXFx1MEI3MVxcdTBCODNcXHUwQjg1LVxcdTBCOEFcXHUwQjhFLVxcdTBCOTBcXHUwQjkyLVxcdTBCOTVcXHUwQjk5XFx1MEI5QVxcdTBCOUNcXHUwQjlFXFx1MEI5RlxcdTBCQTNcXHUwQkE0XFx1MEJBOC1cXHUwQkFBXFx1MEJBRS1cXHUwQkI5XFx1MEJEMFxcdTBDMDUtXFx1MEMwQ1xcdTBDMEUtXFx1MEMxMFxcdTBDMTItXFx1MEMyOFxcdTBDMkEtXFx1MEMzOVxcdTBDM0RcXHUwQzU4LVxcdTBDNUFcXHUwQzYwXFx1MEM2MVxcdTBDODBcXHUwQzg1LVxcdTBDOENcXHUwQzhFLVxcdTBDOTBcXHUwQzkyLVxcdTBDQThcXHUwQ0FBLVxcdTBDQjNcXHUwQ0I1LVxcdTBDQjlcXHUwQ0JEXFx1MENERVxcdTBDRTBcXHUwQ0UxXFx1MENGMVxcdTBDRjJcXHUwRDA1LVxcdTBEMENcXHUwRDBFLVxcdTBEMTBcXHUwRDEyLVxcdTBEM0FcXHUwRDNEXFx1MEQ0RVxcdTBENTQtXFx1MEQ1NlxcdTBENUYtXFx1MEQ2MVxcdTBEN0EtXFx1MEQ3RlxcdTBEODUtXFx1MEQ5NlxcdTBEOUEtXFx1MERCMVxcdTBEQjMtXFx1MERCQlxcdTBEQkRcXHUwREMwLVxcdTBEQzZcXHUwRTAxLVxcdTBFMzBcXHUwRTMyXFx1MEUzM1xcdTBFNDAtXFx1MEU0NlxcdTBFODFcXHUwRTgyXFx1MEU4NFxcdTBFODdcXHUwRTg4XFx1MEU4QVxcdTBFOERcXHUwRTk0LVxcdTBFOTdcXHUwRTk5LVxcdTBFOUZcXHUwRUExLVxcdTBFQTNcXHUwRUE1XFx1MEVBN1xcdTBFQUFcXHUwRUFCXFx1MEVBRC1cXHUwRUIwXFx1MEVCMlxcdTBFQjNcXHUwRUJEXFx1MEVDMC1cXHUwRUM0XFx1MEVDNlxcdTBFREMtXFx1MEVERlxcdTBGMDBcXHUwRjQwLVxcdTBGNDdcXHUwRjQ5LVxcdTBGNkNcXHUwRjg4LVxcdTBGOENcXHUxMDAwLVxcdTEwMkFcXHUxMDNGXFx1MTA1MC1cXHUxMDU1XFx1MTA1QS1cXHUxMDVEXFx1MTA2MVxcdTEwNjVcXHUxMDY2XFx1MTA2RS1cXHUxMDcwXFx1MTA3NS1cXHUxMDgxXFx1MTA4RVxcdTEwQTAtXFx1MTBDNVxcdTEwQzdcXHUxMENEXFx1MTBEMC1cXHUxMEZBXFx1MTBGQy1cXHUxMjQ4XFx1MTI0QS1cXHUxMjREXFx1MTI1MC1cXHUxMjU2XFx1MTI1OFxcdTEyNUEtXFx1MTI1RFxcdTEyNjAtXFx1MTI4OFxcdTEyOEEtXFx1MTI4RFxcdTEyOTAtXFx1MTJCMFxcdTEyQjItXFx1MTJCNVxcdTEyQjgtXFx1MTJCRVxcdTEyQzBcXHUxMkMyLVxcdTEyQzVcXHUxMkM4LVxcdTEyRDZcXHUxMkQ4LVxcdTEzMTBcXHUxMzEyLVxcdTEzMTVcXHUxMzE4LVxcdTEzNUFcXHUxMzgwLVxcdTEzOEZcXHUxM0EwLVxcdTEzRjVcXHUxM0Y4LVxcdTEzRkRcXHUxNDAxLVxcdTE2NkNcXHUxNjZGLVxcdTE2N0ZcXHUxNjgxLVxcdTE2OUFcXHUxNkEwLVxcdTE2RUFcXHUxNkVFLVxcdTE2RjhcXHUxNzAwLVxcdTE3MENcXHUxNzBFLVxcdTE3MTFcXHUxNzIwLVxcdTE3MzFcXHUxNzQwLVxcdTE3NTFcXHUxNzYwLVxcdTE3NkNcXHUxNzZFLVxcdTE3NzBcXHUxNzgwLVxcdTE3QjNcXHUxN0Q3XFx1MTdEQ1xcdTE4MjAtXFx1MTg3N1xcdTE4ODAtXFx1MTg4NFxcdTE4ODctXFx1MThBOFxcdTE4QUFcXHUxOEIwLVxcdTE4RjVcXHUxOTAwLVxcdTE5MUVcXHUxOTUwLVxcdTE5NkRcXHUxOTcwLVxcdTE5NzRcXHUxOTgwLVxcdTE5QUJcXHUxOUIwLVxcdTE5QzlcXHUxQTAwLVxcdTFBMTZcXHUxQTIwLVxcdTFBNTRcXHUxQUE3XFx1MUIwNS1cXHUxQjMzXFx1MUI0NS1cXHUxQjRCXFx1MUI4My1cXHUxQkEwXFx1MUJBRVxcdTFCQUZcXHUxQkJBLVxcdTFCRTVcXHUxQzAwLVxcdTFDMjNcXHUxQzRELVxcdTFDNEZcXHUxQzVBLVxcdTFDN0RcXHUxQzgwLVxcdTFDODhcXHUxQ0U5LVxcdTFDRUNcXHUxQ0VFLVxcdTFDRjFcXHUxQ0Y1XFx1MUNGNlxcdTFEMDAtXFx1MURCRlxcdTFFMDAtXFx1MUYxNVxcdTFGMTgtXFx1MUYxRFxcdTFGMjAtXFx1MUY0NVxcdTFGNDgtXFx1MUY0RFxcdTFGNTAtXFx1MUY1N1xcdTFGNTlcXHUxRjVCXFx1MUY1RFxcdTFGNUYtXFx1MUY3RFxcdTFGODAtXFx1MUZCNFxcdTFGQjYtXFx1MUZCQ1xcdTFGQkVcXHUxRkMyLVxcdTFGQzRcXHUxRkM2LVxcdTFGQ0NcXHUxRkQwLVxcdTFGRDNcXHUxRkQ2LVxcdTFGREJcXHUxRkUwLVxcdTFGRUNcXHUxRkYyLVxcdTFGRjRcXHUxRkY2LVxcdTFGRkNcXHUyMDcxXFx1MjA3RlxcdTIwOTAtXFx1MjA5Q1xcdTIxMDJcXHUyMTA3XFx1MjEwQS1cXHUyMTEzXFx1MjExNVxcdTIxMTktXFx1MjExRFxcdTIxMjRcXHUyMTI2XFx1MjEyOFxcdTIxMkEtXFx1MjEyRFxcdTIxMkYtXFx1MjEzOVxcdTIxM0MtXFx1MjEzRlxcdTIxNDUtXFx1MjE0OVxcdTIxNEVcXHUyMTYwLVxcdTIxODhcXHUyQzAwLVxcdTJDMkVcXHUyQzMwLVxcdTJDNUVcXHUyQzYwLVxcdTJDRTRcXHUyQ0VCLVxcdTJDRUVcXHUyQ0YyXFx1MkNGM1xcdTJEMDAtXFx1MkQyNVxcdTJEMjdcXHUyRDJEXFx1MkQzMC1cXHUyRDY3XFx1MkQ2RlxcdTJEODAtXFx1MkQ5NlxcdTJEQTAtXFx1MkRBNlxcdTJEQTgtXFx1MkRBRVxcdTJEQjAtXFx1MkRCNlxcdTJEQjgtXFx1MkRCRVxcdTJEQzAtXFx1MkRDNlxcdTJEQzgtXFx1MkRDRVxcdTJERDAtXFx1MkRENlxcdTJERDgtXFx1MkRERVxcdTJFMkZcXHUzMDA1LVxcdTMwMDdcXHUzMDIxLVxcdTMwMjlcXHUzMDMxLVxcdTMwMzVcXHUzMDM4LVxcdTMwM0NcXHUzMDQxLVxcdTMwOTZcXHUzMDlELVxcdTMwOUZcXHUzMEExLVxcdTMwRkFcXHUzMEZDLVxcdTMwRkZcXHUzMTA1LVxcdTMxMkVcXHUzMTMxLVxcdTMxOEVcXHUzMUEwLVxcdTMxQkFcXHUzMUYwLVxcdTMxRkZcXHUzNDAwLVxcdTREQjVcXHU0RTAwLVxcdTlGRUFcXHVBMDAwLVxcdUE0OENcXHVBNEQwLVxcdUE0RkRcXHVBNTAwLVxcdUE2MENcXHVBNjEwLVxcdUE2MUZcXHVBNjJBXFx1QTYyQlxcdUE2NDAtXFx1QTY2RVxcdUE2N0YtXFx1QTY5RFxcdUE2QTAtXFx1QTZFRlxcdUE3MTctXFx1QTcxRlxcdUE3MjItXFx1QTc4OFxcdUE3OEItXFx1QTdBRVxcdUE3QjAtXFx1QTdCN1xcdUE3RjctXFx1QTgwMVxcdUE4MDMtXFx1QTgwNVxcdUE4MDctXFx1QTgwQVxcdUE4MEMtXFx1QTgyMlxcdUE4NDAtXFx1QTg3M1xcdUE4ODItXFx1QThCM1xcdUE4RjItXFx1QThGN1xcdUE4RkJcXHVBOEZEXFx1QTkwQS1cXHVBOTI1XFx1QTkzMC1cXHVBOTQ2XFx1QTk2MC1cXHVBOTdDXFx1QTk4NC1cXHVBOUIyXFx1QTlDRlxcdUE5RTAtXFx1QTlFNFxcdUE5RTYtXFx1QTlFRlxcdUE5RkEtXFx1QTlGRVxcdUFBMDAtXFx1QUEyOFxcdUFBNDAtXFx1QUE0MlxcdUFBNDQtXFx1QUE0QlxcdUFBNjAtXFx1QUE3NlxcdUFBN0FcXHVBQTdFLVxcdUFBQUZcXHVBQUIxXFx1QUFCNVxcdUFBQjZcXHVBQUI5LVxcdUFBQkRcXHVBQUMwXFx1QUFDMlxcdUFBREItXFx1QUFERFxcdUFBRTAtXFx1QUFFQVxcdUFBRjItXFx1QUFGNFxcdUFCMDEtXFx1QUIwNlxcdUFCMDktXFx1QUIwRVxcdUFCMTEtXFx1QUIxNlxcdUFCMjAtXFx1QUIyNlxcdUFCMjgtXFx1QUIyRVxcdUFCMzAtXFx1QUI1QVxcdUFCNUMtXFx1QUI2NVxcdUFCNzAtXFx1QUJFMlxcdUFDMDAtXFx1RDdBM1xcdUQ3QjAtXFx1RDdDNlxcdUQ3Q0ItXFx1RDdGQlxcdUY5MDAtXFx1RkE2RFxcdUZBNzAtXFx1RkFEOVxcdUZCMDAtXFx1RkIwNlxcdUZCMTMtXFx1RkIxN1xcdUZCMURcXHVGQjFGLVxcdUZCMjhcXHVGQjJBLVxcdUZCMzZcXHVGQjM4LVxcdUZCM0NcXHVGQjNFXFx1RkI0MFxcdUZCNDFcXHVGQjQzXFx1RkI0NFxcdUZCNDYtXFx1RkJCMVxcdUZCRDMtXFx1RkQzRFxcdUZENTAtXFx1RkQ4RlxcdUZEOTItXFx1RkRDN1xcdUZERjAtXFx1RkRGQlxcdUZFNzAtXFx1RkU3NFxcdUZFNzYtXFx1RkVGQ1xcdUZGMjEtXFx1RkYzQVxcdUZGNDEtXFx1RkY1QVxcdUZGNjYtXFx1RkZCRVxcdUZGQzItXFx1RkZDN1xcdUZGQ0EtXFx1RkZDRlxcdUZGRDItXFx1RkZEN1xcdUZGREEtXFx1RkZEQ118XFx1RDgwMFtcXHVEQzAwLVxcdURDMEJcXHVEQzBELVxcdURDMjZcXHVEQzI4LVxcdURDM0FcXHVEQzNDXFx1REMzRFxcdURDM0YtXFx1REM0RFxcdURDNTAtXFx1REM1RFxcdURDODAtXFx1RENGQVxcdURENDAtXFx1REQ3NFxcdURFODAtXFx1REU5Q1xcdURFQTAtXFx1REVEMFxcdURGMDAtXFx1REYxRlxcdURGMkQtXFx1REY0QVxcdURGNTAtXFx1REY3NVxcdURGODAtXFx1REY5RFxcdURGQTAtXFx1REZDM1xcdURGQzgtXFx1REZDRlxcdURGRDEtXFx1REZENV18XFx1RDgwMVtcXHVEQzAwLVxcdURDOURcXHVEQ0IwLVxcdURDRDNcXHVEQ0Q4LVxcdURDRkJcXHVERDAwLVxcdUREMjdcXHVERDMwLVxcdURENjNcXHVERTAwLVxcdURGMzZcXHVERjQwLVxcdURGNTVcXHVERjYwLVxcdURGNjddfFxcdUQ4MDJbXFx1REMwMC1cXHVEQzA1XFx1REMwOFxcdURDMEEtXFx1REMzNVxcdURDMzdcXHVEQzM4XFx1REMzQ1xcdURDM0YtXFx1REM1NVxcdURDNjAtXFx1REM3NlxcdURDODAtXFx1REM5RVxcdURDRTAtXFx1RENGMlxcdURDRjRcXHVEQ0Y1XFx1REQwMC1cXHVERDE1XFx1REQyMC1cXHVERDM5XFx1REQ4MC1cXHVEREI3XFx1RERCRVxcdUREQkZcXHVERTAwXFx1REUxMC1cXHVERTEzXFx1REUxNS1cXHVERTE3XFx1REUxOS1cXHVERTMzXFx1REU2MC1cXHVERTdDXFx1REU4MC1cXHVERTlDXFx1REVDMC1cXHVERUM3XFx1REVDOS1cXHVERUU0XFx1REYwMC1cXHVERjM1XFx1REY0MC1cXHVERjU1XFx1REY2MC1cXHVERjcyXFx1REY4MC1cXHVERjkxXXxcXHVEODAzW1xcdURDMDAtXFx1REM0OFxcdURDODAtXFx1RENCMlxcdURDQzAtXFx1RENGMl18XFx1RDgwNFtcXHVEQzAzLVxcdURDMzdcXHVEQzgzLVxcdURDQUZcXHVEQ0QwLVxcdURDRThcXHVERDAzLVxcdUREMjZcXHVERDUwLVxcdURENzJcXHVERDc2XFx1REQ4My1cXHVEREIyXFx1RERDMS1cXHVEREM0XFx1REREQVxcdURERENcXHVERTAwLVxcdURFMTFcXHVERTEzLVxcdURFMkJcXHVERTgwLVxcdURFODZcXHVERTg4XFx1REU4QS1cXHVERThEXFx1REU4Ri1cXHVERTlEXFx1REU5Ri1cXHVERUE4XFx1REVCMC1cXHVERURFXFx1REYwNS1cXHVERjBDXFx1REYwRlxcdURGMTBcXHVERjEzLVxcdURGMjhcXHVERjJBLVxcdURGMzBcXHVERjMyXFx1REYzM1xcdURGMzUtXFx1REYzOVxcdURGM0RcXHVERjUwXFx1REY1RC1cXHVERjYxXXxcXHVEODA1W1xcdURDMDAtXFx1REMzNFxcdURDNDctXFx1REM0QVxcdURDODAtXFx1RENBRlxcdURDQzRcXHVEQ0M1XFx1RENDN1xcdUREODAtXFx1RERBRVxcdURERDgtXFx1REREQlxcdURFMDAtXFx1REUyRlxcdURFNDRcXHVERTgwLVxcdURFQUFcXHVERjAwLVxcdURGMTldfFxcdUQ4MDZbXFx1RENBMC1cXHVEQ0RGXFx1RENGRlxcdURFMDBcXHVERTBCLVxcdURFMzJcXHVERTNBXFx1REU1MFxcdURFNUMtXFx1REU4M1xcdURFODYtXFx1REU4OVxcdURFQzAtXFx1REVGOF18XFx1RDgwN1tcXHVEQzAwLVxcdURDMDhcXHVEQzBBLVxcdURDMkVcXHVEQzQwXFx1REM3Mi1cXHVEQzhGXFx1REQwMC1cXHVERDA2XFx1REQwOFxcdUREMDlcXHVERDBCLVxcdUREMzBcXHVERDQ2XXxcXHVEODA4W1xcdURDMDAtXFx1REY5OV18XFx1RDgwOVtcXHVEQzAwLVxcdURDNkVcXHVEQzgwLVxcdURENDNdfFtcXHVEODBDXFx1RDgxQy1cXHVEODIwXFx1RDg0MC1cXHVEODY4XFx1RDg2QS1cXHVEODZDXFx1RDg2Ri1cXHVEODcyXFx1RDg3NC1cXHVEODc5XVtcXHVEQzAwLVxcdURGRkZdfFxcdUQ4MERbXFx1REMwMC1cXHVEQzJFXXxcXHVEODExW1xcdURDMDAtXFx1REU0Nl18XFx1RDgxQVtcXHVEQzAwLVxcdURFMzhcXHVERTQwLVxcdURFNUVcXHVERUQwLVxcdURFRURcXHVERjAwLVxcdURGMkZcXHVERjQwLVxcdURGNDNcXHVERjYzLVxcdURGNzdcXHVERjdELVxcdURGOEZdfFxcdUQ4MUJbXFx1REYwMC1cXHVERjQ0XFx1REY1MFxcdURGOTMtXFx1REY5RlxcdURGRTBcXHVERkUxXXxcXHVEODIxW1xcdURDMDAtXFx1REZFQ118XFx1RDgyMltcXHVEQzAwLVxcdURFRjJdfFxcdUQ4MkNbXFx1REMwMC1cXHVERDFFXFx1REQ3MC1cXHVERUZCXXxcXHVEODJGW1xcdURDMDAtXFx1REM2QVxcdURDNzAtXFx1REM3Q1xcdURDODAtXFx1REM4OFxcdURDOTAtXFx1REM5OV18XFx1RDgzNVtcXHVEQzAwLVxcdURDNTRcXHVEQzU2LVxcdURDOUNcXHVEQzlFXFx1REM5RlxcdURDQTJcXHVEQ0E1XFx1RENBNlxcdURDQTktXFx1RENBQ1xcdURDQUUtXFx1RENCOVxcdURDQkJcXHVEQ0JELVxcdURDQzNcXHVEQ0M1LVxcdUREMDVcXHVERDA3LVxcdUREMEFcXHVERDBELVxcdUREMTRcXHVERDE2LVxcdUREMUNcXHVERDFFLVxcdUREMzlcXHVERDNCLVxcdUREM0VcXHVERDQwLVxcdURENDRcXHVERDQ2XFx1REQ0QS1cXHVERDUwXFx1REQ1Mi1cXHVERUE1XFx1REVBOC1cXHVERUMwXFx1REVDMi1cXHVERURBXFx1REVEQy1cXHVERUZBXFx1REVGQy1cXHVERjE0XFx1REYxNi1cXHVERjM0XFx1REYzNi1cXHVERjRFXFx1REY1MC1cXHVERjZFXFx1REY3MC1cXHVERjg4XFx1REY4QS1cXHVERkE4XFx1REZBQS1cXHVERkMyXFx1REZDNC1cXHVERkNCXXxcXHVEODNBW1xcdURDMDAtXFx1RENDNFxcdUREMDAtXFx1REQ0M118XFx1RDgzQltcXHVERTAwLVxcdURFMDNcXHVERTA1LVxcdURFMUZcXHVERTIxXFx1REUyMlxcdURFMjRcXHVERTI3XFx1REUyOS1cXHVERTMyXFx1REUzNC1cXHVERTM3XFx1REUzOVxcdURFM0JcXHVERTQyXFx1REU0N1xcdURFNDlcXHVERTRCXFx1REU0RC1cXHVERTRGXFx1REU1MVxcdURFNTJcXHVERTU0XFx1REU1N1xcdURFNTlcXHVERTVCXFx1REU1RFxcdURFNUZcXHVERTYxXFx1REU2MlxcdURFNjRcXHVERTY3LVxcdURFNkFcXHVERTZDLVxcdURFNzJcXHVERTc0LVxcdURFNzdcXHVERTc5LVxcdURFN0NcXHVERTdFXFx1REU4MC1cXHVERTg5XFx1REU4Qi1cXHVERTlCXFx1REVBMS1cXHVERUEzXFx1REVBNS1cXHVERUE5XFx1REVBQi1cXHVERUJCXXxcXHVEODY5W1xcdURDMDAtXFx1REVENlxcdURGMDAtXFx1REZGRl18XFx1RDg2RFtcXHVEQzAwLVxcdURGMzRcXHVERjQwLVxcdURGRkZdfFxcdUQ4NkVbXFx1REMwMC1cXHVEQzFEXFx1REMyMC1cXHVERkZGXXxcXHVEODczW1xcdURDMDAtXFx1REVBMVxcdURFQjAtXFx1REZGRl18XFx1RDg3QVtcXHVEQzAwLVxcdURGRTBdfFxcdUQ4N0VbXFx1REMwMC1cXHVERTFEXS8sSURfQ29udGludWU6L1tcXHhBQVxceEI1XFx4QkFcXHhDMC1cXHhENlxceEQ4LVxceEY2XFx4RjgtXFx1MDJDMVxcdTAyQzYtXFx1MDJEMVxcdTAyRTAtXFx1MDJFNFxcdTAyRUNcXHUwMkVFXFx1MDMwMC1cXHUwMzc0XFx1MDM3NlxcdTAzNzdcXHUwMzdBLVxcdTAzN0RcXHUwMzdGXFx1MDM4NlxcdTAzODgtXFx1MDM4QVxcdTAzOENcXHUwMzhFLVxcdTAzQTFcXHUwM0EzLVxcdTAzRjVcXHUwM0Y3LVxcdTA0ODFcXHUwNDgzLVxcdTA0ODdcXHUwNDhBLVxcdTA1MkZcXHUwNTMxLVxcdTA1NTZcXHUwNTU5XFx1MDU2MS1cXHUwNTg3XFx1MDU5MS1cXHUwNUJEXFx1MDVCRlxcdTA1QzFcXHUwNUMyXFx1MDVDNFxcdTA1QzVcXHUwNUM3XFx1MDVEMC1cXHUwNUVBXFx1MDVGMC1cXHUwNUYyXFx1MDYxMC1cXHUwNjFBXFx1MDYyMC1cXHUwNjY5XFx1MDY2RS1cXHUwNkQzXFx1MDZENS1cXHUwNkRDXFx1MDZERi1cXHUwNkU4XFx1MDZFQS1cXHUwNkZDXFx1MDZGRlxcdTA3MTAtXFx1MDc0QVxcdTA3NEQtXFx1MDdCMVxcdTA3QzAtXFx1MDdGNVxcdTA3RkFcXHUwODAwLVxcdTA4MkRcXHUwODQwLVxcdTA4NUJcXHUwODYwLVxcdTA4NkFcXHUwOEEwLVxcdTA4QjRcXHUwOEI2LVxcdTA4QkRcXHUwOEQ0LVxcdTA4RTFcXHUwOEUzLVxcdTA5NjNcXHUwOTY2LVxcdTA5NkZcXHUwOTcxLVxcdTA5ODNcXHUwOTg1LVxcdTA5OENcXHUwOThGXFx1MDk5MFxcdTA5OTMtXFx1MDlBOFxcdTA5QUEtXFx1MDlCMFxcdTA5QjJcXHUwOUI2LVxcdTA5QjlcXHUwOUJDLVxcdTA5QzRcXHUwOUM3XFx1MDlDOFxcdTA5Q0ItXFx1MDlDRVxcdTA5RDdcXHUwOURDXFx1MDlERFxcdTA5REYtXFx1MDlFM1xcdTA5RTYtXFx1MDlGMVxcdTA5RkNcXHUwQTAxLVxcdTBBMDNcXHUwQTA1LVxcdTBBMEFcXHUwQTBGXFx1MEExMFxcdTBBMTMtXFx1MEEyOFxcdTBBMkEtXFx1MEEzMFxcdTBBMzJcXHUwQTMzXFx1MEEzNVxcdTBBMzZcXHUwQTM4XFx1MEEzOVxcdTBBM0NcXHUwQTNFLVxcdTBBNDJcXHUwQTQ3XFx1MEE0OFxcdTBBNEItXFx1MEE0RFxcdTBBNTFcXHUwQTU5LVxcdTBBNUNcXHUwQTVFXFx1MEE2Ni1cXHUwQTc1XFx1MEE4MS1cXHUwQTgzXFx1MEE4NS1cXHUwQThEXFx1MEE4Ri1cXHUwQTkxXFx1MEE5My1cXHUwQUE4XFx1MEFBQS1cXHUwQUIwXFx1MEFCMlxcdTBBQjNcXHUwQUI1LVxcdTBBQjlcXHUwQUJDLVxcdTBBQzVcXHUwQUM3LVxcdTBBQzlcXHUwQUNCLVxcdTBBQ0RcXHUwQUQwXFx1MEFFMC1cXHUwQUUzXFx1MEFFNi1cXHUwQUVGXFx1MEFGOS1cXHUwQUZGXFx1MEIwMS1cXHUwQjAzXFx1MEIwNS1cXHUwQjBDXFx1MEIwRlxcdTBCMTBcXHUwQjEzLVxcdTBCMjhcXHUwQjJBLVxcdTBCMzBcXHUwQjMyXFx1MEIzM1xcdTBCMzUtXFx1MEIzOVxcdTBCM0MtXFx1MEI0NFxcdTBCNDdcXHUwQjQ4XFx1MEI0Qi1cXHUwQjREXFx1MEI1NlxcdTBCNTdcXHUwQjVDXFx1MEI1RFxcdTBCNUYtXFx1MEI2M1xcdTBCNjYtXFx1MEI2RlxcdTBCNzFcXHUwQjgyXFx1MEI4M1xcdTBCODUtXFx1MEI4QVxcdTBCOEUtXFx1MEI5MFxcdTBCOTItXFx1MEI5NVxcdTBCOTlcXHUwQjlBXFx1MEI5Q1xcdTBCOUVcXHUwQjlGXFx1MEJBM1xcdTBCQTRcXHUwQkE4LVxcdTBCQUFcXHUwQkFFLVxcdTBCQjlcXHUwQkJFLVxcdTBCQzJcXHUwQkM2LVxcdTBCQzhcXHUwQkNBLVxcdTBCQ0RcXHUwQkQwXFx1MEJEN1xcdTBCRTYtXFx1MEJFRlxcdTBDMDAtXFx1MEMwM1xcdTBDMDUtXFx1MEMwQ1xcdTBDMEUtXFx1MEMxMFxcdTBDMTItXFx1MEMyOFxcdTBDMkEtXFx1MEMzOVxcdTBDM0QtXFx1MEM0NFxcdTBDNDYtXFx1MEM0OFxcdTBDNEEtXFx1MEM0RFxcdTBDNTVcXHUwQzU2XFx1MEM1OC1cXHUwQzVBXFx1MEM2MC1cXHUwQzYzXFx1MEM2Ni1cXHUwQzZGXFx1MEM4MC1cXHUwQzgzXFx1MEM4NS1cXHUwQzhDXFx1MEM4RS1cXHUwQzkwXFx1MEM5Mi1cXHUwQ0E4XFx1MENBQS1cXHUwQ0IzXFx1MENCNS1cXHUwQ0I5XFx1MENCQy1cXHUwQ0M0XFx1MENDNi1cXHUwQ0M4XFx1MENDQS1cXHUwQ0NEXFx1MENENVxcdTBDRDZcXHUwQ0RFXFx1MENFMC1cXHUwQ0UzXFx1MENFNi1cXHUwQ0VGXFx1MENGMVxcdTBDRjJcXHUwRDAwLVxcdTBEMDNcXHUwRDA1LVxcdTBEMENcXHUwRDBFLVxcdTBEMTBcXHUwRDEyLVxcdTBENDRcXHUwRDQ2LVxcdTBENDhcXHUwRDRBLVxcdTBENEVcXHUwRDU0LVxcdTBENTdcXHUwRDVGLVxcdTBENjNcXHUwRDY2LVxcdTBENkZcXHUwRDdBLVxcdTBEN0ZcXHUwRDgyXFx1MEQ4M1xcdTBEODUtXFx1MEQ5NlxcdTBEOUEtXFx1MERCMVxcdTBEQjMtXFx1MERCQlxcdTBEQkRcXHUwREMwLVxcdTBEQzZcXHUwRENBXFx1MERDRi1cXHUwREQ0XFx1MERENlxcdTBERDgtXFx1MERERlxcdTBERTYtXFx1MERFRlxcdTBERjJcXHUwREYzXFx1MEUwMS1cXHUwRTNBXFx1MEU0MC1cXHUwRTRFXFx1MEU1MC1cXHUwRTU5XFx1MEU4MVxcdTBFODJcXHUwRTg0XFx1MEU4N1xcdTBFODhcXHUwRThBXFx1MEU4RFxcdTBFOTQtXFx1MEU5N1xcdTBFOTktXFx1MEU5RlxcdTBFQTEtXFx1MEVBM1xcdTBFQTVcXHUwRUE3XFx1MEVBQVxcdTBFQUJcXHUwRUFELVxcdTBFQjlcXHUwRUJCLVxcdTBFQkRcXHUwRUMwLVxcdTBFQzRcXHUwRUM2XFx1MEVDOC1cXHUwRUNEXFx1MEVEMC1cXHUwRUQ5XFx1MEVEQy1cXHUwRURGXFx1MEYwMFxcdTBGMThcXHUwRjE5XFx1MEYyMC1cXHUwRjI5XFx1MEYzNVxcdTBGMzdcXHUwRjM5XFx1MEYzRS1cXHUwRjQ3XFx1MEY0OS1cXHUwRjZDXFx1MEY3MS1cXHUwRjg0XFx1MEY4Ni1cXHUwRjk3XFx1MEY5OS1cXHUwRkJDXFx1MEZDNlxcdTEwMDAtXFx1MTA0OVxcdTEwNTAtXFx1MTA5RFxcdTEwQTAtXFx1MTBDNVxcdTEwQzdcXHUxMENEXFx1MTBEMC1cXHUxMEZBXFx1MTBGQy1cXHUxMjQ4XFx1MTI0QS1cXHUxMjREXFx1MTI1MC1cXHUxMjU2XFx1MTI1OFxcdTEyNUEtXFx1MTI1RFxcdTEyNjAtXFx1MTI4OFxcdTEyOEEtXFx1MTI4RFxcdTEyOTAtXFx1MTJCMFxcdTEyQjItXFx1MTJCNVxcdTEyQjgtXFx1MTJCRVxcdTEyQzBcXHUxMkMyLVxcdTEyQzVcXHUxMkM4LVxcdTEyRDZcXHUxMkQ4LVxcdTEzMTBcXHUxMzEyLVxcdTEzMTVcXHUxMzE4LVxcdTEzNUFcXHUxMzVELVxcdTEzNUZcXHUxMzgwLVxcdTEzOEZcXHUxM0EwLVxcdTEzRjVcXHUxM0Y4LVxcdTEzRkRcXHUxNDAxLVxcdTE2NkNcXHUxNjZGLVxcdTE2N0ZcXHUxNjgxLVxcdTE2OUFcXHUxNkEwLVxcdTE2RUFcXHUxNkVFLVxcdTE2RjhcXHUxNzAwLVxcdTE3MENcXHUxNzBFLVxcdTE3MTRcXHUxNzIwLVxcdTE3MzRcXHUxNzQwLVxcdTE3NTNcXHUxNzYwLVxcdTE3NkNcXHUxNzZFLVxcdTE3NzBcXHUxNzcyXFx1MTc3M1xcdTE3ODAtXFx1MTdEM1xcdTE3RDdcXHUxN0RDXFx1MTdERFxcdTE3RTAtXFx1MTdFOVxcdTE4MEItXFx1MTgwRFxcdTE4MTAtXFx1MTgxOVxcdTE4MjAtXFx1MTg3N1xcdTE4ODAtXFx1MThBQVxcdTE4QjAtXFx1MThGNVxcdTE5MDAtXFx1MTkxRVxcdTE5MjAtXFx1MTkyQlxcdTE5MzAtXFx1MTkzQlxcdTE5NDYtXFx1MTk2RFxcdTE5NzAtXFx1MTk3NFxcdTE5ODAtXFx1MTlBQlxcdTE5QjAtXFx1MTlDOVxcdTE5RDAtXFx1MTlEOVxcdTFBMDAtXFx1MUExQlxcdTFBMjAtXFx1MUE1RVxcdTFBNjAtXFx1MUE3Q1xcdTFBN0YtXFx1MUE4OVxcdTFBOTAtXFx1MUE5OVxcdTFBQTdcXHUxQUIwLVxcdTFBQkRcXHUxQjAwLVxcdTFCNEJcXHUxQjUwLVxcdTFCNTlcXHUxQjZCLVxcdTFCNzNcXHUxQjgwLVxcdTFCRjNcXHUxQzAwLVxcdTFDMzdcXHUxQzQwLVxcdTFDNDlcXHUxQzRELVxcdTFDN0RcXHUxQzgwLVxcdTFDODhcXHUxQ0QwLVxcdTFDRDJcXHUxQ0Q0LVxcdTFDRjlcXHUxRDAwLVxcdTFERjlcXHUxREZCLVxcdTFGMTVcXHUxRjE4LVxcdTFGMURcXHUxRjIwLVxcdTFGNDVcXHUxRjQ4LVxcdTFGNERcXHUxRjUwLVxcdTFGNTdcXHUxRjU5XFx1MUY1QlxcdTFGNURcXHUxRjVGLVxcdTFGN0RcXHUxRjgwLVxcdTFGQjRcXHUxRkI2LVxcdTFGQkNcXHUxRkJFXFx1MUZDMi1cXHUxRkM0XFx1MUZDNi1cXHUxRkNDXFx1MUZEMC1cXHUxRkQzXFx1MUZENi1cXHUxRkRCXFx1MUZFMC1cXHUxRkVDXFx1MUZGMi1cXHUxRkY0XFx1MUZGNi1cXHUxRkZDXFx1MjAzRlxcdTIwNDBcXHUyMDU0XFx1MjA3MVxcdTIwN0ZcXHUyMDkwLVxcdTIwOUNcXHUyMEQwLVxcdTIwRENcXHUyMEUxXFx1MjBFNS1cXHUyMEYwXFx1MjEwMlxcdTIxMDdcXHUyMTBBLVxcdTIxMTNcXHUyMTE1XFx1MjExOS1cXHUyMTFEXFx1MjEyNFxcdTIxMjZcXHUyMTI4XFx1MjEyQS1cXHUyMTJEXFx1MjEyRi1cXHUyMTM5XFx1MjEzQy1cXHUyMTNGXFx1MjE0NS1cXHUyMTQ5XFx1MjE0RVxcdTIxNjAtXFx1MjE4OFxcdTJDMDAtXFx1MkMyRVxcdTJDMzAtXFx1MkM1RVxcdTJDNjAtXFx1MkNFNFxcdTJDRUItXFx1MkNGM1xcdTJEMDAtXFx1MkQyNVxcdTJEMjdcXHUyRDJEXFx1MkQzMC1cXHUyRDY3XFx1MkQ2RlxcdTJEN0YtXFx1MkQ5NlxcdTJEQTAtXFx1MkRBNlxcdTJEQTgtXFx1MkRBRVxcdTJEQjAtXFx1MkRCNlxcdTJEQjgtXFx1MkRCRVxcdTJEQzAtXFx1MkRDNlxcdTJEQzgtXFx1MkRDRVxcdTJERDAtXFx1MkRENlxcdTJERDgtXFx1MkRERVxcdTJERTAtXFx1MkRGRlxcdTJFMkZcXHUzMDA1LVxcdTMwMDdcXHUzMDIxLVxcdTMwMkZcXHUzMDMxLVxcdTMwMzVcXHUzMDM4LVxcdTMwM0NcXHUzMDQxLVxcdTMwOTZcXHUzMDk5XFx1MzA5QVxcdTMwOUQtXFx1MzA5RlxcdTMwQTEtXFx1MzBGQVxcdTMwRkMtXFx1MzBGRlxcdTMxMDUtXFx1MzEyRVxcdTMxMzEtXFx1MzE4RVxcdTMxQTAtXFx1MzFCQVxcdTMxRjAtXFx1MzFGRlxcdTM0MDAtXFx1NERCNVxcdTRFMDAtXFx1OUZFQVxcdUEwMDAtXFx1QTQ4Q1xcdUE0RDAtXFx1QTRGRFxcdUE1MDAtXFx1QTYwQ1xcdUE2MTAtXFx1QTYyQlxcdUE2NDAtXFx1QTY2RlxcdUE2NzQtXFx1QTY3RFxcdUE2N0YtXFx1QTZGMVxcdUE3MTctXFx1QTcxRlxcdUE3MjItXFx1QTc4OFxcdUE3OEItXFx1QTdBRVxcdUE3QjAtXFx1QTdCN1xcdUE3RjctXFx1QTgyN1xcdUE4NDAtXFx1QTg3M1xcdUE4ODAtXFx1QThDNVxcdUE4RDAtXFx1QThEOVxcdUE4RTAtXFx1QThGN1xcdUE4RkJcXHVBOEZEXFx1QTkwMC1cXHVBOTJEXFx1QTkzMC1cXHVBOTUzXFx1QTk2MC1cXHVBOTdDXFx1QTk4MC1cXHVBOUMwXFx1QTlDRi1cXHVBOUQ5XFx1QTlFMC1cXHVBOUZFXFx1QUEwMC1cXHVBQTM2XFx1QUE0MC1cXHVBQTREXFx1QUE1MC1cXHVBQTU5XFx1QUE2MC1cXHVBQTc2XFx1QUE3QS1cXHVBQUMyXFx1QUFEQi1cXHVBQUREXFx1QUFFMC1cXHVBQUVGXFx1QUFGMi1cXHVBQUY2XFx1QUIwMS1cXHVBQjA2XFx1QUIwOS1cXHVBQjBFXFx1QUIxMS1cXHVBQjE2XFx1QUIyMC1cXHVBQjI2XFx1QUIyOC1cXHVBQjJFXFx1QUIzMC1cXHVBQjVBXFx1QUI1Qy1cXHVBQjY1XFx1QUI3MC1cXHVBQkVBXFx1QUJFQ1xcdUFCRURcXHVBQkYwLVxcdUFCRjlcXHVBQzAwLVxcdUQ3QTNcXHVEN0IwLVxcdUQ3QzZcXHVEN0NCLVxcdUQ3RkJcXHVGOTAwLVxcdUZBNkRcXHVGQTcwLVxcdUZBRDlcXHVGQjAwLVxcdUZCMDZcXHVGQjEzLVxcdUZCMTdcXHVGQjFELVxcdUZCMjhcXHVGQjJBLVxcdUZCMzZcXHVGQjM4LVxcdUZCM0NcXHVGQjNFXFx1RkI0MFxcdUZCNDFcXHVGQjQzXFx1RkI0NFxcdUZCNDYtXFx1RkJCMVxcdUZCRDMtXFx1RkQzRFxcdUZENTAtXFx1RkQ4RlxcdUZEOTItXFx1RkRDN1xcdUZERjAtXFx1RkRGQlxcdUZFMDAtXFx1RkUwRlxcdUZFMjAtXFx1RkUyRlxcdUZFMzNcXHVGRTM0XFx1RkU0RC1cXHVGRTRGXFx1RkU3MC1cXHVGRTc0XFx1RkU3Ni1cXHVGRUZDXFx1RkYxMC1cXHVGRjE5XFx1RkYyMS1cXHVGRjNBXFx1RkYzRlxcdUZGNDEtXFx1RkY1QVxcdUZGNjYtXFx1RkZCRVxcdUZGQzItXFx1RkZDN1xcdUZGQ0EtXFx1RkZDRlxcdUZGRDItXFx1RkZEN1xcdUZGREEtXFx1RkZEQ118XFx1RDgwMFtcXHVEQzAwLVxcdURDMEJcXHVEQzBELVxcdURDMjZcXHVEQzI4LVxcdURDM0FcXHVEQzNDXFx1REMzRFxcdURDM0YtXFx1REM0RFxcdURDNTAtXFx1REM1RFxcdURDODAtXFx1RENGQVxcdURENDAtXFx1REQ3NFxcdURERkRcXHVERTgwLVxcdURFOUNcXHVERUEwLVxcdURFRDBcXHVERUUwXFx1REYwMC1cXHVERjFGXFx1REYyRC1cXHVERjRBXFx1REY1MC1cXHVERjdBXFx1REY4MC1cXHVERjlEXFx1REZBMC1cXHVERkMzXFx1REZDOC1cXHVERkNGXFx1REZEMS1cXHVERkQ1XXxcXHVEODAxW1xcdURDMDAtXFx1REM5RFxcdURDQTAtXFx1RENBOVxcdURDQjAtXFx1RENEM1xcdURDRDgtXFx1RENGQlxcdUREMDAtXFx1REQyN1xcdUREMzAtXFx1REQ2M1xcdURFMDAtXFx1REYzNlxcdURGNDAtXFx1REY1NVxcdURGNjAtXFx1REY2N118XFx1RDgwMltcXHVEQzAwLVxcdURDMDVcXHVEQzA4XFx1REMwQS1cXHVEQzM1XFx1REMzN1xcdURDMzhcXHVEQzNDXFx1REMzRi1cXHVEQzU1XFx1REM2MC1cXHVEQzc2XFx1REM4MC1cXHVEQzlFXFx1RENFMC1cXHVEQ0YyXFx1RENGNFxcdURDRjVcXHVERDAwLVxcdUREMTVcXHVERDIwLVxcdUREMzlcXHVERDgwLVxcdUREQjdcXHVEREJFXFx1RERCRlxcdURFMDAtXFx1REUwM1xcdURFMDVcXHVERTA2XFx1REUwQy1cXHVERTEzXFx1REUxNS1cXHVERTE3XFx1REUxOS1cXHVERTMzXFx1REUzOC1cXHVERTNBXFx1REUzRlxcdURFNjAtXFx1REU3Q1xcdURFODAtXFx1REU5Q1xcdURFQzAtXFx1REVDN1xcdURFQzktXFx1REVFNlxcdURGMDAtXFx1REYzNVxcdURGNDAtXFx1REY1NVxcdURGNjAtXFx1REY3MlxcdURGODAtXFx1REY5MV18XFx1RDgwM1tcXHVEQzAwLVxcdURDNDhcXHVEQzgwLVxcdURDQjJcXHVEQ0MwLVxcdURDRjJdfFxcdUQ4MDRbXFx1REMwMC1cXHVEQzQ2XFx1REM2Ni1cXHVEQzZGXFx1REM3Ri1cXHVEQ0JBXFx1RENEMC1cXHVEQ0U4XFx1RENGMC1cXHVEQ0Y5XFx1REQwMC1cXHVERDM0XFx1REQzNi1cXHVERDNGXFx1REQ1MC1cXHVERDczXFx1REQ3NlxcdUREODAtXFx1RERDNFxcdUREQ0EtXFx1RERDQ1xcdURERDAtXFx1REREQVxcdURERENcXHVERTAwLVxcdURFMTFcXHVERTEzLVxcdURFMzdcXHVERTNFXFx1REU4MC1cXHVERTg2XFx1REU4OFxcdURFOEEtXFx1REU4RFxcdURFOEYtXFx1REU5RFxcdURFOUYtXFx1REVBOFxcdURFQjAtXFx1REVFQVxcdURFRjAtXFx1REVGOVxcdURGMDAtXFx1REYwM1xcdURGMDUtXFx1REYwQ1xcdURGMEZcXHVERjEwXFx1REYxMy1cXHVERjI4XFx1REYyQS1cXHVERjMwXFx1REYzMlxcdURGMzNcXHVERjM1LVxcdURGMzlcXHVERjNDLVxcdURGNDRcXHVERjQ3XFx1REY0OFxcdURGNEItXFx1REY0RFxcdURGNTBcXHVERjU3XFx1REY1RC1cXHVERjYzXFx1REY2Ni1cXHVERjZDXFx1REY3MC1cXHVERjc0XXxcXHVEODA1W1xcdURDMDAtXFx1REM0QVxcdURDNTAtXFx1REM1OVxcdURDODAtXFx1RENDNVxcdURDQzdcXHVEQ0QwLVxcdURDRDlcXHVERDgwLVxcdUREQjVcXHVEREI4LVxcdUREQzBcXHVEREQ4LVxcdURERERcXHVERTAwLVxcdURFNDBcXHVERTQ0XFx1REU1MC1cXHVERTU5XFx1REU4MC1cXHVERUI3XFx1REVDMC1cXHVERUM5XFx1REYwMC1cXHVERjE5XFx1REYxRC1cXHVERjJCXFx1REYzMC1cXHVERjM5XXxcXHVEODA2W1xcdURDQTAtXFx1RENFOVxcdURDRkZcXHVERTAwLVxcdURFM0VcXHVERTQ3XFx1REU1MC1cXHVERTgzXFx1REU4Ni1cXHVERTk5XFx1REVDMC1cXHVERUY4XXxcXHVEODA3W1xcdURDMDAtXFx1REMwOFxcdURDMEEtXFx1REMzNlxcdURDMzgtXFx1REM0MFxcdURDNTAtXFx1REM1OVxcdURDNzItXFx1REM4RlxcdURDOTItXFx1RENBN1xcdURDQTktXFx1RENCNlxcdUREMDAtXFx1REQwNlxcdUREMDhcXHVERDA5XFx1REQwQi1cXHVERDM2XFx1REQzQVxcdUREM0NcXHVERDNEXFx1REQzRi1cXHVERDQ3XFx1REQ1MC1cXHVERDU5XXxcXHVEODA4W1xcdURDMDAtXFx1REY5OV18XFx1RDgwOVtcXHVEQzAwLVxcdURDNkVcXHVEQzgwLVxcdURENDNdfFtcXHVEODBDXFx1RDgxQy1cXHVEODIwXFx1RDg0MC1cXHVEODY4XFx1RDg2QS1cXHVEODZDXFx1RDg2Ri1cXHVEODcyXFx1RDg3NC1cXHVEODc5XVtcXHVEQzAwLVxcdURGRkZdfFxcdUQ4MERbXFx1REMwMC1cXHVEQzJFXXxcXHVEODExW1xcdURDMDAtXFx1REU0Nl18XFx1RDgxQVtcXHVEQzAwLVxcdURFMzhcXHVERTQwLVxcdURFNUVcXHVERTYwLVxcdURFNjlcXHVERUQwLVxcdURFRURcXHVERUYwLVxcdURFRjRcXHVERjAwLVxcdURGMzZcXHVERjQwLVxcdURGNDNcXHVERjUwLVxcdURGNTlcXHVERjYzLVxcdURGNzdcXHVERjdELVxcdURGOEZdfFxcdUQ4MUJbXFx1REYwMC1cXHVERjQ0XFx1REY1MC1cXHVERjdFXFx1REY4Ri1cXHVERjlGXFx1REZFMFxcdURGRTFdfFxcdUQ4MjFbXFx1REMwMC1cXHVERkVDXXxcXHVEODIyW1xcdURDMDAtXFx1REVGMl18XFx1RDgyQ1tcXHVEQzAwLVxcdUREMUVcXHVERDcwLVxcdURFRkJdfFxcdUQ4MkZbXFx1REMwMC1cXHVEQzZBXFx1REM3MC1cXHVEQzdDXFx1REM4MC1cXHVEQzg4XFx1REM5MC1cXHVEQzk5XFx1REM5RFxcdURDOUVdfFxcdUQ4MzRbXFx1REQ2NS1cXHVERDY5XFx1REQ2RC1cXHVERDcyXFx1REQ3Qi1cXHVERDgyXFx1REQ4NS1cXHVERDhCXFx1RERBQS1cXHVEREFEXFx1REU0Mi1cXHVERTQ0XXxcXHVEODM1W1xcdURDMDAtXFx1REM1NFxcdURDNTYtXFx1REM5Q1xcdURDOUVcXHVEQzlGXFx1RENBMlxcdURDQTVcXHVEQ0E2XFx1RENBOS1cXHVEQ0FDXFx1RENBRS1cXHVEQ0I5XFx1RENCQlxcdURDQkQtXFx1RENDM1xcdURDQzUtXFx1REQwNVxcdUREMDctXFx1REQwQVxcdUREMEQtXFx1REQxNFxcdUREMTYtXFx1REQxQ1xcdUREMUUtXFx1REQzOVxcdUREM0ItXFx1REQzRVxcdURENDAtXFx1REQ0NFxcdURENDZcXHVERDRBLVxcdURENTBcXHVERDUyLVxcdURFQTVcXHVERUE4LVxcdURFQzBcXHVERUMyLVxcdURFREFcXHVERURDLVxcdURFRkFcXHVERUZDLVxcdURGMTRcXHVERjE2LVxcdURGMzRcXHVERjM2LVxcdURGNEVcXHVERjUwLVxcdURGNkVcXHVERjcwLVxcdURGODhcXHVERjhBLVxcdURGQThcXHVERkFBLVxcdURGQzJcXHVERkM0LVxcdURGQ0JcXHVERkNFLVxcdURGRkZdfFxcdUQ4MzZbXFx1REUwMC1cXHVERTM2XFx1REUzQi1cXHVERTZDXFx1REU3NVxcdURFODRcXHVERTlCLVxcdURFOUZcXHVERUExLVxcdURFQUZdfFxcdUQ4MzhbXFx1REMwMC1cXHVEQzA2XFx1REMwOC1cXHVEQzE4XFx1REMxQi1cXHVEQzIxXFx1REMyM1xcdURDMjRcXHVEQzI2LVxcdURDMkFdfFxcdUQ4M0FbXFx1REMwMC1cXHVEQ0M0XFx1RENEMC1cXHVEQ0Q2XFx1REQwMC1cXHVERDRBXFx1REQ1MC1cXHVERDU5XXxcXHVEODNCW1xcdURFMDAtXFx1REUwM1xcdURFMDUtXFx1REUxRlxcdURFMjFcXHVERTIyXFx1REUyNFxcdURFMjdcXHVERTI5LVxcdURFMzJcXHVERTM0LVxcdURFMzdcXHVERTM5XFx1REUzQlxcdURFNDJcXHVERTQ3XFx1REU0OVxcdURFNEJcXHVERTRELVxcdURFNEZcXHVERTUxXFx1REU1MlxcdURFNTRcXHVERTU3XFx1REU1OVxcdURFNUJcXHVERTVEXFx1REU1RlxcdURFNjFcXHVERTYyXFx1REU2NFxcdURFNjctXFx1REU2QVxcdURFNkMtXFx1REU3MlxcdURFNzQtXFx1REU3N1xcdURFNzktXFx1REU3Q1xcdURFN0VcXHVERTgwLVxcdURFODlcXHVERThCLVxcdURFOUJcXHVERUExLVxcdURFQTNcXHVERUE1LVxcdURFQTlcXHVERUFCLVxcdURFQkJdfFxcdUQ4NjlbXFx1REMwMC1cXHVERUQ2XFx1REYwMC1cXHVERkZGXXxcXHVEODZEW1xcdURDMDAtXFx1REYzNFxcdURGNDAtXFx1REZGRl18XFx1RDg2RVtcXHVEQzAwLVxcdURDMURcXHVEQzIwLVxcdURGRkZdfFxcdUQ4NzNbXFx1REMwMC1cXHVERUExXFx1REVCMC1cXHVERkZGXXxcXHVEODdBW1xcdURDMDAtXFx1REZFMF18XFx1RDg3RVtcXHVEQzAwLVxcdURFMURdfFxcdURCNDBbXFx1REQwMC1cXHVEREVGXS99LFU9e2lzU3BhY2VTZXBhcmF0b3I6ZnVuY3Rpb24odSl7cmV0dXJuXCJzdHJpbmdcIj09dHlwZW9mIHUmJkcuU3BhY2VfU2VwYXJhdG9yLnRlc3QodSl9LGlzSWRTdGFydENoYXI6ZnVuY3Rpb24odSl7cmV0dXJuXCJzdHJpbmdcIj09dHlwZW9mIHUmJih1Pj1cImFcIiYmdTw9XCJ6XCJ8fHU+PVwiQVwiJiZ1PD1cIlpcInx8XCIkXCI9PT11fHxcIl9cIj09PXV8fEcuSURfU3RhcnQudGVzdCh1KSl9LGlzSWRDb250aW51ZUNoYXI6ZnVuY3Rpb24odSl7cmV0dXJuXCJzdHJpbmdcIj09dHlwZW9mIHUmJih1Pj1cImFcIiYmdTw9XCJ6XCJ8fHU+PVwiQVwiJiZ1PD1cIlpcInx8dT49XCIwXCImJnU8PVwiOVwifHxcIiRcIj09PXV8fFwiX1wiPT09dXx8XCLigIxcIj09PXV8fFwi4oCNXCI9PT11fHxHLklEX0NvbnRpbnVlLnRlc3QodSkpfSxpc0RpZ2l0OmZ1bmN0aW9uKHUpe3JldHVyblwic3RyaW5nXCI9PXR5cGVvZiB1JiYvWzAtOV0vLnRlc3QodSl9LGlzSGV4RGlnaXQ6ZnVuY3Rpb24odSl7cmV0dXJuXCJzdHJpbmdcIj09dHlwZW9mIHUmJi9bMC05QS1GYS1mXS8udGVzdCh1KX19O2Z1bmN0aW9uIFooKXtmb3IoVD1cImRlZmF1bHRcIix6PVwiXCIsSD0hMSwkPTE7Oyl7Uj1xKCk7dmFyIHU9WFtUXSgpO2lmKHUpcmV0dXJuIHV9fWZ1bmN0aW9uIHEoKXtpZihfW2pdKXJldHVybiBTdHJpbmcuZnJvbUNvZGVQb2ludChfLmNvZGVQb2ludEF0KGopKX1mdW5jdGlvbiBXKCl7dmFyIHU9cSgpO3JldHVyblwiXFxuXCI9PT11PyhWKyssSj0wKTp1P0orPXUubGVuZ3RoOkorKyx1JiYoais9dS5sZW5ndGgpLHV9dmFyIFg9e2RlZmF1bHQ6ZnVuY3Rpb24oKXtzd2l0Y2goUil7Y2FzZVwiXFx0XCI6Y2FzZVwiXFx2XCI6Y2FzZVwiXFxmXCI6Y2FzZVwiIFwiOmNhc2VcIsKgXCI6Y2FzZVwiXFx1ZmVmZlwiOmNhc2VcIlxcblwiOmNhc2VcIlxcclwiOmNhc2VcIlxcdTIwMjhcIjpjYXNlXCJcXHUyMDI5XCI6cmV0dXJuIHZvaWQgVygpO2Nhc2VcIi9cIjpyZXR1cm4gVygpLHZvaWQoVD1cImNvbW1lbnRcIik7Y2FzZSB2b2lkIDA6cmV0dXJuIFcoKSxLKFwiZW9mXCIpfWlmKCFVLmlzU3BhY2VTZXBhcmF0b3IoUikpcmV0dXJuIFhbSV0oKTtXKCl9LGNvbW1lbnQ6ZnVuY3Rpb24oKXtzd2l0Y2goUil7Y2FzZVwiKlwiOnJldHVybiBXKCksdm9pZChUPVwibXVsdGlMaW5lQ29tbWVudFwiKTtjYXNlXCIvXCI6cmV0dXJuIFcoKSx2b2lkKFQ9XCJzaW5nbGVMaW5lQ29tbWVudFwiKX10aHJvdyB0dShXKCkpfSxtdWx0aUxpbmVDb21tZW50OmZ1bmN0aW9uKCl7c3dpdGNoKFIpe2Nhc2VcIipcIjpyZXR1cm4gVygpLHZvaWQoVD1cIm11bHRpTGluZUNvbW1lbnRBc3Rlcmlza1wiKTtjYXNlIHZvaWQgMDp0aHJvdyB0dShXKCkpfVcoKX0sbXVsdGlMaW5lQ29tbWVudEFzdGVyaXNrOmZ1bmN0aW9uKCl7c3dpdGNoKFIpe2Nhc2VcIipcIjpyZXR1cm4gdm9pZCBXKCk7Y2FzZVwiL1wiOnJldHVybiBXKCksdm9pZChUPVwiZGVmYXVsdFwiKTtjYXNlIHZvaWQgMDp0aHJvdyB0dShXKCkpfVcoKSxUPVwibXVsdGlMaW5lQ29tbWVudFwifSxzaW5nbGVMaW5lQ29tbWVudDpmdW5jdGlvbigpe3N3aXRjaChSKXtjYXNlXCJcXG5cIjpjYXNlXCJcXHJcIjpjYXNlXCJcXHUyMDI4XCI6Y2FzZVwiXFx1MjAyOVwiOnJldHVybiBXKCksdm9pZChUPVwiZGVmYXVsdFwiKTtjYXNlIHZvaWQgMDpyZXR1cm4gVygpLEsoXCJlb2ZcIil9VygpfSx2YWx1ZTpmdW5jdGlvbigpe3N3aXRjaChSKXtjYXNlXCJ7XCI6Y2FzZVwiW1wiOnJldHVybiBLKFwicHVuY3R1YXRvclwiLFcoKSk7Y2FzZVwiblwiOnJldHVybiBXKCksUShcInVsbFwiKSxLKFwibnVsbFwiLG51bGwpO2Nhc2VcInRcIjpyZXR1cm4gVygpLFEoXCJydWVcIiksSyhcImJvb2xlYW5cIiwhMCk7Y2FzZVwiZlwiOnJldHVybiBXKCksUShcImFsc2VcIiksSyhcImJvb2xlYW5cIiwhMSk7Y2FzZVwiLVwiOmNhc2VcIitcIjpyZXR1cm5cIi1cIj09PVcoKSYmKCQ9LTEpLHZvaWQoVD1cInNpZ25cIik7Y2FzZVwiLlwiOnJldHVybiB6PVcoKSx2b2lkKFQ9XCJkZWNpbWFsUG9pbnRMZWFkaW5nXCIpO2Nhc2VcIjBcIjpyZXR1cm4gej1XKCksdm9pZChUPVwiemVyb1wiKTtjYXNlXCIxXCI6Y2FzZVwiMlwiOmNhc2VcIjNcIjpjYXNlXCI0XCI6Y2FzZVwiNVwiOmNhc2VcIjZcIjpjYXNlXCI3XCI6Y2FzZVwiOFwiOmNhc2VcIjlcIjpyZXR1cm4gej1XKCksdm9pZChUPVwiZGVjaW1hbEludGVnZXJcIik7Y2FzZVwiSVwiOnJldHVybiBXKCksUShcIm5maW5pdHlcIiksSyhcIm51bWVyaWNcIiwxLzApO2Nhc2VcIk5cIjpyZXR1cm4gVygpLFEoXCJhTlwiKSxLKFwibnVtZXJpY1wiLE5hTik7Y2FzZSdcIic6Y2FzZVwiJ1wiOnJldHVybiBIPSdcIic9PT1XKCksej1cIlwiLHZvaWQoVD1cInN0cmluZ1wiKX10aHJvdyB0dShXKCkpfSxpZGVudGlmaWVyTmFtZVN0YXJ0RXNjYXBlOmZ1bmN0aW9uKCl7aWYoXCJ1XCIhPT1SKXRocm93IHR1KFcoKSk7VygpO3ZhciB1PVkoKTtzd2l0Y2godSl7Y2FzZVwiJFwiOmNhc2VcIl9cIjpicmVhaztkZWZhdWx0OmlmKCFVLmlzSWRTdGFydENoYXIodSkpdGhyb3cgRnUoKX16Kz11LFQ9XCJpZGVudGlmaWVyTmFtZVwifSxpZGVudGlmaWVyTmFtZTpmdW5jdGlvbigpe3N3aXRjaChSKXtjYXNlXCIkXCI6Y2FzZVwiX1wiOmNhc2VcIuKAjFwiOmNhc2VcIuKAjVwiOnJldHVybiB2b2lkKHorPVcoKSk7Y2FzZVwiXFxcXFwiOnJldHVybiBXKCksdm9pZChUPVwiaWRlbnRpZmllck5hbWVFc2NhcGVcIil9aWYoIVUuaXNJZENvbnRpbnVlQ2hhcihSKSlyZXR1cm4gSyhcImlkZW50aWZpZXJcIix6KTt6Kz1XKCl9LGlkZW50aWZpZXJOYW1lRXNjYXBlOmZ1bmN0aW9uKCl7aWYoXCJ1XCIhPT1SKXRocm93IHR1KFcoKSk7VygpO3ZhciB1PVkoKTtzd2l0Y2godSl7Y2FzZVwiJFwiOmNhc2VcIl9cIjpjYXNlXCLigIxcIjpjYXNlXCLigI1cIjpicmVhaztkZWZhdWx0OmlmKCFVLmlzSWRDb250aW51ZUNoYXIodSkpdGhyb3cgRnUoKX16Kz11LFQ9XCJpZGVudGlmaWVyTmFtZVwifSxzaWduOmZ1bmN0aW9uKCl7c3dpdGNoKFIpe2Nhc2VcIi5cIjpyZXR1cm4gej1XKCksdm9pZChUPVwiZGVjaW1hbFBvaW50TGVhZGluZ1wiKTtjYXNlXCIwXCI6cmV0dXJuIHo9VygpLHZvaWQoVD1cInplcm9cIik7Y2FzZVwiMVwiOmNhc2VcIjJcIjpjYXNlXCIzXCI6Y2FzZVwiNFwiOmNhc2VcIjVcIjpjYXNlXCI2XCI6Y2FzZVwiN1wiOmNhc2VcIjhcIjpjYXNlXCI5XCI6cmV0dXJuIHo9VygpLHZvaWQoVD1cImRlY2ltYWxJbnRlZ2VyXCIpO2Nhc2VcIklcIjpyZXR1cm4gVygpLFEoXCJuZmluaXR5XCIpLEsoXCJudW1lcmljXCIsJCooMS8wKSk7Y2FzZVwiTlwiOnJldHVybiBXKCksUShcImFOXCIpLEsoXCJudW1lcmljXCIsTmFOKX10aHJvdyB0dShXKCkpfSx6ZXJvOmZ1bmN0aW9uKCl7c3dpdGNoKFIpe2Nhc2VcIi5cIjpyZXR1cm4geis9VygpLHZvaWQoVD1cImRlY2ltYWxQb2ludFwiKTtjYXNlXCJlXCI6Y2FzZVwiRVwiOnJldHVybiB6Kz1XKCksdm9pZChUPVwiZGVjaW1hbEV4cG9uZW50XCIpO2Nhc2VcInhcIjpjYXNlXCJYXCI6cmV0dXJuIHorPVcoKSx2b2lkKFQ9XCJoZXhhZGVjaW1hbFwiKX1yZXR1cm4gSyhcIm51bWVyaWNcIiwwKiQpfSxkZWNpbWFsSW50ZWdlcjpmdW5jdGlvbigpe3N3aXRjaChSKXtjYXNlXCIuXCI6cmV0dXJuIHorPVcoKSx2b2lkKFQ9XCJkZWNpbWFsUG9pbnRcIik7Y2FzZVwiZVwiOmNhc2VcIkVcIjpyZXR1cm4geis9VygpLHZvaWQoVD1cImRlY2ltYWxFeHBvbmVudFwiKX1pZighVS5pc0RpZ2l0KFIpKXJldHVybiBLKFwibnVtZXJpY1wiLCQqTnVtYmVyKHopKTt6Kz1XKCl9LGRlY2ltYWxQb2ludExlYWRpbmc6ZnVuY3Rpb24oKXtpZihVLmlzRGlnaXQoUikpcmV0dXJuIHorPVcoKSx2b2lkKFQ9XCJkZWNpbWFsRnJhY3Rpb25cIik7dGhyb3cgdHUoVygpKX0sZGVjaW1hbFBvaW50OmZ1bmN0aW9uKCl7c3dpdGNoKFIpe2Nhc2VcImVcIjpjYXNlXCJFXCI6cmV0dXJuIHorPVcoKSx2b2lkKFQ9XCJkZWNpbWFsRXhwb25lbnRcIil9cmV0dXJuIFUuaXNEaWdpdChSKT8oeis9VygpLHZvaWQoVD1cImRlY2ltYWxGcmFjdGlvblwiKSk6SyhcIm51bWVyaWNcIiwkKk51bWJlcih6KSl9LGRlY2ltYWxGcmFjdGlvbjpmdW5jdGlvbigpe3N3aXRjaChSKXtjYXNlXCJlXCI6Y2FzZVwiRVwiOnJldHVybiB6Kz1XKCksdm9pZChUPVwiZGVjaW1hbEV4cG9uZW50XCIpfWlmKCFVLmlzRGlnaXQoUikpcmV0dXJuIEsoXCJudW1lcmljXCIsJCpOdW1iZXIoeikpO3orPVcoKX0sZGVjaW1hbEV4cG9uZW50OmZ1bmN0aW9uKCl7c3dpdGNoKFIpe2Nhc2VcIitcIjpjYXNlXCItXCI6cmV0dXJuIHorPVcoKSx2b2lkKFQ9XCJkZWNpbWFsRXhwb25lbnRTaWduXCIpfWlmKFUuaXNEaWdpdChSKSlyZXR1cm4geis9VygpLHZvaWQoVD1cImRlY2ltYWxFeHBvbmVudEludGVnZXJcIik7dGhyb3cgdHUoVygpKX0sZGVjaW1hbEV4cG9uZW50U2lnbjpmdW5jdGlvbigpe2lmKFUuaXNEaWdpdChSKSlyZXR1cm4geis9VygpLHZvaWQoVD1cImRlY2ltYWxFeHBvbmVudEludGVnZXJcIik7dGhyb3cgdHUoVygpKX0sZGVjaW1hbEV4cG9uZW50SW50ZWdlcjpmdW5jdGlvbigpe2lmKCFVLmlzRGlnaXQoUikpcmV0dXJuIEsoXCJudW1lcmljXCIsJCpOdW1iZXIoeikpO3orPVcoKX0saGV4YWRlY2ltYWw6ZnVuY3Rpb24oKXtpZihVLmlzSGV4RGlnaXQoUikpcmV0dXJuIHorPVcoKSx2b2lkKFQ9XCJoZXhhZGVjaW1hbEludGVnZXJcIik7dGhyb3cgdHUoVygpKX0saGV4YWRlY2ltYWxJbnRlZ2VyOmZ1bmN0aW9uKCl7aWYoIVUuaXNIZXhEaWdpdChSKSlyZXR1cm4gSyhcIm51bWVyaWNcIiwkKk51bWJlcih6KSk7eis9VygpfSxzdHJpbmc6ZnVuY3Rpb24oKXtzd2l0Y2goUil7Y2FzZVwiXFxcXFwiOnJldHVybiBXKCksdm9pZCh6Kz1mdW5jdGlvbigpe3N3aXRjaChxKCkpe2Nhc2VcImJcIjpyZXR1cm4gVygpLFwiXFxiXCI7Y2FzZVwiZlwiOnJldHVybiBXKCksXCJcXGZcIjtjYXNlXCJuXCI6cmV0dXJuIFcoKSxcIlxcblwiO2Nhc2VcInJcIjpyZXR1cm4gVygpLFwiXFxyXCI7Y2FzZVwidFwiOnJldHVybiBXKCksXCJcXHRcIjtjYXNlXCJ2XCI6cmV0dXJuIFcoKSxcIlxcdlwiO2Nhc2VcIjBcIjppZihXKCksVS5pc0RpZ2l0KHEoKSkpdGhyb3cgdHUoVygpKTtyZXR1cm5cIlxcMFwiO2Nhc2VcInhcIjpyZXR1cm4gVygpLGZ1bmN0aW9uKCl7dmFyIHU9XCJcIixEPXEoKTtpZighVS5pc0hleERpZ2l0KEQpKXRocm93IHR1KFcoKSk7aWYodSs9VygpLEQ9cSgpLCFVLmlzSGV4RGlnaXQoRCkpdGhyb3cgdHUoVygpKTtyZXR1cm4gdSs9VygpLFN0cmluZy5mcm9tQ29kZVBvaW50KHBhcnNlSW50KHUsMTYpKX0oKTtjYXNlXCJ1XCI6cmV0dXJuIFcoKSxZKCk7Y2FzZVwiXFxuXCI6Y2FzZVwiXFx1MjAyOFwiOmNhc2VcIlxcdTIwMjlcIjpyZXR1cm4gVygpLFwiXCI7Y2FzZVwiXFxyXCI6cmV0dXJuIFcoKSxcIlxcblwiPT09cSgpJiZXKCksXCJcIjtjYXNlXCIxXCI6Y2FzZVwiMlwiOmNhc2VcIjNcIjpjYXNlXCI0XCI6Y2FzZVwiNVwiOmNhc2VcIjZcIjpjYXNlXCI3XCI6Y2FzZVwiOFwiOmNhc2VcIjlcIjpjYXNlIHZvaWQgMDp0aHJvdyB0dShXKCkpfXJldHVybiBXKCl9KCkpO2Nhc2UnXCInOnJldHVybiBIPyhXKCksSyhcInN0cmluZ1wiLHopKTp2b2lkKHorPVcoKSk7Y2FzZVwiJ1wiOnJldHVybiBIP3ZvaWQoeis9VygpKTooVygpLEsoXCJzdHJpbmdcIix6KSk7Y2FzZVwiXFxuXCI6Y2FzZVwiXFxyXCI6dGhyb3cgdHUoVygpKTtjYXNlXCJcXHUyMDI4XCI6Y2FzZVwiXFx1MjAyOVwiOiFmdW5jdGlvbih1KXtjb25zb2xlLndhcm4oXCJKU09ONTogJ1wiK251KHUpK1wiJyBpbiBzdHJpbmdzIGlzIG5vdCB2YWxpZCBFQ01BU2NyaXB0OyBjb25zaWRlciBlc2NhcGluZ1wiKX0oUik7YnJlYWs7Y2FzZSB2b2lkIDA6dGhyb3cgdHUoVygpKX16Kz1XKCl9LHN0YXJ0OmZ1bmN0aW9uKCl7c3dpdGNoKFIpe2Nhc2VcIntcIjpjYXNlXCJbXCI6cmV0dXJuIEsoXCJwdW5jdHVhdG9yXCIsVygpKX1UPVwidmFsdWVcIn0sYmVmb3JlUHJvcGVydHlOYW1lOmZ1bmN0aW9uKCl7c3dpdGNoKFIpe2Nhc2VcIiRcIjpjYXNlXCJfXCI6cmV0dXJuIHo9VygpLHZvaWQoVD1cImlkZW50aWZpZXJOYW1lXCIpO2Nhc2VcIlxcXFxcIjpyZXR1cm4gVygpLHZvaWQoVD1cImlkZW50aWZpZXJOYW1lU3RhcnRFc2NhcGVcIik7Y2FzZVwifVwiOnJldHVybiBLKFwicHVuY3R1YXRvclwiLFcoKSk7Y2FzZSdcIic6Y2FzZVwiJ1wiOnJldHVybiBIPSdcIic9PT1XKCksdm9pZChUPVwic3RyaW5nXCIpfWlmKFUuaXNJZFN0YXJ0Q2hhcihSKSlyZXR1cm4geis9VygpLHZvaWQoVD1cImlkZW50aWZpZXJOYW1lXCIpO3Rocm93IHR1KFcoKSl9LGFmdGVyUHJvcGVydHlOYW1lOmZ1bmN0aW9uKCl7aWYoXCI6XCI9PT1SKXJldHVybiBLKFwicHVuY3R1YXRvclwiLFcoKSk7dGhyb3cgdHUoVygpKX0sYmVmb3JlUHJvcGVydHlWYWx1ZTpmdW5jdGlvbigpe1Q9XCJ2YWx1ZVwifSxhZnRlclByb3BlcnR5VmFsdWU6ZnVuY3Rpb24oKXtzd2l0Y2goUil7Y2FzZVwiLFwiOmNhc2VcIn1cIjpyZXR1cm4gSyhcInB1bmN0dWF0b3JcIixXKCkpfXRocm93IHR1KFcoKSl9LGJlZm9yZUFycmF5VmFsdWU6ZnVuY3Rpb24oKXtpZihcIl1cIj09PVIpcmV0dXJuIEsoXCJwdW5jdHVhdG9yXCIsVygpKTtUPVwidmFsdWVcIn0sYWZ0ZXJBcnJheVZhbHVlOmZ1bmN0aW9uKCl7c3dpdGNoKFIpe2Nhc2VcIixcIjpjYXNlXCJdXCI6cmV0dXJuIEsoXCJwdW5jdHVhdG9yXCIsVygpKX10aHJvdyB0dShXKCkpfSxlbmQ6ZnVuY3Rpb24oKXt0aHJvdyB0dShXKCkpfX07ZnVuY3Rpb24gSyh1LEQpe3JldHVybnt0eXBlOnUsdmFsdWU6RCxsaW5lOlYsY29sdW1uOkp9fWZ1bmN0aW9uIFEodSl7Zm9yKHZhciBEPTAsZT11O0Q8ZS5sZW5ndGg7RCs9MSl7dmFyIHQ9ZVtEXTtpZihxKCkhPT10KXRocm93IHR1KFcoKSk7VygpfX1mdW5jdGlvbiBZKCl7Zm9yKHZhciB1PVwiXCIsRD00O0QtLSA+MDspe3ZhciBlPXEoKTtpZighVS5pc0hleERpZ2l0KGUpKXRocm93IHR1KFcoKSk7dSs9VygpfXJldHVybiBTdHJpbmcuZnJvbUNvZGVQb2ludChwYXJzZUludCh1LDE2KSl9dmFyIHV1PXtzdGFydDpmdW5jdGlvbigpe2lmKFwiZW9mXCI9PT1NLnR5cGUpdGhyb3cgcnUoKTtEdSgpfSxiZWZvcmVQcm9wZXJ0eU5hbWU6ZnVuY3Rpb24oKXtzd2l0Y2goTS50eXBlKXtjYXNlXCJpZGVudGlmaWVyXCI6Y2FzZVwic3RyaW5nXCI6cmV0dXJuIGs9TS52YWx1ZSx2b2lkKEk9XCJhZnRlclByb3BlcnR5TmFtZVwiKTtjYXNlXCJwdW5jdHVhdG9yXCI6cmV0dXJuIHZvaWQgZXUoKTtjYXNlXCJlb2ZcIjp0aHJvdyBydSgpfX0sYWZ0ZXJQcm9wZXJ0eU5hbWU6ZnVuY3Rpb24oKXtpZihcImVvZlwiPT09TS50eXBlKXRocm93IHJ1KCk7ST1cImJlZm9yZVByb3BlcnR5VmFsdWVcIn0sYmVmb3JlUHJvcGVydHlWYWx1ZTpmdW5jdGlvbigpe2lmKFwiZW9mXCI9PT1NLnR5cGUpdGhyb3cgcnUoKTtEdSgpfSxiZWZvcmVBcnJheVZhbHVlOmZ1bmN0aW9uKCl7aWYoXCJlb2ZcIj09PU0udHlwZSl0aHJvdyBydSgpO1wicHVuY3R1YXRvclwiIT09TS50eXBlfHxcIl1cIiE9PU0udmFsdWU/RHUoKTpldSgpfSxhZnRlclByb3BlcnR5VmFsdWU6ZnVuY3Rpb24oKXtpZihcImVvZlwiPT09TS50eXBlKXRocm93IHJ1KCk7c3dpdGNoKE0udmFsdWUpe2Nhc2VcIixcIjpyZXR1cm4gdm9pZChJPVwiYmVmb3JlUHJvcGVydHlOYW1lXCIpO2Nhc2VcIn1cIjpldSgpfX0sYWZ0ZXJBcnJheVZhbHVlOmZ1bmN0aW9uKCl7aWYoXCJlb2ZcIj09PU0udHlwZSl0aHJvdyBydSgpO3N3aXRjaChNLnZhbHVlKXtjYXNlXCIsXCI6cmV0dXJuIHZvaWQoST1cImJlZm9yZUFycmF5VmFsdWVcIik7Y2FzZVwiXVwiOmV1KCl9fSxlbmQ6ZnVuY3Rpb24oKXt9fTtmdW5jdGlvbiBEdSgpe3ZhciB1O3N3aXRjaChNLnR5cGUpe2Nhc2VcInB1bmN0dWF0b3JcIjpzd2l0Y2goTS52YWx1ZSl7Y2FzZVwie1wiOnU9e307YnJlYWs7Y2FzZVwiW1wiOnU9W119YnJlYWs7Y2FzZVwibnVsbFwiOmNhc2VcImJvb2xlYW5cIjpjYXNlXCJudW1lcmljXCI6Y2FzZVwic3RyaW5nXCI6dT1NLnZhbHVlfWlmKHZvaWQgMD09PUwpTD11O2Vsc2V7dmFyIEQ9T1tPLmxlbmd0aC0xXTtBcnJheS5pc0FycmF5KEQpP0QucHVzaCh1KTpEW2tdPXV9aWYobnVsbCE9PXUmJlwib2JqZWN0XCI9PXR5cGVvZiB1KU8ucHVzaCh1KSxJPUFycmF5LmlzQXJyYXkodSk/XCJiZWZvcmVBcnJheVZhbHVlXCI6XCJiZWZvcmVQcm9wZXJ0eU5hbWVcIjtlbHNle3ZhciBlPU9bTy5sZW5ndGgtMV07ST1udWxsPT1lP1wiZW5kXCI6QXJyYXkuaXNBcnJheShlKT9cImFmdGVyQXJyYXlWYWx1ZVwiOlwiYWZ0ZXJQcm9wZXJ0eVZhbHVlXCJ9fWZ1bmN0aW9uIGV1KCl7Ty5wb3AoKTt2YXIgdT1PW08ubGVuZ3RoLTFdO0k9bnVsbD09dT9cImVuZFwiOkFycmF5LmlzQXJyYXkodSk/XCJhZnRlckFycmF5VmFsdWVcIjpcImFmdGVyUHJvcGVydHlWYWx1ZVwifWZ1bmN0aW9uIHR1KHUpe3JldHVybiBDdSh2b2lkIDA9PT11P1wiSlNPTjU6IGludmFsaWQgZW5kIG9mIGlucHV0IGF0IFwiK1YrXCI6XCIrSjpcIkpTT041OiBpbnZhbGlkIGNoYXJhY3RlciAnXCIrbnUodSkrXCInIGF0IFwiK1YrXCI6XCIrSil9ZnVuY3Rpb24gcnUoKXtyZXR1cm4gQ3UoXCJKU09ONTogaW52YWxpZCBlbmQgb2YgaW5wdXQgYXQgXCIrVitcIjpcIitKKX1mdW5jdGlvbiBGdSgpe3JldHVybiBDdShcIkpTT041OiBpbnZhbGlkIGlkZW50aWZpZXIgY2hhcmFjdGVyIGF0IFwiK1YrXCI6XCIrKEotPTUpKX1mdW5jdGlvbiBudSh1KXt2YXIgRD17XCInXCI6XCJcXFxcJ1wiLCdcIic6J1xcXFxcIicsXCJcXFxcXCI6XCJcXFxcXFxcXFwiLFwiXFxiXCI6XCJcXFxcYlwiLFwiXFxmXCI6XCJcXFxcZlwiLFwiXFxuXCI6XCJcXFxcblwiLFwiXFxyXCI6XCJcXFxcclwiLFwiXFx0XCI6XCJcXFxcdFwiLFwiXFx2XCI6XCJcXFxcdlwiLFwiXFwwXCI6XCJcXFxcMFwiLFwiXFx1MjAyOFwiOlwiXFxcXHUyMDI4XCIsXCJcXHUyMDI5XCI6XCJcXFxcdTIwMjlcIn07aWYoRFt1XSlyZXR1cm4gRFt1XTtpZih1PFwiIFwiKXt2YXIgZT11LmNoYXJDb2RlQXQoMCkudG9TdHJpbmcoMTYpO3JldHVyblwiXFxcXHhcIisoXCIwMFwiK2UpLnN1YnN0cmluZyhlLmxlbmd0aCl9cmV0dXJuIHV9ZnVuY3Rpb24gQ3UodSl7dmFyIEQ9bmV3IFN5bnRheEVycm9yKHUpO3JldHVybiBELmxpbmVOdW1iZXI9VixELmNvbHVtbk51bWJlcj1KLER9cmV0dXJue3BhcnNlOmZ1bmN0aW9uKHUsRCl7Xz1TdHJpbmcodSksST1cInN0YXJ0XCIsTz1bXSxqPTAsVj0xLEo9MCxNPXZvaWQgMCxrPXZvaWQgMCxMPXZvaWQgMDtkb3tNPVooKSx1dVtJXSgpfXdoaWxlKFwiZW9mXCIhPT1NLnR5cGUpO3JldHVyblwiZnVuY3Rpb25cIj09dHlwZW9mIEQ/ZnVuY3Rpb24gdShELGUsdCl7dmFyIHI9RFtlXTtpZihudWxsIT1yJiZcIm9iamVjdFwiPT10eXBlb2Ygcilmb3IodmFyIEYgaW4gcil7dmFyIG49dShyLEYsdCk7dm9pZCAwPT09bj9kZWxldGUgcltGXTpyW0ZdPW59cmV0dXJuIHQuY2FsbChELGUscil9KHtcIlwiOkx9LFwiXCIsRCk6TH0sc3RyaW5naWZ5OmZ1bmN0aW9uKHUsRCxlKXt2YXIgdCxyLEYsbj1bXSxDPVwiXCIsQT1cIlwiO2lmKG51bGw9PUR8fFwib2JqZWN0XCIhPXR5cGVvZiBEfHxBcnJheS5pc0FycmF5KEQpfHwoZT1ELnNwYWNlLEY9RC5xdW90ZSxEPUQucmVwbGFjZXIpLFwiZnVuY3Rpb25cIj09dHlwZW9mIEQpcj1EO2Vsc2UgaWYoQXJyYXkuaXNBcnJheShEKSl7dD1bXTtmb3IodmFyIGk9MCxFPUQ7aTxFLmxlbmd0aDtpKz0xKXt2YXIgbz1FW2ldLGE9dm9pZCAwO1wic3RyaW5nXCI9PXR5cGVvZiBvP2E9bzooXCJudW1iZXJcIj09dHlwZW9mIG98fG8gaW5zdGFuY2VvZiBTdHJpbmd8fG8gaW5zdGFuY2VvZiBOdW1iZXIpJiYoYT1TdHJpbmcobykpLHZvaWQgMCE9PWEmJnQuaW5kZXhPZihhKTwwJiZ0LnB1c2goYSl9fXJldHVybiBlIGluc3RhbmNlb2YgTnVtYmVyP2U9TnVtYmVyKGUpOmUgaW5zdGFuY2VvZiBTdHJpbmcmJihlPVN0cmluZyhlKSksXCJudW1iZXJcIj09dHlwZW9mIGU/ZT4wJiYoZT1NYXRoLm1pbigxMCxNYXRoLmZsb29yKGUpKSxBPVwiICAgICAgICAgIFwiLnN1YnN0cigwLGUpKTpcInN0cmluZ1wiPT10eXBlb2YgZSYmKEE9ZS5zdWJzdHIoMCwxMCkpLGMoXCJcIix7XCJcIjp1fSk7ZnVuY3Rpb24gYyh1LEQpe3ZhciBlPURbdV07c3dpdGNoKG51bGwhPWUmJihcImZ1bmN0aW9uXCI9PXR5cGVvZiBlLnRvSlNPTjU/ZT1lLnRvSlNPTjUodSk6XCJmdW5jdGlvblwiPT10eXBlb2YgZS50b0pTT04mJihlPWUudG9KU09OKHUpKSksciYmKGU9ci5jYWxsKEQsdSxlKSksZSBpbnN0YW5jZW9mIE51bWJlcj9lPU51bWJlcihlKTplIGluc3RhbmNlb2YgU3RyaW5nP2U9U3RyaW5nKGUpOmUgaW5zdGFuY2VvZiBCb29sZWFuJiYoZT1lLnZhbHVlT2YoKSksZSl7Y2FzZSBudWxsOnJldHVyblwibnVsbFwiO2Nhc2UhMDpyZXR1cm5cInRydWVcIjtjYXNlITE6cmV0dXJuXCJmYWxzZVwifXJldHVyblwic3RyaW5nXCI9PXR5cGVvZiBlP0IoZSk6XCJudW1iZXJcIj09dHlwZW9mIGU/U3RyaW5nKGUpOlwib2JqZWN0XCI9PXR5cGVvZiBlP0FycmF5LmlzQXJyYXkoZSk/ZnVuY3Rpb24odSl7aWYobi5pbmRleE9mKHUpPj0wKXRocm93IFR5cGVFcnJvcihcIkNvbnZlcnRpbmcgY2lyY3VsYXIgc3RydWN0dXJlIHRvIEpTT041XCIpO24ucHVzaCh1KTt2YXIgRD1DO0MrPUE7Zm9yKHZhciBlLHQ9W10scj0wO3I8dS5sZW5ndGg7cisrKXt2YXIgRj1jKFN0cmluZyhyKSx1KTt0LnB1c2godm9pZCAwIT09Rj9GOlwibnVsbFwiKX1pZigwPT09dC5sZW5ndGgpZT1cIltdXCI7ZWxzZSBpZihcIlwiPT09QSl7dmFyIGk9dC5qb2luKFwiLFwiKTtlPVwiW1wiK2krXCJdXCJ9ZWxzZXt2YXIgRT1cIixcXG5cIitDLG89dC5qb2luKEUpO2U9XCJbXFxuXCIrQytvK1wiLFxcblwiK0QrXCJdXCJ9cmV0dXJuIG4ucG9wKCksQz1ELGV9KGUpOmZ1bmN0aW9uKHUpe2lmKG4uaW5kZXhPZih1KT49MCl0aHJvdyBUeXBlRXJyb3IoXCJDb252ZXJ0aW5nIGNpcmN1bGFyIHN0cnVjdHVyZSB0byBKU09ONVwiKTtuLnB1c2godSk7dmFyIEQ9QztDKz1BO2Zvcih2YXIgZSxyLEY9dHx8T2JqZWN0LmtleXModSksaT1bXSxFPTAsbz1GO0U8by5sZW5ndGg7RSs9MSl7dmFyIGE9b1tFXSxCPWMoYSx1KTtpZih2b2lkIDAhPT1CKXt2YXIgZj1zKGEpK1wiOlwiO1wiXCIhPT1BJiYoZis9XCIgXCIpLGYrPUIsaS5wdXNoKGYpfX1pZigwPT09aS5sZW5ndGgpZT1cInt9XCI7ZWxzZSBpZihcIlwiPT09QSlyPWkuam9pbihcIixcIiksZT1cIntcIityK1wifVwiO2Vsc2V7dmFyIGw9XCIsXFxuXCIrQztyPWkuam9pbihsKSxlPVwie1xcblwiK0MrcitcIixcXG5cIitEK1wifVwifXJldHVybiBuLnBvcCgpLEM9RCxlfShlKTp2b2lkIDB9ZnVuY3Rpb24gQih1KXtmb3IodmFyIEQ9e1wiJ1wiOi4xLCdcIic6LjJ9LGU9e1wiJ1wiOlwiXFxcXCdcIiwnXCInOidcXFxcXCInLFwiXFxcXFwiOlwiXFxcXFxcXFxcIixcIlxcYlwiOlwiXFxcXGJcIixcIlxcZlwiOlwiXFxcXGZcIixcIlxcblwiOlwiXFxcXG5cIixcIlxcclwiOlwiXFxcXHJcIixcIlxcdFwiOlwiXFxcXHRcIixcIlxcdlwiOlwiXFxcXHZcIixcIlxcMFwiOlwiXFxcXDBcIixcIlxcdTIwMjhcIjpcIlxcXFx1MjAyOFwiLFwiXFx1MjAyOVwiOlwiXFxcXHUyMDI5XCJ9LHQ9XCJcIixyPTA7cjx1Lmxlbmd0aDtyKyspe3ZhciBuPXVbcl07c3dpdGNoKG4pe2Nhc2VcIidcIjpjYXNlJ1wiJzpEW25dKyssdCs9bjtjb250aW51ZTtjYXNlXCJcXDBcIjppZihVLmlzRGlnaXQodVtyKzFdKSl7dCs9XCJcXFxceDAwXCI7Y29udGludWV9fWlmKGVbbl0pdCs9ZVtuXTtlbHNlIGlmKG48XCIgXCIpe3ZhciBDPW4uY2hhckNvZGVBdCgwKS50b1N0cmluZygxNik7dCs9XCJcXFxceFwiKyhcIjAwXCIrQykuc3Vic3RyaW5nKEMubGVuZ3RoKX1lbHNlIHQrPW59dmFyIEE9Rnx8T2JqZWN0LmtleXMoRCkucmVkdWNlKGZ1bmN0aW9uKHUsZSl7cmV0dXJuIERbdV08RFtlXT91OmV9KTtyZXR1cm4gQSsodD10LnJlcGxhY2UobmV3IFJlZ0V4cChBLFwiZ1wiKSxlW0FdKSkrQX1mdW5jdGlvbiBzKHUpe2lmKDA9PT11Lmxlbmd0aClyZXR1cm4gQih1KTt2YXIgRD1TdHJpbmcuZnJvbUNvZGVQb2ludCh1LmNvZGVQb2ludEF0KDApKTtpZighVS5pc0lkU3RhcnRDaGFyKEQpKXJldHVybiBCKHUpO2Zvcih2YXIgZT1ELmxlbmd0aDtlPHUubGVuZ3RoO2UrKylpZighVS5pc0lkQ29udGludWVDaGFyKFN0cmluZy5mcm9tQ29kZVBvaW50KHUuY29kZVBvaW50QXQoZSkpKSlyZXR1cm4gQih1KTtyZXR1cm4gdX19fX0pO1xuIiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHQvLyBubyBtb2R1bGUuaWQgbmVlZGVkXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbiIsIi8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSAobW9kdWxlKSA9PiB7XG5cdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuXHRcdCgpID0+IChtb2R1bGVbJ2RlZmF1bHQnXSkgOlxuXHRcdCgpID0+IChtb2R1bGUpO1xuXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCB7IGE6IGdldHRlciB9KTtcblx0cmV0dXJuIGdldHRlcjtcbn07IiwiLy8gZGVmaW5lIGdldHRlciBmdW5jdGlvbnMgZm9yIGhhcm1vbnkgZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5kID0gKGV4cG9ydHMsIGRlZmluaXRpb24pID0+IHtcblx0Zm9yKHZhciBrZXkgaW4gZGVmaW5pdGlvbikge1xuXHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhkZWZpbml0aW9uLCBrZXkpICYmICFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywga2V5KSkge1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIGtleSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGRlZmluaXRpb25ba2V5XSB9KTtcblx0XHR9XG5cdH1cbn07IiwiX193ZWJwYWNrX3JlcXVpcmVfXy5vID0gKG9iaiwgcHJvcCkgPT4gKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIHByb3ApKSIsIi8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uciA9IChleHBvcnRzKSA9PiB7XG5cdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuXHR9XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG59OyIsImltcG9ydCBkb20sIHsgRnJhZ21lbnQgfSBmcm9tICcuLi91dGlsL2pzeC1yZW5kZXItbW9kL2RvbSc7XHJcbmltcG9ydCAqIGFzIFNlc0FwaSBmcm9tICcuLi91dGlsL2FwaSc7XHJcbmltcG9ydCByb3V0ZXIsIHsgTGluaywgcmVkaXJlY3QgfSBmcm9tICcuLi91dGlsL3JvdXRlcic7XHJcbmltcG9ydCBwYXJzZSBmcm9tICcuLi91dGlsL3BhcnNlJztcclxuaW1wb3J0IHsgcmVwbGFjZUNvbnRlbnRzLCBMb2FkaW5nIH0gZnJvbSAnLi4vdXRpbC90ZW1wbGF0ZSc7XHJcbmltcG9ydCB7IGdldEFkdmFuY2VkU3VtbWFyeSwgZ2V0RmluYWxpemVkU3VydmV5c0V4cG9ydCwgZ2V0U3VtbWFyeSwgZ2V0U3VydmV5QnlJZCwgZ2V0U3VydmV5cyB9IGZyb20gJy4vZGF0YSc7XHJcbmltcG9ydCBTdW1tYXJ5IGZyb20gJy4vU3VtbWFyeSc7XHJcbmltcG9ydCBEZXRhaWxzIGZyb20gJy4vRGV0YWlscyc7XHJcblxyXG5kb2N1bWVudC50aXRsZSA9ICdTdXJ2ZXkgUmVzdWx0cyc7XHJcblxyXG5kb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcuY29udGVudCcpWzBdLmlubmVySFRNTCA9ICcnO1xyXG5cclxubGV0IGNvbnRhaW5lciA9IDxkaXYgaWQ9XCJzdXJ2ZXlDb250ZW50XCI+PC9kaXY+O1xyXG5cclxuZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnLmNvbnRlbnQnKVswXS5hcHBlbmRDaGlsZChcclxuICAgIDxkaXYgY2xhc3M9XCJjb250YWluZXIgYWRtaW5pc3RyYXRpb24tY29udGFpbmVyXCI+XHJcbiAgICAgICAgPHNlY3Rpb24gY2xhc3M9XCJjb250YWluZXJcIj5cclxuICAgICAgICAgICAgPGgxPlN1cnZleSBSZXN1bHRzPC9oMT5cclxuICAgICAgICAgICAgPHNlY3Rpb24gY2xhc3M9XCJib3R0b20tYnVmZmVyXCI+XHJcbiAgICAgICAgICAgICAgICB7Y29udGFpbmVyfVxyXG4gICAgICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgPC9kaXY+KTtcclxuXHJcblxyXG5yb3V0ZXIucmVnaXN0ZXIoW1xyXG4gICAge1xyXG4gICAgICAgIG1hdGNoOiBudWxsLFxyXG4gICAgICAgIGhhbmRsZXI6IGZldGNoU3VydmV5c1xyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgICBtYXRjaDogJ3BhZ2UnLFxyXG4gICAgICAgIGhhbmRsZXI6IGZldGNoU3VydmV5c1xyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgICBtYXRjaDogJ3NlYXJjaCcsXHJcbiAgICAgICAgaGFuZGxlcjogZmV0Y2hTdXJ2ZXlzXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICAgIG1hdGNoOiAnaWQnLFxyXG4gICAgICAgIGhhbmRsZXI6IGdldERldGFpbHNcclxuICAgIH1cclxuXSk7XHJcblxyXG5hc3luYyBmdW5jdGlvbiBmZXRjaFN1cnZleXMoKSB7XHJcbiAgICBjb25zdCBxdWVyeSA9IHBhcnNlLnF1ZXJ5U3RyaW5nKGRvY3VtZW50LmxvY2F0aW9uLnNlYXJjaCk7XHJcbiAgICBjb25zdCBwYWdlID0gTnVtYmVyKHF1ZXJ5ICYmIHF1ZXJ5LnBhZ2UpIHx8IDE7XHJcblxyXG4gICAgY29udGFpbmVyID0gcmVwbGFjZUNvbnRlbnRzKGNvbnRhaW5lciwgPGRpdj5Mb2FkaW5nIHN1cnZleXMmaGVsbGlwOyA8TG9hZGluZyBjb2xvcj1cImJsYWNrXCIgLz48L2Rpdj4pO1xyXG5cclxuICAgIGNvbnN0IGN1cnJlbnRRdWVyeSA9IGRlY29kZVVSSUNvbXBvbmVudCgocXVlcnkgPyBxdWVyeS5zZWFyY2ggOiAnJykgfHwgJycpO1xyXG4gICAgY29uc3Qgc2VhcmNoSW5wdXQgPSAoPGZvcm0gb25TdWJtaXQ9e2ZpbHRlclN1cnZleXN9PlxyXG4gICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIG5hbWU9XCJxdWVyeVwiIHZhbHVlPXtjdXJyZW50UXVlcnl9IC8+XHJcbiAgICAgICAgPGlucHV0IHR5cGU9XCJzdWJtaXRcIiB2YWx1ZT1cIkZpbHRlclwiIC8+XHJcbiAgICA8L2Zvcm0+KTtcclxuXHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGdldFN1cnZleXMoU2VzQXBpLCBwYWdlLCBjdXJyZW50UXVlcnkpO1xyXG4gICAgY29uc3QgcGFnZXMgPSBNYXRoLmNlaWwocmVzcG9uc2UuVG90YWwgLyAzMCk7XHJcblxyXG4gICAgY29udGFpbmVyID0gcmVwbGFjZUNvbnRlbnRzKGNvbnRhaW5lciwgKDxTdW1tYXJ5XHJcbiAgICAgICAgcGFnZT17cGFnZX1cclxuICAgICAgICBwYWdlcz17cGFnZXN9XHJcbiAgICAgICAgc3VydmV5cz17cmVzcG9uc2UuRGF0YX1cclxuICAgICAgICBwYWdlU2VsZWN0PXtmZXRjaFN1cnZleXN9XHJcbiAgICAgICAgZ2V0RGV0YWlscz17Z2V0RGV0YWlsc31cclxuICAgICAgICBnZXRTdW1tYXJ5PXtzdXJ2ZXkgPT4gZ2V0U3VtbWFyeShTZXNBcGksIHN1cnZleSl9XHJcbiAgICAgICAgZ2V0QWR2YW5jZWRTdW1tYXJ5PXsoc3VydmV5LCBvblByb2dyZXNzID0gdW5kZWZpbmVkKSA9PiBnZXRBZHZhbmNlZFN1bW1hcnkoU2VzQXBpLCBzdXJ2ZXksIG9uUHJvZ3Jlc3MpfVxyXG4gICAgICAgIGdldEZpbmFsaXplZFN1cnZleXNFeHBvcnQ9eyhzdGFydERhdGUsIGVuZERhdGUsIG9uUHJvZ3Jlc3MgPSB1bmRlZmluZWQpID0+IGdldEZpbmFsaXplZFN1cnZleXNFeHBvcnQoU2VzQXBpLCBzdGFydERhdGUsIGVuZERhdGUsIG9uUHJvZ3Jlc3MpfVxyXG4gICAgICAgIHNlYXJjaElucHV0PXtzZWFyY2hJbnB1dH1cclxuICAgICAgICBzZWFyY2hRdWVyeT17Y3VycmVudFF1ZXJ5fVxyXG4gICAgLz4pKTtcclxuXHJcbiAgICBmdW5jdGlvbiBmaWx0ZXJTdXJ2ZXlzKGV2ZW50KSB7XHJcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICBjb25zdCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YShldmVudC50YXJnZXQpO1xyXG4gICAgICAgIHJlZGlyZWN0KGAvc2VzL3N1cnZleXM/c2VhcmNoPSR7ZW5jb2RlVVJJQ29tcG9uZW50KGZvcm1EYXRhLmdldCgncXVlcnknKS50cmltKCkgfHwgJycpfWApO1xyXG4gICAgfVxyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBnZXREZXRhaWxzKCkge1xyXG4gICAgY29uc3QgcXVlcnkgPSBwYXJzZS5xdWVyeVN0cmluZyhkb2N1bWVudC5sb2NhdGlvbi5zZWFyY2gpO1xyXG4gICAgY29uc3Qgc3VydmV5SWQgPSBxdWVyeS5pZDtcclxuXHJcbiAgICBjb25zdCBzdXJ2ZXkgPSBhd2FpdCBnZXRTdXJ2ZXlCeUlkKFNlc0FwaSwgc3VydmV5SWQpO1xyXG5cclxuICAgIGxldCByZXN1bHRzRGl2ID0gPGRpdiBpZD1cInN1cnZleVJlc3VsdHNcIj5Mb2FkaW5nIGRldGFpbHMmaGVsbGlwOyA8TG9hZGluZyBjb2xvcj1cImJsYWNrXCIgLz48L2Rpdj47XHJcblxyXG4gICAgY29udGFpbmVyID0gcmVwbGFjZUNvbnRlbnRzKGNvbnRhaW5lciwgKDxGcmFnbWVudD5cclxuICAgICAgICA8aDI+e3N1cnZleS5OYW1lfTwvaDI+XHJcbiAgICAgICAgPExpbmsgdG89e2ZldGNoU3VydmV5c30gY2xhc3NOYW1lPVwibmF2LWJhY2stbGlua1wiIGhyZWY9XCIvc2VzL3N1cnZleXNcIj5CYWNrIHRvIGxpc3Q8L0xpbms+XHJcbiAgICAgICAge3Jlc3VsdHNEaXZ9XHJcbiAgICA8L0ZyYWdtZW50PikpO1xyXG5cclxuICAgIGNvbnN0IHN1bW1hcnkgPSBhd2FpdCBnZXRTdW1tYXJ5KFNlc0FwaSwgc3VydmV5KTtcclxuICAgIGNvbnN0IGdldEFkdmFuY2VkU3VtbWFyeVBhcnRpYWwgPSAocywgb25Qcm9ncmVzcykgPT4gZ2V0QWR2YW5jZWRTdW1tYXJ5KFNlc0FwaSwgcywgb25Qcm9ncmVzcyk7XHJcblxyXG4gICAgcmVzdWx0c0RpdiA9IHJlcGxhY2VDb250ZW50cyhyZXN1bHRzRGl2LCA8RGV0YWlscyBzdXJ2ZXk9e3N1cnZleX0gc3VtbWFyeT17c3VtbWFyeX0gZ2V0QWR2YW5jZWRTdW1tYXJ5PXtnZXRBZHZhbmNlZFN1bW1hcnlQYXJ0aWFsfSAvPik7XHJcbn1cclxuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9