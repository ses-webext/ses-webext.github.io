/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/util/jsx-render-mod/dom.js":
/*!****************************************!*\
  !*** ./src/util/jsx-render-mod/dom.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Fragment": () => (/* binding */ Fragment),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "portalCreator": () => (/* binding */ portalCreator)
/* harmony export */ });
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils */ "./src/util/jsx-render-mod/utils.js");

/**
 * The tag name and create an html together with the attributes
 *
 * @param  {String} tagName name as string, e.g. 'div', 'span', 'svg'
 * @param  {Object} attrs html attributes e.g. data-, width, src
 * @param  {Array} children html nodes from inside de elements
 * @return {HTMLElement|SVGElement} html node with attrs
 */

function createElements(tagName, attrs, children) {
  const element = (0,_utils__WEBPACK_IMPORTED_MODULE_0__.isSVG)(tagName) ? document.createElementNS('http://www.w3.org/2000/svg', tagName) : document.createElement(tagName); // one or multiple will be evaluated to append as string or HTMLElement

  const fragment = (0,_utils__WEBPACK_IMPORTED_MODULE_0__.createFragmentFrom)(children);
  element.appendChild(fragment);
  Object.keys(attrs || {}).forEach(prop => {
    if (prop === 'style') {
      // e.g. origin: <element style={{ prop: value }} />
      Object.assign(element.style, attrs[prop]);
    } else if (prop === 'ref' && typeof attrs.ref === 'function') {
      attrs.ref(element, attrs);
    } else if (prop === 'className') {
      element.setAttribute('class', attrs[prop]);
    } else if (prop === 'xlinkHref') {
      element.setAttributeNS('http://www.w3.org/1999/xlink', 'xlink:href', attrs[prop]);
    } else if (prop === 'dangerouslySetInnerHTML') {
      // eslint-disable-next-line no-underscore-dangle
      element.innerHTML = attrs[prop].__html;
    } else if (prop in _utils__WEBPACK_IMPORTED_MODULE_0__.EVENT_LISTENERS) {
      element.addEventListener(_utils__WEBPACK_IMPORTED_MODULE_0__.EVENT_LISTENERS[prop], attrs[prop]);
    } else {
      // any other prop will be set as attribute
      element.setAttribute(prop, attrs[prop]);
    }
  });
  return element;
}
/**
 * The JSXTag will be unwrapped returning the html
 *
 * @param  {Function} JSXTag name as string, e.g. 'div', 'span', 'svg'
 * @param  {Object} elementProps custom jsx attributes e.g. fn, strings
 * @param  {Array} children html nodes from inside de elements
 *
 * @return {Function} returns de 'dom' (fn) executed, leaving the HTMLElement
 *
 * JSXTag:  function Comp(props) {
 *   return dom("span", null, props.num);
 * }
 */


function composeToFunction(JSXTag, elementProps, children) {
  const props = Object.assign({}, JSXTag.defaultProps || {}, elementProps, {
    children
  });
  const bridge = JSXTag.prototype && JSXTag.prototype.render ? new JSXTag(props).render : JSXTag;
  const result = bridge(props);

  switch (result) {
    case 'FRAGMENT':
      return (0,_utils__WEBPACK_IMPORTED_MODULE_0__.createFragmentFrom)(children);
    // Portals are useful to render modals
    // allow render on a different element than the parent of the chain
    // and leave a comment instead

    case 'PORTAL':
      bridge.target.appendChild((0,_utils__WEBPACK_IMPORTED_MODULE_0__.createFragmentFrom)(children));
      return document.createComment('Portal Used');

    default:
      return result;
  }
}

function dom(element, attrs, ...children) {
  // Custom Components will be functions
  if (typeof element === 'function') {
    if (element.hasOwnProperty('propTypes')) {
      for (let prop of element.propTypes) {
        if (attrs.hasOwnProperty(prop) === false) {
          console.error(`JSX Error: Missing property '${prop}' from '${element.name}' invocation`);
        }
      }
    } // e.g. const CustomTag = ({ w }) => <span width={w} />
    // will be used
    // e.g. <CustomTag w={1} />
    // becomes: CustomTag({ w: 1})


    return composeToFunction(element, attrs, children);
  } // regular html components will be strings to create the elements
  // this is handled by the babel plugins


  if (typeof element === 'string') {
    return createElements(element, attrs, children);
  }

  return console.error(`jsx-render does not handle ${typeof tag}`);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (dom);
const Fragment = () => 'FRAGMENT';
const portalCreator = node => {
  function Portal() {
    return 'PORTAL';
  }

  Portal.target = document.body;

  if (node && node.nodeType === Node.ELEMENT_NODE) {
    Portal.target = node;
  }

  return Portal;
};

/***/ }),

/***/ "./src/util/jsx-render-mod/utils.js":
/*!******************************************!*\
  !*** ./src/util/jsx-render-mod/utils.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EVENT_LISTENERS": () => (/* binding */ EVENT_LISTENERS),
/* harmony export */   "createFragmentFrom": () => (/* binding */ createFragmentFrom),
/* harmony export */   "isSVG": () => (/* binding */ isSVG)
/* harmony export */ });
function isSVG(element) {
  const patt = new RegExp(`^${element}$`, 'i');
  const SVGTags = ['path', 'svg', 'use', 'g'];
  return SVGTags.some(tag => patt.test(tag));
}
function createFragmentFrom(children) {
  // fragments will help later to append multiple children to the initial node
  const fragment = document.createDocumentFragment();

  function processDOMNodes(child) {
    if (child instanceof HTMLElement || child instanceof SVGElement || child instanceof Comment || child instanceof DocumentFragment) {
      fragment.appendChild(child);
    } else if (typeof child === 'string' || typeof child === 'number') {
      const textnode = document.createTextNode(child);
      fragment.appendChild(textnode);
    } else if (child instanceof Array) {
      child.forEach(processDOMNodes);
    } else if (child === false || child === null) {// expression evaluated as false e.g. {false && <Elem />}
      // expression evaluated as false e.g. {null && <Elem />}
    } else if (typeof child === 'function') {} else if (true) {
      // later other things could not be HTMLElement nor strings
      console.log(child, 'is not appendable');
    }
  }

  children.forEach(processDOMNodes);
  return fragment;
} // Map from JSX property (e.g. onClick) to event name (e.g. 'click').

const EVENT_LISTENERS = {
  // Clipboard Events
  onCopy: 'copy',
  onCut: 'cut',
  onPaste: 'paste',
  // Composition Events
  onCompositionEnd: 'compositionend',
  onCompositionStart: 'compositionstart',
  onCompositionUpdate: 'compositionupdate',
  // Focus Events
  onFocus: 'focus',
  onBlur: 'blur',
  // Form Events
  onChange: 'change',
  onBeforeInput: 'beforeinput',
  onInput: 'input',
  onReset: 'reset',
  onSubmit: 'submit',
  onInvalid: 'invalid',
  // Image Events
  onLoad: 'load',
  onError: 'error',
  // Keyboard Events
  onKeyDown: 'keydown',
  onKeyPress: 'keypress',
  onKeyUp: 'keyup',
  // Media Events
  onAbort: 'abort',
  onCanPlay: 'canplay',
  onCanPlayThrough: 'canplaythrough',
  onDurationChange: 'durationchange',
  onEmptied: 'emptied',
  onEncrypted: 'encrypted',
  onEnded: 'ended',
  onLoadedData: 'loadeddata',
  onLoadedMetadata: 'loadedmetadata',
  onLoadStart: 'loadstart',
  onPause: 'pause',
  onPlay: 'play',
  onPlaying: 'playing',
  onProgress: 'progress',
  onRateChange: 'ratechange',
  onSeeked: 'seeked',
  onSeeking: 'seeking',
  onStalled: 'stalled',
  onSuspend: 'suspend',
  onTimeUpdate: 'timeupdate',
  onVolumeChange: 'volumechange',
  onWaiting: 'waiting',
  // MouseEvents
  onClick: 'click',
  onContextMenu: 'contextmenu',
  onDoubleClick: 'doubleclick',
  onDrag: 'drag',
  onDragEnd: 'dragend',
  onDragEnter: 'dragenter',
  onDragExit: 'dragexit',
  onDragLeave: 'dragleave',
  onDragOver: 'dragover',
  onDragStart: 'dragstart',
  onDrop: 'drop',
  onMouseDown: 'mousedown',
  onMouseEnter: 'mouseenter',
  onMouseLeave: 'mouseleave',
  onMouseMove: 'mousemove',
  onMouseOut: 'mouseout',
  onMouseOver: 'mouseover',
  onMouseUp: 'mouseup',
  // Selection Events
  onSelect: 'select',
  // Touch Events
  onTouchCancel: 'touchcancel',
  onTouchEnd: 'touchend',
  onTouchMove: 'touchmove',
  onTouchStart: 'touchstart',
  // Pointer Events
  onPointerDown: 'pointerdown',
  onPointerMove: 'pointermove',
  onPointerUp: 'pointerup',
  onPointerCancel: 'pointercancel',
  onPointerEnter: 'pointerenter',
  onPointerLeave: 'pointerleave',
  onPointerOver: 'pointerover',
  onPointerOut: 'pointerout',
  // UI Events
  onScroll: 'scroll',
  // Wheel Events
  onWheel: 'wheel',
  // Animation Events
  onAnimationStart: 'animationstart',
  onAnimationEnd: 'animationend',
  onAnimationIteration: 'animationiteration',
  // Transition Events
  onTransitionEnd: 'transitionend'
};

/***/ }),

/***/ "./src/util/parse.js":
/*!***************************!*\
  !*** ./src/util/parse.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dateDiff": () => (/* binding */ dateDiff),
/* harmony export */   "dateDiffToDays": () => (/* binding */ dateDiffToDays),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "formatDate": () => (/* binding */ formatDate),
/* harmony export */   "formatLocaleDate": () => (/* binding */ formatLocaleDate),
/* harmony export */   "formatLocaleWeekday": () => (/* binding */ formatLocaleWeekday),
/* harmony export */   "formatTime": () => (/* binding */ formatTime),
/* harmony export */   "getDateIndex": () => (/* binding */ getDateIndex),
/* harmony export */   "getMonday": () => (/* binding */ getMonday),
/* harmony export */   "getOffsetByDays": () => (/* binding */ getOffsetByDays),
/* harmony export */   "getSunday": () => (/* binding */ getSunday),
/* harmony export */   "hasValue": () => (/* binding */ hasValue),
/* harmony export */   "htmlToText": () => (/* binding */ htmlToText),
/* harmony export */   "instanceMetaFromHref": () => (/* binding */ instanceMetaFromHref),
/* harmony export */   "isLastDay": () => (/* binding */ isLastDay),
/* harmony export */   "isLastWeek": () => (/* binding */ isLastWeek),
/* harmony export */   "localeMonthName": () => (/* binding */ localeMonthName),
/* harmony export */   "monthName": () => (/* binding */ monthName),
/* harmony export */   "normalizeDateTime": () => (/* binding */ normalizeDateTime),
/* harmony export */   "offsetByDays": () => (/* binding */ offsetByDays),
/* harmony export */   "paymentsToMatrix": () => (/* binding */ paymentsToMatrix),
/* harmony export */   "prettyJSON": () => (/* binding */ prettyJSON),
/* harmony export */   "queryString": () => (/* binding */ queryString),
/* harmony export */   "sumArrayMax": () => (/* binding */ sumArrayMax),
/* harmony export */   "toAssocArray": () => (/* binding */ toAssocArray),
/* harmony export */   "toCustomAssocArray": () => (/* binding */ toCustomAssocArray),
/* harmony export */   "uuid": () => (/* binding */ uuid),
/* harmony export */   "valueOrEmpty": () => (/* binding */ valueOrEmpty)
/* harmony export */ });
function queryString(query) {
  if (!query) {
    return null;
  }

  return query.split('?')[1].split('&').map(a => a.split('=')).reduce((a, c) => {
    a[c[0]] = c[1];
    return a;
  }, {});
}
/**
 * Calculate number of days passing between two dates
 * @param {Date} a Starting date
 * @param {Date} b Ending date
 * @returns {number} Number of days
 */


function dateDiff(a, b) {
  if (a.getFullYear() == b.getFullYear() && a.getMonth() == b.getMonth() && a.getDate() == b.getDate()) {
    return 0;
  } else {
    return b - a > 0 ? Math.ceil((b - a) / 86400000) : Math.floor((b - a) / 86400000);
  }
}

function dateDiffToDays(days) {
  if (days == 0) {
    return 'Today';
  } else {
    if (days <= 0) {
      return `In ${-days} day${days == -1 ? '' : 's'}`;
    } else {
      return `${days} day${days == 1 ? '' : 's'} ago`;
    }
  }
}
/**
 * Is the date in the last day of a month
 * @param {Date} date
 * @returns {boolean}
 */


function isLastDay(date) {
  const nextDay = new Date(date);
  nextDay.setDate(nextDay.getDate() + 1);
  return date.getMonth() != nextDay.getMonth();
}
/**
 * Is the date in the last week of a month
 * @param {Date} date
 * @returns {boolean}
 */


function isLastWeek(date) {
  const nextWeek = new Date(date);
  nextWeek.setDate(nextWeek.getDate() + 7);
  return date.getMonth() != nextWeek.getMonth();
}

function formatDate(date) {
  const asString = date.toLocaleDateString('en-US', {
    month: 'short',
    year: 'numeric'
  });
  return `${date.getDate()} ${asString}`;
}

function formatTime(date) {
  return date.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: 'numeric',
    // hour12: false,
    hourCycle: 'h23'
  });
}

function formatLocaleDate(date) {
  const day = date.getDate();
  const month = ['януари', 'февруари', 'март', 'април', 'май', 'юни', 'юли', 'август', 'септември', 'октомври', 'ноември', 'декември'][date.getMonth()];
  return `${day} ${month}`;
}

function formatLocaleWeekday(day, getAdj) {
  const weekday = ['неделя', 'понеделник', 'вторник', 'сряда', 'четвъртък', 'петък', 'събота'][day];

  if (getAdj) {
    return [weekday, ['всяка', 'всеки', 'всеки', 'всяка', 'всеки', 'всеки', 'всяка'][day]];
  }

  return weekday;
}
/**
 * Get a new date offset by the specified number of days
 * @param {Date} date Base date
 * @param {number} days How many days to offset
 * @returns {Date}
 */


function getOffsetByDays(date, days) {
  const result = new Date(date);
  result.setUTCDate(result.getUTCDate() + days);
  return result;
}
/**
 * Offset the given date in place by the specified number of days
 * @param {Date} date Base date
 * @param {number} days How many days to offset
 */

function offsetByDays(date, days) {
  date.setUTCDate(date.getUTCDate() + days);
}
/**
 * Create date index as string
 * @param {Date|string} date Base date
 * @returns {string}
 */

function getDateIndex(date) {
  if (typeof date == 'string') {
    date = new Date(date);
  }

  return date.toISOString().slice(0, 10);
}

function prettyJSON(obj) {
  return JSON.stringify(obj, null, 2).replace(/ /gmi, '&nbsp;').replace(/\n/gmi, '<br>');
}

function getMonday(date) {
  const monday = new Date(`${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()} 12:00:00`);
  monday.setDate(monday.getDate() - (monday.getDay() + 6) % 7);
  return monday;
}

function getSunday(date) {
  const sunday = new Date(`${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()} 23:59:59`);
  sunday.setDate(sunday.getDate() + (7 - sunday.getDay()) % 7);
  return sunday;
}

const monthName = {
  1: 'January',
  2: 'February',
  3: 'March',
  4: 'April',
  5: 'May',
  6: 'June',
  7: 'July',
  8: 'August',
  9: 'September',
  10: 'October',
  11: 'November',
  12: 'December'
};
const localeMonthName = {
  1: 'януари',
  2: 'февруари',
  3: 'март',
  4: 'април',
  5: 'май',
  6: 'юни',
  7: 'юли',
  8: 'август',
  9: 'септември',
  10: 'октомври',
  11: 'ноември',
  12: 'декември'
};

function toAssocArray(p, c, i, a) {
  p[c.Id] = c;
  return p;
}

function toCustomAssocArray(indexName, overwrite = false) {
  return (p, c, i, a) => {
    if (p[c[indexName]] !== undefined && overwrite == false) {
      if (Array.isArray(p[c[indexName]])) {
        p[c[indexName]].push(c);
      } else {
        p[c[indexName]] = [p[c[indexName]], c];
      }
    } else {
      p[c[indexName]] = c;
    }

    return p;
  };
}
/**
 * @param {Array<SUPayment>} data 
 * @returns {Array<PaymentViewModel>}
 */

function paymentsToMatrix(data) {
  const template = ['Id', 'PaymentNumber', 'ModuleNameEn', 'PaymentPackagesAsString', 'PaidForUserName', 'Price', 'EducationalForm', 'PaymentDateTime'];
  const parsed = data.map(e => {
    e.EducationalForm = e.EducationalForm == 1 ? 'online' : 'onsite';
    const entry = [];

    for (let prop of template) {
      if (prop === 'PaymentDateTime') {
        entry.push(new Date(e[prop]));
      } else {
        entry.push(e[prop]);
      }
    }

    return entry;
  });
  return [template, ...parsed];
}

function uuid() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    let r = Math.random() * 16 | 0,
        v = c == 'x' ? r : r & 0x3 | 0x8;
    return v.toString(16);
  });
}
function normalizeDateTime(datetime) {
  if (!datetime) {
    return '';
  } else if (datetime.toString().includes('Date(')) {
    const match = /Date\((.+)\)/.exec(datetime);

    if (match !== null) {
      const d = new Date(Number(match[1]));
      return `${('0000' + d.getFullYear()).slice(-4)}-${pt(d.getMonth() + 1)}-${pt(d.getDate())}T${pt(d.getHours())}:${pt(d.getMinutes())}`;
    } else {
      return datetime;
    }
  } else {
    return datetime;
  }
}

function pt(s) {
  return `0${s}`.slice(-2);
}

function htmlToText(html) {
  const div = document.createElement('div');
  div.innerHTML = html;
  return div.textContent;
}

function instanceMetaFromHref(href) {
  const instanceMeta = queryString(href);

  instanceMeta.InstanceRefType = (() => {
    switch (instanceMeta.type) {
      case 'course':
        return 'main';

      case 'fast-track':
        return 'open';

      case 'general-course-instance':
        return 'general';
    }
  })();

  return instanceMeta;
}
function hasValue(value) {
  return value !== null && value !== undefined && value !== '';
}
function valueOrEmpty(value, alt = '') {
  if (value === null || value === undefined || value === '') {
    return alt;
  } else {
    return value;
  }
}
function sumArrayMax(arr) {
  if (arr[0].length == 0 && arr[1].length == 0) {
    return null;
  }

  let result = 0;

  if (arr[0].length > 0) {
    result += Math.max(...arr[0]);
  }

  if (arr[1].length > 0) {
    result += Math.max(...arr[1]);
  }

  return result;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  queryString,
  dateDiff,
  dateDiffToDays,
  isLastDay,
  isLastWeek,
  formatDate,
  formatTime,
  formatLocaleDate,
  formatLocaleWeekday,
  prettyJSON,
  getMonday,
  getSunday,
  monthName,
  localeMonthName,
  toAssocArray,
  paymentsToMatrix,
  htmlToText
});


/***/ }),

/***/ "./src/util/template.js":
/*!******************************!*\
  !*** ./src/util/template.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Alert": () => (/* binding */ Alert),
/* harmony export */   "Autocomplete": () => (/* binding */ Autocomplete),
/* harmony export */   "Container": () => (/* binding */ Container),
/* harmony export */   "DownloadProgressBar": () => (/* binding */ DownloadProgressBar),
/* harmony export */   "Loading": () => (/* binding */ Loading),
/* harmony export */   "No": () => (/* binding */ No),
/* harmony export */   "Question": () => (/* binding */ Question),
/* harmony export */   "Remote": () => (/* binding */ Remote),
/* harmony export */   "Spinner": () => (/* binding */ Spinner),
/* harmony export */   "Yes": () => (/* binding */ Yes),
/* harmony export */   "applyBeginRequest": () => (/* binding */ applyBeginRequest),
/* harmony export */   "applyRequestError": () => (/* binding */ applyRequestError),
/* harmony export */   "applyRequestSuccess": () => (/* binding */ applyRequestSuccess),
/* harmony export */   "createCheckbox": () => (/* binding */ createCheckbox),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "element": () => (/* binding */ element),
/* harmony export */   "getEditorDecoration": () => (/* binding */ getEditorDecoration),
/* harmony export */   "popupTable": () => (/* binding */ popupTable),
/* harmony export */   "replaceContents": () => (/* binding */ replaceContents),
/* harmony export */   "swap": () => (/* binding */ swap),
/* harmony export */   "table": () => (/* binding */ table)
/* harmony export */ });
/* harmony import */ var _parse__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parse */ "./src/util/parse.js");
/* harmony import */ var _util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/jsx-render-mod/dom */ "./src/util/jsx-render-mod/dom.js");


/**
 * 
 * @param {*} type 
 * @param {*} content 
 * @param {*} attributes 
 * @param {{forceType: 'Text' | 'HTML'}} options 
 * @returns 
 */

function element(type, content, attributes, options = undefined) {
  const result = document.createElement(type);

  if (attributes) {
    for (let attr of Object.keys(attributes)) {
      result[attr] = attributes[attr];
    }
  }

  result.append = append.bind(result);

  result.appendTo = parent => {
    parent.append(result);
    return result;
  };

  if (content !== undefined && content !== null) {
    result.append(content, options);
  }

  return result;
}

function append(child, options = undefined) {
  if (typeof child === 'string' || typeof child === 'number') {
    if (options?.forceType != 'Text' && (options?.forceType === 'HTML' || child.toString().trim()[0] === '<')) {
      this.innerHTML = child;
    } else {
      child = document.createTextNode(child);
      this.appendChild(child);
    }
  } else if (Array.isArray(child)) {
    for (let node of child) {
      append.call(this, node);
    }
  } else {
    this.appendChild(child);
  }

  return this;
}

function replaceContents(node, newContents) {
  const cNode = node.cloneNode(false);
  append.call(cNode, newContents);

  try {
    node.parentNode.replaceChild(cNode, node);
  } catch (err) {
    console.info('Node has no parent or another problem occured');
  }

  return cNode;
}
function swap(oldNode, newNode) {
  oldNode.parentNode.replaceChild(newNode, oldNode);
  return newNode;
}
function Spinner({
  id
}) {
  const node = element('div', [element('div', null, {
    classList: 'sk-cube sk-cube1'
  }), element('div', null, {
    classList: 'sk-cube sk-cube2'
  }), element('div', null, {
    classList: 'sk-cube sk-cube3'
  }), element('div', null, {
    classList: 'sk-cube sk-cube4'
  }), element('div', null, {
    classList: 'sk-cube sk-cube5'
  }), element('div', null, {
    classList: 'sk-cube sk-cube6'
  }), element('div', null, {
    classList: 'sk-cube sk-cube7'
  }), element('div', null, {
    classList: 'sk-cube sk-cube8'
  }), element('div', null, {
    classList: 'sk-cube sk-cube9'
  })], {
    classList: 'sk-cube-grid'
  });

  if (id) {
    node.setAttribute('id', id);
  }

  return node;
}
function Loading({
  id,
  color = 'white'
}) {
  const node = element('div', [element('div', null, {
    classList: 'rect1'
  }), element('div', null, {
    classList: 'rect2'
  }), element('div', null, {
    classList: 'rect3'
  }), element('div', null, {
    classList: 'rect4'
  }), element('div', null, {
    classList: 'rect5'
  })], {
    classList: getClass()
  });

  if (id) {
    node.setAttribute('id', id);
  }

  return node;

  function getClass() {
    return `spinner ${color}`;
  }
}
function Remote({
  src,
  parse,
  component,
  color = 'white',
  onReady,
  onError
}) {
  const id = (0,_parse__WEBPACK_IMPORTED_MODULE_0__.uuid)();
  resolve();
  const loader = Loading({
    id,
    color
  });
  return loader;

  async function resolve() {
    let data = await (async () => {
      try {
        return (await (src instanceof Promise)) ? src : src();
      } catch (e) {
        if (onError) {
          onError(e, loader);
          throw e;
        }

        const retryBtn = element('button', [element('i', null, {
          className: 'glyphicon glyphicon-repeat'
        }), 'Retry'], {
          style: 'background-color: green'
        });
        retryBtn.addEventListener('click', () => {
          replaceSelf(Remote({
            src,
            parse,
            component,
            color
          }));
        });
        return element('div', [element('i', null, {
          className: 'glyphicon glyphicon-remove',
          style: 'color: red'
        }), e.message, retryBtn], {
          id: id
        });
      }
    })();

    if (parse) {
      data = parse(data);
    }

    replaceSelf(data);

    function replaceSelf(data) {
      //const loader = document.getElementById(id);
      const parent = loader.parentNode;

      if (component) {
        parent.insertBefore(component(data), loader);
      } else {
        append(data);
      } //await new Promise(resolve => setTimeout(10, resolve));
      //console.log(document.getElementById(id));


      loader.remove();

      if (onReady) {
        onReady();
      }

      function append(child) {
        if (typeof child === 'string' || typeof child === 'number') {
          if (child.toString().trim()[0] === '<') {
            const fragment = element('div', child);
            fragment.childNodes.forEach(n => parent.insertBefore(n.cloneNode(true), loader));
          } else {
            parent.insertBefore(document.createTextNode(child), loader);
          }
        } else if (Array.isArray(child)) {
          for (let node of child) {
            append(node);
          }
        } else {
          parent.insertBefore(child, loader);
        }
      }
    }
  }
}
function Yes() {
  const el = document.createElement('i');
  el.className = 'glyphicon glyphicon-ok';
  el.style.color = 'green';
  return el;
}
function No() {
  const el = document.createElement('i');
  el.className = 'glyphicon glyphicon-remove';
  el.style.color = 'red';
  return el;
}
function Question([title, answers]) {
  return element('div', [element('h2', title), element('ul', Object.entries(answers).map(([a, isCorrect]) => element('li', a, {
    classList: isCorrect ? 'correct-answer' : 'none'
  }, true)))], {
    classList: 'question-container'
  });
}
;
function Alert() {
  const el = document.createElement('i');
  el.className = 'glyphicon glyphicon-warning-sign';
  el.style.color = 'orange';
  return el;
}
function Container({
  children,
  className
}) {
  const section = element('section', children, {
    className: className ? 'event-container' : 'container'
  });
  const el = element('div', section, {
    className: className ? className : 'container administration-container ses-container'
  });
  return el;
}
function popupTable(data) {
  let html = `
        <style>
            table {
                border-collapse: collapse;
            }
            tr, td, th {
                border: 1px solid black;
                padding: 0.25em 0.5em;
            }
        </style>
        `;
  html += '<table><thead><tr>';

  for (let col of data[0]) {
    html += `<th>${col}</th>`;
  }

  html += '</tr></thead><tbody>';

  for (let row = 1; row < data.length; row++) {
    html += '<tr>';

    for (let col of data[row]) {
      html += `<td>${col}</td>`;
    }

    html += '</tr>';
  }

  html += '</tbody></table>';
  return html;
}
function getEditorDecoration(element) {
  function enable() {
    element.classList.add('enabled');
  }

  function disable() {
    element.classList.remove('enabled');
  }

  function working() {
    element.classList.remove('enabled');
    element.classList.add('working');
  }

  function updated() {
    element.classList.remove('working');
    element.classList.add('updated');
    setTimeout(() => element.classList.remove('updated'), 3000);
  }

  function failure() {
    element.classList.remove('working');
    element.classList.add('failed');
  }

  function _clear() {
    element.classList.remove('enabled');
    element.classList.remove('working');
    element.classList.remove('updated');
    element.classList.remove('failed');
  }

  return {
    enable,
    disable,
    working,
    updated,
    failure,
    _clear
  };
}
function applyBeginRequest(element) {
  element.childNodes.forEach(c => c.childNodes.forEach(n => n.disabled = true));
  element.classList.remove('enabled');
  element.classList.remove('failed');
  element.classList.add('working');
}
function applyRequestSuccess(element) {
  element.classList.remove('working');
  element.classList.add('updated');
  setTimeout(() => element.classList.remove('updated'), 3000);
}
function applyRequestError(refElement, errorContainer, fields) {
  refElement.childNodes.forEach(c => c.childNodes.forEach(n => n.disabled = false));
  refElement.classList.remove('working');
  refElement.classList.add('failed');
  console.warn(errorContainer);

  if (errorContainer.message !== undefined) {
    alert(errorContainer.message);
  } else {
    for (let error of Object.keys(errorContainer)) {
      if (error.length == 0) {
        alert(errorContainer[error].errors.join('\n'));
      } else {
        const field = fields[error];

        for (let message of errorContainer[error].errors) {
          field.appendChild(element('p', message));
        }
      }
    }
  }
}
function createCheckbox(name, data, text, onChange, defaultValue = false) {
  const id = 'ses-' + name;
  let value = readPrevInput();
  data[name] = value;
  let element = document.createElement('input');
  element.type = 'checkbox';
  element.id = id;
  element.name = name;
  let label = document.createElement('label');
  label.htmlFor = id;
  label.textContent = text;
  /*
  let element = <input type="checkbox" className="ses-check" id={id} name={name} />;
  let label = <label for={id}>{text}</label>;
  */

  element.checked = value;
  element.addEventListener('change', toggle);

  function readPrevInput() {
    let prevInput = document.getElementById(id);

    if (prevInput) {
      return prevInput.checked;
    } else {
      return defaultValue;
    }
  }

  function toggle(e) {
    value = e.target.checked;
    data[name] = value;
    redraw();
  }

  function redraw() {
    try {
      onChange();
    } catch (err) {
      console.log(err.message);
    }
  }

  const checkbox = {
    element,
    label
  };
  Object.defineProperty(checkbox, 'value', {
    get: () => value,
    set: newValue => {
      value = newValue;
      element.checked = value;
      data[name] = value;
      redraw();
    }
  });
  return checkbox;
}
function table(data, layout) {
  const thead = element('thead', element('tr', layout.map(h => element('th', h.label))));
  const tbody = element('tbody', data.map(r => element('tr', layout.map(h => element('td', r[h.name])))));
  const table = element('table', [thead, tbody]);
  table.thead = thead;
  table.tbody = tbody;
  return table;
}
function Autocomplete({
  values,
  current
}) {
  let autocomplete = element('div', [element('input', undefined, {
    className: 'ses-search-autocomplete-input'
  }), element('div', element('ul'), {
    className: 'ses-search-autocomplete-suggestions'
  })], {
    className: 'ses-search-autocomplete-container'
  });
  const suggestionsContainer = autocomplete.querySelector('.ses-search-autocomplete-suggestions');
  const input = autocomplete.querySelector('.ses-search-autocomplete-input');
  let selectedIndex = undefined;

  if (current != undefined) {
    input.value = current;
  }

  autocomplete.getValue = function () {
    return input.value;
  };

  function searchHandler(e) {
    const inputVal = e.currentTarget.value;
    let results = values;

    if (inputVal.length > 0) {
      results = values.filter(x => x.toLowerCase().indexOf(inputVal.toLowerCase()) > -1);
    }

    showSuggestions(results, inputVal);

    if (e.keyCode === 38 || e.keyCode === 40 || e.keyCode === 13) {
      scrollResults(e);
    }
  }

  function showSuggestions(results, inputVal) {
    let suggestions = suggestionsContainer.querySelector('ul');
    replaceContents(suggestions, '');
    suggestions = suggestionsContainer.querySelector('ul');
    ;

    if (results.length > 0) {
      for (let i = 0; i < results.length; i++) {
        let item = results[i];
        const match = item.match(new RegExp(inputVal, 'i'));
        item = item.replace(match[0], `<strong>${match[0]}</strong>`);
        let newLi = element('li', item, undefined, {
          forceType: "HTML"
        });
        suggestions.appendChild(newLi);
      }

      suggestions.classList.add('has-suggestions');
    } else {
      suggestions.classList.remove('has-suggestions');
    }
  }

  function useSuggestion(e) {
    input.value = e.target.textContent;
    input.focus();
    let suggestions = suggestionsContainer.querySelector('ul');
    replaceContents(suggestions, '');
    suggestions = suggestionsContainer.querySelector('ul');
    suggestions.classList.remove('has-suggestions');
  }

  function scrollResults(e) {
    let allSuggestions = [...suggestionsContainer.querySelectorAll('ul li')];
    let oldIndex = undefined;
    let indexChange = 1; // enter

    if (e.keyCode === 13) {
      input.value = allSuggestions[selectedIndex].textContent;
      selectedIndex = undefined;
      let suggestions = suggestionsContainer.querySelector('ul');
      suggestions.classList.remove('has-suggestions');
      return;
    }

    if (e.keyCode === 40) {
      // down arrow
      indexChange = 1;
    } else if (e.keyCode === 38) {
      // up arrow
      indexChange = -1;
    }

    if (selectedIndex == undefined) {
      selectedIndex = indexChange === 1 ? 0 : allSuggestions.length - 1;
    } else {
      oldIndex = selectedIndex;
      selectedIndex = (selectedIndex + indexChange + allSuggestions.length) % allSuggestions.length;
    }

    if (oldIndex !== undefined && oldIndex < allSuggestions.length) {
      allSuggestions[oldIndex].classList.remove('selected');
    }

    allSuggestions[selectedIndex].classList.add('selected');
  }

  input.addEventListener('keyup', searchHandler);
  suggestionsContainer.addEventListener('click', useSuggestion);
  return autocomplete;
}
/**
 * Creates a span element that represents a download progress bar
 * @param { {downloadFunction: (onProgress: import('./util.js').OnProgressFunction), returnFunction: function} } settings Contains the function that will download the resources, which will be called with onProgress
 * and the returnFunction which will be called with the results after the download finishes
 */

function DownloadProgressBar({
  downloadFunction,
  returnFunction
}) {
  const percent = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_1__["default"])("span", null, "0%");
  const bar = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_1__["default"])("span", {
    style: {
      padding: '0 0.5em',
      display: 'inline-block',
      width: '25%',
      background: 'linear-gradient(to right, #ffa000 0%, #eee 0)'
    }
  }, percent, " \u0421\u0432\u0430\u043B\u044F\u043D\u0435");
  downloadFunction(onProgress).then(data => {
    if (returnFunction) {
      returnFunction(data);
    }
  });
  return bar;

  function onProgress(completed, total, response, index) {
    const progress = Math.floor(completed / total * 100);
    percent.textContent = progress + '%';
    bar.style.background = `linear-gradient(to right, #ffa000 ${progress}%, #eee 0)`;
  }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  element
});

/***/ }),

/***/ "./src/util/util.js":
/*!**************************!*\
  !*** ./src/util/util.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "assertTemplate": () => (/* binding */ assertTemplate),
/* harmony export */   "createThrottledExecutor": () => (/* binding */ createThrottledExecutor),
/* harmony export */   "crossBrowserFileUpload": () => (/* binding */ crossBrowserFileUpload),
/* harmony export */   "distribute": () => (/* binding */ distribute),
/* harmony export */   "download": () => (/* binding */ download),
/* harmony export */   "escapeHTML": () => (/* binding */ escapeHTML),
/* harmony export */   "exportPaymentsToXlsx": () => (/* binding */ exportPaymentsToXlsx),
/* harmony export */   "exportToJson": () => (/* binding */ exportToJson),
/* harmony export */   "exportToXlsx": () => (/* binding */ exportToXlsx),
/* harmony export */   "getExcludedModuleInstances": () => (/* binding */ getExcludedModuleInstances),
/* harmony export */   "getExcludedModules": () => (/* binding */ getExcludedModules),
/* harmony export */   "getFundamentalLevelIds": () => (/* binding */ getFundamentalLevelIds),
/* harmony export */   "getLocale": () => (/* binding */ getLocale),
/* harmony export */   "getMime": () => (/* binding */ getMime),
/* harmony export */   "getProfessionInstanceIds": () => (/* binding */ getProfessionInstanceIds),
/* harmony export */   "getSubsite": () => (/* binding */ getSubsite),
/* harmony export */   "hasCPOAccess": () => (/* binding */ hasCPOAccess),
/* harmony export */   "iconAsset": () => (/* binding */ iconAsset),
/* harmony export */   "importFromXlsx": () => (/* binding */ importFromXlsx),
/* harmony export */   "importQuizFromXlsx": () => (/* binding */ importQuizFromXlsx),
/* harmony export */   "isAdmin": () => (/* binding */ isAdmin),
/* harmony export */   "openFile": () => (/* binding */ openFile),
/* harmony export */   "roundUpWithPrecision": () => (/* binding */ roundUpWithPrecision),
/* harmony export */   "serializeCalls": () => (/* binding */ serializeCalls),
/* harmony export */   "toLegacyXlsFile": () => (/* binding */ toLegacyXlsFile),
/* harmony export */   "toXlsxFile": () => (/* binding */ toXlsxFile),
/* harmony export */   "withProgress": () => (/* binding */ withProgress),
/* harmony export */   "zipFiles": () => (/* binding */ zipFiles)
/* harmony export */ });
/* harmony import */ var _parse__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parse */ "./src/util/parse.js");
/* globals xlsx, JSZip */

function importQuizFromXlsx(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = function (e) {
      const fileData = e.target.result;
      const wb = xlsx.read(fileData, {
        type: 'binary'
      });
      const firstSheet = wb.Sheets[wb.SheetNames[0]];
      const apiData = xlsx.utils.sheet_to_json(firstSheet, {
        header: 1
      }).slice(1) // remove first row
      .reduce((data, currentRow) => {
        if (currentRow.length !== 0) {
          const correctAnswerIndex = currentRow.pop();
          const question = currentRow[0];
          const allAnswers = currentRow.slice(1);
          const correctAnswer = currentRow[correctAnswerIndex];
          data[question] = allAnswers.reduce((answers, a) => {
            if (a != undefined && a.toString().trim() !== '') {
              answers[a] = a === correctAnswer;
            }

            return answers;
          }, {});
        }

        return data;
      }, {});
      resolve(apiData);
    };

    reader.readAsBinaryString(blob);
  });
}
function importFromXlsx(blob, useCellDates = false) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = function (e) {
      const file = e.target.result;

      try {
        const wb = xlsx.read(file, {
          type: 'binary',
          cellDates: useCellDates
        });
        const firstSheet = wb.Sheets[wb.SheetNames[0]];
        const data = xlsx.utils.sheet_to_json(firstSheet, {
          header: 1
        });
        resolve(data);
      } catch (err) {
        console.log('Error parsing XLSX file, make sure the library is loaded');
        reject(err);
      }
    };

    reader.onerror = function (e) {
      console.log('Error reading file');
      reject(e);
    };

    reader.readAsBinaryString(blob);
  });
}
function toXlsxFile(table, name = 'Output', ws_name) {
  if (ws_name === undefined) {
    ws_name = name.slice(0, 31);
  }

  const wb = xlsx.utils.book_new(),
        ws = xlsx.utils.aoa_to_sheet(table); // wb.Workbook = { Views: ['Window2'] };

  xlsx.utils.book_append_sheet(wb, ws, ws_name);
  const data = xlsx.write(wb, {
    type: 'array',
    bookType: 'xlsx'
  });
  const file = new File([data], name + '.xlsx', {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  });
  return file;
}
function toLegacyXlsFile(table, name = 'Output', ws_name) {
  if (ws_name === undefined) {
    ws_name = name.slice(0, 31);
  }

  const wb = xlsx.utils.book_new(),
        ws = xlsx.utils.aoa_to_sheet(table);
  wb.Workbook = {
    Views: ['Window2']
  };
  xlsx.utils.book_append_sheet(wb, ws, ws_name);
  const data = xlsx.write(wb, {
    type: 'array',
    bookType: 'biff8'
  });
  const file = new File([data], name + '.xls', {
    type: 'application/vnd.ms-excel'
  });
  return file;
}
function exportToXlsx(table, name = 'Output', ws_name) {
  const filename = `${name}.xlsx`;

  if (ws_name === undefined) {
    ws_name = name.slice(0, 31);
  } // Sheet name cannot contain: \ / ? * [ ]


  const sheetRegex = /[\[\]\\\/\*]/gi;

  if (sheetRegex.test(ws_name)) {
    ws_name = ws_name.replace(sheetRegex, '-');
  }

  const wb = xlsx.utils.book_new(),
        ws = xlsx.utils.aoa_to_sheet(table);
  xlsx.utils.book_append_sheet(wb, ws, ws_name);
  xlsx.writeFile(wb, filename);
}
function exportPaymentsToXlsx(data, year, month) {
  const filename = `Payments-${_parse__WEBPACK_IMPORTED_MODULE_0__["default"].monthName[month]}-${year}.xlsx`;
  const ws_name = `Payments ${_parse__WEBPACK_IMPORTED_MODULE_0__["default"].monthName[month]} ${year}`;
  const wb = xlsx.utils.book_new(),
        ws = xlsx.utils.aoa_to_sheet(data);
  xlsx.utils.book_append_sheet(wb, ws, ws_name);
  xlsx.writeFile(wb, filename);
}
function exportToJson(data, name = 'Output') {
  const blob = new Blob([data], {
    type: 'application/json'
  });

  if (window.navigator.msSaveOrOpenBlob) {
    window.navigator.msSaveBlob(blob, name + '.json');
  } else {
    var elem = window.document.createElement('a');
    elem.href = window.URL.createObjectURL(blob);
    elem.download = name + '.json';
    document.body.appendChild(elem);
    elem.click();
    document.body.removeChild(elem);
  }
}
/**
 * @param {{folder: string, files: File[]}[]} files 
 */

async function zipFiles(files) {
  const zip = new JSZip();

  for (let entry of files) {
    const current = zip.folder(entry.folder);
    current.file(entry.files.photo.name, await blobToBase64(entry.files.photo.file), {
      base64: true
    });
    current.file(entry.files.medical.name, await blobToBase64(entry.files.medical.file), {
      base64: true
    });
    current.file(entry.files.diploma.name, await blobToBase64(entry.files.diploma.file), {
      base64: true
    });
  }

  return zip.generateAsync({
    type: 'blob'
  });

  function blobToBase64(blob) {
    return new Promise(resolve => {
      const reader = new FileReader();

      reader.onload = function () {
        const dataUrl = reader.result;
        const base64 = dataUrl.split(',')[1];
        resolve(base64);
      };

      reader.readAsDataURL(blob);
    });
  }

  ;
}
const mimes = {
  'bmp': 'image/bmp',
  'gif': 'image/gif',
  'jpeg': 'image/jpeg',
  'jpg': 'image/jpeg',
  'png': 'image/png',
  'pdf': 'application/pdf',
  'tif': 'image/tiff',
  'tiff': 'image/tiff',
  'webp': 'image/webp',
  'zip': 'application/zip',
  '7z': 'application/x-7z-compressed',
  'tar': 'application/x-tar',
  'rar': 'application/vnd.rar'
};
function getMime(extension) {
  extension = extension.toLocaleLowerCase();
  return mimes[extension] || 'application/octet-stream';
}
async function openFile(file, name = 'output.txt') {
  try {
    var elem = window.document.createElement('a');
    elem.target = '_blank';
    elem.download = name;
    const href = window.URL.createObjectURL(file);
    elem.href = href;
    elem.click();
    setTimeout(() => URL.revokeObjectURL(href), 60000);
  } catch (err) {
    console.error(err);
  }
}
function download(blob, name = 'output.txt') {
  if (window.navigator.msSaveOrOpenBlob) {
    window.navigator.msSaveBlob(blob, name);
  } else {
    var elem = window.document.createElement('a');
    elem.target = '_blank';
    const href = window.URL.createObjectURL(blob);
    elem.href = href;
    elem.download = name;
    elem.click();
    setTimeout(() => URL.revokeObjectURL(href), 60000);
  }
}
async function crossBrowserFileUpload(apiCall, file) {
  if (!!window.chrome) {
    const fileUrl = URL.createObjectURL(file);
    const result = await apiCall({
      fileUrl,
      name: file.name
    });
    URL.revokeObjectURL(fileUrl);
    return result;
  } else {
    return await apiCall({
      file
    });
  }
}
function getSubsite() {
  switch (window.location.host.substr(0, 7)) {
    case 'digital':
      return 'digital';

    case 'creativ':
      return 'creative';

    case 'platfor':
      return 'platform';

    case 'ai.soft':
      return 'ai';

    case 'finance':
      return 'financeacademy';

    case 'dev.dig':
      return 'devdigital';

    case 'dev.sof':
      return 'devsoftuni';

    default:
      return 'programming';
  }
}
function hasCPOAccess() {
  return ['digital', 'creative', 'programming', 'devdigital', 'devsoftuni'].includes(getSubsite());
}
function isAdmin() {
  const e = document.querySelectorAll('a[href="/administration/navigation" i]');

  if (e.length > 0) {
    return true;
  } else {
    return false;
  }
}
function serializeCalls(fnArray, delay) {
  const callArray = [];

  if (delay !== undefined) {
    for (let i = 0; i < fnArray.length; i++) {
      const handler = (res, rej) => {
        setTimeout(async () => {
          try {
            const result = await fnArray[i]();
            res(result);
          } catch (err) {
            rej(err);
          }
        }, i * delay);
      };

      const pr = new Promise(handler);
      callArray.push(pr);
    }
  } else {
    for (let i = 0; i < fnArray.length; i++) {
      const handler = (res, rej) => {
        if (i > 0) {
          callArray[i - 1].finally(async () => {
            try {
              const result = await fnArray[i]();
              res(result);
            } catch (err) {
              rej(err);
            }
          });
        } else {
          fnArray[i]().then(res).catch(rej);
        }
      };

      const pr = new Promise(handler);
      callArray.push(pr);
    }
  }

  return callArray;
}
async function withProgress(callArray, onChange, delay = 10) {
  return new Promise((resolve, reject) => {
    // Failsave for empty callArray
    if (callArray.length == 0) {
      onChange(undefined, 0, 1, 1);
      resolve([]);
    }

    let resolved = 0;
    const response = [];
    callNext(0);

    function callNext(i) {
      if (i >= callArray.length) {
        return;
      } else {
        callArray[i].then(res => onResolve(res, i)).catch(onError);
        setTimeout(() => callNext(i + 1), delay);
      }
    }

    function onResolve(res, index) {
      resolved++;

      if (onChange) {
        onChange(res, index, resolved, callArray.length);
      }

      response[index] = res;

      if (resolved === callArray.length) {
        resolve(response);
      }
    }

    function onError(e) {
      reject(e);
    }
  });
}
/**
 * @typedef {(completed: number, total: number, response, index: number) => void} OnProgressFunction
 */

/**
 * @typedef {() => Promise} AsyncFunction
 */

/**
 * Initiate remote calls at intervals
 * @param {Array<AsyncFunction>} fnArray 
 * @param {OnProgressFunction} onProgress 
 * @param {number} [delay=10]
 * @returns 
 */

async function distribute(fnArray, onProgress, delay = 10) {
  return new Promise((resolve, reject) => {
    const total = fnArray.length;
    let completed = 0;
    let resolved = 0; // Failsave for empty fnArray

    if (total == 0) {
      if (typeof onProgress == 'function') {
        onProgress(undefined, 0, 1, 1);
      }

      resolve([]);
    }

    const calls = fnArray.map((fn, i) => {
      const call = {
        fn,
        sent: false,
        cancelled: false,
        response: undefined,
        timer: null
      };
      call.onCall = onCall.bind(call, i);
      call.cancel = onCancel.bind(call);
      call.timer = setTimeout(call.onCall, i * delay);
      return call;
    });
    calls.forEach((c, i) => c.next = calls[i + 1]);

    async function onCall(i) {
      if (this.sent == false) {
        clearTimeout(this.timer);
      }

      if (this.cancelled == false) {
        this.sent = true;

        try {
          const promise = this.fn();
          this.response = await promise;

          if (promise._cacheHit && this.next) {
            this.next.onCall();
          }

          resolved++;

          if (this.cancelled == false && resolved === total) {
            resolve(calls.map(c => c.response));
          }
        } catch (err) {
          onError(err);
        }
      }

      completed++;

      if (typeof onProgress == 'function') {
        onProgress(completed, total, this.response, i);
      }
    }

    function onCancel() {
      if (this.cancelled == false) {
        this.cancelled = true;

        if (this.sent == false) {
          clearTimeout(this.timer);
          this.onCall();
        }
      }
    }

    function onError(e) {
      calls.forEach(c => c.cancel());

      if (e instanceof Error) {
        e._responses = calls.map(c => c.response);
      }

      reject(e);
    }
  });
}
function assertTemplate(template, target, bottom = false) {
  if (template.Data !== undefined && template.Total !== undefined) {
    template = template.Data;
    target = target.Data;
  }

  if (Array.isArray(template)) {
    if (Array.isArray(target)) {
      if (bottom) {
        return;
      } else {
        assertTemplate(template[0], target[0], true);
      }
    } else {
      throw new TypeError('Target type mismatch');
    }
  } else if (typeof template === 'object') {
    if (typeof target === 'object') {
      const model = Object.keys(template);

      for (let prop of model) {
        if (target.hasOwnProperty(prop) === false) {
          throw new TypeError('Missing property on target: ' + prop);
        }
      }
    } else {
      throw new TypeError('Target type mismatch');
    }
  } else if (typeof template !== typeof target) {
    throw new TypeError('Target type mismatch');
  } else {
    return true;
  }
}
function getLocale() {
  return 'bg';
}
function createThrottledExecutor(callback, delay) {
  let timer = null;
  return function (...params) {
    clear();
    timer = setTimeout(() => {
      clear();
      callback(...params);
    }, delay);
  };

  function clear() {
    if (timer !== null) {
      clearTimeout(timer);
    }
  }
}
function iconAsset(name) {
  return browser.runtime.getURL(`icons/${name}.png`);
}
function escapeHTML(str) {
  return str.replace(/[&<>]/g, tag => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;'
  })[tag]);
}
;
function getFundamentalLevelIds(appname) {
  return {
    'programming': [19, 44, 57, 70, 106],
    'digital': [6, 7, 8, 23, 24, 25, 27, 33, 35, 40],
    'creative': [23, 24, 42, 52]
  }[appname];
}
function getProfessionInstanceIds(appname) {
  return {
    // Commented are for QA
    'programming': [1007, 1009, 1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1020, 1022, 1023, 1024, 1025, 1026, // 1028,
    1029, 1030, 1031, 1032, 1033, 1034, 1035, 1036, 1037, 1038, 1039, 1040, 1041, 1042, 1043, 1044, 1045, 1046, 1047, 1048, 1049, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1062, 1063, 1064, 1065, 1066, // 1067,
    // 1068,
    // 1069,
    1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078],
    'digital': [1, 3, 4, 5, 6, 7, 8, 9],
    'creative': [1, 3, 4, 5],
    'devdigital': [1, 3, 4, 5, 6, 7, 8, 9],
    'ai': []
  }[appname];
}
function getExcludedModules(appname) {
  return {
    'programming': [2]
  }[appname];
}
function getExcludedModuleInstances(appname) {
  return {
    'digital': [5, 50],
    'creative': [1, 14, 28, 46],
    'devdigital': [5, 50]
  }[appname];
}
/**
 * @description Rounds up a number up to specified number of decimal places using a specified number of decimal places as precision.
 * This allows correct rounding of problematic floating point numbers like "55.00000000000001" or "0.460000000000001"
 * @param {Number} number The number to round up
 * @param {Number} decimalPlacesToRoundTo The number of decimal places to round to
 * @param {Number} decimalPlacesPrecision The number of decimal places that should be considered for the rounding. Should be larger than decimalPlacesToRoundTo
 * @returns The rounded number
 */

function roundUpWithPrecision(number, decimalPlacesToRoundTo, decimalPlacesPrecision) {
  if (decimalPlacesPrecision <= decimalPlacesToRoundTo) {
    throw new RangeError('decimalPlacesPrecision should be larger than decimalPlacesToRoundTo');
  }

  let precisionValue = 10 ** decimalPlacesPrecision;
  let roundingValue = 10 ** decimalPlacesToRoundTo;
  let roundingValueBigInt = BigInt(roundingValue);
  let precisionDifferenceValue = BigInt(precisionValue / roundingValue);
  let bigInt = BigInt(Math.trunc(number * precisionValue));
  let roundedPlacesNumberPart = bigInt / precisionDifferenceValue;
  let precisionDifferenceLeftover = bigInt % precisionDifferenceValue;
  roundedPlacesNumberPart += precisionDifferenceLeftover > 0 ? 1n : 0n;
  let numberPart = roundedPlacesNumberPart / roundingValueBigInt;
  let decimalPart = roundedPlacesNumberPart % roundingValueBigInt;
  let roundedNum = Number(`${numberPart}.${decimalPart.toString().padStart(decimalPlacesToRoundTo, '0')}`);
  return roundedNum;
}

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!****************************!*\
  !*** ./src/admin/admin.js ***!
  \****************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _util_template__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/template */ "./src/util/template.js");
/* harmony import */ var _util_util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/util */ "./src/util/util.js");


const tabIndexes = {
  trainings: {
    programming: 3,
    digital: 4,
    creative: 4,
    ai: 4,
    financeacademy: 4,
    devdigital: 4
  },
  stats: {
    programming: 14,
    digital: 10,
    creative: 10,
    ai: 10,
    financeacademy: 11,
    devdigital: 10
  },
  quiz: {
    programming: 13
  },
  stream: {
    programming: 1,
    digital: 3,
    creative: 3,
    ai: 3,
    financeacademy: 3,
    devdigital: 3
  }
};
insertMenus();

function insertMenus() {
  const subsite = (0,_util_util__WEBPACK_IMPORTED_MODULE_1__.getSubsite)();
  const menus = [];

  switch (subsite) {
    case 'programming':
      menus.push({
        index: tabIndexes.trainings[subsite],
        name: 'Course Manager',
        url: '/ses/course'
      });
      menus.push({
        index: tabIndexes.stats[subsite],
        name: 'Survey Aggregate',
        url: '/ses/surveys'
      });
      menus.push({
        index: tabIndexes.stats[subsite],
        name: 'Season Stats',
        url: '/ses/stats'
      });
      menus.push({
        index: tabIndexes.quiz[subsite],
        name: 'Quiz Management',
        url: '/ses/quiz'
      });
      menus.push({
        index: tabIndexes.stream[subsite],
        name: 'Stream Dashboard',
        url: '/ses/stream'
      });
      menus.push({
        index: tabIndexes.trainings[subsite],
        name: 'Trainings Overview',
        url: '/ses/overview'
      });
      break;

    case 'digital':
    case 'creative':
    case 'devdigital':
    case 'ai':
      menus.push({
        index: tabIndexes.trainings[subsite],
        name: 'Course Manager',
        url: '/ses/course'
      });
      menus.push({
        index: tabIndexes.stats[subsite],
        name: 'Survey Aggregate',
        url: '/ses/surveys'
      });
      menus.push({
        index: tabIndexes.stats[subsite],
        name: 'Season Stats',
        url: '/ses/stats'
      });
      menus.push({
        index: tabIndexes.stream[subsite],
        name: 'Stream Dashboard',
        url: '/ses/stream'
      });
      menus.push({
        index: tabIndexes.trainings[subsite],
        name: 'Trainings Overview',
        url: '/ses/overview'
      });
      break;

    case 'financeacademy':
      menus.push({
        index: tabIndexes.trainings[subsite],
        name: 'Course Manager',
        url: '/ses/course'
      });
      menus.push({
        index: tabIndexes.stats[subsite],
        name: 'Survey Aggregate',
        url: '/ses/surveys'
      });
      menus.push({
        index: tabIndexes.stream[subsite],
        name: 'Stream Dashboard',
        url: '/ses/stream'
      });
      menus.push({
        index: tabIndexes.trainings[subsite],
        name: 'Trainings Overview',
        url: '/ses/overview'
      });
      break;
  }

  menus.forEach(m => insertMenuItem(m.index, m.name, m.url, 'icons/icon48.png'));
}

function insertMenuItem(tabIndex, label, href, iconPath) {
  const iconURL = browser.runtime.getURL(iconPath);
  const container = document.querySelector('#AdministrationNavigation-' + tabIndex).children[0];
  const row = getOrCreateRow(container);
  const col = _util_template__WEBPACK_IMPORTED_MODULE_0__["default"].element('div', null, {
    classList: getStyle()
  });
  const anchor = _util_template__WEBPACK_IMPORTED_MODULE_0__["default"].element('a', [_util_template__WEBPACK_IMPORTED_MODULE_0__["default"].element('img', null, {
    title: label,
    src: iconURL,
    alt: label,
    classList: 'bottom-buffer'
  }), _util_template__WEBPACK_IMPORTED_MODULE_0__["default"].element('div', label, {
    classList: 'bottom-buffer'
  })], {
    href
  });
  col.append(anchor);
  row.append(col);

  function getOrCreateRow(container) {
    const lastRow = [...container.querySelectorAll('.row.bottom-buffer')].pop();
    const cols = lastRow.querySelectorAll('.col-md-3');

    if (cols.length < 4) {
      return lastRow;
    } else {
      const row = _util_template__WEBPACK_IMPORTED_MODULE_0__["default"].element('div', null, {
        classList: 'row no-margin-offset text-center bottom-buffer'
      });
      container.appendChild(row);
      return row;
    }
  }
}

function getStyle() {
  switch ((0,_util_util__WEBPACK_IMPORTED_MODULE_1__.getSubsite)()) {
    case 'programming':
      return 'col-md-3';

    case 'digital':
    case 'creative':
    case 'platform':
    case 'devdigital':
    case 'ai':
    case 'financeacademy':
      return 'col-md-3 no-padding';
  }
}
})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9kZXYvL2NvbnRlbnQtc2NyaXB0cy9hZG1pbi5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUtBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBWEE7QUFhQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUdBOzs7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwSEE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUdBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBTUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFFQTtBQUNBOztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBM0dBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUtBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUlBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSkE7QUFNQTs7QUFFQTtBQUNBO0FBQ0E7QUFjQTtBQUNBOztBQUVBO0FBQ0E7O0FBU0E7QUFDQTtBQVNBOztBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWkE7QUFnQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFaQTs7QUFlQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFVQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0FBR0E7QUFDQTtBQUNBO0FBQUE7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQUE7O0FBQ0E7QUFBQTs7QUFDQTtBQUFBO0FBSEE7QUFLQTs7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFqQkE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM3VUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTs7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7O0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUVBOztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQUE7QUFFQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSkE7QUFNQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBR0E7QUFBQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7OztBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFOQTtBQVFBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBUEE7QUFVQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQURBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0Z0JBO0FBRUE7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7QUFDQTtBQUFBO0FBREE7QUFJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFJQTtBQUNBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUFBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUFBO0FBQUE7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUFBO0FBQUE7QUFFQTtBQUNBO0FBRUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7OztBQUdBOztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFBQTtBQUFBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQ0E7O0FBQ0E7QUFBQTtBQUFBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFBQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWJBO0FBZ0JBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFoQkE7QUFrQkE7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUdBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMQTtBQU9BO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBSEE7QUFLQTtBQUFBO0FBR0E7QUFDQTtBQUNBO0FBT0E7QUFZQTtBQXBCQTtBQTJCQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBbUJBO0FBdUNBO0FBQ0E7QUFDQTtBQVVBO0FBVUE7QUFNQTtBQVVBO0FBbEdBO0FBb0dBO0FBRUE7QUFDQTtBQUNBO0FBREE7QUFLQTtBQUVBO0FBQ0E7QUFDQTtBQUlBO0FBTUE7QUFYQTtBQWdCQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7Ozs7OztBQ3RyQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7O0FDdkJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7O0FDUEE7Ozs7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUNOQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU5BO0FBUUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFOQTtBQVFBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTkE7QUFwQkE7QUE4QkE7O0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7O0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUF4QkE7O0FBMEJBO0FBQ0E7O0FBR0E7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBREE7QUFHQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBSkE7QUFPQTtBQURBO0FBSUE7QUFEQTtBQUlBO0FBQ0E7O0FBR0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFUQTtBQVdBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy91dGlsL2pzeC1yZW5kZXItbW9kL2RvbS5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL3V0aWwvanN4LXJlbmRlci1tb2QvdXRpbHMuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy91dGlsL3BhcnNlLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvdXRpbC90ZW1wbGF0ZS5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL3V0aWwvdXRpbC5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvd2VicGFjay9ydW50aW1lL2RlZmluZSBwcm9wZXJ0eSBnZXR0ZXJzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvd2VicGFjay9ydW50aW1lL2hhc093blByb3BlcnR5IHNob3J0aGFuZCIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlL3dlYnBhY2svcnVudGltZS9tYWtlIG5hbWVzcGFjZSBvYmplY3QiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9hZG1pbi9hZG1pbi5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBpc1NWRywgY3JlYXRlRnJhZ21lbnRGcm9tLCBFVkVOVF9MSVNURU5FUlMgfSBmcm9tICcuL3V0aWxzJztcclxuXHJcbi8qKlxyXG4gKiBUaGUgdGFnIG5hbWUgYW5kIGNyZWF0ZSBhbiBodG1sIHRvZ2V0aGVyIHdpdGggdGhlIGF0dHJpYnV0ZXNcclxuICpcclxuICogQHBhcmFtICB7U3RyaW5nfSB0YWdOYW1lIG5hbWUgYXMgc3RyaW5nLCBlLmcuICdkaXYnLCAnc3BhbicsICdzdmcnXHJcbiAqIEBwYXJhbSAge09iamVjdH0gYXR0cnMgaHRtbCBhdHRyaWJ1dGVzIGUuZy4gZGF0YS0sIHdpZHRoLCBzcmNcclxuICogQHBhcmFtICB7QXJyYXl9IGNoaWxkcmVuIGh0bWwgbm9kZXMgZnJvbSBpbnNpZGUgZGUgZWxlbWVudHNcclxuICogQHJldHVybiB7SFRNTEVsZW1lbnR8U1ZHRWxlbWVudH0gaHRtbCBub2RlIHdpdGggYXR0cnNcclxuICovXHJcbmZ1bmN0aW9uIGNyZWF0ZUVsZW1lbnRzKHRhZ05hbWUsIGF0dHJzLCBjaGlsZHJlbikge1xyXG4gICAgY29uc3QgZWxlbWVudCA9IGlzU1ZHKHRhZ05hbWUpXHJcbiAgICAgICAgPyBkb2N1bWVudC5jcmVhdGVFbGVtZW50TlMoJ2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJywgdGFnTmFtZSlcclxuICAgICAgICA6IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQodGFnTmFtZSk7XHJcblxyXG4gICAgLy8gb25lIG9yIG11bHRpcGxlIHdpbGwgYmUgZXZhbHVhdGVkIHRvIGFwcGVuZCBhcyBzdHJpbmcgb3IgSFRNTEVsZW1lbnRcclxuICAgIGNvbnN0IGZyYWdtZW50ID0gY3JlYXRlRnJhZ21lbnRGcm9tKGNoaWxkcmVuKTtcclxuICAgIGVsZW1lbnQuYXBwZW5kQ2hpbGQoZnJhZ21lbnQpO1xyXG5cclxuICAgIE9iamVjdC5rZXlzKGF0dHJzIHx8IHt9KS5mb3JFYWNoKHByb3AgPT4ge1xyXG4gICAgICAgIGlmIChwcm9wID09PSAnc3R5bGUnKSB7XHJcbiAgICAgICAgICAgIC8vIGUuZy4gb3JpZ2luOiA8ZWxlbWVudCBzdHlsZT17eyBwcm9wOiB2YWx1ZSB9fSAvPlxyXG4gICAgICAgICAgICBPYmplY3QuYXNzaWduKGVsZW1lbnQuc3R5bGUsIGF0dHJzW3Byb3BdKTtcclxuICAgICAgICB9IGVsc2UgaWYgKHByb3AgPT09ICdyZWYnICYmIHR5cGVvZiBhdHRycy5yZWYgPT09ICdmdW5jdGlvbicpIHtcclxuICAgICAgICAgICAgYXR0cnMucmVmKGVsZW1lbnQsIGF0dHJzKTtcclxuICAgICAgICB9IGVsc2UgaWYgKHByb3AgPT09ICdjbGFzc05hbWUnKSB7XHJcbiAgICAgICAgICAgIGVsZW1lbnQuc2V0QXR0cmlidXRlKCdjbGFzcycsIGF0dHJzW3Byb3BdKTtcclxuICAgICAgICB9IGVsc2UgaWYgKHByb3AgPT09ICd4bGlua0hyZWYnKSB7XHJcbiAgICAgICAgICAgIGVsZW1lbnQuc2V0QXR0cmlidXRlTlMoJ2h0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsnLCAneGxpbms6aHJlZicsIGF0dHJzW3Byb3BdKTtcclxuICAgICAgICB9IGVsc2UgaWYgKHByb3AgPT09ICdkYW5nZXJvdXNseVNldElubmVySFRNTCcpIHtcclxuICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVuZGVyc2NvcmUtZGFuZ2xlXHJcbiAgICAgICAgICAgIGVsZW1lbnQuaW5uZXJIVE1MID0gYXR0cnNbcHJvcF0uX19odG1sO1xyXG4gICAgICAgIH0gZWxzZSBpZiAocHJvcCBpbiBFVkVOVF9MSVNURU5FUlMpIHtcclxuICAgICAgICAgICAgZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKEVWRU5UX0xJU1RFTkVSU1twcm9wXSwgYXR0cnNbcHJvcF0pO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIC8vIGFueSBvdGhlciBwcm9wIHdpbGwgYmUgc2V0IGFzIGF0dHJpYnV0ZVxyXG4gICAgICAgICAgICBlbGVtZW50LnNldEF0dHJpYnV0ZShwcm9wLCBhdHRyc1twcm9wXSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIGVsZW1lbnQ7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBUaGUgSlNYVGFnIHdpbGwgYmUgdW53cmFwcGVkIHJldHVybmluZyB0aGUgaHRtbFxyXG4gKlxyXG4gKiBAcGFyYW0gIHtGdW5jdGlvbn0gSlNYVGFnIG5hbWUgYXMgc3RyaW5nLCBlLmcuICdkaXYnLCAnc3BhbicsICdzdmcnXHJcbiAqIEBwYXJhbSAge09iamVjdH0gZWxlbWVudFByb3BzIGN1c3RvbSBqc3ggYXR0cmlidXRlcyBlLmcuIGZuLCBzdHJpbmdzXHJcbiAqIEBwYXJhbSAge0FycmF5fSBjaGlsZHJlbiBodG1sIG5vZGVzIGZyb20gaW5zaWRlIGRlIGVsZW1lbnRzXHJcbiAqXHJcbiAqIEByZXR1cm4ge0Z1bmN0aW9ufSByZXR1cm5zIGRlICdkb20nIChmbikgZXhlY3V0ZWQsIGxlYXZpbmcgdGhlIEhUTUxFbGVtZW50XHJcbiAqXHJcbiAqIEpTWFRhZzogIGZ1bmN0aW9uIENvbXAocHJvcHMpIHtcclxuICogICByZXR1cm4gZG9tKFwic3BhblwiLCBudWxsLCBwcm9wcy5udW0pO1xyXG4gKiB9XHJcbiAqL1xyXG5mdW5jdGlvbiBjb21wb3NlVG9GdW5jdGlvbihKU1hUYWcsIGVsZW1lbnRQcm9wcywgY2hpbGRyZW4pIHtcclxuICAgIGNvbnN0IHByb3BzID0gT2JqZWN0LmFzc2lnbih7fSwgSlNYVGFnLmRlZmF1bHRQcm9wcyB8fCB7fSwgZWxlbWVudFByb3BzLCB7IGNoaWxkcmVuIH0pO1xyXG4gICAgY29uc3QgYnJpZGdlID0gKEpTWFRhZy5wcm90b3R5cGUgJiYgSlNYVGFnLnByb3RvdHlwZS5yZW5kZXIpID8gbmV3IEpTWFRhZyhwcm9wcykucmVuZGVyIDogSlNYVGFnO1xyXG4gICAgY29uc3QgcmVzdWx0ID0gYnJpZGdlKHByb3BzKTtcclxuXHJcbiAgICBzd2l0Y2ggKHJlc3VsdCkge1xyXG4gICAgICAgIGNhc2UgJ0ZSQUdNRU5UJzpcclxuICAgICAgICAgICAgcmV0dXJuIGNyZWF0ZUZyYWdtZW50RnJvbShjaGlsZHJlbik7XHJcblxyXG4gICAgICAgIC8vIFBvcnRhbHMgYXJlIHVzZWZ1bCB0byByZW5kZXIgbW9kYWxzXHJcbiAgICAgICAgLy8gYWxsb3cgcmVuZGVyIG9uIGEgZGlmZmVyZW50IGVsZW1lbnQgdGhhbiB0aGUgcGFyZW50IG9mIHRoZSBjaGFpblxyXG4gICAgICAgIC8vIGFuZCBsZWF2ZSBhIGNvbW1lbnQgaW5zdGVhZFxyXG4gICAgICAgIGNhc2UgJ1BPUlRBTCc6XHJcbiAgICAgICAgICAgIGJyaWRnZS50YXJnZXQuYXBwZW5kQ2hpbGQoY3JlYXRlRnJhZ21lbnRGcm9tKGNoaWxkcmVuKSk7XHJcbiAgICAgICAgICAgIHJldHVybiBkb2N1bWVudC5jcmVhdGVDb21tZW50KCdQb3J0YWwgVXNlZCcpO1xyXG4gICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGRvbShlbGVtZW50LCBhdHRycywgLi4uY2hpbGRyZW4pIHtcclxuICAgIC8vIEN1c3RvbSBDb21wb25lbnRzIHdpbGwgYmUgZnVuY3Rpb25zXHJcbiAgICBpZiAodHlwZW9mIGVsZW1lbnQgPT09ICdmdW5jdGlvbicpIHtcclxuICAgICAgICBpZiAoZWxlbWVudC5oYXNPd25Qcm9wZXJ0eSgncHJvcFR5cGVzJykpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgcHJvcCBvZiBlbGVtZW50LnByb3BUeXBlcykge1xyXG4gICAgICAgICAgICAgICAgaWYgKGF0dHJzLmhhc093blByb3BlcnR5KHByb3ApID09PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEpTWCBFcnJvcjogTWlzc2luZyBwcm9wZXJ0eSAnJHtwcm9wfScgZnJvbSAnJHtlbGVtZW50Lm5hbWV9JyBpbnZvY2F0aW9uYCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gZS5nLiBjb25zdCBDdXN0b21UYWcgPSAoeyB3IH0pID0+IDxzcGFuIHdpZHRoPXt3fSAvPlxyXG4gICAgICAgIC8vIHdpbGwgYmUgdXNlZFxyXG4gICAgICAgIC8vIGUuZy4gPEN1c3RvbVRhZyB3PXsxfSAvPlxyXG4gICAgICAgIC8vIGJlY29tZXM6IEN1c3RvbVRhZyh7IHc6IDF9KVxyXG4gICAgICAgIHJldHVybiBjb21wb3NlVG9GdW5jdGlvbihlbGVtZW50LCBhdHRycywgY2hpbGRyZW4pO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIHJlZ3VsYXIgaHRtbCBjb21wb25lbnRzIHdpbGwgYmUgc3RyaW5ncyB0byBjcmVhdGUgdGhlIGVsZW1lbnRzXHJcbiAgICAvLyB0aGlzIGlzIGhhbmRsZWQgYnkgdGhlIGJhYmVsIHBsdWdpbnNcclxuICAgIGlmICh0eXBlb2YgZWxlbWVudCA9PT0gJ3N0cmluZycpIHtcclxuICAgICAgICByZXR1cm4gY3JlYXRlRWxlbWVudHMoZWxlbWVudCwgYXR0cnMsIGNoaWxkcmVuKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gY29uc29sZS5lcnJvcihganN4LXJlbmRlciBkb2VzIG5vdCBoYW5kbGUgJHt0eXBlb2YgdGFnfWApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBkb207XHJcbmV4cG9ydCBjb25zdCBGcmFnbWVudCA9ICgpID0+ICdGUkFHTUVOVCc7XHJcbmV4cG9ydCBjb25zdCBwb3J0YWxDcmVhdG9yID0gbm9kZSA9PiB7XHJcbiAgICBmdW5jdGlvbiBQb3J0YWwoKSB7XHJcbiAgICAgICAgcmV0dXJuICdQT1JUQUwnO1xyXG4gICAgfVxyXG5cclxuICAgIFBvcnRhbC50YXJnZXQgPSBkb2N1bWVudC5ib2R5O1xyXG5cclxuICAgIGlmIChub2RlICYmIG5vZGUubm9kZVR5cGUgPT09IE5vZGUuRUxFTUVOVF9OT0RFKSB7XHJcbiAgICAgICAgUG9ydGFsLnRhcmdldCA9IG5vZGU7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIFBvcnRhbDtcclxufTtcclxuIiwiZXhwb3J0IGZ1bmN0aW9uIGlzU1ZHKGVsZW1lbnQpIHtcclxuICAgIGNvbnN0IHBhdHQgPSBuZXcgUmVnRXhwKGBeJHtlbGVtZW50fSRgLCAnaScpO1xyXG4gICAgY29uc3QgU1ZHVGFncyA9IFsncGF0aCcsICdzdmcnLCAndXNlJywgJ2cnXTtcclxuXHJcbiAgICByZXR1cm4gU1ZHVGFncy5zb21lKHRhZyA9PiBwYXR0LnRlc3QodGFnKSk7XHJcbn1cclxuXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlRnJhZ21lbnRGcm9tKGNoaWxkcmVuKSB7XHJcbiAgICAvLyBmcmFnbWVudHMgd2lsbCBoZWxwIGxhdGVyIHRvIGFwcGVuZCBtdWx0aXBsZSBjaGlsZHJlbiB0byB0aGUgaW5pdGlhbCBub2RlXHJcbiAgICBjb25zdCBmcmFnbWVudCA9IGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKTtcclxuXHJcbiAgICBmdW5jdGlvbiBwcm9jZXNzRE9NTm9kZXMoY2hpbGQpIHtcclxuICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgIGNoaWxkIGluc3RhbmNlb2YgSFRNTEVsZW1lbnQgfHxcclxuICAgICAgICAgICAgY2hpbGQgaW5zdGFuY2VvZiBTVkdFbGVtZW50IHx8XHJcbiAgICAgICAgICAgIGNoaWxkIGluc3RhbmNlb2YgQ29tbWVudCB8fFxyXG4gICAgICAgICAgICBjaGlsZCBpbnN0YW5jZW9mIERvY3VtZW50RnJhZ21lbnRcclxuICAgICAgICApIHtcclxuICAgICAgICAgICAgZnJhZ21lbnQuYXBwZW5kQ2hpbGQoY2hpbGQpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIGNoaWxkID09PSAnc3RyaW5nJyB8fCB0eXBlb2YgY2hpbGQgPT09ICdudW1iZXInKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHRleHRub2RlID0gZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUoY2hpbGQpO1xyXG4gICAgICAgICAgICBmcmFnbWVudC5hcHBlbmRDaGlsZCh0ZXh0bm9kZSk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChjaGlsZCBpbnN0YW5jZW9mIEFycmF5KSB7XHJcbiAgICAgICAgICAgIGNoaWxkLmZvckVhY2gocHJvY2Vzc0RPTU5vZGVzKTtcclxuICAgICAgICB9IGVsc2UgaWYgKGNoaWxkID09PSBmYWxzZSB8fCBjaGlsZCA9PT0gbnVsbCkge1xyXG4gICAgICAgICAgICAvLyBleHByZXNzaW9uIGV2YWx1YXRlZCBhcyBmYWxzZSBlLmcuIHtmYWxzZSAmJiA8RWxlbSAvPn1cclxuICAgICAgICAgICAgLy8gZXhwcmVzc2lvbiBldmFsdWF0ZWQgYXMgZmFsc2UgZS5nLiB7bnVsbCAmJiA8RWxlbSAvPn1cclxuICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBjaGlsZCA9PT0gJ2Z1bmN0aW9uJykge1xyXG5cclxuICAgICAgICB9IGVsc2UgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSAnZGV2ZWxvcG1lbnQnKSB7XHJcbiAgICAgICAgICAgIC8vIGxhdGVyIG90aGVyIHRoaW5ncyBjb3VsZCBub3QgYmUgSFRNTEVsZW1lbnQgbm9yIHN0cmluZ3NcclxuICAgICAgICAgICAgY29uc29sZS5sb2coY2hpbGQsICdpcyBub3QgYXBwZW5kYWJsZScpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBjaGlsZHJlbi5mb3JFYWNoKHByb2Nlc3NET01Ob2Rlcyk7XHJcblxyXG4gICAgcmV0dXJuIGZyYWdtZW50O1xyXG59XHJcblxyXG4vLyBNYXAgZnJvbSBKU1ggcHJvcGVydHkgKGUuZy4gb25DbGljaykgdG8gZXZlbnQgbmFtZSAoZS5nLiAnY2xpY2snKS5cclxuZXhwb3J0IGNvbnN0IEVWRU5UX0xJU1RFTkVSUyA9IHtcclxuICAgIC8vIENsaXBib2FyZCBFdmVudHNcclxuICAgIG9uQ29weTogJ2NvcHknLFxyXG4gICAgb25DdXQ6ICdjdXQnLFxyXG4gICAgb25QYXN0ZTogJ3Bhc3RlJyxcclxuXHJcbiAgICAvLyBDb21wb3NpdGlvbiBFdmVudHNcclxuICAgIG9uQ29tcG9zaXRpb25FbmQ6ICdjb21wb3NpdGlvbmVuZCcsXHJcbiAgICBvbkNvbXBvc2l0aW9uU3RhcnQ6ICdjb21wb3NpdGlvbnN0YXJ0JyxcclxuICAgIG9uQ29tcG9zaXRpb25VcGRhdGU6ICdjb21wb3NpdGlvbnVwZGF0ZScsXHJcblxyXG4gICAgLy8gRm9jdXMgRXZlbnRzXHJcbiAgICBvbkZvY3VzOiAnZm9jdXMnLFxyXG4gICAgb25CbHVyOiAnYmx1cicsXHJcblxyXG4gICAgLy8gRm9ybSBFdmVudHNcclxuICAgIG9uQ2hhbmdlOiAnY2hhbmdlJyxcclxuICAgIG9uQmVmb3JlSW5wdXQ6ICdiZWZvcmVpbnB1dCcsXHJcbiAgICBvbklucHV0OiAnaW5wdXQnLFxyXG4gICAgb25SZXNldDogJ3Jlc2V0JyxcclxuICAgIG9uU3VibWl0OiAnc3VibWl0JyxcclxuICAgIG9uSW52YWxpZDogJ2ludmFsaWQnLFxyXG5cclxuICAgIC8vIEltYWdlIEV2ZW50c1xyXG4gICAgb25Mb2FkOiAnbG9hZCcsXHJcbiAgICBvbkVycm9yOiAnZXJyb3InLFxyXG5cclxuICAgIC8vIEtleWJvYXJkIEV2ZW50c1xyXG4gICAgb25LZXlEb3duOiAna2V5ZG93bicsXHJcbiAgICBvbktleVByZXNzOiAna2V5cHJlc3MnLFxyXG4gICAgb25LZXlVcDogJ2tleXVwJyxcclxuXHJcbiAgICAvLyBNZWRpYSBFdmVudHNcclxuICAgIG9uQWJvcnQ6ICdhYm9ydCcsXHJcbiAgICBvbkNhblBsYXk6ICdjYW5wbGF5JyxcclxuICAgIG9uQ2FuUGxheVRocm91Z2g6ICdjYW5wbGF5dGhyb3VnaCcsXHJcbiAgICBvbkR1cmF0aW9uQ2hhbmdlOiAnZHVyYXRpb25jaGFuZ2UnLFxyXG4gICAgb25FbXB0aWVkOiAnZW1wdGllZCcsXHJcbiAgICBvbkVuY3J5cHRlZDogJ2VuY3J5cHRlZCcsXHJcbiAgICBvbkVuZGVkOiAnZW5kZWQnLFxyXG4gICAgb25Mb2FkZWREYXRhOiAnbG9hZGVkZGF0YScsXHJcbiAgICBvbkxvYWRlZE1ldGFkYXRhOiAnbG9hZGVkbWV0YWRhdGEnLFxyXG4gICAgb25Mb2FkU3RhcnQ6ICdsb2Fkc3RhcnQnLFxyXG4gICAgb25QYXVzZTogJ3BhdXNlJyxcclxuICAgIG9uUGxheTogJ3BsYXknLFxyXG4gICAgb25QbGF5aW5nOiAncGxheWluZycsXHJcbiAgICBvblByb2dyZXNzOiAncHJvZ3Jlc3MnLFxyXG4gICAgb25SYXRlQ2hhbmdlOiAncmF0ZWNoYW5nZScsXHJcbiAgICBvblNlZWtlZDogJ3NlZWtlZCcsXHJcbiAgICBvblNlZWtpbmc6ICdzZWVraW5nJyxcclxuICAgIG9uU3RhbGxlZDogJ3N0YWxsZWQnLFxyXG4gICAgb25TdXNwZW5kOiAnc3VzcGVuZCcsXHJcbiAgICBvblRpbWVVcGRhdGU6ICd0aW1ldXBkYXRlJyxcclxuICAgIG9uVm9sdW1lQ2hhbmdlOiAndm9sdW1lY2hhbmdlJyxcclxuICAgIG9uV2FpdGluZzogJ3dhaXRpbmcnLFxyXG5cclxuICAgIC8vIE1vdXNlRXZlbnRzXHJcbiAgICBvbkNsaWNrOiAnY2xpY2snLFxyXG4gICAgb25Db250ZXh0TWVudTogJ2NvbnRleHRtZW51JyxcclxuICAgIG9uRG91YmxlQ2xpY2s6ICdkb3VibGVjbGljaycsXHJcbiAgICBvbkRyYWc6ICdkcmFnJyxcclxuICAgIG9uRHJhZ0VuZDogJ2RyYWdlbmQnLFxyXG4gICAgb25EcmFnRW50ZXI6ICdkcmFnZW50ZXInLFxyXG4gICAgb25EcmFnRXhpdDogJ2RyYWdleGl0JyxcclxuICAgIG9uRHJhZ0xlYXZlOiAnZHJhZ2xlYXZlJyxcclxuICAgIG9uRHJhZ092ZXI6ICdkcmFnb3ZlcicsXHJcbiAgICBvbkRyYWdTdGFydDogJ2RyYWdzdGFydCcsXHJcbiAgICBvbkRyb3A6ICdkcm9wJyxcclxuICAgIG9uTW91c2VEb3duOiAnbW91c2Vkb3duJyxcclxuICAgIG9uTW91c2VFbnRlcjogJ21vdXNlZW50ZXInLFxyXG4gICAgb25Nb3VzZUxlYXZlOiAnbW91c2VsZWF2ZScsXHJcbiAgICBvbk1vdXNlTW92ZTogJ21vdXNlbW92ZScsXHJcbiAgICBvbk1vdXNlT3V0OiAnbW91c2VvdXQnLFxyXG4gICAgb25Nb3VzZU92ZXI6ICdtb3VzZW92ZXInLFxyXG4gICAgb25Nb3VzZVVwOiAnbW91c2V1cCcsXHJcblxyXG4gICAgLy8gU2VsZWN0aW9uIEV2ZW50c1xyXG4gICAgb25TZWxlY3Q6ICdzZWxlY3QnLFxyXG5cclxuICAgIC8vIFRvdWNoIEV2ZW50c1xyXG4gICAgb25Ub3VjaENhbmNlbDogJ3RvdWNoY2FuY2VsJyxcclxuICAgIG9uVG91Y2hFbmQ6ICd0b3VjaGVuZCcsXHJcbiAgICBvblRvdWNoTW92ZTogJ3RvdWNobW92ZScsXHJcbiAgICBvblRvdWNoU3RhcnQ6ICd0b3VjaHN0YXJ0JyxcclxuXHJcbiAgICAvLyBQb2ludGVyIEV2ZW50c1xyXG4gICAgb25Qb2ludGVyRG93bjogJ3BvaW50ZXJkb3duJyxcclxuICAgIG9uUG9pbnRlck1vdmU6ICdwb2ludGVybW92ZScsXHJcbiAgICBvblBvaW50ZXJVcDogJ3BvaW50ZXJ1cCcsXHJcbiAgICBvblBvaW50ZXJDYW5jZWw6ICdwb2ludGVyY2FuY2VsJyxcclxuICAgIG9uUG9pbnRlckVudGVyOiAncG9pbnRlcmVudGVyJyxcclxuICAgIG9uUG9pbnRlckxlYXZlOiAncG9pbnRlcmxlYXZlJyxcclxuICAgIG9uUG9pbnRlck92ZXI6ICdwb2ludGVyb3ZlcicsXHJcbiAgICBvblBvaW50ZXJPdXQ6ICdwb2ludGVyb3V0JyxcclxuXHJcbiAgICAvLyBVSSBFdmVudHNcclxuICAgIG9uU2Nyb2xsOiAnc2Nyb2xsJyxcclxuXHJcbiAgICAvLyBXaGVlbCBFdmVudHNcclxuICAgIG9uV2hlZWw6ICd3aGVlbCcsXHJcblxyXG4gICAgLy8gQW5pbWF0aW9uIEV2ZW50c1xyXG4gICAgb25BbmltYXRpb25TdGFydDogJ2FuaW1hdGlvbnN0YXJ0JyxcclxuICAgIG9uQW5pbWF0aW9uRW5kOiAnYW5pbWF0aW9uZW5kJyxcclxuICAgIG9uQW5pbWF0aW9uSXRlcmF0aW9uOiAnYW5pbWF0aW9uaXRlcmF0aW9uJyxcclxuXHJcbiAgICAvLyBUcmFuc2l0aW9uIEV2ZW50c1xyXG4gICAgb25UcmFuc2l0aW9uRW5kOiAndHJhbnNpdGlvbmVuZCcsXHJcbn07IiwiZnVuY3Rpb24gcXVlcnlTdHJpbmcocXVlcnkpIHtcclxuICAgIGlmICghcXVlcnkpIHtcclxuICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICAgIHJldHVybiBxdWVyeVxyXG4gICAgICAgIC5zcGxpdCgnPycpWzFdXHJcbiAgICAgICAgLnNwbGl0KCcmJylcclxuICAgICAgICAubWFwKGEgPT4gYS5zcGxpdCgnPScpKVxyXG4gICAgICAgIC5yZWR1Y2UoKGEsIGMpID0+IHtcclxuICAgICAgICAgICAgYVtjWzBdXSA9IGNbMV07XHJcbiAgICAgICAgICAgIHJldHVybiBhO1xyXG4gICAgICAgIH0sIHt9KTtcclxufVxyXG5cclxuLyoqXHJcbiAqIENhbGN1bGF0ZSBudW1iZXIgb2YgZGF5cyBwYXNzaW5nIGJldHdlZW4gdHdvIGRhdGVzXHJcbiAqIEBwYXJhbSB7RGF0ZX0gYSBTdGFydGluZyBkYXRlXHJcbiAqIEBwYXJhbSB7RGF0ZX0gYiBFbmRpbmcgZGF0ZVxyXG4gKiBAcmV0dXJucyB7bnVtYmVyfSBOdW1iZXIgb2YgZGF5c1xyXG4gKi9cclxuZnVuY3Rpb24gZGF0ZURpZmYoYSwgYikge1xyXG4gICAgaWYgKGEuZ2V0RnVsbFllYXIoKSA9PSBiLmdldEZ1bGxZZWFyKCkgJiZcclxuICAgICAgICBhLmdldE1vbnRoKCkgPT0gYi5nZXRNb250aCgpICYmXHJcbiAgICAgICAgYS5nZXREYXRlKCkgPT0gYi5nZXREYXRlKCkpIHtcclxuICAgICAgICByZXR1cm4gMDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIChiIC0gYSkgPiAwID8gTWF0aC5jZWlsKChiIC0gYSkgLyA4NjQwMDAwMCkgOiBNYXRoLmZsb29yKChiIC0gYSkgLyA4NjQwMDAwMCk7XHJcbiAgICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGRhdGVEaWZmVG9EYXlzKGRheXMpIHtcclxuICAgIGlmIChkYXlzID09IDApIHtcclxuICAgICAgICByZXR1cm4gJ1RvZGF5JztcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgaWYgKGRheXMgPD0gMCkge1xyXG4gICAgICAgICAgICByZXR1cm4gYEluICR7LWRheXN9IGRheSR7ZGF5cyA9PSAtMSA/ICcnIDogJ3MnfWA7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIGAke2RheXN9IGRheSR7ZGF5cyA9PSAxID8gJycgOiAncyd9IGFnb2A7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG4vKipcclxuICogSXMgdGhlIGRhdGUgaW4gdGhlIGxhc3QgZGF5IG9mIGEgbW9udGhcclxuICogQHBhcmFtIHtEYXRlfSBkYXRlXHJcbiAqIEByZXR1cm5zIHtib29sZWFufVxyXG4gKi9cclxuZnVuY3Rpb24gaXNMYXN0RGF5KGRhdGUpIHtcclxuICAgIGNvbnN0IG5leHREYXkgPSBuZXcgRGF0ZShkYXRlKTtcclxuICAgIG5leHREYXkuc2V0RGF0ZShuZXh0RGF5LmdldERhdGUoKSArIDEpO1xyXG4gICAgcmV0dXJuIChkYXRlLmdldE1vbnRoKCkgIT0gbmV4dERheS5nZXRNb250aCgpKTtcclxufVxyXG5cclxuLyoqXHJcbiAqIElzIHRoZSBkYXRlIGluIHRoZSBsYXN0IHdlZWsgb2YgYSBtb250aFxyXG4gKiBAcGFyYW0ge0RhdGV9IGRhdGVcclxuICogQHJldHVybnMge2Jvb2xlYW59XHJcbiAqL1xyXG5mdW5jdGlvbiBpc0xhc3RXZWVrKGRhdGUpIHtcclxuICAgIGNvbnN0IG5leHRXZWVrID0gbmV3IERhdGUoZGF0ZSk7XHJcbiAgICBuZXh0V2Vlay5zZXREYXRlKG5leHRXZWVrLmdldERhdGUoKSArIDcpO1xyXG4gICAgcmV0dXJuIChkYXRlLmdldE1vbnRoKCkgIT0gbmV4dFdlZWsuZ2V0TW9udGgoKSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZvcm1hdERhdGUoZGF0ZSkge1xyXG4gICAgY29uc3QgYXNTdHJpbmcgPSBkYXRlLnRvTG9jYWxlRGF0ZVN0cmluZygnZW4tVVMnLCB7XHJcbiAgICAgICAgbW9udGg6ICdzaG9ydCcsXHJcbiAgICAgICAgeWVhcjogJ251bWVyaWMnXHJcbiAgICB9KTtcclxuICAgIHJldHVybiBgJHtkYXRlLmdldERhdGUoKX0gJHthc1N0cmluZ31gO1xyXG59XHJcblxyXG5mdW5jdGlvbiBmb3JtYXRUaW1lKGRhdGUpIHtcclxuICAgIHJldHVybiBkYXRlLnRvTG9jYWxlVGltZVN0cmluZygnZW4tVVMnLCB7XHJcbiAgICAgICAgaG91cjogJ251bWVyaWMnLFxyXG4gICAgICAgIG1pbnV0ZTogJ251bWVyaWMnLFxyXG4gICAgICAgIC8vIGhvdXIxMjogZmFsc2UsXHJcbiAgICAgICAgaG91ckN5Y2xlOiAnaDIzJ1xyXG4gICAgfSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZvcm1hdExvY2FsZURhdGUoZGF0ZSkge1xyXG4gICAgY29uc3QgZGF5ID0gZGF0ZS5nZXREYXRlKCk7XHJcbiAgICBjb25zdCBtb250aCA9IFtcclxuICAgICAgICAn0Y/QvdGD0LDRgNC4JyxcclxuICAgICAgICAn0YTQtdCy0YDRg9Cw0YDQuCcsXHJcbiAgICAgICAgJ9C80LDRgNGCJyxcclxuICAgICAgICAn0LDQv9GA0LjQuycsXHJcbiAgICAgICAgJ9C80LDQuScsXHJcbiAgICAgICAgJ9GO0L3QuCcsXHJcbiAgICAgICAgJ9GO0LvQuCcsXHJcbiAgICAgICAgJ9Cw0LLQs9GD0YHRgicsXHJcbiAgICAgICAgJ9GB0LXQv9GC0LXQvNCy0YDQuCcsXHJcbiAgICAgICAgJ9C+0LrRgtC+0LzQstGA0LgnLFxyXG4gICAgICAgICfQvdC+0LXQvNCy0YDQuCcsXHJcbiAgICAgICAgJ9C00LXQutC10LzQstGA0LgnXHJcbiAgICBdW2RhdGUuZ2V0TW9udGgoKV07XHJcbiAgICByZXR1cm4gYCR7ZGF5fSAke21vbnRofWA7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZvcm1hdExvY2FsZVdlZWtkYXkoZGF5LCBnZXRBZGopIHtcclxuICAgIGNvbnN0IHdlZWtkYXkgPSBbXHJcbiAgICAgICAgJ9C90LXQtNC10LvRjycsXHJcbiAgICAgICAgJ9C/0L7QvdC10LTQtdC70L3QuNC6JyxcclxuICAgICAgICAn0LLRgtC+0YDQvdC40LonLFxyXG4gICAgICAgICfRgdGA0Y/QtNCwJyxcclxuICAgICAgICAn0YfQtdGC0LLRitGA0YLRitC6JyxcclxuICAgICAgICAn0L/QtdGC0YrQuicsXHJcbiAgICAgICAgJ9GB0YrQsdC+0YLQsCcsXHJcbiAgICBdW2RheV07XHJcbiAgICBpZiAoZ2V0QWRqKSB7XHJcbiAgICAgICAgcmV0dXJuIFt3ZWVrZGF5LCBbXHJcbiAgICAgICAgICAgICfQstGB0Y/QutCwJyxcclxuICAgICAgICAgICAgJ9Cy0YHQtdC60LgnLFxyXG4gICAgICAgICAgICAn0LLRgdC10LrQuCcsXHJcbiAgICAgICAgICAgICfQstGB0Y/QutCwJyxcclxuICAgICAgICAgICAgJ9Cy0YHQtdC60LgnLFxyXG4gICAgICAgICAgICAn0LLRgdC10LrQuCcsXHJcbiAgICAgICAgICAgICfQstGB0Y/QutCwJyxcclxuICAgICAgICBdW2RheV1dO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHdlZWtkYXk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBHZXQgYSBuZXcgZGF0ZSBvZmZzZXQgYnkgdGhlIHNwZWNpZmllZCBudW1iZXIgb2YgZGF5c1xyXG4gKiBAcGFyYW0ge0RhdGV9IGRhdGUgQmFzZSBkYXRlXHJcbiAqIEBwYXJhbSB7bnVtYmVyfSBkYXlzIEhvdyBtYW55IGRheXMgdG8gb2Zmc2V0XHJcbiAqIEByZXR1cm5zIHtEYXRlfVxyXG4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIGdldE9mZnNldEJ5RGF5cyhkYXRlLCBkYXlzKSB7XHJcbiAgICBjb25zdCByZXN1bHQgPSBuZXcgRGF0ZShkYXRlKTtcclxuICAgIHJlc3VsdC5zZXRVVENEYXRlKHJlc3VsdC5nZXRVVENEYXRlKCkgKyBkYXlzKTtcclxuICAgIHJldHVybiByZXN1bHQ7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBPZmZzZXQgdGhlIGdpdmVuIGRhdGUgaW4gcGxhY2UgYnkgdGhlIHNwZWNpZmllZCBudW1iZXIgb2YgZGF5c1xyXG4gKiBAcGFyYW0ge0RhdGV9IGRhdGUgQmFzZSBkYXRlXHJcbiAqIEBwYXJhbSB7bnVtYmVyfSBkYXlzIEhvdyBtYW55IGRheXMgdG8gb2Zmc2V0XHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gb2Zmc2V0QnlEYXlzKGRhdGUsIGRheXMpIHtcclxuICAgIGRhdGUuc2V0VVRDRGF0ZShkYXRlLmdldFVUQ0RhdGUoKSArIGRheXMpO1xyXG59XHJcblxyXG4vKipcclxuICogQ3JlYXRlIGRhdGUgaW5kZXggYXMgc3RyaW5nXHJcbiAqIEBwYXJhbSB7RGF0ZXxzdHJpbmd9IGRhdGUgQmFzZSBkYXRlXHJcbiAqIEByZXR1cm5zIHtzdHJpbmd9XHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGF0ZUluZGV4KGRhdGUpIHtcclxuICAgIGlmICh0eXBlb2YgZGF0ZSA9PSAnc3RyaW5nJykge1xyXG4gICAgICAgIGRhdGUgPSBuZXcgRGF0ZShkYXRlKTtcclxuICAgIH1cclxuICAgIHJldHVybiBkYXRlLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBwcmV0dHlKU09OKG9iaikge1xyXG4gICAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KG9iaiwgbnVsbCwgMikucmVwbGFjZSgvIC9nbWksICcmbmJzcDsnKS5yZXBsYWNlKC9cXG4vZ21pLCAnPGJyPicpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRNb25kYXkoZGF0ZSkge1xyXG4gICAgY29uc3QgbW9uZGF5ID0gbmV3IERhdGUoYCR7ZGF0ZS5nZXRGdWxsWWVhcigpfS0ke2RhdGUuZ2V0TW9udGgoKSArIDF9LSR7ZGF0ZS5nZXREYXRlKCl9IDEyOjAwOjAwYCk7XHJcbiAgICBtb25kYXkuc2V0RGF0ZShtb25kYXkuZ2V0RGF0ZSgpIC0gKChtb25kYXkuZ2V0RGF5KCkgKyA2KSAlIDcpKTtcclxuICAgIHJldHVybiBtb25kYXk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGdldFN1bmRheShkYXRlKSB7XHJcbiAgICBjb25zdCBzdW5kYXkgPSBuZXcgRGF0ZShgJHtkYXRlLmdldEZ1bGxZZWFyKCl9LSR7ZGF0ZS5nZXRNb250aCgpICsgMX0tJHtkYXRlLmdldERhdGUoKX0gMjM6NTk6NTlgKTtcclxuICAgIHN1bmRheS5zZXREYXRlKHN1bmRheS5nZXREYXRlKCkgKyAoKDcgLSBzdW5kYXkuZ2V0RGF5KCkpICUgNykpO1xyXG4gICAgcmV0dXJuIHN1bmRheTtcclxufVxyXG5cclxuY29uc3QgbW9udGhOYW1lID0ge1xyXG4gICAgMTogJ0phbnVhcnknLFxyXG4gICAgMjogJ0ZlYnJ1YXJ5JyxcclxuICAgIDM6ICdNYXJjaCcsXHJcbiAgICA0OiAnQXByaWwnLFxyXG4gICAgNTogJ01heScsXHJcbiAgICA2OiAnSnVuZScsXHJcbiAgICA3OiAnSnVseScsXHJcbiAgICA4OiAnQXVndXN0JyxcclxuICAgIDk6ICdTZXB0ZW1iZXInLFxyXG4gICAgMTA6ICdPY3RvYmVyJyxcclxuICAgIDExOiAnTm92ZW1iZXInLFxyXG4gICAgMTI6ICdEZWNlbWJlcicsXHJcbn07XHJcblxyXG5cclxuY29uc3QgbG9jYWxlTW9udGhOYW1lID0ge1xyXG4gICAgMTogJ9GP0L3Rg9Cw0YDQuCcsXHJcbiAgICAyOiAn0YTQtdCy0YDRg9Cw0YDQuCcsXHJcbiAgICAzOiAn0LzQsNGA0YInLFxyXG4gICAgNDogJ9Cw0L/RgNC40LsnLFxyXG4gICAgNTogJ9C80LDQuScsXHJcbiAgICA2OiAn0Y7QvdC4JyxcclxuICAgIDc6ICfRjtC70LgnLFxyXG4gICAgODogJ9Cw0LLQs9GD0YHRgicsXHJcbiAgICA5OiAn0YHQtdC/0YLQtdC80LLRgNC4JyxcclxuICAgIDEwOiAn0L7QutGC0L7QvNCy0YDQuCcsXHJcbiAgICAxMTogJ9C90L7QtdC80LLRgNC4JyxcclxuICAgIDEyOiAn0LTQtdC60LXQvNCy0YDQuCcsXHJcbn07XHJcblxyXG5mdW5jdGlvbiB0b0Fzc29jQXJyYXkocCwgYywgaSwgYSkge1xyXG4gICAgcFtjLklkXSA9IGM7XHJcbiAgICByZXR1cm4gcDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHRvQ3VzdG9tQXNzb2NBcnJheShpbmRleE5hbWUsIG92ZXJ3cml0ZSA9IGZhbHNlKSB7XHJcbiAgICByZXR1cm4gKHAsIGMsIGksIGEpID0+IHtcclxuICAgICAgICBpZiAocFtjW2luZGV4TmFtZV1dICE9PSB1bmRlZmluZWQgJiYgb3ZlcndyaXRlID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KHBbY1tpbmRleE5hbWVdXSkpIHtcclxuICAgICAgICAgICAgICAgIHBbY1tpbmRleE5hbWVdXS5wdXNoKGMpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcFtjW2luZGV4TmFtZV1dID0gW3BbY1tpbmRleE5hbWVdXSwgY107XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBwW2NbaW5kZXhOYW1lXV0gPSBjO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gcDtcclxuICAgIH07XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBAcGFyYW0ge0FycmF5PFNVUGF5bWVudD59IGRhdGEgXHJcbiAqIEByZXR1cm5zIHtBcnJheTxQYXltZW50Vmlld01vZGVsPn1cclxuICovXHJcbmZ1bmN0aW9uIHBheW1lbnRzVG9NYXRyaXgoZGF0YSkge1xyXG4gICAgY29uc3QgdGVtcGxhdGUgPSBbXHJcbiAgICAgICAgJ0lkJyxcclxuICAgICAgICAnUGF5bWVudE51bWJlcicsXHJcbiAgICAgICAgJ01vZHVsZU5hbWVFbicsXHJcbiAgICAgICAgJ1BheW1lbnRQYWNrYWdlc0FzU3RyaW5nJyxcclxuICAgICAgICAnUGFpZEZvclVzZXJOYW1lJyxcclxuICAgICAgICAnUHJpY2UnLFxyXG4gICAgICAgICdFZHVjYXRpb25hbEZvcm0nLFxyXG4gICAgICAgICdQYXltZW50RGF0ZVRpbWUnXHJcbiAgICBdO1xyXG4gICAgY29uc3QgcGFyc2VkID0gZGF0YS5tYXAoZSA9PiB7XHJcbiAgICAgICAgZS5FZHVjYXRpb25hbEZvcm0gPSBlLkVkdWNhdGlvbmFsRm9ybSA9PSAxID8gJ29ubGluZScgOiAnb25zaXRlJztcclxuICAgICAgICBjb25zdCBlbnRyeSA9IFtdO1xyXG4gICAgICAgIGZvciAobGV0IHByb3Agb2YgdGVtcGxhdGUpIHtcclxuICAgICAgICAgICAgaWYgKHByb3AgPT09ICdQYXltZW50RGF0ZVRpbWUnKSB7XHJcbiAgICAgICAgICAgICAgICBlbnRyeS5wdXNoKG5ldyBEYXRlKGVbcHJvcF0pKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGVudHJ5LnB1c2goZVtwcm9wXSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGVudHJ5O1xyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIFt0ZW1wbGF0ZSwgLi4ucGFyc2VkXTtcclxufVxyXG5cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiB1dWlkKCkge1xyXG4gICAgcmV0dXJuICd4eHh4eHh4eC14eHh4LTR4eHgteXh4eC14eHh4eHh4eHh4eHgnLnJlcGxhY2UoL1t4eV0vZywgZnVuY3Rpb24gKGMpIHtcclxuICAgICAgICBsZXQgciA9IE1hdGgucmFuZG9tKCkgKiAxNiB8IDAsXHJcbiAgICAgICAgICAgIHYgPSBjID09ICd4JyA/IHIgOiAociAmIDB4MyB8IDB4OCk7XHJcbiAgICAgICAgcmV0dXJuIHYudG9TdHJpbmcoMTYpO1xyXG4gICAgfSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBub3JtYWxpemVEYXRlVGltZShkYXRldGltZSkge1xyXG4gICAgaWYgKCFkYXRldGltZSkge1xyXG4gICAgICAgIHJldHVybiAnJztcclxuICAgIH0gZWxzZSBpZiAoZGF0ZXRpbWUudG9TdHJpbmcoKS5pbmNsdWRlcygnRGF0ZSgnKSkge1xyXG4gICAgICAgIGNvbnN0IG1hdGNoID0gL0RhdGVcXCgoLispXFwpLy5leGVjKGRhdGV0aW1lKTtcclxuICAgICAgICBpZiAobWF0Y2ggIT09IG51bGwpIHtcclxuICAgICAgICAgICAgY29uc3QgZCA9IG5ldyBEYXRlKE51bWJlcihtYXRjaFsxXSkpO1xyXG4gICAgICAgICAgICByZXR1cm4gYCR7KCcwMDAwJyArIGQuZ2V0RnVsbFllYXIoKSkuc2xpY2UoLTQpfS0ke3B0KGQuZ2V0TW9udGgoKSArIDEpfS0ke3B0KGQuZ2V0RGF0ZSgpKX1UJHtwdChkLmdldEhvdXJzKCkpfToke3B0KGQuZ2V0TWludXRlcygpKX1gO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiBkYXRldGltZTtcclxuICAgICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJldHVybiBkYXRldGltZTtcclxuICAgIH1cclxufVxyXG5cclxuZnVuY3Rpb24gcHQocykge1xyXG4gICAgcmV0dXJuIGAwJHtzfWAuc2xpY2UoLTIpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBodG1sVG9UZXh0KGh0bWwpIHtcclxuICAgIGNvbnN0IGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgZGl2LmlubmVySFRNTCA9IGh0bWw7XHJcblxyXG4gICAgcmV0dXJuIGRpdi50ZXh0Q29udGVudDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGluc3RhbmNlTWV0YUZyb21IcmVmKGhyZWYpIHtcclxuICAgIGNvbnN0IGluc3RhbmNlTWV0YSA9IHF1ZXJ5U3RyaW5nKGhyZWYpO1xyXG4gICAgaW5zdGFuY2VNZXRhLkluc3RhbmNlUmVmVHlwZSA9ICgoKSA9PiB7XHJcbiAgICAgICAgc3dpdGNoIChpbnN0YW5jZU1ldGEudHlwZSkge1xyXG4gICAgICAgICAgICBjYXNlICdjb3Vyc2UnOiByZXR1cm4gJ21haW4nO1xyXG4gICAgICAgICAgICBjYXNlICdmYXN0LXRyYWNrJzogcmV0dXJuICdvcGVuJztcclxuICAgICAgICAgICAgY2FzZSAnZ2VuZXJhbC1jb3Vyc2UtaW5zdGFuY2UnOiByZXR1cm4gJ2dlbmVyYWwnO1xyXG4gICAgICAgIH1cclxuICAgIH0pKCk7XHJcblxyXG4gICAgcmV0dXJuIGluc3RhbmNlTWV0YTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGhhc1ZhbHVlKHZhbHVlKSB7XHJcbiAgICByZXR1cm4gKHZhbHVlICE9PSBudWxsICYmIHZhbHVlICE9PSB1bmRlZmluZWQgJiYgdmFsdWUgIT09ICcnKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHZhbHVlT3JFbXB0eSh2YWx1ZSwgYWx0ID0gJycpIHtcclxuICAgIGlmICh2YWx1ZSA9PT0gbnVsbCB8fCB2YWx1ZSA9PT0gdW5kZWZpbmVkIHx8IHZhbHVlID09PSAnJykge1xyXG4gICAgICAgIHJldHVybiBhbHQ7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJldHVybiB2YWx1ZTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHN1bUFycmF5TWF4KGFycikge1xyXG4gICAgaWYgKGFyclswXS5sZW5ndGggPT0gMCAmJiBhcnJbMV0ubGVuZ3RoID09IDApIHtcclxuICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuXHJcbiAgICBsZXQgcmVzdWx0ID0gMDtcclxuXHJcbiAgICBpZiAoYXJyWzBdLmxlbmd0aCA+IDApIHtcclxuICAgICAgICByZXN1bHQgKz0gTWF0aC5tYXgoLi4uYXJyWzBdKTtcclxuICAgIH1cclxuICAgIGlmIChhcnJbMV0ubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIHJlc3VsdCArPSBNYXRoLm1heCguLi5hcnJbMV0pO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiByZXN1bHQ7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IHtcclxuICAgIHF1ZXJ5U3RyaW5nLFxyXG4gICAgZGF0ZURpZmYsXHJcbiAgICBkYXRlRGlmZlRvRGF5cyxcclxuICAgIGlzTGFzdERheSxcclxuICAgIGlzTGFzdFdlZWssXHJcbiAgICBmb3JtYXREYXRlLFxyXG4gICAgZm9ybWF0VGltZSxcclxuICAgIGZvcm1hdExvY2FsZURhdGUsXHJcbiAgICBmb3JtYXRMb2NhbGVXZWVrZGF5LFxyXG4gICAgcHJldHR5SlNPTixcclxuICAgIGdldE1vbmRheSxcclxuICAgIGdldFN1bmRheSxcclxuICAgIG1vbnRoTmFtZSxcclxuICAgIGxvY2FsZU1vbnRoTmFtZSxcclxuICAgIHRvQXNzb2NBcnJheSxcclxuICAgIHBheW1lbnRzVG9NYXRyaXgsXHJcbiAgICBodG1sVG9UZXh0XHJcbn07XHJcblxyXG5cclxuZXhwb3J0IHtcclxuICAgIHF1ZXJ5U3RyaW5nLFxyXG4gICAgZGF0ZURpZmYsXHJcbiAgICBkYXRlRGlmZlRvRGF5cyxcclxuICAgIGlzTGFzdERheSxcclxuICAgIGlzTGFzdFdlZWssXHJcbiAgICBmb3JtYXREYXRlLFxyXG4gICAgZm9ybWF0VGltZSxcclxuICAgIGZvcm1hdExvY2FsZURhdGUsXHJcbiAgICBmb3JtYXRMb2NhbGVXZWVrZGF5LFxyXG4gICAgcHJldHR5SlNPTixcclxuICAgIGdldE1vbmRheSxcclxuICAgIGdldFN1bmRheSxcclxuICAgIG1vbnRoTmFtZSxcclxuICAgIGxvY2FsZU1vbnRoTmFtZSxcclxuICAgIHRvQXNzb2NBcnJheSxcclxuICAgIHBheW1lbnRzVG9NYXRyaXgsXHJcbiAgICBodG1sVG9UZXh0XHJcbn07IiwiaW1wb3J0IHsgdXVpZCB9IGZyb20gJy4vcGFyc2UnO1xyXG5pbXBvcnQgZG9tLCB7IEZyYWdtZW50IH0gZnJvbSAnLi4vdXRpbC9qc3gtcmVuZGVyLW1vZC9kb20nO1xyXG5cclxuLyoqXHJcbiAqIFxyXG4gKiBAcGFyYW0geyp9IHR5cGUgXHJcbiAqIEBwYXJhbSB7Kn0gY29udGVudCBcclxuICogQHBhcmFtIHsqfSBhdHRyaWJ1dGVzIFxyXG4gKiBAcGFyYW0ge3tmb3JjZVR5cGU6ICdUZXh0JyB8ICdIVE1MJ319IG9wdGlvbnMgXHJcbiAqIEByZXR1cm5zIFxyXG4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIGVsZW1lbnQodHlwZSwgY29udGVudCwgYXR0cmlidXRlcywgb3B0aW9ucyA9IHVuZGVmaW5lZCkge1xyXG4gICAgY29uc3QgcmVzdWx0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCh0eXBlKTtcclxuXHJcbiAgICBpZiAoYXR0cmlidXRlcykge1xyXG4gICAgICAgIGZvciAobGV0IGF0dHIgb2YgT2JqZWN0LmtleXMoYXR0cmlidXRlcykpIHtcclxuICAgICAgICAgICAgcmVzdWx0W2F0dHJdID0gYXR0cmlidXRlc1thdHRyXTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcmVzdWx0LmFwcGVuZCA9IGFwcGVuZC5iaW5kKHJlc3VsdCk7XHJcblxyXG4gICAgcmVzdWx0LmFwcGVuZFRvID0gKHBhcmVudCkgPT4ge1xyXG4gICAgICAgIHBhcmVudC5hcHBlbmQocmVzdWx0KTtcclxuICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgfTtcclxuXHJcbiAgICBpZiAoY29udGVudCAhPT0gdW5kZWZpbmVkICYmIGNvbnRlbnQgIT09IG51bGwpIHtcclxuICAgICAgICByZXN1bHQuYXBwZW5kKGNvbnRlbnQsIG9wdGlvbnMpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxufVxyXG5cclxuZnVuY3Rpb24gYXBwZW5kKGNoaWxkLCBvcHRpb25zID0gdW5kZWZpbmVkKSB7XHJcbiAgICBpZiAodHlwZW9mIChjaGlsZCkgPT09ICdzdHJpbmcnIHx8IHR5cGVvZiAoY2hpbGQpID09PSAnbnVtYmVyJykge1xyXG4gICAgICAgIGlmIChvcHRpb25zPy5mb3JjZVR5cGUgIT0gJ1RleHQnICYmIChvcHRpb25zPy5mb3JjZVR5cGUgPT09ICdIVE1MJyB8fCBjaGlsZC50b1N0cmluZygpLnRyaW0oKVswXSA9PT0gJzwnKSkge1xyXG4gICAgICAgICAgICB0aGlzLmlubmVySFRNTCA9IGNoaWxkO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGNoaWxkID0gZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUoY2hpbGQpO1xyXG4gICAgICAgICAgICB0aGlzLmFwcGVuZENoaWxkKGNoaWxkKTtcclxuICAgICAgICB9XHJcbiAgICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkoY2hpbGQpKSB7XHJcbiAgICAgICAgZm9yIChsZXQgbm9kZSBvZiBjaGlsZCkge1xyXG4gICAgICAgICAgICBhcHBlbmQuY2FsbCh0aGlzLCBub2RlKTtcclxuICAgICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIHRoaXMuYXBwZW5kQ2hpbGQoY2hpbGQpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRoaXM7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiByZXBsYWNlQ29udGVudHMobm9kZSwgbmV3Q29udGVudHMpIHtcclxuICAgIGNvbnN0IGNOb2RlID0gbm9kZS5jbG9uZU5vZGUoZmFsc2UpO1xyXG4gICAgYXBwZW5kLmNhbGwoY05vZGUsIG5ld0NvbnRlbnRzKTtcclxuICAgIHRyeSB7XHJcbiAgICAgICAgbm9kZS5wYXJlbnROb2RlLnJlcGxhY2VDaGlsZChjTm9kZSwgbm9kZSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmluZm8oJ05vZGUgaGFzIG5vIHBhcmVudCBvciBhbm90aGVyIHByb2JsZW0gb2NjdXJlZCcpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBjTm9kZTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHN3YXAob2xkTm9kZSwgbmV3Tm9kZSkge1xyXG4gICAgb2xkTm9kZS5wYXJlbnROb2RlLnJlcGxhY2VDaGlsZChuZXdOb2RlLCBvbGROb2RlKTtcclxuICAgIHJldHVybiBuZXdOb2RlO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU3Bpbm5lcih7IGlkIH0pIHtcclxuICAgIGNvbnN0IG5vZGUgPSBlbGVtZW50KCdkaXYnLCBbXHJcbiAgICAgICAgZWxlbWVudCgnZGl2JywgbnVsbCwgeyBjbGFzc0xpc3Q6ICdzay1jdWJlIHNrLWN1YmUxJyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3NrLWN1YmUgc2stY3ViZTInIH0pLFxyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAnc2stY3ViZSBzay1jdWJlMycgfSksXHJcbiAgICAgICAgZWxlbWVudCgnZGl2JywgbnVsbCwgeyBjbGFzc0xpc3Q6ICdzay1jdWJlIHNrLWN1YmU0JyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3NrLWN1YmUgc2stY3ViZTUnIH0pLFxyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAnc2stY3ViZSBzay1jdWJlNicgfSksXHJcbiAgICAgICAgZWxlbWVudCgnZGl2JywgbnVsbCwgeyBjbGFzc0xpc3Q6ICdzay1jdWJlIHNrLWN1YmU3JyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3NrLWN1YmUgc2stY3ViZTgnIH0pLFxyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAnc2stY3ViZSBzay1jdWJlOScgfSksXHJcbiAgICBdLCB7IGNsYXNzTGlzdDogJ3NrLWN1YmUtZ3JpZCcgfSk7XHJcbiAgICBpZiAoaWQpIHtcclxuICAgICAgICBub2RlLnNldEF0dHJpYnV0ZSgnaWQnLCBpZCk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIG5vZGU7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBMb2FkaW5nKHsgaWQsIGNvbG9yID0gJ3doaXRlJyB9KSB7XHJcbiAgICBjb25zdCBub2RlID0gZWxlbWVudCgnZGl2JywgW1xyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAncmVjdDEnIH0pLFxyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAncmVjdDInIH0pLFxyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAncmVjdDMnIH0pLFxyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAncmVjdDQnIH0pLFxyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAncmVjdDUnIH0pLFxyXG4gICAgXSwgeyBjbGFzc0xpc3Q6IGdldENsYXNzKCkgfSk7XHJcbiAgICBpZiAoaWQpIHtcclxuICAgICAgICBub2RlLnNldEF0dHJpYnV0ZSgnaWQnLCBpZCk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIG5vZGU7XHJcblxyXG5cclxuICAgIGZ1bmN0aW9uIGdldENsYXNzKCkge1xyXG4gICAgICAgIHJldHVybiBgc3Bpbm5lciAke2NvbG9yfWA7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBSZW1vdGUoeyBzcmMsIHBhcnNlLCBjb21wb25lbnQsIGNvbG9yID0gJ3doaXRlJywgb25SZWFkeSwgb25FcnJvciB9KSB7XHJcbiAgICBjb25zdCBpZCA9IHV1aWQoKTtcclxuICAgIHJlc29sdmUoKTtcclxuXHJcbiAgICBjb25zdCBsb2FkZXIgPSBMb2FkaW5nKHsgaWQsIGNvbG9yIH0pO1xyXG5cclxuICAgIHJldHVybiBsb2FkZXI7XHJcblxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHJlc29sdmUoKSB7XHJcbiAgICAgICAgbGV0IGRhdGEgPSBhd2FpdCAoYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGF3YWl0IChzcmMgaW5zdGFuY2VvZiBQcm9taXNlKSA/IHNyYyA6IHNyYygpO1xyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAob25FcnJvcikge1xyXG4gICAgICAgICAgICAgICAgICAgIG9uRXJyb3IoZSwgbG9hZGVyKTtcclxuICAgICAgICAgICAgICAgICAgICB0aHJvdyBlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY29uc3QgcmV0cnlCdG4gPSBlbGVtZW50KCdidXR0b24nLCBbXHJcbiAgICAgICAgICAgICAgICAgICAgZWxlbWVudCgnaScsIG51bGwsIHsgY2xhc3NOYW1lOiAnZ2x5cGhpY29uIGdseXBoaWNvbi1yZXBlYXQnIH0pLFxyXG4gICAgICAgICAgICAgICAgICAgICdSZXRyeSdcclxuICAgICAgICAgICAgICAgIF0sIHsgc3R5bGU6ICdiYWNrZ3JvdW5kLWNvbG9yOiBncmVlbicgfSk7XHJcbiAgICAgICAgICAgICAgICByZXRyeUJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICByZXBsYWNlU2VsZihSZW1vdGUoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzcmMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhcnNlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb21wb25lbnQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yXHJcbiAgICAgICAgICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZWxlbWVudCgnZGl2JywgW1xyXG4gICAgICAgICAgICAgICAgICAgIGVsZW1lbnQoJ2knLCBudWxsLCB7IGNsYXNzTmFtZTogJ2dseXBoaWNvbiBnbHlwaGljb24tcmVtb3ZlJywgc3R5bGU6ICdjb2xvcjogcmVkJyB9KSxcclxuICAgICAgICAgICAgICAgICAgICBlLm1lc3NhZ2UsXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0cnlCdG5cclxuICAgICAgICAgICAgICAgIF0sIHsgaWQ6IGlkIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSkoKTtcclxuXHJcbiAgICAgICAgaWYgKHBhcnNlKSB7XHJcbiAgICAgICAgICAgIGRhdGEgPSBwYXJzZShkYXRhKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJlcGxhY2VTZWxmKGRhdGEpO1xyXG5cclxuICAgICAgICBmdW5jdGlvbiByZXBsYWNlU2VsZihkYXRhKSB7XHJcbiAgICAgICAgICAgIC8vY29uc3QgbG9hZGVyID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaWQpO1xyXG4gICAgICAgICAgICBjb25zdCBwYXJlbnQgPSBsb2FkZXIucGFyZW50Tm9kZTtcclxuXHJcbiAgICAgICAgICAgIGlmIChjb21wb25lbnQpIHtcclxuICAgICAgICAgICAgICAgIHBhcmVudC5pbnNlcnRCZWZvcmUoY29tcG9uZW50KGRhdGEpLCBsb2FkZXIpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgYXBwZW5kKGRhdGEpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vYXdhaXQgbmV3IFByb21pc2UocmVzb2x2ZSA9PiBzZXRUaW1lb3V0KDEwLCByZXNvbHZlKSk7XHJcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaWQpKTtcclxuICAgICAgICAgICAgbG9hZGVyLnJlbW92ZSgpO1xyXG4gICAgICAgICAgICBpZiAob25SZWFkeSkge1xyXG4gICAgICAgICAgICAgICAgb25SZWFkeSgpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBmdW5jdGlvbiBhcHBlbmQoY2hpbGQpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgKGNoaWxkKSA9PT0gJ3N0cmluZycgfHwgdHlwZW9mIChjaGlsZCkgPT09ICdudW1iZXInKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNoaWxkLnRvU3RyaW5nKCkudHJpbSgpWzBdID09PSAnPCcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZnJhZ21lbnQgPSBlbGVtZW50KCdkaXYnLCBjaGlsZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZyYWdtZW50LmNoaWxkTm9kZXMuZm9yRWFjaChuID0+IHBhcmVudC5pbnNlcnRCZWZvcmUobi5jbG9uZU5vZGUodHJ1ZSksIGxvYWRlcikpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhcmVudC5pbnNlcnRCZWZvcmUoZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUoY2hpbGQpLCBsb2FkZXIpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheShjaGlsZCkpIHtcclxuICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBub2RlIG9mIGNoaWxkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFwcGVuZChub2RlKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHBhcmVudC5pbnNlcnRCZWZvcmUoY2hpbGQsIGxvYWRlcik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBZZXMoKSB7XHJcbiAgICBjb25zdCBlbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2knKTtcclxuICAgIGVsLmNsYXNzTmFtZSA9ICdnbHlwaGljb24gZ2x5cGhpY29uLW9rJztcclxuICAgIGVsLnN0eWxlLmNvbG9yID0gJ2dyZWVuJztcclxuICAgIHJldHVybiBlbDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIE5vKCkge1xyXG4gICAgY29uc3QgZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdpJyk7XHJcbiAgICBlbC5jbGFzc05hbWUgPSAnZ2x5cGhpY29uIGdseXBoaWNvbi1yZW1vdmUnO1xyXG4gICAgZWwuc3R5bGUuY29sb3IgPSAncmVkJztcclxuICAgIHJldHVybiBlbDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFF1ZXN0aW9uKFt0aXRsZSwgYW5zd2Vyc10pIHtcclxuICAgIHJldHVybiBlbGVtZW50KCdkaXYnLCBbXHJcbiAgICAgICAgZWxlbWVudCgnaDInLCB0aXRsZSksXHJcbiAgICAgICAgZWxlbWVudCgndWwnLCBPYmplY3QuZW50cmllcyhhbnN3ZXJzKS5tYXAoKFthLCBpc0NvcnJlY3RdKSA9PiBlbGVtZW50KCdsaScsIGEsIHsgY2xhc3NMaXN0OiBpc0NvcnJlY3QgPyAnY29ycmVjdC1hbnN3ZXInIDogJ25vbmUnIH0sIHRydWUpKSlcclxuICAgIF0sIHsgY2xhc3NMaXN0OiAncXVlc3Rpb24tY29udGFpbmVyJyB9KTtcclxufTtcclxuXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQWxlcnQoKSB7XHJcbiAgICBjb25zdCBlbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2knKTtcclxuICAgIGVsLmNsYXNzTmFtZSA9ICdnbHlwaGljb24gZ2x5cGhpY29uLXdhcm5pbmctc2lnbic7XHJcbiAgICBlbC5zdHlsZS5jb2xvciA9ICdvcmFuZ2UnO1xyXG4gICAgcmV0dXJuIGVsO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQ29udGFpbmVyKHsgY2hpbGRyZW4sIGNsYXNzTmFtZSB9KSB7XHJcbiAgICBjb25zdCBzZWN0aW9uID0gZWxlbWVudCgnc2VjdGlvbicsIGNoaWxkcmVuLCB7XHJcbiAgICAgICAgY2xhc3NOYW1lOiBjbGFzc05hbWUgPyAnZXZlbnQtY29udGFpbmVyJyA6ICdjb250YWluZXInXHJcbiAgICB9KTtcclxuICAgIGNvbnN0IGVsID0gZWxlbWVudCgnZGl2Jywgc2VjdGlvbiwge1xyXG4gICAgICAgIGNsYXNzTmFtZTogY2xhc3NOYW1lID8gY2xhc3NOYW1lIDogJ2NvbnRhaW5lciBhZG1pbmlzdHJhdGlvbi1jb250YWluZXIgc2VzLWNvbnRhaW5lcidcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIGVsO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gcG9wdXBUYWJsZShkYXRhKSB7XHJcbiAgICBsZXQgaHRtbCA9IGBcclxuICAgICAgICA8c3R5bGU+XHJcbiAgICAgICAgICAgIHRhYmxlIHtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdHIsIHRkLCB0aCB7XHJcbiAgICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCBibGFjaztcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDAuMjVlbSAwLjVlbTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIDwvc3R5bGU+XHJcbiAgICAgICAgYDtcclxuICAgIGh0bWwgKz0gJzx0YWJsZT48dGhlYWQ+PHRyPic7XHJcbiAgICBmb3IgKGxldCBjb2wgb2YgZGF0YVswXSkge1xyXG4gICAgICAgIGh0bWwgKz0gYDx0aD4ke2NvbH08L3RoPmA7XHJcbiAgICB9XHJcbiAgICBodG1sICs9ICc8L3RyPjwvdGhlYWQ+PHRib2R5Pic7XHJcbiAgICBmb3IgKGxldCByb3cgPSAxOyByb3cgPCBkYXRhLmxlbmd0aDsgcm93KyspIHtcclxuICAgICAgICBodG1sICs9ICc8dHI+JztcclxuICAgICAgICBmb3IgKGxldCBjb2wgb2YgZGF0YVtyb3ddKSB7XHJcbiAgICAgICAgICAgIGh0bWwgKz0gYDx0ZD4ke2NvbH08L3RkPmA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGh0bWwgKz0gJzwvdHI+JztcclxuICAgIH1cclxuICAgIGh0bWwgKz0gJzwvdGJvZHk+PC90YWJsZT4nO1xyXG4gICAgcmV0dXJuIGh0bWw7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRFZGl0b3JEZWNvcmF0aW9uKGVsZW1lbnQpIHtcclxuICAgIGZ1bmN0aW9uIGVuYWJsZSgpIHtcclxuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5hZGQoJ2VuYWJsZWQnKTtcclxuICAgIH1cclxuICAgIGZ1bmN0aW9uIGRpc2FibGUoKSB7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdlbmFibGVkJyk7XHJcbiAgICB9XHJcbiAgICBmdW5jdGlvbiB3b3JraW5nKCkge1xyXG4gICAgICAgIGVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnZW5hYmxlZCcpO1xyXG4gICAgICAgIGVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnd29ya2luZycpO1xyXG4gICAgfVxyXG4gICAgZnVuY3Rpb24gdXBkYXRlZCgpIHtcclxuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ3dvcmtpbmcnKTtcclxuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5hZGQoJ3VwZGF0ZWQnKTtcclxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IGVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgndXBkYXRlZCcpLCAzMDAwKTtcclxuICAgIH1cclxuICAgIGZ1bmN0aW9uIGZhaWx1cmUoKSB7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCd3b3JraW5nJyk7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QuYWRkKCdmYWlsZWQnKTtcclxuICAgIH1cclxuICAgIGZ1bmN0aW9uIF9jbGVhcigpIHtcclxuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ2VuYWJsZWQnKTtcclxuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ3dvcmtpbmcnKTtcclxuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ3VwZGF0ZWQnKTtcclxuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ2ZhaWxlZCcpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgZW5hYmxlLFxyXG4gICAgICAgIGRpc2FibGUsXHJcbiAgICAgICAgd29ya2luZyxcclxuICAgICAgICB1cGRhdGVkLFxyXG4gICAgICAgIGZhaWx1cmUsXHJcbiAgICAgICAgX2NsZWFyXHJcbiAgICB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gYXBwbHlCZWdpblJlcXVlc3QoZWxlbWVudCkge1xyXG4gICAgZWxlbWVudC5jaGlsZE5vZGVzLmZvckVhY2goYyA9PiBjLmNoaWxkTm9kZXMuZm9yRWFjaChuID0+IG4uZGlzYWJsZWQgPSB0cnVlKSk7XHJcbiAgICBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ2VuYWJsZWQnKTtcclxuICAgIGVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnZmFpbGVkJyk7XHJcbiAgICBlbGVtZW50LmNsYXNzTGlzdC5hZGQoJ3dvcmtpbmcnKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGFwcGx5UmVxdWVzdFN1Y2Nlc3MoZWxlbWVudCkge1xyXG4gICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCd3b3JraW5nJyk7XHJcbiAgICBlbGVtZW50LmNsYXNzTGlzdC5hZGQoJ3VwZGF0ZWQnKTtcclxuICAgIHNldFRpbWVvdXQoKCkgPT4gZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCd1cGRhdGVkJyksIDMwMDApO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gYXBwbHlSZXF1ZXN0RXJyb3IocmVmRWxlbWVudCwgZXJyb3JDb250YWluZXIsIGZpZWxkcykge1xyXG4gICAgcmVmRWxlbWVudC5jaGlsZE5vZGVzLmZvckVhY2goYyA9PiBjLmNoaWxkTm9kZXMuZm9yRWFjaChuID0+IG4uZGlzYWJsZWQgPSBmYWxzZSkpO1xyXG4gICAgcmVmRWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCd3b3JraW5nJyk7XHJcbiAgICByZWZFbGVtZW50LmNsYXNzTGlzdC5hZGQoJ2ZhaWxlZCcpO1xyXG4gICAgY29uc29sZS53YXJuKGVycm9yQ29udGFpbmVyKTtcclxuICAgIGlmIChlcnJvckNvbnRhaW5lci5tZXNzYWdlICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICBhbGVydChlcnJvckNvbnRhaW5lci5tZXNzYWdlKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgZm9yIChsZXQgZXJyb3Igb2YgT2JqZWN0LmtleXMoZXJyb3JDb250YWluZXIpKSB7XHJcbiAgICAgICAgICAgIGlmIChlcnJvci5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgYWxlcnQoZXJyb3JDb250YWluZXJbZXJyb3JdLmVycm9ycy5qb2luKCdcXG4nKSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBmaWVsZCA9IGZpZWxkc1tlcnJvcl07XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBtZXNzYWdlIG9mIGVycm9yQ29udGFpbmVyW2Vycm9yXS5lcnJvcnMpIHtcclxuICAgICAgICAgICAgICAgICAgICBmaWVsZC5hcHBlbmRDaGlsZChlbGVtZW50KCdwJywgbWVzc2FnZSkpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlQ2hlY2tib3gobmFtZSwgZGF0YSwgdGV4dCwgb25DaGFuZ2UsIGRlZmF1bHRWYWx1ZSA9IGZhbHNlKSB7XHJcbiAgICBjb25zdCBpZCA9ICdzZXMtJyArIG5hbWU7XHJcbiAgICBsZXQgdmFsdWUgPSByZWFkUHJldklucHV0KCk7XHJcbiAgICBkYXRhW25hbWVdID0gdmFsdWU7XHJcbiAgICBsZXQgZWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2lucHV0Jyk7XHJcbiAgICBlbGVtZW50LnR5cGUgPSAnY2hlY2tib3gnO1xyXG4gICAgZWxlbWVudC5pZCA9IGlkO1xyXG4gICAgZWxlbWVudC5uYW1lID0gbmFtZTtcclxuICAgIGxldCBsYWJlbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xhYmVsJyk7XHJcbiAgICBsYWJlbC5odG1sRm9yID0gaWQ7XHJcbiAgICBsYWJlbC50ZXh0Q29udGVudCA9IHRleHQ7XHJcblxyXG4gICAgLypcclxuICAgIGxldCBlbGVtZW50ID0gPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNsYXNzTmFtZT1cInNlcy1jaGVja1wiIGlkPXtpZH0gbmFtZT17bmFtZX0gLz47XHJcbiAgICBsZXQgbGFiZWwgPSA8bGFiZWwgZm9yPXtpZH0+e3RleHR9PC9sYWJlbD47XHJcbiAgICAqL1xyXG4gICAgZWxlbWVudC5jaGVja2VkID0gdmFsdWU7XHJcbiAgICBlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsIHRvZ2dsZSk7XHJcblxyXG4gICAgZnVuY3Rpb24gcmVhZFByZXZJbnB1dCgpIHtcclxuICAgICAgICBsZXQgcHJldklucHV0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaWQpO1xyXG4gICAgICAgIGlmIChwcmV2SW5wdXQpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHByZXZJbnB1dC5jaGVja2VkO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiBkZWZhdWx0VmFsdWU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIHRvZ2dsZShlKSB7XHJcbiAgICAgICAgdmFsdWUgPSBlLnRhcmdldC5jaGVja2VkO1xyXG4gICAgICAgIGRhdGFbbmFtZV0gPSB2YWx1ZTtcclxuICAgICAgICByZWRyYXcoKTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiByZWRyYXcoKSB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgb25DaGFuZ2UoKTtcclxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyLm1lc3NhZ2UpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBjaGVja2JveCA9IHtcclxuICAgICAgICBlbGVtZW50LFxyXG4gICAgICAgIGxhYmVsXHJcbiAgICB9O1xyXG5cclxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShjaGVja2JveCwgJ3ZhbHVlJywge1xyXG4gICAgICAgIGdldDogKCkgPT4gdmFsdWUsXHJcbiAgICAgICAgc2V0OiAobmV3VmFsdWUpID0+IHtcclxuICAgICAgICAgICAgdmFsdWUgPSBuZXdWYWx1ZTtcclxuICAgICAgICAgICAgZWxlbWVudC5jaGVja2VkID0gdmFsdWU7XHJcbiAgICAgICAgICAgIGRhdGFbbmFtZV0gPSB2YWx1ZTtcclxuICAgICAgICAgICAgcmVkcmF3KCk7XHJcbiAgICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIGNoZWNrYm94O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdGFibGUoZGF0YSwgbGF5b3V0KSB7XHJcbiAgICBjb25zdCB0aGVhZCA9IGVsZW1lbnQoJ3RoZWFkJywgZWxlbWVudCgndHInLCBsYXlvdXQubWFwKGggPT4gZWxlbWVudCgndGgnLCBoLmxhYmVsKSkpKTtcclxuICAgIGNvbnN0IHRib2R5ID0gZWxlbWVudCgndGJvZHknLCBkYXRhLm1hcChyID0+IGVsZW1lbnQoJ3RyJywgbGF5b3V0Lm1hcChoID0+IGVsZW1lbnQoJ3RkJywgcltoLm5hbWVdKSkpKSk7XHJcblxyXG4gICAgY29uc3QgdGFibGUgPSBlbGVtZW50KCd0YWJsZScsIFt0aGVhZCwgdGJvZHldKTtcclxuICAgIHRhYmxlLnRoZWFkID0gdGhlYWQ7XHJcbiAgICB0YWJsZS50Ym9keSA9IHRib2R5O1xyXG5cclxuICAgIHJldHVybiB0YWJsZTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIEF1dG9jb21wbGV0ZSh7IHZhbHVlcywgY3VycmVudCB9KSB7XHJcbiAgICBsZXQgYXV0b2NvbXBsZXRlID0gZWxlbWVudCgnZGl2JywgW1xyXG4gICAgICAgIGVsZW1lbnQoJ2lucHV0JywgdW5kZWZpbmVkLCB7IGNsYXNzTmFtZTogJ3Nlcy1zZWFyY2gtYXV0b2NvbXBsZXRlLWlucHV0JyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBlbGVtZW50KCd1bCcpLCB7IGNsYXNzTmFtZTogJ3Nlcy1zZWFyY2gtYXV0b2NvbXBsZXRlLXN1Z2dlc3Rpb25zJyB9KVxyXG4gICAgXSwgeyBjbGFzc05hbWU6ICdzZXMtc2VhcmNoLWF1dG9jb21wbGV0ZS1jb250YWluZXInIH0pO1xyXG5cclxuICAgIGNvbnN0IHN1Z2dlc3Rpb25zQ29udGFpbmVyID0gYXV0b2NvbXBsZXRlLnF1ZXJ5U2VsZWN0b3IoJy5zZXMtc2VhcmNoLWF1dG9jb21wbGV0ZS1zdWdnZXN0aW9ucycpO1xyXG4gICAgY29uc3QgaW5wdXQgPSBhdXRvY29tcGxldGUucXVlcnlTZWxlY3RvcignLnNlcy1zZWFyY2gtYXV0b2NvbXBsZXRlLWlucHV0Jyk7XHJcbiAgICBsZXQgc2VsZWN0ZWRJbmRleCA9IHVuZGVmaW5lZDtcclxuXHJcbiAgICBpZiAoY3VycmVudCAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICBpbnB1dC52YWx1ZSA9IGN1cnJlbnQ7XHJcbiAgICB9XHJcblxyXG4gICAgYXV0b2NvbXBsZXRlLmdldFZhbHVlID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHJldHVybiBpbnB1dC52YWx1ZTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBzZWFyY2hIYW5kbGVyKGUpIHtcclxuICAgICAgICBjb25zdCBpbnB1dFZhbCA9IGUuY3VycmVudFRhcmdldC52YWx1ZTtcclxuICAgICAgICBsZXQgcmVzdWx0cyA9IHZhbHVlcztcclxuICAgICAgICBpZiAoaW5wdXRWYWwubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICByZXN1bHRzID0gdmFsdWVzLmZpbHRlcih4ID0+IHgudG9Mb3dlckNhc2UoKS5pbmRleE9mKGlucHV0VmFsLnRvTG93ZXJDYXNlKCkpID4gLTEpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBzaG93U3VnZ2VzdGlvbnMocmVzdWx0cywgaW5wdXRWYWwpO1xyXG4gICAgICAgIGlmIChlLmtleUNvZGUgPT09IDM4IHx8IGUua2V5Q29kZSA9PT0gNDAgfHwgZS5rZXlDb2RlID09PSAxMykge1xyXG4gICAgICAgICAgICBzY3JvbGxSZXN1bHRzKGUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBzaG93U3VnZ2VzdGlvbnMocmVzdWx0cywgaW5wdXRWYWwpIHtcclxuICAgICAgICBsZXQgc3VnZ2VzdGlvbnMgPSBzdWdnZXN0aW9uc0NvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCd1bCcpO1xyXG4gICAgICAgIHJlcGxhY2VDb250ZW50cyhzdWdnZXN0aW9ucywgJycpO1xyXG4gICAgICAgIHN1Z2dlc3Rpb25zID0gc3VnZ2VzdGlvbnNDb250YWluZXIucXVlcnlTZWxlY3RvcigndWwnKTs7XHJcblxyXG4gICAgICAgIGlmIChyZXN1bHRzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCByZXN1bHRzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgaXRlbSA9IHJlc3VsdHNbaV07XHJcbiAgICAgICAgICAgICAgICBjb25zdCBtYXRjaCA9IGl0ZW0ubWF0Y2gobmV3IFJlZ0V4cChpbnB1dFZhbCwgJ2knKSk7XHJcbiAgICAgICAgICAgICAgICBpdGVtID0gaXRlbS5yZXBsYWNlKG1hdGNoWzBdLCBgPHN0cm9uZz4ke21hdGNoWzBdfTwvc3Ryb25nPmApO1xyXG4gICAgICAgICAgICAgICAgbGV0IG5ld0xpID0gZWxlbWVudCgnbGknLCBpdGVtLCB1bmRlZmluZWQsIHsgZm9yY2VUeXBlOiBcIkhUTUxcIiB9KTtcclxuICAgICAgICAgICAgICAgIHN1Z2dlc3Rpb25zLmFwcGVuZENoaWxkKG5ld0xpKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBzdWdnZXN0aW9ucy5jbGFzc0xpc3QuYWRkKCdoYXMtc3VnZ2VzdGlvbnMnKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBzdWdnZXN0aW9ucy5jbGFzc0xpc3QucmVtb3ZlKCdoYXMtc3VnZ2VzdGlvbnMnKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gdXNlU3VnZ2VzdGlvbihlKSB7XHJcbiAgICAgICAgaW5wdXQudmFsdWUgPSBlLnRhcmdldC50ZXh0Q29udGVudDtcclxuICAgICAgICBpbnB1dC5mb2N1cygpO1xyXG4gICAgICAgIGxldCBzdWdnZXN0aW9ucyA9IHN1Z2dlc3Rpb25zQ29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoJ3VsJyk7XHJcbiAgICAgICAgcmVwbGFjZUNvbnRlbnRzKHN1Z2dlc3Rpb25zLCAnJyk7XHJcbiAgICAgICAgc3VnZ2VzdGlvbnMgPSBzdWdnZXN0aW9uc0NvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCd1bCcpO1xyXG4gICAgICAgIHN1Z2dlc3Rpb25zLmNsYXNzTGlzdC5yZW1vdmUoJ2hhcy1zdWdnZXN0aW9ucycpO1xyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIHNjcm9sbFJlc3VsdHMoZSkge1xyXG4gICAgICAgIGxldCBhbGxTdWdnZXN0aW9ucyA9IFsuLi5zdWdnZXN0aW9uc0NvbnRhaW5lci5xdWVyeVNlbGVjdG9yQWxsKCd1bCBsaScpXTtcclxuICAgICAgICBsZXQgb2xkSW5kZXggPSB1bmRlZmluZWQ7XHJcbiAgICAgICAgbGV0IGluZGV4Q2hhbmdlID0gMTtcclxuXHJcbiAgICAgICAgLy8gZW50ZXJcclxuICAgICAgICBpZiAoZS5rZXlDb2RlID09PSAxMykge1xyXG4gICAgICAgICAgICBpbnB1dC52YWx1ZSA9IGFsbFN1Z2dlc3Rpb25zW3NlbGVjdGVkSW5kZXhdLnRleHRDb250ZW50O1xyXG4gICAgICAgICAgICBzZWxlY3RlZEluZGV4ID0gdW5kZWZpbmVkO1xyXG4gICAgICAgICAgICBsZXQgc3VnZ2VzdGlvbnMgPSBzdWdnZXN0aW9uc0NvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCd1bCcpO1xyXG4gICAgICAgICAgICBzdWdnZXN0aW9ucy5jbGFzc0xpc3QucmVtb3ZlKCdoYXMtc3VnZ2VzdGlvbnMnKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGUua2V5Q29kZSA9PT0gNDApIHtcclxuICAgICAgICAgICAgLy8gZG93biBhcnJvd1xyXG4gICAgICAgICAgICBpbmRleENoYW5nZSA9IDE7XHJcbiAgICAgICAgfSBlbHNlIGlmIChlLmtleUNvZGUgPT09IDM4KSB7XHJcbiAgICAgICAgICAgIC8vIHVwIGFycm93XHJcbiAgICAgICAgICAgIGluZGV4Q2hhbmdlID0gLTE7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoc2VsZWN0ZWRJbmRleCA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgc2VsZWN0ZWRJbmRleCA9IGluZGV4Q2hhbmdlID09PSAxID8gMCA6IGFsbFN1Z2dlc3Rpb25zLmxlbmd0aCAtIDE7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgb2xkSW5kZXggPSBzZWxlY3RlZEluZGV4O1xyXG4gICAgICAgICAgICBzZWxlY3RlZEluZGV4ID0gKChzZWxlY3RlZEluZGV4ICsgaW5kZXhDaGFuZ2UpICsgYWxsU3VnZ2VzdGlvbnMubGVuZ3RoKSAlIGFsbFN1Z2dlc3Rpb25zLmxlbmd0aDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChvbGRJbmRleCAhPT0gdW5kZWZpbmVkICYmIG9sZEluZGV4IDwgYWxsU3VnZ2VzdGlvbnMubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgIGFsbFN1Z2dlc3Rpb25zW29sZEluZGV4XS5jbGFzc0xpc3QucmVtb3ZlKCdzZWxlY3RlZCcpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgYWxsU3VnZ2VzdGlvbnNbc2VsZWN0ZWRJbmRleF0uY2xhc3NMaXN0LmFkZCgnc2VsZWN0ZWQnKTtcclxuICAgIH1cclxuXHJcbiAgICBpbnB1dC5hZGRFdmVudExpc3RlbmVyKCdrZXl1cCcsIHNlYXJjaEhhbmRsZXIpO1xyXG4gICAgc3VnZ2VzdGlvbnNDb250YWluZXIuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCB1c2VTdWdnZXN0aW9uKTtcclxuICAgIHJldHVybiBhdXRvY29tcGxldGU7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBDcmVhdGVzIGEgc3BhbiBlbGVtZW50IHRoYXQgcmVwcmVzZW50cyBhIGRvd25sb2FkIHByb2dyZXNzIGJhclxyXG4gKiBAcGFyYW0geyB7ZG93bmxvYWRGdW5jdGlvbjogKG9uUHJvZ3Jlc3M6IGltcG9ydCgnLi91dGlsLmpzJykuT25Qcm9ncmVzc0Z1bmN0aW9uKSwgcmV0dXJuRnVuY3Rpb246IGZ1bmN0aW9ufSB9IHNldHRpbmdzIENvbnRhaW5zIHRoZSBmdW5jdGlvbiB0aGF0IHdpbGwgZG93bmxvYWQgdGhlIHJlc291cmNlcywgd2hpY2ggd2lsbCBiZSBjYWxsZWQgd2l0aCBvblByb2dyZXNzXHJcbiAqIGFuZCB0aGUgcmV0dXJuRnVuY3Rpb24gd2hpY2ggd2lsbCBiZSBjYWxsZWQgd2l0aCB0aGUgcmVzdWx0cyBhZnRlciB0aGUgZG93bmxvYWQgZmluaXNoZXNcclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBEb3dubG9hZFByb2dyZXNzQmFyKHsgZG93bmxvYWRGdW5jdGlvbiwgcmV0dXJuRnVuY3Rpb24gfSkge1xyXG4gICAgY29uc3QgcGVyY2VudCA9IDxzcGFuPjAlPC9zcGFuPjtcclxuICAgIGNvbnN0IGJhciA9IDxzcGFuIHN0eWxlPXt7IHBhZGRpbmc6ICcwIDAuNWVtJywgZGlzcGxheTogJ2lubGluZS1ibG9jaycsIHdpZHRoOiAnMjUlJywgYmFja2dyb3VuZDogJ2xpbmVhci1ncmFkaWVudCh0byByaWdodCwgI2ZmYTAwMCAwJSwgI2VlZSAwKScgfX0+e3BlcmNlbnR9INCh0LLQsNC70Y/QvdC1PC9zcGFuPjtcclxuICAgIGRvd25sb2FkRnVuY3Rpb24ob25Qcm9ncmVzcykudGhlbihkYXRhID0+IHtcclxuICAgICAgICBpZiAocmV0dXJuRnVuY3Rpb24pIHtcclxuICAgICAgICAgICAgcmV0dXJuRnVuY3Rpb24oZGF0YSlcclxuICAgICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gYmFyO1xyXG5cclxuICAgIGZ1bmN0aW9uIG9uUHJvZ3Jlc3MoY29tcGxldGVkLCB0b3RhbCwgcmVzcG9uc2UsIGluZGV4KSB7XHJcbiAgICAgICAgY29uc3QgcHJvZ3Jlc3MgPSBNYXRoLmZsb29yKGNvbXBsZXRlZCAvIHRvdGFsICogMTAwKTtcclxuICAgICAgICBwZXJjZW50LnRleHRDb250ZW50ID0gcHJvZ3Jlc3MgKyAnJSc7XHJcbiAgICAgICAgYmFyLnN0eWxlLmJhY2tncm91bmQgPSBgbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZmZhMDAwICR7cHJvZ3Jlc3N9JSwgI2VlZSAwKWA7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IHtcclxuICAgIGVsZW1lbnRcclxufTsiLCIvKiBnbG9iYWxzIHhsc3gsIEpTWmlwICovXHJcblxyXG5pbXBvcnQgcGFyc2UgZnJvbSAnLi9wYXJzZSc7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaW1wb3J0UXVpekZyb21YbHN4KGJsb2IpIHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcclxuICAgICAgICByZWFkZXIub25sb2FkID0gZnVuY3Rpb24gKGUpIHtcclxuICAgICAgICAgICAgY29uc3QgZmlsZURhdGEgPSBlLnRhcmdldC5yZXN1bHQ7XHJcbiAgICAgICAgICAgIGNvbnN0IHdiID0geGxzeC5yZWFkKGZpbGVEYXRhLCB7XHJcbiAgICAgICAgICAgICAgICB0eXBlOiAnYmluYXJ5J1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgY29uc3QgZmlyc3RTaGVldCA9IHdiLlNoZWV0c1t3Yi5TaGVldE5hbWVzWzBdXTtcclxuICAgICAgICAgICAgY29uc3QgYXBpRGF0YSA9IHhsc3gudXRpbHNcclxuICAgICAgICAgICAgICAgIC5zaGVldF90b19qc29uKGZpcnN0U2hlZXQsIHsgaGVhZGVyOiAxIH0pXHJcbiAgICAgICAgICAgICAgICAuc2xpY2UoMSkgLy8gcmVtb3ZlIGZpcnN0IHJvd1xyXG4gICAgICAgICAgICAgICAgLnJlZHVjZSgoZGF0YSwgY3VycmVudFJvdykgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChjdXJyZW50Um93Lmxlbmd0aCAhPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjb3JyZWN0QW5zd2VySW5kZXggPSBjdXJyZW50Um93LnBvcCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBxdWVzdGlvbiA9IGN1cnJlbnRSb3dbMF07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGFsbEFuc3dlcnMgPSBjdXJyZW50Um93LnNsaWNlKDEpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjb3JyZWN0QW5zd2VyID0gY3VycmVudFJvd1tjb3JyZWN0QW5zd2VySW5kZXhdO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YVtxdWVzdGlvbl0gPSBhbGxBbnN3ZXJzLnJlZHVjZSgoYW5zd2VycywgYSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGEgIT0gdW5kZWZpbmVkICYmIGEudG9TdHJpbmcoKS50cmltKCkgIT09ICcnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5zd2Vyc1thXSA9IGEgPT09IGNvcnJlY3RBbnN3ZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGFuc3dlcnM7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sIHt9KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBkYXRhO1xyXG4gICAgICAgICAgICAgICAgfSwge30pO1xyXG5cclxuICAgICAgICAgICAgcmVzb2x2ZShhcGlEYXRhKTtcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICByZWFkZXIucmVhZEFzQmluYXJ5U3RyaW5nKGJsb2IpO1xyXG4gICAgfSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBpbXBvcnRGcm9tWGxzeChibG9iLCB1c2VDZWxsRGF0ZXMgPSBmYWxzZSkge1xyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xyXG4gICAgICAgIHJlYWRlci5vbmxvYWQgPSBmdW5jdGlvbiAoZSkge1xyXG4gICAgICAgICAgICBjb25zdCBmaWxlID0gZS50YXJnZXQucmVzdWx0O1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgY29uc3Qgd2IgPSB4bHN4LnJlYWQoZmlsZSwge1xyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6ICdiaW5hcnknLFxyXG4gICAgICAgICAgICAgICAgICAgIGNlbGxEYXRlczogdXNlQ2VsbERhdGVzXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGZpcnN0U2hlZXQgPSB3Yi5TaGVldHNbd2IuU2hlZXROYW1lc1swXV07XHJcbiAgICAgICAgICAgICAgICBjb25zdCBkYXRhID0geGxzeC51dGlscy5zaGVldF90b19qc29uKGZpcnN0U2hlZXQsIHsgaGVhZGVyOiAxIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgIHJlc29sdmUoZGF0YSk7XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ0Vycm9yIHBhcnNpbmcgWExTWCBmaWxlLCBtYWtlIHN1cmUgdGhlIGxpYnJhcnkgaXMgbG9hZGVkJyk7XHJcbiAgICAgICAgICAgICAgICByZWplY3QoZXJyKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgcmVhZGVyLm9uZXJyb3IgPSBmdW5jdGlvbiAoZSkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygnRXJyb3IgcmVhZGluZyBmaWxlJyk7XHJcbiAgICAgICAgICAgIHJlamVjdChlKTtcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICByZWFkZXIucmVhZEFzQmluYXJ5U3RyaW5nKGJsb2IpO1xyXG4gICAgfSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiB0b1hsc3hGaWxlKHRhYmxlLCBuYW1lID0gJ091dHB1dCcsIHdzX25hbWUpIHtcclxuICAgIGlmICh3c19uYW1lID09PSB1bmRlZmluZWQpIHtcclxuICAgICAgICB3c19uYW1lID0gbmFtZS5zbGljZSgwLCAzMSk7XHJcbiAgICB9XHJcbiAgICBjb25zdCB3YiA9IHhsc3gudXRpbHMuYm9va19uZXcoKSwgd3MgPSB4bHN4LnV0aWxzLmFvYV90b19zaGVldCh0YWJsZSk7XHJcbiAgICAvLyB3Yi5Xb3JrYm9vayA9IHsgVmlld3M6IFsnV2luZG93MiddIH07XHJcbiAgICB4bHN4LnV0aWxzLmJvb2tfYXBwZW5kX3NoZWV0KHdiLCB3cywgd3NfbmFtZSk7XHJcbiAgICBjb25zdCBkYXRhID0geGxzeC53cml0ZSh3Yiwge1xyXG4gICAgICAgIHR5cGU6ICdhcnJheScsXHJcbiAgICAgICAgYm9va1R5cGU6ICd4bHN4J1xyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgZmlsZSA9IG5ldyBGaWxlKFtkYXRhXSwgbmFtZSArICcueGxzeCcsIHsgdHlwZTogJ2FwcGxpY2F0aW9uL3ZuZC5vcGVueG1sZm9ybWF0cy1vZmZpY2Vkb2N1bWVudC5zcHJlYWRzaGVldG1sLnNoZWV0JyB9KTtcclxuXHJcbiAgICByZXR1cm4gZmlsZTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHRvTGVnYWN5WGxzRmlsZSh0YWJsZSwgbmFtZSA9ICdPdXRwdXQnLCB3c19uYW1lKSB7XHJcbiAgICBpZiAod3NfbmFtZSA9PT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgd3NfbmFtZSA9IG5hbWUuc2xpY2UoMCwgMzEpO1xyXG4gICAgfVxyXG4gICAgY29uc3Qgd2IgPSB4bHN4LnV0aWxzLmJvb2tfbmV3KCksIHdzID0geGxzeC51dGlscy5hb2FfdG9fc2hlZXQodGFibGUpO1xyXG4gICAgd2IuV29ya2Jvb2sgPSB7IFZpZXdzOiBbJ1dpbmRvdzInXSB9O1xyXG4gICAgeGxzeC51dGlscy5ib29rX2FwcGVuZF9zaGVldCh3Yiwgd3MsIHdzX25hbWUpO1xyXG4gICAgY29uc3QgZGF0YSA9IHhsc3gud3JpdGUod2IsIHtcclxuICAgICAgICB0eXBlOiAnYXJyYXknLFxyXG4gICAgICAgIGJvb2tUeXBlOiAnYmlmZjgnXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCBmaWxlID0gbmV3IEZpbGUoW2RhdGFdLCBuYW1lICsgJy54bHMnLCB7IHR5cGU6ICdhcHBsaWNhdGlvbi92bmQubXMtZXhjZWwnIH0pO1xyXG5cclxuICAgIHJldHVybiBmaWxlO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZXhwb3J0VG9YbHN4KHRhYmxlLCBuYW1lID0gJ091dHB1dCcsIHdzX25hbWUpIHtcclxuICAgIGNvbnN0IGZpbGVuYW1lID0gYCR7bmFtZX0ueGxzeGA7XHJcbiAgICBpZiAod3NfbmFtZSA9PT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgd3NfbmFtZSA9IG5hbWUuc2xpY2UoMCwgMzEpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFNoZWV0IG5hbWUgY2Fubm90IGNvbnRhaW46IFxcIC8gPyAqIFsgXVxyXG4gICAgY29uc3Qgc2hlZXRSZWdleCA9IC9bXFxbXFxdXFxcXFxcL1xcKl0vZ2k7XHJcbiAgICBpZiAoc2hlZXRSZWdleC50ZXN0KHdzX25hbWUpKSB7XHJcbiAgICAgICAgd3NfbmFtZSA9IHdzX25hbWUucmVwbGFjZShzaGVldFJlZ2V4LCAnLScpO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHdiID0geGxzeC51dGlscy5ib29rX25ldygpLCB3cyA9IHhsc3gudXRpbHMuYW9hX3RvX3NoZWV0KHRhYmxlKTtcclxuICAgIHhsc3gudXRpbHMuYm9va19hcHBlbmRfc2hlZXQod2IsIHdzLCB3c19uYW1lKTtcclxuICAgIHhsc3gud3JpdGVGaWxlKHdiLCBmaWxlbmFtZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBleHBvcnRQYXltZW50c1RvWGxzeChkYXRhLCB5ZWFyLCBtb250aCkge1xyXG4gICAgY29uc3QgZmlsZW5hbWUgPSBgUGF5bWVudHMtJHtwYXJzZS5tb250aE5hbWVbbW9udGhdfS0ke3llYXJ9Lnhsc3hgO1xyXG4gICAgY29uc3Qgd3NfbmFtZSA9IGBQYXltZW50cyAke3BhcnNlLm1vbnRoTmFtZVttb250aF19ICR7eWVhcn1gO1xyXG4gICAgY29uc3Qgd2IgPSB4bHN4LnV0aWxzLmJvb2tfbmV3KCksIHdzID0geGxzeC51dGlscy5hb2FfdG9fc2hlZXQoZGF0YSk7XHJcbiAgICB4bHN4LnV0aWxzLmJvb2tfYXBwZW5kX3NoZWV0KHdiLCB3cywgd3NfbmFtZSk7XHJcbiAgICB4bHN4LndyaXRlRmlsZSh3YiwgZmlsZW5hbWUpO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZXhwb3J0VG9Kc29uKGRhdGEsIG5hbWUgPSAnT3V0cHV0Jykge1xyXG4gICAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKFtkYXRhXSwgeyB0eXBlOiAnYXBwbGljYXRpb24vanNvbicgfSk7XHJcbiAgICBpZiAod2luZG93Lm5hdmlnYXRvci5tc1NhdmVPck9wZW5CbG9iKSB7XHJcbiAgICAgICAgd2luZG93Lm5hdmlnYXRvci5tc1NhdmVCbG9iKGJsb2IsIG5hbWUgKyAnLmpzb24nKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdmFyIGVsZW0gPSB3aW5kb3cuZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xyXG4gICAgICAgIGVsZW0uaHJlZiA9IHdpbmRvdy5VUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xyXG4gICAgICAgIGVsZW0uZG93bmxvYWQgPSBuYW1lICsgJy5qc29uJztcclxuICAgICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGVsZW0pO1xyXG4gICAgICAgIGVsZW0uY2xpY2soKTtcclxuICAgICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGVsZW0pO1xyXG4gICAgfVxyXG59XHJcblxyXG4vKipcclxuICogQHBhcmFtIHt7Zm9sZGVyOiBzdHJpbmcsIGZpbGVzOiBGaWxlW119W119IGZpbGVzIFxyXG4gKi9cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHppcEZpbGVzKGZpbGVzKSB7XHJcbiAgICBjb25zdCB6aXAgPSBuZXcgSlNaaXAoKTtcclxuICAgIGZvciAobGV0IGVudHJ5IG9mIGZpbGVzKSB7XHJcbiAgICAgICAgY29uc3QgY3VycmVudCA9IHppcC5mb2xkZXIoZW50cnkuZm9sZGVyKTtcclxuICAgICAgICBjdXJyZW50LmZpbGUoZW50cnkuZmlsZXMucGhvdG8ubmFtZSwgYXdhaXQgYmxvYlRvQmFzZTY0KGVudHJ5LmZpbGVzLnBob3RvLmZpbGUpLCB7IGJhc2U2NDogdHJ1ZSB9KTtcclxuICAgICAgICBjdXJyZW50LmZpbGUoZW50cnkuZmlsZXMubWVkaWNhbC5uYW1lLCBhd2FpdCBibG9iVG9CYXNlNjQoZW50cnkuZmlsZXMubWVkaWNhbC5maWxlKSwgeyBiYXNlNjQ6IHRydWUgfSk7XHJcbiAgICAgICAgY3VycmVudC5maWxlKGVudHJ5LmZpbGVzLmRpcGxvbWEubmFtZSwgYXdhaXQgYmxvYlRvQmFzZTY0KGVudHJ5LmZpbGVzLmRpcGxvbWEuZmlsZSksIHsgYmFzZTY0OiB0cnVlIH0pO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHppcC5nZW5lcmF0ZUFzeW5jKHsgdHlwZTogJ2Jsb2InIH0pO1xyXG5cclxuICAgIGZ1bmN0aW9uIGJsb2JUb0Jhc2U2NChibG9iKSB7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKHJlc29sdmUgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xyXG4gICAgICAgICAgICByZWFkZXIub25sb2FkID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgZGF0YVVybCA9IHJlYWRlci5yZXN1bHQ7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBiYXNlNjQgPSBkYXRhVXJsLnNwbGl0KCcsJylbMV07XHJcbiAgICAgICAgICAgICAgICByZXNvbHZlKGJhc2U2NCk7XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIHJlYWRlci5yZWFkQXNEYXRhVVJMKGJsb2IpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxufVxyXG5cclxuY29uc3QgbWltZXMgPSB7XHJcbiAgICAnYm1wJzogJ2ltYWdlL2JtcCcsXHJcbiAgICAnZ2lmJzogJ2ltYWdlL2dpZicsXHJcbiAgICAnanBlZyc6ICdpbWFnZS9qcGVnJyxcclxuICAgICdqcGcnOiAnaW1hZ2UvanBlZycsXHJcbiAgICAncG5nJzogJ2ltYWdlL3BuZycsXHJcbiAgICAncGRmJzogJ2FwcGxpY2F0aW9uL3BkZicsXHJcbiAgICAndGlmJzogJ2ltYWdlL3RpZmYnLFxyXG4gICAgJ3RpZmYnOiAnaW1hZ2UvdGlmZicsXHJcbiAgICAnd2VicCc6ICdpbWFnZS93ZWJwJyxcclxuICAgICd6aXAnOiAnYXBwbGljYXRpb24vemlwJyxcclxuICAgICc3eic6ICdhcHBsaWNhdGlvbi94LTd6LWNvbXByZXNzZWQnLFxyXG4gICAgJ3Rhcic6ICdhcHBsaWNhdGlvbi94LXRhcicsXHJcbiAgICAncmFyJzogJ2FwcGxpY2F0aW9uL3ZuZC5yYXInXHJcbn07XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0TWltZShleHRlbnNpb24pIHtcclxuICAgIGV4dGVuc2lvbiA9IGV4dGVuc2lvbi50b0xvY2FsZUxvd2VyQ2FzZSgpO1xyXG4gICAgcmV0dXJuIG1pbWVzW2V4dGVuc2lvbl0gfHwgJ2FwcGxpY2F0aW9uL29jdGV0LXN0cmVhbSc7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBvcGVuRmlsZShmaWxlLCBuYW1lID0gJ291dHB1dC50eHQnKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIHZhciBlbGVtID0gd2luZG93LmRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcclxuICAgICAgICBlbGVtLnRhcmdldCA9ICdfYmxhbmsnO1xyXG4gICAgICAgIGVsZW0uZG93bmxvYWQgPSBuYW1lO1xyXG4gICAgICAgIGNvbnN0IGhyZWYgPSB3aW5kb3cuVVJMLmNyZWF0ZU9iamVjdFVSTChmaWxlKTtcclxuICAgICAgICBlbGVtLmhyZWYgPSBocmVmO1xyXG4gICAgICAgIGVsZW0uY2xpY2soKTtcclxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IFVSTC5yZXZva2VPYmplY3RVUkwoaHJlZiksIDYwMDAwKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGRvd25sb2FkKGJsb2IsIG5hbWUgPSAnb3V0cHV0LnR4dCcpIHtcclxuICAgIGlmICh3aW5kb3cubmF2aWdhdG9yLm1zU2F2ZU9yT3BlbkJsb2IpIHtcclxuICAgICAgICB3aW5kb3cubmF2aWdhdG9yLm1zU2F2ZUJsb2IoYmxvYiwgbmFtZSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIHZhciBlbGVtID0gd2luZG93LmRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcclxuICAgICAgICBlbGVtLnRhcmdldCA9ICdfYmxhbmsnO1xyXG4gICAgICAgIGNvbnN0IGhyZWYgPSB3aW5kb3cuVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTtcclxuICAgICAgICBlbGVtLmhyZWYgPSBocmVmO1xyXG4gICAgICAgIGVsZW0uZG93bmxvYWQgPSBuYW1lO1xyXG4gICAgICAgIGVsZW0uY2xpY2soKTtcclxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IFVSTC5yZXZva2VPYmplY3RVUkwoaHJlZiksIDYwMDAwKTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyb3NzQnJvd3NlckZpbGVVcGxvYWQoYXBpQ2FsbCwgZmlsZSkge1xyXG4gICAgaWYgKCEhd2luZG93LmNocm9tZSkge1xyXG4gICAgICAgIGNvbnN0IGZpbGVVcmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGZpbGUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGFwaUNhbGwoeyBmaWxlVXJsLCBuYW1lOiBmaWxlLm5hbWUgfSk7XHJcbiAgICAgICAgVVJMLnJldm9rZU9iamVjdFVSTChmaWxlVXJsKTtcclxuICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gYXdhaXQgYXBpQ2FsbCh7IGZpbGUgfSk7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRTdWJzaXRlKCkge1xyXG4gICAgc3dpdGNoICh3aW5kb3cubG9jYXRpb24uaG9zdC5zdWJzdHIoMCwgNykpIHtcclxuICAgICAgICBjYXNlICdkaWdpdGFsJzpcclxuICAgICAgICAgICAgcmV0dXJuICdkaWdpdGFsJztcclxuICAgICAgICBjYXNlICdjcmVhdGl2JzpcclxuICAgICAgICAgICAgcmV0dXJuICdjcmVhdGl2ZSc7XHJcbiAgICAgICAgY2FzZSAncGxhdGZvcic6XHJcbiAgICAgICAgICAgIHJldHVybiAncGxhdGZvcm0nO1xyXG4gICAgICAgIGNhc2UgJ2FpLnNvZnQnOlxyXG4gICAgICAgICAgICByZXR1cm4gJ2FpJztcclxuICAgICAgICBjYXNlICdmaW5hbmNlJzpcclxuICAgICAgICAgICAgcmV0dXJuICdmaW5hbmNlYWNhZGVteSc7XHJcbiAgICAgICAgY2FzZSAnZGV2LmRpZyc6XHJcbiAgICAgICAgICAgIHJldHVybiAnZGV2ZGlnaXRhbCc7XHJcbiAgICAgICAgY2FzZSAnZGV2LnNvZic6XHJcbiAgICAgICAgICAgIHJldHVybiAnZGV2c29mdHVuaSc7XHJcbiAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgcmV0dXJuICdwcm9ncmFtbWluZyc7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBoYXNDUE9BY2Nlc3MoKSB7XHJcbiAgICByZXR1cm4gWydkaWdpdGFsJywgJ2NyZWF0aXZlJywgJ3Byb2dyYW1taW5nJywgJ2RldmRpZ2l0YWwnLCAnZGV2c29mdHVuaSddLmluY2x1ZGVzKGdldFN1YnNpdGUoKSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBpc0FkbWluKCkge1xyXG4gICAgY29uc3QgZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJ2FbaHJlZj1cIi9hZG1pbmlzdHJhdGlvbi9uYXZpZ2F0aW9uXCIgaV0nKTtcclxuICAgIGlmIChlLmxlbmd0aCA+IDApIHsgcmV0dXJuIHRydWU7IH1cclxuICAgIGVsc2UgeyByZXR1cm4gZmFsc2U7IH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHNlcmlhbGl6ZUNhbGxzKGZuQXJyYXksIGRlbGF5KSB7XHJcbiAgICBjb25zdCBjYWxsQXJyYXkgPSBbXTtcclxuXHJcbiAgICBpZiAoZGVsYXkgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZm5BcnJheS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBjb25zdCBoYW5kbGVyID0gKHJlcywgcmVqKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KGFzeW5jICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBmbkFycmF5W2ldKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcyhyZXN1bHQpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZWooZXJyKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9LCBpICogZGVsYXkpO1xyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBjb25zdCBwciA9IG5ldyBQcm9taXNlKGhhbmRsZXIpO1xyXG5cclxuICAgICAgICAgICAgY2FsbEFycmF5LnB1c2gocHIpO1xyXG4gICAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBmbkFycmF5Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGhhbmRsZXIgPSAocmVzLCByZWopID0+IHtcclxuICAgICAgICAgICAgICAgIGlmIChpID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNhbGxBcnJheVtpIC0gMV0uZmluYWxseShhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBmbkFycmF5W2ldKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXMocmVzdWx0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWooZXJyKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBmbkFycmF5W2ldKCkudGhlbihyZXMpLmNhdGNoKHJlaik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIGNvbnN0IHByID0gbmV3IFByb21pc2UoaGFuZGxlcik7XHJcblxyXG4gICAgICAgICAgICBjYWxsQXJyYXkucHVzaChwcik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBjYWxsQXJyYXk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB3aXRoUHJvZ3Jlc3MoY2FsbEFycmF5LCBvbkNoYW5nZSwgZGVsYXkgPSAxMCkge1xyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICAvLyBGYWlsc2F2ZSBmb3IgZW1wdHkgY2FsbEFycmF5XHJcbiAgICAgICAgaWYgKGNhbGxBcnJheS5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgICAgICBvbkNoYW5nZSh1bmRlZmluZWQsIDAsIDEsIDEpO1xyXG4gICAgICAgICAgICByZXNvbHZlKFtdKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCByZXNvbHZlZCA9IDA7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBbXTtcclxuICAgICAgICBjYWxsTmV4dCgwKTtcclxuXHJcbiAgICAgICAgZnVuY3Rpb24gY2FsbE5leHQoaSkge1xyXG4gICAgICAgICAgICBpZiAoaSA+PSBjYWxsQXJyYXkubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBjYWxsQXJyYXlbaV1cclxuICAgICAgICAgICAgICAgICAgICAudGhlbihyZXMgPT4gb25SZXNvbHZlKHJlcywgaSkpXHJcbiAgICAgICAgICAgICAgICAgICAgLmNhdGNoKG9uRXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiBjYWxsTmV4dChpICsgMSksIGRlbGF5KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZnVuY3Rpb24gb25SZXNvbHZlKHJlcywgaW5kZXgpIHtcclxuICAgICAgICAgICAgcmVzb2x2ZWQrKztcclxuICAgICAgICAgICAgaWYgKG9uQ2hhbmdlKSB7XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZShyZXMsIGluZGV4LCByZXNvbHZlZCwgY2FsbEFycmF5Lmxlbmd0aCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmVzcG9uc2VbaW5kZXhdID0gcmVzO1xyXG4gICAgICAgICAgICBpZiAocmVzb2x2ZWQgPT09IGNhbGxBcnJheS5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgIHJlc29sdmUocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBmdW5jdGlvbiBvbkVycm9yKGUpIHtcclxuICAgICAgICAgICAgcmVqZWN0KGUpO1xyXG4gICAgICAgIH1cclxuICAgIH0pO1xyXG59XHJcblxyXG4vKipcclxuICogQHR5cGVkZWYgeyhjb21wbGV0ZWQ6IG51bWJlciwgdG90YWw6IG51bWJlciwgcmVzcG9uc2UsIGluZGV4OiBudW1iZXIpID0+IHZvaWR9IE9uUHJvZ3Jlc3NGdW5jdGlvblxyXG4gKi9cclxuXHJcbi8qKlxyXG4gKiBAdHlwZWRlZiB7KCkgPT4gUHJvbWlzZX0gQXN5bmNGdW5jdGlvblxyXG4gKi9cclxuXHJcbi8qKlxyXG4gKiBJbml0aWF0ZSByZW1vdGUgY2FsbHMgYXQgaW50ZXJ2YWxzXHJcbiAqIEBwYXJhbSB7QXJyYXk8QXN5bmNGdW5jdGlvbj59IGZuQXJyYXkgXHJcbiAqIEBwYXJhbSB7T25Qcm9ncmVzc0Z1bmN0aW9ufSBvblByb2dyZXNzIFxyXG4gKiBAcGFyYW0ge251bWJlcn0gW2RlbGF5PTEwXVxyXG4gKiBAcmV0dXJucyBcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkaXN0cmlidXRlKGZuQXJyYXksIG9uUHJvZ3Jlc3MsIGRlbGF5ID0gMTApIHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgY29uc3QgdG90YWwgPSBmbkFycmF5Lmxlbmd0aDtcclxuICAgICAgICBsZXQgY29tcGxldGVkID0gMDtcclxuICAgICAgICBsZXQgcmVzb2x2ZWQgPSAwO1xyXG5cclxuICAgICAgICAvLyBGYWlsc2F2ZSBmb3IgZW1wdHkgZm5BcnJheVxyXG4gICAgICAgIGlmICh0b3RhbCA9PSAwKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2Ygb25Qcm9ncmVzcyA9PSAnZnVuY3Rpb24nKSB7XHJcbiAgICAgICAgICAgICAgICBvblByb2dyZXNzKHVuZGVmaW5lZCwgMCwgMSwgMSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmVzb2x2ZShbXSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCBjYWxscyA9IGZuQXJyYXkubWFwKChmbiwgaSkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBjYWxsID0ge1xyXG4gICAgICAgICAgICAgICAgZm4sXHJcbiAgICAgICAgICAgICAgICBzZW50OiBmYWxzZSxcclxuICAgICAgICAgICAgICAgIGNhbmNlbGxlZDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICByZXNwb25zZTogdW5kZWZpbmVkLFxyXG4gICAgICAgICAgICAgICAgdGltZXI6IG51bGwsXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIGNhbGwub25DYWxsID0gb25DYWxsLmJpbmQoY2FsbCwgaSk7XHJcbiAgICAgICAgICAgIGNhbGwuY2FuY2VsID0gb25DYW5jZWwuYmluZChjYWxsKTtcclxuICAgICAgICAgICAgY2FsbC50aW1lciA9IHNldFRpbWVvdXQoY2FsbC5vbkNhbGwsIGkgKiBkZWxheSk7XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gY2FsbDtcclxuICAgICAgICB9KTtcclxuICAgICAgICBjYWxscy5mb3JFYWNoKChjLCBpKSA9PiBjLm5leHQgPSBjYWxsc1tpICsgMV0pO1xyXG5cclxuICAgICAgICBhc3luYyBmdW5jdGlvbiBvbkNhbGwoaSkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5zZW50ID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICBjbGVhclRpbWVvdXQodGhpcy50aW1lcik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMuY2FuY2VsbGVkID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNlbnQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBwcm9taXNlID0gdGhpcy5mbigpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmVzcG9uc2UgPSBhd2FpdCBwcm9taXNlO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm9taXNlLl9jYWNoZUhpdCAmJiB0aGlzLm5leHQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5uZXh0Lm9uQ2FsbCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICByZXNvbHZlZCsrO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNhbmNlbGxlZCA9PSBmYWxzZSAmJiByZXNvbHZlZCA9PT0gdG90YWwpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShjYWxscy5tYXAoYyA9PiBjLnJlc3BvbnNlKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgb25FcnJvcihlcnIpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNvbXBsZXRlZCsrO1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIG9uUHJvZ3Jlc3MgPT0gJ2Z1bmN0aW9uJykge1xyXG4gICAgICAgICAgICAgICAgb25Qcm9ncmVzcyhjb21wbGV0ZWQsIHRvdGFsLCB0aGlzLnJlc3BvbnNlLCBpKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZnVuY3Rpb24gb25DYW5jZWwoKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNhbmNlbGxlZCA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jYW5jZWxsZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuc2VudCA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aGlzLnRpbWVyKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm9uQ2FsbCgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBmdW5jdGlvbiBvbkVycm9yKGUpIHtcclxuICAgICAgICAgICAgY2FsbHMuZm9yRWFjaChjID0+IGMuY2FuY2VsKCkpO1xyXG4gICAgICAgICAgICBpZiAoZSBpbnN0YW5jZW9mIEVycm9yKSB7XHJcbiAgICAgICAgICAgICAgICBlLl9yZXNwb25zZXMgPSBjYWxscy5tYXAoYyA9PiBjLnJlc3BvbnNlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZWplY3QoZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBhc3NlcnRUZW1wbGF0ZSh0ZW1wbGF0ZSwgdGFyZ2V0LCBib3R0b20gPSBmYWxzZSkge1xyXG4gICAgaWYgKHRlbXBsYXRlLkRhdGEgIT09IHVuZGVmaW5lZCAmJiB0ZW1wbGF0ZS5Ub3RhbCAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgdGVtcGxhdGUgPSB0ZW1wbGF0ZS5EYXRhO1xyXG4gICAgICAgIHRhcmdldCA9IHRhcmdldC5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChBcnJheS5pc0FycmF5KHRlbXBsYXRlKSkge1xyXG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KHRhcmdldCkpIHtcclxuICAgICAgICAgICAgaWYgKGJvdHRvbSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgYXNzZXJ0VGVtcGxhdGUodGVtcGxhdGVbMF0sIHRhcmdldFswXSwgdHJ1ZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdUYXJnZXQgdHlwZSBtaXNtYXRjaCcpO1xyXG4gICAgICAgIH1cclxuICAgIH0gZWxzZSBpZiAodHlwZW9mIHRlbXBsYXRlID09PSAnb2JqZWN0Jykge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGFyZ2V0ID09PSAnb2JqZWN0Jykge1xyXG4gICAgICAgICAgICBjb25zdCBtb2RlbCA9IE9iamVjdC5rZXlzKHRlbXBsYXRlKTtcclxuICAgICAgICAgICAgZm9yIChsZXQgcHJvcCBvZiBtb2RlbCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRhcmdldC5oYXNPd25Qcm9wZXJ0eShwcm9wKSA9PT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdNaXNzaW5nIHByb3BlcnR5IG9uIHRhcmdldDogJyArIHByb3ApO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignVGFyZ2V0IHR5cGUgbWlzbWF0Y2gnKTtcclxuICAgICAgICB9XHJcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiB0ZW1wbGF0ZSAhPT0gdHlwZW9mIHRhcmdldCkge1xyXG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1RhcmdldCB0eXBlIG1pc21hdGNoJyk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0TG9jYWxlKCkge1xyXG4gICAgcmV0dXJuICdiZyc7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVUaHJvdHRsZWRFeGVjdXRvcihjYWxsYmFjaywgZGVsYXkpIHtcclxuICAgIGxldCB0aW1lciA9IG51bGw7XHJcblxyXG4gICAgcmV0dXJuIGZ1bmN0aW9uICguLi5wYXJhbXMpIHtcclxuICAgICAgICBjbGVhcigpO1xyXG4gICAgICAgIHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgIGNsZWFyKCk7XHJcbiAgICAgICAgICAgIGNhbGxiYWNrKC4uLnBhcmFtcyk7XHJcbiAgICAgICAgfSwgZGVsYXkpO1xyXG4gICAgfTtcclxuXHJcbiAgICBmdW5jdGlvbiBjbGVhcigpIHtcclxuICAgICAgICBpZiAodGltZXIgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVyKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBpY29uQXNzZXQobmFtZSkge1xyXG4gICAgcmV0dXJuIGJyb3dzZXIucnVudGltZS5nZXRVUkwoYGljb25zLyR7bmFtZX0ucG5nYCk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBlc2NhcGVIVE1MKHN0cikge1xyXG4gICAgcmV0dXJuIHN0ci5yZXBsYWNlKC9bJjw+XS9nLFxyXG4gICAgICAgIHRhZyA9PiAoe1xyXG4gICAgICAgICAgICAnJic6ICcmYW1wOycsXHJcbiAgICAgICAgICAgICc8JzogJyZsdDsnLFxyXG4gICAgICAgICAgICAnPic6ICcmZ3Q7J1xyXG4gICAgICAgIH1bdGFnXSkpXHJcbn07XHJcblxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGdldEZ1bmRhbWVudGFsTGV2ZWxJZHMoYXBwbmFtZSkge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICAncHJvZ3JhbW1pbmcnOiBbXHJcbiAgICAgICAgICAgIDE5LFxyXG4gICAgICAgICAgICA0NCxcclxuICAgICAgICAgICAgNTcsXHJcbiAgICAgICAgICAgIDcwLFxyXG4gICAgICAgICAgICAxMDZcclxuICAgICAgICBdLFxyXG4gICAgICAgICdkaWdpdGFsJzogW1xyXG4gICAgICAgICAgICA2LFxyXG4gICAgICAgICAgICA3LFxyXG4gICAgICAgICAgICA4LFxyXG4gICAgICAgICAgICAyMyxcclxuICAgICAgICAgICAgMjQsXHJcbiAgICAgICAgICAgIDI1LFxyXG4gICAgICAgICAgICAyNyxcclxuICAgICAgICAgICAgMzMsXHJcbiAgICAgICAgICAgIDM1LFxyXG4gICAgICAgICAgICA0MFxyXG4gICAgICAgIF0sXHJcbiAgICAgICAgJ2NyZWF0aXZlJzogW1xyXG4gICAgICAgICAgICAyMyxcclxuICAgICAgICAgICAgMjQsXHJcbiAgICAgICAgICAgIDQyLFxyXG4gICAgICAgICAgICA1MlxyXG4gICAgICAgIF1cclxuICAgIH1bYXBwbmFtZV07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRQcm9mZXNzaW9uSW5zdGFuY2VJZHMoYXBwbmFtZSkge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICAvLyBDb21tZW50ZWQgYXJlIGZvciBRQVxyXG4gICAgICAgICdwcm9ncmFtbWluZyc6IFtcclxuICAgICAgICAgICAgMTAwNyxcclxuICAgICAgICAgICAgMTAwOSxcclxuICAgICAgICAgICAgMTAxMCxcclxuICAgICAgICAgICAgMTAxMSxcclxuICAgICAgICAgICAgMTAxMixcclxuICAgICAgICAgICAgMTAxMyxcclxuICAgICAgICAgICAgMTAxNCxcclxuICAgICAgICAgICAgMTAxNSxcclxuICAgICAgICAgICAgMTAxNixcclxuICAgICAgICAgICAgMTAxNyxcclxuICAgICAgICAgICAgMTAxOCxcclxuICAgICAgICAgICAgMTAyMCxcclxuICAgICAgICAgICAgMTAyMixcclxuICAgICAgICAgICAgMTAyMyxcclxuICAgICAgICAgICAgMTAyNCxcclxuICAgICAgICAgICAgMTAyNSxcclxuICAgICAgICAgICAgMTAyNixcclxuICAgICAgICAgICAgLy8gMTAyOCxcclxuICAgICAgICAgICAgMTAyOSxcclxuICAgICAgICAgICAgMTAzMCxcclxuICAgICAgICAgICAgMTAzMSxcclxuICAgICAgICAgICAgMTAzMixcclxuICAgICAgICAgICAgMTAzMyxcclxuICAgICAgICAgICAgMTAzNCxcclxuICAgICAgICAgICAgMTAzNSxcclxuICAgICAgICAgICAgMTAzNixcclxuICAgICAgICAgICAgMTAzNyxcclxuICAgICAgICAgICAgMTAzOCxcclxuICAgICAgICAgICAgMTAzOSxcclxuICAgICAgICAgICAgMTA0MCxcclxuICAgICAgICAgICAgMTA0MSxcclxuICAgICAgICAgICAgMTA0MixcclxuICAgICAgICAgICAgMTA0MyxcclxuICAgICAgICAgICAgMTA0NCxcclxuICAgICAgICAgICAgMTA0NSxcclxuICAgICAgICAgICAgMTA0NixcclxuICAgICAgICAgICAgMTA0NyxcclxuICAgICAgICAgICAgMTA0OCxcclxuICAgICAgICAgICAgMTA0OSxcclxuICAgICAgICAgICAgMTA1MCxcclxuICAgICAgICAgICAgMTA1MSxcclxuICAgICAgICAgICAgMTA1MixcclxuICAgICAgICAgICAgMTA1MyxcclxuICAgICAgICAgICAgMTA1NCxcclxuICAgICAgICAgICAgMTA1NSxcclxuICAgICAgICAgICAgMTA1NixcclxuICAgICAgICAgICAgMTA1NyxcclxuICAgICAgICAgICAgMTA1OCxcclxuICAgICAgICAgICAgMTA1OSxcclxuICAgICAgICAgICAgMTA2MCxcclxuICAgICAgICAgICAgMTA2MSxcclxuICAgICAgICAgICAgMTA2MixcclxuICAgICAgICAgICAgMTA2MyxcclxuICAgICAgICAgICAgMTA2NCxcclxuICAgICAgICAgICAgMTA2NSxcclxuICAgICAgICAgICAgMTA2NixcclxuICAgICAgICAgICAgLy8gMTA2NyxcclxuICAgICAgICAgICAgLy8gMTA2OCxcclxuICAgICAgICAgICAgLy8gMTA2OSxcclxuICAgICAgICAgICAgMTA3MCxcclxuICAgICAgICAgICAgMTA3MSxcclxuICAgICAgICAgICAgMTA3MixcclxuICAgICAgICAgICAgMTA3MyxcclxuICAgICAgICAgICAgMTA3NCxcclxuICAgICAgICAgICAgMTA3NSxcclxuICAgICAgICAgICAgMTA3NixcclxuICAgICAgICAgICAgMTA3NyxcclxuICAgICAgICAgICAgMTA3OFxyXG4gICAgICAgIF0sXHJcbiAgICAgICAgJ2RpZ2l0YWwnOiBbXHJcbiAgICAgICAgICAgIDEsXHJcbiAgICAgICAgICAgIDMsXHJcbiAgICAgICAgICAgIDQsXHJcbiAgICAgICAgICAgIDUsXHJcbiAgICAgICAgICAgIDYsXHJcbiAgICAgICAgICAgIDcsXHJcbiAgICAgICAgICAgIDgsXHJcbiAgICAgICAgICAgIDlcclxuICAgICAgICBdLFxyXG4gICAgICAgICdjcmVhdGl2ZSc6IFtcclxuICAgICAgICAgICAgMSxcclxuICAgICAgICAgICAgMyxcclxuICAgICAgICAgICAgNCxcclxuICAgICAgICAgICAgNVxyXG4gICAgICAgIF0sXHJcbiAgICAgICAgJ2RldmRpZ2l0YWwnOiBbXHJcbiAgICAgICAgICAgIDEsXHJcbiAgICAgICAgICAgIDMsXHJcbiAgICAgICAgICAgIDQsXHJcbiAgICAgICAgICAgIDUsXHJcbiAgICAgICAgICAgIDYsXHJcbiAgICAgICAgICAgIDcsXHJcbiAgICAgICAgICAgIDgsXHJcbiAgICAgICAgICAgIDlcclxuICAgICAgICBdLFxyXG4gICAgICAgICdhaSc6W11cclxuICAgIH1bYXBwbmFtZV07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRFeGNsdWRlZE1vZHVsZXMoYXBwbmFtZSkge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICAncHJvZ3JhbW1pbmcnOiBbXHJcbiAgICAgICAgICAgIDJcclxuICAgICAgICBdXHJcbiAgICB9W2FwcG5hbWVdO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0RXhjbHVkZWRNb2R1bGVJbnN0YW5jZXMoYXBwbmFtZSkge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICAnZGlnaXRhbCc6IFtcclxuICAgICAgICAgICAgNSxcclxuICAgICAgICAgICAgNTBcclxuICAgICAgICBdLFxyXG4gICAgICAgICdjcmVhdGl2ZSc6IFtcclxuICAgICAgICAgICAgMSxcclxuICAgICAgICAgICAgMTQsXHJcbiAgICAgICAgICAgIDI4LFxyXG4gICAgICAgICAgICA0NlxyXG4gICAgICAgIF0sXHJcbiAgICAgICAgJ2RldmRpZ2l0YWwnOiBbXHJcbiAgICAgICAgICAgIDUsXHJcbiAgICAgICAgICAgIDUwXHJcbiAgICAgICAgXSxcclxuICAgIH1bYXBwbmFtZV07XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBAZGVzY3JpcHRpb24gUm91bmRzIHVwIGEgbnVtYmVyIHVwIHRvIHNwZWNpZmllZCBudW1iZXIgb2YgZGVjaW1hbCBwbGFjZXMgdXNpbmcgYSBzcGVjaWZpZWQgbnVtYmVyIG9mIGRlY2ltYWwgcGxhY2VzIGFzIHByZWNpc2lvbi5cclxuICogVGhpcyBhbGxvd3MgY29ycmVjdCByb3VuZGluZyBvZiBwcm9ibGVtYXRpYyBmbG9hdGluZyBwb2ludCBudW1iZXJzIGxpa2UgXCI1NS4wMDAwMDAwMDAwMDAwMVwiIG9yIFwiMC40NjAwMDAwMDAwMDAwMDFcIlxyXG4gKiBAcGFyYW0ge051bWJlcn0gbnVtYmVyIFRoZSBudW1iZXIgdG8gcm91bmQgdXBcclxuICogQHBhcmFtIHtOdW1iZXJ9IGRlY2ltYWxQbGFjZXNUb1JvdW5kVG8gVGhlIG51bWJlciBvZiBkZWNpbWFsIHBsYWNlcyB0byByb3VuZCB0b1xyXG4gKiBAcGFyYW0ge051bWJlcn0gZGVjaW1hbFBsYWNlc1ByZWNpc2lvbiBUaGUgbnVtYmVyIG9mIGRlY2ltYWwgcGxhY2VzIHRoYXQgc2hvdWxkIGJlIGNvbnNpZGVyZWQgZm9yIHRoZSByb3VuZGluZy4gU2hvdWxkIGJlIGxhcmdlciB0aGFuIGRlY2ltYWxQbGFjZXNUb1JvdW5kVG9cclxuICogQHJldHVybnMgVGhlIHJvdW5kZWQgbnVtYmVyXHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gcm91bmRVcFdpdGhQcmVjaXNpb24obnVtYmVyLCBkZWNpbWFsUGxhY2VzVG9Sb3VuZFRvLCBkZWNpbWFsUGxhY2VzUHJlY2lzaW9uKSB7XHJcbiAgICBpZiAoZGVjaW1hbFBsYWNlc1ByZWNpc2lvbiA8PSBkZWNpbWFsUGxhY2VzVG9Sb3VuZFRvKSB7XHJcbiAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ2RlY2ltYWxQbGFjZXNQcmVjaXNpb24gc2hvdWxkIGJlIGxhcmdlciB0aGFuIGRlY2ltYWxQbGFjZXNUb1JvdW5kVG8nKTtcclxuICAgIH1cclxuXHJcbiAgICBsZXQgcHJlY2lzaW9uVmFsdWUgPSAxMCAqKiBkZWNpbWFsUGxhY2VzUHJlY2lzaW9uO1xyXG4gICAgbGV0IHJvdW5kaW5nVmFsdWUgPSAxMCAqKiBkZWNpbWFsUGxhY2VzVG9Sb3VuZFRvO1xyXG4gICAgbGV0IHJvdW5kaW5nVmFsdWVCaWdJbnQgPSBCaWdJbnQocm91bmRpbmdWYWx1ZSk7XHJcbiAgICBsZXQgcHJlY2lzaW9uRGlmZmVyZW5jZVZhbHVlID0gQmlnSW50KHByZWNpc2lvblZhbHVlIC8gcm91bmRpbmdWYWx1ZSk7XHJcblxyXG4gICAgbGV0IGJpZ0ludCA9IEJpZ0ludChNYXRoLnRydW5jKG51bWJlciAqIHByZWNpc2lvblZhbHVlKSk7XHJcbiAgICBsZXQgcm91bmRlZFBsYWNlc051bWJlclBhcnQgPSBiaWdJbnQgLyBwcmVjaXNpb25EaWZmZXJlbmNlVmFsdWU7XHJcblxyXG4gICAgbGV0IHByZWNpc2lvbkRpZmZlcmVuY2VMZWZ0b3ZlciA9IGJpZ0ludCAlIHByZWNpc2lvbkRpZmZlcmVuY2VWYWx1ZTtcclxuICAgIHJvdW5kZWRQbGFjZXNOdW1iZXJQYXJ0ICs9IHByZWNpc2lvbkRpZmZlcmVuY2VMZWZ0b3ZlciA+IDAgPyAxbiA6IDBuO1xyXG5cclxuICAgIGxldCBudW1iZXJQYXJ0ID0gcm91bmRlZFBsYWNlc051bWJlclBhcnQgLyByb3VuZGluZ1ZhbHVlQmlnSW50O1xyXG4gICAgbGV0IGRlY2ltYWxQYXJ0ID0gcm91bmRlZFBsYWNlc051bWJlclBhcnQgJSByb3VuZGluZ1ZhbHVlQmlnSW50O1xyXG5cclxuICAgIGxldCByb3VuZGVkTnVtID0gTnVtYmVyKGAke251bWJlclBhcnR9LiR7ZGVjaW1hbFBhcnQudG9TdHJpbmcoKS5wYWRTdGFydChkZWNpbWFsUGxhY2VzVG9Sb3VuZFRvLCAnMCcpfWApO1xyXG4gICAgcmV0dXJuIHJvdW5kZWROdW07XHJcbn0iLCIvLyBUaGUgbW9kdWxlIGNhY2hlXG52YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307XG5cbi8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG5mdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuXHR2YXIgY2FjaGVkTW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0aWYgKGNhY2hlZE1vZHVsZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0cmV0dXJuIGNhY2hlZE1vZHVsZS5leHBvcnRzO1xuXHR9XG5cdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG5cdHZhciBtb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdID0ge1xuXHRcdC8vIG5vIG1vZHVsZS5pZCBuZWVkZWRcblx0XHQvLyBubyBtb2R1bGUubG9hZGVkIG5lZWRlZFxuXHRcdGV4cG9ydHM6IHt9XG5cdH07XG5cblx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG5cdF9fd2VicGFja19tb2R1bGVzX19bbW9kdWxlSWRdKG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG5cdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG5cdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbn1cblxuIiwiLy8gZGVmaW5lIGdldHRlciBmdW5jdGlvbnMgZm9yIGhhcm1vbnkgZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5kID0gKGV4cG9ydHMsIGRlZmluaXRpb24pID0+IHtcblx0Zm9yKHZhciBrZXkgaW4gZGVmaW5pdGlvbikge1xuXHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhkZWZpbml0aW9uLCBrZXkpICYmICFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywga2V5KSkge1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIGtleSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGRlZmluaXRpb25ba2V5XSB9KTtcblx0XHR9XG5cdH1cbn07IiwiX193ZWJwYWNrX3JlcXVpcmVfXy5vID0gKG9iaiwgcHJvcCkgPT4gKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIHByb3ApKSIsIi8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uciA9IChleHBvcnRzKSA9PiB7XG5cdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuXHR9XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG59OyIsImltcG9ydCB0ZW1wbGF0ZSBmcm9tICcuLi91dGlsL3RlbXBsYXRlJztcclxuaW1wb3J0IHsgZ2V0U3Vic2l0ZSB9IGZyb20gJy4uL3V0aWwvdXRpbCc7XHJcblxyXG5jb25zdCB0YWJJbmRleGVzID0ge1xyXG4gICAgdHJhaW5pbmdzOiB7XHJcbiAgICAgICAgcHJvZ3JhbW1pbmc6IDMsXHJcbiAgICAgICAgZGlnaXRhbDogNCxcclxuICAgICAgICBjcmVhdGl2ZTogNCxcclxuICAgICAgICBhaTogNCxcclxuICAgICAgICBmaW5hbmNlYWNhZGVteTogNCxcclxuICAgICAgICBkZXZkaWdpdGFsOiA0XHJcbiAgICB9LFxyXG4gICAgc3RhdHM6IHtcclxuICAgICAgICBwcm9ncmFtbWluZzogMTQsXHJcbiAgICAgICAgZGlnaXRhbDogMTAsXHJcbiAgICAgICAgY3JlYXRpdmU6IDEwLFxyXG4gICAgICAgIGFpOiAxMCxcclxuICAgICAgICBmaW5hbmNlYWNhZGVteTogMTEsXHJcbiAgICAgICAgZGV2ZGlnaXRhbDogMTBcclxuICAgIH0sXHJcbiAgICBxdWl6OiB7XHJcbiAgICAgICAgcHJvZ3JhbW1pbmc6IDEzXHJcbiAgICB9LFxyXG4gICAgc3RyZWFtOiB7XHJcbiAgICAgICAgcHJvZ3JhbW1pbmc6IDEsXHJcbiAgICAgICAgZGlnaXRhbDogMyxcclxuICAgICAgICBjcmVhdGl2ZTogMyxcclxuICAgICAgICBhaTogMyxcclxuICAgICAgICBmaW5hbmNlYWNhZGVteTogMyxcclxuICAgICAgICBkZXZkaWdpdGFsOiAzXHJcbiAgICB9XHJcbn07XHJcblxyXG5pbnNlcnRNZW51cygpO1xyXG5cclxuZnVuY3Rpb24gaW5zZXJ0TWVudXMoKSB7XHJcbiAgICBjb25zdCBzdWJzaXRlID0gZ2V0U3Vic2l0ZSgpO1xyXG4gICAgY29uc3QgbWVudXMgPSBbXTtcclxuICAgIHN3aXRjaCAoc3Vic2l0ZSkge1xyXG4gICAgICAgIGNhc2UgJ3Byb2dyYW1taW5nJzpcclxuICAgICAgICAgICAgbWVudXMucHVzaCh7IGluZGV4OiB0YWJJbmRleGVzLnRyYWluaW5nc1tzdWJzaXRlXSwgbmFtZTogJ0NvdXJzZSBNYW5hZ2VyJywgdXJsOiAnL3Nlcy9jb3Vyc2UnIH0pO1xyXG4gICAgICAgICAgICBtZW51cy5wdXNoKHsgaW5kZXg6IHRhYkluZGV4ZXMuc3RhdHNbc3Vic2l0ZV0sIG5hbWU6ICdTdXJ2ZXkgQWdncmVnYXRlJywgdXJsOiAnL3Nlcy9zdXJ2ZXlzJyB9KTtcclxuICAgICAgICAgICAgbWVudXMucHVzaCh7IGluZGV4OiB0YWJJbmRleGVzLnN0YXRzW3N1YnNpdGVdLCBuYW1lOiAnU2Vhc29uIFN0YXRzJywgdXJsOiAnL3Nlcy9zdGF0cycgfSk7XHJcbiAgICAgICAgICAgIG1lbnVzLnB1c2goeyBpbmRleDogdGFiSW5kZXhlcy5xdWl6W3N1YnNpdGVdLCBuYW1lOiAnUXVpeiBNYW5hZ2VtZW50JywgdXJsOiAnL3Nlcy9xdWl6JyB9KTtcclxuICAgICAgICAgICAgbWVudXMucHVzaCh7IGluZGV4OiB0YWJJbmRleGVzLnN0cmVhbVtzdWJzaXRlXSwgbmFtZTogJ1N0cmVhbSBEYXNoYm9hcmQnLCB1cmw6ICcvc2VzL3N0cmVhbScgfSk7XHJcbiAgICAgICAgICAgIG1lbnVzLnB1c2goeyBpbmRleDogdGFiSW5kZXhlcy50cmFpbmluZ3Nbc3Vic2l0ZV0sIG5hbWU6ICdUcmFpbmluZ3MgT3ZlcnZpZXcnLCB1cmw6ICcvc2VzL292ZXJ2aWV3JyB9KTtcclxuICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgY2FzZSAnZGlnaXRhbCc6XHJcbiAgICAgICAgY2FzZSAnY3JlYXRpdmUnOlxyXG4gICAgICAgIGNhc2UgJ2RldmRpZ2l0YWwnOlxyXG4gICAgICAgIGNhc2UgJ2FpJzpcclxuICAgICAgICAgICAgbWVudXMucHVzaCh7IGluZGV4OiB0YWJJbmRleGVzLnRyYWluaW5nc1tzdWJzaXRlXSwgbmFtZTogJ0NvdXJzZSBNYW5hZ2VyJywgdXJsOiAnL3Nlcy9jb3Vyc2UnIH0pO1xyXG4gICAgICAgICAgICBtZW51cy5wdXNoKHsgaW5kZXg6IHRhYkluZGV4ZXMuc3RhdHNbc3Vic2l0ZV0sIG5hbWU6ICdTdXJ2ZXkgQWdncmVnYXRlJywgdXJsOiAnL3Nlcy9zdXJ2ZXlzJyB9KTtcclxuICAgICAgICAgICAgbWVudXMucHVzaCh7IGluZGV4OiB0YWJJbmRleGVzLnN0YXRzW3N1YnNpdGVdLCBuYW1lOiAnU2Vhc29uIFN0YXRzJywgdXJsOiAnL3Nlcy9zdGF0cycgfSk7XHJcbiAgICAgICAgICAgIG1lbnVzLnB1c2goeyBpbmRleDogdGFiSW5kZXhlcy5zdHJlYW1bc3Vic2l0ZV0sIG5hbWU6ICdTdHJlYW0gRGFzaGJvYXJkJywgdXJsOiAnL3Nlcy9zdHJlYW0nIH0pO1xyXG4gICAgICAgICAgICBtZW51cy5wdXNoKHsgaW5kZXg6IHRhYkluZGV4ZXMudHJhaW5pbmdzW3N1YnNpdGVdLCBuYW1lOiAnVHJhaW5pbmdzIE92ZXJ2aWV3JywgdXJsOiAnL3Nlcy9vdmVydmlldycgfSk7XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgJ2ZpbmFuY2VhY2FkZW15JzpcclxuICAgICAgICAgICAgbWVudXMucHVzaCh7IGluZGV4OiB0YWJJbmRleGVzLnRyYWluaW5nc1tzdWJzaXRlXSwgbmFtZTogJ0NvdXJzZSBNYW5hZ2VyJywgdXJsOiAnL3Nlcy9jb3Vyc2UnIH0pO1xyXG4gICAgICAgICAgICBtZW51cy5wdXNoKHsgaW5kZXg6IHRhYkluZGV4ZXMuc3RhdHNbc3Vic2l0ZV0sIG5hbWU6ICdTdXJ2ZXkgQWdncmVnYXRlJywgdXJsOiAnL3Nlcy9zdXJ2ZXlzJyB9KTtcclxuICAgICAgICAgICAgbWVudXMucHVzaCh7IGluZGV4OiB0YWJJbmRleGVzLnN0cmVhbVtzdWJzaXRlXSwgbmFtZTogJ1N0cmVhbSBEYXNoYm9hcmQnLCB1cmw6ICcvc2VzL3N0cmVhbScgfSk7XHJcbiAgICAgICAgICAgIG1lbnVzLnB1c2goeyBpbmRleDogdGFiSW5kZXhlcy50cmFpbmluZ3Nbc3Vic2l0ZV0sIG5hbWU6ICdUcmFpbmluZ3MgT3ZlcnZpZXcnLCB1cmw6ICcvc2VzL292ZXJ2aWV3JyB9KTtcclxuICAgICAgICAgICAgYnJlYWs7XHJcbiAgICB9XHJcbiAgICBtZW51cy5mb3JFYWNoKG0gPT4gaW5zZXJ0TWVudUl0ZW0obS5pbmRleCwgbS5uYW1lLCBtLnVybCwgJ2ljb25zL2ljb240OC5wbmcnKSk7XHJcbn1cclxuXHJcblxyXG5mdW5jdGlvbiBpbnNlcnRNZW51SXRlbSh0YWJJbmRleCwgbGFiZWwsIGhyZWYsIGljb25QYXRoKSB7XHJcbiAgICBjb25zdCBpY29uVVJMID0gYnJvd3Nlci5ydW50aW1lLmdldFVSTChpY29uUGF0aCk7XHJcblxyXG4gICAgY29uc3QgY29udGFpbmVyID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI0FkbWluaXN0cmF0aW9uTmF2aWdhdGlvbi0nICsgdGFiSW5kZXgpLmNoaWxkcmVuWzBdO1xyXG4gICAgY29uc3Qgcm93ID0gZ2V0T3JDcmVhdGVSb3coY29udGFpbmVyKTtcclxuXHJcbiAgICBjb25zdCBjb2wgPSB0ZW1wbGF0ZS5lbGVtZW50KCdkaXYnLCBudWxsLCB7XHJcbiAgICAgICAgY2xhc3NMaXN0OiBnZXRTdHlsZSgpXHJcbiAgICB9KTtcclxuICAgIGNvbnN0IGFuY2hvciA9IHRlbXBsYXRlLmVsZW1lbnQoJ2EnLCBbXHJcbiAgICAgICAgdGVtcGxhdGUuZWxlbWVudCgnaW1nJywgbnVsbCwge1xyXG4gICAgICAgICAgICB0aXRsZTogbGFiZWwsXHJcbiAgICAgICAgICAgIHNyYzogaWNvblVSTCxcclxuICAgICAgICAgICAgYWx0OiBsYWJlbCxcclxuICAgICAgICAgICAgY2xhc3NMaXN0OiAnYm90dG9tLWJ1ZmZlcidcclxuICAgICAgICB9KSxcclxuICAgICAgICB0ZW1wbGF0ZS5lbGVtZW50KCdkaXYnLCBsYWJlbCwge1xyXG4gICAgICAgICAgICBjbGFzc0xpc3Q6ICdib3R0b20tYnVmZmVyJ1xyXG4gICAgICAgIH0pXHJcbiAgICBdLCB7XHJcbiAgICAgICAgaHJlZlxyXG4gICAgfSk7XHJcblxyXG4gICAgY29sLmFwcGVuZChhbmNob3IpO1xyXG4gICAgcm93LmFwcGVuZChjb2wpO1xyXG5cclxuXHJcbiAgICBmdW5jdGlvbiBnZXRPckNyZWF0ZVJvdyhjb250YWluZXIpIHtcclxuICAgICAgICBjb25zdCBsYXN0Um93ID0gWy4uLmNvbnRhaW5lci5xdWVyeVNlbGVjdG9yQWxsKCcucm93LmJvdHRvbS1idWZmZXInKV0ucG9wKCk7XHJcbiAgICAgICAgY29uc3QgY29scyA9IGxhc3RSb3cucXVlcnlTZWxlY3RvckFsbCgnLmNvbC1tZC0zJyk7XHJcbiAgICAgICAgaWYgKGNvbHMubGVuZ3RoIDwgNCkge1xyXG4gICAgICAgICAgICByZXR1cm4gbGFzdFJvdztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBjb25zdCByb3cgPSB0ZW1wbGF0ZS5lbGVtZW50KCdkaXYnLCBudWxsLCB7XHJcbiAgICAgICAgICAgICAgICBjbGFzc0xpc3Q6ICdyb3cgbm8tbWFyZ2luLW9mZnNldCB0ZXh0LWNlbnRlciBib3R0b20tYnVmZmVyJ1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgY29udGFpbmVyLmFwcGVuZENoaWxkKHJvdyk7XHJcbiAgICAgICAgICAgIHJldHVybiByb3c7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRTdHlsZSgpIHtcclxuICAgIHN3aXRjaCAoZ2V0U3Vic2l0ZSgpKSB7XHJcbiAgICAgICAgY2FzZSAncHJvZ3JhbW1pbmcnOlxyXG4gICAgICAgICAgICByZXR1cm4gJ2NvbC1tZC0zJztcclxuICAgICAgICBjYXNlICdkaWdpdGFsJzpcclxuICAgICAgICBjYXNlICdjcmVhdGl2ZSc6XHJcbiAgICAgICAgY2FzZSAncGxhdGZvcm0nOlxyXG4gICAgICAgIGNhc2UgJ2RldmRpZ2l0YWwnOlxyXG4gICAgICAgIGNhc2UgJ2FpJzogXHJcbiAgICAgICAgY2FzZSAnZmluYW5jZWFjYWRlbXknOlxyXG4gICAgICAgICAgICByZXR1cm4gJ2NvbC1tZC0zIG5vLXBhZGRpbmcnO1xyXG4gICAgfVxyXG59Il0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9