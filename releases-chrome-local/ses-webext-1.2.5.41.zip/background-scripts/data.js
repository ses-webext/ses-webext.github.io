/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!*********************************!*\
  !*** ./src/data-source/data.js ***!
  \*********************************/
browser.runtime.onConnect.addListener(connected);

function connected(p) {
  if (p.name !== 'ses-data-port') return;
  p.onMessage.addListener(onMessage);

  async function onMessage(m) {
    if (m.set) {
      let storageObj = {
        [m.set]: {
          when: Date.now(),
          data: m.data
        }
      };
      await browser.storage.local.set(storageObj); // console.log('Stored: ' + m.set);
      // console.dir(storageObj);
    } else if (m.get) {
      const entry = await browser.storage.local.get(m.get);
      const storedData = entry[m.get];
      const response = {
        _uuid: m._uuid,
        data: storedData ? storedData.data : undefined,
        when: storedData ? storedData.when : undefined
      }; // console.log('Get: ' + m.get);
      // console.dir(response);
      // console.dir(await browser.storage.local.get(null));

      p.postMessage(response);
    } else if (m.clear) {
      console.info('Clearing cache for ' + m.clear);
      await browser.storage.local.remove(m.clear);
    }
  }
}

let heartbeatInterval;

async function runHeartbeat() {
  await browser.storage.local.set({
    'datasource-heartbeat': new Date().getTime()
  });
}

async function startHeartbeat() {
  // Run the heartbeat once at service worker startup.
  runHeartbeat().then(() => {
    heartbeatInterval = setInterval(runHeartbeat, 20 * 1000);
  });
}

async function stopHeartbeat() {
  clearInterval(heartbeatInterval);
}

browser.runtime.onSuspend.addListener(stopHeartbeat);
startHeartbeat();
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9kZXYvL2JhY2tncm91bmQtc2NyaXB0cy9kYXRhLmpzIiwibWFwcGluZ3MiOiI7Ozs7O0FBQUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBREE7QUFNQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFIQTtBQU1BO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBR0E7O0FBRUE7QUFDQTtBQUFBO0FBQUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0EiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL2RhdGEtc291cmNlL2RhdGEuanMiXSwic291cmNlc0NvbnRlbnQiOlsiYnJvd3Nlci5ydW50aW1lLm9uQ29ubmVjdC5hZGRMaXN0ZW5lcihjb25uZWN0ZWQpO1xyXG5cclxuZnVuY3Rpb24gY29ubmVjdGVkKHApIHtcclxuICAgIGlmIChwLm5hbWUgIT09ICdzZXMtZGF0YS1wb3J0JykgcmV0dXJuO1xyXG4gICAgcC5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIob25NZXNzYWdlKTtcclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBvbk1lc3NhZ2UobSkge1xyXG4gICAgICAgIGlmIChtLnNldCkge1xyXG4gICAgICAgICAgICBsZXQgc3RvcmFnZU9iaiA9IHtcclxuICAgICAgICAgICAgICAgIFttLnNldF06IHtcclxuICAgICAgICAgICAgICAgICAgICB3aGVuOiBEYXRlLm5vdygpLFxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGE6IG0uZGF0YVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoc3RvcmFnZU9iaik7XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCdTdG9yZWQ6ICcgKyBtLnNldCk7XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUuZGlyKHN0b3JhZ2VPYmopO1xyXG4gICAgICAgIH0gZWxzZSBpZiAobS5nZXQpIHtcclxuICAgICAgICAgICAgY29uc3QgZW50cnkgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KG0uZ2V0KTtcclxuICAgICAgICAgICAgY29uc3Qgc3RvcmVkRGF0YSA9IGVudHJ5W20uZ2V0XTtcclxuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSB7XHJcbiAgICAgICAgICAgICAgICBfdXVpZDogbS5fdXVpZCxcclxuICAgICAgICAgICAgICAgIGRhdGE6IHN0b3JlZERhdGEgPyBzdG9yZWREYXRhLmRhdGEgOiB1bmRlZmluZWQsXHJcbiAgICAgICAgICAgICAgICB3aGVuOiBzdG9yZWREYXRhID8gc3RvcmVkRGF0YS53aGVuIDogdW5kZWZpbmVkXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCdHZXQ6ICcgKyBtLmdldCk7XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUuZGlyKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgLy8gY29uc29sZS5kaXIoYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChudWxsKSk7XHJcbiAgICAgICAgICAgIHAucG9zdE1lc3NhZ2UocmVzcG9uc2UpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAobS5jbGVhcikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmluZm8oJ0NsZWFyaW5nIGNhY2hlIGZvciAnICsgbS5jbGVhcik7XHJcbiAgICAgICAgICAgIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5yZW1vdmUobS5jbGVhcik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5cclxubGV0IGhlYXJ0YmVhdEludGVydmFsO1xyXG5cclxuYXN5bmMgZnVuY3Rpb24gcnVuSGVhcnRiZWF0KCkge1xyXG4gICAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7ICdkYXRhc291cmNlLWhlYXJ0YmVhdCc6IG5ldyBEYXRlKCkuZ2V0VGltZSgpIH0pO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBzdGFydEhlYXJ0YmVhdCgpIHtcclxuICAgIC8vIFJ1biB0aGUgaGVhcnRiZWF0IG9uY2UgYXQgc2VydmljZSB3b3JrZXIgc3RhcnR1cC5cclxuICAgIHJ1bkhlYXJ0YmVhdCgpLnRoZW4oKCkgPT4ge1xyXG4gICAgICAgIGhlYXJ0YmVhdEludGVydmFsID0gc2V0SW50ZXJ2YWwocnVuSGVhcnRiZWF0LCAyMCAqIDEwMDApO1xyXG4gICAgfSk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHN0b3BIZWFydGJlYXQoKSB7XHJcbiAgICBjbGVhckludGVydmFsKGhlYXJ0YmVhdEludGVydmFsKTtcclxufVxyXG5cclxuYnJvd3Nlci5ydW50aW1lLm9uU3VzcGVuZC5hZGRMaXN0ZW5lcihzdG9wSGVhcnRiZWF0KTtcclxuc3RhcnRIZWFydGJlYXQoKTsiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=