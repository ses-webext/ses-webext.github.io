/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/util/parse.js":
/*!***************************!*\
  !*** ./src/util/parse.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dateDiff": () => (/* binding */ dateDiff),
/* harmony export */   "dateDiffToDays": () => (/* binding */ dateDiffToDays),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "formatDate": () => (/* binding */ formatDate),
/* harmony export */   "formatLocaleDate": () => (/* binding */ formatLocaleDate),
/* harmony export */   "formatLocaleWeekday": () => (/* binding */ formatLocaleWeekday),
/* harmony export */   "formatTime": () => (/* binding */ formatTime),
/* harmony export */   "getDateIndex": () => (/* binding */ getDateIndex),
/* harmony export */   "getMonday": () => (/* binding */ getMonday),
/* harmony export */   "getOffsetByDays": () => (/* binding */ getOffsetByDays),
/* harmony export */   "getSunday": () => (/* binding */ getSunday),
/* harmony export */   "hasValue": () => (/* binding */ hasValue),
/* harmony export */   "htmlToText": () => (/* binding */ htmlToText),
/* harmony export */   "instanceMetaFromHref": () => (/* binding */ instanceMetaFromHref),
/* harmony export */   "isLastDay": () => (/* binding */ isLastDay),
/* harmony export */   "isLastWeek": () => (/* binding */ isLastWeek),
/* harmony export */   "localeMonthName": () => (/* binding */ localeMonthName),
/* harmony export */   "monthName": () => (/* binding */ monthName),
/* harmony export */   "normalizeDateTime": () => (/* binding */ normalizeDateTime),
/* harmony export */   "offsetByDays": () => (/* binding */ offsetByDays),
/* harmony export */   "paymentsToMatrix": () => (/* binding */ paymentsToMatrix),
/* harmony export */   "prettyJSON": () => (/* binding */ prettyJSON),
/* harmony export */   "queryString": () => (/* binding */ queryString),
/* harmony export */   "sumArrayMax": () => (/* binding */ sumArrayMax),
/* harmony export */   "toAssocArray": () => (/* binding */ toAssocArray),
/* harmony export */   "toCustomAssocArray": () => (/* binding */ toCustomAssocArray),
/* harmony export */   "uuid": () => (/* binding */ uuid),
/* harmony export */   "valueOrEmpty": () => (/* binding */ valueOrEmpty)
/* harmony export */ });
function queryString(query) {
  if (!query) {
    return null;
  }

  return query.split('?')[1].split('&').map(a => a.split('=')).reduce((a, c) => {
    a[c[0]] = c[1];
    return a;
  }, {});
}
/**
 * Calculate number of days passing between two dates
 * @param {Date} a Starting date
 * @param {Date} b Ending date
 * @returns {number} Number of days
 */


function dateDiff(a, b) {
  if (a.getFullYear() == b.getFullYear() && a.getMonth() == b.getMonth() && a.getDate() == b.getDate()) {
    return 0;
  } else {
    return b - a > 0 ? Math.ceil((b - a) / 86400000) : Math.floor((b - a) / 86400000);
  }
}

function dateDiffToDays(days) {
  if (days == 0) {
    return 'Today';
  } else {
    if (days <= 0) {
      return `In ${-days} day${days == -1 ? '' : 's'}`;
    } else {
      return `${days} day${days == 1 ? '' : 's'} ago`;
    }
  }
}
/**
 * Is the date in the last day of a month
 * @param {Date} date
 * @returns {boolean}
 */


function isLastDay(date) {
  const nextDay = new Date(date);
  nextDay.setDate(nextDay.getDate() + 1);
  return date.getMonth() != nextDay.getMonth();
}
/**
 * Is the date in the last week of a month
 * @param {Date} date
 * @returns {boolean}
 */


function isLastWeek(date) {
  const nextWeek = new Date(date);
  nextWeek.setDate(nextWeek.getDate() + 7);
  return date.getMonth() != nextWeek.getMonth();
}

function formatDate(date) {
  const asString = date.toLocaleDateString('en-US', {
    month: 'short',
    year: 'numeric'
  });
  return `${date.getDate()} ${asString}`;
}

function formatTime(date) {
  return date.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: 'numeric',
    // hour12: false,
    hourCycle: 'h23'
  });
}

function formatLocaleDate(date) {
  const day = date.getDate();
  const month = ['януари', 'февруари', 'март', 'април', 'май', 'юни', 'юли', 'август', 'септември', 'октомври', 'ноември', 'декември'][date.getMonth()];
  return `${day} ${month}`;
}

function formatLocaleWeekday(day, getAdj) {
  const weekday = ['неделя', 'понеделник', 'вторник', 'сряда', 'четвъртък', 'петък', 'събота'][day];

  if (getAdj) {
    return [weekday, ['всяка', 'всеки', 'всеки', 'всяка', 'всеки', 'всеки', 'всяка'][day]];
  }

  return weekday;
}
/**
 * Get a new date offset by the specified number of days
 * @param {Date} date Base date
 * @param {number} days How many days to offset
 * @returns {Date}
 */


function getOffsetByDays(date, days) {
  const result = new Date(date);
  result.setUTCDate(result.getUTCDate() + days);
  return result;
}
/**
 * Offset the given date in place by the specified number of days
 * @param {Date} date Base date
 * @param {number} days How many days to offset
 */

function offsetByDays(date, days) {
  date.setUTCDate(date.getUTCDate() + days);
}
/**
 * Create date index as string
 * @param {Date|string} date Base date
 * @returns {string}
 */

function getDateIndex(date) {
  if (typeof date == 'string') {
    date = new Date(date);
  }

  return date.toISOString().slice(0, 10);
}

function prettyJSON(obj) {
  return JSON.stringify(obj, null, 2).replace(/ /gmi, '&nbsp;').replace(/\n/gmi, '<br>');
}

function getMonday(date) {
  const monday = new Date(`${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()} 12:00:00`);
  monday.setDate(monday.getDate() - (monday.getDay() + 6) % 7);
  return monday;
}

function getSunday(date) {
  const sunday = new Date(`${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()} 23:59:59`);
  sunday.setDate(sunday.getDate() + (7 - sunday.getDay()) % 7);
  return sunday;
}

const monthName = {
  1: 'January',
  2: 'February',
  3: 'March',
  4: 'April',
  5: 'May',
  6: 'June',
  7: 'July',
  8: 'August',
  9: 'September',
  10: 'October',
  11: 'November',
  12: 'December'
};
const localeMonthName = {
  1: 'януари',
  2: 'февруари',
  3: 'март',
  4: 'април',
  5: 'май',
  6: 'юни',
  7: 'юли',
  8: 'август',
  9: 'септември',
  10: 'октомври',
  11: 'ноември',
  12: 'декември'
};

function toAssocArray(p, c, i, a) {
  p[c.Id] = c;
  return p;
}

function toCustomAssocArray(indexName, overwrite = false) {
  return (p, c, i, a) => {
    if (p[c[indexName]] !== undefined && overwrite == false) {
      if (Array.isArray(p[c[indexName]])) {
        p[c[indexName]].push(c);
      } else {
        p[c[indexName]] = [p[c[indexName]], c];
      }
    } else {
      p[c[indexName]] = c;
    }

    return p;
  };
}
/**
 * @param {Array<SUPayment>} data 
 * @returns {Array<PaymentViewModel>}
 */

function paymentsToMatrix(data) {
  const template = ['Id', 'PaymentNumber', 'ModuleNameEn', 'PaymentPackagesAsString', 'PaidForUserName', 'Price', 'EducationalForm', 'PaymentDateTime'];
  const parsed = data.map(e => {
    e.EducationalForm = e.EducationalForm == 1 ? 'online' : 'onsite';
    const entry = [];

    for (let prop of template) {
      if (prop === 'PaymentDateTime') {
        entry.push(new Date(e[prop]));
      } else {
        entry.push(e[prop]);
      }
    }

    return entry;
  });
  return [template, ...parsed];
}

function uuid() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    let r = Math.random() * 16 | 0,
        v = c == 'x' ? r : r & 0x3 | 0x8;
    return v.toString(16);
  });
}
function normalizeDateTime(datetime) {
  if (!datetime) {
    return '';
  } else if (datetime.toString().includes('Date(')) {
    const match = /Date\((.+)\)/.exec(datetime);

    if (match !== null) {
      const d = new Date(Number(match[1]));
      return `${('0000' + d.getFullYear()).slice(-4)}-${pt(d.getMonth() + 1)}-${pt(d.getDate())}T${pt(d.getHours())}:${pt(d.getMinutes())}`;
    } else {
      return datetime;
    }
  } else {
    return datetime;
  }
}

function pt(s) {
  return `0${s}`.slice(-2);
}

function htmlToText(html) {
  const div = document.createElement('div');
  div.innerHTML = html;
  return div.textContent;
}

function instanceMetaFromHref(href) {
  const instanceMeta = queryString(href);

  instanceMeta.InstanceRefType = (() => {
    switch (instanceMeta.type) {
      case 'course':
        return 'main';

      case 'fast-track':
        return 'open';

      case 'general-course-instance':
        return 'general';
    }
  })();

  return instanceMeta;
}
function hasValue(value) {
  return value !== null && value !== undefined && value !== '';
}
function valueOrEmpty(value, alt = '') {
  if (value === null || value === undefined || value === '') {
    return alt;
  } else {
    return value;
  }
}
function sumArrayMax(arr) {
  if (arr[0].length == 0 && arr[1].length == 0) {
    return null;
  }

  let result = 0;

  if (arr[0].length > 0) {
    result += Math.max(...arr[0]);
  }

  if (arr[1].length > 0) {
    result += Math.max(...arr[1]);
  }

  return result;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  queryString,
  dateDiff,
  dateDiffToDays,
  isLastDay,
  isLastWeek,
  formatDate,
  formatTime,
  formatLocaleDate,
  formatLocaleWeekday,
  prettyJSON,
  getMonday,
  getSunday,
  monthName,
  localeMonthName,
  toAssocArray,
  paymentsToMatrix,
  htmlToText
});


/***/ }),

/***/ "./src/util/router.js":
/*!****************************!*\
  !*** ./src/util/router.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Link": () => (/* binding */ Link),
/* harmony export */   "back": () => (/* binding */ back),
/* harmony export */   "checkActiveNav": () => (/* binding */ checkActiveNav),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "redirect": () => (/* binding */ redirect)
/* harmony export */ });
/* harmony import */ var _parse__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parse */ "./src/util/parse.js");

function Link({
  href,
  to,
  nav,
  partial,
  req,
  children,
  ...props
}) {
  try {
    const element = document.createElement('a');

    if (href !== undefined) {
      element.setAttribute('href', href);
      element.addEventListener('click', e => handler(e, element));
    }

    for (let prop of Object.keys(props)) {
      element[prop] = props[prop];
    }

    if (nav) {
      element.classList.add('ses-nav');
      const hrefTokens = _parse__WEBPACK_IMPORTED_MODULE_0__["default"].queryString(element.href);

      const matcher = nav => matchRoute(hrefTokens, nav);

      element.checkActiveNav = () => {
        if (window.location.search.split('?')[1] === element.href.split('?')[1]) {
          return element.classList.add('active');
        } else if (partial) {
          if (activeNav.some(matcher)) {
            if (req === undefined) {
              return element.classList.add('active');
            } else if (activeNav.some(nav => matchRoute(req, nav))) {
              return element.classList.add('active');
            }
          }
        }

        element.classList.remove('active');
      };

      element.checkActiveNav();
    }

    appendAll(children, element);
    return element;
  } catch (err) {
    console.error(err.message);
  }

  function handler(e, element) {
    e.preventDefault();
    const title = document.title;
    window.history.pushState({}, title, href);

    if (to !== undefined) {
      if (nav) {
        checkActiveNav();
      }

      to();
    } else {
      trigger();
    }
  }

  function appendAll(children, element) {
    for (let child of children) {
      if (Array.isArray(child)) {
        appendAll(child, element);
      } else if (typeof child === 'string' || typeof child === 'number') {
        element.appendChild(document.createTextNode(child));
      } else {
        element.appendChild(child);
      }
    }
  }
}
function redirect(href) {
  const title = document.title;
  window.history.pushState({}, title, href);
  trigger();
}
function back() {
  window.history.back();
}
function checkActiveNav() {
  document.querySelectorAll('.ses-nav').forEach(e => e.checkActiveNav());
}

function link(callback, title) {
  return function (element) {
    element.addEventListener('click', e => {
      e.preventDefault();
      title = title || document.title;
      window.history.pushState({}, title, e.target.href);
      callback(e);
    });
  };
}

window.onpopstate = function (e) {
  try {
    trigger();
  } catch (e) {
    console.error('Routing handler error:');
    console.error(e.message);
  }
}; // must have a static instance available - starting with top level on first call to register, replaced by active route upon load/navigation
// subsequent calls to register add the routes to the active router

/**
 * @typedef {Object} Route
 * @property {{name: string}} match - Name of query parameter and its value
 * @property {Function} handler - Callback to be executed on match. Expected to render content
 * @property {*=} context - Optional object that will be passed to handler
 * @property {Route[]=} routes - Nested routes
 */

/** @type {number} - Debug counter */

/** @type {Route[]} */


const routes = [];
/** @type {Route} */

let activeRoute = null;
let activeNav = [];
/**
 * Add nested routes to currently active route. If first call, top level routes are defined
 * @param {Route[]} options - List of routes
 * @param {*=} context - Optional object that will be passed to handlers
 */

function register(options, context) {
  let currentRoutes = routes;

  if (activeRoute !== null) {
    activeRoute.routes = activeRoute.routes || [];
    currentRoutes = activeRoute.routes;
  }

  const newRoutes = [];

  for (let route of options) {
    route = Object.assign(route, {
      context
    });
    const routeId = currentRoutes.reduce((p, c, i) => matchRoute(route.match, c.match) ? i : p, undefined);

    if (routeId !== undefined) {
      currentRoutes[routeId] = route;
    } else {
      newRoutes.push(route);
    }
  }

  newRoutes.forEach(r => currentRoutes.push(r));
  trigger(currentRoutes);
}
/**
 * Run a check against the routing list and execute matching handlers
 * @param {Route[]=} currentRoutes - Currently active routing list
 */


function trigger(currentRoutes) {
  if (currentRoutes === undefined || currentRoutes === routes) {
    currentRoutes = routes;
    activeNav = [];
  }
  /** @type {Object.<string, string>?} */


  const query = _parse__WEBPACK_IMPORTED_MODULE_0__["default"].queryString(document.location.search);

  for (let route of currentRoutes) {
    if (matchRoute(query, route.match)) {
      activeRoute = route;
      activeNav.push(activeRoute.match);
      checkActiveNav();
      return route.handler(query, route.context);
    }
  }
}
/**
 * Check if a given query object matches a given route pattern
 * @param {Object.<string, string>?} query - Query parameters
 * @param {{name: string}} match - Parameter name and value that must match
 * @returns {boolean}
 */


function matchRoute(query, match) {
  if (match === query) {
    return true;
  } else if (query) {
    if (typeof match === 'string' && query.hasOwnProperty(match)) {
      return true;
    } else {
      for (let name in match) {
        if (query[name] === match[name]) {
          return true;
        }
      }
    }
  } // No match


  return false;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  link,
  register
});

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!**********************************!*\
  !*** ./src/protocol/protocol.js ***!
  \**********************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _util_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/router */ "./src/util/router.js");

_util_router__WEBPACK_IMPORTED_MODULE_0__["default"].register([{
  match: 'course',
  handler: preselect
}]);

async function preselect(query) {
  await new Promise(r => setTimeout(r, 500));

  if (query.course) {
    document.querySelector('input[name="TrainingId_input"]').value = query.course;
    document.querySelector('input[name="TrainingId"]').value = query.course;
  }
}
})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9kZXYvL2NvbnRlbnQtc2NyaXB0cy9wcm90b2NvbC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBS0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUZBO0FBSUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKQTtBQU1BOztBQUVBO0FBQ0E7QUFDQTtBQWNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFTQTtBQUNBO0FBU0E7O0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFaQTtBQWdCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVpBOztBQWVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQVVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFHQTtBQUNBO0FBQ0E7QUFBQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFBQTs7QUFDQTtBQUFBOztBQUNBO0FBQUE7QUFIQTtBQUtBOztBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWpCQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM3VUE7QUFHQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7OztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRkE7Ozs7OztBQ2xNQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7QUN2QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7QUNQQTs7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDTkE7QUFHQTtBQUVBO0FBQ0E7QUFGQTs7QUFNQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL3V0aWwvcGFyc2UuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy91dGlsL3JvdXRlci5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvd2VicGFjay9ydW50aW1lL2RlZmluZSBwcm9wZXJ0eSBnZXR0ZXJzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvd2VicGFjay9ydW50aW1lL2hhc093blByb3BlcnR5IHNob3J0aGFuZCIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlL3dlYnBhY2svcnVudGltZS9tYWtlIG5hbWVzcGFjZSBvYmplY3QiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9wcm90b2NvbC9wcm90b2NvbC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJmdW5jdGlvbiBxdWVyeVN0cmluZyhxdWVyeSkge1xyXG4gICAgaWYgKCFxdWVyeSkge1xyXG4gICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHF1ZXJ5XHJcbiAgICAgICAgLnNwbGl0KCc/JylbMV1cclxuICAgICAgICAuc3BsaXQoJyYnKVxyXG4gICAgICAgIC5tYXAoYSA9PiBhLnNwbGl0KCc9JykpXHJcbiAgICAgICAgLnJlZHVjZSgoYSwgYykgPT4ge1xyXG4gICAgICAgICAgICBhW2NbMF1dID0gY1sxXTtcclxuICAgICAgICAgICAgcmV0dXJuIGE7XHJcbiAgICAgICAgfSwge30pO1xyXG59XHJcblxyXG4vKipcclxuICogQ2FsY3VsYXRlIG51bWJlciBvZiBkYXlzIHBhc3NpbmcgYmV0d2VlbiB0d28gZGF0ZXNcclxuICogQHBhcmFtIHtEYXRlfSBhIFN0YXJ0aW5nIGRhdGVcclxuICogQHBhcmFtIHtEYXRlfSBiIEVuZGluZyBkYXRlXHJcbiAqIEByZXR1cm5zIHtudW1iZXJ9IE51bWJlciBvZiBkYXlzXHJcbiAqL1xyXG5mdW5jdGlvbiBkYXRlRGlmZihhLCBiKSB7XHJcbiAgICBpZiAoYS5nZXRGdWxsWWVhcigpID09IGIuZ2V0RnVsbFllYXIoKSAmJlxyXG4gICAgICAgIGEuZ2V0TW9udGgoKSA9PSBiLmdldE1vbnRoKCkgJiZcclxuICAgICAgICBhLmdldERhdGUoKSA9PSBiLmdldERhdGUoKSkge1xyXG4gICAgICAgIHJldHVybiAwO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gKGIgLSBhKSA+IDAgPyBNYXRoLmNlaWwoKGIgLSBhKSAvIDg2NDAwMDAwKSA6IE1hdGguZmxvb3IoKGIgLSBhKSAvIDg2NDAwMDAwKTtcclxuICAgIH1cclxufVxyXG5cclxuZnVuY3Rpb24gZGF0ZURpZmZUb0RheXMoZGF5cykge1xyXG4gICAgaWYgKGRheXMgPT0gMCkge1xyXG4gICAgICAgIHJldHVybiAnVG9kYXknO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICBpZiAoZGF5cyA8PSAwKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBgSW4gJHstZGF5c30gZGF5JHtkYXlzID09IC0xID8gJycgOiAncyd9YDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gYCR7ZGF5c30gZGF5JHtkYXlzID09IDEgPyAnJyA6ICdzJ30gYWdvYDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBJcyB0aGUgZGF0ZSBpbiB0aGUgbGFzdCBkYXkgb2YgYSBtb250aFxyXG4gKiBAcGFyYW0ge0RhdGV9IGRhdGVcclxuICogQHJldHVybnMge2Jvb2xlYW59XHJcbiAqL1xyXG5mdW5jdGlvbiBpc0xhc3REYXkoZGF0ZSkge1xyXG4gICAgY29uc3QgbmV4dERheSA9IG5ldyBEYXRlKGRhdGUpO1xyXG4gICAgbmV4dERheS5zZXREYXRlKG5leHREYXkuZ2V0RGF0ZSgpICsgMSk7XHJcbiAgICByZXR1cm4gKGRhdGUuZ2V0TW9udGgoKSAhPSBuZXh0RGF5LmdldE1vbnRoKCkpO1xyXG59XHJcblxyXG4vKipcclxuICogSXMgdGhlIGRhdGUgaW4gdGhlIGxhc3Qgd2VlayBvZiBhIG1vbnRoXHJcbiAqIEBwYXJhbSB7RGF0ZX0gZGF0ZVxyXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cclxuICovXHJcbmZ1bmN0aW9uIGlzTGFzdFdlZWsoZGF0ZSkge1xyXG4gICAgY29uc3QgbmV4dFdlZWsgPSBuZXcgRGF0ZShkYXRlKTtcclxuICAgIG5leHRXZWVrLnNldERhdGUobmV4dFdlZWsuZ2V0RGF0ZSgpICsgNyk7XHJcbiAgICByZXR1cm4gKGRhdGUuZ2V0TW9udGgoKSAhPSBuZXh0V2Vlay5nZXRNb250aCgpKTtcclxufVxyXG5cclxuZnVuY3Rpb24gZm9ybWF0RGF0ZShkYXRlKSB7XHJcbiAgICBjb25zdCBhc1N0cmluZyA9IGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKCdlbi1VUycsIHtcclxuICAgICAgICBtb250aDogJ3Nob3J0JyxcclxuICAgICAgICB5ZWFyOiAnbnVtZXJpYydcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIGAke2RhdGUuZ2V0RGF0ZSgpfSAke2FzU3RyaW5nfWA7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZvcm1hdFRpbWUoZGF0ZSkge1xyXG4gICAgcmV0dXJuIGRhdGUudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1VUycsIHtcclxuICAgICAgICBob3VyOiAnbnVtZXJpYycsXHJcbiAgICAgICAgbWludXRlOiAnbnVtZXJpYycsXHJcbiAgICAgICAgLy8gaG91cjEyOiBmYWxzZSxcclxuICAgICAgICBob3VyQ3ljbGU6ICdoMjMnXHJcbiAgICB9KTtcclxufVxyXG5cclxuZnVuY3Rpb24gZm9ybWF0TG9jYWxlRGF0ZShkYXRlKSB7XHJcbiAgICBjb25zdCBkYXkgPSBkYXRlLmdldERhdGUoKTtcclxuICAgIGNvbnN0IG1vbnRoID0gW1xyXG4gICAgICAgICfRj9C90YPQsNGA0LgnLFxyXG4gICAgICAgICfRhNC10LLRgNGD0LDRgNC4JyxcclxuICAgICAgICAn0LzQsNGA0YInLFxyXG4gICAgICAgICfQsNC/0YDQuNC7JyxcclxuICAgICAgICAn0LzQsNC5JyxcclxuICAgICAgICAn0Y7QvdC4JyxcclxuICAgICAgICAn0Y7Qu9C4JyxcclxuICAgICAgICAn0LDQstCz0YPRgdGCJyxcclxuICAgICAgICAn0YHQtdC/0YLQtdC80LLRgNC4JyxcclxuICAgICAgICAn0L7QutGC0L7QvNCy0YDQuCcsXHJcbiAgICAgICAgJ9C90L7QtdC80LLRgNC4JyxcclxuICAgICAgICAn0LTQtdC60LXQvNCy0YDQuCdcclxuICAgIF1bZGF0ZS5nZXRNb250aCgpXTtcclxuICAgIHJldHVybiBgJHtkYXl9ICR7bW9udGh9YDtcclxufVxyXG5cclxuZnVuY3Rpb24gZm9ybWF0TG9jYWxlV2Vla2RheShkYXksIGdldEFkaikge1xyXG4gICAgY29uc3Qgd2Vla2RheSA9IFtcclxuICAgICAgICAn0L3QtdC00LXQu9GPJyxcclxuICAgICAgICAn0L/QvtC90LXQtNC10LvQvdC40LonLFxyXG4gICAgICAgICfQstGC0L7RgNC90LjQuicsXHJcbiAgICAgICAgJ9GB0YDRj9C00LAnLFxyXG4gICAgICAgICfRh9C10YLQstGK0YDRgtGK0LonLFxyXG4gICAgICAgICfQv9C10YLRitC6JyxcclxuICAgICAgICAn0YHRitCx0L7RgtCwJyxcclxuICAgIF1bZGF5XTtcclxuICAgIGlmIChnZXRBZGopIHtcclxuICAgICAgICByZXR1cm4gW3dlZWtkYXksIFtcclxuICAgICAgICAgICAgJ9Cy0YHRj9C60LAnLFxyXG4gICAgICAgICAgICAn0LLRgdC10LrQuCcsXHJcbiAgICAgICAgICAgICfQstGB0LXQutC4JyxcclxuICAgICAgICAgICAgJ9Cy0YHRj9C60LAnLFxyXG4gICAgICAgICAgICAn0LLRgdC10LrQuCcsXHJcbiAgICAgICAgICAgICfQstGB0LXQutC4JyxcclxuICAgICAgICAgICAgJ9Cy0YHRj9C60LAnLFxyXG4gICAgICAgIF1bZGF5XV07XHJcbiAgICB9XHJcbiAgICByZXR1cm4gd2Vla2RheTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEdldCBhIG5ldyBkYXRlIG9mZnNldCBieSB0aGUgc3BlY2lmaWVkIG51bWJlciBvZiBkYXlzXHJcbiAqIEBwYXJhbSB7RGF0ZX0gZGF0ZSBCYXNlIGRhdGVcclxuICogQHBhcmFtIHtudW1iZXJ9IGRheXMgSG93IG1hbnkgZGF5cyB0byBvZmZzZXRcclxuICogQHJldHVybnMge0RhdGV9XHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gZ2V0T2Zmc2V0QnlEYXlzKGRhdGUsIGRheXMpIHtcclxuICAgIGNvbnN0IHJlc3VsdCA9IG5ldyBEYXRlKGRhdGUpO1xyXG4gICAgcmVzdWx0LnNldFVUQ0RhdGUocmVzdWx0LmdldFVUQ0RhdGUoKSArIGRheXMpO1xyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxufVxyXG5cclxuLyoqXHJcbiAqIE9mZnNldCB0aGUgZ2l2ZW4gZGF0ZSBpbiBwbGFjZSBieSB0aGUgc3BlY2lmaWVkIG51bWJlciBvZiBkYXlzXHJcbiAqIEBwYXJhbSB7RGF0ZX0gZGF0ZSBCYXNlIGRhdGVcclxuICogQHBhcmFtIHtudW1iZXJ9IGRheXMgSG93IG1hbnkgZGF5cyB0byBvZmZzZXRcclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBvZmZzZXRCeURheXMoZGF0ZSwgZGF5cykge1xyXG4gICAgZGF0ZS5zZXRVVENEYXRlKGRhdGUuZ2V0VVRDRGF0ZSgpICsgZGF5cyk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBDcmVhdGUgZGF0ZSBpbmRleCBhcyBzdHJpbmdcclxuICogQHBhcmFtIHtEYXRlfHN0cmluZ30gZGF0ZSBCYXNlIGRhdGVcclxuICogQHJldHVybnMge3N0cmluZ31cclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXREYXRlSW5kZXgoZGF0ZSkge1xyXG4gICAgaWYgKHR5cGVvZiBkYXRlID09ICdzdHJpbmcnKSB7XHJcbiAgICAgICAgZGF0ZSA9IG5ldyBEYXRlKGRhdGUpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGRhdGUudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHByZXR0eUpTT04ob2JqKSB7XHJcbiAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkob2JqLCBudWxsLCAyKS5yZXBsYWNlKC8gL2dtaSwgJyZuYnNwOycpLnJlcGxhY2UoL1xcbi9nbWksICc8YnI+Jyk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGdldE1vbmRheShkYXRlKSB7XHJcbiAgICBjb25zdCBtb25kYXkgPSBuZXcgRGF0ZShgJHtkYXRlLmdldEZ1bGxZZWFyKCl9LSR7ZGF0ZS5nZXRNb250aCgpICsgMX0tJHtkYXRlLmdldERhdGUoKX0gMTI6MDA6MDBgKTtcclxuICAgIG1vbmRheS5zZXREYXRlKG1vbmRheS5nZXREYXRlKCkgLSAoKG1vbmRheS5nZXREYXkoKSArIDYpICUgNykpO1xyXG4gICAgcmV0dXJuIG1vbmRheTtcclxufVxyXG5cclxuZnVuY3Rpb24gZ2V0U3VuZGF5KGRhdGUpIHtcclxuICAgIGNvbnN0IHN1bmRheSA9IG5ldyBEYXRlKGAke2RhdGUuZ2V0RnVsbFllYXIoKX0tJHtkYXRlLmdldE1vbnRoKCkgKyAxfS0ke2RhdGUuZ2V0RGF0ZSgpfSAyMzo1OTo1OWApO1xyXG4gICAgc3VuZGF5LnNldERhdGUoc3VuZGF5LmdldERhdGUoKSArICgoNyAtIHN1bmRheS5nZXREYXkoKSkgJSA3KSk7XHJcbiAgICByZXR1cm4gc3VuZGF5O1xyXG59XHJcblxyXG5jb25zdCBtb250aE5hbWUgPSB7XHJcbiAgICAxOiAnSmFudWFyeScsXHJcbiAgICAyOiAnRmVicnVhcnknLFxyXG4gICAgMzogJ01hcmNoJyxcclxuICAgIDQ6ICdBcHJpbCcsXHJcbiAgICA1OiAnTWF5JyxcclxuICAgIDY6ICdKdW5lJyxcclxuICAgIDc6ICdKdWx5JyxcclxuICAgIDg6ICdBdWd1c3QnLFxyXG4gICAgOTogJ1NlcHRlbWJlcicsXHJcbiAgICAxMDogJ09jdG9iZXInLFxyXG4gICAgMTE6ICdOb3ZlbWJlcicsXHJcbiAgICAxMjogJ0RlY2VtYmVyJyxcclxufTtcclxuXHJcblxyXG5jb25zdCBsb2NhbGVNb250aE5hbWUgPSB7XHJcbiAgICAxOiAn0Y/QvdGD0LDRgNC4JyxcclxuICAgIDI6ICfRhNC10LLRgNGD0LDRgNC4JyxcclxuICAgIDM6ICfQvNCw0YDRgicsXHJcbiAgICA0OiAn0LDQv9GA0LjQuycsXHJcbiAgICA1OiAn0LzQsNC5JyxcclxuICAgIDY6ICfRjtC90LgnLFxyXG4gICAgNzogJ9GO0LvQuCcsXHJcbiAgICA4OiAn0LDQstCz0YPRgdGCJyxcclxuICAgIDk6ICfRgdC10L/RgtC10LzQstGA0LgnLFxyXG4gICAgMTA6ICfQvtC60YLQvtC80LLRgNC4JyxcclxuICAgIDExOiAn0L3QvtC10LzQstGA0LgnLFxyXG4gICAgMTI6ICfQtNC10LrQtdC80LLRgNC4JyxcclxufTtcclxuXHJcbmZ1bmN0aW9uIHRvQXNzb2NBcnJheShwLCBjLCBpLCBhKSB7XHJcbiAgICBwW2MuSWRdID0gYztcclxuICAgIHJldHVybiBwO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdG9DdXN0b21Bc3NvY0FycmF5KGluZGV4TmFtZSwgb3ZlcndyaXRlID0gZmFsc2UpIHtcclxuICAgIHJldHVybiAocCwgYywgaSwgYSkgPT4ge1xyXG4gICAgICAgIGlmIChwW2NbaW5kZXhOYW1lXV0gIT09IHVuZGVmaW5lZCAmJiBvdmVyd3JpdGUgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkocFtjW2luZGV4TmFtZV1dKSkge1xyXG4gICAgICAgICAgICAgICAgcFtjW2luZGV4TmFtZV1dLnB1c2goYyk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBwW2NbaW5kZXhOYW1lXV0gPSBbcFtjW2luZGV4TmFtZV1dLCBjXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHBbY1tpbmRleE5hbWVdXSA9IGM7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBwO1xyXG4gICAgfTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEBwYXJhbSB7QXJyYXk8U1VQYXltZW50Pn0gZGF0YSBcclxuICogQHJldHVybnMge0FycmF5PFBheW1lbnRWaWV3TW9kZWw+fVxyXG4gKi9cclxuZnVuY3Rpb24gcGF5bWVudHNUb01hdHJpeChkYXRhKSB7XHJcbiAgICBjb25zdCB0ZW1wbGF0ZSA9IFtcclxuICAgICAgICAnSWQnLFxyXG4gICAgICAgICdQYXltZW50TnVtYmVyJyxcclxuICAgICAgICAnTW9kdWxlTmFtZUVuJyxcclxuICAgICAgICAnUGF5bWVudFBhY2thZ2VzQXNTdHJpbmcnLFxyXG4gICAgICAgICdQYWlkRm9yVXNlck5hbWUnLFxyXG4gICAgICAgICdQcmljZScsXHJcbiAgICAgICAgJ0VkdWNhdGlvbmFsRm9ybScsXHJcbiAgICAgICAgJ1BheW1lbnREYXRlVGltZSdcclxuICAgIF07XHJcbiAgICBjb25zdCBwYXJzZWQgPSBkYXRhLm1hcChlID0+IHtcclxuICAgICAgICBlLkVkdWNhdGlvbmFsRm9ybSA9IGUuRWR1Y2F0aW9uYWxGb3JtID09IDEgPyAnb25saW5lJyA6ICdvbnNpdGUnO1xyXG4gICAgICAgIGNvbnN0IGVudHJ5ID0gW107XHJcbiAgICAgICAgZm9yIChsZXQgcHJvcCBvZiB0ZW1wbGF0ZSkge1xyXG4gICAgICAgICAgICBpZiAocHJvcCA9PT0gJ1BheW1lbnREYXRlVGltZScpIHtcclxuICAgICAgICAgICAgICAgIGVudHJ5LnB1c2gobmV3IERhdGUoZVtwcm9wXSkpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgZW50cnkucHVzaChlW3Byb3BdKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gZW50cnk7XHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gW3RlbXBsYXRlLCAuLi5wYXJzZWRdO1xyXG59XHJcblxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHV1aWQoKSB7XHJcbiAgICByZXR1cm4gJ3h4eHh4eHh4LXh4eHgtNHh4eC15eHh4LXh4eHh4eHh4eHh4eCcucmVwbGFjZSgvW3h5XS9nLCBmdW5jdGlvbiAoYykge1xyXG4gICAgICAgIGxldCByID0gTWF0aC5yYW5kb20oKSAqIDE2IHwgMCxcclxuICAgICAgICAgICAgdiA9IGMgPT0gJ3gnID8gciA6IChyICYgMHgzIHwgMHg4KTtcclxuICAgICAgICByZXR1cm4gdi50b1N0cmluZygxNik7XHJcbiAgICB9KTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZURhdGVUaW1lKGRhdGV0aW1lKSB7XHJcbiAgICBpZiAoIWRhdGV0aW1lKSB7XHJcbiAgICAgICAgcmV0dXJuICcnO1xyXG4gICAgfSBlbHNlIGlmIChkYXRldGltZS50b1N0cmluZygpLmluY2x1ZGVzKCdEYXRlKCcpKSB7XHJcbiAgICAgICAgY29uc3QgbWF0Y2ggPSAvRGF0ZVxcKCguKylcXCkvLmV4ZWMoZGF0ZXRpbWUpO1xyXG4gICAgICAgIGlmIChtYXRjaCAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICBjb25zdCBkID0gbmV3IERhdGUoTnVtYmVyKG1hdGNoWzFdKSk7XHJcbiAgICAgICAgICAgIHJldHVybiBgJHsoJzAwMDAnICsgZC5nZXRGdWxsWWVhcigpKS5zbGljZSgtNCl9LSR7cHQoZC5nZXRNb250aCgpICsgMSl9LSR7cHQoZC5nZXREYXRlKCkpfVQke3B0KGQuZ2V0SG91cnMoKSl9OiR7cHQoZC5nZXRNaW51dGVzKCkpfWA7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIGRhdGV0aW1lO1xyXG4gICAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIGRhdGV0aW1lO1xyXG4gICAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBwdChzKSB7XHJcbiAgICByZXR1cm4gYDAke3N9YC5zbGljZSgtMik7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGh0bWxUb1RleHQoaHRtbCkge1xyXG4gICAgY29uc3QgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgICBkaXYuaW5uZXJIVE1MID0gaHRtbDtcclxuXHJcbiAgICByZXR1cm4gZGl2LnRleHRDb250ZW50O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaW5zdGFuY2VNZXRhRnJvbUhyZWYoaHJlZikge1xyXG4gICAgY29uc3QgaW5zdGFuY2VNZXRhID0gcXVlcnlTdHJpbmcoaHJlZik7XHJcbiAgICBpbnN0YW5jZU1ldGEuSW5zdGFuY2VSZWZUeXBlID0gKCgpID0+IHtcclxuICAgICAgICBzd2l0Y2ggKGluc3RhbmNlTWV0YS50eXBlKSB7XHJcbiAgICAgICAgICAgIGNhc2UgJ2NvdXJzZSc6IHJldHVybiAnbWFpbic7XHJcbiAgICAgICAgICAgIGNhc2UgJ2Zhc3QtdHJhY2snOiByZXR1cm4gJ29wZW4nO1xyXG4gICAgICAgICAgICBjYXNlICdnZW5lcmFsLWNvdXJzZS1pbnN0YW5jZSc6IHJldHVybiAnZ2VuZXJhbCc7XHJcbiAgICAgICAgfVxyXG4gICAgfSkoKTtcclxuXHJcbiAgICByZXR1cm4gaW5zdGFuY2VNZXRhO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaGFzVmFsdWUodmFsdWUpIHtcclxuICAgIHJldHVybiAodmFsdWUgIT09IG51bGwgJiYgdmFsdWUgIT09IHVuZGVmaW5lZCAmJiB2YWx1ZSAhPT0gJycpO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdmFsdWVPckVtcHR5KHZhbHVlLCBhbHQgPSAnJykge1xyXG4gICAgaWYgKHZhbHVlID09PSBudWxsIHx8IHZhbHVlID09PSB1bmRlZmluZWQgfHwgdmFsdWUgPT09ICcnKSB7XHJcbiAgICAgICAgcmV0dXJuIGFsdDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gc3VtQXJyYXlNYXgoYXJyKSB7XHJcbiAgICBpZiAoYXJyWzBdLmxlbmd0aCA9PSAwICYmIGFyclsxXS5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG5cclxuICAgIGxldCByZXN1bHQgPSAwO1xyXG5cclxuICAgIGlmIChhcnJbMF0ubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIHJlc3VsdCArPSBNYXRoLm1heCguLi5hcnJbMF0pO1xyXG4gICAgfVxyXG4gICAgaWYgKGFyclsxXS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgcmVzdWx0ICs9IE1hdGgubWF4KC4uLmFyclsxXSk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQge1xyXG4gICAgcXVlcnlTdHJpbmcsXHJcbiAgICBkYXRlRGlmZixcclxuICAgIGRhdGVEaWZmVG9EYXlzLFxyXG4gICAgaXNMYXN0RGF5LFxyXG4gICAgaXNMYXN0V2VlayxcclxuICAgIGZvcm1hdERhdGUsXHJcbiAgICBmb3JtYXRUaW1lLFxyXG4gICAgZm9ybWF0TG9jYWxlRGF0ZSxcclxuICAgIGZvcm1hdExvY2FsZVdlZWtkYXksXHJcbiAgICBwcmV0dHlKU09OLFxyXG4gICAgZ2V0TW9uZGF5LFxyXG4gICAgZ2V0U3VuZGF5LFxyXG4gICAgbW9udGhOYW1lLFxyXG4gICAgbG9jYWxlTW9udGhOYW1lLFxyXG4gICAgdG9Bc3NvY0FycmF5LFxyXG4gICAgcGF5bWVudHNUb01hdHJpeCxcclxuICAgIGh0bWxUb1RleHRcclxufTtcclxuXHJcblxyXG5leHBvcnQge1xyXG4gICAgcXVlcnlTdHJpbmcsXHJcbiAgICBkYXRlRGlmZixcclxuICAgIGRhdGVEaWZmVG9EYXlzLFxyXG4gICAgaXNMYXN0RGF5LFxyXG4gICAgaXNMYXN0V2VlayxcclxuICAgIGZvcm1hdERhdGUsXHJcbiAgICBmb3JtYXRUaW1lLFxyXG4gICAgZm9ybWF0TG9jYWxlRGF0ZSxcclxuICAgIGZvcm1hdExvY2FsZVdlZWtkYXksXHJcbiAgICBwcmV0dHlKU09OLFxyXG4gICAgZ2V0TW9uZGF5LFxyXG4gICAgZ2V0U3VuZGF5LFxyXG4gICAgbW9udGhOYW1lLFxyXG4gICAgbG9jYWxlTW9udGhOYW1lLFxyXG4gICAgdG9Bc3NvY0FycmF5LFxyXG4gICAgcGF5bWVudHNUb01hdHJpeCxcclxuICAgIGh0bWxUb1RleHRcclxufTsiLCJpbXBvcnQgcGFyc2UgZnJvbSAnLi9wYXJzZSc7XHJcblxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIExpbmsoeyBocmVmLCB0bywgbmF2LCBwYXJ0aWFsLCByZXEsIGNoaWxkcmVuLCAuLi5wcm9wcyB9KSB7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IGVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XHJcbiAgICAgICAgaWYgKGhyZWYgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICBlbGVtZW50LnNldEF0dHJpYnV0ZSgnaHJlZicsIGhyZWYpO1xyXG4gICAgICAgICAgICBlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGUpID0+IGhhbmRsZXIoZSwgZWxlbWVudCkpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBmb3IgKGxldCBwcm9wIG9mIE9iamVjdC5rZXlzKHByb3BzKSkge1xyXG4gICAgICAgICAgICBlbGVtZW50W3Byb3BdID0gcHJvcHNbcHJvcF07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChuYXYpIHtcclxuICAgICAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QuYWRkKCdzZXMtbmF2Jyk7XHJcbiAgICAgICAgICAgIGNvbnN0IGhyZWZUb2tlbnMgPSBwYXJzZS5xdWVyeVN0cmluZyhlbGVtZW50LmhyZWYpO1xyXG4gICAgICAgICAgICBjb25zdCBtYXRjaGVyID0gKG5hdikgPT4gbWF0Y2hSb3V0ZShocmVmVG9rZW5zLCBuYXYpO1xyXG4gICAgICAgICAgICBlbGVtZW50LmNoZWNrQWN0aXZlTmF2ID0gKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHdpbmRvdy5sb2NhdGlvbi5zZWFyY2guc3BsaXQoJz8nKVsxXSA9PT0gZWxlbWVudC5ocmVmLnNwbGl0KCc/JylbMV0pIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZWxlbWVudC5jbGFzc0xpc3QuYWRkKCdhY3RpdmUnKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAocGFydGlhbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChhY3RpdmVOYXYuc29tZShtYXRjaGVyKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVxID09PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBlbGVtZW50LmNsYXNzTGlzdC5hZGQoJ2FjdGl2ZScpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGFjdGl2ZU5hdi5zb21lKG5hdiA9PiBtYXRjaFJvdXRlKHJlcSwgbmF2KSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBlbGVtZW50LmNsYXNzTGlzdC5hZGQoJ2FjdGl2ZScpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdhY3RpdmUnKTtcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgZWxlbWVudC5jaGVja0FjdGl2ZU5hdigpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBhcHBlbmRBbGwoY2hpbGRyZW4sIGVsZW1lbnQpO1xyXG5cclxuICAgICAgICByZXR1cm4gZWxlbWVudDtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyLm1lc3NhZ2UpO1xyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIGhhbmRsZXIoZSwgZWxlbWVudCkge1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICBjb25zdCB0aXRsZSA9IGRvY3VtZW50LnRpdGxlO1xyXG4gICAgICAgIHdpbmRvdy5oaXN0b3J5LnB1c2hTdGF0ZSh7fSwgdGl0bGUsIGhyZWYpO1xyXG5cclxuICAgICAgICBpZiAodG8gIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICBpZiAobmF2KSB7XHJcbiAgICAgICAgICAgICAgICBjaGVja0FjdGl2ZU5hdigpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRvKCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdHJpZ2dlcigpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBhcHBlbmRBbGwoY2hpbGRyZW4sIGVsZW1lbnQpIHtcclxuICAgICAgICBmb3IgKGxldCBjaGlsZCBvZiBjaGlsZHJlbikge1xyXG4gICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShjaGlsZCkpIHtcclxuICAgICAgICAgICAgICAgIGFwcGVuZEFsbChjaGlsZCwgZWxlbWVudCk7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIGNoaWxkID09PSAnc3RyaW5nJyB8fCB0eXBlb2YgY2hpbGQgPT09ICdudW1iZXInKSB7XHJcbiAgICAgICAgICAgICAgICBlbGVtZW50LmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKGNoaWxkKSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBlbGVtZW50LmFwcGVuZENoaWxkKGNoaWxkKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHJlZGlyZWN0KGhyZWYpIHtcclxuICAgIGNvbnN0IHRpdGxlID0gZG9jdW1lbnQudGl0bGU7XHJcbiAgICB3aW5kb3cuaGlzdG9yeS5wdXNoU3RhdGUoe30sIHRpdGxlLCBocmVmKTtcclxuICAgIHRyaWdnZXIoKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGJhY2soKSB7XHJcbiAgICB3aW5kb3cuaGlzdG9yeS5iYWNrKCk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBjaGVja0FjdGl2ZU5hdigpIHtcclxuICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJy5zZXMtbmF2JykuZm9yRWFjaChlID0+IGUuY2hlY2tBY3RpdmVOYXYoKSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGxpbmsoY2FsbGJhY2ssIHRpdGxlKSB7XHJcbiAgICByZXR1cm4gZnVuY3Rpb24gKGVsZW1lbnQpIHtcclxuICAgICAgICBlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgZSA9PiB7XHJcbiAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgdGl0bGUgPSB0aXRsZSB8fCBkb2N1bWVudC50aXRsZTtcclxuICAgICAgICAgICAgd2luZG93Lmhpc3RvcnkucHVzaFN0YXRlKHt9LCB0aXRsZSwgZS50YXJnZXQuaHJlZik7XHJcblxyXG4gICAgICAgICAgICBjYWxsYmFjayhlKTtcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcbn1cclxuXHJcblxyXG53aW5kb3cub25wb3BzdGF0ZSA9IGZ1bmN0aW9uIChlKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIHRyaWdnZXIoKTtcclxuICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKCdSb3V0aW5nIGhhbmRsZXIgZXJyb3I6Jyk7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihlLm1lc3NhZ2UpO1xyXG4gICAgfVxyXG59O1xyXG5cclxuLy8gbXVzdCBoYXZlIGEgc3RhdGljIGluc3RhbmNlIGF2YWlsYWJsZSAtIHN0YXJ0aW5nIHdpdGggdG9wIGxldmVsIG9uIGZpcnN0IGNhbGwgdG8gcmVnaXN0ZXIsIHJlcGxhY2VkIGJ5IGFjdGl2ZSByb3V0ZSB1cG9uIGxvYWQvbmF2aWdhdGlvblxyXG4vLyBzdWJzZXF1ZW50IGNhbGxzIHRvIHJlZ2lzdGVyIGFkZCB0aGUgcm91dGVzIHRvIHRoZSBhY3RpdmUgcm91dGVyXHJcbi8qKlxyXG4gKiBAdHlwZWRlZiB7T2JqZWN0fSBSb3V0ZVxyXG4gKiBAcHJvcGVydHkge3tuYW1lOiBzdHJpbmd9fSBtYXRjaCAtIE5hbWUgb2YgcXVlcnkgcGFyYW1ldGVyIGFuZCBpdHMgdmFsdWVcclxuICogQHByb3BlcnR5IHtGdW5jdGlvbn0gaGFuZGxlciAtIENhbGxiYWNrIHRvIGJlIGV4ZWN1dGVkIG9uIG1hdGNoLiBFeHBlY3RlZCB0byByZW5kZXIgY29udGVudFxyXG4gKiBAcHJvcGVydHkgeyo9fSBjb250ZXh0IC0gT3B0aW9uYWwgb2JqZWN0IHRoYXQgd2lsbCBiZSBwYXNzZWQgdG8gaGFuZGxlclxyXG4gKiBAcHJvcGVydHkge1JvdXRlW109fSByb3V0ZXMgLSBOZXN0ZWQgcm91dGVzXHJcbiAqL1xyXG5cclxuLyoqIEB0eXBlIHtudW1iZXJ9IC0gRGVidWcgY291bnRlciAqL1xyXG5cclxuLyoqIEB0eXBlIHtSb3V0ZVtdfSAqL1xyXG5jb25zdCByb3V0ZXMgPSBbXTtcclxuLyoqIEB0eXBlIHtSb3V0ZX0gKi9cclxubGV0IGFjdGl2ZVJvdXRlID0gbnVsbDtcclxubGV0IGFjdGl2ZU5hdiA9IFtdO1xyXG5cclxuLyoqXHJcbiAqIEFkZCBuZXN0ZWQgcm91dGVzIHRvIGN1cnJlbnRseSBhY3RpdmUgcm91dGUuIElmIGZpcnN0IGNhbGwsIHRvcCBsZXZlbCByb3V0ZXMgYXJlIGRlZmluZWRcclxuICogQHBhcmFtIHtSb3V0ZVtdfSBvcHRpb25zIC0gTGlzdCBvZiByb3V0ZXNcclxuICogQHBhcmFtIHsqPX0gY29udGV4dCAtIE9wdGlvbmFsIG9iamVjdCB0aGF0IHdpbGwgYmUgcGFzc2VkIHRvIGhhbmRsZXJzXHJcbiAqL1xyXG5mdW5jdGlvbiByZWdpc3RlcihvcHRpb25zLCBjb250ZXh0KSB7XHJcbiAgICBsZXQgY3VycmVudFJvdXRlcyA9IHJvdXRlcztcclxuICAgIGlmIChhY3RpdmVSb3V0ZSAhPT0gbnVsbCkge1xyXG4gICAgICAgIGFjdGl2ZVJvdXRlLnJvdXRlcyA9IGFjdGl2ZVJvdXRlLnJvdXRlcyB8fCBbXTtcclxuICAgICAgICBjdXJyZW50Um91dGVzID0gYWN0aXZlUm91dGUucm91dGVzO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IG5ld1JvdXRlcyA9IFtdO1xyXG4gICAgZm9yIChsZXQgcm91dGUgb2Ygb3B0aW9ucykge1xyXG4gICAgICAgIHJvdXRlID0gT2JqZWN0LmFzc2lnbihyb3V0ZSwgeyBjb250ZXh0IH0pO1xyXG4gICAgICAgIGNvbnN0IHJvdXRlSWQgPSBjdXJyZW50Um91dGVzLnJlZHVjZSgocCwgYywgaSkgPT4gbWF0Y2hSb3V0ZShyb3V0ZS5tYXRjaCwgYy5tYXRjaCkgPyBpIDogcCwgdW5kZWZpbmVkKTtcclxuICAgICAgICBpZiAocm91dGVJZCAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIGN1cnJlbnRSb3V0ZXNbcm91dGVJZF0gPSByb3V0ZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBuZXdSb3V0ZXMucHVzaChyb3V0ZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgbmV3Um91dGVzLmZvckVhY2gociA9PiBjdXJyZW50Um91dGVzLnB1c2gocikpO1xyXG5cclxuICAgIHRyaWdnZXIoY3VycmVudFJvdXRlcyk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBSdW4gYSBjaGVjayBhZ2FpbnN0IHRoZSByb3V0aW5nIGxpc3QgYW5kIGV4ZWN1dGUgbWF0Y2hpbmcgaGFuZGxlcnNcclxuICogQHBhcmFtIHtSb3V0ZVtdPX0gY3VycmVudFJvdXRlcyAtIEN1cnJlbnRseSBhY3RpdmUgcm91dGluZyBsaXN0XHJcbiAqL1xyXG5mdW5jdGlvbiB0cmlnZ2VyKGN1cnJlbnRSb3V0ZXMpIHtcclxuICAgIGlmIChjdXJyZW50Um91dGVzID09PSB1bmRlZmluZWQgfHwgY3VycmVudFJvdXRlcyA9PT0gcm91dGVzKSB7XHJcbiAgICAgICAgY3VycmVudFJvdXRlcyA9IHJvdXRlcztcclxuICAgICAgICBhY3RpdmVOYXYgPSBbXTtcclxuICAgIH1cclxuICAgIC8qKiBAdHlwZSB7T2JqZWN0LjxzdHJpbmcsIHN0cmluZz4/fSAqL1xyXG4gICAgY29uc3QgcXVlcnkgPSBwYXJzZS5xdWVyeVN0cmluZyhkb2N1bWVudC5sb2NhdGlvbi5zZWFyY2gpO1xyXG5cclxuICAgIGZvciAobGV0IHJvdXRlIG9mIGN1cnJlbnRSb3V0ZXMpIHtcclxuICAgICAgICBpZiAobWF0Y2hSb3V0ZShxdWVyeSwgcm91dGUubWF0Y2gpKSB7XHJcbiAgICAgICAgICAgIGFjdGl2ZVJvdXRlID0gcm91dGU7XHJcbiAgICAgICAgICAgIGFjdGl2ZU5hdi5wdXNoKGFjdGl2ZVJvdXRlLm1hdGNoKTtcclxuICAgICAgICAgICAgY2hlY2tBY3RpdmVOYXYoKTtcclxuICAgICAgICAgICAgcmV0dXJuIHJvdXRlLmhhbmRsZXIocXVlcnksIHJvdXRlLmNvbnRleHQpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIENoZWNrIGlmIGEgZ2l2ZW4gcXVlcnkgb2JqZWN0IG1hdGNoZXMgYSBnaXZlbiByb3V0ZSBwYXR0ZXJuXHJcbiAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsIHN0cmluZz4/fSBxdWVyeSAtIFF1ZXJ5IHBhcmFtZXRlcnNcclxuICogQHBhcmFtIHt7bmFtZTogc3RyaW5nfX0gbWF0Y2ggLSBQYXJhbWV0ZXIgbmFtZSBhbmQgdmFsdWUgdGhhdCBtdXN0IG1hdGNoXHJcbiAqIEByZXR1cm5zIHtib29sZWFufVxyXG4gKi9cclxuZnVuY3Rpb24gbWF0Y2hSb3V0ZShxdWVyeSwgbWF0Y2gpIHtcclxuICAgIGlmIChtYXRjaCA9PT0gcXVlcnkpIHtcclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH0gZWxzZSBpZiAocXVlcnkpIHtcclxuICAgICAgICBpZiAodHlwZW9mIG1hdGNoID09PSAnc3RyaW5nJyAmJiBxdWVyeS5oYXNPd25Qcm9wZXJ0eShtYXRjaCkpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgbmFtZSBpbiBtYXRjaCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHF1ZXJ5W25hbWVdID09PSBtYXRjaFtuYW1lXSkgeyByZXR1cm4gdHJ1ZTsgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIE5vIG1hdGNoXHJcbiAgICByZXR1cm4gZmFsc2U7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IHtcclxuICAgIGxpbmssXHJcbiAgICByZWdpc3RlclxyXG59OyIsIi8vIFRoZSBtb2R1bGUgY2FjaGVcbnZhciBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX18gPSB7fTtcblxuLy8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbmZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG5cdHZhciBjYWNoZWRNb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdO1xuXHRpZiAoY2FjaGVkTW9kdWxlICE9PSB1bmRlZmluZWQpIHtcblx0XHRyZXR1cm4gY2FjaGVkTW9kdWxlLmV4cG9ydHM7XG5cdH1cblx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcblx0dmFyIG1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF0gPSB7XG5cdFx0Ly8gbm8gbW9kdWxlLmlkIG5lZWRlZFxuXHRcdC8vIG5vIG1vZHVsZS5sb2FkZWQgbmVlZGVkXG5cdFx0ZXhwb3J0czoge31cblx0fTtcblxuXHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cblx0X193ZWJwYWNrX21vZHVsZXNfX1ttb2R1bGVJZF0obW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cblx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcblx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xufVxuXG4iLCIvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9ucyBmb3IgaGFybW9ueSBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSAoZXhwb3J0cywgZGVmaW5pdGlvbikgPT4ge1xuXHRmb3IodmFyIGtleSBpbiBkZWZpbml0aW9uKSB7XG5cdFx0aWYoX193ZWJwYWNrX3JlcXVpcmVfXy5vKGRlZmluaXRpb24sIGtleSkgJiYgIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBrZXkpKSB7XG5cdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywga2V5LCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZGVmaW5pdGlvbltrZXldIH0pO1xuXHRcdH1cblx0fVxufTsiLCJfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSAob2JqLCBwcm9wKSA9PiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iaiwgcHJvcCkpIiwiLy8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5yID0gKGV4cG9ydHMpID0+IHtcblx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG5cdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG5cdH1cblx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbn07IiwiaW1wb3J0IHJvdXRlciBmcm9tICcuLi91dGlsL3JvdXRlcic7XHJcblxyXG5cclxucm91dGVyLnJlZ2lzdGVyKFtcclxuICAgIHtcclxuICAgICAgICBtYXRjaDogJ2NvdXJzZScsXHJcbiAgICAgICAgaGFuZGxlcjogcHJlc2VsZWN0XHJcbiAgICB9LFxyXG5dKTtcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHByZXNlbGVjdChxdWVyeSkge1xyXG4gICAgYXdhaXQgbmV3IFByb21pc2UociA9PiBzZXRUaW1lb3V0KHIsIDUwMCkpO1xyXG5cclxuICAgIGlmIChxdWVyeS5jb3Vyc2UpIHtcclxuICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdpbnB1dFtuYW1lPVwiVHJhaW5pbmdJZF9pbnB1dFwiXScpLnZhbHVlID0gcXVlcnkuY291cnNlO1xyXG4gICAgICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2lucHV0W25hbWU9XCJUcmFpbmluZ0lkXCJdJykudmFsdWUgPSBxdWVyeS5jb3Vyc2U7XHJcbiAgICB9XHJcbn0iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=