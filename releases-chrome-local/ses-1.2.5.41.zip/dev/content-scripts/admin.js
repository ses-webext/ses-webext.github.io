/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/util/jsx-render-mod/dom.js":
/*!****************************************!*\
  !*** ./src/util/jsx-render-mod/dom.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Fragment": () => (/* binding */ Fragment),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "portalCreator": () => (/* binding */ portalCreator)
/* harmony export */ });
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils */ "./src/util/jsx-render-mod/utils.js");

/**
 * The tag name and create an html together with the attributes
 *
 * @param  {String} tagName name as string, e.g. 'div', 'span', 'svg'
 * @param  {Object} attrs html attributes e.g. data-, width, src
 * @param  {Array} children html nodes from inside de elements
 * @return {HTMLElement|SVGElement} html node with attrs
 */

function createElements(tagName, attrs, children) {
  const element = (0,_utils__WEBPACK_IMPORTED_MODULE_0__.isSVG)(tagName) ? document.createElementNS('http://www.w3.org/2000/svg', tagName) : document.createElement(tagName); // one or multiple will be evaluated to append as string or HTMLElement

  const fragment = (0,_utils__WEBPACK_IMPORTED_MODULE_0__.createFragmentFrom)(children);
  element.appendChild(fragment);
  Object.keys(attrs || {}).forEach(prop => {
    if (prop === 'style') {
      // e.g. origin: <element style={{ prop: value }} />
      Object.assign(element.style, attrs[prop]);
    } else if (prop === 'ref' && typeof attrs.ref === 'function') {
      attrs.ref(element, attrs);
    } else if (prop === 'className') {
      element.setAttribute('class', attrs[prop]);
    } else if (prop === 'xlinkHref') {
      element.setAttributeNS('http://www.w3.org/1999/xlink', 'xlink:href', attrs[prop]);
    } else if (prop === 'dangerouslySetInnerHTML') {
      // eslint-disable-next-line no-underscore-dangle
      element.innerHTML = attrs[prop].__html;
    } else if (prop in _utils__WEBPACK_IMPORTED_MODULE_0__.EVENT_LISTENERS) {
      element.addEventListener(_utils__WEBPACK_IMPORTED_MODULE_0__.EVENT_LISTENERS[prop], attrs[prop]);
    } else {
      // any other prop will be set as attribute
      element.setAttribute(prop, attrs[prop]);
    }
  });
  return element;
}
/**
 * The JSXTag will be unwrapped returning the html
 *
 * @param  {Function} JSXTag name as string, e.g. 'div', 'span', 'svg'
 * @param  {Object} elementProps custom jsx attributes e.g. fn, strings
 * @param  {Array} children html nodes from inside de elements
 *
 * @return {Function} returns de 'dom' (fn) executed, leaving the HTMLElement
 *
 * JSXTag:  function Comp(props) {
 *   return dom("span", null, props.num);
 * }
 */


function composeToFunction(JSXTag, elementProps, children) {
  const props = Object.assign({}, JSXTag.defaultProps || {}, elementProps, {
    children
  });
  const bridge = JSXTag.prototype && JSXTag.prototype.render ? new JSXTag(props).render : JSXTag;
  const result = bridge(props);

  switch (result) {
    case 'FRAGMENT':
      return (0,_utils__WEBPACK_IMPORTED_MODULE_0__.createFragmentFrom)(children);
    // Portals are useful to render modals
    // allow render on a different element than the parent of the chain
    // and leave a comment instead

    case 'PORTAL':
      bridge.target.appendChild((0,_utils__WEBPACK_IMPORTED_MODULE_0__.createFragmentFrom)(children));
      return document.createComment('Portal Used');

    default:
      return result;
  }
}

function dom(element, attrs, ...children) {
  // Custom Components will be functions
  if (typeof element === 'function') {
    if (element.hasOwnProperty('propTypes')) {
      for (let prop of element.propTypes) {
        if (attrs.hasOwnProperty(prop) === false) {
          console.error(`JSX Error: Missing property '${prop}' from '${element.name}' invocation`);
        }
      }
    } // e.g. const CustomTag = ({ w }) => <span width={w} />
    // will be used
    // e.g. <CustomTag w={1} />
    // becomes: CustomTag({ w: 1})


    return composeToFunction(element, attrs, children);
  } // regular html components will be strings to create the elements
  // this is handled by the babel plugins


  if (typeof element === 'string') {
    return createElements(element, attrs, children);
  }

  return console.error(`jsx-render does not handle ${typeof tag}`);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (dom);
const Fragment = () => 'FRAGMENT';
const portalCreator = node => {
  function Portal() {
    return 'PORTAL';
  }

  Portal.target = document.body;

  if (node && node.nodeType === Node.ELEMENT_NODE) {
    Portal.target = node;
  }

  return Portal;
};

/***/ }),

/***/ "./src/util/jsx-render-mod/utils.js":
/*!******************************************!*\
  !*** ./src/util/jsx-render-mod/utils.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EVENT_LISTENERS": () => (/* binding */ EVENT_LISTENERS),
/* harmony export */   "createFragmentFrom": () => (/* binding */ createFragmentFrom),
/* harmony export */   "isSVG": () => (/* binding */ isSVG)
/* harmony export */ });
function isSVG(element) {
  const patt = new RegExp(`^${element}$`, 'i');
  const SVGTags = ['path', 'svg', 'use', 'g'];
  return SVGTags.some(tag => patt.test(tag));
}
function createFragmentFrom(children) {
  // fragments will help later to append multiple children to the initial node
  const fragment = document.createDocumentFragment();

  function processDOMNodes(child) {
    if (child instanceof HTMLElement || child instanceof SVGElement || child instanceof Comment || child instanceof DocumentFragment) {
      fragment.appendChild(child);
    } else if (typeof child === 'string' || typeof child === 'number') {
      const textnode = document.createTextNode(child);
      fragment.appendChild(textnode);
    } else if (child instanceof Array) {
      child.forEach(processDOMNodes);
    } else if (child === false || child === null) {// expression evaluated as false e.g. {false && <Elem />}
      // expression evaluated as false e.g. {null && <Elem />}
    } else if (typeof child === 'function') {} else if (true) {
      // later other things could not be HTMLElement nor strings
      console.log(child, 'is not appendable');
    }
  }

  children.forEach(processDOMNodes);
  return fragment;
} // Map from JSX property (e.g. onClick) to event name (e.g. 'click').

const EVENT_LISTENERS = {
  // Clipboard Events
  onCopy: 'copy',
  onCut: 'cut',
  onPaste: 'paste',
  // Composition Events
  onCompositionEnd: 'compositionend',
  onCompositionStart: 'compositionstart',
  onCompositionUpdate: 'compositionupdate',
  // Focus Events
  onFocus: 'focus',
  onBlur: 'blur',
  // Form Events
  onChange: 'change',
  onBeforeInput: 'beforeinput',
  onInput: 'input',
  onReset: 'reset',
  onSubmit: 'submit',
  onInvalid: 'invalid',
  // Image Events
  onLoad: 'load',
  onError: 'error',
  // Keyboard Events
  onKeyDown: 'keydown',
  onKeyPress: 'keypress',
  onKeyUp: 'keyup',
  // Media Events
  onAbort: 'abort',
  onCanPlay: 'canplay',
  onCanPlayThrough: 'canplaythrough',
  onDurationChange: 'durationchange',
  onEmptied: 'emptied',
  onEncrypted: 'encrypted',
  onEnded: 'ended',
  onLoadedData: 'loadeddata',
  onLoadedMetadata: 'loadedmetadata',
  onLoadStart: 'loadstart',
  onPause: 'pause',
  onPlay: 'play',
  onPlaying: 'playing',
  onProgress: 'progress',
  onRateChange: 'ratechange',
  onSeeked: 'seeked',
  onSeeking: 'seeking',
  onStalled: 'stalled',
  onSuspend: 'suspend',
  onTimeUpdate: 'timeupdate',
  onVolumeChange: 'volumechange',
  onWaiting: 'waiting',
  // MouseEvents
  onClick: 'click',
  onContextMenu: 'contextmenu',
  onDoubleClick: 'doubleclick',
  onDrag: 'drag',
  onDragEnd: 'dragend',
  onDragEnter: 'dragenter',
  onDragExit: 'dragexit',
  onDragLeave: 'dragleave',
  onDragOver: 'dragover',
  onDragStart: 'dragstart',
  onDrop: 'drop',
  onMouseDown: 'mousedown',
  onMouseEnter: 'mouseenter',
  onMouseLeave: 'mouseleave',
  onMouseMove: 'mousemove',
  onMouseOut: 'mouseout',
  onMouseOver: 'mouseover',
  onMouseUp: 'mouseup',
  // Selection Events
  onSelect: 'select',
  // Touch Events
  onTouchCancel: 'touchcancel',
  onTouchEnd: 'touchend',
  onTouchMove: 'touchmove',
  onTouchStart: 'touchstart',
  // Pointer Events
  onPointerDown: 'pointerdown',
  onPointerMove: 'pointermove',
  onPointerUp: 'pointerup',
  onPointerCancel: 'pointercancel',
  onPointerEnter: 'pointerenter',
  onPointerLeave: 'pointerleave',
  onPointerOver: 'pointerover',
  onPointerOut: 'pointerout',
  // UI Events
  onScroll: 'scroll',
  // Wheel Events
  onWheel: 'wheel',
  // Animation Events
  onAnimationStart: 'animationstart',
  onAnimationEnd: 'animationend',
  onAnimationIteration: 'animationiteration',
  // Transition Events
  onTransitionEnd: 'transitionend'
};

/***/ }),

/***/ "./src/util/parse.js":
/*!***************************!*\
  !*** ./src/util/parse.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dateDiff": () => (/* binding */ dateDiff),
/* harmony export */   "dateDiffToDays": () => (/* binding */ dateDiffToDays),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "formatDate": () => (/* binding */ formatDate),
/* harmony export */   "formatLocaleDate": () => (/* binding */ formatLocaleDate),
/* harmony export */   "formatLocaleWeekday": () => (/* binding */ formatLocaleWeekday),
/* harmony export */   "formatTime": () => (/* binding */ formatTime),
/* harmony export */   "getDateIndex": () => (/* binding */ getDateIndex),
/* harmony export */   "getMonday": () => (/* binding */ getMonday),
/* harmony export */   "getOffsetByDays": () => (/* binding */ getOffsetByDays),
/* harmony export */   "getSunday": () => (/* binding */ getSunday),
/* harmony export */   "hasValue": () => (/* binding */ hasValue),
/* harmony export */   "htmlToText": () => (/* binding */ htmlToText),
/* harmony export */   "instanceMetaFromHref": () => (/* binding */ instanceMetaFromHref),
/* harmony export */   "isLastDay": () => (/* binding */ isLastDay),
/* harmony export */   "isLastWeek": () => (/* binding */ isLastWeek),
/* harmony export */   "localeMonthName": () => (/* binding */ localeMonthName),
/* harmony export */   "monthName": () => (/* binding */ monthName),
/* harmony export */   "normalizeDateTime": () => (/* binding */ normalizeDateTime),
/* harmony export */   "offsetByDays": () => (/* binding */ offsetByDays),
/* harmony export */   "paymentsToMatrix": () => (/* binding */ paymentsToMatrix),
/* harmony export */   "prettyJSON": () => (/* binding */ prettyJSON),
/* harmony export */   "queryString": () => (/* binding */ queryString),
/* harmony export */   "sumArrayMax": () => (/* binding */ sumArrayMax),
/* harmony export */   "toAssocArray": () => (/* binding */ toAssocArray),
/* harmony export */   "toCustomAssocArray": () => (/* binding */ toCustomAssocArray),
/* harmony export */   "uuid": () => (/* binding */ uuid),
/* harmony export */   "valueOrEmpty": () => (/* binding */ valueOrEmpty)
/* harmony export */ });
function queryString(query) {
  if (!query) {
    return null;
  }

  return query.split('?')[1].split('&').map(a => a.split('=')).reduce((a, c) => {
    a[c[0]] = c[1];
    return a;
  }, {});
}
/**
 * Calculate number of days passing between two dates
 * @param {Date} a Starting date
 * @param {Date} b Ending date
 * @returns {number} Number of days
 */


function dateDiff(a, b) {
  if (a.getFullYear() == b.getFullYear() && a.getMonth() == b.getMonth() && a.getDate() == b.getDate()) {
    return 0;
  } else {
    return b - a > 0 ? Math.ceil((b - a) / 86400000) : Math.floor((b - a) / 86400000);
  }
}

function dateDiffToDays(days) {
  if (days == 0) {
    return 'Today';
  } else {
    if (days <= 0) {
      return `In ${-days} day${days == -1 ? '' : 's'}`;
    } else {
      return `${days} day${days == 1 ? '' : 's'} ago`;
    }
  }
}
/**
 * Is the date in the last day of a month
 * @param {Date} date
 * @returns {boolean}
 */


function isLastDay(date) {
  const nextDay = new Date(date);
  nextDay.setDate(nextDay.getDate() + 1);
  return date.getMonth() != nextDay.getMonth();
}
/**
 * Is the date in the last week of a month
 * @param {Date} date
 * @returns {boolean}
 */


function isLastWeek(date) {
  const nextWeek = new Date(date);
  nextWeek.setDate(nextWeek.getDate() + 7);
  return date.getMonth() != nextWeek.getMonth();
}

function formatDate(date) {
  const asString = date.toLocaleDateString('en-US', {
    month: 'short',
    year: 'numeric'
  });
  return `${date.getDate()} ${asString}`;
}

function formatTime(date) {
  return date.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: 'numeric',
    // hour12: false,
    hourCycle: 'h23'
  });
}

function formatLocaleDate(date) {
  const day = date.getDate();
  const month = ['януари', 'февруари', 'март', 'април', 'май', 'юни', 'юли', 'август', 'септември', 'октомври', 'ноември', 'декември'][date.getMonth()];
  return `${day} ${month}`;
}

function formatLocaleWeekday(day, getAdj) {
  const weekday = ['неделя', 'понеделник', 'вторник', 'сряда', 'четвъртък', 'петък', 'събота'][day];

  if (getAdj) {
    return [weekday, ['всяка', 'всеки', 'всеки', 'всяка', 'всеки', 'всеки', 'всяка'][day]];
  }

  return weekday;
}
/**
 * Get a new date offset by the specified number of days
 * @param {Date} date Base date
 * @param {number} days How many days to offset
 * @returns {Date}
 */


function getOffsetByDays(date, days) {
  const result = new Date(date);
  result.setUTCDate(result.getUTCDate() + days);
  return result;
}
/**
 * Offset the given date in place by the specified number of days
 * @param {Date} date Base date
 * @param {number} days How many days to offset
 */

function offsetByDays(date, days) {
  date.setUTCDate(date.getUTCDate() + days);
}
/**
 * Create date index as string
 * @param {Date|string} date Base date
 * @returns {string}
 */

function getDateIndex(date) {
  if (typeof date == 'string') {
    date = new Date(date);
  }

  return date.toISOString().slice(0, 10);
}

function prettyJSON(obj) {
  return JSON.stringify(obj, null, 2).replace(/ /gmi, '&nbsp;').replace(/\n/gmi, '<br>');
}

function getMonday(date) {
  const monday = new Date(`${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()} 12:00:00`);
  monday.setDate(monday.getDate() - (monday.getDay() + 6) % 7);
  return monday;
}

function getSunday(date) {
  const sunday = new Date(`${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()} 23:59:59`);
  sunday.setDate(sunday.getDate() + (7 - sunday.getDay()) % 7);
  return sunday;
}

const monthName = {
  1: 'January',
  2: 'February',
  3: 'March',
  4: 'April',
  5: 'May',
  6: 'June',
  7: 'July',
  8: 'August',
  9: 'September',
  10: 'October',
  11: 'November',
  12: 'December'
};
const localeMonthName = {
  1: 'януари',
  2: 'февруари',
  3: 'март',
  4: 'април',
  5: 'май',
  6: 'юни',
  7: 'юли',
  8: 'август',
  9: 'септември',
  10: 'октомври',
  11: 'ноември',
  12: 'декември'
};

function toAssocArray(p, c, i, a) {
  p[c.Id] = c;
  return p;
}

function toCustomAssocArray(indexName, overwrite = false) {
  return (p, c, i, a) => {
    if (p[c[indexName]] !== undefined && overwrite == false) {
      if (Array.isArray(p[c[indexName]])) {
        p[c[indexName]].push(c);
      } else {
        p[c[indexName]] = [p[c[indexName]], c];
      }
    } else {
      p[c[indexName]] = c;
    }

    return p;
  };
}
/**
 * @param {Array<SUPayment>} data 
 * @returns {Array<PaymentViewModel>}
 */

function paymentsToMatrix(data) {
  const template = ['Id', 'PaymentNumber', 'ModuleNameEn', 'PaymentPackagesAsString', 'PaidForUserName', 'Price', 'EducationalForm', 'PaymentDateTime'];
  const parsed = data.map(e => {
    e.EducationalForm = e.EducationalForm == 1 ? 'online' : 'onsite';
    const entry = [];

    for (let prop of template) {
      if (prop === 'PaymentDateTime') {
        entry.push(new Date(e[prop]));
      } else {
        entry.push(e[prop]);
      }
    }

    return entry;
  });
  return [template, ...parsed];
}

function uuid() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    let r = Math.random() * 16 | 0,
        v = c == 'x' ? r : r & 0x3 | 0x8;
    return v.toString(16);
  });
}
function normalizeDateTime(datetime) {
  if (!datetime) {
    return '';
  } else if (datetime.toString().includes('Date(')) {
    const match = /Date\((.+)\)/.exec(datetime);

    if (match !== null) {
      const d = new Date(Number(match[1]));
      return `${('0000' + d.getFullYear()).slice(-4)}-${pt(d.getMonth() + 1)}-${pt(d.getDate())}T${pt(d.getHours())}:${pt(d.getMinutes())}`;
    } else {
      return datetime;
    }
  } else {
    return datetime;
  }
}

function pt(s) {
  return `0${s}`.slice(-2);
}

function htmlToText(html) {
  const div = document.createElement('div');
  div.innerHTML = html;
  return div.textContent;
}

function instanceMetaFromHref(href) {
  const instanceMeta = queryString(href);

  instanceMeta.InstanceRefType = (() => {
    switch (instanceMeta.type) {
      case 'course':
        return 'main';

      case 'fast-track':
        return 'open';

      case 'general-course-instance':
        return 'general';
    }
  })();

  return instanceMeta;
}
function hasValue(value) {
  return value !== null && value !== undefined && value !== '';
}
function valueOrEmpty(value, alt = '') {
  if (value === null || value === undefined || value === '') {
    return alt;
  } else {
    return value;
  }
}
function sumArrayMax(arr) {
  if (arr[0].length == 0 && arr[1].length == 0) {
    return null;
  }

  let result = 0;

  if (arr[0].length > 0) {
    result += Math.max(...arr[0]);
  }

  if (arr[1].length > 0) {
    result += Math.max(...arr[1]);
  }

  return result;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  queryString,
  dateDiff,
  dateDiffToDays,
  isLastDay,
  isLastWeek,
  formatDate,
  formatTime,
  formatLocaleDate,
  formatLocaleWeekday,
  prettyJSON,
  getMonday,
  getSunday,
  monthName,
  localeMonthName,
  toAssocArray,
  paymentsToMatrix,
  htmlToText
});


/***/ }),

/***/ "./src/util/template.js":
/*!******************************!*\
  !*** ./src/util/template.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Alert": () => (/* binding */ Alert),
/* harmony export */   "Autocomplete": () => (/* binding */ Autocomplete),
/* harmony export */   "Container": () => (/* binding */ Container),
/* harmony export */   "DownloadProgressBar": () => (/* binding */ DownloadProgressBar),
/* harmony export */   "Loading": () => (/* binding */ Loading),
/* harmony export */   "No": () => (/* binding */ No),
/* harmony export */   "Question": () => (/* binding */ Question),
/* harmony export */   "Remote": () => (/* binding */ Remote),
/* harmony export */   "Spinner": () => (/* binding */ Spinner),
/* harmony export */   "Yes": () => (/* binding */ Yes),
/* harmony export */   "applyBeginRequest": () => (/* binding */ applyBeginRequest),
/* harmony export */   "applyRequestError": () => (/* binding */ applyRequestError),
/* harmony export */   "applyRequestSuccess": () => (/* binding */ applyRequestSuccess),
/* harmony export */   "createCheckbox": () => (/* binding */ createCheckbox),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "element": () => (/* binding */ element),
/* harmony export */   "getEditorDecoration": () => (/* binding */ getEditorDecoration),
/* harmony export */   "popupTable": () => (/* binding */ popupTable),
/* harmony export */   "replaceContents": () => (/* binding */ replaceContents),
/* harmony export */   "swap": () => (/* binding */ swap),
/* harmony export */   "table": () => (/* binding */ table)
/* harmony export */ });
/* harmony import */ var _parse__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parse */ "./src/util/parse.js");
/* harmony import */ var _util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/jsx-render-mod/dom */ "./src/util/jsx-render-mod/dom.js");


/**
 * 
 * @param {*} type 
 * @param {*} content 
 * @param {*} attributes 
 * @param {{forceType: 'Text' | 'HTML'}} options 
 * @returns 
 */

function element(type, content, attributes, options = undefined) {
  const result = document.createElement(type);

  if (attributes) {
    for (let attr of Object.keys(attributes)) {
      result[attr] = attributes[attr];
    }
  }

  result.append = append.bind(result);

  result.appendTo = parent => {
    parent.append(result);
    return result;
  };

  if (content !== undefined && content !== null) {
    result.append(content, options);
  }

  return result;
}

function append(child, options = undefined) {
  if (typeof child === 'string' || typeof child === 'number') {
    if (options?.forceType != 'Text' && (options?.forceType === 'HTML' || child.toString().trim()[0] === '<')) {
      this.innerHTML = child;
    } else {
      child = document.createTextNode(child);
      this.appendChild(child);
    }
  } else if (Array.isArray(child)) {
    for (let node of child) {
      append.call(this, node);
    }
  } else {
    this.appendChild(child);
  }

  return this;
}

function replaceContents(node, newContents) {
  const cNode = node.cloneNode(false);
  append.call(cNode, newContents);

  try {
    node.parentNode.replaceChild(cNode, node);
  } catch (err) {
    console.info('Node has no parent or another problem occured');
  }

  return cNode;
}
function swap(oldNode, newNode) {
  oldNode.parentNode.replaceChild(newNode, oldNode);
  return newNode;
}
function Spinner({
  id
}) {
  const node = element('div', [element('div', null, {
    classList: 'sk-cube sk-cube1'
  }), element('div', null, {
    classList: 'sk-cube sk-cube2'
  }), element('div', null, {
    classList: 'sk-cube sk-cube3'
  }), element('div', null, {
    classList: 'sk-cube sk-cube4'
  }), element('div', null, {
    classList: 'sk-cube sk-cube5'
  }), element('div', null, {
    classList: 'sk-cube sk-cube6'
  }), element('div', null, {
    classList: 'sk-cube sk-cube7'
  }), element('div', null, {
    classList: 'sk-cube sk-cube8'
  }), element('div', null, {
    classList: 'sk-cube sk-cube9'
  })], {
    classList: 'sk-cube-grid'
  });

  if (id) {
    node.setAttribute('id', id);
  }

  return node;
}
function Loading({
  id,
  color = 'white'
}) {
  const node = element('div', [element('div', null, {
    classList: 'rect1'
  }), element('div', null, {
    classList: 'rect2'
  }), element('div', null, {
    classList: 'rect3'
  }), element('div', null, {
    classList: 'rect4'
  }), element('div', null, {
    classList: 'rect5'
  })], {
    classList: getClass()
  });

  if (id) {
    node.setAttribute('id', id);
  }

  return node;

  function getClass() {
    return `spinner ${color}`;
  }
}
function Remote({
  src,
  parse,
  component,
  color = 'white',
  onReady,
  onError
}) {
  const id = (0,_parse__WEBPACK_IMPORTED_MODULE_0__.uuid)();
  resolve();
  const loader = Loading({
    id,
    color
  });
  return loader;

  async function resolve() {
    let data = await (async () => {
      try {
        return (await (src instanceof Promise)) ? src : src();
      } catch (e) {
        if (onError) {
          onError(e, loader);
          throw e;
        }

        const retryBtn = element('button', [element('i', null, {
          className: 'glyphicon glyphicon-repeat'
        }), 'Retry'], {
          style: 'background-color: green'
        });
        retryBtn.addEventListener('click', () => {
          replaceSelf(Remote({
            src,
            parse,
            component,
            color
          }));
        });
        return element('div', [element('i', null, {
          className: 'glyphicon glyphicon-remove',
          style: 'color: red'
        }), e.message, retryBtn], {
          id: id
        });
      }
    })();

    if (parse) {
      data = parse(data);
    }

    replaceSelf(data);

    function replaceSelf(data) {
      //const loader = document.getElementById(id);
      const parent = loader.parentNode;

      if (component) {
        parent.insertBefore(component(data), loader);
      } else {
        append(data);
      } //await new Promise(resolve => setTimeout(10, resolve));
      //console.log(document.getElementById(id));


      loader.remove();

      if (onReady) {
        onReady();
      }

      function append(child) {
        if (typeof child === 'string' || typeof child === 'number') {
          if (child.toString().trim()[0] === '<') {
            const fragment = element('div', child);
            fragment.childNodes.forEach(n => parent.insertBefore(n.cloneNode(true), loader));
          } else {
            parent.insertBefore(document.createTextNode(child), loader);
          }
        } else if (Array.isArray(child)) {
          for (let node of child) {
            append(node);
          }
        } else {
          parent.insertBefore(child, loader);
        }
      }
    }
  }
}
function Yes() {
  const el = document.createElement('i');
  el.className = 'glyphicon glyphicon-ok';
  el.style.color = 'green';
  return el;
}
function No() {
  const el = document.createElement('i');
  el.className = 'glyphicon glyphicon-remove';
  el.style.color = 'red';
  return el;
}
function Question([title, answers]) {
  return element('div', [element('h2', title), element('ul', Object.entries(answers).map(([a, isCorrect]) => element('li', a, {
    classList: isCorrect ? 'correct-answer' : 'none'
  }, true)))], {
    classList: 'question-container'
  });
}
;
function Alert() {
  const el = document.createElement('i');
  el.className = 'glyphicon glyphicon-warning-sign';
  el.style.color = 'orange';
  return el;
}
function Container({
  children,
  className
}) {
  const section = element('section', children, {
    className: className ? 'event-container' : 'container'
  });
  const el = element('div', section, {
    className: className ? className : 'container administration-container ses-container'
  });
  return el;
}
function popupTable(data) {
  let html = `
        <style>
            table {
                border-collapse: collapse;
            }
            tr, td, th {
                border: 1px solid black;
                padding: 0.25em 0.5em;
            }
        </style>
        `;
  html += '<table><thead><tr>';

  for (let col of data[0]) {
    html += `<th>${col}</th>`;
  }

  html += '</tr></thead><tbody>';

  for (let row = 1; row < data.length; row++) {
    html += '<tr>';

    for (let col of data[row]) {
      html += `<td>${col}</td>`;
    }

    html += '</tr>';
  }

  html += '</tbody></table>';
  return html;
}
function getEditorDecoration(element) {
  function enable() {
    element.classList.add('enabled');
  }

  function disable() {
    element.classList.remove('enabled');
  }

  function working() {
    element.classList.remove('enabled');
    element.classList.add('working');
  }

  function updated() {
    element.classList.remove('working');
    element.classList.add('updated');
    setTimeout(() => element.classList.remove('updated'), 3000);
  }

  function failure() {
    element.classList.remove('working');
    element.classList.add('failed');
  }

  function _clear() {
    element.classList.remove('enabled');
    element.classList.remove('working');
    element.classList.remove('updated');
    element.classList.remove('failed');
  }

  return {
    enable,
    disable,
    working,
    updated,
    failure,
    _clear
  };
}
function applyBeginRequest(element) {
  element.childNodes.forEach(c => c.childNodes.forEach(n => n.disabled = true));
  element.classList.remove('enabled');
  element.classList.remove('failed');
  element.classList.add('working');
}
function applyRequestSuccess(element) {
  element.classList.remove('working');
  element.classList.add('updated');
  setTimeout(() => element.classList.remove('updated'), 3000);
}
function applyRequestError(refElement, errorContainer, fields) {
  refElement.childNodes.forEach(c => c.childNodes.forEach(n => n.disabled = false));
  refElement.classList.remove('working');
  refElement.classList.add('failed');
  console.warn(errorContainer);

  if (errorContainer.message !== undefined) {
    alert(errorContainer.message);
  } else {
    for (let error of Object.keys(errorContainer)) {
      if (error.length == 0) {
        alert(errorContainer[error].errors.join('\n'));
      } else {
        const field = fields[error];

        for (let message of errorContainer[error].errors) {
          field.appendChild(element('p', message));
        }
      }
    }
  }
}
function createCheckbox(name, data, text, onChange, defaultValue = false) {
  const id = 'ses-' + name;
  let value = readPrevInput();
  data[name] = value;
  let element = document.createElement('input');
  element.type = 'checkbox';
  element.id = id;
  element.name = name;
  let label = document.createElement('label');
  label.htmlFor = id;
  label.textContent = text;
  /*
  let element = <input type="checkbox" className="ses-check" id={id} name={name} />;
  let label = <label for={id}>{text}</label>;
  */

  element.checked = value;
  element.addEventListener('change', toggle);

  function readPrevInput() {
    let prevInput = document.getElementById(id);

    if (prevInput) {
      return prevInput.checked;
    } else {
      return defaultValue;
    }
  }

  function toggle(e) {
    value = e.target.checked;
    data[name] = value;
    redraw();
  }

  function redraw() {
    try {
      onChange();
    } catch (err) {
      console.log(err.message);
    }
  }

  const checkbox = {
    element,
    label
  };
  Object.defineProperty(checkbox, 'value', {
    get: () => value,
    set: newValue => {
      value = newValue;
      element.checked = value;
      data[name] = value;
      redraw();
    }
  });
  return checkbox;
}
function table(data, layout) {
  const thead = element('thead', element('tr', layout.map(h => element('th', h.label))));
  const tbody = element('tbody', data.map(r => element('tr', layout.map(h => element('td', r[h.name])))));
  const table = element('table', [thead, tbody]);
  table.thead = thead;
  table.tbody = tbody;
  return table;
}
function Autocomplete({
  values,
  current
}) {
  let autocomplete = element('div', [element('input', undefined, {
    className: 'ses-search-autocomplete-input'
  }), element('div', element('ul'), {
    className: 'ses-search-autocomplete-suggestions'
  })], {
    className: 'ses-search-autocomplete-container'
  });
  const suggestionsContainer = autocomplete.querySelector('.ses-search-autocomplete-suggestions');
  const input = autocomplete.querySelector('.ses-search-autocomplete-input');
  let selectedIndex = undefined;

  if (current != undefined) {
    input.value = current;
  }

  autocomplete.getValue = function () {
    return input.value;
  };

  function searchHandler(e) {
    const inputVal = e.currentTarget.value;
    let results = values;

    if (inputVal.length > 0) {
      results = values.filter(x => x.toLowerCase().indexOf(inputVal.toLowerCase()) > -1);
    }

    showSuggestions(results, inputVal);

    if (e.keyCode === 38 || e.keyCode === 40 || e.keyCode === 13) {
      scrollResults(e);
    }
  }

  function showSuggestions(results, inputVal) {
    let suggestions = suggestionsContainer.querySelector('ul');
    replaceContents(suggestions, '');
    suggestions = suggestionsContainer.querySelector('ul');
    ;

    if (results.length > 0) {
      for (let i = 0; i < results.length; i++) {
        let item = results[i];
        const match = item.match(new RegExp(inputVal, 'i'));
        item = item.replace(match[0], `<strong>${match[0]}</strong>`);
        let newLi = element('li', item, undefined, {
          forceType: "HTML"
        });
        suggestions.appendChild(newLi);
      }

      suggestions.classList.add('has-suggestions');
    } else {
      suggestions.classList.remove('has-suggestions');
    }
  }

  function useSuggestion(e) {
    input.value = e.target.textContent;
    input.focus();
    let suggestions = suggestionsContainer.querySelector('ul');
    replaceContents(suggestions, '');
    suggestions = suggestionsContainer.querySelector('ul');
    suggestions.classList.remove('has-suggestions');
  }

  function scrollResults(e) {
    let allSuggestions = [...suggestionsContainer.querySelectorAll('ul li')];
    let oldIndex = undefined;
    let indexChange = 1; // enter

    if (e.keyCode === 13) {
      input.value = allSuggestions[selectedIndex].textContent;
      selectedIndex = undefined;
      let suggestions = suggestionsContainer.querySelector('ul');
      suggestions.classList.remove('has-suggestions');
      return;
    }

    if (e.keyCode === 40) {
      // down arrow
      indexChange = 1;
    } else if (e.keyCode === 38) {
      // up arrow
      indexChange = -1;
    }

    if (selectedIndex == undefined) {
      selectedIndex = indexChange === 1 ? 0 : allSuggestions.length - 1;
    } else {
      oldIndex = selectedIndex;
      selectedIndex = (selectedIndex + indexChange + allSuggestions.length) % allSuggestions.length;
    }

    if (oldIndex !== undefined && oldIndex < allSuggestions.length) {
      allSuggestions[oldIndex].classList.remove('selected');
    }

    allSuggestions[selectedIndex].classList.add('selected');
  }

  input.addEventListener('keyup', searchHandler);
  suggestionsContainer.addEventListener('click', useSuggestion);
  return autocomplete;
}
/**
 * Creates a span element that represents a download progress bar
 * @param { {downloadFunction: (onProgress: import('./util.js').OnProgressFunction), returnFunction: function} } settings Contains the function that will download the resources, which will be called with onProgress
 * and the returnFunction which will be called with the results after the download finishes
 */

function DownloadProgressBar({
  downloadFunction,
  returnFunction
}) {
  const percent = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_1__["default"])("span", null, "0%");
  const bar = (0,_util_jsx_render_mod_dom__WEBPACK_IMPORTED_MODULE_1__["default"])("span", {
    style: {
      padding: '0 0.5em',
      display: 'inline-block',
      width: '25%',
      background: 'linear-gradient(to right, #ffa000 0%, #eee 0)'
    }
  }, percent, " \u0421\u0432\u0430\u043B\u044F\u043D\u0435");
  downloadFunction(onProgress).then(data => {
    if (returnFunction) {
      returnFunction(data);
    }
  });
  return bar;

  function onProgress(completed, total, response, index) {
    const progress = Math.floor(completed / total * 100);
    percent.textContent = progress + '%';
    bar.style.background = `linear-gradient(to right, #ffa000 ${progress}%, #eee 0)`;
  }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  element
});

/***/ }),

/***/ "./src/util/util.js":
/*!**************************!*\
  !*** ./src/util/util.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "assertTemplate": () => (/* binding */ assertTemplate),
/* harmony export */   "createThrottledExecutor": () => (/* binding */ createThrottledExecutor),
/* harmony export */   "crossBrowserFileUpload": () => (/* binding */ crossBrowserFileUpload),
/* harmony export */   "distribute": () => (/* binding */ distribute),
/* harmony export */   "download": () => (/* binding */ download),
/* harmony export */   "escapeHTML": () => (/* binding */ escapeHTML),
/* harmony export */   "exportPaymentsToXlsx": () => (/* binding */ exportPaymentsToXlsx),
/* harmony export */   "exportToJson": () => (/* binding */ exportToJson),
/* harmony export */   "exportToXlsx": () => (/* binding */ exportToXlsx),
/* harmony export */   "getExcludedModuleInstances": () => (/* binding */ getExcludedModuleInstances),
/* harmony export */   "getExcludedModules": () => (/* binding */ getExcludedModules),
/* harmony export */   "getFundamentalLevelIds": () => (/* binding */ getFundamentalLevelIds),
/* harmony export */   "getLocale": () => (/* binding */ getLocale),
/* harmony export */   "getMime": () => (/* binding */ getMime),
/* harmony export */   "getProfessionInstanceIds": () => (/* binding */ getProfessionInstanceIds),
/* harmony export */   "getSubsite": () => (/* binding */ getSubsite),
/* harmony export */   "hasCPOAccess": () => (/* binding */ hasCPOAccess),
/* harmony export */   "iconAsset": () => (/* binding */ iconAsset),
/* harmony export */   "importFromXlsx": () => (/* binding */ importFromXlsx),
/* harmony export */   "importQuizFromXlsx": () => (/* binding */ importQuizFromXlsx),
/* harmony export */   "isAdmin": () => (/* binding */ isAdmin),
/* harmony export */   "openFile": () => (/* binding */ openFile),
/* harmony export */   "roundUpWithPrecision": () => (/* binding */ roundUpWithPrecision),
/* harmony export */   "serializeCalls": () => (/* binding */ serializeCalls),
/* harmony export */   "toLegacyXlsFile": () => (/* binding */ toLegacyXlsFile),
/* harmony export */   "toXlsxFile": () => (/* binding */ toXlsxFile),
/* harmony export */   "withProgress": () => (/* binding */ withProgress),
/* harmony export */   "zipFiles": () => (/* binding */ zipFiles)
/* harmony export */ });
/* harmony import */ var _parse__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parse */ "./src/util/parse.js");
/* globals xlsx, JSZip */

function importQuizFromXlsx(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = function (e) {
      const fileData = e.target.result;
      const wb = xlsx.read(fileData, {
        type: 'binary'
      });
      const firstSheet = wb.Sheets[wb.SheetNames[0]];
      const apiData = xlsx.utils.sheet_to_json(firstSheet, {
        header: 1
      }).slice(1) // remove first row
      .reduce((data, currentRow) => {
        if (currentRow.length !== 0) {
          const correctAnswerIndex = currentRow.pop();
          const question = currentRow[0];
          const allAnswers = currentRow.slice(1);
          const correctAnswer = currentRow[correctAnswerIndex];
          data[question] = allAnswers.reduce((answers, a) => {
            if (a != undefined && a.toString().trim() !== '') {
              answers[a] = a === correctAnswer;
            }

            return answers;
          }, {});
        }

        return data;
      }, {});
      resolve(apiData);
    };

    reader.readAsBinaryString(blob);
  });
}
function importFromXlsx(blob, useCellDates = false) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = function (e) {
      const file = e.target.result;

      try {
        const wb = xlsx.read(file, {
          type: 'binary',
          cellDates: useCellDates
        });
        const firstSheet = wb.Sheets[wb.SheetNames[0]];
        const data = xlsx.utils.sheet_to_json(firstSheet, {
          header: 1
        });
        resolve(data);
      } catch (err) {
        console.log('Error parsing XLSX file, make sure the library is loaded');
        reject(err);
      }
    };

    reader.onerror = function (e) {
      console.log('Error reading file');
      reject(e);
    };

    reader.readAsBinaryString(blob);
  });
}
function toXlsxFile(table, name = 'Output', ws_name) {
  if (ws_name === undefined) {
    ws_name = name.slice(0, 31);
  }

  const wb = xlsx.utils.book_new(),
        ws = xlsx.utils.aoa_to_sheet(table); // wb.Workbook = { Views: ['Window2'] };

  xlsx.utils.book_append_sheet(wb, ws, ws_name);
  const data = xlsx.write(wb, {
    type: 'array',
    bookType: 'xlsx'
  });
  const file = new File([data], name + '.xlsx', {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  });
  return file;
}
function toLegacyXlsFile(table, name = 'Output', ws_name) {
  if (ws_name === undefined) {
    ws_name = name.slice(0, 31);
  }

  const wb = xlsx.utils.book_new(),
        ws = xlsx.utils.aoa_to_sheet(table);
  wb.Workbook = {
    Views: ['Window2']
  };
  xlsx.utils.book_append_sheet(wb, ws, ws_name);
  const data = xlsx.write(wb, {
    type: 'array',
    bookType: 'biff8'
  });
  const file = new File([data], name + '.xls', {
    type: 'application/vnd.ms-excel'
  });
  return file;
}
function exportToXlsx(table, name = 'Output', ws_name) {
  const filename = `${name}.xlsx`;

  if (ws_name === undefined) {
    ws_name = name.slice(0, 31);
  } // Sheet name cannot contain: \ / ? * [ ]


  const sheetRegex = /[\[\]\\\/\*]/gi;

  if (sheetRegex.test(ws_name)) {
    ws_name = ws_name.replace(sheetRegex, '-');
  }

  const wb = xlsx.utils.book_new(),
        ws = xlsx.utils.aoa_to_sheet(table);
  xlsx.utils.book_append_sheet(wb, ws, ws_name);
  xlsx.writeFile(wb, filename);
}
function exportPaymentsToXlsx(data, year, month) {
  const filename = `Payments-${_parse__WEBPACK_IMPORTED_MODULE_0__["default"].monthName[month]}-${year}.xlsx`;
  const ws_name = `Payments ${_parse__WEBPACK_IMPORTED_MODULE_0__["default"].monthName[month]} ${year}`;
  const wb = xlsx.utils.book_new(),
        ws = xlsx.utils.aoa_to_sheet(data);
  xlsx.utils.book_append_sheet(wb, ws, ws_name);
  xlsx.writeFile(wb, filename);
}
function exportToJson(data, name = 'Output') {
  const blob = new Blob([data], {
    type: 'application/json'
  });

  if (window.navigator.msSaveOrOpenBlob) {
    window.navigator.msSaveBlob(blob, name + '.json');
  } else {
    var elem = window.document.createElement('a');
    elem.href = window.URL.createObjectURL(blob);
    elem.download = name + '.json';
    document.body.appendChild(elem);
    elem.click();
    document.body.removeChild(elem);
  }
}
/**
 * @param {{folder: string, files: File[]}[]} files 
 */

async function zipFiles(files) {
  const zip = new JSZip();

  for (let entry of files) {
    const current = zip.folder(entry.folder);
    current.file(entry.files.photo.name, await blobToBase64(entry.files.photo.file), {
      base64: true
    });
    current.file(entry.files.medical.name, await blobToBase64(entry.files.medical.file), {
      base64: true
    });
    current.file(entry.files.diploma.name, await blobToBase64(entry.files.diploma.file), {
      base64: true
    });
  }

  return zip.generateAsync({
    type: 'blob'
  });

  function blobToBase64(blob) {
    return new Promise(resolve => {
      const reader = new FileReader();

      reader.onload = function () {
        const dataUrl = reader.result;
        const base64 = dataUrl.split(',')[1];
        resolve(base64);
      };

      reader.readAsDataURL(blob);
    });
  }

  ;
}
const mimes = {
  'bmp': 'image/bmp',
  'gif': 'image/gif',
  'jpeg': 'image/jpeg',
  'jpg': 'image/jpeg',
  'png': 'image/png',
  'pdf': 'application/pdf',
  'tif': 'image/tiff',
  'tiff': 'image/tiff',
  'webp': 'image/webp',
  'zip': 'application/zip',
  '7z': 'application/x-7z-compressed',
  'tar': 'application/x-tar',
  'rar': 'application/vnd.rar'
};
function getMime(extension) {
  extension = extension.toLocaleLowerCase();
  return mimes[extension] || 'application/octet-stream';
}
async function openFile(file, name = 'output.txt') {
  try {
    var elem = window.document.createElement('a');
    elem.target = '_blank';
    elem.download = name;
    const href = window.URL.createObjectURL(file);
    elem.href = href;
    elem.click();
    setTimeout(() => URL.revokeObjectURL(href), 60000);
  } catch (err) {
    console.error(err);
  }
}
function download(blob, name = 'output.txt') {
  if (window.navigator.msSaveOrOpenBlob) {
    window.navigator.msSaveBlob(blob, name);
  } else {
    var elem = window.document.createElement('a');
    elem.target = '_blank';
    const href = window.URL.createObjectURL(blob);
    elem.href = href;
    elem.download = name;
    elem.click();
    setTimeout(() => URL.revokeObjectURL(href), 60000);
  }
}
async function crossBrowserFileUpload(apiCall, file) {
  if (!!window.chrome) {
    const fileUrl = URL.createObjectURL(file);
    const result = await apiCall({
      fileUrl,
      name: file.name
    });
    URL.revokeObjectURL(fileUrl);
    return result;
  } else {
    return await apiCall({
      file
    });
  }
}
function getSubsite() {
  switch (window.location.host.substr(0, 7)) {
    case 'digital':
      return 'digital';

    case 'creativ':
      return 'creative';

    case 'platfor':
      return 'platform';

    case 'ai.soft':
      return 'ai';

    case 'finance':
      return 'financeacademy';

    case 'dev.dig':
      return 'devdigital';

    case 'dev.sof':
      return 'devsoftuni';

    default:
      return 'programming';
  }
}
function hasCPOAccess() {
  return ['digital', 'creative', 'programming', 'devdigital', 'devsoftuni'].includes(getSubsite());
}
function isAdmin() {
  const e = document.querySelectorAll('a[href="/administration/navigation" i]');

  if (e.length > 0) {
    return true;
  } else {
    return false;
  }
}
function serializeCalls(fnArray, delay) {
  const callArray = [];

  if (delay !== undefined) {
    for (let i = 0; i < fnArray.length; i++) {
      const handler = (res, rej) => {
        setTimeout(async () => {
          try {
            const result = await fnArray[i]();
            res(result);
          } catch (err) {
            rej(err);
          }
        }, i * delay);
      };

      const pr = new Promise(handler);
      callArray.push(pr);
    }
  } else {
    for (let i = 0; i < fnArray.length; i++) {
      const handler = (res, rej) => {
        if (i > 0) {
          callArray[i - 1].finally(async () => {
            try {
              const result = await fnArray[i]();
              res(result);
            } catch (err) {
              rej(err);
            }
          });
        } else {
          fnArray[i]().then(res).catch(rej);
        }
      };

      const pr = new Promise(handler);
      callArray.push(pr);
    }
  }

  return callArray;
}
async function withProgress(callArray, onChange, delay = 10) {
  return new Promise((resolve, reject) => {
    // Failsave for empty callArray
    if (callArray.length == 0) {
      onChange(undefined, 0, 1, 1);
      resolve([]);
    }

    let resolved = 0;
    const response = [];
    callNext(0);

    function callNext(i) {
      if (i >= callArray.length) {
        return;
      } else {
        callArray[i].then(res => onResolve(res, i)).catch(onError);
        setTimeout(() => callNext(i + 1), delay);
      }
    }

    function onResolve(res, index) {
      resolved++;

      if (onChange) {
        onChange(res, index, resolved, callArray.length);
      }

      response[index] = res;

      if (resolved === callArray.length) {
        resolve(response);
      }
    }

    function onError(e) {
      reject(e);
    }
  });
}
/**
 * @typedef {(completed: number, total: number, response, index: number) => void} OnProgressFunction
 */

/**
 * @typedef {() => Promise} AsyncFunction
 */

/**
 * Initiate remote calls at intervals
 * @param {Array<AsyncFunction>} fnArray 
 * @param {OnProgressFunction} onProgress 
 * @param {number} [delay=10]
 * @returns 
 */

async function distribute(fnArray, onProgress, delay = 10) {
  return new Promise((resolve, reject) => {
    const total = fnArray.length;
    let completed = 0;
    let resolved = 0; // Failsave for empty fnArray

    if (total == 0) {
      if (typeof onProgress == 'function') {
        onProgress(undefined, 0, 1, 1);
      }

      resolve([]);
    }

    const calls = fnArray.map((fn, i) => {
      const call = {
        fn,
        sent: false,
        cancelled: false,
        response: undefined,
        timer: null
      };
      call.onCall = onCall.bind(call, i);
      call.cancel = onCancel.bind(call);
      call.timer = setTimeout(call.onCall, i * delay);
      return call;
    });
    calls.forEach((c, i) => c.next = calls[i + 1]);

    async function onCall(i) {
      if (this.sent == false) {
        clearTimeout(this.timer);
      }

      if (this.cancelled == false) {
        this.sent = true;

        try {
          const promise = this.fn();
          this.response = await promise;

          if (promise._cacheHit && this.next) {
            this.next.onCall();
          }

          resolved++;

          if (this.cancelled == false && resolved === total) {
            resolve(calls.map(c => c.response));
          }
        } catch (err) {
          onError(err);
        }
      }

      completed++;

      if (typeof onProgress == 'function') {
        onProgress(completed, total, this.response, i);
      }
    }

    function onCancel() {
      if (this.cancelled == false) {
        this.cancelled = true;

        if (this.sent == false) {
          clearTimeout(this.timer);
          this.onCall();
        }
      }
    }

    function onError(e) {
      calls.forEach(c => c.cancel());

      if (e instanceof Error) {
        e._responses = calls.map(c => c.response);
      }

      reject(e);
    }
  });
}
function assertTemplate(template, target, bottom = false) {
  if (template.Data !== undefined && template.Total !== undefined) {
    template = template.Data;
    target = target.Data;
  }

  if (Array.isArray(template)) {
    if (Array.isArray(target)) {
      if (bottom) {
        return;
      } else {
        assertTemplate(template[0], target[0], true);
      }
    } else {
      throw new TypeError('Target type mismatch');
    }
  } else if (typeof template === 'object') {
    if (typeof target === 'object') {
      const model = Object.keys(template);

      for (let prop of model) {
        if (target.hasOwnProperty(prop) === false) {
          throw new TypeError('Missing property on target: ' + prop);
        }
      }
    } else {
      throw new TypeError('Target type mismatch');
    }
  } else if (typeof template !== typeof target) {
    throw new TypeError('Target type mismatch');
  } else {
    return true;
  }
}
function getLocale() {
  return 'bg';
}
function createThrottledExecutor(callback, delay) {
  let timer = null;
  return function (...params) {
    clear();
    timer = setTimeout(() => {
      clear();
      callback(...params);
    }, delay);
  };

  function clear() {
    if (timer !== null) {
      clearTimeout(timer);
    }
  }
}
function iconAsset(name) {
  return browser.runtime.getURL(`icons/${name}.png`);
}
function escapeHTML(str) {
  return str.replace(/[&<>]/g, tag => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;'
  })[tag]);
}
;
function getFundamentalLevelIds(appname) {
  return {
    'programming': [19, 44, 57, 70, 106],
    'digital': [6, 7, 8, 23, 24, 25, 27, 33, 35, 40],
    'creative': [23, 24, 42, 52]
  }[appname];
}
function getProfessionInstanceIds(appname) {
  return {
    // Commented are for QA
    'programming': [1007, 1009, 1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1020, 1022, 1023, 1024, 1025, 1026, // 1028,
    1029, 1030, 1031, 1032, 1033, 1034, 1035, 1036, 1037, 1038, 1039, 1040, 1041, 1042, 1043, 1044, 1045, 1046, 1047, 1048, 1049, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1062, 1063, 1064, 1065, 1066, // 1067,
    // 1068,
    // 1069,
    1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078],
    'digital': [1, 3, 4, 5, 6, 7, 8, 9],
    'creative': [1, 3, 4, 5],
    'devdigital': [1, 3, 4, 5, 6, 7, 8, 9]
  }[appname];
}
function getExcludedModules(appname) {
  return {
    'programming': [2]
  }[appname];
}
function getExcludedModuleInstances(appname) {
  return {
    'digital': [5, 50],
    'creative': [1, 14, 28, 46],
    'devdigital': [5, 50]
  }[appname];
}
/**
 * @description Rounds up a number up to specified number of decimal places using a specified number of decimal places as precision.
 * This allows correct rounding of problematic floating point numbers like "55.00000000000001" or "0.460000000000001"
 * @param {Number} number The number to round up
 * @param {Number} decimalPlacesToRoundTo The number of decimal places to round to
 * @param {Number} decimalPlacesPrecision The number of decimal places that should be considered for the rounding. Should be larger than decimalPlacesToRoundTo
 * @returns The rounded number
 */

function roundUpWithPrecision(number, decimalPlacesToRoundTo, decimalPlacesPrecision) {
  if (decimalPlacesPrecision <= decimalPlacesToRoundTo) {
    throw new RangeError('decimalPlacesPrecision should be larger than decimalPlacesToRoundTo');
  }

  let precisionValue = 10 ** decimalPlacesPrecision;
  let roundingValue = 10 ** decimalPlacesToRoundTo;
  let roundingValueBigInt = BigInt(roundingValue);
  let precisionDifferenceValue = BigInt(precisionValue / roundingValue);
  let bigInt = BigInt(Math.trunc(number * precisionValue));
  let roundedPlacesNumberPart = bigInt / precisionDifferenceValue;
  let precisionDifferenceLeftover = bigInt % precisionDifferenceValue;
  roundedPlacesNumberPart += precisionDifferenceLeftover > 0 ? 1n : 0n;
  let numberPart = roundedPlacesNumberPart / roundingValueBigInt;
  let decimalPart = roundedPlacesNumberPart % roundingValueBigInt;
  let roundedNum = Number(`${numberPart}.${decimalPart.toString().padStart(decimalPlacesToRoundTo, '0')}`);
  return roundedNum;
}

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!****************************!*\
  !*** ./src/admin/admin.js ***!
  \****************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _util_template__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/template */ "./src/util/template.js");
/* harmony import */ var _util_util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/util */ "./src/util/util.js");


const tabIndexes = {
  trainings: {
    programming: 3,
    digital: 4,
    creative: 4,
    ai: 4,
    financeacademy: 4,
    devdigital: 4
  },
  stats: {
    programming: 14,
    digital: 10,
    creative: 10,
    ai: 10,
    financeacademy: 11,
    devdigital: 10
  },
  quiz: {
    programming: 13
  },
  stream: {
    programming: 1,
    digital: 3,
    creative: 3,
    ai: 3,
    financeacademy: 3,
    devdigital: 3
  }
};
insertMenus();

function insertMenus() {
  const subsite = (0,_util_util__WEBPACK_IMPORTED_MODULE_1__.getSubsite)();
  const menus = [];

  switch (subsite) {
    case 'programming':
      menus.push({
        index: tabIndexes.trainings[subsite],
        name: 'Course Manager',
        url: '/ses/course'
      });
      menus.push({
        index: tabIndexes.stats[subsite],
        name: 'Survey Aggregate',
        url: '/ses/surveys'
      });
      menus.push({
        index: tabIndexes.stats[subsite],
        name: 'Season Stats',
        url: '/ses/stats'
      });
      menus.push({
        index: tabIndexes.quiz[subsite],
        name: 'Quiz Management',
        url: '/ses/quiz'
      });
      menus.push({
        index: tabIndexes.stream[subsite],
        name: 'Stream Dashboard',
        url: '/ses/stream'
      });
      menus.push({
        index: tabIndexes.trainings[subsite],
        name: 'Trainings Overview',
        url: '/ses/overview'
      });
      break;

    case 'digital':
    case 'creative':
    case 'devdigital':
    case 'ai':
      menus.push({
        index: tabIndexes.trainings[subsite],
        name: 'Course Manager',
        url: '/ses/course'
      });
      menus.push({
        index: tabIndexes.stats[subsite],
        name: 'Survey Aggregate',
        url: '/ses/surveys'
      });
      menus.push({
        index: tabIndexes.stats[subsite],
        name: 'Season Stats',
        url: '/ses/stats'
      });
      menus.push({
        index: tabIndexes.stream[subsite],
        name: 'Stream Dashboard',
        url: '/ses/stream'
      });
      menus.push({
        index: tabIndexes.trainings[subsite],
        name: 'Trainings Overview',
        url: '/ses/overview'
      });
      break;

    case 'financeacademy':
      menus.push({
        index: tabIndexes.trainings[subsite],
        name: 'Course Manager',
        url: '/ses/course'
      });
      menus.push({
        index: tabIndexes.stats[subsite],
        name: 'Survey Aggregate',
        url: '/ses/surveys'
      });
      menus.push({
        index: tabIndexes.stream[subsite],
        name: 'Stream Dashboard',
        url: '/ses/stream'
      });
      menus.push({
        index: tabIndexes.trainings[subsite],
        name: 'Trainings Overview',
        url: '/ses/overview'
      });
      break;
  }

  menus.forEach(m => insertMenuItem(m.index, m.name, m.url, 'icons/icon48.png'));
}

function insertMenuItem(tabIndex, label, href, iconPath) {
  const iconURL = browser.runtime.getURL(iconPath);
  const container = document.querySelector('#AdministrationNavigation-' + tabIndex).children[0];
  const row = getOrCreateRow(container);
  const col = _util_template__WEBPACK_IMPORTED_MODULE_0__["default"].element('div', null, {
    classList: getStyle()
  });
  const anchor = _util_template__WEBPACK_IMPORTED_MODULE_0__["default"].element('a', [_util_template__WEBPACK_IMPORTED_MODULE_0__["default"].element('img', null, {
    title: label,
    src: iconURL,
    alt: label,
    classList: 'bottom-buffer'
  }), _util_template__WEBPACK_IMPORTED_MODULE_0__["default"].element('div', label, {
    classList: 'bottom-buffer'
  })], {
    href
  });
  col.append(anchor);
  row.append(col);

  function getOrCreateRow(container) {
    const lastRow = [...container.querySelectorAll('.row.bottom-buffer')].pop();
    const cols = lastRow.querySelectorAll('.col-md-3');

    if (cols.length < 4) {
      return lastRow;
    } else {
      const row = _util_template__WEBPACK_IMPORTED_MODULE_0__["default"].element('div', null, {
        classList: 'row no-margin-offset text-center bottom-buffer'
      });
      container.appendChild(row);
      return row;
    }
  }
}

function getStyle() {
  switch ((0,_util_util__WEBPACK_IMPORTED_MODULE_1__.getSubsite)()) {
    case 'programming':
      return 'col-md-3';

    case 'digital':
    case 'creative':
    case 'platform':
    case 'devdigital':
    case 'ai':
    case 'financeacademy':
      return 'col-md-3 no-padding';
  }
}
})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9kZXYvL2NvbnRlbnQtc2NyaXB0cy9hZG1pbi5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUtBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBWEE7QUFhQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUdBOzs7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwSEE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUdBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBTUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFFQTtBQUNBOztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBM0dBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUtBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFGQTtBQUlBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSkE7QUFNQTs7QUFFQTtBQUNBO0FBQ0E7QUFjQTtBQUNBOztBQUVBO0FBQ0E7O0FBU0E7QUFDQTtBQVNBOztBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWkE7QUFnQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFaQTs7QUFlQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFVQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUVBO0FBQ0E7O0FBR0E7QUFDQTtBQUNBO0FBQUE7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQUE7O0FBQ0E7QUFBQTs7QUFDQTtBQUFBO0FBSEE7QUFLQTs7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFqQkE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM3VUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTs7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7O0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUVBOztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQUE7QUFFQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSkE7QUFNQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBR0E7QUFBQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7OztBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFOQTtBQVFBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBUEE7QUFVQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBOztBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQURBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0Z0JBO0FBRUE7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7QUFDQTtBQUFBO0FBREE7QUFJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFJQTtBQUNBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUFBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUFBO0FBQUE7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFLQTtBQUFBO0FBQUE7QUFFQTtBQUNBO0FBRUE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7OztBQUdBOztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFBQTtBQUFBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQ0E7O0FBQ0E7QUFBQTtBQUFBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFBQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWJBO0FBZ0JBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFoQkE7QUFrQkE7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUNBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUdBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMQTtBQU9BO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBSEE7QUFLQTtBQUFBO0FBR0E7QUFDQTtBQUNBO0FBT0E7QUFZQTtBQXBCQTtBQTJCQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBbUJBO0FBdUNBO0FBQ0E7QUFDQTtBQVVBO0FBVUE7QUFNQTtBQXhGQTtBQW1HQTtBQUVBO0FBQ0E7QUFDQTtBQURBO0FBS0E7QUFFQTtBQUNBO0FBQ0E7QUFJQTtBQU1BO0FBWEE7QUFnQkE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBOzs7Ozs7QUNyckJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7OztBQ3ZCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7OztBQ1BBOzs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FDTkE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFOQTtBQVFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTkE7QUFRQTtBQUNBO0FBREE7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU5BO0FBcEJBO0FBOEJBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBOztBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBeEJBOztBQTBCQTtBQUNBOztBQUdBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQURBO0FBR0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUpBO0FBT0E7QUFEQTtBQUlBO0FBREE7QUFJQTtBQUNBOztBQUdBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBREE7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBVEE7QUFXQSIsInNvdXJjZXMiOlsid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvdXRpbC9qc3gtcmVuZGVyLW1vZC9kb20uanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy91dGlsL2pzeC1yZW5kZXItbW9kL3V0aWxzLmpzIiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvdXRpbC9wYXJzZS5qcyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlLy4vc3JjL3V0aWwvdGVtcGxhdGUuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy91dGlsL3V0aWwuanMiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS93ZWJwYWNrL2Jvb3RzdHJhcCIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlL3dlYnBhY2svcnVudGltZS9kZWZpbmUgcHJvcGVydHkgZ2V0dGVycyIsIndlYnBhY2s6Ly9zb2Z0dW5pLWVuaGFuY2VtZW50LXN1aXRlL3dlYnBhY2svcnVudGltZS9oYXNPd25Qcm9wZXJ0eSBzaG9ydGhhbmQiLCJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS93ZWJwYWNrL3J1bnRpbWUvbWFrZSBuYW1lc3BhY2Ugb2JqZWN0Iiwid2VicGFjazovL3NvZnR1bmktZW5oYW5jZW1lbnQtc3VpdGUvLi9zcmMvYWRtaW4vYWRtaW4uanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgaXNTVkcsIGNyZWF0ZUZyYWdtZW50RnJvbSwgRVZFTlRfTElTVEVORVJTIH0gZnJvbSAnLi91dGlscyc7XHJcblxyXG4vKipcclxuICogVGhlIHRhZyBuYW1lIGFuZCBjcmVhdGUgYW4gaHRtbCB0b2dldGhlciB3aXRoIHRoZSBhdHRyaWJ1dGVzXHJcbiAqXHJcbiAqIEBwYXJhbSAge1N0cmluZ30gdGFnTmFtZSBuYW1lIGFzIHN0cmluZywgZS5nLiAnZGl2JywgJ3NwYW4nLCAnc3ZnJ1xyXG4gKiBAcGFyYW0gIHtPYmplY3R9IGF0dHJzIGh0bWwgYXR0cmlidXRlcyBlLmcuIGRhdGEtLCB3aWR0aCwgc3JjXHJcbiAqIEBwYXJhbSAge0FycmF5fSBjaGlsZHJlbiBodG1sIG5vZGVzIGZyb20gaW5zaWRlIGRlIGVsZW1lbnRzXHJcbiAqIEByZXR1cm4ge0hUTUxFbGVtZW50fFNWR0VsZW1lbnR9IGh0bWwgbm9kZSB3aXRoIGF0dHJzXHJcbiAqL1xyXG5mdW5jdGlvbiBjcmVhdGVFbGVtZW50cyh0YWdOYW1lLCBhdHRycywgY2hpbGRyZW4pIHtcclxuICAgIGNvbnN0IGVsZW1lbnQgPSBpc1NWRyh0YWdOYW1lKVxyXG4gICAgICAgID8gZG9jdW1lbnQuY3JlYXRlRWxlbWVudE5TKCdodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZycsIHRhZ05hbWUpXHJcbiAgICAgICAgOiBkb2N1bWVudC5jcmVhdGVFbGVtZW50KHRhZ05hbWUpO1xyXG5cclxuICAgIC8vIG9uZSBvciBtdWx0aXBsZSB3aWxsIGJlIGV2YWx1YXRlZCB0byBhcHBlbmQgYXMgc3RyaW5nIG9yIEhUTUxFbGVtZW50XHJcbiAgICBjb25zdCBmcmFnbWVudCA9IGNyZWF0ZUZyYWdtZW50RnJvbShjaGlsZHJlbik7XHJcbiAgICBlbGVtZW50LmFwcGVuZENoaWxkKGZyYWdtZW50KTtcclxuXHJcbiAgICBPYmplY3Qua2V5cyhhdHRycyB8fCB7fSkuZm9yRWFjaChwcm9wID0+IHtcclxuICAgICAgICBpZiAocHJvcCA9PT0gJ3N0eWxlJykge1xyXG4gICAgICAgICAgICAvLyBlLmcuIG9yaWdpbjogPGVsZW1lbnQgc3R5bGU9e3sgcHJvcDogdmFsdWUgfX0gLz5cclxuICAgICAgICAgICAgT2JqZWN0LmFzc2lnbihlbGVtZW50LnN0eWxlLCBhdHRyc1twcm9wXSk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChwcm9wID09PSAncmVmJyAmJiB0eXBlb2YgYXR0cnMucmVmID09PSAnZnVuY3Rpb24nKSB7XHJcbiAgICAgICAgICAgIGF0dHJzLnJlZihlbGVtZW50LCBhdHRycyk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChwcm9wID09PSAnY2xhc3NOYW1lJykge1xyXG4gICAgICAgICAgICBlbGVtZW50LnNldEF0dHJpYnV0ZSgnY2xhc3MnLCBhdHRyc1twcm9wXSk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChwcm9wID09PSAneGxpbmtIcmVmJykge1xyXG4gICAgICAgICAgICBlbGVtZW50LnNldEF0dHJpYnV0ZU5TKCdodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rJywgJ3hsaW5rOmhyZWYnLCBhdHRyc1twcm9wXSk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChwcm9wID09PSAnZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUwnKSB7XHJcbiAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby11bmRlcnNjb3JlLWRhbmdsZVxyXG4gICAgICAgICAgICBlbGVtZW50LmlubmVySFRNTCA9IGF0dHJzW3Byb3BdLl9faHRtbDtcclxuICAgICAgICB9IGVsc2UgaWYgKHByb3AgaW4gRVZFTlRfTElTVEVORVJTKSB7XHJcbiAgICAgICAgICAgIGVsZW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihFVkVOVF9MSVNURU5FUlNbcHJvcF0sIGF0dHJzW3Byb3BdKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAvLyBhbnkgb3RoZXIgcHJvcCB3aWxsIGJlIHNldCBhcyBhdHRyaWJ1dGVcclxuICAgICAgICAgICAgZWxlbWVudC5zZXRBdHRyaWJ1dGUocHJvcCwgYXR0cnNbcHJvcF0pO1xyXG4gICAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiBlbGVtZW50O1xyXG59XHJcblxyXG4vKipcclxuICogVGhlIEpTWFRhZyB3aWxsIGJlIHVud3JhcHBlZCByZXR1cm5pbmcgdGhlIGh0bWxcclxuICpcclxuICogQHBhcmFtICB7RnVuY3Rpb259IEpTWFRhZyBuYW1lIGFzIHN0cmluZywgZS5nLiAnZGl2JywgJ3NwYW4nLCAnc3ZnJ1xyXG4gKiBAcGFyYW0gIHtPYmplY3R9IGVsZW1lbnRQcm9wcyBjdXN0b20ganN4IGF0dHJpYnV0ZXMgZS5nLiBmbiwgc3RyaW5nc1xyXG4gKiBAcGFyYW0gIHtBcnJheX0gY2hpbGRyZW4gaHRtbCBub2RlcyBmcm9tIGluc2lkZSBkZSBlbGVtZW50c1xyXG4gKlxyXG4gKiBAcmV0dXJuIHtGdW5jdGlvbn0gcmV0dXJucyBkZSAnZG9tJyAoZm4pIGV4ZWN1dGVkLCBsZWF2aW5nIHRoZSBIVE1MRWxlbWVudFxyXG4gKlxyXG4gKiBKU1hUYWc6ICBmdW5jdGlvbiBDb21wKHByb3BzKSB7XHJcbiAqICAgcmV0dXJuIGRvbShcInNwYW5cIiwgbnVsbCwgcHJvcHMubnVtKTtcclxuICogfVxyXG4gKi9cclxuZnVuY3Rpb24gY29tcG9zZVRvRnVuY3Rpb24oSlNYVGFnLCBlbGVtZW50UHJvcHMsIGNoaWxkcmVuKSB7XHJcbiAgICBjb25zdCBwcm9wcyA9IE9iamVjdC5hc3NpZ24oe30sIEpTWFRhZy5kZWZhdWx0UHJvcHMgfHwge30sIGVsZW1lbnRQcm9wcywgeyBjaGlsZHJlbiB9KTtcclxuICAgIGNvbnN0IGJyaWRnZSA9IChKU1hUYWcucHJvdG90eXBlICYmIEpTWFRhZy5wcm90b3R5cGUucmVuZGVyKSA/IG5ldyBKU1hUYWcocHJvcHMpLnJlbmRlciA6IEpTWFRhZztcclxuICAgIGNvbnN0IHJlc3VsdCA9IGJyaWRnZShwcm9wcyk7XHJcblxyXG4gICAgc3dpdGNoIChyZXN1bHQpIHtcclxuICAgICAgICBjYXNlICdGUkFHTUVOVCc6XHJcbiAgICAgICAgICAgIHJldHVybiBjcmVhdGVGcmFnbWVudEZyb20oY2hpbGRyZW4pO1xyXG5cclxuICAgICAgICAvLyBQb3J0YWxzIGFyZSB1c2VmdWwgdG8gcmVuZGVyIG1vZGFsc1xyXG4gICAgICAgIC8vIGFsbG93IHJlbmRlciBvbiBhIGRpZmZlcmVudCBlbGVtZW50IHRoYW4gdGhlIHBhcmVudCBvZiB0aGUgY2hhaW5cclxuICAgICAgICAvLyBhbmQgbGVhdmUgYSBjb21tZW50IGluc3RlYWRcclxuICAgICAgICBjYXNlICdQT1JUQUwnOlxyXG4gICAgICAgICAgICBicmlkZ2UudGFyZ2V0LmFwcGVuZENoaWxkKGNyZWF0ZUZyYWdtZW50RnJvbShjaGlsZHJlbikpO1xyXG4gICAgICAgICAgICByZXR1cm4gZG9jdW1lbnQuY3JlYXRlQ29tbWVudCgnUG9ydGFsIFVzZWQnKTtcclxuICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBkb20oZWxlbWVudCwgYXR0cnMsIC4uLmNoaWxkcmVuKSB7XHJcbiAgICAvLyBDdXN0b20gQ29tcG9uZW50cyB3aWxsIGJlIGZ1bmN0aW9uc1xyXG4gICAgaWYgKHR5cGVvZiBlbGVtZW50ID09PSAnZnVuY3Rpb24nKSB7XHJcbiAgICAgICAgaWYgKGVsZW1lbnQuaGFzT3duUHJvcGVydHkoJ3Byb3BUeXBlcycpKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IHByb3Agb2YgZWxlbWVudC5wcm9wVHlwZXMpIHtcclxuICAgICAgICAgICAgICAgIGlmIChhdHRycy5oYXNPd25Qcm9wZXJ0eShwcm9wKSA9PT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGBKU1ggRXJyb3I6IE1pc3NpbmcgcHJvcGVydHkgJyR7cHJvcH0nIGZyb20gJyR7ZWxlbWVudC5uYW1lfScgaW52b2NhdGlvbmApO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIGUuZy4gY29uc3QgQ3VzdG9tVGFnID0gKHsgdyB9KSA9PiA8c3BhbiB3aWR0aD17d30gLz5cclxuICAgICAgICAvLyB3aWxsIGJlIHVzZWRcclxuICAgICAgICAvLyBlLmcuIDxDdXN0b21UYWcgdz17MX0gLz5cclxuICAgICAgICAvLyBiZWNvbWVzOiBDdXN0b21UYWcoeyB3OiAxfSlcclxuICAgICAgICByZXR1cm4gY29tcG9zZVRvRnVuY3Rpb24oZWxlbWVudCwgYXR0cnMsIGNoaWxkcmVuKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyByZWd1bGFyIGh0bWwgY29tcG9uZW50cyB3aWxsIGJlIHN0cmluZ3MgdG8gY3JlYXRlIHRoZSBlbGVtZW50c1xyXG4gICAgLy8gdGhpcyBpcyBoYW5kbGVkIGJ5IHRoZSBiYWJlbCBwbHVnaW5zXHJcbiAgICBpZiAodHlwZW9mIGVsZW1lbnQgPT09ICdzdHJpbmcnKSB7XHJcbiAgICAgICAgcmV0dXJuIGNyZWF0ZUVsZW1lbnRzKGVsZW1lbnQsIGF0dHJzLCBjaGlsZHJlbik7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIGNvbnNvbGUuZXJyb3IoYGpzeC1yZW5kZXIgZG9lcyBub3QgaGFuZGxlICR7dHlwZW9mIHRhZ31gKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZG9tO1xyXG5leHBvcnQgY29uc3QgRnJhZ21lbnQgPSAoKSA9PiAnRlJBR01FTlQnO1xyXG5leHBvcnQgY29uc3QgcG9ydGFsQ3JlYXRvciA9IG5vZGUgPT4ge1xyXG4gICAgZnVuY3Rpb24gUG9ydGFsKCkge1xyXG4gICAgICAgIHJldHVybiAnUE9SVEFMJztcclxuICAgIH1cclxuXHJcbiAgICBQb3J0YWwudGFyZ2V0ID0gZG9jdW1lbnQuYm9keTtcclxuXHJcbiAgICBpZiAobm9kZSAmJiBub2RlLm5vZGVUeXBlID09PSBOb2RlLkVMRU1FTlRfTk9ERSkge1xyXG4gICAgICAgIFBvcnRhbC50YXJnZXQgPSBub2RlO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBQb3J0YWw7XHJcbn07XHJcbiIsImV4cG9ydCBmdW5jdGlvbiBpc1NWRyhlbGVtZW50KSB7XHJcbiAgICBjb25zdCBwYXR0ID0gbmV3IFJlZ0V4cChgXiR7ZWxlbWVudH0kYCwgJ2knKTtcclxuICAgIGNvbnN0IFNWR1RhZ3MgPSBbJ3BhdGgnLCAnc3ZnJywgJ3VzZScsICdnJ107XHJcblxyXG4gICAgcmV0dXJuIFNWR1RhZ3Muc29tZSh0YWcgPT4gcGF0dC50ZXN0KHRhZykpO1xyXG59XHJcblxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUZyYWdtZW50RnJvbShjaGlsZHJlbikge1xyXG4gICAgLy8gZnJhZ21lbnRzIHdpbGwgaGVscCBsYXRlciB0byBhcHBlbmQgbXVsdGlwbGUgY2hpbGRyZW4gdG8gdGhlIGluaXRpYWwgbm9kZVxyXG4gICAgY29uc3QgZnJhZ21lbnQgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KCk7XHJcblxyXG4gICAgZnVuY3Rpb24gcHJvY2Vzc0RPTU5vZGVzKGNoaWxkKSB7XHJcbiAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICBjaGlsZCBpbnN0YW5jZW9mIEhUTUxFbGVtZW50IHx8XHJcbiAgICAgICAgICAgIGNoaWxkIGluc3RhbmNlb2YgU1ZHRWxlbWVudCB8fFxyXG4gICAgICAgICAgICBjaGlsZCBpbnN0YW5jZW9mIENvbW1lbnQgfHxcclxuICAgICAgICAgICAgY2hpbGQgaW5zdGFuY2VvZiBEb2N1bWVudEZyYWdtZW50XHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICAgIGZyYWdtZW50LmFwcGVuZENoaWxkKGNoaWxkKTtcclxuICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBjaGlsZCA9PT0gJ3N0cmluZycgfHwgdHlwZW9mIGNoaWxkID09PSAnbnVtYmVyJykge1xyXG4gICAgICAgICAgICBjb25zdCB0ZXh0bm9kZSA9IGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKGNoaWxkKTtcclxuICAgICAgICAgICAgZnJhZ21lbnQuYXBwZW5kQ2hpbGQodGV4dG5vZGUpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoY2hpbGQgaW5zdGFuY2VvZiBBcnJheSkge1xyXG4gICAgICAgICAgICBjaGlsZC5mb3JFYWNoKHByb2Nlc3NET01Ob2Rlcyk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChjaGlsZCA9PT0gZmFsc2UgfHwgY2hpbGQgPT09IG51bGwpIHtcclxuICAgICAgICAgICAgLy8gZXhwcmVzc2lvbiBldmFsdWF0ZWQgYXMgZmFsc2UgZS5nLiB7ZmFsc2UgJiYgPEVsZW0gLz59XHJcbiAgICAgICAgICAgIC8vIGV4cHJlc3Npb24gZXZhbHVhdGVkIGFzIGZhbHNlIGUuZy4ge251bGwgJiYgPEVsZW0gLz59XHJcbiAgICAgICAgfSBlbHNlIGlmICh0eXBlb2YgY2hpbGQgPT09ICdmdW5jdGlvbicpIHtcclxuXHJcbiAgICAgICAgfSBlbHNlIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ2RldmVsb3BtZW50Jykge1xyXG4gICAgICAgICAgICAvLyBsYXRlciBvdGhlciB0aGluZ3MgY291bGQgbm90IGJlIEhUTUxFbGVtZW50IG5vciBzdHJpbmdzXHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGNoaWxkLCAnaXMgbm90IGFwcGVuZGFibGUnKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY2hpbGRyZW4uZm9yRWFjaChwcm9jZXNzRE9NTm9kZXMpO1xyXG5cclxuICAgIHJldHVybiBmcmFnbWVudDtcclxufVxyXG5cclxuLy8gTWFwIGZyb20gSlNYIHByb3BlcnR5IChlLmcuIG9uQ2xpY2spIHRvIGV2ZW50IG5hbWUgKGUuZy4gJ2NsaWNrJykuXHJcbmV4cG9ydCBjb25zdCBFVkVOVF9MSVNURU5FUlMgPSB7XHJcbiAgICAvLyBDbGlwYm9hcmQgRXZlbnRzXHJcbiAgICBvbkNvcHk6ICdjb3B5JyxcclxuICAgIG9uQ3V0OiAnY3V0JyxcclxuICAgIG9uUGFzdGU6ICdwYXN0ZScsXHJcblxyXG4gICAgLy8gQ29tcG9zaXRpb24gRXZlbnRzXHJcbiAgICBvbkNvbXBvc2l0aW9uRW5kOiAnY29tcG9zaXRpb25lbmQnLFxyXG4gICAgb25Db21wb3NpdGlvblN0YXJ0OiAnY29tcG9zaXRpb25zdGFydCcsXHJcbiAgICBvbkNvbXBvc2l0aW9uVXBkYXRlOiAnY29tcG9zaXRpb251cGRhdGUnLFxyXG5cclxuICAgIC8vIEZvY3VzIEV2ZW50c1xyXG4gICAgb25Gb2N1czogJ2ZvY3VzJyxcclxuICAgIG9uQmx1cjogJ2JsdXInLFxyXG5cclxuICAgIC8vIEZvcm0gRXZlbnRzXHJcbiAgICBvbkNoYW5nZTogJ2NoYW5nZScsXHJcbiAgICBvbkJlZm9yZUlucHV0OiAnYmVmb3JlaW5wdXQnLFxyXG4gICAgb25JbnB1dDogJ2lucHV0JyxcclxuICAgIG9uUmVzZXQ6ICdyZXNldCcsXHJcbiAgICBvblN1Ym1pdDogJ3N1Ym1pdCcsXHJcbiAgICBvbkludmFsaWQ6ICdpbnZhbGlkJyxcclxuXHJcbiAgICAvLyBJbWFnZSBFdmVudHNcclxuICAgIG9uTG9hZDogJ2xvYWQnLFxyXG4gICAgb25FcnJvcjogJ2Vycm9yJyxcclxuXHJcbiAgICAvLyBLZXlib2FyZCBFdmVudHNcclxuICAgIG9uS2V5RG93bjogJ2tleWRvd24nLFxyXG4gICAgb25LZXlQcmVzczogJ2tleXByZXNzJyxcclxuICAgIG9uS2V5VXA6ICdrZXl1cCcsXHJcblxyXG4gICAgLy8gTWVkaWEgRXZlbnRzXHJcbiAgICBvbkFib3J0OiAnYWJvcnQnLFxyXG4gICAgb25DYW5QbGF5OiAnY2FucGxheScsXHJcbiAgICBvbkNhblBsYXlUaHJvdWdoOiAnY2FucGxheXRocm91Z2gnLFxyXG4gICAgb25EdXJhdGlvbkNoYW5nZTogJ2R1cmF0aW9uY2hhbmdlJyxcclxuICAgIG9uRW1wdGllZDogJ2VtcHRpZWQnLFxyXG4gICAgb25FbmNyeXB0ZWQ6ICdlbmNyeXB0ZWQnLFxyXG4gICAgb25FbmRlZDogJ2VuZGVkJyxcclxuICAgIG9uTG9hZGVkRGF0YTogJ2xvYWRlZGRhdGEnLFxyXG4gICAgb25Mb2FkZWRNZXRhZGF0YTogJ2xvYWRlZG1ldGFkYXRhJyxcclxuICAgIG9uTG9hZFN0YXJ0OiAnbG9hZHN0YXJ0JyxcclxuICAgIG9uUGF1c2U6ICdwYXVzZScsXHJcbiAgICBvblBsYXk6ICdwbGF5JyxcclxuICAgIG9uUGxheWluZzogJ3BsYXlpbmcnLFxyXG4gICAgb25Qcm9ncmVzczogJ3Byb2dyZXNzJyxcclxuICAgIG9uUmF0ZUNoYW5nZTogJ3JhdGVjaGFuZ2UnLFxyXG4gICAgb25TZWVrZWQ6ICdzZWVrZWQnLFxyXG4gICAgb25TZWVraW5nOiAnc2Vla2luZycsXHJcbiAgICBvblN0YWxsZWQ6ICdzdGFsbGVkJyxcclxuICAgIG9uU3VzcGVuZDogJ3N1c3BlbmQnLFxyXG4gICAgb25UaW1lVXBkYXRlOiAndGltZXVwZGF0ZScsXHJcbiAgICBvblZvbHVtZUNoYW5nZTogJ3ZvbHVtZWNoYW5nZScsXHJcbiAgICBvbldhaXRpbmc6ICd3YWl0aW5nJyxcclxuXHJcbiAgICAvLyBNb3VzZUV2ZW50c1xyXG4gICAgb25DbGljazogJ2NsaWNrJyxcclxuICAgIG9uQ29udGV4dE1lbnU6ICdjb250ZXh0bWVudScsXHJcbiAgICBvbkRvdWJsZUNsaWNrOiAnZG91YmxlY2xpY2snLFxyXG4gICAgb25EcmFnOiAnZHJhZycsXHJcbiAgICBvbkRyYWdFbmQ6ICdkcmFnZW5kJyxcclxuICAgIG9uRHJhZ0VudGVyOiAnZHJhZ2VudGVyJyxcclxuICAgIG9uRHJhZ0V4aXQ6ICdkcmFnZXhpdCcsXHJcbiAgICBvbkRyYWdMZWF2ZTogJ2RyYWdsZWF2ZScsXHJcbiAgICBvbkRyYWdPdmVyOiAnZHJhZ292ZXInLFxyXG4gICAgb25EcmFnU3RhcnQ6ICdkcmFnc3RhcnQnLFxyXG4gICAgb25Ecm9wOiAnZHJvcCcsXHJcbiAgICBvbk1vdXNlRG93bjogJ21vdXNlZG93bicsXHJcbiAgICBvbk1vdXNlRW50ZXI6ICdtb3VzZWVudGVyJyxcclxuICAgIG9uTW91c2VMZWF2ZTogJ21vdXNlbGVhdmUnLFxyXG4gICAgb25Nb3VzZU1vdmU6ICdtb3VzZW1vdmUnLFxyXG4gICAgb25Nb3VzZU91dDogJ21vdXNlb3V0JyxcclxuICAgIG9uTW91c2VPdmVyOiAnbW91c2VvdmVyJyxcclxuICAgIG9uTW91c2VVcDogJ21vdXNldXAnLFxyXG5cclxuICAgIC8vIFNlbGVjdGlvbiBFdmVudHNcclxuICAgIG9uU2VsZWN0OiAnc2VsZWN0JyxcclxuXHJcbiAgICAvLyBUb3VjaCBFdmVudHNcclxuICAgIG9uVG91Y2hDYW5jZWw6ICd0b3VjaGNhbmNlbCcsXHJcbiAgICBvblRvdWNoRW5kOiAndG91Y2hlbmQnLFxyXG4gICAgb25Ub3VjaE1vdmU6ICd0b3VjaG1vdmUnLFxyXG4gICAgb25Ub3VjaFN0YXJ0OiAndG91Y2hzdGFydCcsXHJcblxyXG4gICAgLy8gUG9pbnRlciBFdmVudHNcclxuICAgIG9uUG9pbnRlckRvd246ICdwb2ludGVyZG93bicsXHJcbiAgICBvblBvaW50ZXJNb3ZlOiAncG9pbnRlcm1vdmUnLFxyXG4gICAgb25Qb2ludGVyVXA6ICdwb2ludGVydXAnLFxyXG4gICAgb25Qb2ludGVyQ2FuY2VsOiAncG9pbnRlcmNhbmNlbCcsXHJcbiAgICBvblBvaW50ZXJFbnRlcjogJ3BvaW50ZXJlbnRlcicsXHJcbiAgICBvblBvaW50ZXJMZWF2ZTogJ3BvaW50ZXJsZWF2ZScsXHJcbiAgICBvblBvaW50ZXJPdmVyOiAncG9pbnRlcm92ZXInLFxyXG4gICAgb25Qb2ludGVyT3V0OiAncG9pbnRlcm91dCcsXHJcblxyXG4gICAgLy8gVUkgRXZlbnRzXHJcbiAgICBvblNjcm9sbDogJ3Njcm9sbCcsXHJcblxyXG4gICAgLy8gV2hlZWwgRXZlbnRzXHJcbiAgICBvbldoZWVsOiAnd2hlZWwnLFxyXG5cclxuICAgIC8vIEFuaW1hdGlvbiBFdmVudHNcclxuICAgIG9uQW5pbWF0aW9uU3RhcnQ6ICdhbmltYXRpb25zdGFydCcsXHJcbiAgICBvbkFuaW1hdGlvbkVuZDogJ2FuaW1hdGlvbmVuZCcsXHJcbiAgICBvbkFuaW1hdGlvbkl0ZXJhdGlvbjogJ2FuaW1hdGlvbml0ZXJhdGlvbicsXHJcblxyXG4gICAgLy8gVHJhbnNpdGlvbiBFdmVudHNcclxuICAgIG9uVHJhbnNpdGlvbkVuZDogJ3RyYW5zaXRpb25lbmQnLFxyXG59OyIsImZ1bmN0aW9uIHF1ZXJ5U3RyaW5nKHF1ZXJ5KSB7XHJcbiAgICBpZiAoIXF1ZXJ5KSB7XHJcbiAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gcXVlcnlcclxuICAgICAgICAuc3BsaXQoJz8nKVsxXVxyXG4gICAgICAgIC5zcGxpdCgnJicpXHJcbiAgICAgICAgLm1hcChhID0+IGEuc3BsaXQoJz0nKSlcclxuICAgICAgICAucmVkdWNlKChhLCBjKSA9PiB7XHJcbiAgICAgICAgICAgIGFbY1swXV0gPSBjWzFdO1xyXG4gICAgICAgICAgICByZXR1cm4gYTtcclxuICAgICAgICB9LCB7fSk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBDYWxjdWxhdGUgbnVtYmVyIG9mIGRheXMgcGFzc2luZyBiZXR3ZWVuIHR3byBkYXRlc1xyXG4gKiBAcGFyYW0ge0RhdGV9IGEgU3RhcnRpbmcgZGF0ZVxyXG4gKiBAcGFyYW0ge0RhdGV9IGIgRW5kaW5nIGRhdGVcclxuICogQHJldHVybnMge251bWJlcn0gTnVtYmVyIG9mIGRheXNcclxuICovXHJcbmZ1bmN0aW9uIGRhdGVEaWZmKGEsIGIpIHtcclxuICAgIGlmIChhLmdldEZ1bGxZZWFyKCkgPT0gYi5nZXRGdWxsWWVhcigpICYmXHJcbiAgICAgICAgYS5nZXRNb250aCgpID09IGIuZ2V0TW9udGgoKSAmJlxyXG4gICAgICAgIGEuZ2V0RGF0ZSgpID09IGIuZ2V0RGF0ZSgpKSB7XHJcbiAgICAgICAgcmV0dXJuIDA7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJldHVybiAoYiAtIGEpID4gMCA/IE1hdGguY2VpbCgoYiAtIGEpIC8gODY0MDAwMDApIDogTWF0aC5mbG9vcigoYiAtIGEpIC8gODY0MDAwMDApO1xyXG4gICAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBkYXRlRGlmZlRvRGF5cyhkYXlzKSB7XHJcbiAgICBpZiAoZGF5cyA9PSAwKSB7XHJcbiAgICAgICAgcmV0dXJuICdUb2RheSc7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIGlmIChkYXlzIDw9IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuIGBJbiAkey1kYXlzfSBkYXkke2RheXMgPT0gLTEgPyAnJyA6ICdzJ31gO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiBgJHtkYXlzfSBkYXkke2RheXMgPT0gMSA/ICcnIDogJ3MnfSBhZ29gO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIElzIHRoZSBkYXRlIGluIHRoZSBsYXN0IGRheSBvZiBhIG1vbnRoXHJcbiAqIEBwYXJhbSB7RGF0ZX0gZGF0ZVxyXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cclxuICovXHJcbmZ1bmN0aW9uIGlzTGFzdERheShkYXRlKSB7XHJcbiAgICBjb25zdCBuZXh0RGF5ID0gbmV3IERhdGUoZGF0ZSk7XHJcbiAgICBuZXh0RGF5LnNldERhdGUobmV4dERheS5nZXREYXRlKCkgKyAxKTtcclxuICAgIHJldHVybiAoZGF0ZS5nZXRNb250aCgpICE9IG5leHREYXkuZ2V0TW9udGgoKSk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBJcyB0aGUgZGF0ZSBpbiB0aGUgbGFzdCB3ZWVrIG9mIGEgbW9udGhcclxuICogQHBhcmFtIHtEYXRlfSBkYXRlXHJcbiAqIEByZXR1cm5zIHtib29sZWFufVxyXG4gKi9cclxuZnVuY3Rpb24gaXNMYXN0V2VlayhkYXRlKSB7XHJcbiAgICBjb25zdCBuZXh0V2VlayA9IG5ldyBEYXRlKGRhdGUpO1xyXG4gICAgbmV4dFdlZWsuc2V0RGF0ZShuZXh0V2Vlay5nZXREYXRlKCkgKyA3KTtcclxuICAgIHJldHVybiAoZGF0ZS5nZXRNb250aCgpICE9IG5leHRXZWVrLmdldE1vbnRoKCkpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBmb3JtYXREYXRlKGRhdGUpIHtcclxuICAgIGNvbnN0IGFzU3RyaW5nID0gZGF0ZS50b0xvY2FsZURhdGVTdHJpbmcoJ2VuLVVTJywge1xyXG4gICAgICAgIG1vbnRoOiAnc2hvcnQnLFxyXG4gICAgICAgIHllYXI6ICdudW1lcmljJ1xyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gYCR7ZGF0ZS5nZXREYXRlKCl9ICR7YXNTdHJpbmd9YDtcclxufVxyXG5cclxuZnVuY3Rpb24gZm9ybWF0VGltZShkYXRlKSB7XHJcbiAgICByZXR1cm4gZGF0ZS50b0xvY2FsZVRpbWVTdHJpbmcoJ2VuLVVTJywge1xyXG4gICAgICAgIGhvdXI6ICdudW1lcmljJyxcclxuICAgICAgICBtaW51dGU6ICdudW1lcmljJyxcclxuICAgICAgICAvLyBob3VyMTI6IGZhbHNlLFxyXG4gICAgICAgIGhvdXJDeWNsZTogJ2gyMydcclxuICAgIH0pO1xyXG59XHJcblxyXG5mdW5jdGlvbiBmb3JtYXRMb2NhbGVEYXRlKGRhdGUpIHtcclxuICAgIGNvbnN0IGRheSA9IGRhdGUuZ2V0RGF0ZSgpO1xyXG4gICAgY29uc3QgbW9udGggPSBbXHJcbiAgICAgICAgJ9GP0L3Rg9Cw0YDQuCcsXHJcbiAgICAgICAgJ9GE0LXQstGA0YPQsNGA0LgnLFxyXG4gICAgICAgICfQvNCw0YDRgicsXHJcbiAgICAgICAgJ9Cw0L/RgNC40LsnLFxyXG4gICAgICAgICfQvNCw0LknLFxyXG4gICAgICAgICfRjtC90LgnLFxyXG4gICAgICAgICfRjtC70LgnLFxyXG4gICAgICAgICfQsNCy0LPRg9GB0YInLFxyXG4gICAgICAgICfRgdC10L/RgtC10LzQstGA0LgnLFxyXG4gICAgICAgICfQvtC60YLQvtC80LLRgNC4JyxcclxuICAgICAgICAn0L3QvtC10LzQstGA0LgnLFxyXG4gICAgICAgICfQtNC10LrQtdC80LLRgNC4J1xyXG4gICAgXVtkYXRlLmdldE1vbnRoKCldO1xyXG4gICAgcmV0dXJuIGAke2RheX0gJHttb250aH1gO1xyXG59XHJcblxyXG5mdW5jdGlvbiBmb3JtYXRMb2NhbGVXZWVrZGF5KGRheSwgZ2V0QWRqKSB7XHJcbiAgICBjb25zdCB3ZWVrZGF5ID0gW1xyXG4gICAgICAgICfQvdC10LTQtdC70Y8nLFxyXG4gICAgICAgICfQv9C+0L3QtdC00LXQu9C90LjQuicsXHJcbiAgICAgICAgJ9Cy0YLQvtGA0L3QuNC6JyxcclxuICAgICAgICAn0YHRgNGP0LTQsCcsXHJcbiAgICAgICAgJ9GH0LXRgtCy0YrRgNGC0YrQuicsXHJcbiAgICAgICAgJ9C/0LXRgtGK0LonLFxyXG4gICAgICAgICfRgdGK0LHQvtGC0LAnLFxyXG4gICAgXVtkYXldO1xyXG4gICAgaWYgKGdldEFkaikge1xyXG4gICAgICAgIHJldHVybiBbd2Vla2RheSwgW1xyXG4gICAgICAgICAgICAn0LLRgdGP0LrQsCcsXHJcbiAgICAgICAgICAgICfQstGB0LXQutC4JyxcclxuICAgICAgICAgICAgJ9Cy0YHQtdC60LgnLFxyXG4gICAgICAgICAgICAn0LLRgdGP0LrQsCcsXHJcbiAgICAgICAgICAgICfQstGB0LXQutC4JyxcclxuICAgICAgICAgICAgJ9Cy0YHQtdC60LgnLFxyXG4gICAgICAgICAgICAn0LLRgdGP0LrQsCcsXHJcbiAgICAgICAgXVtkYXldXTtcclxuICAgIH1cclxuICAgIHJldHVybiB3ZWVrZGF5O1xyXG59XHJcblxyXG4vKipcclxuICogR2V0IGEgbmV3IGRhdGUgb2Zmc2V0IGJ5IHRoZSBzcGVjaWZpZWQgbnVtYmVyIG9mIGRheXNcclxuICogQHBhcmFtIHtEYXRlfSBkYXRlIEJhc2UgZGF0ZVxyXG4gKiBAcGFyYW0ge251bWJlcn0gZGF5cyBIb3cgbWFueSBkYXlzIHRvIG9mZnNldFxyXG4gKiBAcmV0dXJucyB7RGF0ZX1cclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRPZmZzZXRCeURheXMoZGF0ZSwgZGF5cykge1xyXG4gICAgY29uc3QgcmVzdWx0ID0gbmV3IERhdGUoZGF0ZSk7XHJcbiAgICByZXN1bHQuc2V0VVRDRGF0ZShyZXN1bHQuZ2V0VVRDRGF0ZSgpICsgZGF5cyk7XHJcbiAgICByZXR1cm4gcmVzdWx0O1xyXG59XHJcblxyXG4vKipcclxuICogT2Zmc2V0IHRoZSBnaXZlbiBkYXRlIGluIHBsYWNlIGJ5IHRoZSBzcGVjaWZpZWQgbnVtYmVyIG9mIGRheXNcclxuICogQHBhcmFtIHtEYXRlfSBkYXRlIEJhc2UgZGF0ZVxyXG4gKiBAcGFyYW0ge251bWJlcn0gZGF5cyBIb3cgbWFueSBkYXlzIHRvIG9mZnNldFxyXG4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIG9mZnNldEJ5RGF5cyhkYXRlLCBkYXlzKSB7XHJcbiAgICBkYXRlLnNldFVUQ0RhdGUoZGF0ZS5nZXRVVENEYXRlKCkgKyBkYXlzKTtcclxufVxyXG5cclxuLyoqXHJcbiAqIENyZWF0ZSBkYXRlIGluZGV4IGFzIHN0cmluZ1xyXG4gKiBAcGFyYW0ge0RhdGV8c3RyaW5nfSBkYXRlIEJhc2UgZGF0ZVxyXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxyXG4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIGdldERhdGVJbmRleChkYXRlKSB7XHJcbiAgICBpZiAodHlwZW9mIGRhdGUgPT0gJ3N0cmluZycpIHtcclxuICAgICAgICBkYXRlID0gbmV3IERhdGUoZGF0ZSk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gZGF0ZS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKTtcclxufVxyXG5cclxuZnVuY3Rpb24gcHJldHR5SlNPTihvYmopIHtcclxuICAgIHJldHVybiBKU09OLnN0cmluZ2lmeShvYmosIG51bGwsIDIpLnJlcGxhY2UoLyAvZ21pLCAnJm5ic3A7JykucmVwbGFjZSgvXFxuL2dtaSwgJzxicj4nKTtcclxufVxyXG5cclxuZnVuY3Rpb24gZ2V0TW9uZGF5KGRhdGUpIHtcclxuICAgIGNvbnN0IG1vbmRheSA9IG5ldyBEYXRlKGAke2RhdGUuZ2V0RnVsbFllYXIoKX0tJHtkYXRlLmdldE1vbnRoKCkgKyAxfS0ke2RhdGUuZ2V0RGF0ZSgpfSAxMjowMDowMGApO1xyXG4gICAgbW9uZGF5LnNldERhdGUobW9uZGF5LmdldERhdGUoKSAtICgobW9uZGF5LmdldERheSgpICsgNikgJSA3KSk7XHJcbiAgICByZXR1cm4gbW9uZGF5O1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRTdW5kYXkoZGF0ZSkge1xyXG4gICAgY29uc3Qgc3VuZGF5ID0gbmV3IERhdGUoYCR7ZGF0ZS5nZXRGdWxsWWVhcigpfS0ke2RhdGUuZ2V0TW9udGgoKSArIDF9LSR7ZGF0ZS5nZXREYXRlKCl9IDIzOjU5OjU5YCk7XHJcbiAgICBzdW5kYXkuc2V0RGF0ZShzdW5kYXkuZ2V0RGF0ZSgpICsgKCg3IC0gc3VuZGF5LmdldERheSgpKSAlIDcpKTtcclxuICAgIHJldHVybiBzdW5kYXk7XHJcbn1cclxuXHJcbmNvbnN0IG1vbnRoTmFtZSA9IHtcclxuICAgIDE6ICdKYW51YXJ5JyxcclxuICAgIDI6ICdGZWJydWFyeScsXHJcbiAgICAzOiAnTWFyY2gnLFxyXG4gICAgNDogJ0FwcmlsJyxcclxuICAgIDU6ICdNYXknLFxyXG4gICAgNjogJ0p1bmUnLFxyXG4gICAgNzogJ0p1bHknLFxyXG4gICAgODogJ0F1Z3VzdCcsXHJcbiAgICA5OiAnU2VwdGVtYmVyJyxcclxuICAgIDEwOiAnT2N0b2JlcicsXHJcbiAgICAxMTogJ05vdmVtYmVyJyxcclxuICAgIDEyOiAnRGVjZW1iZXInLFxyXG59O1xyXG5cclxuXHJcbmNvbnN0IGxvY2FsZU1vbnRoTmFtZSA9IHtcclxuICAgIDE6ICfRj9C90YPQsNGA0LgnLFxyXG4gICAgMjogJ9GE0LXQstGA0YPQsNGA0LgnLFxyXG4gICAgMzogJ9C80LDRgNGCJyxcclxuICAgIDQ6ICfQsNC/0YDQuNC7JyxcclxuICAgIDU6ICfQvNCw0LknLFxyXG4gICAgNjogJ9GO0L3QuCcsXHJcbiAgICA3OiAn0Y7Qu9C4JyxcclxuICAgIDg6ICfQsNCy0LPRg9GB0YInLFxyXG4gICAgOTogJ9GB0LXQv9GC0LXQvNCy0YDQuCcsXHJcbiAgICAxMDogJ9C+0LrRgtC+0LzQstGA0LgnLFxyXG4gICAgMTE6ICfQvdC+0LXQvNCy0YDQuCcsXHJcbiAgICAxMjogJ9C00LXQutC10LzQstGA0LgnLFxyXG59O1xyXG5cclxuZnVuY3Rpb24gdG9Bc3NvY0FycmF5KHAsIGMsIGksIGEpIHtcclxuICAgIHBbYy5JZF0gPSBjO1xyXG4gICAgcmV0dXJuIHA7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiB0b0N1c3RvbUFzc29jQXJyYXkoaW5kZXhOYW1lLCBvdmVyd3JpdGUgPSBmYWxzZSkge1xyXG4gICAgcmV0dXJuIChwLCBjLCBpLCBhKSA9PiB7XHJcbiAgICAgICAgaWYgKHBbY1tpbmRleE5hbWVdXSAhPT0gdW5kZWZpbmVkICYmIG92ZXJ3cml0ZSA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShwW2NbaW5kZXhOYW1lXV0pKSB7XHJcbiAgICAgICAgICAgICAgICBwW2NbaW5kZXhOYW1lXV0ucHVzaChjKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHBbY1tpbmRleE5hbWVdXSA9IFtwW2NbaW5kZXhOYW1lXV0sIGNdO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcFtjW2luZGV4TmFtZV1dID0gYztcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHA7XHJcbiAgICB9O1xyXG59XHJcblxyXG4vKipcclxuICogQHBhcmFtIHtBcnJheTxTVVBheW1lbnQ+fSBkYXRhIFxyXG4gKiBAcmV0dXJucyB7QXJyYXk8UGF5bWVudFZpZXdNb2RlbD59XHJcbiAqL1xyXG5mdW5jdGlvbiBwYXltZW50c1RvTWF0cml4KGRhdGEpIHtcclxuICAgIGNvbnN0IHRlbXBsYXRlID0gW1xyXG4gICAgICAgICdJZCcsXHJcbiAgICAgICAgJ1BheW1lbnROdW1iZXInLFxyXG4gICAgICAgICdNb2R1bGVOYW1lRW4nLFxyXG4gICAgICAgICdQYXltZW50UGFja2FnZXNBc1N0cmluZycsXHJcbiAgICAgICAgJ1BhaWRGb3JVc2VyTmFtZScsXHJcbiAgICAgICAgJ1ByaWNlJyxcclxuICAgICAgICAnRWR1Y2F0aW9uYWxGb3JtJyxcclxuICAgICAgICAnUGF5bWVudERhdGVUaW1lJ1xyXG4gICAgXTtcclxuICAgIGNvbnN0IHBhcnNlZCA9IGRhdGEubWFwKGUgPT4ge1xyXG4gICAgICAgIGUuRWR1Y2F0aW9uYWxGb3JtID0gZS5FZHVjYXRpb25hbEZvcm0gPT0gMSA/ICdvbmxpbmUnIDogJ29uc2l0ZSc7XHJcbiAgICAgICAgY29uc3QgZW50cnkgPSBbXTtcclxuICAgICAgICBmb3IgKGxldCBwcm9wIG9mIHRlbXBsYXRlKSB7XHJcbiAgICAgICAgICAgIGlmIChwcm9wID09PSAnUGF5bWVudERhdGVUaW1lJykge1xyXG4gICAgICAgICAgICAgICAgZW50cnkucHVzaChuZXcgRGF0ZShlW3Byb3BdKSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBlbnRyeS5wdXNoKGVbcHJvcF0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBlbnRyeTtcclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiBbdGVtcGxhdGUsIC4uLnBhcnNlZF07XHJcbn1cclxuXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdXVpZCgpIHtcclxuICAgIHJldHVybiAneHh4eHh4eHgteHh4eC00eHh4LXl4eHgteHh4eHh4eHh4eHh4Jy5yZXBsYWNlKC9beHldL2csIGZ1bmN0aW9uIChjKSB7XHJcbiAgICAgICAgbGV0IHIgPSBNYXRoLnJhbmRvbSgpICogMTYgfCAwLFxyXG4gICAgICAgICAgICB2ID0gYyA9PSAneCcgPyByIDogKHIgJiAweDMgfCAweDgpO1xyXG4gICAgICAgIHJldHVybiB2LnRvU3RyaW5nKDE2KTtcclxuICAgIH0pO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gbm9ybWFsaXplRGF0ZVRpbWUoZGF0ZXRpbWUpIHtcclxuICAgIGlmICghZGF0ZXRpbWUpIHtcclxuICAgICAgICByZXR1cm4gJyc7XHJcbiAgICB9IGVsc2UgaWYgKGRhdGV0aW1lLnRvU3RyaW5nKCkuaW5jbHVkZXMoJ0RhdGUoJykpIHtcclxuICAgICAgICBjb25zdCBtYXRjaCA9IC9EYXRlXFwoKC4rKVxcKS8uZXhlYyhkYXRldGltZSk7XHJcbiAgICAgICAgaWYgKG1hdGNoICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGQgPSBuZXcgRGF0ZShOdW1iZXIobWF0Y2hbMV0pKTtcclxuICAgICAgICAgICAgcmV0dXJuIGAkeygnMDAwMCcgKyBkLmdldEZ1bGxZZWFyKCkpLnNsaWNlKC00KX0tJHtwdChkLmdldE1vbnRoKCkgKyAxKX0tJHtwdChkLmdldERhdGUoKSl9VCR7cHQoZC5nZXRIb3VycygpKX06JHtwdChkLmdldE1pbnV0ZXMoKSl9YDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gZGF0ZXRpbWU7XHJcbiAgICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gZGF0ZXRpbWU7XHJcbiAgICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHB0KHMpIHtcclxuICAgIHJldHVybiBgMCR7c31gLnNsaWNlKC0yKTtcclxufVxyXG5cclxuZnVuY3Rpb24gaHRtbFRvVGV4dChodG1sKSB7XHJcbiAgICBjb25zdCBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcclxuICAgIGRpdi5pbm5lckhUTUwgPSBodG1sO1xyXG5cclxuICAgIHJldHVybiBkaXYudGV4dENvbnRlbnQ7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBpbnN0YW5jZU1ldGFGcm9tSHJlZihocmVmKSB7XHJcbiAgICBjb25zdCBpbnN0YW5jZU1ldGEgPSBxdWVyeVN0cmluZyhocmVmKTtcclxuICAgIGluc3RhbmNlTWV0YS5JbnN0YW5jZVJlZlR5cGUgPSAoKCkgPT4ge1xyXG4gICAgICAgIHN3aXRjaCAoaW5zdGFuY2VNZXRhLnR5cGUpIHtcclxuICAgICAgICAgICAgY2FzZSAnY291cnNlJzogcmV0dXJuICdtYWluJztcclxuICAgICAgICAgICAgY2FzZSAnZmFzdC10cmFjayc6IHJldHVybiAnb3Blbic7XHJcbiAgICAgICAgICAgIGNhc2UgJ2dlbmVyYWwtY291cnNlLWluc3RhbmNlJzogcmV0dXJuICdnZW5lcmFsJztcclxuICAgICAgICB9XHJcbiAgICB9KSgpO1xyXG5cclxuICAgIHJldHVybiBpbnN0YW5jZU1ldGE7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBoYXNWYWx1ZSh2YWx1ZSkge1xyXG4gICAgcmV0dXJuICh2YWx1ZSAhPT0gbnVsbCAmJiB2YWx1ZSAhPT0gdW5kZWZpbmVkICYmIHZhbHVlICE9PSAnJyk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiB2YWx1ZU9yRW1wdHkodmFsdWUsIGFsdCA9ICcnKSB7XHJcbiAgICBpZiAodmFsdWUgPT09IG51bGwgfHwgdmFsdWUgPT09IHVuZGVmaW5lZCB8fCB2YWx1ZSA9PT0gJycpIHtcclxuICAgICAgICByZXR1cm4gYWx0O1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gdmFsdWU7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBzdW1BcnJheU1heChhcnIpIHtcclxuICAgIGlmIChhcnJbMF0ubGVuZ3RoID09IDAgJiYgYXJyWzFdLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcblxyXG4gICAgbGV0IHJlc3VsdCA9IDA7XHJcblxyXG4gICAgaWYgKGFyclswXS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgcmVzdWx0ICs9IE1hdGgubWF4KC4uLmFyclswXSk7XHJcbiAgICB9XHJcbiAgICBpZiAoYXJyWzFdLmxlbmd0aCA+IDApIHtcclxuICAgICAgICByZXN1bHQgKz0gTWF0aC5tYXgoLi4uYXJyWzFdKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gcmVzdWx0O1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCB7XHJcbiAgICBxdWVyeVN0cmluZyxcclxuICAgIGRhdGVEaWZmLFxyXG4gICAgZGF0ZURpZmZUb0RheXMsXHJcbiAgICBpc0xhc3REYXksXHJcbiAgICBpc0xhc3RXZWVrLFxyXG4gICAgZm9ybWF0RGF0ZSxcclxuICAgIGZvcm1hdFRpbWUsXHJcbiAgICBmb3JtYXRMb2NhbGVEYXRlLFxyXG4gICAgZm9ybWF0TG9jYWxlV2Vla2RheSxcclxuICAgIHByZXR0eUpTT04sXHJcbiAgICBnZXRNb25kYXksXHJcbiAgICBnZXRTdW5kYXksXHJcbiAgICBtb250aE5hbWUsXHJcbiAgICBsb2NhbGVNb250aE5hbWUsXHJcbiAgICB0b0Fzc29jQXJyYXksXHJcbiAgICBwYXltZW50c1RvTWF0cml4LFxyXG4gICAgaHRtbFRvVGV4dFxyXG59O1xyXG5cclxuXHJcbmV4cG9ydCB7XHJcbiAgICBxdWVyeVN0cmluZyxcclxuICAgIGRhdGVEaWZmLFxyXG4gICAgZGF0ZURpZmZUb0RheXMsXHJcbiAgICBpc0xhc3REYXksXHJcbiAgICBpc0xhc3RXZWVrLFxyXG4gICAgZm9ybWF0RGF0ZSxcclxuICAgIGZvcm1hdFRpbWUsXHJcbiAgICBmb3JtYXRMb2NhbGVEYXRlLFxyXG4gICAgZm9ybWF0TG9jYWxlV2Vla2RheSxcclxuICAgIHByZXR0eUpTT04sXHJcbiAgICBnZXRNb25kYXksXHJcbiAgICBnZXRTdW5kYXksXHJcbiAgICBtb250aE5hbWUsXHJcbiAgICBsb2NhbGVNb250aE5hbWUsXHJcbiAgICB0b0Fzc29jQXJyYXksXHJcbiAgICBwYXltZW50c1RvTWF0cml4LFxyXG4gICAgaHRtbFRvVGV4dFxyXG59OyIsImltcG9ydCB7IHV1aWQgfSBmcm9tICcuL3BhcnNlJztcclxuaW1wb3J0IGRvbSwgeyBGcmFnbWVudCB9IGZyb20gJy4uL3V0aWwvanN4LXJlbmRlci1tb2QvZG9tJztcclxuXHJcbi8qKlxyXG4gKiBcclxuICogQHBhcmFtIHsqfSB0eXBlIFxyXG4gKiBAcGFyYW0geyp9IGNvbnRlbnQgXHJcbiAqIEBwYXJhbSB7Kn0gYXR0cmlidXRlcyBcclxuICogQHBhcmFtIHt7Zm9yY2VUeXBlOiAnVGV4dCcgfCAnSFRNTCd9fSBvcHRpb25zIFxyXG4gKiBAcmV0dXJucyBcclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBlbGVtZW50KHR5cGUsIGNvbnRlbnQsIGF0dHJpYnV0ZXMsIG9wdGlvbnMgPSB1bmRlZmluZWQpIHtcclxuICAgIGNvbnN0IHJlc3VsdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQodHlwZSk7XHJcblxyXG4gICAgaWYgKGF0dHJpYnV0ZXMpIHtcclxuICAgICAgICBmb3IgKGxldCBhdHRyIG9mIE9iamVjdC5rZXlzKGF0dHJpYnV0ZXMpKSB7XHJcbiAgICAgICAgICAgIHJlc3VsdFthdHRyXSA9IGF0dHJpYnV0ZXNbYXR0cl07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHJlc3VsdC5hcHBlbmQgPSBhcHBlbmQuYmluZChyZXN1bHQpO1xyXG5cclxuICAgIHJlc3VsdC5hcHBlbmRUbyA9IChwYXJlbnQpID0+IHtcclxuICAgICAgICBwYXJlbnQuYXBwZW5kKHJlc3VsdCk7XHJcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgIH07XHJcblxyXG4gICAgaWYgKGNvbnRlbnQgIT09IHVuZGVmaW5lZCAmJiBjb250ZW50ICE9PSBudWxsKSB7XHJcbiAgICAgICAgcmVzdWx0LmFwcGVuZChjb250ZW50LCBvcHRpb25zKTtcclxuICAgIH1cclxuICAgIHJldHVybiByZXN1bHQ7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGFwcGVuZChjaGlsZCwgb3B0aW9ucyA9IHVuZGVmaW5lZCkge1xyXG4gICAgaWYgKHR5cGVvZiAoY2hpbGQpID09PSAnc3RyaW5nJyB8fCB0eXBlb2YgKGNoaWxkKSA9PT0gJ251bWJlcicpIHtcclxuICAgICAgICBpZiAob3B0aW9ucz8uZm9yY2VUeXBlICE9ICdUZXh0JyAmJiAob3B0aW9ucz8uZm9yY2VUeXBlID09PSAnSFRNTCcgfHwgY2hpbGQudG9TdHJpbmcoKS50cmltKClbMF0gPT09ICc8JykpIHtcclxuICAgICAgICAgICAgdGhpcy5pbm5lckhUTUwgPSBjaGlsZDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBjaGlsZCA9IGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKGNoaWxkKTtcclxuICAgICAgICAgICAgdGhpcy5hcHBlbmRDaGlsZChjaGlsZCk7XHJcbiAgICAgICAgfVxyXG4gICAgfSBlbHNlIGlmIChBcnJheS5pc0FycmF5KGNoaWxkKSkge1xyXG4gICAgICAgIGZvciAobGV0IG5vZGUgb2YgY2hpbGQpIHtcclxuICAgICAgICAgICAgYXBwZW5kLmNhbGwodGhpcywgbm9kZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICB0aGlzLmFwcGVuZENoaWxkKGNoaWxkKTtcclxuICAgIH1cclxuICAgIHJldHVybiB0aGlzO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gcmVwbGFjZUNvbnRlbnRzKG5vZGUsIG5ld0NvbnRlbnRzKSB7XHJcbiAgICBjb25zdCBjTm9kZSA9IG5vZGUuY2xvbmVOb2RlKGZhbHNlKTtcclxuICAgIGFwcGVuZC5jYWxsKGNOb2RlLCBuZXdDb250ZW50cyk7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIG5vZGUucGFyZW50Tm9kZS5yZXBsYWNlQ2hpbGQoY05vZGUsIG5vZGUpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgY29uc29sZS5pbmZvKCdOb2RlIGhhcyBubyBwYXJlbnQgb3IgYW5vdGhlciBwcm9ibGVtIG9jY3VyZWQnKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gY05vZGU7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBzd2FwKG9sZE5vZGUsIG5ld05vZGUpIHtcclxuICAgIG9sZE5vZGUucGFyZW50Tm9kZS5yZXBsYWNlQ2hpbGQobmV3Tm9kZSwgb2xkTm9kZSk7XHJcbiAgICByZXR1cm4gbmV3Tm9kZTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFNwaW5uZXIoeyBpZCB9KSB7XHJcbiAgICBjb25zdCBub2RlID0gZWxlbWVudCgnZGl2JywgW1xyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAnc2stY3ViZSBzay1jdWJlMScgfSksXHJcbiAgICAgICAgZWxlbWVudCgnZGl2JywgbnVsbCwgeyBjbGFzc0xpc3Q6ICdzay1jdWJlIHNrLWN1YmUyJyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3NrLWN1YmUgc2stY3ViZTMnIH0pLFxyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAnc2stY3ViZSBzay1jdWJlNCcgfSksXHJcbiAgICAgICAgZWxlbWVudCgnZGl2JywgbnVsbCwgeyBjbGFzc0xpc3Q6ICdzay1jdWJlIHNrLWN1YmU1JyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3NrLWN1YmUgc2stY3ViZTYnIH0pLFxyXG4gICAgICAgIGVsZW1lbnQoJ2RpdicsIG51bGwsIHsgY2xhc3NMaXN0OiAnc2stY3ViZSBzay1jdWJlNycgfSksXHJcbiAgICAgICAgZWxlbWVudCgnZGl2JywgbnVsbCwgeyBjbGFzc0xpc3Q6ICdzay1jdWJlIHNrLWN1YmU4JyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3NrLWN1YmUgc2stY3ViZTknIH0pLFxyXG4gICAgXSwgeyBjbGFzc0xpc3Q6ICdzay1jdWJlLWdyaWQnIH0pO1xyXG4gICAgaWYgKGlkKSB7XHJcbiAgICAgICAgbm9kZS5zZXRBdHRyaWJ1dGUoJ2lkJywgaWQpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBub2RlO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gTG9hZGluZyh7IGlkLCBjb2xvciA9ICd3aGl0ZScgfSkge1xyXG4gICAgY29uc3Qgbm9kZSA9IGVsZW1lbnQoJ2RpdicsIFtcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3JlY3QxJyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3JlY3QyJyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3JlY3QzJyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3JlY3Q0JyB9KSxcclxuICAgICAgICBlbGVtZW50KCdkaXYnLCBudWxsLCB7IGNsYXNzTGlzdDogJ3JlY3Q1JyB9KSxcclxuICAgIF0sIHsgY2xhc3NMaXN0OiBnZXRDbGFzcygpIH0pO1xyXG4gICAgaWYgKGlkKSB7XHJcbiAgICAgICAgbm9kZS5zZXRBdHRyaWJ1dGUoJ2lkJywgaWQpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBub2RlO1xyXG5cclxuXHJcbiAgICBmdW5jdGlvbiBnZXRDbGFzcygpIHtcclxuICAgICAgICByZXR1cm4gYHNwaW5uZXIgJHtjb2xvcn1gO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gUmVtb3RlKHsgc3JjLCBwYXJzZSwgY29tcG9uZW50LCBjb2xvciA9ICd3aGl0ZScsIG9uUmVhZHksIG9uRXJyb3IgfSkge1xyXG4gICAgY29uc3QgaWQgPSB1dWlkKCk7XHJcbiAgICByZXNvbHZlKCk7XHJcblxyXG4gICAgY29uc3QgbG9hZGVyID0gTG9hZGluZyh7IGlkLCBjb2xvciB9KTtcclxuXHJcbiAgICByZXR1cm4gbG9hZGVyO1xyXG5cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiByZXNvbHZlKCkge1xyXG4gICAgICAgIGxldCBkYXRhID0gYXdhaXQgKGFzeW5jICgpID0+IHtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBhd2FpdCAoc3JjIGluc3RhbmNlb2YgUHJvbWlzZSkgPyBzcmMgOiBzcmMoKTtcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKG9uRXJyb3IpIHtcclxuICAgICAgICAgICAgICAgICAgICBvbkVycm9yKGUsIGxvYWRlcik7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNvbnN0IHJldHJ5QnRuID0gZWxlbWVudCgnYnV0dG9uJywgW1xyXG4gICAgICAgICAgICAgICAgICAgIGVsZW1lbnQoJ2knLCBudWxsLCB7IGNsYXNzTmFtZTogJ2dseXBoaWNvbiBnbHlwaGljb24tcmVwZWF0JyB9KSxcclxuICAgICAgICAgICAgICAgICAgICAnUmV0cnknXHJcbiAgICAgICAgICAgICAgICBdLCB7IHN0eWxlOiAnYmFja2dyb3VuZC1jb2xvcjogZ3JlZW4nIH0pO1xyXG4gICAgICAgICAgICAgICAgcmV0cnlCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVwbGFjZVNlbGYoUmVtb3RlKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3JjLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXJzZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29tcG9uZW50LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvclxyXG4gICAgICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGVsZW1lbnQoJ2RpdicsIFtcclxuICAgICAgICAgICAgICAgICAgICBlbGVtZW50KCdpJywgbnVsbCwgeyBjbGFzc05hbWU6ICdnbHlwaGljb24gZ2x5cGhpY29uLXJlbW92ZScsIHN0eWxlOiAnY29sb3I6IHJlZCcgfSksXHJcbiAgICAgICAgICAgICAgICAgICAgZS5tZXNzYWdlLFxyXG4gICAgICAgICAgICAgICAgICAgIHJldHJ5QnRuXHJcbiAgICAgICAgICAgICAgICBdLCB7IGlkOiBpZCB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pKCk7XHJcblxyXG4gICAgICAgIGlmIChwYXJzZSkge1xyXG4gICAgICAgICAgICBkYXRhID0gcGFyc2UoZGF0YSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXBsYWNlU2VsZihkYXRhKTtcclxuXHJcbiAgICAgICAgZnVuY3Rpb24gcmVwbGFjZVNlbGYoZGF0YSkge1xyXG4gICAgICAgICAgICAvL2NvbnN0IGxvYWRlciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKTtcclxuICAgICAgICAgICAgY29uc3QgcGFyZW50ID0gbG9hZGVyLnBhcmVudE5vZGU7XHJcblxyXG4gICAgICAgICAgICBpZiAoY29tcG9uZW50KSB7XHJcbiAgICAgICAgICAgICAgICBwYXJlbnQuaW5zZXJ0QmVmb3JlKGNvbXBvbmVudChkYXRhKSwgbG9hZGVyKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGFwcGVuZChkYXRhKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvL2F3YWl0IG5ldyBQcm9taXNlKHJlc29sdmUgPT4gc2V0VGltZW91dCgxMCwgcmVzb2x2ZSkpO1xyXG4gICAgICAgICAgICAvL2NvbnNvbGUubG9nKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKSk7XHJcbiAgICAgICAgICAgIGxvYWRlci5yZW1vdmUoKTtcclxuICAgICAgICAgICAgaWYgKG9uUmVhZHkpIHtcclxuICAgICAgICAgICAgICAgIG9uUmVhZHkoKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgZnVuY3Rpb24gYXBwZW5kKGNoaWxkKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIChjaGlsZCkgPT09ICdzdHJpbmcnIHx8IHR5cGVvZiAoY2hpbGQpID09PSAnbnVtYmVyJykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChjaGlsZC50b1N0cmluZygpLnRyaW0oKVswXSA9PT0gJzwnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGZyYWdtZW50ID0gZWxlbWVudCgnZGl2JywgY2hpbGQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmcmFnbWVudC5jaGlsZE5vZGVzLmZvckVhY2gobiA9PiBwYXJlbnQuaW5zZXJ0QmVmb3JlKG4uY2xvbmVOb2RlKHRydWUpLCBsb2FkZXIpKTtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXJlbnQuaW5zZXJ0QmVmb3JlKGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKGNoaWxkKSwgbG9hZGVyKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkoY2hpbGQpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgbm9kZSBvZiBjaGlsZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBhcHBlbmQobm9kZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBwYXJlbnQuaW5zZXJ0QmVmb3JlKGNoaWxkLCBsb2FkZXIpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gWWVzKCkge1xyXG4gICAgY29uc3QgZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdpJyk7XHJcbiAgICBlbC5jbGFzc05hbWUgPSAnZ2x5cGhpY29uIGdseXBoaWNvbi1vayc7XHJcbiAgICBlbC5zdHlsZS5jb2xvciA9ICdncmVlbic7XHJcbiAgICByZXR1cm4gZWw7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBObygpIHtcclxuICAgIGNvbnN0IGVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaScpO1xyXG4gICAgZWwuY2xhc3NOYW1lID0gJ2dseXBoaWNvbiBnbHlwaGljb24tcmVtb3ZlJztcclxuICAgIGVsLnN0eWxlLmNvbG9yID0gJ3JlZCc7XHJcbiAgICByZXR1cm4gZWw7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBRdWVzdGlvbihbdGl0bGUsIGFuc3dlcnNdKSB7XHJcbiAgICByZXR1cm4gZWxlbWVudCgnZGl2JywgW1xyXG4gICAgICAgIGVsZW1lbnQoJ2gyJywgdGl0bGUpLFxyXG4gICAgICAgIGVsZW1lbnQoJ3VsJywgT2JqZWN0LmVudHJpZXMoYW5zd2VycykubWFwKChbYSwgaXNDb3JyZWN0XSkgPT4gZWxlbWVudCgnbGknLCBhLCB7IGNsYXNzTGlzdDogaXNDb3JyZWN0ID8gJ2NvcnJlY3QtYW5zd2VyJyA6ICdub25lJyB9LCB0cnVlKSkpXHJcbiAgICBdLCB7IGNsYXNzTGlzdDogJ3F1ZXN0aW9uLWNvbnRhaW5lcicgfSk7XHJcbn07XHJcblxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIEFsZXJ0KCkge1xyXG4gICAgY29uc3QgZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdpJyk7XHJcbiAgICBlbC5jbGFzc05hbWUgPSAnZ2x5cGhpY29uIGdseXBoaWNvbi13YXJuaW5nLXNpZ24nO1xyXG4gICAgZWwuc3R5bGUuY29sb3IgPSAnb3JhbmdlJztcclxuICAgIHJldHVybiBlbDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIENvbnRhaW5lcih7IGNoaWxkcmVuLCBjbGFzc05hbWUgfSkge1xyXG4gICAgY29uc3Qgc2VjdGlvbiA9IGVsZW1lbnQoJ3NlY3Rpb24nLCBjaGlsZHJlbiwge1xyXG4gICAgICAgIGNsYXNzTmFtZTogY2xhc3NOYW1lID8gJ2V2ZW50LWNvbnRhaW5lcicgOiAnY29udGFpbmVyJ1xyXG4gICAgfSk7XHJcbiAgICBjb25zdCBlbCA9IGVsZW1lbnQoJ2RpdicsIHNlY3Rpb24sIHtcclxuICAgICAgICBjbGFzc05hbWU6IGNsYXNzTmFtZSA/IGNsYXNzTmFtZSA6ICdjb250YWluZXIgYWRtaW5pc3RyYXRpb24tY29udGFpbmVyIHNlcy1jb250YWluZXInXHJcbiAgICB9KTtcclxuICAgIHJldHVybiBlbDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHBvcHVwVGFibGUoZGF0YSkge1xyXG4gICAgbGV0IGh0bWwgPSBgXHJcbiAgICAgICAgPHN0eWxlPlxyXG4gICAgICAgICAgICB0YWJsZSB7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRyLCB0ZCwgdGgge1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgYmxhY2s7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAwLjI1ZW0gMC41ZW07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICA8L3N0eWxlPlxyXG4gICAgICAgIGA7XHJcbiAgICBodG1sICs9ICc8dGFibGU+PHRoZWFkPjx0cj4nO1xyXG4gICAgZm9yIChsZXQgY29sIG9mIGRhdGFbMF0pIHtcclxuICAgICAgICBodG1sICs9IGA8dGg+JHtjb2x9PC90aD5gO1xyXG4gICAgfVxyXG4gICAgaHRtbCArPSAnPC90cj48L3RoZWFkPjx0Ym9keT4nO1xyXG4gICAgZm9yIChsZXQgcm93ID0gMTsgcm93IDwgZGF0YS5sZW5ndGg7IHJvdysrKSB7XHJcbiAgICAgICAgaHRtbCArPSAnPHRyPic7XHJcbiAgICAgICAgZm9yIChsZXQgY29sIG9mIGRhdGFbcm93XSkge1xyXG4gICAgICAgICAgICBodG1sICs9IGA8dGQ+JHtjb2x9PC90ZD5gO1xyXG4gICAgICAgIH1cclxuICAgICAgICBodG1sICs9ICc8L3RyPic7XHJcbiAgICB9XHJcbiAgICBodG1sICs9ICc8L3Rib2R5PjwvdGFibGU+JztcclxuICAgIHJldHVybiBodG1sO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0RWRpdG9yRGVjb3JhdGlvbihlbGVtZW50KSB7XHJcbiAgICBmdW5jdGlvbiBlbmFibGUoKSB7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QuYWRkKCdlbmFibGVkJyk7XHJcbiAgICB9XHJcbiAgICBmdW5jdGlvbiBkaXNhYmxlKCkge1xyXG4gICAgICAgIGVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnZW5hYmxlZCcpO1xyXG4gICAgfVxyXG4gICAgZnVuY3Rpb24gd29ya2luZygpIHtcclxuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ2VuYWJsZWQnKTtcclxuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5hZGQoJ3dvcmtpbmcnKTtcclxuICAgIH1cclxuICAgIGZ1bmN0aW9uIHVwZGF0ZWQoKSB7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCd3b3JraW5nJyk7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QuYWRkKCd1cGRhdGVkJyk7XHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ3VwZGF0ZWQnKSwgMzAwMCk7XHJcbiAgICB9XHJcbiAgICBmdW5jdGlvbiBmYWlsdXJlKCkge1xyXG4gICAgICAgIGVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnd29ya2luZycpO1xyXG4gICAgICAgIGVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnZmFpbGVkJyk7XHJcbiAgICB9XHJcbiAgICBmdW5jdGlvbiBfY2xlYXIoKSB7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdlbmFibGVkJyk7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCd3b3JraW5nJyk7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCd1cGRhdGVkJyk7XHJcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdmYWlsZWQnKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGVuYWJsZSxcclxuICAgICAgICBkaXNhYmxlLFxyXG4gICAgICAgIHdvcmtpbmcsXHJcbiAgICAgICAgdXBkYXRlZCxcclxuICAgICAgICBmYWlsdXJlLFxyXG4gICAgICAgIF9jbGVhclxyXG4gICAgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGFwcGx5QmVnaW5SZXF1ZXN0KGVsZW1lbnQpIHtcclxuICAgIGVsZW1lbnQuY2hpbGROb2Rlcy5mb3JFYWNoKGMgPT4gYy5jaGlsZE5vZGVzLmZvckVhY2gobiA9PiBuLmRpc2FibGVkID0gdHJ1ZSkpO1xyXG4gICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdlbmFibGVkJyk7XHJcbiAgICBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ2ZhaWxlZCcpO1xyXG4gICAgZWxlbWVudC5jbGFzc0xpc3QuYWRkKCd3b3JraW5nJyk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBhcHBseVJlcXVlc3RTdWNjZXNzKGVsZW1lbnQpIHtcclxuICAgIGVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnd29ya2luZycpO1xyXG4gICAgZWxlbWVudC5jbGFzc0xpc3QuYWRkKCd1cGRhdGVkJyk7XHJcbiAgICBzZXRUaW1lb3V0KCgpID0+IGVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgndXBkYXRlZCcpLCAzMDAwKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGFwcGx5UmVxdWVzdEVycm9yKHJlZkVsZW1lbnQsIGVycm9yQ29udGFpbmVyLCBmaWVsZHMpIHtcclxuICAgIHJlZkVsZW1lbnQuY2hpbGROb2Rlcy5mb3JFYWNoKGMgPT4gYy5jaGlsZE5vZGVzLmZvckVhY2gobiA9PiBuLmRpc2FibGVkID0gZmFsc2UpKTtcclxuICAgIHJlZkVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnd29ya2luZycpO1xyXG4gICAgcmVmRWxlbWVudC5jbGFzc0xpc3QuYWRkKCdmYWlsZWQnKTtcclxuICAgIGNvbnNvbGUud2FybihlcnJvckNvbnRhaW5lcik7XHJcbiAgICBpZiAoZXJyb3JDb250YWluZXIubWVzc2FnZSAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgYWxlcnQoZXJyb3JDb250YWluZXIubWVzc2FnZSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIGZvciAobGV0IGVycm9yIG9mIE9iamVjdC5rZXlzKGVycm9yQ29udGFpbmVyKSkge1xyXG4gICAgICAgICAgICBpZiAoZXJyb3IubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgIGFsZXJ0KGVycm9yQ29udGFpbmVyW2Vycm9yXS5lcnJvcnMuam9pbignXFxuJykpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgZmllbGQgPSBmaWVsZHNbZXJyb3JdO1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgbWVzc2FnZSBvZiBlcnJvckNvbnRhaW5lcltlcnJvcl0uZXJyb3JzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZmllbGQuYXBwZW5kQ2hpbGQoZWxlbWVudCgncCcsIG1lc3NhZ2UpKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUNoZWNrYm94KG5hbWUsIGRhdGEsIHRleHQsIG9uQ2hhbmdlLCBkZWZhdWx0VmFsdWUgPSBmYWxzZSkge1xyXG4gICAgY29uc3QgaWQgPSAnc2VzLScgKyBuYW1lO1xyXG4gICAgbGV0IHZhbHVlID0gcmVhZFByZXZJbnB1dCgpO1xyXG4gICAgZGF0YVtuYW1lXSA9IHZhbHVlO1xyXG4gICAgbGV0IGVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdpbnB1dCcpO1xyXG4gICAgZWxlbWVudC50eXBlID0gJ2NoZWNrYm94JztcclxuICAgIGVsZW1lbnQuaWQgPSBpZDtcclxuICAgIGVsZW1lbnQubmFtZSA9IG5hbWU7XHJcbiAgICBsZXQgbGFiZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsYWJlbCcpO1xyXG4gICAgbGFiZWwuaHRtbEZvciA9IGlkO1xyXG4gICAgbGFiZWwudGV4dENvbnRlbnQgPSB0ZXh0O1xyXG5cclxuICAgIC8qXHJcbiAgICBsZXQgZWxlbWVudCA9IDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBjbGFzc05hbWU9XCJzZXMtY2hlY2tcIiBpZD17aWR9IG5hbWU9e25hbWV9IC8+O1xyXG4gICAgbGV0IGxhYmVsID0gPGxhYmVsIGZvcj17aWR9Pnt0ZXh0fTwvbGFiZWw+O1xyXG4gICAgKi9cclxuICAgIGVsZW1lbnQuY2hlY2tlZCA9IHZhbHVlO1xyXG4gICAgZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCB0b2dnbGUpO1xyXG5cclxuICAgIGZ1bmN0aW9uIHJlYWRQcmV2SW5wdXQoKSB7XHJcbiAgICAgICAgbGV0IHByZXZJbnB1dCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKTtcclxuICAgICAgICBpZiAocHJldklucHV0KSB7XHJcbiAgICAgICAgICAgIHJldHVybiBwcmV2SW5wdXQuY2hlY2tlZDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gZGVmYXVsdFZhbHVlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiB0b2dnbGUoZSkge1xyXG4gICAgICAgIHZhbHVlID0gZS50YXJnZXQuY2hlY2tlZDtcclxuICAgICAgICBkYXRhW25hbWVdID0gdmFsdWU7XHJcbiAgICAgICAgcmVkcmF3KCk7XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gcmVkcmF3KCkge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlKCk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVyci5tZXNzYWdlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgY2hlY2tib3ggPSB7XHJcbiAgICAgICAgZWxlbWVudCxcclxuICAgICAgICBsYWJlbFxyXG4gICAgfTtcclxuXHJcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoY2hlY2tib3gsICd2YWx1ZScsIHtcclxuICAgICAgICBnZXQ6ICgpID0+IHZhbHVlLFxyXG4gICAgICAgIHNldDogKG5ld1ZhbHVlKSA9PiB7XHJcbiAgICAgICAgICAgIHZhbHVlID0gbmV3VmFsdWU7XHJcbiAgICAgICAgICAgIGVsZW1lbnQuY2hlY2tlZCA9IHZhbHVlO1xyXG4gICAgICAgICAgICBkYXRhW25hbWVdID0gdmFsdWU7XHJcbiAgICAgICAgICAgIHJlZHJhdygpO1xyXG4gICAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiBjaGVja2JveDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHRhYmxlKGRhdGEsIGxheW91dCkge1xyXG4gICAgY29uc3QgdGhlYWQgPSBlbGVtZW50KCd0aGVhZCcsIGVsZW1lbnQoJ3RyJywgbGF5b3V0Lm1hcChoID0+IGVsZW1lbnQoJ3RoJywgaC5sYWJlbCkpKSk7XHJcbiAgICBjb25zdCB0Ym9keSA9IGVsZW1lbnQoJ3Rib2R5JywgZGF0YS5tYXAociA9PiBlbGVtZW50KCd0cicsIGxheW91dC5tYXAoaCA9PiBlbGVtZW50KCd0ZCcsIHJbaC5uYW1lXSkpKSkpO1xyXG5cclxuICAgIGNvbnN0IHRhYmxlID0gZWxlbWVudCgndGFibGUnLCBbdGhlYWQsIHRib2R5XSk7XHJcbiAgICB0YWJsZS50aGVhZCA9IHRoZWFkO1xyXG4gICAgdGFibGUudGJvZHkgPSB0Ym9keTtcclxuXHJcbiAgICByZXR1cm4gdGFibGU7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBBdXRvY29tcGxldGUoeyB2YWx1ZXMsIGN1cnJlbnQgfSkge1xyXG4gICAgbGV0IGF1dG9jb21wbGV0ZSA9IGVsZW1lbnQoJ2RpdicsIFtcclxuICAgICAgICBlbGVtZW50KCdpbnB1dCcsIHVuZGVmaW5lZCwgeyBjbGFzc05hbWU6ICdzZXMtc2VhcmNoLWF1dG9jb21wbGV0ZS1pbnB1dCcgfSksXHJcbiAgICAgICAgZWxlbWVudCgnZGl2JywgZWxlbWVudCgndWwnKSwgeyBjbGFzc05hbWU6ICdzZXMtc2VhcmNoLWF1dG9jb21wbGV0ZS1zdWdnZXN0aW9ucycgfSlcclxuICAgIF0sIHsgY2xhc3NOYW1lOiAnc2VzLXNlYXJjaC1hdXRvY29tcGxldGUtY29udGFpbmVyJyB9KTtcclxuXHJcbiAgICBjb25zdCBzdWdnZXN0aW9uc0NvbnRhaW5lciA9IGF1dG9jb21wbGV0ZS5xdWVyeVNlbGVjdG9yKCcuc2VzLXNlYXJjaC1hdXRvY29tcGxldGUtc3VnZ2VzdGlvbnMnKTtcclxuICAgIGNvbnN0IGlucHV0ID0gYXV0b2NvbXBsZXRlLnF1ZXJ5U2VsZWN0b3IoJy5zZXMtc2VhcmNoLWF1dG9jb21wbGV0ZS1pbnB1dCcpO1xyXG4gICAgbGV0IHNlbGVjdGVkSW5kZXggPSB1bmRlZmluZWQ7XHJcblxyXG4gICAgaWYgKGN1cnJlbnQgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgaW5wdXQudmFsdWUgPSBjdXJyZW50O1xyXG4gICAgfVxyXG5cclxuICAgIGF1dG9jb21wbGV0ZS5nZXRWYWx1ZSA9IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICByZXR1cm4gaW5wdXQudmFsdWU7XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gc2VhcmNoSGFuZGxlcihlKSB7XHJcbiAgICAgICAgY29uc3QgaW5wdXRWYWwgPSBlLmN1cnJlbnRUYXJnZXQudmFsdWU7XHJcbiAgICAgICAgbGV0IHJlc3VsdHMgPSB2YWx1ZXM7XHJcbiAgICAgICAgaWYgKGlucHV0VmFsLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgcmVzdWx0cyA9IHZhbHVlcy5maWx0ZXIoeCA9PiB4LnRvTG93ZXJDYXNlKCkuaW5kZXhPZihpbnB1dFZhbC50b0xvd2VyQ2FzZSgpKSA+IC0xKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgc2hvd1N1Z2dlc3Rpb25zKHJlc3VsdHMsIGlucHV0VmFsKTtcclxuICAgICAgICBpZiAoZS5rZXlDb2RlID09PSAzOCB8fCBlLmtleUNvZGUgPT09IDQwIHx8IGUua2V5Q29kZSA9PT0gMTMpIHtcclxuICAgICAgICAgICAgc2Nyb2xsUmVzdWx0cyhlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gc2hvd1N1Z2dlc3Rpb25zKHJlc3VsdHMsIGlucHV0VmFsKSB7XHJcbiAgICAgICAgbGV0IHN1Z2dlc3Rpb25zID0gc3VnZ2VzdGlvbnNDb250YWluZXIucXVlcnlTZWxlY3RvcigndWwnKTtcclxuICAgICAgICByZXBsYWNlQ29udGVudHMoc3VnZ2VzdGlvbnMsICcnKTtcclxuICAgICAgICBzdWdnZXN0aW9ucyA9IHN1Z2dlc3Rpb25zQ29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoJ3VsJyk7O1xyXG5cclxuICAgICAgICBpZiAocmVzdWx0cy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcmVzdWx0cy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgbGV0IGl0ZW0gPSByZXN1bHRzW2ldO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgbWF0Y2ggPSBpdGVtLm1hdGNoKG5ldyBSZWdFeHAoaW5wdXRWYWwsICdpJykpO1xyXG4gICAgICAgICAgICAgICAgaXRlbSA9IGl0ZW0ucmVwbGFjZShtYXRjaFswXSwgYDxzdHJvbmc+JHttYXRjaFswXX08L3N0cm9uZz5gKTtcclxuICAgICAgICAgICAgICAgIGxldCBuZXdMaSA9IGVsZW1lbnQoJ2xpJywgaXRlbSwgdW5kZWZpbmVkLCB7IGZvcmNlVHlwZTogXCJIVE1MXCIgfSk7XHJcbiAgICAgICAgICAgICAgICBzdWdnZXN0aW9ucy5hcHBlbmRDaGlsZChuZXdMaSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgc3VnZ2VzdGlvbnMuY2xhc3NMaXN0LmFkZCgnaGFzLXN1Z2dlc3Rpb25zJyk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgc3VnZ2VzdGlvbnMuY2xhc3NMaXN0LnJlbW92ZSgnaGFzLXN1Z2dlc3Rpb25zJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGZ1bmN0aW9uIHVzZVN1Z2dlc3Rpb24oZSkge1xyXG4gICAgICAgIGlucHV0LnZhbHVlID0gZS50YXJnZXQudGV4dENvbnRlbnQ7XHJcbiAgICAgICAgaW5wdXQuZm9jdXMoKTtcclxuICAgICAgICBsZXQgc3VnZ2VzdGlvbnMgPSBzdWdnZXN0aW9uc0NvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCd1bCcpO1xyXG4gICAgICAgIHJlcGxhY2VDb250ZW50cyhzdWdnZXN0aW9ucywgJycpO1xyXG4gICAgICAgIHN1Z2dlc3Rpb25zID0gc3VnZ2VzdGlvbnNDb250YWluZXIucXVlcnlTZWxlY3RvcigndWwnKTtcclxuICAgICAgICBzdWdnZXN0aW9ucy5jbGFzc0xpc3QucmVtb3ZlKCdoYXMtc3VnZ2VzdGlvbnMnKTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBzY3JvbGxSZXN1bHRzKGUpIHtcclxuICAgICAgICBsZXQgYWxsU3VnZ2VzdGlvbnMgPSBbLi4uc3VnZ2VzdGlvbnNDb250YWluZXIucXVlcnlTZWxlY3RvckFsbCgndWwgbGknKV07XHJcbiAgICAgICAgbGV0IG9sZEluZGV4ID0gdW5kZWZpbmVkO1xyXG4gICAgICAgIGxldCBpbmRleENoYW5nZSA9IDE7XHJcblxyXG4gICAgICAgIC8vIGVudGVyXHJcbiAgICAgICAgaWYgKGUua2V5Q29kZSA9PT0gMTMpIHtcclxuICAgICAgICAgICAgaW5wdXQudmFsdWUgPSBhbGxTdWdnZXN0aW9uc1tzZWxlY3RlZEluZGV4XS50ZXh0Q29udGVudDtcclxuICAgICAgICAgICAgc2VsZWN0ZWRJbmRleCA9IHVuZGVmaW5lZDtcclxuICAgICAgICAgICAgbGV0IHN1Z2dlc3Rpb25zID0gc3VnZ2VzdGlvbnNDb250YWluZXIucXVlcnlTZWxlY3RvcigndWwnKTtcclxuICAgICAgICAgICAgc3VnZ2VzdGlvbnMuY2xhc3NMaXN0LnJlbW92ZSgnaGFzLXN1Z2dlc3Rpb25zJyk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChlLmtleUNvZGUgPT09IDQwKSB7XHJcbiAgICAgICAgICAgIC8vIGRvd24gYXJyb3dcclxuICAgICAgICAgICAgaW5kZXhDaGFuZ2UgPSAxO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoZS5rZXlDb2RlID09PSAzOCkge1xyXG4gICAgICAgICAgICAvLyB1cCBhcnJvd1xyXG4gICAgICAgICAgICBpbmRleENoYW5nZSA9IC0xO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHNlbGVjdGVkSW5kZXggPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIHNlbGVjdGVkSW5kZXggPSBpbmRleENoYW5nZSA9PT0gMSA/IDAgOiBhbGxTdWdnZXN0aW9ucy5sZW5ndGggLSAxO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIG9sZEluZGV4ID0gc2VsZWN0ZWRJbmRleDtcclxuICAgICAgICAgICAgc2VsZWN0ZWRJbmRleCA9ICgoc2VsZWN0ZWRJbmRleCArIGluZGV4Q2hhbmdlKSArIGFsbFN1Z2dlc3Rpb25zLmxlbmd0aCkgJSBhbGxTdWdnZXN0aW9ucy5sZW5ndGg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAob2xkSW5kZXggIT09IHVuZGVmaW5lZCAmJiBvbGRJbmRleCA8IGFsbFN1Z2dlc3Rpb25zLmxlbmd0aCkge1xyXG4gICAgICAgICAgICBhbGxTdWdnZXN0aW9uc1tvbGRJbmRleF0uY2xhc3NMaXN0LnJlbW92ZSgnc2VsZWN0ZWQnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGFsbFN1Z2dlc3Rpb25zW3NlbGVjdGVkSW5kZXhdLmNsYXNzTGlzdC5hZGQoJ3NlbGVjdGVkJyk7XHJcbiAgICB9XHJcblxyXG4gICAgaW5wdXQuYWRkRXZlbnRMaXN0ZW5lcigna2V5dXAnLCBzZWFyY2hIYW5kbGVyKTtcclxuICAgIHN1Z2dlc3Rpb25zQ29udGFpbmVyLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgdXNlU3VnZ2VzdGlvbik7XHJcbiAgICByZXR1cm4gYXV0b2NvbXBsZXRlO1xyXG59XHJcblxyXG4vKipcclxuICogQ3JlYXRlcyBhIHNwYW4gZWxlbWVudCB0aGF0IHJlcHJlc2VudHMgYSBkb3dubG9hZCBwcm9ncmVzcyBiYXJcclxuICogQHBhcmFtIHsge2Rvd25sb2FkRnVuY3Rpb246IChvblByb2dyZXNzOiBpbXBvcnQoJy4vdXRpbC5qcycpLk9uUHJvZ3Jlc3NGdW5jdGlvbiksIHJldHVybkZ1bmN0aW9uOiBmdW5jdGlvbn0gfSBzZXR0aW5ncyBDb250YWlucyB0aGUgZnVuY3Rpb24gdGhhdCB3aWxsIGRvd25sb2FkIHRoZSByZXNvdXJjZXMsIHdoaWNoIHdpbGwgYmUgY2FsbGVkIHdpdGggb25Qcm9ncmVzc1xyXG4gKiBhbmQgdGhlIHJldHVybkZ1bmN0aW9uIHdoaWNoIHdpbGwgYmUgY2FsbGVkIHdpdGggdGhlIHJlc3VsdHMgYWZ0ZXIgdGhlIGRvd25sb2FkIGZpbmlzaGVzXHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gRG93bmxvYWRQcm9ncmVzc0Jhcih7IGRvd25sb2FkRnVuY3Rpb24sIHJldHVybkZ1bmN0aW9uIH0pIHtcclxuICAgIGNvbnN0IHBlcmNlbnQgPSA8c3Bhbj4wJTwvc3Bhbj47XHJcbiAgICBjb25zdCBiYXIgPSA8c3BhbiBzdHlsZT17eyBwYWRkaW5nOiAnMCAwLjVlbScsIGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snLCB3aWR0aDogJzI1JScsIGJhY2tncm91bmQ6ICdsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICNmZmEwMDAgMCUsICNlZWUgMCknIH19PntwZXJjZW50fSDQodCy0LDQu9GP0L3QtTwvc3Bhbj47XHJcbiAgICBkb3dubG9hZEZ1bmN0aW9uKG9uUHJvZ3Jlc3MpLnRoZW4oZGF0YSA9PiB7XHJcbiAgICAgICAgaWYgKHJldHVybkZ1bmN0aW9uKSB7XHJcbiAgICAgICAgICAgIHJldHVybkZ1bmN0aW9uKGRhdGEpXHJcbiAgICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIGJhcjtcclxuXHJcbiAgICBmdW5jdGlvbiBvblByb2dyZXNzKGNvbXBsZXRlZCwgdG90YWwsIHJlc3BvbnNlLCBpbmRleCkge1xyXG4gICAgICAgIGNvbnN0IHByb2dyZXNzID0gTWF0aC5mbG9vcihjb21wbGV0ZWQgLyB0b3RhbCAqIDEwMCk7XHJcbiAgICAgICAgcGVyY2VudC50ZXh0Q29udGVudCA9IHByb2dyZXNzICsgJyUnO1xyXG4gICAgICAgIGJhci5zdHlsZS5iYWNrZ3JvdW5kID0gYGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgI2ZmYTAwMCAke3Byb2dyZXNzfSUsICNlZWUgMClgO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCB7XHJcbiAgICBlbGVtZW50XHJcbn07IiwiLyogZ2xvYmFscyB4bHN4LCBKU1ppcCAqL1xyXG5cclxuaW1wb3J0IHBhcnNlIGZyb20gJy4vcGFyc2UnO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGltcG9ydFF1aXpGcm9tWGxzeChibG9iKSB7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XHJcbiAgICAgICAgcmVhZGVyLm9ubG9hZCA9IGZ1bmN0aW9uIChlKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGZpbGVEYXRhID0gZS50YXJnZXQucmVzdWx0O1xyXG4gICAgICAgICAgICBjb25zdCB3YiA9IHhsc3gucmVhZChmaWxlRGF0YSwge1xyXG4gICAgICAgICAgICAgICAgdHlwZTogJ2JpbmFyeSdcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIGNvbnN0IGZpcnN0U2hlZXQgPSB3Yi5TaGVldHNbd2IuU2hlZXROYW1lc1swXV07XHJcbiAgICAgICAgICAgIGNvbnN0IGFwaURhdGEgPSB4bHN4LnV0aWxzXHJcbiAgICAgICAgICAgICAgICAuc2hlZXRfdG9fanNvbihmaXJzdFNoZWV0LCB7IGhlYWRlcjogMSB9KVxyXG4gICAgICAgICAgICAgICAgLnNsaWNlKDEpIC8vIHJlbW92ZSBmaXJzdCByb3dcclxuICAgICAgICAgICAgICAgIC5yZWR1Y2UoKGRhdGEsIGN1cnJlbnRSb3cpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoY3VycmVudFJvdy5sZW5ndGggIT09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY29ycmVjdEFuc3dlckluZGV4ID0gY3VycmVudFJvdy5wb3AoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcXVlc3Rpb24gPSBjdXJyZW50Um93WzBdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBhbGxBbnN3ZXJzID0gY3VycmVudFJvdy5zbGljZSgxKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY29ycmVjdEFuc3dlciA9IGN1cnJlbnRSb3dbY29ycmVjdEFuc3dlckluZGV4XTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGFbcXVlc3Rpb25dID0gYWxsQW5zd2Vycy5yZWR1Y2UoKGFuc3dlcnMsIGEpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChhICE9IHVuZGVmaW5lZCAmJiBhLnRvU3RyaW5nKCkudHJpbSgpICE9PSAnJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuc3dlcnNbYV0gPSBhID09PSBjb3JyZWN0QW5zd2VyO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBhbnN3ZXJzO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LCB7fSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZGF0YTtcclxuICAgICAgICAgICAgICAgIH0sIHt9KTtcclxuXHJcbiAgICAgICAgICAgIHJlc29sdmUoYXBpRGF0YSk7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgcmVhZGVyLnJlYWRBc0JpbmFyeVN0cmluZyhibG9iKTtcclxuICAgIH0pO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaW1wb3J0RnJvbVhsc3goYmxvYiwgdXNlQ2VsbERhdGVzID0gZmFsc2UpIHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcclxuICAgICAgICByZWFkZXIub25sb2FkID0gZnVuY3Rpb24gKGUpIHtcclxuICAgICAgICAgICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LnJlc3VsdDtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHdiID0geGxzeC5yZWFkKGZpbGUsIHtcclxuICAgICAgICAgICAgICAgICAgICB0eXBlOiAnYmluYXJ5JyxcclxuICAgICAgICAgICAgICAgICAgICBjZWxsRGF0ZXM6IHVzZUNlbGxEYXRlc1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBmaXJzdFNoZWV0ID0gd2IuU2hlZXRzW3diLlNoZWV0TmFtZXNbMF1dO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgZGF0YSA9IHhsc3gudXRpbHMuc2hlZXRfdG9fanNvbihmaXJzdFNoZWV0LCB7IGhlYWRlcjogMSB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICByZXNvbHZlKGRhdGEpO1xyXG4gICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdFcnJvciBwYXJzaW5nIFhMU1ggZmlsZSwgbWFrZSBzdXJlIHRoZSBsaWJyYXJ5IGlzIGxvYWRlZCcpO1xyXG4gICAgICAgICAgICAgICAgcmVqZWN0KGVycik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgICAgIHJlYWRlci5vbmVycm9yID0gZnVuY3Rpb24gKGUpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ0Vycm9yIHJlYWRpbmcgZmlsZScpO1xyXG4gICAgICAgICAgICByZWplY3QoZSk7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgcmVhZGVyLnJlYWRBc0JpbmFyeVN0cmluZyhibG9iKTtcclxuICAgIH0pO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdG9YbHN4RmlsZSh0YWJsZSwgbmFtZSA9ICdPdXRwdXQnLCB3c19uYW1lKSB7XHJcbiAgICBpZiAod3NfbmFtZSA9PT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgd3NfbmFtZSA9IG5hbWUuc2xpY2UoMCwgMzEpO1xyXG4gICAgfVxyXG4gICAgY29uc3Qgd2IgPSB4bHN4LnV0aWxzLmJvb2tfbmV3KCksIHdzID0geGxzeC51dGlscy5hb2FfdG9fc2hlZXQodGFibGUpO1xyXG4gICAgLy8gd2IuV29ya2Jvb2sgPSB7IFZpZXdzOiBbJ1dpbmRvdzInXSB9O1xyXG4gICAgeGxzeC51dGlscy5ib29rX2FwcGVuZF9zaGVldCh3Yiwgd3MsIHdzX25hbWUpO1xyXG4gICAgY29uc3QgZGF0YSA9IHhsc3gud3JpdGUod2IsIHtcclxuICAgICAgICB0eXBlOiAnYXJyYXknLFxyXG4gICAgICAgIGJvb2tUeXBlOiAneGxzeCdcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IGZpbGUgPSBuZXcgRmlsZShbZGF0YV0sIG5hbWUgKyAnLnhsc3gnLCB7IHR5cGU6ICdhcHBsaWNhdGlvbi92bmQub3BlbnhtbGZvcm1hdHMtb2ZmaWNlZG9jdW1lbnQuc3ByZWFkc2hlZXRtbC5zaGVldCcgfSk7XHJcblxyXG4gICAgcmV0dXJuIGZpbGU7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiB0b0xlZ2FjeVhsc0ZpbGUodGFibGUsIG5hbWUgPSAnT3V0cHV0Jywgd3NfbmFtZSkge1xyXG4gICAgaWYgKHdzX25hbWUgPT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgIHdzX25hbWUgPSBuYW1lLnNsaWNlKDAsIDMxKTtcclxuICAgIH1cclxuICAgIGNvbnN0IHdiID0geGxzeC51dGlscy5ib29rX25ldygpLCB3cyA9IHhsc3gudXRpbHMuYW9hX3RvX3NoZWV0KHRhYmxlKTtcclxuICAgIHdiLldvcmtib29rID0geyBWaWV3czogWydXaW5kb3cyJ10gfTtcclxuICAgIHhsc3gudXRpbHMuYm9va19hcHBlbmRfc2hlZXQod2IsIHdzLCB3c19uYW1lKTtcclxuICAgIGNvbnN0IGRhdGEgPSB4bHN4LndyaXRlKHdiLCB7XHJcbiAgICAgICAgdHlwZTogJ2FycmF5JyxcclxuICAgICAgICBib29rVHlwZTogJ2JpZmY4J1xyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgZmlsZSA9IG5ldyBGaWxlKFtkYXRhXSwgbmFtZSArICcueGxzJywgeyB0eXBlOiAnYXBwbGljYXRpb24vdm5kLm1zLWV4Y2VsJyB9KTtcclxuXHJcbiAgICByZXR1cm4gZmlsZTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGV4cG9ydFRvWGxzeCh0YWJsZSwgbmFtZSA9ICdPdXRwdXQnLCB3c19uYW1lKSB7XHJcbiAgICBjb25zdCBmaWxlbmFtZSA9IGAke25hbWV9Lnhsc3hgO1xyXG4gICAgaWYgKHdzX25hbWUgPT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgIHdzX25hbWUgPSBuYW1lLnNsaWNlKDAsIDMxKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBTaGVldCBuYW1lIGNhbm5vdCBjb250YWluOiBcXCAvID8gKiBbIF1cclxuICAgIGNvbnN0IHNoZWV0UmVnZXggPSAvW1xcW1xcXVxcXFxcXC9cXCpdL2dpO1xyXG4gICAgaWYgKHNoZWV0UmVnZXgudGVzdCh3c19uYW1lKSkge1xyXG4gICAgICAgIHdzX25hbWUgPSB3c19uYW1lLnJlcGxhY2Uoc2hlZXRSZWdleCwgJy0nKTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCB3YiA9IHhsc3gudXRpbHMuYm9va19uZXcoKSwgd3MgPSB4bHN4LnV0aWxzLmFvYV90b19zaGVldCh0YWJsZSk7XHJcbiAgICB4bHN4LnV0aWxzLmJvb2tfYXBwZW5kX3NoZWV0KHdiLCB3cywgd3NfbmFtZSk7XHJcbiAgICB4bHN4LndyaXRlRmlsZSh3YiwgZmlsZW5hbWUpO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZXhwb3J0UGF5bWVudHNUb1hsc3goZGF0YSwgeWVhciwgbW9udGgpIHtcclxuICAgIGNvbnN0IGZpbGVuYW1lID0gYFBheW1lbnRzLSR7cGFyc2UubW9udGhOYW1lW21vbnRoXX0tJHt5ZWFyfS54bHN4YDtcclxuICAgIGNvbnN0IHdzX25hbWUgPSBgUGF5bWVudHMgJHtwYXJzZS5tb250aE5hbWVbbW9udGhdfSAke3llYXJ9YDtcclxuICAgIGNvbnN0IHdiID0geGxzeC51dGlscy5ib29rX25ldygpLCB3cyA9IHhsc3gudXRpbHMuYW9hX3RvX3NoZWV0KGRhdGEpO1xyXG4gICAgeGxzeC51dGlscy5ib29rX2FwcGVuZF9zaGVldCh3Yiwgd3MsIHdzX25hbWUpO1xyXG4gICAgeGxzeC53cml0ZUZpbGUod2IsIGZpbGVuYW1lKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGV4cG9ydFRvSnNvbihkYXRhLCBuYW1lID0gJ091dHB1dCcpIHtcclxuICAgIGNvbnN0IGJsb2IgPSBuZXcgQmxvYihbZGF0YV0sIHsgdHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nIH0pO1xyXG4gICAgaWYgKHdpbmRvdy5uYXZpZ2F0b3IubXNTYXZlT3JPcGVuQmxvYikge1xyXG4gICAgICAgIHdpbmRvdy5uYXZpZ2F0b3IubXNTYXZlQmxvYihibG9iLCBuYW1lICsgJy5qc29uJyk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIHZhciBlbGVtID0gd2luZG93LmRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcclxuICAgICAgICBlbGVtLmhyZWYgPSB3aW5kb3cuVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTtcclxuICAgICAgICBlbGVtLmRvd25sb2FkID0gbmFtZSArICcuanNvbic7XHJcbiAgICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChlbGVtKTtcclxuICAgICAgICBlbGVtLmNsaWNrKCk7XHJcbiAgICAgICAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChlbGVtKTtcclxuICAgIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIEBwYXJhbSB7e2ZvbGRlcjogc3RyaW5nLCBmaWxlczogRmlsZVtdfVtdfSBmaWxlcyBcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB6aXBGaWxlcyhmaWxlcykge1xyXG4gICAgY29uc3QgemlwID0gbmV3IEpTWmlwKCk7XHJcbiAgICBmb3IgKGxldCBlbnRyeSBvZiBmaWxlcykge1xyXG4gICAgICAgIGNvbnN0IGN1cnJlbnQgPSB6aXAuZm9sZGVyKGVudHJ5LmZvbGRlcik7XHJcbiAgICAgICAgY3VycmVudC5maWxlKGVudHJ5LmZpbGVzLnBob3RvLm5hbWUsIGF3YWl0IGJsb2JUb0Jhc2U2NChlbnRyeS5maWxlcy5waG90by5maWxlKSwgeyBiYXNlNjQ6IHRydWUgfSk7XHJcbiAgICAgICAgY3VycmVudC5maWxlKGVudHJ5LmZpbGVzLm1lZGljYWwubmFtZSwgYXdhaXQgYmxvYlRvQmFzZTY0KGVudHJ5LmZpbGVzLm1lZGljYWwuZmlsZSksIHsgYmFzZTY0OiB0cnVlIH0pO1xyXG4gICAgICAgIGN1cnJlbnQuZmlsZShlbnRyeS5maWxlcy5kaXBsb21hLm5hbWUsIGF3YWl0IGJsb2JUb0Jhc2U2NChlbnRyeS5maWxlcy5kaXBsb21hLmZpbGUpLCB7IGJhc2U2NDogdHJ1ZSB9KTtcclxuICAgIH1cclxuICAgIHJldHVybiB6aXAuZ2VuZXJhdGVBc3luYyh7IHR5cGU6ICdibG9iJyB9KTtcclxuXHJcbiAgICBmdW5jdGlvbiBibG9iVG9CYXNlNjQoYmxvYikge1xyXG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShyZXNvbHZlID0+IHtcclxuICAgICAgICAgICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcclxuICAgICAgICAgICAgcmVhZGVyLm9ubG9hZCA9IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGRhdGFVcmwgPSByZWFkZXIucmVzdWx0O1xyXG4gICAgICAgICAgICAgICAgY29uc3QgYmFzZTY0ID0gZGF0YVVybC5zcGxpdCgnLCcpWzFdO1xyXG4gICAgICAgICAgICAgICAgcmVzb2x2ZShiYXNlNjQpO1xyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICByZWFkZXIucmVhZEFzRGF0YVVSTChibG9iKTtcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcbn1cclxuXHJcbmNvbnN0IG1pbWVzID0ge1xyXG4gICAgJ2JtcCc6ICdpbWFnZS9ibXAnLFxyXG4gICAgJ2dpZic6ICdpbWFnZS9naWYnLFxyXG4gICAgJ2pwZWcnOiAnaW1hZ2UvanBlZycsXHJcbiAgICAnanBnJzogJ2ltYWdlL2pwZWcnLFxyXG4gICAgJ3BuZyc6ICdpbWFnZS9wbmcnLFxyXG4gICAgJ3BkZic6ICdhcHBsaWNhdGlvbi9wZGYnLFxyXG4gICAgJ3RpZic6ICdpbWFnZS90aWZmJyxcclxuICAgICd0aWZmJzogJ2ltYWdlL3RpZmYnLFxyXG4gICAgJ3dlYnAnOiAnaW1hZ2Uvd2VicCcsXHJcbiAgICAnemlwJzogJ2FwcGxpY2F0aW9uL3ppcCcsXHJcbiAgICAnN3onOiAnYXBwbGljYXRpb24veC03ei1jb21wcmVzc2VkJyxcclxuICAgICd0YXInOiAnYXBwbGljYXRpb24veC10YXInLFxyXG4gICAgJ3Jhcic6ICdhcHBsaWNhdGlvbi92bmQucmFyJ1xyXG59O1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGdldE1pbWUoZXh0ZW5zaW9uKSB7XHJcbiAgICBleHRlbnNpb24gPSBleHRlbnNpb24udG9Mb2NhbGVMb3dlckNhc2UoKTtcclxuICAgIHJldHVybiBtaW1lc1tleHRlbnNpb25dIHx8ICdhcHBsaWNhdGlvbi9vY3RldC1zdHJlYW0nO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gb3BlbkZpbGUoZmlsZSwgbmFtZSA9ICdvdXRwdXQudHh0Jykge1xyXG4gICAgdHJ5IHtcclxuICAgICAgICB2YXIgZWxlbSA9IHdpbmRvdy5kb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XHJcbiAgICAgICAgZWxlbS50YXJnZXQgPSAnX2JsYW5rJztcclxuICAgICAgICBlbGVtLmRvd25sb2FkID0gbmFtZTtcclxuICAgICAgICBjb25zdCBocmVmID0gd2luZG93LlVSTC5jcmVhdGVPYmplY3RVUkwoZmlsZSk7XHJcbiAgICAgICAgZWxlbS5ocmVmID0gaHJlZjtcclxuICAgICAgICBlbGVtLmNsaWNrKCk7XHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiBVUkwucmV2b2tlT2JqZWN0VVJMKGhyZWYpLCA2MDAwMCk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBkb3dubG9hZChibG9iLCBuYW1lID0gJ291dHB1dC50eHQnKSB7XHJcbiAgICBpZiAod2luZG93Lm5hdmlnYXRvci5tc1NhdmVPck9wZW5CbG9iKSB7XHJcbiAgICAgICAgd2luZG93Lm5hdmlnYXRvci5tc1NhdmVCbG9iKGJsb2IsIG5hbWUpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICB2YXIgZWxlbSA9IHdpbmRvdy5kb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XHJcbiAgICAgICAgZWxlbS50YXJnZXQgPSAnX2JsYW5rJztcclxuICAgICAgICBjb25zdCBocmVmID0gd2luZG93LlVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYik7XHJcbiAgICAgICAgZWxlbS5ocmVmID0gaHJlZjtcclxuICAgICAgICBlbGVtLmRvd25sb2FkID0gbmFtZTtcclxuICAgICAgICBlbGVtLmNsaWNrKCk7XHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiBVUkwucmV2b2tlT2JqZWN0VVJMKGhyZWYpLCA2MDAwMCk7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcm9zc0Jyb3dzZXJGaWxlVXBsb2FkKGFwaUNhbGwsIGZpbGUpIHtcclxuICAgIGlmICghIXdpbmRvdy5jaHJvbWUpIHtcclxuICAgICAgICBjb25zdCBmaWxlVXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChmaWxlKTtcclxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBhcGlDYWxsKHsgZmlsZVVybCwgbmFtZTogZmlsZS5uYW1lIH0pO1xyXG4gICAgICAgIFVSTC5yZXZva2VPYmplY3RVUkwoZmlsZVVybCk7XHJcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIGF3YWl0IGFwaUNhbGwoeyBmaWxlIH0pO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0U3Vic2l0ZSgpIHtcclxuICAgIHN3aXRjaCAod2luZG93LmxvY2F0aW9uLmhvc3Quc3Vic3RyKDAsIDcpKSB7XHJcbiAgICAgICAgY2FzZSAnZGlnaXRhbCc6XHJcbiAgICAgICAgICAgIHJldHVybiAnZGlnaXRhbCc7XHJcbiAgICAgICAgY2FzZSAnY3JlYXRpdic6XHJcbiAgICAgICAgICAgIHJldHVybiAnY3JlYXRpdmUnO1xyXG4gICAgICAgIGNhc2UgJ3BsYXRmb3InOlxyXG4gICAgICAgICAgICByZXR1cm4gJ3BsYXRmb3JtJztcclxuICAgICAgICBjYXNlICdhaS5zb2Z0JzpcclxuICAgICAgICAgICAgcmV0dXJuICdhaSc7XHJcbiAgICAgICAgY2FzZSAnZmluYW5jZSc6XHJcbiAgICAgICAgICAgIHJldHVybiAnZmluYW5jZWFjYWRlbXknO1xyXG4gICAgICAgIGNhc2UgJ2Rldi5kaWcnOlxyXG4gICAgICAgICAgICByZXR1cm4gJ2RldmRpZ2l0YWwnO1xyXG4gICAgICAgIGNhc2UgJ2Rldi5zb2YnOlxyXG4gICAgICAgICAgICByZXR1cm4gJ2RldnNvZnR1bmknO1xyXG4gICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgIHJldHVybiAncHJvZ3JhbW1pbmcnO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaGFzQ1BPQWNjZXNzKCkge1xyXG4gICAgcmV0dXJuIFsnZGlnaXRhbCcsICdjcmVhdGl2ZScsICdwcm9ncmFtbWluZycsICdkZXZkaWdpdGFsJywgJ2RldnNvZnR1bmknXS5pbmNsdWRlcyhnZXRTdWJzaXRlKCkpO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaXNBZG1pbigpIHtcclxuICAgIGNvbnN0IGUgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCdhW2hyZWY9XCIvYWRtaW5pc3RyYXRpb24vbmF2aWdhdGlvblwiIGldJyk7XHJcbiAgICBpZiAoZS5sZW5ndGggPiAwKSB7IHJldHVybiB0cnVlOyB9XHJcbiAgICBlbHNlIHsgcmV0dXJuIGZhbHNlOyB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBzZXJpYWxpemVDYWxscyhmbkFycmF5LCBkZWxheSkge1xyXG4gICAgY29uc3QgY2FsbEFycmF5ID0gW107XHJcblxyXG4gICAgaWYgKGRlbGF5ICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGZuQXJyYXkubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgY29uc3QgaGFuZGxlciA9IChyZXMsIHJlaikgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0VGltZW91dChhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZm5BcnJheVtpXSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXMocmVzdWx0KTtcclxuICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVqKGVycik7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSwgaSAqIGRlbGF5KTtcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgY29uc3QgcHIgPSBuZXcgUHJvbWlzZShoYW5kbGVyKTtcclxuXHJcbiAgICAgICAgICAgIGNhbGxBcnJheS5wdXNoKHByKTtcclxuICAgICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZm5BcnJheS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBjb25zdCBoYW5kbGVyID0gKHJlcywgcmVqKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoaSA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICBjYWxsQXJyYXlbaSAtIDFdLmZpbmFsbHkoYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZm5BcnJheVtpXSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzKHJlc3VsdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVqKGVycik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZm5BcnJheVtpXSgpLnRoZW4ocmVzKS5jYXRjaChyZWopO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBjb25zdCBwciA9IG5ldyBQcm9taXNlKGhhbmRsZXIpO1xyXG5cclxuICAgICAgICAgICAgY2FsbEFycmF5LnB1c2gocHIpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gY2FsbEFycmF5O1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gd2l0aFByb2dyZXNzKGNhbGxBcnJheSwgb25DaGFuZ2UsIGRlbGF5ID0gMTApIHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgLy8gRmFpbHNhdmUgZm9yIGVtcHR5IGNhbGxBcnJheVxyXG4gICAgICAgIGlmIChjYWxsQXJyYXkubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgb25DaGFuZ2UodW5kZWZpbmVkLCAwLCAxLCAxKTtcclxuICAgICAgICAgICAgcmVzb2x2ZShbXSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgcmVzb2x2ZWQgPSAwO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gW107XHJcbiAgICAgICAgY2FsbE5leHQoMCk7XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIGNhbGxOZXh0KGkpIHtcclxuICAgICAgICAgICAgaWYgKGkgPj0gY2FsbEFycmF5Lmxlbmd0aCkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY2FsbEFycmF5W2ldXHJcbiAgICAgICAgICAgICAgICAgICAgLnRoZW4ocmVzID0+IG9uUmVzb2x2ZShyZXMsIGkpKVxyXG4gICAgICAgICAgICAgICAgICAgIC5jYXRjaChvbkVycm9yKTtcclxuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4gY2FsbE5leHQoaSArIDEpLCBkZWxheSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIG9uUmVzb2x2ZShyZXMsIGluZGV4KSB7XHJcbiAgICAgICAgICAgIHJlc29sdmVkKys7XHJcbiAgICAgICAgICAgIGlmIChvbkNoYW5nZSkge1xyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2UocmVzLCBpbmRleCwgcmVzb2x2ZWQsIGNhbGxBcnJheS5sZW5ndGgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJlc3BvbnNlW2luZGV4XSA9IHJlcztcclxuICAgICAgICAgICAgaWYgKHJlc29sdmVkID09PSBjYWxsQXJyYXkubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgICAgICByZXNvbHZlKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZnVuY3Rpb24gb25FcnJvcihlKSB7XHJcbiAgICAgICAgICAgIHJlamVjdChlKTtcclxuICAgICAgICB9XHJcbiAgICB9KTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEB0eXBlZGVmIHsoY29tcGxldGVkOiBudW1iZXIsIHRvdGFsOiBudW1iZXIsIHJlc3BvbnNlLCBpbmRleDogbnVtYmVyKSA9PiB2b2lkfSBPblByb2dyZXNzRnVuY3Rpb25cclxuICovXHJcblxyXG4vKipcclxuICogQHR5cGVkZWYgeygpID0+IFByb21pc2V9IEFzeW5jRnVuY3Rpb25cclxuICovXHJcblxyXG4vKipcclxuICogSW5pdGlhdGUgcmVtb3RlIGNhbGxzIGF0IGludGVydmFsc1xyXG4gKiBAcGFyYW0ge0FycmF5PEFzeW5jRnVuY3Rpb24+fSBmbkFycmF5IFxyXG4gKiBAcGFyYW0ge09uUHJvZ3Jlc3NGdW5jdGlvbn0gb25Qcm9ncmVzcyBcclxuICogQHBhcmFtIHtudW1iZXJ9IFtkZWxheT0xMF1cclxuICogQHJldHVybnMgXHJcbiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGlzdHJpYnV0ZShmbkFycmF5LCBvblByb2dyZXNzLCBkZWxheSA9IDEwKSB7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHRvdGFsID0gZm5BcnJheS5sZW5ndGg7XHJcbiAgICAgICAgbGV0IGNvbXBsZXRlZCA9IDA7XHJcbiAgICAgICAgbGV0IHJlc29sdmVkID0gMDtcclxuXHJcbiAgICAgICAgLy8gRmFpbHNhdmUgZm9yIGVtcHR5IGZuQXJyYXlcclxuICAgICAgICBpZiAodG90YWwgPT0gMCkge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIG9uUHJvZ3Jlc3MgPT0gJ2Z1bmN0aW9uJykge1xyXG4gICAgICAgICAgICAgICAgb25Qcm9ncmVzcyh1bmRlZmluZWQsIDAsIDEsIDEpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJlc29sdmUoW10pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgY2FsbHMgPSBmbkFycmF5Lm1hcCgoZm4sIGkpID0+IHtcclxuICAgICAgICAgICAgY29uc3QgY2FsbCA9IHtcclxuICAgICAgICAgICAgICAgIGZuLFxyXG4gICAgICAgICAgICAgICAgc2VudDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICBjYW5jZWxsZWQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2U6IHVuZGVmaW5lZCxcclxuICAgICAgICAgICAgICAgIHRpbWVyOiBudWxsLFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBjYWxsLm9uQ2FsbCA9IG9uQ2FsbC5iaW5kKGNhbGwsIGkpO1xyXG4gICAgICAgICAgICBjYWxsLmNhbmNlbCA9IG9uQ2FuY2VsLmJpbmQoY2FsbCk7XHJcbiAgICAgICAgICAgIGNhbGwudGltZXIgPSBzZXRUaW1lb3V0KGNhbGwub25DYWxsLCBpICogZGVsYXkpO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuIGNhbGw7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgY2FsbHMuZm9yRWFjaCgoYywgaSkgPT4gYy5uZXh0ID0gY2FsbHNbaSArIDFdKTtcclxuXHJcbiAgICAgICAgYXN5bmMgZnVuY3Rpb24gb25DYWxsKGkpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuc2VudCA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgY2xlYXJUaW1lb3V0KHRoaXMudGltZXIpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNhbmNlbGxlZCA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zZW50ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcHJvbWlzZSA9IHRoaXMuZm4oKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnJlc3BvbnNlID0gYXdhaXQgcHJvbWlzZTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocHJvbWlzZS5fY2FjaGVIaXQgJiYgdGhpcy5uZXh0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubmV4dC5vbkNhbGwoKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZWQrKztcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5jYW5jZWxsZWQgPT0gZmFsc2UgJiYgcmVzb2x2ZWQgPT09IHRvdGFsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUoY2FsbHMubWFwKGMgPT4gYy5yZXNwb25zZSkpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICAgICAgICAgIG9uRXJyb3IoZXJyKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjb21wbGV0ZWQrKztcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBvblByb2dyZXNzID09ICdmdW5jdGlvbicpIHtcclxuICAgICAgICAgICAgICAgIG9uUHJvZ3Jlc3MoY29tcGxldGVkLCB0b3RhbCwgdGhpcy5yZXNwb25zZSwgaSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIG9uQ2FuY2VsKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jYW5jZWxsZWQgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY2FuY2VsbGVkID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLnNlbnQgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICBjbGVhclRpbWVvdXQodGhpcy50aW1lcik7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5vbkNhbGwoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZnVuY3Rpb24gb25FcnJvcihlKSB7XHJcbiAgICAgICAgICAgIGNhbGxzLmZvckVhY2goYyA9PiBjLmNhbmNlbCgpKTtcclxuICAgICAgICAgICAgaWYgKGUgaW5zdGFuY2VvZiBFcnJvcikge1xyXG4gICAgICAgICAgICAgICAgZS5fcmVzcG9uc2VzID0gY2FsbHMubWFwKGMgPT4gYy5yZXNwb25zZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmVqZWN0KGUpO1xyXG4gICAgICAgIH1cclxuICAgIH0pO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gYXNzZXJ0VGVtcGxhdGUodGVtcGxhdGUsIHRhcmdldCwgYm90dG9tID0gZmFsc2UpIHtcclxuICAgIGlmICh0ZW1wbGF0ZS5EYXRhICE9PSB1bmRlZmluZWQgJiYgdGVtcGxhdGUuVG90YWwgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgIHRlbXBsYXRlID0gdGVtcGxhdGUuRGF0YTtcclxuICAgICAgICB0YXJnZXQgPSB0YXJnZXQuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoQXJyYXkuaXNBcnJheSh0ZW1wbGF0ZSkpIHtcclxuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheSh0YXJnZXQpKSB7XHJcbiAgICAgICAgICAgIGlmIChib3R0b20pIHtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGFzc2VydFRlbXBsYXRlKHRlbXBsYXRlWzBdLCB0YXJnZXRbMF0sIHRydWUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignVGFyZ2V0IHR5cGUgbWlzbWF0Y2gnKTtcclxuICAgICAgICB9XHJcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiB0ZW1wbGF0ZSA9PT0gJ29iamVjdCcpIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRhcmdldCA9PT0gJ29iamVjdCcpIHtcclxuICAgICAgICAgICAgY29uc3QgbW9kZWwgPSBPYmplY3Qua2V5cyh0ZW1wbGF0ZSk7XHJcbiAgICAgICAgICAgIGZvciAobGV0IHByb3Agb2YgbW9kZWwpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0YXJnZXQuaGFzT3duUHJvcGVydHkocHJvcCkgPT09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignTWlzc2luZyBwcm9wZXJ0eSBvbiB0YXJnZXQ6ICcgKyBwcm9wKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1RhcmdldCB0eXBlIG1pc21hdGNoJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfSBlbHNlIGlmICh0eXBlb2YgdGVtcGxhdGUgIT09IHR5cGVvZiB0YXJnZXQpIHtcclxuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdUYXJnZXQgdHlwZSBtaXNtYXRjaCcpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGdldExvY2FsZSgpIHtcclxuICAgIHJldHVybiAnYmcnO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlVGhyb3R0bGVkRXhlY3V0b3IoY2FsbGJhY2ssIGRlbGF5KSB7XHJcbiAgICBsZXQgdGltZXIgPSBudWxsO1xyXG5cclxuICAgIHJldHVybiBmdW5jdGlvbiAoLi4ucGFyYW1zKSB7XHJcbiAgICAgICAgY2xlYXIoKTtcclxuICAgICAgICB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICBjbGVhcigpO1xyXG4gICAgICAgICAgICBjYWxsYmFjayguLi5wYXJhbXMpO1xyXG4gICAgICAgIH0sIGRlbGF5KTtcclxuICAgIH07XHJcblxyXG4gICAgZnVuY3Rpb24gY2xlYXIoKSB7XHJcbiAgICAgICAgaWYgKHRpbWVyICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aW1lcik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaWNvbkFzc2V0KG5hbWUpIHtcclxuICAgIHJldHVybiBicm93c2VyLnJ1bnRpbWUuZ2V0VVJMKGBpY29ucy8ke25hbWV9LnBuZ2ApO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZXNjYXBlSFRNTChzdHIpIHtcclxuICAgIHJldHVybiBzdHIucmVwbGFjZSgvWyY8Pl0vZyxcclxuICAgICAgICB0YWcgPT4gKHtcclxuICAgICAgICAgICAgJyYnOiAnJmFtcDsnLFxyXG4gICAgICAgICAgICAnPCc6ICcmbHQ7JyxcclxuICAgICAgICAgICAgJz4nOiAnJmd0OydcclxuICAgICAgICB9W3RhZ10pKVxyXG59O1xyXG5cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRGdW5kYW1lbnRhbExldmVsSWRzKGFwcG5hbWUpIHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgJ3Byb2dyYW1taW5nJzogW1xyXG4gICAgICAgICAgICAxOSxcclxuICAgICAgICAgICAgNDQsXHJcbiAgICAgICAgICAgIDU3LFxyXG4gICAgICAgICAgICA3MCxcclxuICAgICAgICAgICAgMTA2XHJcbiAgICAgICAgXSxcclxuICAgICAgICAnZGlnaXRhbCc6IFtcclxuICAgICAgICAgICAgNixcclxuICAgICAgICAgICAgNyxcclxuICAgICAgICAgICAgOCxcclxuICAgICAgICAgICAgMjMsXHJcbiAgICAgICAgICAgIDI0LFxyXG4gICAgICAgICAgICAyNSxcclxuICAgICAgICAgICAgMjcsXHJcbiAgICAgICAgICAgIDMzLFxyXG4gICAgICAgICAgICAzNSxcclxuICAgICAgICAgICAgNDBcclxuICAgICAgICBdLFxyXG4gICAgICAgICdjcmVhdGl2ZSc6IFtcclxuICAgICAgICAgICAgMjMsXHJcbiAgICAgICAgICAgIDI0LFxyXG4gICAgICAgICAgICA0MixcclxuICAgICAgICAgICAgNTJcclxuICAgICAgICBdXHJcbiAgICB9W2FwcG5hbWVdO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0UHJvZmVzc2lvbkluc3RhbmNlSWRzKGFwcG5hbWUpIHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgLy8gQ29tbWVudGVkIGFyZSBmb3IgUUFcclxuICAgICAgICAncHJvZ3JhbW1pbmcnOiBbXHJcbiAgICAgICAgICAgIDEwMDcsXHJcbiAgICAgICAgICAgIDEwMDksXHJcbiAgICAgICAgICAgIDEwMTAsXHJcbiAgICAgICAgICAgIDEwMTEsXHJcbiAgICAgICAgICAgIDEwMTIsXHJcbiAgICAgICAgICAgIDEwMTMsXHJcbiAgICAgICAgICAgIDEwMTQsXHJcbiAgICAgICAgICAgIDEwMTUsXHJcbiAgICAgICAgICAgIDEwMTYsXHJcbiAgICAgICAgICAgIDEwMTcsXHJcbiAgICAgICAgICAgIDEwMTgsXHJcbiAgICAgICAgICAgIDEwMjAsXHJcbiAgICAgICAgICAgIDEwMjIsXHJcbiAgICAgICAgICAgIDEwMjMsXHJcbiAgICAgICAgICAgIDEwMjQsXHJcbiAgICAgICAgICAgIDEwMjUsXHJcbiAgICAgICAgICAgIDEwMjYsXHJcbiAgICAgICAgICAgIC8vIDEwMjgsXHJcbiAgICAgICAgICAgIDEwMjksXHJcbiAgICAgICAgICAgIDEwMzAsXHJcbiAgICAgICAgICAgIDEwMzEsXHJcbiAgICAgICAgICAgIDEwMzIsXHJcbiAgICAgICAgICAgIDEwMzMsXHJcbiAgICAgICAgICAgIDEwMzQsXHJcbiAgICAgICAgICAgIDEwMzUsXHJcbiAgICAgICAgICAgIDEwMzYsXHJcbiAgICAgICAgICAgIDEwMzcsXHJcbiAgICAgICAgICAgIDEwMzgsXHJcbiAgICAgICAgICAgIDEwMzksXHJcbiAgICAgICAgICAgIDEwNDAsXHJcbiAgICAgICAgICAgIDEwNDEsXHJcbiAgICAgICAgICAgIDEwNDIsXHJcbiAgICAgICAgICAgIDEwNDMsXHJcbiAgICAgICAgICAgIDEwNDQsXHJcbiAgICAgICAgICAgIDEwNDUsXHJcbiAgICAgICAgICAgIDEwNDYsXHJcbiAgICAgICAgICAgIDEwNDcsXHJcbiAgICAgICAgICAgIDEwNDgsXHJcbiAgICAgICAgICAgIDEwNDksXHJcbiAgICAgICAgICAgIDEwNTAsXHJcbiAgICAgICAgICAgIDEwNTEsXHJcbiAgICAgICAgICAgIDEwNTIsXHJcbiAgICAgICAgICAgIDEwNTMsXHJcbiAgICAgICAgICAgIDEwNTQsXHJcbiAgICAgICAgICAgIDEwNTUsXHJcbiAgICAgICAgICAgIDEwNTYsXHJcbiAgICAgICAgICAgIDEwNTcsXHJcbiAgICAgICAgICAgIDEwNTgsXHJcbiAgICAgICAgICAgIDEwNTksXHJcbiAgICAgICAgICAgIDEwNjAsXHJcbiAgICAgICAgICAgIDEwNjEsXHJcbiAgICAgICAgICAgIDEwNjIsXHJcbiAgICAgICAgICAgIDEwNjMsXHJcbiAgICAgICAgICAgIDEwNjQsXHJcbiAgICAgICAgICAgIDEwNjUsXHJcbiAgICAgICAgICAgIDEwNjYsXHJcbiAgICAgICAgICAgIC8vIDEwNjcsXHJcbiAgICAgICAgICAgIC8vIDEwNjgsXHJcbiAgICAgICAgICAgIC8vIDEwNjksXHJcbiAgICAgICAgICAgIDEwNzAsXHJcbiAgICAgICAgICAgIDEwNzEsXHJcbiAgICAgICAgICAgIDEwNzIsXHJcbiAgICAgICAgICAgIDEwNzMsXHJcbiAgICAgICAgICAgIDEwNzQsXHJcbiAgICAgICAgICAgIDEwNzUsXHJcbiAgICAgICAgICAgIDEwNzYsXHJcbiAgICAgICAgICAgIDEwNzcsXHJcbiAgICAgICAgICAgIDEwNzhcclxuICAgICAgICBdLFxyXG4gICAgICAgICdkaWdpdGFsJzogW1xyXG4gICAgICAgICAgICAxLFxyXG4gICAgICAgICAgICAzLFxyXG4gICAgICAgICAgICA0LFxyXG4gICAgICAgICAgICA1LFxyXG4gICAgICAgICAgICA2LFxyXG4gICAgICAgICAgICA3LFxyXG4gICAgICAgICAgICA4LFxyXG4gICAgICAgICAgICA5XHJcbiAgICAgICAgXSxcclxuICAgICAgICAnY3JlYXRpdmUnOiBbXHJcbiAgICAgICAgICAgIDEsXHJcbiAgICAgICAgICAgIDMsXHJcbiAgICAgICAgICAgIDQsXHJcbiAgICAgICAgICAgIDVcclxuICAgICAgICBdLFxyXG4gICAgICAgICdkZXZkaWdpdGFsJzogW1xyXG4gICAgICAgICAgICAxLFxyXG4gICAgICAgICAgICAzLFxyXG4gICAgICAgICAgICA0LFxyXG4gICAgICAgICAgICA1LFxyXG4gICAgICAgICAgICA2LFxyXG4gICAgICAgICAgICA3LFxyXG4gICAgICAgICAgICA4LFxyXG4gICAgICAgICAgICA5XHJcbiAgICAgICAgXSxcclxuICAgIH1bYXBwbmFtZV07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRFeGNsdWRlZE1vZHVsZXMoYXBwbmFtZSkge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICAncHJvZ3JhbW1pbmcnOiBbXHJcbiAgICAgICAgICAgIDJcclxuICAgICAgICBdXHJcbiAgICB9W2FwcG5hbWVdO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0RXhjbHVkZWRNb2R1bGVJbnN0YW5jZXMoYXBwbmFtZSkge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICAnZGlnaXRhbCc6IFtcclxuICAgICAgICAgICAgNSxcclxuICAgICAgICAgICAgNTBcclxuICAgICAgICBdLFxyXG4gICAgICAgICdjcmVhdGl2ZSc6IFtcclxuICAgICAgICAgICAgMSxcclxuICAgICAgICAgICAgMTQsXHJcbiAgICAgICAgICAgIDI4LFxyXG4gICAgICAgICAgICA0NlxyXG4gICAgICAgIF0sXHJcbiAgICAgICAgJ2RldmRpZ2l0YWwnOiBbXHJcbiAgICAgICAgICAgIDUsXHJcbiAgICAgICAgICAgIDUwXHJcbiAgICAgICAgXSxcclxuICAgIH1bYXBwbmFtZV07XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBAZGVzY3JpcHRpb24gUm91bmRzIHVwIGEgbnVtYmVyIHVwIHRvIHNwZWNpZmllZCBudW1iZXIgb2YgZGVjaW1hbCBwbGFjZXMgdXNpbmcgYSBzcGVjaWZpZWQgbnVtYmVyIG9mIGRlY2ltYWwgcGxhY2VzIGFzIHByZWNpc2lvbi5cclxuICogVGhpcyBhbGxvd3MgY29ycmVjdCByb3VuZGluZyBvZiBwcm9ibGVtYXRpYyBmbG9hdGluZyBwb2ludCBudW1iZXJzIGxpa2UgXCI1NS4wMDAwMDAwMDAwMDAwMVwiIG9yIFwiMC40NjAwMDAwMDAwMDAwMDFcIlxyXG4gKiBAcGFyYW0ge051bWJlcn0gbnVtYmVyIFRoZSBudW1iZXIgdG8gcm91bmQgdXBcclxuICogQHBhcmFtIHtOdW1iZXJ9IGRlY2ltYWxQbGFjZXNUb1JvdW5kVG8gVGhlIG51bWJlciBvZiBkZWNpbWFsIHBsYWNlcyB0byByb3VuZCB0b1xyXG4gKiBAcGFyYW0ge051bWJlcn0gZGVjaW1hbFBsYWNlc1ByZWNpc2lvbiBUaGUgbnVtYmVyIG9mIGRlY2ltYWwgcGxhY2VzIHRoYXQgc2hvdWxkIGJlIGNvbnNpZGVyZWQgZm9yIHRoZSByb3VuZGluZy4gU2hvdWxkIGJlIGxhcmdlciB0aGFuIGRlY2ltYWxQbGFjZXNUb1JvdW5kVG9cclxuICogQHJldHVybnMgVGhlIHJvdW5kZWQgbnVtYmVyXHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gcm91bmRVcFdpdGhQcmVjaXNpb24obnVtYmVyLCBkZWNpbWFsUGxhY2VzVG9Sb3VuZFRvLCBkZWNpbWFsUGxhY2VzUHJlY2lzaW9uKSB7XHJcbiAgICBpZiAoZGVjaW1hbFBsYWNlc1ByZWNpc2lvbiA8PSBkZWNpbWFsUGxhY2VzVG9Sb3VuZFRvKSB7XHJcbiAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ2RlY2ltYWxQbGFjZXNQcmVjaXNpb24gc2hvdWxkIGJlIGxhcmdlciB0aGFuIGRlY2ltYWxQbGFjZXNUb1JvdW5kVG8nKTtcclxuICAgIH1cclxuXHJcbiAgICBsZXQgcHJlY2lzaW9uVmFsdWUgPSAxMCAqKiBkZWNpbWFsUGxhY2VzUHJlY2lzaW9uO1xyXG4gICAgbGV0IHJvdW5kaW5nVmFsdWUgPSAxMCAqKiBkZWNpbWFsUGxhY2VzVG9Sb3VuZFRvO1xyXG4gICAgbGV0IHJvdW5kaW5nVmFsdWVCaWdJbnQgPSBCaWdJbnQocm91bmRpbmdWYWx1ZSk7XHJcbiAgICBsZXQgcHJlY2lzaW9uRGlmZmVyZW5jZVZhbHVlID0gQmlnSW50KHByZWNpc2lvblZhbHVlIC8gcm91bmRpbmdWYWx1ZSk7XHJcblxyXG4gICAgbGV0IGJpZ0ludCA9IEJpZ0ludChNYXRoLnRydW5jKG51bWJlciAqIHByZWNpc2lvblZhbHVlKSk7XHJcbiAgICBsZXQgcm91bmRlZFBsYWNlc051bWJlclBhcnQgPSBiaWdJbnQgLyBwcmVjaXNpb25EaWZmZXJlbmNlVmFsdWU7XHJcblxyXG4gICAgbGV0IHByZWNpc2lvbkRpZmZlcmVuY2VMZWZ0b3ZlciA9IGJpZ0ludCAlIHByZWNpc2lvbkRpZmZlcmVuY2VWYWx1ZTtcclxuICAgIHJvdW5kZWRQbGFjZXNOdW1iZXJQYXJ0ICs9IHByZWNpc2lvbkRpZmZlcmVuY2VMZWZ0b3ZlciA+IDAgPyAxbiA6IDBuO1xyXG5cclxuICAgIGxldCBudW1iZXJQYXJ0ID0gcm91bmRlZFBsYWNlc051bWJlclBhcnQgLyByb3VuZGluZ1ZhbHVlQmlnSW50O1xyXG4gICAgbGV0IGRlY2ltYWxQYXJ0ID0gcm91bmRlZFBsYWNlc051bWJlclBhcnQgJSByb3VuZGluZ1ZhbHVlQmlnSW50O1xyXG5cclxuICAgIGxldCByb3VuZGVkTnVtID0gTnVtYmVyKGAke251bWJlclBhcnR9LiR7ZGVjaW1hbFBhcnQudG9TdHJpbmcoKS5wYWRTdGFydChkZWNpbWFsUGxhY2VzVG9Sb3VuZFRvLCAnMCcpfWApO1xyXG4gICAgcmV0dXJuIHJvdW5kZWROdW07XHJcbn0iLCIvLyBUaGUgbW9kdWxlIGNhY2hlXG52YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307XG5cbi8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG5mdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuXHR2YXIgY2FjaGVkTW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0aWYgKGNhY2hlZE1vZHVsZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0cmV0dXJuIGNhY2hlZE1vZHVsZS5leHBvcnRzO1xuXHR9XG5cdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG5cdHZhciBtb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdID0ge1xuXHRcdC8vIG5vIG1vZHVsZS5pZCBuZWVkZWRcblx0XHQvLyBubyBtb2R1bGUubG9hZGVkIG5lZWRlZFxuXHRcdGV4cG9ydHM6IHt9XG5cdH07XG5cblx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG5cdF9fd2VicGFja19tb2R1bGVzX19bbW9kdWxlSWRdKG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG5cdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG5cdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbn1cblxuIiwiLy8gZGVmaW5lIGdldHRlciBmdW5jdGlvbnMgZm9yIGhhcm1vbnkgZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5kID0gKGV4cG9ydHMsIGRlZmluaXRpb24pID0+IHtcblx0Zm9yKHZhciBrZXkgaW4gZGVmaW5pdGlvbikge1xuXHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhkZWZpbml0aW9uLCBrZXkpICYmICFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywga2V5KSkge1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIGtleSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGRlZmluaXRpb25ba2V5XSB9KTtcblx0XHR9XG5cdH1cbn07IiwiX193ZWJwYWNrX3JlcXVpcmVfXy5vID0gKG9iaiwgcHJvcCkgPT4gKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIHByb3ApKSIsIi8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uciA9IChleHBvcnRzKSA9PiB7XG5cdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuXHR9XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG59OyIsImltcG9ydCB0ZW1wbGF0ZSBmcm9tICcuLi91dGlsL3RlbXBsYXRlJztcclxuaW1wb3J0IHsgZ2V0U3Vic2l0ZSB9IGZyb20gJy4uL3V0aWwvdXRpbCc7XHJcblxyXG5jb25zdCB0YWJJbmRleGVzID0ge1xyXG4gICAgdHJhaW5pbmdzOiB7XHJcbiAgICAgICAgcHJvZ3JhbW1pbmc6IDMsXHJcbiAgICAgICAgZGlnaXRhbDogNCxcclxuICAgICAgICBjcmVhdGl2ZTogNCxcclxuICAgICAgICBhaTogNCxcclxuICAgICAgICBmaW5hbmNlYWNhZGVteTogNCxcclxuICAgICAgICBkZXZkaWdpdGFsOiA0XHJcbiAgICB9LFxyXG4gICAgc3RhdHM6IHtcclxuICAgICAgICBwcm9ncmFtbWluZzogMTQsXHJcbiAgICAgICAgZGlnaXRhbDogMTAsXHJcbiAgICAgICAgY3JlYXRpdmU6IDEwLFxyXG4gICAgICAgIGFpOiAxMCxcclxuICAgICAgICBmaW5hbmNlYWNhZGVteTogMTEsXHJcbiAgICAgICAgZGV2ZGlnaXRhbDogMTBcclxuICAgIH0sXHJcbiAgICBxdWl6OiB7XHJcbiAgICAgICAgcHJvZ3JhbW1pbmc6IDEzXHJcbiAgICB9LFxyXG4gICAgc3RyZWFtOiB7XHJcbiAgICAgICAgcHJvZ3JhbW1pbmc6IDEsXHJcbiAgICAgICAgZGlnaXRhbDogMyxcclxuICAgICAgICBjcmVhdGl2ZTogMyxcclxuICAgICAgICBhaTogMyxcclxuICAgICAgICBmaW5hbmNlYWNhZGVteTogMyxcclxuICAgICAgICBkZXZkaWdpdGFsOiAzXHJcbiAgICB9XHJcbn07XHJcblxyXG5pbnNlcnRNZW51cygpO1xyXG5cclxuZnVuY3Rpb24gaW5zZXJ0TWVudXMoKSB7XHJcbiAgICBjb25zdCBzdWJzaXRlID0gZ2V0U3Vic2l0ZSgpO1xyXG4gICAgY29uc3QgbWVudXMgPSBbXTtcclxuICAgIHN3aXRjaCAoc3Vic2l0ZSkge1xyXG4gICAgICAgIGNhc2UgJ3Byb2dyYW1taW5nJzpcclxuICAgICAgICAgICAgbWVudXMucHVzaCh7IGluZGV4OiB0YWJJbmRleGVzLnRyYWluaW5nc1tzdWJzaXRlXSwgbmFtZTogJ0NvdXJzZSBNYW5hZ2VyJywgdXJsOiAnL3Nlcy9jb3Vyc2UnIH0pO1xyXG4gICAgICAgICAgICBtZW51cy5wdXNoKHsgaW5kZXg6IHRhYkluZGV4ZXMuc3RhdHNbc3Vic2l0ZV0sIG5hbWU6ICdTdXJ2ZXkgQWdncmVnYXRlJywgdXJsOiAnL3Nlcy9zdXJ2ZXlzJyB9KTtcclxuICAgICAgICAgICAgbWVudXMucHVzaCh7IGluZGV4OiB0YWJJbmRleGVzLnN0YXRzW3N1YnNpdGVdLCBuYW1lOiAnU2Vhc29uIFN0YXRzJywgdXJsOiAnL3Nlcy9zdGF0cycgfSk7XHJcbiAgICAgICAgICAgIG1lbnVzLnB1c2goeyBpbmRleDogdGFiSW5kZXhlcy5xdWl6W3N1YnNpdGVdLCBuYW1lOiAnUXVpeiBNYW5hZ2VtZW50JywgdXJsOiAnL3Nlcy9xdWl6JyB9KTtcclxuICAgICAgICAgICAgbWVudXMucHVzaCh7IGluZGV4OiB0YWJJbmRleGVzLnN0cmVhbVtzdWJzaXRlXSwgbmFtZTogJ1N0cmVhbSBEYXNoYm9hcmQnLCB1cmw6ICcvc2VzL3N0cmVhbScgfSk7XHJcbiAgICAgICAgICAgIG1lbnVzLnB1c2goeyBpbmRleDogdGFiSW5kZXhlcy50cmFpbmluZ3Nbc3Vic2l0ZV0sIG5hbWU6ICdUcmFpbmluZ3MgT3ZlcnZpZXcnLCB1cmw6ICcvc2VzL292ZXJ2aWV3JyB9KTtcclxuICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgY2FzZSAnZGlnaXRhbCc6XHJcbiAgICAgICAgY2FzZSAnY3JlYXRpdmUnOlxyXG4gICAgICAgIGNhc2UgJ2RldmRpZ2l0YWwnOlxyXG4gICAgICAgIGNhc2UgJ2FpJzpcclxuICAgICAgICAgICAgbWVudXMucHVzaCh7IGluZGV4OiB0YWJJbmRleGVzLnRyYWluaW5nc1tzdWJzaXRlXSwgbmFtZTogJ0NvdXJzZSBNYW5hZ2VyJywgdXJsOiAnL3Nlcy9jb3Vyc2UnIH0pO1xyXG4gICAgICAgICAgICBtZW51cy5wdXNoKHsgaW5kZXg6IHRhYkluZGV4ZXMuc3RhdHNbc3Vic2l0ZV0sIG5hbWU6ICdTdXJ2ZXkgQWdncmVnYXRlJywgdXJsOiAnL3Nlcy9zdXJ2ZXlzJyB9KTtcclxuICAgICAgICAgICAgbWVudXMucHVzaCh7IGluZGV4OiB0YWJJbmRleGVzLnN0YXRzW3N1YnNpdGVdLCBuYW1lOiAnU2Vhc29uIFN0YXRzJywgdXJsOiAnL3Nlcy9zdGF0cycgfSk7XHJcbiAgICAgICAgICAgIG1lbnVzLnB1c2goeyBpbmRleDogdGFiSW5kZXhlcy5zdHJlYW1bc3Vic2l0ZV0sIG5hbWU6ICdTdHJlYW0gRGFzaGJvYXJkJywgdXJsOiAnL3Nlcy9zdHJlYW0nIH0pO1xyXG4gICAgICAgICAgICBtZW51cy5wdXNoKHsgaW5kZXg6IHRhYkluZGV4ZXMudHJhaW5pbmdzW3N1YnNpdGVdLCBuYW1lOiAnVHJhaW5pbmdzIE92ZXJ2aWV3JywgdXJsOiAnL3Nlcy9vdmVydmlldycgfSk7XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgJ2ZpbmFuY2VhY2FkZW15JzpcclxuICAgICAgICAgICAgbWVudXMucHVzaCh7IGluZGV4OiB0YWJJbmRleGVzLnRyYWluaW5nc1tzdWJzaXRlXSwgbmFtZTogJ0NvdXJzZSBNYW5hZ2VyJywgdXJsOiAnL3Nlcy9jb3Vyc2UnIH0pO1xyXG4gICAgICAgICAgICBtZW51cy5wdXNoKHsgaW5kZXg6IHRhYkluZGV4ZXMuc3RhdHNbc3Vic2l0ZV0sIG5hbWU6ICdTdXJ2ZXkgQWdncmVnYXRlJywgdXJsOiAnL3Nlcy9zdXJ2ZXlzJyB9KTtcclxuICAgICAgICAgICAgbWVudXMucHVzaCh7IGluZGV4OiB0YWJJbmRleGVzLnN0cmVhbVtzdWJzaXRlXSwgbmFtZTogJ1N0cmVhbSBEYXNoYm9hcmQnLCB1cmw6ICcvc2VzL3N0cmVhbScgfSk7XHJcbiAgICAgICAgICAgIG1lbnVzLnB1c2goeyBpbmRleDogdGFiSW5kZXhlcy50cmFpbmluZ3Nbc3Vic2l0ZV0sIG5hbWU6ICdUcmFpbmluZ3MgT3ZlcnZpZXcnLCB1cmw6ICcvc2VzL292ZXJ2aWV3JyB9KTtcclxuICAgICAgICAgICAgYnJlYWs7XHJcbiAgICB9XHJcbiAgICBtZW51cy5mb3JFYWNoKG0gPT4gaW5zZXJ0TWVudUl0ZW0obS5pbmRleCwgbS5uYW1lLCBtLnVybCwgJ2ljb25zL2ljb240OC5wbmcnKSk7XHJcbn1cclxuXHJcblxyXG5mdW5jdGlvbiBpbnNlcnRNZW51SXRlbSh0YWJJbmRleCwgbGFiZWwsIGhyZWYsIGljb25QYXRoKSB7XHJcbiAgICBjb25zdCBpY29uVVJMID0gYnJvd3Nlci5ydW50aW1lLmdldFVSTChpY29uUGF0aCk7XHJcblxyXG4gICAgY29uc3QgY29udGFpbmVyID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI0FkbWluaXN0cmF0aW9uTmF2aWdhdGlvbi0nICsgdGFiSW5kZXgpLmNoaWxkcmVuWzBdO1xyXG4gICAgY29uc3Qgcm93ID0gZ2V0T3JDcmVhdGVSb3coY29udGFpbmVyKTtcclxuXHJcbiAgICBjb25zdCBjb2wgPSB0ZW1wbGF0ZS5lbGVtZW50KCdkaXYnLCBudWxsLCB7XHJcbiAgICAgICAgY2xhc3NMaXN0OiBnZXRTdHlsZSgpXHJcbiAgICB9KTtcclxuICAgIGNvbnN0IGFuY2hvciA9IHRlbXBsYXRlLmVsZW1lbnQoJ2EnLCBbXHJcbiAgICAgICAgdGVtcGxhdGUuZWxlbWVudCgnaW1nJywgbnVsbCwge1xyXG4gICAgICAgICAgICB0aXRsZTogbGFiZWwsXHJcbiAgICAgICAgICAgIHNyYzogaWNvblVSTCxcclxuICAgICAgICAgICAgYWx0OiBsYWJlbCxcclxuICAgICAgICAgICAgY2xhc3NMaXN0OiAnYm90dG9tLWJ1ZmZlcidcclxuICAgICAgICB9KSxcclxuICAgICAgICB0ZW1wbGF0ZS5lbGVtZW50KCdkaXYnLCBsYWJlbCwge1xyXG4gICAgICAgICAgICBjbGFzc0xpc3Q6ICdib3R0b20tYnVmZmVyJ1xyXG4gICAgICAgIH0pXHJcbiAgICBdLCB7XHJcbiAgICAgICAgaHJlZlxyXG4gICAgfSk7XHJcblxyXG4gICAgY29sLmFwcGVuZChhbmNob3IpO1xyXG4gICAgcm93LmFwcGVuZChjb2wpO1xyXG5cclxuXHJcbiAgICBmdW5jdGlvbiBnZXRPckNyZWF0ZVJvdyhjb250YWluZXIpIHtcclxuICAgICAgICBjb25zdCBsYXN0Um93ID0gWy4uLmNvbnRhaW5lci5xdWVyeVNlbGVjdG9yQWxsKCcucm93LmJvdHRvbS1idWZmZXInKV0ucG9wKCk7XHJcbiAgICAgICAgY29uc3QgY29scyA9IGxhc3RSb3cucXVlcnlTZWxlY3RvckFsbCgnLmNvbC1tZC0zJyk7XHJcbiAgICAgICAgaWYgKGNvbHMubGVuZ3RoIDwgNCkge1xyXG4gICAgICAgICAgICByZXR1cm4gbGFzdFJvdztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBjb25zdCByb3cgPSB0ZW1wbGF0ZS5lbGVtZW50KCdkaXYnLCBudWxsLCB7XHJcbiAgICAgICAgICAgICAgICBjbGFzc0xpc3Q6ICdyb3cgbm8tbWFyZ2luLW9mZnNldCB0ZXh0LWNlbnRlciBib3R0b20tYnVmZmVyJ1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgY29udGFpbmVyLmFwcGVuZENoaWxkKHJvdyk7XHJcbiAgICAgICAgICAgIHJldHVybiByb3c7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRTdHlsZSgpIHtcclxuICAgIHN3aXRjaCAoZ2V0U3Vic2l0ZSgpKSB7XHJcbiAgICAgICAgY2FzZSAncHJvZ3JhbW1pbmcnOlxyXG4gICAgICAgICAgICByZXR1cm4gJ2NvbC1tZC0zJztcclxuICAgICAgICBjYXNlICdkaWdpdGFsJzpcclxuICAgICAgICBjYXNlICdjcmVhdGl2ZSc6XHJcbiAgICAgICAgY2FzZSAncGxhdGZvcm0nOlxyXG4gICAgICAgIGNhc2UgJ2RldmRpZ2l0YWwnOlxyXG4gICAgICAgIGNhc2UgJ2FpJzogXHJcbiAgICAgICAgY2FzZSAnZmluYW5jZWFjYWRlbXknOlxyXG4gICAgICAgICAgICByZXR1cm4gJ2NvbC1tZC0zIG5vLXBhZGRpbmcnO1xyXG4gICAgfVxyXG59Il0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9