/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!**********************************************!*\
  !*** ./src/service-worker/service-worker.js ***!
  \**********************************************/
try {
  //Load code that equalizes changes between browsers and manifest versions
  //Ensure cross-manifest-polyfill is loaded after browser-polyfill
  importScripts('./static/browser-polyfill.min.js', './static/cross-manifest-polyfill.js');
  importScripts('./background-scripts/api.js', './background-scripts/data.js', './background-scripts/tools.js');
} catch (e) {
  console.error(e);
}
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9kZXYvL2JhY2tncm91bmQtc2VydmljZS13b3JrZXIuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vc29mdHVuaS1lbmhhbmNlbWVudC1zdWl0ZS8uL3NyYy9zZXJ2aWNlLXdvcmtlci9zZXJ2aWNlLXdvcmtlci5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJ0cnl7XHJcbiAgICAvL0xvYWQgY29kZSB0aGF0IGVxdWFsaXplcyBjaGFuZ2VzIGJldHdlZW4gYnJvd3NlcnMgYW5kIG1hbmlmZXN0IHZlcnNpb25zXHJcbiAgICAvL0Vuc3VyZSBjcm9zcy1tYW5pZmVzdC1wb2x5ZmlsbCBpcyBsb2FkZWQgYWZ0ZXIgYnJvd3Nlci1wb2x5ZmlsbFxyXG4gICAgaW1wb3J0U2NyaXB0cygnLi9zdGF0aWMvYnJvd3Nlci1wb2x5ZmlsbC5taW4uanMnLCAnLi9zdGF0aWMvY3Jvc3MtbWFuaWZlc3QtcG9seWZpbGwuanMnKTtcclxuICAgIGltcG9ydFNjcmlwdHMoJy4vYmFja2dyb3VuZC1zY3JpcHRzL2FwaS5qcycsICcuL2JhY2tncm91bmQtc2NyaXB0cy9kYXRhLmpzJywgJy4vYmFja2dyb3VuZC1zY3JpcHRzL3Rvb2xzLmpzJylcclxufSBjYXRjaChlKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKGUpO1xyXG59XHJcbiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==